# MECH ASSAULT — Final Offline Build Package

This package is a continuation of the existing `mech-assault-full-game-rebuild` project. It is **not** a fresh project or a restart from the skeleton.

## Included from the existing build
- 3D Hangar and robot/titan selection flow
- Deep robot -> equipment -> weapon -> detail -> upgrade navigation
- Pilot, drone and specialization workspaces
- Robot/titan inventory and store systems
- Persistent offline GameState/economy/loadouts
- Offline Game Modes -> Matchmaking -> Deployment -> Combat flow
- Battle loading/deployment presentation
- Combat HUD, abilities, weapons, AI, hazards and touch controls
- Post-battle statistics/rewards and local persistence
- Missions, operations, events, data pads, collections, leaderboards, profile and offline social/clan shells
- Settings and HUD editor workspace

## Important
The build is intentionally branded MECH ASSAULT and uses original naming/UI rather than copying proprietary War Robots assets.

The supplied environment does not contain the project's Godot 4.4.1 executable, so this package has not been engine-rendered/exported in this environment. The source-level project is preserved as built; run it in the documented Godot environment for the final engine compile/export.
