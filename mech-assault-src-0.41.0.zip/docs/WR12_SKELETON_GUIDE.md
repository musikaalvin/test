# MECH ASSAULT // War Robots 12.3-12.4 Reference Skeleton

This project now has a data-driven integration layer for the user's owned/licensed assets. The repository does **not** include third-party War Robots art, audio, source code, or UI files.

## What is wired

- `data/mech_assault_reference_12_4.json` is the canonical reference manifest.
- `ContentRegistry` resolves robot, weapon, pilot, drone and UI assets from `res://assets`.
- Robot visual scenes accept common candidates such as `res://assets/robots/<ID>/robot.tscn` or `model.glb`.
- Weapon/pilot/drone asset hooks are data-driven and can be added without changing every UI screen.
- The Hangar -> Robot -> Weapon Select -> Weapon Detail -> Upgrade stack remains deep/navigation-first.
- Loading screen now accepts a full battle background and hero image, with the existing procedural fallback kept intact.
- A generic controller prompt rail shows A/B/X/Y, LB/RB and Start bindings when an XInput/PlayStation-style pad is connected.
- `InputRouter` already exposes the corresponding gamepad actions, so the prompt rail is the visible contract rather than a second input system.

## Asset drop-in contract

Preferred robot layout:

```text
res://assets/robots/SCARAB/robot.tscn
res://assets/robots/SCARAB/model.glb
res://assets/robots/SCARAB/animations/
res://assets/robots/SCARAB/mounts.json
res://assets/robots/SCARAB/thumbnail.png
res://assets/robots/SCARAB/vfx/
res://assets/robots/SCARAB/sfx/
```

Titan assets use `res://assets/titans/<ID>/...` with a fallback candidate under `res://assets/robots/<ID>/...`. Weapons, pilots and drones follow the same pattern in the manifest.

## Reference snapshot included

The manifest records public 12.3 / 12.4 values where the patch notes explicitly expose them. Examples: Fang's Sandcloak behavior, Bedwyr's Duel/Barrier Field contract, Ravager's post-11.2 Veil changes, Iaraghi, Harmattan, Ultimate Rime and Ultimate Glacier values, and the 12.4 pilot/drone additions.

Entries without a verified public numeric snapshot are deliberately marked as `asset_mapping_only` or `name_only`; do not invent values just to fill the table. Populate them from the target 12.4 source snapshot you choose, then connect them to the runtime systems.

## Next integration step

The remaining work is intentionally left at the skeleton boundary: connect each imported asset's animation names and weapon sockets to the existing `RobotRig`, `WeaponMount`, ability and VFX systems. That keeps the source architecture stable while allowing the existing owned assets to supply the final appearance/animation layer.
