# Weapon Catalog Expansion

The 12.4 reference catalog has been expanded from the original 11 weapon hooks to **63 weapon profiles**:

- **41 robot-weapon profiles**
- **19 Titan-weapon profiles**
- remaining entries are legacy/ultimate/reference hooks retained for compatibility

The expansion is data-driven. Every profile has an asset contract for model, animation, thumbnail, VFX and SFX, so the project's existing owned assets can be mounted without changing the UI architecture.

## Public reference coverage

The catalog includes documented 12.0–12.4 weapon families from official War Robots patch notes, including Iaraghi, Lumen, Voonith/Urhag/Shantak, Celsius/Fahrenheit/Kelvin, Rime/Cryo/Glacier, Toxin/Venom variants, Gladius/Pilum and Titan families such as Furnace/Torch, Venire/Vincere, Void/Chasm, Muninn/Huginn, Equalizer/Arbiter, Vajra/Maha Vajra, Striker and Evora/Veyron.

Where an official patch note exposes only a balance delta rather than a complete weapon specification, the profile is marked `stats_completeness: partial`. No missing values are invented.

## Sources

- War Robots 12.0 update notes: https://warrobots.com/en/posts/414
- War Robots 12.1 update notes: https://warrobots.com/en/posts/416
- War Robots 12.2 update notes: https://warrobots.com/en/posts/417
- War Robots 12.4 update notes: https://warrobots.com/en/posts/422
