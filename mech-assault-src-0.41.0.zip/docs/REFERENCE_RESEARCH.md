# Public reference snapshot used by the skeleton

The integration manifest is based on the public War Robots 12.3 and 12.4 patch notes plus public robot reference pages. It is a design/data reference only; it does not include third-party assets or code.

Sources:

- 12.4 Update Notes: https://warrobots.com/en/posts/422
- 12.3 Update Notes: https://warrobots.com/en/posts/418
- Bedwyr overview: https://warrobots.com/en/robots/102?content_block=124

Key public values carried into the manifest:

- 12.4 Dedopali: three remote pods, Invisibility 7 s, 15 s cooldown, Swarm 7 s, Gravity Lift 7 s, 8 s ability cooldown, 1 Heavy + 2 Light, 330,000 durability, 50 km/h.
- 12.4 Iaraghi: Energy, 600 m, full-charge damage 45,000 / 67,500 / 90,000 (L/M/H), 6 particles, 1 s shot interval, 6 ammo, 5 s primary + 5 s secondary reload intervals, reload amount 1 + 5.
- 12.4 Ultimate Shell: 7 s ability, 5 s cooldown, 245% speed increase, 305,550 / 213,900 / 168,000 front/side/rear shields, 1 Heavy + 2 Light, 601,000 durability, 43 km/h.
- 12.4 Ultimate Rime / Glacier: 350 m, 1 particle, 0.06 s shot interval, 35 ammo, 0.3 s reload, damage 2,205 / 4,032 respectively.
- 12.3 Fang / Omen Fang: Sandcloak dash + Stealth reference, four Medium slots in the public Fang build; Omen Fang is the Special Edition introduced in 12.3.
- Bedwyr: Duel applies Deathmark + Taunt; Barrier Field is an Absorber wall that turns absorbed damage into Titan durability; the Titan has passive durability regeneration.

Numbers from the official patch notes are maxed-item figures and are subject to later balance changes. Entries where the public source did not expose the exact target snapshot are deliberately flagged instead of being fabricated.
