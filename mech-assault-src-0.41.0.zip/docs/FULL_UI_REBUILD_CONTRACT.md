# MECH ASSAULT — Full UI/UX skeleton contract

This pass incorporates the attached full rebuild specification as a **runtime/architecture contract** rather than pretending the placeholder hub screens are already production-complete. The source asks for a full game interface, modular navigation, context restoration, separate equipment/inventory/store experiences, controller/mobile/PC input, state coverage, and rendered validation.

## Added

- `data/mech_assault_full_ui_contract.json` — machine-readable screen/state/input/flow contract.
- `src/ui/ui_contract.gd` — runtime metadata reader; it does not duplicate robot/weapon gameplay data.
- Additional UI routes in `UIManager`: settings sub-screens, battle/pause/robot-selection states, reward claim, errors, tutorial, confirmation, notifications and a dedicated robot-equipment route.
- Matching skeleton pages in `MegaHubScreen` so every route is reachable while the real gameplay-backed screen implementations are phased in.
- `tools/validate_full_ui_contract.py` — checks the required route and architecture contract.

## Important distinction

The specification explicitly says not to destroy existing gameplay systems and to reuse existing robot, weapon, Titan, pilot, drone, specialization, inventory, upgrade and save systems. Therefore this pass **does not fabricate a second gameplay database**. The new contract only describes UI routes, states and navigation expectations.

## Target flow

`Hangar → Robot Equipment → Weapon Inventory → Weapon Detail → Equip → Back → Pilot/Drone/Specialization → Upgrade → Hangar → Robot Inventory → Deck → Titan → Store/Events/Missions/Social/Settings → Game Mode → Matchmaking → Deployment → Battle → Robot Selection → Post-Battle → Rewards → Hangar`

## Remaining implementation boundary

Some routes still use the existing reusable `MegaHubScreen` as a visual placeholder. That is deliberate skeleton behavior: the route exists, focus/back behavior exists, and the contract is testable without inventing fake backend state. The next polish phase can replace those placeholders one by one with dedicated production screens.
