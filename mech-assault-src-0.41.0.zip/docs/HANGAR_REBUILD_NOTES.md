# Hangar Rebuild Pass

This pass keeps MECH ASSAULT fully offline and tightens the presentation around a classic mech-hangar shell:

- persistent top profile/resource chrome with explicit `OFFLINE · LOCAL` status
- stronger left crew rail and right utility rail hierarchy
- larger, cleaner `TO BATTLE` primary action with an offline deployment tooltip
- selected-mech identity card now advertises local deployment readiness
- bottom mech cards get a selection/status accent without changing the existing roster data model
- all existing node names and navigation contracts used by the smoke suite are preserved

No networking, service calls, cloud state or multiplayer code was added.
