# Hangar UI Rules — MECH ASSAULT

The hangar is the game's offline home screen. It borrows the readable patterns of modern mech-collection games while keeping all names, art, geometry and implementation original.

## Layout contract

1. The 3D bay is the visual hero. UI chrome must never cover the selected mech's framed bounds.
2. Top chrome owns player identity, local resources, build stamp and an explicit `OFFLINE · LOCAL` state.
3. The upper-right action is the single primary CTA: `TO BATTLE` starts the local match scene and never requires a network service.
4. Left rail contains progression/crew destinations. Right rail contains utility/equipment destinations.
5. Bottom dock contains the owned mech cycle, the titan bay and the store entry.
6. The selected mech gets a stronger amber treatment. Unselected machines remain readable but visually quieter.
7. Upgrade callouts are honest: no upgrade bubble is shown when the chassis is fully upgraded.

## Interaction rules

1. Tap an occupied pad to select that mech. Tapping the already-selected mech opens equipment.
2. Tap an empty pad to open the local store at the correct robot/titan section.
3. Drag across the bay rotates the model, not the camera.
4. Mouse wheel or two-finger pinch changes showroom zoom inside hard clamps.
5. Releasing the pointer must stop the motion immediately; there is no idle camera drift.
6. `BACK` returns to the previous screen. At the hangar root it opens the quit confirmation.
7. Every visible button is wired to a local screen/action, or is explicitly disabled with an explanation.

## Offline rules

1. No HTTP/API/auth/socket dependency is allowed for the hangar.
2. Wallet values, ownership, loadouts, upgrades and settings come from `GameState` and local save data.
3. `TO BATTLE` routes through `SceneRouter.goto_game()` into the local combat scene.
4. The UI must never display a fake "connected", "server", "cloud", or "online" state.
5. Network services may be added later, but the offline hangar must remain fully playable without them.

## Visual language

Use dark steel panels, cyan information accents, amber selection/primary attention, green health/ready states and red for destructive actions. Keep panels translucent enough that the 3D bay remains visible. Prefer compact labels, strong hierarchy, angular/cut-corner profiles and small status stamps instead of giant dashboard cards.
