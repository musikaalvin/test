# MECH ASSAULT — Full Game UX Rebuild

This build moves the project from a Hangar UI demo toward a complete offline robot-combat game shell.

## Implemented foundation

- Physical 3D Hangar remains the home screen.
- `TO BATTLE` now enters a real local flow: Game Modes → Matchmaking → Deployment → Combat.
- Persistent GameState remains authoritative for robots, weapons, pilots, drones, specializations, upgrades and wallet data.
- Added data-driven meta-game workspaces for missions, operations, events, data pads, collections, leaderboards, profile and offline social/clan shells.
- Added dedicated HUD editor workspace and deployment state.
- Added post-battle/reward workspace for persistent local results.
- Added explicit OFFLINE / LOCAL state instead of pretending to contact a server.
- Existing combat scene, AI, weapons, hazards, maps and touch controls are preserved.
- Navigation uses the existing UIManager stack and reusable UiParts/UiTheme components.

## Design boundary

War Robots is used only as high-level UX inspiration. MECH ASSAULT does not copy its proprietary artwork, logos, exact screen geometry, fonts, icons or assets.

## Validation limitation

The build host supplied with this conversation does not contain the project's documented Godot 4.4.1 binary, so an engine compile/render pass could not be executed here. The source tree was statically checked for referenced screen scripts and missing mapped UI resources. Install/run the project with the documented `tools/env.sh` + `tools/validate.sh` environment before calling the build production-ready.
