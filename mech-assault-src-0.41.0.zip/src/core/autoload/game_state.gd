extends Node

enum Phase { BOOT, MENU, COMBAT, VICTORY, DEFEAT }
enum SlotSize { LIGHT = 0, MEDIUM = 1, HEAVY = 2, ALPHA = 3, BETA = 4 }
# War Robots ladders: regular robots and weapons run MK1/MK2/MK3 x lv1-12,
# a titan's hull runs a single 1-150 ladder, titan weapons run 1-25.
enum UpgradeClass { STANDARD = 0, TITAN_HULL = 1, TITAN_WEAPON = 2 }
# How the UI picks its control scheme: AUTO follows live input detection,
# FORCE_* pins it (CONTROLS button in settings).
enum UiMode { AUTO = 0, FORCE_TOUCH = 1, FORCE_OFF = 2 }

const BUILD_LABEL := "v0.41.0 · 2026-10-09"
const MK_MAX := 3
const LV_MAX := 12
const LV_MAX_TITAN := 150
const LV_MAX_TITAN_WEAPON := 25
const SETTINGS_PATH := "user://settings.cfg"
const SLOT_COUNT := 4
const PALETTE_COUNT := 5
const DEADZONE_MIN := 0.05
const DEADZONE_MAX := 0.30
const DEADZONE_DEFAULT := 0.15
# Paint shop: first two liveries are free, the rest are bought with silver.
const PAINT_COSTS: Array[int] = [0, 0, 30000, 45000, 60000]
# Robots no longer self-repair from thin air: healing comes from drones
# (emergency burst + PATCH field repair), pilots and specializations.
const BASE_REGEN := 0.0

const SLOT_LABELS: Array[String] = ["LIGHT", "MEDIUM", "HEAVY", "ALPHA", "BETA"]
const SLOT_BADGES: Array[String] = ["L", "M", "H", "a", "b"]
const UI_MODE_LABELS: Array[String] = ["AUTO", "TOUCH", "KEYS"]
const TARGET_PRIORITY_LABELS: Array[String] = ["CROSSHAIR", "NEAREST"]

const ROBOT_SCARAB: StringName = &"SCARAB"
const ROBOT_VORTEX: StringName = &"VORTEX"
const ROBOT_RAMPART: StringName = &"RAMPART"
const ROBOT_PRAETOR: StringName = &"PRAETOR"
const ROBOT_CITADEL: StringName = &"CITADEL"
const ROBOT_RAVAGER: StringName = &"RAVAGER"
const ROBOT_ORDER: Array[StringName] = [
	&"SCARAB", &"VORTEX", &"RAMPART", &"PRAETOR", &"CITADEL", &"RAVAGER",
]

const ROBOT_DEFS: Dictionary = {
	&"SCARAB": {
		"name": "SCARAB", "klass": "Quadruped Assault",
		"slots": [SlotSize.MEDIUM, SlotSize.MEDIUM, SlotSize.MEDIUM, SlotSize.MEDIUM],
		"armor": 340000.0, "speed": 7.0, "speed_scale": 1.0, "scale": 1.0,
		"ability": "SHADOW DASH", "ability_short": "DASH", "rig": "quadruped",
		"ability_desc": "Burst-dash 30 m cloaked for 6.5 s; the wake jammers enemies caught behind you.",
		"wall_climb": true, "builtin": "STINGER LANCE",
	},
	&"VORTEX": {
		"name": "VORTEX", "klass": "Heavy Assault",
		"slots": [SlotSize.HEAVY, SlotSize.HEAVY, SlotSize.HEAVY, SlotSize.HEAVY],
		"armor": 430000.0, "speed": 5.2, "speed_scale": 0.76, "scale": 1.18,
		"ability": "JUMP JET", "ability_short": "JET", "rig": "biped",
		"ability_desc": "Rocket-assisted leap clears cover and high ground, landing ready to fire.",
		"builtin": "ARC NEEDLER", "cost": 350000, "currency": "silver",
	},
	&"RAMPART": {
		"name": "ZEPHYR", "klass": "Aerial Raider",
		"slots": [SlotSize.MEDIUM, SlotSize.MEDIUM, SlotSize.HEAVY],
		"armor": 380000.0, "speed": 7.4, "speed_scale": 1.05, "scale": 0.85,
		"ability": "GALE VEIL", "ability_short": "GALE", "rig": "zephyr",
		"ability_desc": "Rise into 13 s of hover flight; each hit taken aloft triggers 1.5 s of invisibility.",
		"builtin": "WINDCUTTER", "flyer": true, "builtin_gated": true,
		"builtin_desc": "Built-in machine gun fires only while Gale Veil is active, then overheats.",
		"cost": 450000, "currency": "silver",
	},
	&"PRAETOR": {
		"name": "PRAETOR", "klass": "Titan Juggernaut", "is_titan": true,
		"slots": [SlotSize.ALPHA, SlotSize.ALPHA, SlotSize.BETA, SlotSize.BETA],
		"armor": 700000.0, "speed": 5.6, "speed_scale": 0.8, "scale": 1.0,
		"ability": "NULLFIELD", "ability_short": "NULL",
		"ability_desc": "5 s barrier absorbs 3 hits and refunds the damage as repair; locks nearby enemies.",
		"secondary": "GRAV THRUST", "secondary_short": "THRUST",
		"secondary_desc": "Grav shockwave hurls every enemy caught in 11 m backward.",
		"rig": "titan", "builtin": "",
		"cost": 2500, "currency": "plat",
	},
	&"CITADEL": {
		"name": "CITADEL", "klass": "Barrier Juggernaut", "is_titan": true,
		"slots": [SlotSize.ALPHA, SlotSize.BETA, SlotSize.BETA],
		"armor": 500000.0, "speed": 5.6, "speed_scale": 0.8, "scale": 1.0,
		"ability": "CHALLENGE", "ability_short": "CHAL",
		"ability_desc": "Marks the closest hostile (400 m) for 9 s: it drops everything and hunts you while the mark amplifies every hit it takes.",
		"secondary": "IRONVEIL", "secondary_short": "IRON",
		"secondary_desc": "9 s frontal barrier cuts damage taken by 90% and repairs 35% of the raw damage back, up to 40% of max hull per use.",
		"stat3_label": "CORE", "stat3_value": "90 %",
		"passive_regen": 0.002,
		"rig": "titan", "builtin": "",
		"cost": 3000, "currency": "plat",
	},
	&"RAVAGER": {
		"name": "RAVAGER", "klass": "Assault Brawler", "is_titan": true,
		"slots": [SlotSize.ALPHA, SlotSize.BETA, SlotSize.BETA],
		"armor": 400000.0, "speed": 6.4, "speed_scale": 0.9, "scale": 1.0,
		"ability": "SHROUD", "ability_short": "SHRD",
		"ability_desc": "8 s dark field: a 100 m aura slows every hostile inside and stacks a damage mark on each (one stack per 0.5 s, x3 at full duration).",
		"secondary": "LUNGE", "secondary_short": "LUNG",
		"secondary_desc": "Ram dash (2 charges): for 2.5 s all damage taken converts to a halved flow that drains over 4 s as repairable damage.",
		"stat3_label": "RANGE", "stat3_value": "100 M",
		"dot_taken": 0.75,
		"rig": "titan", "builtin": "",
		"cost": 2800, "currency": "plat",
	},
}

# Sell values are SILVER ONLY (War Robots sells every asset type for silver,
# including titans). Keys must cover every id in ROBOT_DEFS.
const ROBOT_SELL_VALUES: Dictionary = {
	&"SCARAB": 25000, &"VORTEX": 45000, &"RAMPART": 60000, &"PRAETOR": 400000,
	&"CITADEL": 500000, &"RAVAGER": 450000,
}

const TITAN_ITEM_IDS: Array[String] = [
	"JUGGERNAUT-A", "DEMOLISHER-A", "OVERLORD-A",
	"HAVOC-B", "ARCLANCE-B", "CELERITY-B",
	"VOID-A", "CHASH-B",
	# v0.35 War Robots 12.x titan catalog (manifest titan_weapons).
	"BARQ-A", "BARQ-B", "VENIRE-A", "VINCERE-B",
	"FURNACE-A", "TORCH-B", "CHASM-B", "MUNINN-A", "HUGINN-B",
	"EQUALIZER-A", "ARBITER-B", "VAJRA-A", "MAHA-VAJRA-B",
	"STRIKER-A", "EVORA-A", "VEYRON-B", "ANGUISHER-A", "RUINER-B",
]

const ALL_ITEM_IDS: Array[String] = [
	"RAZOR-L", "RAZOR-M", "RAZOR-H",
	"MAUL-L", "MAUL-M", "MAUL-H",
	"VOLT-L", "VOLT-M", "VOLT-H",
	"TORQ-L", "TORQ-M", "TORQ-H",
	"BREACH-L", "BREACH-M", "BREACH-H",
	"FERRIC-L", "FERRIC-M", "FERRIC-H",
	"LUMEN-L", "LUMEN-M", "LUMEN-H",
	"PYRE-L", "PYRE-M", "PYRE-H",
	"VOLLEY-L", "VOLLEY-M", "VOLLEY-H",
	"ECHO-L", "ECHO-M", "ECHO-H",
	# v0.35 War Robots 12.x catalog (manifest robot_weapons, patch 414-422).
	# Sizes follow the wiki infoboxes exactly: Iaraghi is L-only, Gladius is
	# L-only (Pilum is the H member), Elox is L+Murix M, Toxin/Venom/Bane is
	# the L/M/H corrosive ladder. "Ultimate *" and the *_12_4 ids are cosmetic
	# variants of the same weapon (GT §3.4 — "do not treat as separate
	# weapons") and are deliberately NOT separate catalog entries.
	"IARAGHI-L",
	"HARMATTAN-L", "HARMATTAN-M", "HARMATTAN-H",
	"CELSIUS-L", "FAHRENHEIT-M", "KELVIN-H",
	"VOONITH-L", "URHAG-M", "SHANTAK-H",
	"ATOMIZER-M",
	"GLADIUS-L", "PILUM-H",
	"RIME-L", "CRYO-M", "GLACIER-H",
	"VELOS-L", "VELOS-M", "VELOS-H", "MACHAIRA-M", "BASILEUS-H",
	"HIPPO-L", "KROKO-M", "LIODARI-H",
	"ELOX-L", "MURIX-M",
	"KSIPHOS-L", "LABRYS-M", "CESTUS-H",
	"TOXIN-L", "VENOM-M", "BANE-H",
]

const PALETTE_NAMES: Array[String] = [
	"AURUM", "MAGMA", "VERDANT", "GLACIER", "NOCTURNE",
]

var phase: Phase = Phase.BOOT
var selected_quality: int = 2
# AUTO graphics: start at the hardware-recommended tier and let FPS stepping
# adjust within that recommendation until the player picks a tier manually.
var quality_auto: bool = true
# Control scheme override (UiMode) — read by PlatformUtil.effective_mode().
var input_ui_mode: int = UiMode.AUTO
var selected_robot: StringName = &"SCARAB"
# Which titan stands on the hangar's dedicated titan pad when the selected
# robot is not itself a titan. Updated by select_robot, persisted.
var active_titan: StringName = &""
var enemies_registered: int = 0
var enemies_killed: int = 0
var match_time: float = 0.0
var player_damage_dealt: float = 0.0
var player_damage_taken: float = 0.0

var loadouts: Dictionary = {}
var inventory: Dictionary = {}
var silver: int = 1000000000
var gold: int = 1000000
var spare_parts: int = 1000000
var microchips: int = 500000
var module_points: int = 500000
var platinum: int = 500000
# Memorium: War Robots 9.3 pilot currency - every pilot skill train and every
# rank/tier promotion spends it (never silver/gold).
var memorium: int = 500000
var upgrades: Dictionary = {}
var owned_robots: Array[StringName] = []
var owned_drones: Array[String] = []
var drone_levels: Dictionary = {}
var selected_drone: String = ""
var drone_assignments: Dictionary = {}
var specs: Dictionary = {}
var _strict_ownership: bool = false

var armor_palette: int = 0
var robot_palettes: Dictionary = {}
var unlocked_paints: Array[int] = [0, 1]
var look_sensitivity: float = 1.0
var master_volume: float = 0.8
var invert_look_y: bool = false
var music_volume: float = 0.7
var damage_numbers: bool = true
var fps_counter: bool = false
var vibration_enabled: bool = true
# Analog-stick deadzones, per stick (left = move, right = look), radial and
# rescaled so there is no input jump when a stick leaves the dead zone.
# Tunable from Settings; the range matches the spec (0.05 .. 0.30).
var pad_deadzone_left: float = 0.15
var pad_deadzone_right: float = 0.15
# Development-only input diagnostics overlay (inert in release builds).
var input_diagnostics: bool = false
# Lock-on preference: 0 = CROSSHAIR (whatever sits nearest the middle of
# the screen, the original behaviour), 1 = NEAREST (closest hull). Read by
# GameSession._cone_candidates.
var target_priority: int = 0
var match_reward_silver: int = 0
var match_reward_gold: int = 0
var match_reward_parts: int = 0
var match_reward_chips: int = 0
var match_reward_platinum: int = 0
var match_reward_modules: int = 0
var pilot_xp_gained: int = 0

func _ready() -> void:
	_build_defaults()
	load_settings()
	_migrate_removed_item_ids()
	_migrate_ownership()
	_cover_mounted_copies()
	apply_settings()

# Removed / renamed catalog ids folded into the surviving ladder member.
# v0.39 deleted the three sizes the wiki never published (GLADIUS-H — Gladius
# is Light-only, Pilum is the Heavy member; IARAGHI-M/H — those pages are
# API:MISSING) plus the cosmetic "Ultimate *" and "*_12_4" duplicates, which
# the ground-truth file lists under "skins / variants — do not treat as
# separate weapons". Old saves that still hold a removed id keep working: the
# pool copies and every mounted loadout slot are rewritten to the survivor.
# Idempotent — a stale key simply stops existing after one boot.
const REMOVED_ITEM_IDS: Dictionary = {
	"GLADIUS-H": "PILUM-H",
	"IARAGHI-M": "IARAGHI-L",
	"IARAGHI-H": "IARAGHI-L",
	"ULTIMATE-TOXIN-L": "TOXIN-L",
	"ULTIMATE-VENOM-M": "VENOM-M",
	"ULTIMATE-ATOMIZER": "ATOMIZER-M",
	"ULTIMATE-RIME": "RIME-L",
	"ULTIMATE-GLACIER": "GLACIER-H",
	"RIME-12_4": "RIME-L",
	"CRYO-12_4": "CRYO-M",
	"GLACIER-12_4": "GLACIER-H",
}

func _migrate_removed_item_ids() -> void:
	for old_value in REMOVED_ITEM_IDS.keys():
		var old_id := String(old_value)
		var new_id := String(REMOVED_ITEM_IDS[old_value])
		if not ALL_ITEM_IDS.has(new_id):
			continue
		if inventory.has(old_id):
			var carried: int = int(inventory.get(old_id, 0))
			inventory.erase(old_id)
			if carried > 0:
				inventory[new_id] = pool_count(new_id) + carried
		for robot_id in loadouts.keys():
			var slots: Array = loadouts[robot_id]
			for index in slots.size():
				if String(slots[index]) == old_id:
					slots[index] = new_id

# New chassis arrive on old saves with their default loadout already mounted:
# the pool must own at least every mounted copy, otherwise the equip /
# free-copies arithmetic refuses to work. Runs after the pool has loaded from
# disk (load_settings) and after the one-time migration; idempotent.
func _cover_mounted_copies() -> void:
	for robot_id in loadouts.keys():
		for item_value in loadouts[robot_id] as Array:
			var item := String(item_value)
			if item.is_empty():
				continue
			var mounted := equipped_count(item)
			if pool_count(item) < mounted:
				inventory[item] = mounted

func _migrate_ownership() -> void:
	if _strict_ownership:
		return
	_strict_ownership = true
	var all_ids: Array = ALL_ITEM_IDS.duplicate()
	for item_id in TITAN_ITEM_IDS:
		if not all_ids.has(item_id):
			all_ids.append(item_id)
	for item_id in all_ids:
		inventory[item_id] = pool_count(String(item_id)) + equipped_count(String(item_id))

func _build_defaults() -> void:
	loadouts = {
		&"SCARAB": _default_loadout(&"SCARAB"),
		&"VORTEX": _default_loadout(&"VORTEX"),
		&"RAMPART": _default_loadout(&"RAMPART"),
		&"PRAETOR": _default_loadout(&"PRAETOR"),
		&"CITADEL": _default_loadout(&"CITADEL"),
		&"RAVAGER": _default_loadout(&"RAVAGER"),
	}
	inventory = {}
	for item_id in ALL_ITEM_IDS:
		inventory[item_id] = 2
	pilot_assignments = {
		&"SCARAB": "vex", &"VORTEX": "orin", &"RAMPART": "sable",
		&"PRAETOR": "mara", &"CITADEL": "dorn", &"RAVAGER": "varga",
	}
	owned_pilots = ["vex", "orin", "sable", "mara", "dorn", "varga"]
	for pilot_id in ["vex", "orin", "sable", "mara", "dorn", "varga"]:
		pilots[pilot_id] = {"level": 21, "xp": 0, "tier": 1,
				"skills": [0, 0, 0, 0, 0, 0, 0]}
	owned_robots = [&"SCARAB"]
	owned_drones = ["wisp", "bulwark", "patch", "kestrel", "scourveil", "prena"]
	drone_levels = {"wisp": 1, "bulwark": 1, "patch": 1, "kestrel": 1,
			"scourveil": 1, "prena": 1}
	selected_drone = "wisp"
	# v0.26 pairing: each robot runs a different drone and the titan runs none
	# (War Robots titans have no companion drone of their own).
	drone_assignments = {
		&"SCARAB": "wisp", &"VORTEX": "kestrel",
		&"RAMPART": "bulwark", &"PRAETOR": "",
		&"CITADEL": "", &"RAVAGER": "",
	}
	specs = {}

static func _default_loadout(robot_id: StringName) -> Array:
	if robot_id == ROBOT_VORTEX:
		return ["VOLT-H", "VOLT-H", "VOLT-H", "VOLT-H"]
	if robot_id == ROBOT_RAMPART:
		return ["LUMEN-M", "LUMEN-M", "PYRE-H"]
	if robot_id == ROBOT_PRAETOR:
		return ["JUGGERNAUT-A", "JUGGERNAUT-A", "HAVOC-B", "HAVOC-B"]
	if robot_id == ROBOT_CITADEL:
		return ["JUGGERNAUT-A", "CELERITY-B", "CELERITY-B"]
	if robot_id == ROBOT_RAVAGER:
		return ["DEMOLISHER-A", "HAVOC-B", "HAVOC-B"]
	return ["RAZOR-M", "RAZOR-M", "MAUL-M", "MAUL-M"]

func enter_menu() -> void:
	phase = Phase.MENU

func reset_match() -> void:
	enemies_registered = 0
	enemies_killed = 0
	match_time = 0.0
	player_damage_dealt = 0.0
	player_damage_taken = 0.0
	match_reward_silver = 0
	match_reward_gold = 0
	match_reward_parts = 0
	match_reward_chips = 0
	match_reward_platinum = 0
	match_reward_modules = 0
	pilot_xp_gained = 0

func begin_combat() -> void:
	reset_match()
	phase = Phase.COMBAT
	Events.match_started.emit()

func register_enemy() -> void:
	enemies_registered += 1

func reward_parts(amount: int) -> void:
	spare_parts += amount
	match_reward_parts += amount
	Events.wallet_changed.emit()

func reward_chips(amount: int) -> void:
	microchips += amount
	match_reward_chips += amount
	Events.wallet_changed.emit()

func reward_module_points(amount: int) -> void:
	module_points += amount
	match_reward_modules += amount
	Events.wallet_changed.emit()

func reward_platinum(amount: int) -> void:
	platinum += amount
	match_reward_platinum += amount
	Events.wallet_changed.emit()

func notify_enemy_killed() -> void:
	enemies_killed += 1
	reward_silver(3000)
	reward_parts(600)
	reward_chips(150)
	reward_module_points(5)
	reward_platinum(5)
	if enemies_registered > 0 and enemies_killed >= enemies_registered:
		phase = Phase.VICTORY
		reward_silver(20000)
		gold += 30
		match_reward_gold += 30
		reward_parts(4000)
		reward_chips(1500)
		reward_module_points(60)
		reward_platinum(50)
		grant_pilot_match_xp()
		Events.all_enemies_defeated.emit()
		Events.match_ended.emit(true)

func notify_player_died() -> void:
	if phase == Phase.COMBAT:
		phase = Phase.DEFEAT
		reward_silver(5000)
		gold += 10
		match_reward_gold += 10
		reward_parts(1500)
		reward_chips(500)
		reward_module_points(25)
		reward_platinum(20)
		grant_pilot_match_xp()
		Events.player_died.emit()
		Events.match_ended.emit(false)

func remaining_enemies() -> int:
	return maxi(0, enemies_registered - enemies_killed)

func phase_label() -> String:
	match phase:
		Phase.BOOT: return "BOOT"
		Phase.MENU: return "MENU"
		Phase.COMBAT: return "COMBAT"
		Phase.VICTORY: return "VICTORY"
		Phase.DEFEAT: return "DEFEAT"
	return "UNKNOWN"

# ---------------------------------------------------------------- robots

func robot_def(robot_id: StringName = selected_robot) -> Dictionary:
	if ROBOT_DEFS.has(robot_id):
		return ROBOT_DEFS[robot_id] as Dictionary
	return ROBOT_DEFS[&"SCARAB"] as Dictionary

func robot_slots(robot_id: StringName = selected_robot) -> Array:
	return robot_def(robot_id).get("slots", []) as Array

func is_titan(robot_id: StringName = selected_robot) -> bool:
	return bool(robot_def(robot_id).get("is_titan", false))

func slot_size(robot_id: StringName, index: int) -> int:
	var slots := robot_slots(robot_id)
	if index < 0 or index >= slots.size():
		return SlotSize.MEDIUM
	return slots[index]

func slot_badge(size: int) -> String:
	return SLOT_BADGES[clampi(size, 0, SLOT_BADGES.size() - 1)]

func owns_robot(robot_id: StringName) -> bool:
	return owned_robots.has(robot_id)

func robot_buy_cost(robot_id: StringName) -> int:
	var definition := robot_def(robot_id)
	if definition.is_empty() or owns_robot(robot_id):
		return 0
	return int(definition.get("cost", 0))

func robot_buy_currency(robot_id: StringName) -> String:
	return String(robot_def(robot_id).get("currency", "silver"))

func buy_robot(robot_id: StringName) -> bool:
	var cost := robot_buy_cost(robot_id)
	if cost <= 0:
		return false
	var currency := robot_buy_currency(robot_id)
	if currency == "plat":
		if platinum < cost:
			return false
		platinum -= cost
	else:
		if silver < cost:
			return false
		silver -= cost
	owned_robots.append(robot_id)
	_sync_pool_to_loadouts()
	save_settings()
	Events.wallet_changed.emit()
	return true

func weapon_buy_cost(item_id: String) -> int:
	match item_slot_size(item_id):
		SlotSize.LIGHT: return 25000
		SlotSize.MEDIUM: return 55000
		SlotSize.HEAVY: return 120000
		SlotSize.ALPHA: return 550
		SlotSize.BETA: return 400
	return 50000

func weapon_buy_currency(item_id: String) -> String:
	var size := item_slot_size(item_id)
	return "plat" if size == SlotSize.ALPHA or size == SlotSize.BETA else "silver"

func buy_item(item_id: String) -> bool:
	if not ALL_ITEM_IDS.has(item_id) and not TITAN_ITEM_IDS.has(item_id):
		return false
	var cost := weapon_buy_cost(item_id)
	if cost <= 0:
		return false
	if weapon_buy_currency(item_id) == "plat":
		if platinum < cost:
			return false
		platinum -= cost
	else:
		if silver < cost:
			return false
		silver -= cost
	inventory[item_id] = pool_count(item_id) + 1
	save_settings()
	Events.wallet_changed.emit()
	return true

func select_robot(robot_id: StringName) -> void:
	if ROBOT_DEFS.has(robot_id) and owns_robot(robot_id):
		selected_robot = robot_id
		if is_titan(robot_id):
			active_titan = robot_id
		sync_palette_cursor()
		save_settings()

func cycle_robot() -> StringName:
	var index := ROBOT_ORDER.find(selected_robot)
	for step in ROBOT_ORDER.size():
		var candidate := ROBOT_ORDER[(index + step + 1) % ROBOT_ORDER.size()]
		if owns_robot(candidate):
			selected_robot = candidate
			sync_palette_cursor()
			save_settings()
			return selected_robot
	return selected_robot

# ---------------------------------------------------------------- selling
# War Robots sell rules: every sale pays SILVER ONLY; the UI shows the price
# first, then a confirm dialog; equipped / assigned / active gear and the
# active hangar robot are blocked until moved out. All guards fail silently
# (return false) so the UI can toast the reason itself.

func sell_price_item(item_id: String) -> int:
	if not ALL_ITEM_IDS.has(item_id) and not TITAN_ITEM_IDS.has(item_id):
		return 0
	match item_slot_size(item_id):
		# Titan guns buy with platinum, which the wallet cannot convert into
		# silver: an explicit table stands in for 40% of the buy price
		# (A = 40% of a 550000 silver-equivalent, B = 40% of 400000).
		SlotSize.ALPHA: return 220000
		SlotSize.BETA: return 160000
	# Regular guns: 40% of weapon_buy_cost -> L 10000 / M 22000 / H 48000.
	return int(roundf(0.4 * float(weapon_buy_cost(item_id))))

func sell_item(item_id: String) -> bool:
	var price := sell_price_item(item_id)
	# Mirrors equip_item's accounting: only an UNMOUNTED copy may leave
	# (pool total - equipped_count >= 1), so a mounted gun can never vanish.
	if price <= 0 or free_copies(item_id) < 1:
		return false
	inventory[item_id] = pool_count(item_id) - 1
	silver += price
	save_settings()
	Events.wallet_changed.emit()
	return true

func sell_price_robot(robot_id: StringName) -> int:
	return int(ROBOT_SELL_VALUES.get(robot_id, 0))

func sell_robot(robot_id: StringName) -> bool:
	if not owns_robot(robot_id) or robot_id == selected_robot:
		return false
	# The active hangar deck always keeps a robot to fight with.
	if owned_robots.size() <= 1:
		return false
	var price := sell_price_robot(robot_id)
	if price <= 0:
		return false
	owned_robots.erase(robot_id)
	# Its hangar staff goes back to the roster; loadouts, palettes, specs and
	# upgrade tracks stay with the id, so a rebuy restores the robot exactly.
	pilot_assignments.erase(robot_id)
	drone_assignments.erase(robot_id)
	silver += price
	# Belt and braces: the selected robot must always be an owned one.
	if not owns_robot(selected_robot):
		selected_robot = owned_robots[0]
		sync_palette_cursor()
	save_settings()
	Events.wallet_changed.emit()
	return true

# ---------------------------------------------------------------- loadout

func equipped_item(robot_id: StringName, index: int) -> String:
	var loadout := loadouts.get(robot_id, []) as Array
	if index >= 0 and index < loadout.size():
		return loadout[index] as String
	return ""

func equipped_items(robot_id: StringName = selected_robot) -> Array:
	return loadouts.get(robot_id, []) as Array

func pool_count(item_id: String) -> int:
	return int(inventory.get(item_id, 0))

func equipped_count(item_id: String) -> int:
	var count := 0
	for robot_id in loadouts.keys():
		for equipped in loadouts[robot_id] as Array:
			if String(equipped) == item_id:
				count += 1
	return count

func free_copies(item_id: String) -> int:
	return maxi(0, pool_count(item_id) - equipped_count(item_id))

func _sync_pool_to_loadouts() -> void:
	for robot_id in loadouts.keys():
		for item in loadouts[robot_id] as Array:
			var item_id := String(item)
			if item_id.is_empty():
				continue
			var needed := equipped_count(item_id)
			if pool_count(item_id) < needed:
				inventory[item_id] = needed

func available_items_for_slot(robot_id: StringName, index: int) -> Array[String]:
	var wanted := slot_size(robot_id, index)
	var current := equipped_item(robot_id, index)
	var result: Array[String] = []
	for item_id in inventory.keys():
		var id := String(item_id)
		if item_slot_size(id) != wanted:
			continue
		if id == current or free_copies(id) > 0:
			result.append(id)
	result.sort()
	return result

func equip_item(robot_id: StringName, index: int, item_id: String) -> bool:
	if item_slot_size(item_id) != slot_size(robot_id, index):
		return false
	if not loadouts.has(robot_id):
		return false
	var loadout := loadouts[robot_id] as Array
	if index < 0 or index >= loadout.size():
		return false
	var current := String(loadout[index])
	if current == item_id:
		return true
	if not inventory.has(item_id) or free_copies(item_id) < 1:
		return false
	loadout[index] = item_id
	if not current.is_empty():
		upgrades.erase(upgrade_key(robot_id, index))
	save_settings()
	return true

func unequip_item(robot_id: StringName, index: int) -> String:
	if not loadouts.has(robot_id):
		return ""
	var loadout := loadouts[robot_id] as Array
	if index < 0 or index >= loadout.size():
		return ""
	var item_id := loadout[index] as String
	if item_id.is_empty():
		return ""
	loadout[index] = ""
	save_settings()
	return item_id

func filled_slots(robot_id: StringName = selected_robot) -> int:
	var count := 0
	for item_id in equipped_items(robot_id):
		if String(item_id) != "":
			count += 1
	return count

# Number of weapon hardpoints a chassis actually has (ZEPHYR has 3, the rest 4).
func slot_count(robot_id: StringName = selected_robot) -> int:
	var slots: Array = robot_def(robot_id).get("slots", [])
	return slots.size()

# ---------------------------------------------------------------- weapon items

func item_slot_size(item_id: String) -> int:
	# Delegates to WeaponData so multi-hyphen ids (MAHA-VAJRA-B, ANGUISHER-A,
	# TOXIN-L) resolve to the right size token.
	match WeaponData.item_size_of(item_id):
		WeaponData.Size.LIGHT: return SlotSize.LIGHT
		WeaponData.Size.HEAVY: return SlotSize.HEAVY
		WeaponData.Size.ALPHA: return SlotSize.ALPHA
		WeaponData.Size.BETA: return SlotSize.BETA
	return SlotSize.MEDIUM

func item_family(item_id: String) -> String:
	return WeaponData.item_family_of(item_id)

func item_display_name(item_id: String) -> String:
	if item_id.is_empty():
		return "EMPTY HARDPOINT"
	return item_id

# Class captions for the v0.35 catalog families (original 10 stay in the
# match below).
const WEAPON_CLASS_LABELS: Dictionary = {
	"IARAGHI": "Energy Burst · Mid",
	"HARMATTAN": "Scattergun · Close",
	"CELSIUS": "Flame · Close", "FAHRENHEIT": "Flame · Close",
	"KELVIN": "Flame · Close",
	"VOONITH": "Energy Wave · Long", "URHAG": "Energy Wave · Long",
	"SHANTAK": "Energy Wave · Long",
	"ATOMIZER": "Energy MG · Mid",
	"GLADIUS": "Autocannon · Long", "PILUM": "Autocannon · Long",
	"RIME": "Freeze Rocket · Mid", "CRYO": "Freeze Rocket · Mid",
	"GLACIER": "Freeze Rocket · Mid",
	"VELOS": "Acid · Mid", "MACHAIRA": "Acid · Mid", "BASILEUS": "Acid · Mid",
	"HIPPO": "Breach · Mid", "KROKO": "Breach · Mid", "LIODARI": "Breach · Mid",
	"ELOX": "Corrosive · Mid", "MURIX": "Corrosive · Mid",
	"KSIPHOS": "Grenade · Mid", "LABRYS": "Grenade · Mid",
	"CESTUS": "Grenade · Mid",
	"TOXIN": "Corrosive · Close", "VENOM": "Corrosive · Close",
	"BANE": "Corrosive · Close",
	"BARQ": "Arc · Close",
	"VENIRE": "Rocket · Mid", "VINCERE": "Rocket · Mid",
	"FURNACE": "Beam · Long", "TORCH": "Beam · Long",
	"CHASM": "Titan Salvo · Mid",
	"MUNINN": "Chain Arc · Mid", "HUGINN": "Chain Arc · Mid",
	"EQUALIZER": "Rocket · Long", "ARBITER": "Rocket · Long",
	"VAJRA": "Scattergun · Close", "MAHA-VAJRA": "Scattergun · Close",
	"STRIKER": "Rail · Long",
	"EVORA": "Sonic · Mid", "VEYRON": "Sonic · Mid",
	"ANGUISHER": "Acid Shotgun · Close", "RUINER": "Acid Shotgun · Close",
}

func item_class_label(item_id: String) -> String:
	if item_id.is_empty():
		return "Tap to assign weapon"
	var family := item_family(item_id)
	var size := SLOT_LABELS[item_slot_size(item_id)]
	if WEAPON_CLASS_LABELS.has(family):
		return "%s · %s" % [size, String(WEAPON_CLASS_LABELS[family])]
	match family:
		"VOLT": return "%s · Electric · Short" % size
		"RAZOR": return "%s · Autocannon · Mid" % size
		"MAUL": return "%s · Scattergun · Close" % size
		"TORQ": return "%s · Magnetic · Long" % size
		"BREACH": return "%s · Rocket · Slow" % size
		"FERRIC": return "%s · Corrosive · Mid" % size
		"LUMEN": return "%s · Beam · Long" % size
		"PYRE": return "%s · Flame · Close" % size
		"VOLLEY": return "%s · Salvo · Mid" % size
		"ECHO": return "%s · Sonic · Close" % size
	return size

func weapon_for_item(item_id: String):
	if item_id.is_empty():
		return null
	var data := WeaponData.for_item(item_id)
	var items := equipped_items(selected_robot)
	for index in items.size():
		if String(items[index]) == item_id:
			apply_weapon_upgrades(data, selected_robot, index)
			break
	return data

# ---------------------------------------------------------------- palettes

func palette_colors(index: int) -> Array[Color]:
	var i := clampi(index, 0, PALETTE_COUNT - 1)
	match i:
		1:
			return [Color(0.5, 0.14, 0.09), Color(0.17, 0.07, 0.05), Color(0.95, 0.38, 0.08)]
		2:
			return [Color(0.25, 0.3, 0.16), Color(0.1, 0.13, 0.08), Color(0.5, 0.75, 0.2)]
		3:
			return [Color(0.5, 0.57, 0.63), Color(0.16, 0.2, 0.28), Color(0.45, 0.85, 1.0)]
		4:
			return [Color(0.1, 0.1, 0.12), Color(0.05, 0.05, 0.06), Color(0.85, 0.15, 0.18)]
	return [Color(0.62, 0.52, 0.36), Color(0.2, 0.19, 0.16), Color(0.85, 0.55, 0.12)]

func set_palette(index: int) -> void:
	# Palettes are PER ROBOT — picking a paint on one mech must not repaint
	# the whole hangar after an app restart.
	armor_palette = clampi(index, 0, PALETTE_COUNT - 1)
	robot_palettes[String(selected_robot)] = armor_palette
	save_settings()

func palette_for(robot_id: StringName) -> int:
	if robot_palettes.has(String(robot_id)):
		return clampi(int(robot_palettes[String(robot_id)]), 0, PALETTE_COUNT - 1)
	return clampi(armor_palette, 0, PALETTE_COUNT - 1)

func sync_palette_cursor() -> void:
	armor_palette = palette_for(selected_robot)

func paint_unlocked(index: int) -> bool:
	return unlocked_paints.has(clampi(index, 0, PALETTE_COUNT - 1))

func paint_cost(index: int) -> int:
	return PAINT_COSTS[clampi(index, 0, PALETTE_COUNT - 1)]

# Returns true when the paint is (now) owned. False = not enough silver.
func unlock_paint(index: int) -> bool:
	var i := clampi(index, 0, PALETTE_COUNT - 1)
	if unlocked_paints.has(i):
		return true
	var cost := PAINT_COSTS[i]
	if silver < cost:
		return false
	silver -= cost
	unlocked_paints.append(i)
	save_settings()
	Events.wallet_changed.emit()
	return true

# Hangar combat-stat visibility: base -> final for every multiplier with
# the PILOT / DRONE / SPECIALIZATION contributions spelled out per row.
func combat_stat_report(robot_id: StringName = selected_robot) -> Array[Dictionary]:
	var labels: Array[Dictionary] = [
		{"key": "hp", "label": "ARMOR"},
		{"key": "damage", "label": "DAMAGE"},
		{"key": "fire_rate", "label": "FIRE RATE"},
		{"key": "speed", "label": "SPEED"},
		{"key": "defense", "label": "RESIST"},
		{"key": "cooldown", "label": "ABILITY CDR"},
		{"key": "regen", "label": "REPAIR"},
	]
	var systems: Array[Dictionary] = [
		{"label": "PILOT", "effects": pilot_effects(robot_id)},
		{"label": "DRONE", "effects": drone_effects(robot_id)},
		{"label": "SPEC", "effects": spec_effects(robot_id)},
	]
	var passive_regen := float(robot_def(robot_id).get("passive_regen", 0.0))
	if passive_regen > 0.0:
		systems.append({"label": "REACTOR", "effects": {
			"hp": 1.0, "damage": 1.0, "fire_rate": 1.0, "speed": 1.0,
			"defense": 1.0, "cooldown": 1.0, "regen": passive_regen,
		}})
	var final := combat_stats(robot_id)
	var rows: Array[Dictionary] = []
	for entry in labels:
		var stat_key := String(entry.get("key", ""))
		var is_regen := stat_key == "regen"
		var base := BASE_REGEN if is_regen else 1.0
		var sources: Array[String] = []
		for system in systems:
			var effects: Dictionary = system["effects"]
			var value := float(effects.get(stat_key, base))
			if is_regen:
				if value > 0.0:
					sources.append("%s +%.2f%%/s" % [String(system.get("label", "")),
							value * 100.0])
			elif not is_equal_approx(value, 1.0):
				sources.append("%s %+.1f%%" % [String(system.get("label", "")),
						(value - 1.0) * 100.0])
		rows.append({
			"key": stat_key,
			"label": String(entry.get("label", "")),
			"base": base,
			"final": float(final.get(stat_key, base)),
			"sources": sources,
		})
	return rows

# ---------------------------------------------------------------- settings

func set_look_sensitivity(value: float) -> void:
	look_sensitivity = clampf(value, 0.3, 2.5)
	apply_settings()
	save_settings()

func set_master_volume(value: float) -> void:
	master_volume = clampf(value, 0.0, 1.0)
	apply_settings()
	save_settings()

func set_invert_look(value: bool) -> void:
	invert_look_y = value
	apply_settings()
	save_settings()

func set_music_volume(value: float) -> void:
	music_volume = clampf(value, 0.0, 1.0)
	apply_settings()
	save_settings()

func set_damage_numbers(value: bool) -> void:
	damage_numbers = value
	save_settings()

func set_fps_counter(value: bool) -> void:
	fps_counter = value
	save_settings()

func set_vibration_enabled(value: bool) -> void:
	vibration_enabled = value
	save_settings()

func set_pad_deadzone_left(value: float) -> void:
	pad_deadzone_left = clampf(value, DEADZONE_MIN, DEADZONE_MAX)
	apply_settings()
	save_settings()

func set_pad_deadzone_right(value: float) -> void:
	pad_deadzone_right = clampf(value, DEADZONE_MIN, DEADZONE_MAX)
	apply_settings()
	save_settings()

func set_input_diagnostics(value: bool) -> void:
	input_diagnostics = value
	save_settings()

func set_target_priority(value: int) -> void:
	target_priority = clampi(value, 0, TARGET_PRIORITY_LABELS.size() - 1)
	save_settings()

func cycle_target_priority() -> void:
	set_target_priority((target_priority + 1) % TARGET_PRIORITY_LABELS.size())

func target_priority_label() -> String:
	return TARGET_PRIORITY_LABELS[clampi(target_priority, 0,
			TARGET_PRIORITY_LABELS.size() - 1)]

func cycle_input_ui_mode() -> void:
	input_ui_mode = (input_ui_mode + 1) % UI_MODE_LABELS.size()
	save_settings()

func input_ui_mode_label() -> String:
	return UI_MODE_LABELS[clampi(input_ui_mode, 0, UI_MODE_LABELS.size() - 1)]

func cycle_graphics() -> void:
	Quality.cycle_tier()
	selected_quality = Quality.tier()
	save_settings()

func apply_settings() -> void:
	InputRouter.camera_sensitivity = look_sensitivity
	InputRouter.invert_look_y = invert_look_y
	InputRouter.pad_deadzone_left = clampf(pad_deadzone_left, DEADZONE_MIN, DEADZONE_MAX)
	InputRouter.pad_deadzone_right = clampf(pad_deadzone_right, DEADZONE_MIN, DEADZONE_MAX)
	AudioServer.set_bus_volume_db(0, linear_to_db(maxf(master_volume, 0.001)))
	var music_bus := AudioServer.get_bus_index("Music")
	if music_bus >= 0:
		AudioServer.set_bus_volume_db(music_bus,
				linear_to_db(maxf(music_volume, 0.001)))

func robot_power(robot_id: StringName = selected_robot) -> int:
	var power := int(float(robot_def(robot_id).get("armor", 200.0)) * 2.0)
	var slots := robot_slots(robot_id)
	for index in slots.size():
		var item := equipped_item(robot_id, index)
		if item.is_empty():
			continue
		var base_damage := WeaponData.for_item(item).damage
		power += int(base_damage * 6.0 * item_damage_mult(robot_id, index))
	return maxi(1, int(round(float(power) * body_mult(robot_id))))

static func fmt_amount(value: float) -> String:
	var sign_char := "" if value >= 0.0 else "-"
	var v := absf(value)
	# Promote to millions before the K branch can render "1000K": a value
	# just under 1M must read "1.00M", never a mixed-unit pair like
	# "1000K / 1.48M".  Sub-10M values keep two decimals (WR style).
	if v >= 999500.0:
		var millions := v / 1000000.0
		if millions < 10.0:
			return "%s%.2fM" % [sign_char, millions]
		return "%s%dM" % [sign_char, int(round(millions))]
	if v >= 10000.0:
		var thousands := v / 1000.0
		if thousands < 100.0:
			var text := "%.1f" % thousands
			if text.ends_with("0"):
				text = text.substr(0, text.length() - 2)
			return "%s%sK" % [sign_char, text]
		return "%s%dK" % [sign_char, int(round(thousands))]
	return "%s%d" % [sign_char, int(round(v))]

func pilot_level() -> int:
	var total := 0
	for key in upgrades.keys():
		var state := upgrades[key] as Vector2i
		# Titan ladders run past the MK ladder; keep one key worth of credit.
		var level := clampi(state.y, 1, LV_MAX)
		total += (clampi(state.x, 1, MK_MAX) - 1) * LV_MAX + level
	return 1 + int(total / 12.0)

# ---------------------------------------------------------------- upgrades
# MK1 lv1-12 -> MK2 lv1-12 -> MK3 lv1-12 (War Robots style). Damage curve has no
# drop at MK transitions; performance (rate of fire / heat efficiency) scales softer.

func upgrade_key(robot_id: StringName, index: int) -> String:
	return "%s:%d" % [String(robot_id), index]

func body_upgrade_key(robot_id: StringName) -> String:
	return "%s:body" % String(robot_id)

# Which ladder a key belongs to: MK1-3 x lv1-12 for normal robots and weapons,
# a single lv1-150 ladder for a titan hull, lv1-25 for titan weapons.
func upgrade_class(key: String) -> int:
	var parts := key.split(":", false, 2)
	if parts.size() != 2:
		return UpgradeClass.STANDARD
	var robot_id := StringName(parts[0])
	if parts[1] == "body":
		return UpgradeClass.TITAN_HULL if is_titan(robot_id) else UpgradeClass.STANDARD
	var item := equipped_item(robot_id, int(parts[1]))
	if not item.is_empty() and item_slot_size(item) >= SlotSize.ALPHA:
		return UpgradeClass.TITAN_WEAPON
	return UpgradeClass.STANDARD

func upgrade_level_cap(key: String) -> int:
	match upgrade_class(key):
		UpgradeClass.TITAN_HULL: return LV_MAX_TITAN
		UpgradeClass.TITAN_WEAPON: return LV_MAX_TITAN_WEAPON
	return LV_MAX

func upgrade_mk_cap(key: String) -> int:
	return 1 if upgrade_class(key) != UpgradeClass.STANDARD else MK_MAX

func upgrade_state(key: String) -> Vector2i:
	var state := upgrades.get(key, Vector2i(1, 1)) as Vector2i
	return Vector2i(clampi(state.x, 1, upgrade_mk_cap(key)),
			clampi(state.y, 1, upgrade_level_cap(key)))

static func damage_mult_for(mk: int, lv: int) -> float:
	match mk:
		2: return 1.85 + 0.025 * float(lv - 1)
		3: return 2.15 + 0.030 * float(lv - 1)
	return 1.0 + 0.075 * float(lv - 1)

static func durability_mult_for(mk: int, lv: int) -> float:
	match mk:
		2: return 2.10 + 0.025 * float(lv - 1)
		3: return 2.40 + 0.040 * float(lv - 1)
	return 1.0 + 0.100 * float(lv - 1)

static func performance_mult_for(mk: int, lv: int) -> float:
	match mk:
		2: return 1.24 + 0.010 * float(lv - 1)
		3: return 1.36 + 0.015 * float(lv - 1)
	return 1.0 + 0.020 * float(lv - 1)

# Titan ladders: hull lv1-150 durability, titan weapons lv1-25 damage/rate.
static func titan_durability_mult_for(lv: int) -> float:
	return 1.0 + 0.004 * float(lv - 1)

static func titan_damage_mult_for(lv: int) -> float:
	return 1.0 + 0.020 * float(lv - 1)

static func titan_performance_mult_for(lv: int) -> float:
	return 1.0 + 0.008 * float(lv - 1)

func item_damage_mult(robot_id: StringName, index: int) -> float:
	var key := upgrade_key(robot_id, index)
	if upgrade_class(key) == UpgradeClass.TITAN_WEAPON:
		return titan_damage_mult_for(upgrade_state(key).y)
	var state := upgrade_state(key)
	return damage_mult_for(state.x, state.y)

func item_performance_mult(robot_id: StringName, index: int) -> float:
	var key := upgrade_key(robot_id, index)
	if upgrade_class(key) == UpgradeClass.TITAN_WEAPON:
		return titan_performance_mult_for(upgrade_state(key).y)
	var state := upgrade_state(key)
	return performance_mult_for(state.x, state.y)

# Key-aware helpers for the upgrade screen (it previews any state, including
# the one being purchased next).
func body_mult_at(key: String, state: Vector2i) -> float:
	if upgrade_class(key) == UpgradeClass.TITAN_HULL:
		return titan_durability_mult_for(state.y)
	return durability_mult_for(state.x, state.y)

func weapon_damage_mult_at(key: String, state: Vector2i) -> float:
	if upgrade_class(key) == UpgradeClass.TITAN_WEAPON:
		return titan_damage_mult_for(state.y)
	return damage_mult_for(state.x, state.y)

func weapon_performance_mult_at(key: String, state: Vector2i) -> float:
	if upgrade_class(key) == UpgradeClass.TITAN_WEAPON:
		return titan_performance_mult_for(state.y)
	return performance_mult_for(state.x, state.y)

func body_mult(robot_id: StringName = selected_robot) -> float:
	var key := body_upgrade_key(robot_id)
	if upgrade_class(key) == UpgradeClass.TITAN_HULL:
		return titan_durability_mult_for(upgrade_state(key).y)
	var state := upgrade_state(key)
	return durability_mult_for(state.x, state.y)

func apply_weapon_upgrades(data: WeaponData, robot_id: StringName, index: int) -> void:
	if data == null:
		return
	var damage_mult := item_damage_mult(robot_id, index)
	var perf_mult := item_performance_mult(robot_id, index)
	data.damage = roundf(data.damage * damage_mult * 10.0) / 10.0
	data.shots_per_minute = roundf(data.shots_per_minute * perf_mult)
	data.heat_per_shot = data.heat_per_shot / perf_mult
	data.display_name = data.item_id
	apply_combat_stats(data)

func upgrade_cost(key: String) -> Dictionary:
	var cls := upgrade_class(key)
	var state := upgrade_state(key)
	var cap := upgrade_level_cap(key)
	if cls == UpgradeClass.STANDARD:
		if state.x == MK_MAX and state.y >= LV_MAX:
			return {"maxed": true, "silver": 0, "gold": 0, "parts": 0,
					"platinum": 0, "mk": state.x, "lv": state.y, "cap": cap}
		if state.y >= LV_MAX:
			return {"maxed": false, "silver": 0, "gold": 500 * state.x,
					"parts": 150 * state.x, "platinum": 0, "mk": state.x,
					"lv": state.y, "cap": cap}
		var factor := 1.0 + 2.5 * float(state.x - 1)
		var raw := 1500.0 * float(state.y) * float(state.y) * factor
		return {"maxed": false, "silver": int(snappedf(raw, 500.0)), "gold": 0,
				"parts": 20 * state.y * state.x, "platinum": 0, "mk": state.x,
				"lv": state.y, "cap": cap}
	# Titan hull (lv1-150) and titan weapons (lv1-25) upgrade with platinum only.
	if state.y >= cap:
		return {"maxed": true, "silver": 0, "gold": 0, "parts": 0,
				"platinum": 0, "mk": state.x, "lv": state.y, "cap": cap}
	var step := 8.0 if cls == UpgradeClass.TITAN_HULL else 30.0
	return {"maxed": false, "silver": 0, "gold": 0, "parts": 0,
			"platinum": int(snappedf(step * float(state.y), 5.0)),
			"mk": state.x, "lv": state.y, "cap": cap}

func perform_upgrade(key: String) -> bool:
	var cost := upgrade_cost(key)
	if bool(cost["maxed"]):
		return false
	var state := upgrade_state(key)
	var parts := int(cost["parts"])
	if int(cost["platinum"]) > 0:
		if platinum < int(cost["platinum"]):
			return false
		platinum -= int(cost["platinum"])
		upgrades[key] = Vector2i(state.x, state.y + 1)
	elif int(cost["gold"]) > 0:
		if gold < int(cost["gold"]) or spare_parts < parts:
			return false
		gold -= int(cost["gold"])
		spare_parts -= parts
		upgrades[key] = Vector2i(state.x + 1, 1)
	else:
		if silver < int(cost["silver"]) or spare_parts < parts:
			return false
		silver -= int(cost["silver"])
		spare_parts -= parts
		upgrades[key] = Vector2i(state.x, state.y + 1)
	save_settings()
	Events.wallet_changed.emit()
	return true

func reward_silver(amount: int) -> void:
	silver += amount
	match_reward_silver += amount
	Events.wallet_changed.emit()

func can_upgrade(key: String) -> bool:
	var cost := upgrade_cost(key)
	if bool(cost["maxed"]):
		return false
	if spare_parts < int(cost["parts"]):
		return false
	if int(cost["platinum"]) > 0:
		return platinum >= int(cost["platinum"])
	if int(cost["gold"]) > 0:
		return gold >= int(cost["gold"])
	return silver >= int(cost["silver"])

# ---------------------------------------------------------------- pilots
# War Robots style: level ladder to 70, skill slots unlock every 10 levels,
# seven skill tracks trained independently (instant, silver), skill tiers
# T1-T4 boosted by pilot tier (legendary pilots reach T4).

const PILOT_MAX_LEVEL := 70
const PILOT_XP_BASE := 50
const PILOT_SLOT_LEVELS: Array[int] = [1, 11, 21, 31, 41, 51, 61]
const PILOT_TIER_MULT: Array[float] = [1.0, 1.0, 1.1, 1.2, 1.5]
const PILOT_SKILL_NAMES: Array[String] = [
	"ARMOR PLATING", "REACTIVE KEVLAR", "GUNNERY", "LOADER CREW",
	"FIELD REPAIR", "OVERCLOCK", "SURGE",
]
const PILOT_SKILL_DESC: Array[String] = [
	"+2% durability per level",
	"1.2% less damage taken per level",
	"+1.8% weapon damage per level",
	"+1.4% rate of fire per level",
	"+0.1% max HP/s field repair per level",
	"2.5% faster ability recharge per level",
	"+1.2% top speed per level",
]
# rarity 1 standard (tier cap T3), 2 elite (T3, +20% XP), 3 legendary (T4, +50% XP)
const PILOT_DEFS: Array[Dictionary] = [
	{"id": "vex", "name": "VEX", "klass": "STRIKER", "rarity": 1,
		"sig_robot": ROBOT_SCARAB},
	{"id": "orin", "name": "ORIN", "klass": "GUNNER", "rarity": 1,
		"sig_robot": ROBOT_VORTEX},
	{"id": "sable", "name": "SABLE", "klass": "WRECKER", "rarity": 1,
		"sig_robot": ROBOT_RAMPART},
	{"id": "nyx", "name": "NYX", "klass": "SCOUT", "rarity": 1},
	{"id": "rhett", "name": "RHETT", "klass": "BREACHER", "rarity": 2},
	{"id": "ilya", "name": "ILYA", "klass": "ORDNANCE", "rarity": 2},
	{"id": "mara", "name": "MARA VANCE", "klass": "TACTICIAN", "rarity": 3,
		"sig_robot": ROBOT_PRAETOR},
	{"id": "kade", "name": "KADE", "klass": "VANGUARD", "rarity": 3},
	{"id": "dorn", "name": "DORN", "klass": "BASTION", "rarity": 3,
		"sig_robot": ROBOT_CITADEL},
	{"id": "varga", "name": "VARGA", "klass": "REAVER", "rarity": 3,
		"sig_robot": ROBOT_RAVAGER},
	# v0.35 — WR 12.3/12.4 legendary pilots (names + signature robots are the
	# WR pairing; unique carries their legendary skill in our own words).
	{"id": "nadir", "name": "NADIR RAKHIM", "klass": "STRIKER", "rarity": 3,
		"sig_robot": ROBOT_SCARAB,
		"unique": "Dustbind — Sandcloak dash leaves an EMP + rust cone · Dead Calm — tighter scatter spread up close"},
	{"id": "toshiro", "name": "TOSHIRO KUROSAWA", "klass": "BASTION", "rarity": 3,
		"sig_robot": ROBOT_CITADEL,
		"unique": "Toshiro's Protection — barrier field lasts 5 s longer · Resilience — +10% hull durability"},
	{"id": "cliff", "name": "CLIFF DEBUSSE", "klass": "REAVER", "rarity": 3,
		"sig_robot": ROBOT_RAVAGER,
		"unique": "Cliff's Sanctuary — shroud grants +5% durability and repairs over time"},
	{"id": "donnie", "name": "DONNIE WOO", "klass": "GUNNER", "rarity": 3,
		"unique": "Donnie's Blindness — charged burst blinds the target · WOO HOO — charge reload sped up"},
	{"id": "andor", "name": "ANDOR MIHHARR", "klass": "WRECKER", "rarity": 3,
		"unique": "A Bet on Life — bonus damage while aegis is up · Infinite Luck — freeze rockets chill harder"},
]

const DRONE_MAX_LEVEL := 9
const DRONE_DEFS: Array[Dictionary] = [
	{"id": "wisp", "name": "WISP", "klass": "SCOUT", "rarity": 1,
		"effect": "speed", "per_level": 0.01, "heal": 0.08, "sig_robot": ROBOT_SCARAB,
		"desc": "+1% top speed per level · emergency repair 8% HP at critical · SPECIALIST OF SCARAB (x1.5 on match)"},
	{"id": "bulwark", "name": "BULWARK", "klass": "GUARDIAN", "rarity": 1,
		"effect": "defense", "per_level": 0.01, "heal": 0.12, "sig_robot": ROBOT_RAMPART,
		"desc": "-1% damage taken per level · emergency repair 12% HP at critical · SPECIALIST OF ZEPHYR (x1.5 on match)"},
	{"id": "patch", "name": "PATCH", "klass": "SUPPORT", "rarity": 2,
		"effect": "regen", "per_level": 0.001, "heal": 0.15, "sig_robot": "",
		"desc": "+0.1% max HP/s field repair per level · emergency repair 15% HP at critical · spare drone for any chassis"},
	{"id": "kestrel", "name": "KESTREL", "klass": "INTERCEPTOR", "rarity": 2,
		"effect": "damage", "per_level": 0.01, "heal": 0.08, "sig_robot": ROBOT_VORTEX,
		"desc": "+1% weapon damage per level · emergency repair 8% HP at critical · SPECIALIST OF VORTEX (x1.5 on match)"},
	# v0.35 — WR 12.3/12.4 specialist drones.
	{"id": "scourveil", "name": "SCOURVEIL", "klass": "STRIKER", "rarity": 3,
		"effect": "speed", "per_level": 0.012, "heal": 0.10, "sig_robot": ROBOT_SCARAB,
		"desc": "+1.2% top speed per level · emergency repair 10% HP at critical · SPECIALIST OF SCARAB (x1.5 on match)"},
	{"id": "prena", "name": "PRENA", "klass": "INTERCEPTOR", "rarity": 3,
		"effect": "damage", "per_level": 0.012, "heal": 0.08, "sig_robot": "",
		"desc": "+1.2% weapon damage per level · emergency repair 8% HP at critical · specialist drone for any chassis"},
]

const SPEC_MAX_RANK := 5
const SPEC_BASE: Array[Dictionary] = [
	{"id": "hull", "name": "HULL DENSITY", "effect": "hp", "per_rank": 0.025,
		"desc": "+2.5% armor per rank"},
	{"id": "targeting", "name": "TARGETING ARRAY", "effect": "damage", "per_rank": 0.025,
		"desc": "+2.5% weapon damage per rank"},
	{"id": "servos", "name": "SERVO MOTORS", "effect": "speed", "per_rank": 0.018,
		"desc": "+1.8% top speed per rank"},
	{"id": "capacitor", "name": "ABILITY CAPACITOR", "effect": "cooldown", "per_rank": 0.025,
		"desc": "-2.5% ability cooldown per rank"},
]
const SPEC_CLASS: Dictionary = {
	&"SCARAB": [
		{"id": "carapace", "name": "CARAPACE LAMINATE", "effect": "defense", "per_rank": 0.02,
			"desc": "-2% damage taken per rank"},
		{"id": "venom", "name": "VENOM GLANDS", "effect": "damage", "per_rank": 0.03,
			"desc": "+3% weapon damage per rank"},
		{"id": "swarm", "name": "SWARM LOGIC", "effect": "fire_rate", "per_rank": 0.025,
			"desc": "+2.5% rate of fire per rank"},
		{"id": "phase", "name": "PHASE WEAVE", "effect": "regen", "per_rank": 0.001,
			"desc": "+0.1% max HP/s repair per rank"},
	],
	&"VORTEX": [
		{"id": "titanium", "name": "TITANIUM RIBS", "effect": "hp", "per_rank": 0.035,
			"desc": "+3.5% armor per rank"},
		{"id": "arcfocus", "name": "ARC FOCUS", "effect": "fire_rate", "per_rank": 0.03,
			"desc": "+3% rate of fire per rank"},
		{"id": "jettanks", "name": "JET TANKS", "effect": "cooldown", "per_rank": 0.03,
			"desc": "-3% ability cooldown per rank"},
		{"id": "heavydrive", "name": "HEAVY DRIVES", "effect": "speed", "per_rank": 0.022,
			"desc": "+2.2% top speed per rank"},
	],
	&"RAMPART": [
		{"id": "bulwark", "name": "AEROPLATE", "effect": "defense", "per_rank": 0.03,
			"desc": "-3% damage taken per rank"},
		{"id": "siegebrake", "name": "STORM CANNONS", "effect": "damage", "per_rank": 0.028,
			"desc": "+2.8% weapon damage per rank"},
		{"id": "fieldmedic", "name": "REPAIR NANITES", "effect": "regen", "per_rank": 0.0015,
			"desc": "+0.15% max HP/s repair per rank"},
		{"id": "reinforce", "name": "DENSE FRAME", "effect": "hp", "per_rank": 0.03,
			"desc": "+3% armor per rank"},
	],
	&"PRAETOR": [
		{"id": "aegis", "name": "AEGIS MATRIX", "effect": "defense", "per_rank": 0.025,
			"desc": "-2.5% damage taken per rank"},
		{"id": "siegefire", "name": "SIEGE FIRE", "effect": "damage", "per_rank": 0.03,
			"desc": "+3% weapon damage per rank"},
		{"id": "gravcoils", "name": "GRAV COILS", "effect": "speed", "per_rank": 0.02,
			"desc": "+2% top speed per rank"},
		{"id": "coreloop", "name": "CORE LOOP", "effect": "cooldown", "per_rank": 0.03,
			"desc": "-3% ability cooldown per rank"},
	],
	&"CITADEL": [
		{"id": "bastion", "name": "BASTION PLATING", "effect": "defense", "per_rank": 0.025,
			"desc": "-2.5% damage taken per rank"},
		{"id": "provocation", "name": "PROVOCATION", "effect": "cooldown", "per_rank": 0.03,
			"desc": "-3% ability cooldown per rank"},
		{"id": "reactor", "name": "REACTOR LATTICE", "effect": "regen", "per_rank": 0.0015,
			"desc": "+0.15% max HP/s repair per rank"},
		{"id": "counterweight", "name": "COUNTERWEIGHT", "effect": "hp", "per_rank": 0.03,
			"desc": "+3% armor per rank"},
	],
	&"RAVAGER": [
		{"id": "shred", "name": "SHRED ROUNDS", "effect": "damage", "per_rank": 0.03,
			"desc": "+3% weapon damage per rank"},
		{"id": "overclock", "name": "OVERCLOCK", "effect": "fire_rate", "per_rank": 0.025,
			"desc": "+2.5% rate of fire per rank"},
		{"id": "ramplate", "name": "RAM PLATE", "effect": "hp", "per_rank": 0.03,
			"desc": "+3% armor per rank"},
		{"id": "pulsedrive", "name": "PULSE DRIVE", "effect": "speed", "per_rank": 0.022,
			"desc": "+2.2% top speed per rank"},
	],
}

var pilots: Dictionary = {}
var pilot_assignments: Dictionary = {}
# Pilots are bought (silver for standard/elite, gold for legendary); the four
# signature pilots of the starting roster come with the account.
var owned_pilots: Array[String] = []

func pilot_def(pilot_id: String) -> Dictionary:
	for definition in PILOT_DEFS:
		if String(definition.get("id", "")) == pilot_id:
			return definition
	return {}

func ensure_pilot(pilot_id: String) -> Dictionary:
	if not pilots.has(pilot_id):
		pilots[pilot_id] = {"level": 1, "xp": 0, "tier": 1, "skills": [0, 0, 0, 0, 0, 0, 0]}
	return pilots[pilot_id] as Dictionary

func pilot_state(pilot_id: String) -> Dictionary:
	return ensure_pilot(pilot_id)

func assigned_pilot(robot_id: StringName) -> String:
	return String(pilot_assignments.get(robot_id, ""))

func owns_pilot(pilot_id: String) -> bool:
	return owned_pilots.has(pilot_id)

# Pilot prices follow rarity: standard 25k silver, elite 80k silver,
# legendary 250 gold (WR sells legendary pilots for gold).
func pilot_buy_cost(pilot_id: String) -> int:
	if pilot_def(pilot_id).is_empty() or owns_pilot(pilot_id):
		return 0
	match pilot_rarity(pilot_id):
		2: return 80000
		3: return 250
	return 25000

func pilot_buy_currency(pilot_id: String) -> String:
	return "gold" if pilot_rarity(pilot_id) >= 3 else "silver"

func buy_pilot(pilot_id: String) -> bool:
	var cost := pilot_buy_cost(pilot_id)
	if cost <= 0:
		return false
	if pilot_buy_currency(pilot_id) == "gold":
		if gold < cost:
			return false
		gold -= cost
	else:
		if silver < cost:
			return false
		silver -= cost
	if not owned_pilots.has(pilot_id):
		owned_pilots.append(pilot_id)
	ensure_pilot(pilot_id)
	save_settings()
	Events.wallet_changed.emit()
	return true

# Pilot exclusivity was removed: one pilot may sit in several hangar slots at
# once, so "is this pilot in use" scans EVERY robot's assignment entry.
func is_pilot_assigned(pilot_id: String) -> bool:
	for robot_id in pilot_assignments.keys():
		if String(pilot_assignments[robot_id]) == pilot_id:
			return true
	return false

func sell_price_pilot(pilot_id: String) -> int:
	if pilot_def(pilot_id).is_empty():
		return 0
	var level := int(ensure_pilot(pilot_id).get("level", 1))
	return snappedi(pilot_rarity(pilot_id) * 8000 + level * 200, 500)

func sell_pilot(pilot_id: String) -> bool:
	if not owns_pilot(pilot_id) or is_pilot_assigned(pilot_id):
		return false
	var price := sell_price_pilot(pilot_id)
	if price <= 0:
		return false
	owned_pilots.erase(pilot_id)
	# The level/skill state stays (same policy as upgrade tracks), so a rebuy
	# restores the trained pilot.
	silver += price
	save_settings()
	Events.wallet_changed.emit()
	return true

func assign_pilot(robot_id: StringName, pilot_id: String) -> bool:
	if pilot_id.is_empty() or pilot_def(pilot_id).is_empty() \
			or not owns_pilot(pilot_id):
		return false
	pilot_assignments[robot_id] = pilot_id
	ensure_pilot(pilot_id)
	save_settings()
	Events.pilot_progress.emit()
	return true

func pilot_rarity(pilot_id: String) -> int:
	return int(pilot_def(pilot_id).get("rarity", 1))

func pilot_max_tier(pilot_id: String) -> int:
	return 4 if pilot_rarity(pilot_id) >= 3 else 3

func pilot_xp_need(level: int) -> int:
	return PILOT_XP_BASE * level

func pilot_skill_unlocked(pilot_id: String, skill_index: int) -> bool:
	var state := ensure_pilot(pilot_id)
	return int(state.get("level", 1)) >= PILOT_SLOT_LEVELS[skill_index]

func pilot_skill_level(pilot_id: String, skill_index: int) -> int:
	var state := ensure_pilot(pilot_id)
	var skills := state.get("skills", []) as Array
	if skill_index < 0 or skill_index >= skills.size():
		return 0
	return int(skills[skill_index])

func pilot_skill_cost(pilot_id: String, skill_index: int) -> int:
	return 600 * (pilot_skill_level(pilot_id, skill_index) + 1)

func train_pilot_skill(pilot_id: String, skill_index: int) -> bool:
	if pilot_def(pilot_id).is_empty():
		return false
	if not pilot_skill_unlocked(pilot_id, skill_index):
		return false
	if pilot_skill_level(pilot_id, skill_index) >= 10:
		return false
	var cost := pilot_skill_cost(pilot_id, skill_index)
	if memorium < cost:
		return false
	memorium -= cost
	var state := ensure_pilot(pilot_id)
	var skills := state.get("skills", []) as Array
	skills[skill_index] = pilot_skill_level(pilot_id, skill_index) + 1
	state["skills"] = skills
	save_settings()
	Events.wallet_changed.emit()
	Events.pilot_progress.emit()
	return true

func pilot_tier_cost(pilot_id: String) -> int:
	var state := ensure_pilot(pilot_id)
	var tier := int(state.get("tier", 1))
	if tier >= pilot_max_tier(pilot_id):
		return 0
	match tier:
		1: return 150
		2: return 250
	return 500

func upgrade_pilot_tier(pilot_id: String) -> bool:
	var cost := pilot_tier_cost(pilot_id)
	# WR 9.3: pilot rank/tier promotions cost Memorium, never gold.
	if cost <= 0 or memorium < cost:
		return false
	memorium -= cost
	var state := ensure_pilot(pilot_id)
	state["tier"] = int(state.get("tier", 1)) + 1
	save_settings()
	Events.wallet_changed.emit()
	Events.pilot_progress.emit()
	return true

func pilot_tier_mult(pilot_id: String) -> float:
	var tier := int(ensure_pilot(pilot_id).get("tier", 1))
	return PILOT_TIER_MULT[clampi(tier, 1, 4)]

func grant_pilot_match_xp() -> void:
	var pilot_id := assigned_pilot(selected_robot)
	if pilot_id.is_empty():
		return
	var rarity := pilot_rarity(pilot_id)
	var gain := enemies_killed * 100 + (600 if phase == Phase.VICTORY else 200)
	gain = int(float(gain) * (1.0 if rarity == 1 else (1.2 if rarity == 2 else 1.5)))
	var state := ensure_pilot(pilot_id)
	var level := int(state.get("level", 1))
	var xp := int(state.get("xp", 0)) + gain
	while level < PILOT_MAX_LEVEL and xp >= pilot_xp_need(level):
		xp -= pilot_xp_need(level)
		level += 1
	state["level"] = level
	state["xp"] = xp
	pilot_xp_gained += gain
	save_settings()
	Events.pilot_progress.emit()

func signature_pilot_name_for(robot_id: StringName) -> String:
	for definition in PILOT_DEFS:
		if String(definition.get("sig_robot", "")) == String(robot_id):
			return String(definition.get("name", ""))
	return ""

func signature_drone_name_for(robot_id: StringName) -> String:
	for definition in DRONE_DEFS:
		if String(definition.get("sig_robot", "")) == String(robot_id):
			return String(definition.get("name", ""))
	return ""

func pilot_effects(robot_id: StringName = selected_robot) -> Dictionary:
	var effects := {
		"hp": 1.0, "defense": 1.0, "damage": 1.0, "fire_rate": 1.0,
		"regen": 0.0, "cooldown": 1.0, "speed": 1.0,
	}
	var pilot_id := assigned_pilot(robot_id)
	if pilot_id.is_empty():
		return effects
	var mult := pilot_tier_mult(pilot_id)
	var lv0 := pilot_skill_level(pilot_id, 0)
	var lv1 := pilot_skill_level(pilot_id, 1)
	var lv2 := pilot_skill_level(pilot_id, 2)
	var lv3 := pilot_skill_level(pilot_id, 3)
	var lv4 := pilot_skill_level(pilot_id, 4)
	var lv5 := pilot_skill_level(pilot_id, 5)
	var lv6 := pilot_skill_level(pilot_id, 6)
	effects["hp"] = 1.0 + 0.02 * float(lv0) * mult
	effects["defense"] = maxf(0.5, 1.0 - 0.012 * float(lv1) * mult)
	effects["damage"] = 1.0 + 0.018 * float(lv2) * mult
	effects["fire_rate"] = 1.0 + 0.014 * float(lv3) * mult
	effects["regen"] = 0.001 * float(lv4) * mult
	effects["cooldown"] = maxf(0.5, 1.0 - 0.025 * float(lv5) * mult)
	effects["speed"] = 1.0 + 0.012 * float(lv6) * mult
	var sig := String(pilot_def(pilot_id).get("sig_robot", ""))
	if sig == String(robot_id):
		for key in ["hp", "defense", "damage", "fire_rate", "cooldown", "speed"]:
			effects[key] = 1.0 + (effects[key] - 1.0) * 1.5
		effects["regen"] *= 1.5
	return effects

# ---------------------------------------------------------------- drones

func drone_def(drone_id: String) -> Dictionary:
	for definition in DRONE_DEFS:
		if String(definition.get("id", "")) == drone_id:
			return definition
	return {}

func owns_drone(drone_id: String) -> bool:
	return owned_drones.has(drone_id)

func drone_level(drone_id: String) -> int:
	if not owns_drone(drone_id):
		return 0
	return clampi(int(drone_levels.get(drone_id, 1)), 1, DRONE_MAX_LEVEL)

func drone_buy_cost(drone_id: String) -> int:
	var definition := drone_def(drone_id)
	if definition.is_empty() or owns_drone(drone_id):
		return 0
	return 200 + 200 * int(definition.get("rarity", 1))

func drone_upgrade_cost(drone_id: String) -> int:
	var definition := drone_def(drone_id)
	if definition.is_empty() or not owns_drone(drone_id):
		return 0
	var level := drone_level(drone_id)
	if level >= DRONE_MAX_LEVEL:
		return 0
	return 250 * int(definition.get("rarity", 1)) * level

func buy_drone(drone_id: String) -> bool:
	var cost := drone_buy_cost(drone_id)
	if cost <= 0 or microchips < cost:
		return false
	microchips -= cost
	owned_drones.append(drone_id)
	drone_levels[drone_id] = 1
	save_settings()
	Events.wallet_changed.emit()
	return true

# "In use" = any hangar slot pairings (robot -> drone) naming this drone.
func is_drone_assigned(drone_id: String) -> bool:
	for robot_id in drone_assignments.keys():
		if String(drone_assignments[robot_id]) == drone_id:
			return true
	return false

func sell_price_drone(drone_id: String) -> int:
	if drone_def(drone_id).is_empty():
		return 0
	return snappedi(int(drone_def(drone_id).get("rarity", 1)) * 6000, 500)

func sell_drone(drone_id: String) -> bool:
	if not owns_drone(drone_id):
		return false
	# Blocked while a slot runs it, while it is the ACTIVE drone
	# (selected_drone - robots with no slot entry read it as their fallback),
	# and when it is the last drone on the account.
	if is_drone_assigned(drone_id) or selected_drone == drone_id:
		return false
	if owned_drones.size() <= 1:
		return false
	var price := sell_price_drone(drone_id)
	if price <= 0:
		return false
	owned_drones.erase(drone_id)
	drone_levels.erase(drone_id)
	silver += price
	save_settings()
	Events.wallet_changed.emit()
	return true

func upgrade_drone(drone_id: String) -> bool:
	var cost := drone_upgrade_cost(drone_id)
	if cost <= 0 or microchips < cost:
		return false
	microchips -= cost
	drone_levels[drone_id] = drone_level(drone_id) + 1
	save_settings()
	Events.wallet_changed.emit()
	return true

func select_drone(drone_id: String) -> bool:
	if is_titan() or not owns_drone(drone_id):
		return false
	selected_drone = drone_id
	drone_assignments[selected_robot] = drone_id
	save_settings()
	Events.wallet_changed.emit()
	return true

func assign_drone(robot_id: StringName, drone_id: String) -> bool:
	if is_titan(robot_id) or not owns_drone(drone_id):
		return false
	drone_assignments[robot_id] = drone_id
	if robot_id == selected_robot:
		selected_drone = drone_id
	save_settings()
	Events.wallet_changed.emit()
	return true

func drone_for_robot(robot_id: StringName) -> String:
	if is_titan(robot_id):
		# Titans run no companion drone (WR titans cannot equip drones).
		return ""
	var assigned := String(drone_assignments.get(robot_id, ""))
	if not assigned.is_empty() and owns_drone(assigned):
		return assigned
	if not selected_drone.is_empty() and owns_drone(selected_drone):
		return selected_drone
	return ""

func drone_break_mult(level: int) -> float:
	if level >= 9:
		return 3.0
	if level >= 4:
		return 2.0
	return 1.0

func drone_effects(robot_id: StringName = selected_robot) -> Dictionary:
	var effects := {"speed": 1.0, "defense": 1.0, "damage": 1.0, "regen": 0.0}
	var drone_id := drone_for_robot(robot_id)
	if drone_id.is_empty():
		return effects
	var definition := drone_def(drone_id)
	if definition.is_empty():
		return effects
	var value := float(definition.get("per_level", 0.0)) \
			* float(drone_level(drone_id)) \
			* drone_break_mult(drone_level(drone_id))
	if String(definition.get("sig_robot", "")) == String(robot_id):
		value *= 1.5
	match String(definition.get("effect", "")):
		"speed": effects["speed"] = 1.0 + value
		"defense": effects["defense"] = maxf(0.5, 1.0 - value)
		"damage": effects["damage"] = 1.0 + value
		"regen": effects["regen"] = value
	return effects

# ---------------------------------------------------------------- specializations

func spec_nodes(robot_id: StringName) -> Array:
	var nodes: Array = []
	nodes.append_array(SPEC_BASE)
	var class_nodes := SPEC_CLASS.get(robot_id, []) as Array
	nodes.append_array(class_nodes)
	return nodes

func spec_rank(robot_id: StringName, node_id: String) -> int:
	var robot_specs := specs.get(robot_id, {}) as Dictionary
	return clampi(int(robot_specs.get(node_id, 0)), 0, SPEC_MAX_RANK)

func spec_upgrade_cost(robot_id: StringName, node_id: String) -> int:
	if spec_rank(robot_id, node_id) >= SPEC_MAX_RANK:
		return 0
	return 4 * (spec_rank(robot_id, node_id) + 1)

func upgrade_spec(robot_id: StringName, node_id: String) -> bool:
	var cost := spec_upgrade_cost(robot_id, node_id)
	if cost <= 0 or module_points < cost:
		return false
	module_points -= cost
	if not specs.has(robot_id):
		specs[robot_id] = {}
	var robot_specs := specs[robot_id] as Dictionary
	robot_specs[node_id] = spec_rank(robot_id, node_id) + 1
	specs[robot_id] = robot_specs
	save_settings()
	Events.wallet_changed.emit()
	return true

func spec_effects(robot_id: StringName = selected_robot) -> Dictionary:
	var effects := {
		"hp": 1.0, "defense": 1.0, "damage": 1.0, "fire_rate": 1.0,
		"regen": 0.0, "cooldown": 1.0, "speed": 1.0,
	}
	for node in spec_nodes(robot_id):
		var node_id := String(node.get("id", ""))
		var rank := spec_rank(robot_id, node_id)
		if rank <= 0:
			continue
		var value := float(node.get("per_rank", 0.0)) * float(rank)
		match String(node.get("effect", "")):
			"hp": effects["hp"] = effects["hp"] + value
			"defense": effects["defense"] = maxf(0.4, effects["defense"] - value)
			"damage": effects["damage"] = effects["damage"] + value
			"fire_rate": effects["fire_rate"] = effects["fire_rate"] + value
			"regen": effects["regen"] = effects["regen"] + value
			"cooldown": effects["cooldown"] = maxf(0.4, effects["cooldown"] - value)
			"speed": effects["speed"] = effects["speed"] + value
	return effects

func combat_stats(robot_id: StringName = selected_robot) -> Dictionary:
	var stats := {
		"hp": 1.0, "defense": 1.0, "damage": 1.0, "fire_rate": 1.0,
		# A chassis may declare its own reactor upkeep (CITADEL's passive):
		# folded into the same regen key so pilot/spec stacking is unchanged.
		"regen": BASE_REGEN + float(robot_def(robot_id).get("passive_regen", 0.0)),
		"cooldown": 1.0, "speed": 1.0,
	}
	var sources: Array[Dictionary] = [
		pilot_effects(robot_id), spec_effects(robot_id), drone_effects(robot_id),
	]
	for source in sources:
		stats["hp"] *= float(source.get("hp", 1.0))
		stats["defense"] *= float(source.get("defense", 1.0))
		stats["damage"] *= float(source.get("damage", 1.0))
		stats["fire_rate"] *= float(source.get("fire_rate", 1.0))
		stats["cooldown"] *= float(source.get("cooldown", 1.0))
		stats["speed"] *= float(source.get("speed", 1.0))
		stats["regen"] += float(source.get("regen", 0.0))
	return stats

func apply_combat_stats(data: WeaponData) -> void:
	if data == null:
		return
	var stats := combat_stats()
	var damage_mult := float(stats.get("damage", 1.0))
	var fire_mult := float(stats.get("fire_rate", 1.0))
	data.damage = roundf(data.damage * damage_mult * 10.0) / 10.0
	if fire_mult > 0.0:
		data.shots_per_minute = roundf(data.shots_per_minute * fire_mult)
		data.heat_per_shot = data.heat_per_shot / fire_mult

# ---------------------------------------------------------------- persistence

func save_settings() -> void:
	var config := ConfigFile.new()
	config.set_value("input", "sensitivity", look_sensitivity)
	config.set_value("input", "invert_y", invert_look_y)
	config.set_value("input", "vibration", vibration_enabled)
	config.set_value("input", "ui_mode", input_ui_mode)
	config.set_value("input", "target_priority", target_priority)
	config.set_value("input", "dz_left", pad_deadzone_left)
	config.set_value("input", "dz_right", pad_deadzone_right)
	config.set_value("input", "diagnostics", input_diagnostics)
	config.set_value("audio", "volume", master_volume)
	config.set_value("audio", "music", music_volume)
	config.set_value("hud", "damage_numbers", damage_numbers)
	config.set_value("hud", "fps", fps_counter)
	config.set_value("graphics", "tier", selected_quality)
	config.set_value("graphics", "auto", quality_auto)
	config.set_value("world", "robot", selected_robot)
	config.set_value("hangar", "active_titan", active_titan)
	config.set_value("hangar", "palette", armor_palette)
	for robot_key in robot_palettes:
		config.set_value("hangar", "palette_" + String(robot_key),
				int(robot_palettes[robot_key]))
	config.set_value("hangar", "paints", unlocked_paints)
	config.set_value("economy", "silver", silver)
	config.set_value("economy", "gold", gold)
	config.set_value("economy", "parts", spare_parts)
	config.set_value("economy", "chips", microchips)
	config.set_value("economy", "modules", module_points)
	config.set_value("economy", "plat", platinum)
	config.set_value("economy", "memorium", memorium)
	config.set_value("economy", "grant_v11", true)
	config.set_value("economy", "grant_v16", true)
	config.set_value("economy", "grant_v16b", true)
	config.set_value("economy", "grant_v17", true)
	config.set_value("economy", "grant_v29", true)
	config.set_value("economy", "grant_v29b", true)
	config.set_value("economy", "strict_v18", true)
	config.set_value("economy", "drone_roster_v25", true)
	config.set_value("economy", "drone_roster_v35", true)
	for key in upgrades.keys():
		config.set_value("upgrade", String(key), upgrades[key] as Vector2i)
	for robot_id in loadouts.keys():
		var loadout: Array = loadouts[robot_id]
		config.set_value("loadout", String(robot_id), PackedStringArray(loadout))
	var pool := PackedStringArray()
	for item_id in inventory.keys():
		for count in int(inventory[item_id]):
			pool.append(String(item_id))
	config.set_value("hangar", "pool", pool)
	var owned_pack := PackedStringArray()
	for robot_id in owned_robots:
		owned_pack.append(String(robot_id))
	config.set_value("hangar", "owned", owned_pack)
	config.set_value("hangar", "owned_v16", true)
	for robot_id in pilot_assignments.keys():
		config.set_value("pilot", "assign:%s" % String(robot_id),
				String(pilot_assignments[robot_id]))
	config.set_value("pilot", "owned", PackedStringArray(owned_pilots))
	for pilot_id in pilots.keys():
		var state := pilots[pilot_id] as Dictionary
		var packed := PackedInt32Array([
				int(state.get("level", 1)), int(state.get("xp", 0)),
				int(state.get("tier", 1))])
		var skills := state.get("skills", []) as Array
		for index in 7:
			packed.append(int(skills[index]) if index < skills.size() else 0)
		config.set_value("pilot", String(pilot_id), packed)
	config.set_value("drone", "owned", PackedStringArray(owned_drones))
	config.set_value("drone", "active", selected_drone)
	config.set_value("drone", "pair_v26", true)
	for robot_id in drone_assignments.keys():
		config.set_value("drone", "assign:%s" % String(robot_id),
				String(drone_assignments[robot_id]))
	for drone_id in drone_levels.keys():
		config.set_value("drone", "lv:%s" % String(drone_id), int(drone_levels[drone_id]))
	for robot_id in specs.keys():
		var robot_specs := specs[robot_id] as Dictionary
		for node_id in robot_specs.keys():
			config.set_value("spec", "%s:%s" % [String(robot_id), String(node_id)],
					clampi(int(robot_specs[node_id]), 0, SPEC_MAX_RANK))
	config.save(SETTINGS_PATH)

func load_settings() -> void:
	var config := ConfigFile.new()
	if config.load(SETTINGS_PATH) != OK:
		return
	look_sensitivity = clampf(float(config.get_value("input", "sensitivity", 1.0)), 0.3, 2.5)
	invert_look_y = bool(config.get_value("input", "invert_y", false))
	vibration_enabled = bool(config.get_value("input", "vibration", true))
	input_ui_mode = clampi(int(config.get_value("input", "ui_mode", UiMode.AUTO)),
			0, UI_MODE_LABELS.size() - 1)
	target_priority = clampi(int(config.get_value("input", "target_priority", 0)),
			0, TARGET_PRIORITY_LABELS.size() - 1)
	pad_deadzone_left = clampf(float(config.get_value("input", "dz_left",
			DEADZONE_DEFAULT)), DEADZONE_MIN, DEADZONE_MAX)
	pad_deadzone_right = clampf(float(config.get_value("input", "dz_right",
			DEADZONE_DEFAULT)), DEADZONE_MIN, DEADZONE_MAX)
	input_diagnostics = bool(config.get_value("input", "diagnostics", false))
	master_volume = clampf(float(config.get_value("audio", "volume", 0.8)), 0.0, 1.0)
	music_volume = clampf(float(config.get_value("audio", "music", 0.7)), 0.0, 1.0)
	damage_numbers = bool(config.get_value("hud", "damage_numbers", true))
	fps_counter = bool(config.get_value("hud", "fps", false))
	quality_auto = bool(config.get_value("graphics", "auto", true))
	selected_quality = clampi(int(config.get_value("graphics", "tier", 2)), 0, 3)
	if quality_auto:
		selected_quality = clampi(Hardware.recommended_tier(), 0, 3)
	var robot_value := StringName(str(config.get_value("world", "robot", "SCARAB")))
	if ROBOT_DEFS.has(robot_value):
		selected_robot = robot_value
	active_titan = StringName(str(config.get_value("hangar", "active_titan", "")))
	if not ROBOT_DEFS.has(active_titan):
		active_titan = &""
	armor_palette = clampi(int(config.get_value("hangar", "palette", 0)), 0, PALETTE_COUNT - 1)
	robot_palettes.clear()
	for key in config.get_section_keys("hangar"):
		if String(key).begins_with("palette_"):
			var robot_key := String(key).substr(8)
			robot_palettes[robot_key] = clampi(
					int(config.get_value("hangar", key, 0)), 0, PALETTE_COUNT - 1)
	# Legacy single-palette saves: adopt it for the selected robot only, so
	# robots the player never painted keep the default instead of inheriting.
	if not robot_palettes.has(String(selected_robot)):
		robot_palettes[String(selected_robot)] = armor_palette
	armor_palette = palette_for(selected_robot)
	# Paint shop unlocks. Old saves never stored one: start free-only and
	# grandfather every palette already equipped on some robot.
	unlocked_paints.clear()
	var stored_paints: Variant = config.get_value("hangar", "paints", [0, 1])
	if stored_paints is Array:
		for paint_value in stored_paints:
			var paint_index := int(paint_value)
			if paint_index >= 0 and paint_index < PALETTE_COUNT \
					and not unlocked_paints.has(paint_index):
				unlocked_paints.append(paint_index)
	for palette_value in robot_palettes.values():
		var equipped_paint := int(palette_value)
		if not unlocked_paints.has(equipped_paint):
			unlocked_paints.append(equipped_paint)
	if not unlocked_paints.has(armor_palette):
		unlocked_paints.append(armor_palette)
	if unlocked_paints.is_empty():
		unlocked_paints.append(0)
	if config.has_section_key("hangar", "owned"):
		owned_robots = []
		var stored_owned := config.get_value("hangar", "owned", PackedStringArray()) as PackedStringArray
		for robot_id in stored_owned:
			var robot_name := StringName(robot_id)
			if ROBOT_DEFS.has(robot_name) and not owned_robots.has(robot_name):
				owned_robots.append(robot_name)
		if not owned_robots.has(ROBOT_SCARAB):
			owned_robots.insert(0, ROBOT_SCARAB)
	elif not bool(config.get_value("hangar", "owned_v16", false)):
		owned_robots = [ROBOT_SCARAB, ROBOT_VORTEX, ROBOT_RAMPART]
	if not owned_robots.has(ROBOT_SCARAB):
		owned_robots = [ROBOT_SCARAB]
	if not owns_robot(selected_robot):
		selected_robot = ROBOT_SCARAB
	silver = maxi(0, int(config.get_value("economy", "silver", 1000000000)))
	gold = maxi(0, int(config.get_value("economy", "gold", 1000000)))
	spare_parts = maxi(0, int(config.get_value("economy", "parts", 1000000)))
	microchips = maxi(0, int(config.get_value("economy", "chips", 500000)))
	module_points = maxi(0, int(config.get_value("economy", "modules", 500000)))
	platinum = maxi(0, int(config.get_value("economy", "plat", 500000)))
	memorium = maxi(0, int(config.get_value("economy", "memorium", 500000)))
	if not bool(config.get_value("economy", "grant_v11", false)):
		silver = maxi(silver, 1000000000)
		gold = maxi(gold, 1000000)
	if not bool(config.get_value("economy", "grant_v16", false)):
		spare_parts = maxi(spare_parts, 25000)
	if not bool(config.get_value("economy", "grant_v16b", false)):
		microchips = maxi(microchips, 1500)
		module_points = maxi(module_points, 40)
		platinum = maxi(platinum, 4000)
	if not bool(config.get_value("economy", "grant_v17", false)):
		spare_parts = maxi(spare_parts, 250000)
		microchips = maxi(microchips, 100000)
		module_points = maxi(module_points, 3000)
		platinum = maxi(platinum, 100000)
	if not bool(config.get_value("economy", "grant_v29", false)):
		spare_parts = maxi(spare_parts, 1000000)
		platinum = maxi(platinum, 500000)
	if not bool(config.get_value("economy", "grant_v29b", false)):
		# Resource floor pass: every non-silver/gold wallet at >= 500k
		# (memorium is new in this build) + the two new titan specialists.
		spare_parts = maxi(spare_parts, 1000000)
		microchips = maxi(microchips, 500000)
		module_points = maxi(module_points, 500000)
		platinum = maxi(platinum, 500000)
		memorium = maxi(memorium, 500000)
		for pair: Array in [
			["dorn", ROBOT_CITADEL], ["varga", ROBOT_RAVAGER],
		]:
			var pilot_id := String(pair[0])
			var robot_id := pair[1] as StringName
			if not owned_pilots.has(pilot_id):
				owned_pilots.append(pilot_id)
			if not pilots.has(pilot_id):
				pilots[pilot_id] = {"level": 21, "xp": 0, "tier": 1,
						"skills": [0, 0, 0, 0, 0, 0, 0]}
			if not pilot_assignments.has(robot_id):
				pilot_assignments[robot_id] = pilot_id
	_strict_ownership = bool(config.get_value("economy", "strict_v18", false))
	if config.has_section("upgrade"):
		for key in config.get_section_keys("upgrade"):
			var state: Variant = config.get_value("upgrade", key, Vector2i(1, 1))
			if state is Vector2i:
				# Titan ladders run to lv150; per-key caps are applied on read by
				# upgrade_state() once the loadout tells us which ladder it is.
				upgrades[key] = Vector2i(
						clampi(state.x, 1, MK_MAX), clampi(state.y, 1, LV_MAX_TITAN))
	for robot_id in ROBOT_DEFS.keys():
		var stored: Variant = config.get_value("loadout", String(robot_id), null)
		if stored is PackedStringArray:
			var loadout: Array = []
			var slots: Array = robot_slots(robot_id)
			for index in slots.size():
				var item := ""
				if index < stored.size():
					item = String(stored[index])
				if not item.is_empty() and item_slot_size(item) != slots[index]:
					item = ""
				loadout.append(item)
			loadouts[robot_id] = loadout
	for robot_id in ROBOT_DEFS.keys():
		var loaded := loadouts.get(robot_id, []) as Array
		var has_item := false
		for item in loaded:
			if String(item) != "":
				has_item = true
				break
		if not has_item:
			loadouts[robot_id] = _default_loadout(robot_id)
	if config.has_section_key("hangar", "pool"):
		inventory = {}
		var pool := config.get_value("hangar", "pool") as PackedStringArray
		for item_id in pool:
			inventory[item_id] = pool_count(item_id) + 1
	for item_id in ALL_ITEM_IDS:
		if not inventory.has(item_id):
			inventory[item_id] = 2
	if config.has_section("pilot"):
		for key in config.get_section_keys("pilot"):
			var value: Variant = config.get_value("pilot", key, null)
			if key == "owned" and value is PackedStringArray:
				var loaded_pilots: Array[String] = []
				for pilot_id in value as PackedStringArray:
					if not pilot_def(String(pilot_id)).is_empty() \
							and not loaded_pilots.has(String(pilot_id)):
						loaded_pilots.append(String(pilot_id))
				if not loaded_pilots.is_empty():
					owned_pilots = loaded_pilots
			elif key.begins_with("assign:"):
				if value is String and not String(value).is_empty():
					pilot_assignments[StringName(key.trim_prefix("assign:"))] = String(value)
			elif value is PackedInt32Array:
				var arr := value as PackedInt32Array
				if arr.size() >= 3:
					var skills: Array = []
					for index in range(3, arr.size()):
						skills.append(int(arr[index]))
					while skills.size() < 7:
						skills.append(0)
					pilots[key] = {
							"level": clampi(int(arr[0]), 1, PILOT_MAX_LEVEL),
							"xp": maxi(0, int(arr[1])),
							"tier": clampi(int(arr[2]), 1, 4),
							"skills": skills,
					}
	# A pilot already sitting in a hangar slot must count as owned, whatever
	# version of the save wrote the assignment.
	for robot_id in pilot_assignments.keys():
		var assigned := String(pilot_assignments[robot_id])
		if not assigned.is_empty() and not owned_pilots.has(assigned):
			owned_pilots.append(assigned)
	if config.has_section("drone"):
		var loaded_owned := config.get_value("drone", "owned", PackedStringArray(["wisp"])) as PackedStringArray
		owned_drones = []
		for drone_id in loaded_owned:
			if not drone_def(String(drone_id)).is_empty() and not owned_drones.has(String(drone_id)):
				owned_drones.append(String(drone_id))
		if owned_drones.is_empty():
			owned_drones = ["wisp"]
		selected_drone = String(config.get_value("drone", "active", "wisp"))
		for key in config.get_section_keys("drone"):
			if key.begins_with("lv:"):
				var drone_id := key.trim_prefix("lv:")
				if owns_drone(drone_id):
					drone_levels[drone_id] = clampi(int(config.get_value("drone", key, 1)), 1, DRONE_MAX_LEVEL)
			elif key.begins_with("assign:"):
				var assigned_robot := StringName(key.trim_prefix("assign:"))
				if ROBOT_DEFS.has(assigned_robot):
					var assigned_drone := String(config.get_value("drone", key, ""))
					if owns_drone(assigned_drone):
						drone_assignments[assigned_robot] = assigned_drone
		if not owns_drone(selected_drone):
			selected_drone = owned_drones[0]
	for drone_id in owned_drones:
		if not drone_levels.has(drone_id):
			drone_levels[drone_id] = 1
	if not bool(config.get_value("economy", "drone_roster_v25", false)):
		for definition in DRONE_DEFS:
			var roster_id := String(definition.get("id", ""))
			if not owned_drones.has(roster_id):
				owned_drones.append(roster_id)
			if not drone_levels.has(roster_id):
				drone_levels[roster_id] = 1
		var pair_map := {
			ROBOT_SCARAB: "wisp", ROBOT_VORTEX: "kestrel",
			ROBOT_RAMPART: "bulwark", ROBOT_PRAETOR: "",
			ROBOT_CITADEL: "", ROBOT_RAVAGER: "",
		}
		for robot_id in ROBOT_ORDER:
			if not drone_assignments.has(robot_id):
				drone_assignments[robot_id] = String(pair_map.get(robot_id, "wisp"))
		_sync_pool_to_loadouts()
	# v0.35: grant the WR 12.3/12.4 specialist drones to older saves too.
	if not bool(config.get_value("economy", "drone_roster_v35", false)):
		for definition in DRONE_DEFS:
			var roster_id := String(definition.get("id", ""))
			if not owned_drones.has(roster_id):
				owned_drones.append(roster_id)
			if not drone_levels.has(roster_id):
				drone_levels[roster_id] = 1
	# v0.26: one-time re-pair so every chassis runs a different drone and the
	# titan runs none. Only rewrites saves written before this release.
	if not bool(config.get_value("drone", "pair_v26", false)):
		var pair_v26 := {
			ROBOT_SCARAB: "wisp", ROBOT_VORTEX: "kestrel",
			ROBOT_RAMPART: "bulwark", ROBOT_PRAETOR: "",
			ROBOT_CITADEL: "", ROBOT_RAVAGER: "",
		}
		for robot_id in ROBOT_ORDER:
			drone_assignments[robot_id] = String(pair_v26.get(robot_id, "wisp"))
		if not owns_drone(selected_drone):
			selected_drone = "wisp"
	if config.has_section("spec"):
		for key in config.get_section_keys("spec"):
			var parts := key.split(":", false, 1)
			if parts.size() != 2:
				continue
			var robot_id := StringName(parts[0])
			if not ROBOT_DEFS.has(robot_id):
				continue
			if not specs.has(robot_id):
				specs[robot_id] = {}
			var robot_specs := specs[robot_id] as Dictionary
			robot_specs[parts[1]] = clampi(int(config.get_value("spec", key, 0)), 0, SPEC_MAX_RANK)
	for definition in PILOT_DEFS:
		ensure_pilot(String(definition.get("id", "")))
	for robot_id in ROBOT_DEFS.keys():
		var pilot_id := assigned_pilot(robot_id)
		if not pilot_id.is_empty() and pilot_def(pilot_id).is_empty():
			pilot_assignments.erase(robot_id)
