extends Node

# Deadzones are per-stick, RADIAL and rescaled (see _radial_deadzone): a
# scalar per-axis cut leaves a 0..0.18 jump when the stick leaves the zone,
# which is exactly what reads as "the robot drifts / snaps on its own".
# The values themselves are live settings (GameState.pad_deadzone_left /
# _right, 0.05 .. 0.30, default 0.15).
const DEADZONE_MIN := 0.05
const DEADZONE_MAX := 0.30
# Residual gate for the COMBINED vector only (keyboard + pad + touch). Real
# deadzoning happens per stick; this just swallows float dust so a stick
# that is exactly at rest cannot creep the robot forward.
const COMBINED_EPSILON := 0.02
# Gamepad axes are polled raw and re-centred here instead of being bound to
# the move actions: a wireless pad that never reports a neutral centre (or
# that SDL maps to the wrong physical axis) otherwise holds `move_back`
# pressed forever and the robot drives itself around the arena.
const PAD_CAL_FRAMES := 20
const PAD_TRIGGER_ARM := 0.25
const PAD_TRIGGER_FIRE := 0.5
# Trigger travel that must be observed before a press can be measured — a
# jittering axis at rest must never count as a pull.
const PAD_TRIGGER_TRAVEL := 0.4

var move_vector: Vector2 = Vector2.ZERO
var look_delta: Vector2 = Vector2.ZERO
var fire_held: bool = false
var group_held: Array[bool] = [false, false]
var slot_held: Array[bool] = [false, false, false, false]
var ability_requested: bool = false
var secondary_ability_requested: bool = false
var camera_sensitivity: float = 1.0
var invert_look_y: bool = false
var look_touch_index: int = -1
var pad_connected: bool = false
# Live deadzones (pushed from GameState.apply_settings).
var pad_deadzone_left: float = 0.15
var pad_deadzone_right: float = 0.15

var _virtual_move: Vector2 = Vector2.ZERO
var _virtual_fire: bool = false
var _virtual_group: Array[bool] = [false, false]
var _virtual_slot: Array[bool] = [false, false, false, false]
var _gamepad_trigger_fire: bool = false
var _actions_ready: bool = false
var _mouse_look: bool = false
# Mouse fire is tracked by EVENT, never by Input.is_action_pressed: only an
# LMB press that no Control consumed counts, so clicking a HUD/menu button
# can no longer also fire the guns (spec phase 9: one event, one action).
var _mouse_fire: bool = false
# A pressed ScreenTouch seen since the start of this frame. Godot always
# dispatches the EMULATED twin of an input before the event that produced it,
# so for one frame the pair reads:
#   real mouse press -> [Touch twin, LMB source]   (twin seen first)
#   finger press     -> [LMB twin,  Touch source]  (twin seen first)
# That ordering is the only way to tell the two apart — _mouse_fire must
# follow the mouse and never the finger.
var _touch_twin_seen: bool = false
var _pad_device: int = -1
var _pad_rest: Vector4 = Vector4.ZERO
var _pad_rest_trigger: float = 0.0
var _pad_trigger_low: float = 1.0
var _pad_trigger_high: float = -1.0
var _pad_samples: int = 0
var _pad_calibrated: bool = false
var _pad_trigger_armed: bool = false
# Normalised (0..1) press amount of the fire trigger after rest correction.
var _pad_trigger_value: float = 0.0

func _ready() -> void:
	# Detect touch / keyboard / gamepad before any scene is built.
	PlatformUtil.init()
	_define_actions()
	pad_connected = not Input.get_connected_joypads().is_empty()
	Input.joy_connection_changed.connect(_on_joy_connection)

func _on_joy_connection(device: int, connected: bool) -> void:
	pad_connected = connected or not Input.get_connected_joypads().is_empty()
	Events.gamepad_connection_changed.emit(device, connected)
	if pad_connected:
		PlatformUtil.set_mode(PlatformUtil.InputMode.GAMEPAD)
	elif PlatformUtil.current_mode == PlatformUtil.InputMode.GAMEPAD:
		# Last pad unplugged: fall back to whatever the platform now says.
		PlatformUtil.set_mode(PlatformUtil.detect_mode())
	# Re-centre on the (new) device before reading any axis from it.
	_reset_pad_state()

func _reset_pad_state() -> void:
	_pad_device = -1
	_pad_rest = Vector4.ZERO
	_pad_rest_trigger = 0.0
	_pad_trigger_low = 1.0
	_pad_trigger_high = -1.0
	_pad_samples = 0
	_pad_calibrated = false
	_pad_trigger_armed = false
	_pad_trigger_value = 0.0
	_gamepad_trigger_fire = false
	# Unplug mid-frame must not leave a ghost: the last stick reading would
	# otherwise be re-used by the next consumers (a camera kick, a drift).
	move_vector = Vector2.ZERO
	look_delta = Vector2.ZERO
	look_touch_index = -1

func _define_actions() -> void:
	if _actions_ready:
		return
	_actions_ready = true
	# No JoypadMotion bindings on the move actions: left-stick movement is
	# polled directly (with a rest-centre) so a mis-centred wireless pad can
	# never masquerade as a held key.
	_add_action("move_forward", [KEY_W, KEY_UP], [], [JOY_BUTTON_DPAD_UP])
	_add_action("move_back", [KEY_S, KEY_DOWN], [], [JOY_BUTTON_DPAD_DOWN])
	_add_action("move_left", [KEY_A, KEY_LEFT], [], [JOY_BUTTON_DPAD_LEFT])
	_add_action("move_right", [KEY_D, KEY_RIGHT], [], [JOY_BUTTON_DPAD_RIGHT])
	# MOUSE_BUTTON_LEFT is deliberately NOT bound here. The mouse is handled
	# as its own event stream (see _mouse_fire) so that a press a Control
	# already consumed — a HUD button, a menu card — cannot also fire the
	# weapons. Keyboard and pad stay on the shared action.
	_add_action("fire", [KEY_SPACE], [], [JOY_BUTTON_A])
	_add_action("weapon_1", [KEY_1], [], [JOY_BUTTON_LEFT_SHOULDER])
	_add_action("weapon_2", [KEY_2], [], [JOY_BUTTON_RIGHT_SHOULDER])
	_add_action("ability", [KEY_SHIFT, KEY_Q], [], [JOY_BUTTON_B])
	_add_action("secondary_ability", [KEY_E], [], [JOY_BUTTON_X])
	_add_action("lock_cycle", [KEY_T], [], [JOY_BUTTON_Y])
	_add_action("toggle_camera", [KEY_V])
	_add_action("restart", [KEY_R])
	_add_action("pause", [KEY_ESCAPE], [], [JOY_BUTTON_START, JOY_BUTTON_BACK])
	_add_joy_binding(&"ui_accept", JOY_BUTTON_A)
	_add_joy_binding(&"ui_cancel", JOY_BUTTON_BACK)
	# Console convention: B closes menus / pause. While the tree is paused
	# InputRouter itself is frozen, so it can never re-fire combat "ability".
	_add_joy_binding(&"ui_cancel", JOY_BUTTON_B)

func _add_joy_binding(action: StringName, button: JoyButton) -> void:
	if not InputMap.has_action(action):
		return
	for event in InputMap.action_get_events(action):
		if event is InputEventJoypadButton \
				and (event as InputEventJoypadButton).button_index == button:
			return
	var joy := InputEventJoypadButton.new()
	joy.button_index = button
	InputMap.action_add_event(action, joy)

func _add_action(action: StringName, keys: Array, axes: Array = [], buttons: Array = [],
		mouse_buttons: Array = []) -> void:
	if InputMap.has_action(action):
		InputMap.action_erase_events(action)
	else:
		InputMap.add_action(action, 0.2)
	for key in keys:
		var event := InputEventKey.new()
		event.physical_keycode = key
		InputMap.action_add_event(action, event)
	for axis_data in axes:
		var event := InputEventJoypadMotion.new()
		event.axis = axis_data[0]
		event.axis_value = axis_data[1]
		InputMap.action_add_event(action, event)
	for button in buttons:
		var event := InputEventJoypadButton.new()
		event.button_index = button
		InputMap.action_add_event(action, event)
	for mouse_button in mouse_buttons:
		var event := InputEventMouseButton.new()
		event.button_index = mouse_button
		InputMap.action_add_event(action, event)

func _process(delta: float) -> void:
	var pad_move := _poll_gamepad(delta)
	# Radial deadzone with rescale, per stick — keyboard and the touch stick
	# are digital/explicitly zeroed upstream, so they pass through untouched.
	pad_move = _radial_deadzone(pad_move, pad_deadzone_left)
	var stick := Vector2(Input.get_action_strength(&"move_right") - Input.get_action_strength(&"move_left"),
			Input.get_action_strength(&"move_forward") - Input.get_action_strength(&"move_back"))
	var combined := stick + pad_move + _virtual_move
	if combined.length() < COMBINED_EPSILON:
		combined = Vector2.ZERO
	else:
		combined = combined.limit_length(1.0)
	move_vector = combined
	# Belt-and-braces: a release that slipped through (window unfocused mid
	# drag, tree paused for a frame) must not leave the guns stuck on.
	if _mouse_fire and not Input.is_mouse_button_pressed(MOUSE_BUTTON_LEFT):
		_mouse_fire = false
	fire_held = Input.is_action_pressed(&"fire") or _mouse_fire \
			or _virtual_fire or _gamepad_trigger_fire
	# All of this frame's events are in; the twin ordering starts fresh.
	_touch_twin_seen = false
	group_held[0] = Input.is_action_pressed(&"weapon_1") or _virtual_group[0]
	group_held[1] = Input.is_action_pressed(&"weapon_2") or _virtual_group[1]
	for index in slot_held.size():
		slot_held[index] = _virtual_slot[index]

# Raw poll of the first connected pad. The first PAD_CAL_FRAMES samples are
# averaged into a per-device rest centre, so a pad whose "neutral" is not
# (0, 0) — typical of cheap wireless pads before their first axis report, or
# of a mis-mapped SDL layout — still reads as "not touched" at rest.
# Returns a deadzoned move vector (forward = +y).
func _poll_gamepad(delta: float) -> Vector2:
	var joy := Input.get_connected_joypads()
	if joy.is_empty():
		if _pad_device != -1 or _pad_calibrated:
			_reset_pad_state()
		return Vector2.ZERO
	var device := joy[0]
	if device != _pad_device:
		_reset_pad_state()
		_pad_device = device
	var left := Vector2(Input.get_joy_axis(device, JOY_AXIS_LEFT_X),
			Input.get_joy_axis(device, JOY_AXIS_LEFT_Y))
	var right := Vector2(Input.get_joy_axis(device, PlatformUtil.PAD_LOOK_AXIS_X),
			Input.get_joy_axis(device, PlatformUtil.PAD_LOOK_AXIS_Y))
	var trigger := Input.get_joy_axis(device, PlatformUtil.PAD_TRIGGER_FIRE_AXIS)
	if not _pad_calibrated:
		_pad_rest += Vector4(left.x, left.y, right.x, right.y)
		_pad_rest_trigger += trigger
		_pad_trigger_low = minf(_pad_trigger_low, trigger)
		_pad_samples += 1
		if _pad_samples < PAD_CAL_FRAMES:
			return Vector2.ZERO
		_pad_rest /= float(_pad_samples)
		_pad_rest_trigger /= float(_pad_samples)
		_pad_calibrated = true
		_pad_trigger_low = _pad_rest_trigger
		_pad_trigger_high = _pad_rest_trigger
		# Only trust the fire trigger if it has been seen near its own rest:
		# an inverted or stuck trigger would otherwise hold fire forever.
		_pad_trigger_armed = _pad_trigger_low <= PAD_TRIGGER_ARM
		print("INPUT pad %s rest=(%.3f %.3f | %.3f %.3f) trigger=%.3f armed=%s" % [
				Input.get_joy_name(device), _pad_rest.x, _pad_rest.y,
				_pad_rest.z, _pad_rest.w, _pad_rest_trigger,
				str(_pad_trigger_armed)])
		return Vector2.ZERO
	# --- trigger -------------------------------------------------------
	# Platforms disagree on where a trigger rests (-1, 0, or the far end of
	# an inverted axis), so the fire threshold is a FRACTION OF THE OBSERVED
	# TRAVEL rather than a raw axis value. The release gate stays on the raw
	# axis, which fails safe: an inverted axis simply never arms.
	_pad_trigger_low = minf(_pad_trigger_low, trigger)
	_pad_trigger_high = maxf(_pad_trigger_high, trigger)
	var travel := _pad_trigger_high - _pad_trigger_low
	if travel >= PAD_TRIGGER_TRAVEL:
		_pad_trigger_value = clampf((trigger - _pad_trigger_low) / travel, 0.0, 1.0)
	else:
		_pad_trigger_value = 0.0
	if trigger <= PAD_TRIGGER_ARM:
		_pad_trigger_armed = true
	_gamepad_trigger_fire = _pad_trigger_armed and _pad_trigger_value > PAD_TRIGGER_FIRE
	# --- sticks --------------------------------------------------------
	# Raw, rest-corrected deltas: the radial deadzone (with its rescale) is
	# applied by the caller so left and right keep independent settings.
	var move := Vector2(_pad_wrap(left.x - _pad_rest.x),
			-_pad_wrap(left.y - _pad_rest.y))
	var look := _radial_deadzone(
			Vector2(_pad_wrap(right.x - _pad_rest.z),
					_pad_wrap(right.y - _pad_rest.w)),
			pad_deadzone_right)
	if look.x != 0.0:
		look_delta.x += look.x * 2.6 * delta * camera_sensitivity
	if look.y != 0.0:
		look_delta.y += look.y * 2.6 * delta * camera_sensitivity \
				* (-1.0 if invert_look_y else 1.0)
	return move

static func _pad_wrap(value: float) -> float:
	# Axis deltas that cross the -1/1 seam (pad resting near an extreme).
	if value > 1.0:
		return value - 2.0
	if value < -1.0:
		return value + 2.0
	return value

# Radial (vector) deadzone with a rescaled exit: everything inside the
# circle is zero, everything outside is remapped to 0..1 so input ramps
# smoothly out of the dead zone instead of jumping by the radius.
func _radial_deadzone(value: Vector2, deadzone: float) -> Vector2:
	var dz := clampf(deadzone, DEADZONE_MIN, DEADZONE_MAX)
	var magnitude := value.length()
	if magnitude <= dz or magnitude <= 0.0001:
		return Vector2.ZERO
	return value * ((minf(magnitude, 1.0) - dz) / (1.0 - dz) / magnitude)

func _physics_process(_delta: float) -> void:
	if Input.is_action_just_pressed(&"ability") or ability_requested:
		ability_requested = false
		Events.ability_requested.emit()
	if Input.is_action_just_pressed(&"secondary_ability") or secondary_ability_requested:
		secondary_ability_requested = false
		Events.secondary_ability_requested.emit()
	if Input.is_action_just_pressed(&"lock_cycle"):
		Events.lock_cycle_requested.emit()

func _input(event: InputEvent) -> void:
	# Observe only (never consumed): this runs before GUI input, so events a
	# Control handles still count toward the live input mode.
	PlatformUtil.observe_event(event)
	# Releases are read pre-GUI so they can never be swallowed by a Control
	# that happens to sit under the cursor when the button comes up — a
	# swallowed release is exactly how "the robot keeps firing by itself".
	if event is InputEventScreenTouch:
		if (event as InputEventScreenTouch).pressed:
			_touch_twin_seen = true
	elif event is InputEventMouseButton:
		var button := event as InputEventMouseButton
		if button.button_index == MOUSE_BUTTON_LEFT and not button.pressed:
			_mouse_fire = false

func _unhandled_input(event: InputEvent) -> void:
	# emulate_touch_from_mouse turns every desktop click into a ScreenTouch;
	# only a live touch rig may read those for look. Otherwise any mouse drag
	# (or click on a HUD button) swings the camera while the fire button is
	# also held — the "robot plays itself" bug on the Windows build.
	var touch_live := PlatformUtil.effective_mode() == PlatformUtil.InputMode.TOUCH
	if event is InputEventScreenTouch:
		if not touch_live:
			look_touch_index = -1
			return
		var touch := event as InputEventScreenTouch
		if touch.pressed:
			if look_touch_index == -1 and touch.position.x > get_viewport().get_visible_rect().size.x * 0.35:
				look_touch_index = touch.index
		elif touch.index == look_touch_index:
			look_touch_index = -1
	elif event is InputEventScreenDrag:
		if not touch_live:
			return
		var drag := event as InputEventScreenDrag
		if drag.index == look_touch_index:
			_add_look(drag.relative)
	elif event is InputEventMouseButton:
		var mouse := event as InputEventMouseButton
		if mouse.button_index == PlatformUtil.MOUSE_LOOK_BUTTON:
			_set_mouse_look(mouse.pressed)
		elif mouse.button_index == MOUSE_BUTTON_LEFT and mouse.pressed:
			# Reaching _unhandled_input means no Control took the click, so
			# this press is a genuine "shoot at the world" gesture. Clicks on
			# HUD/menu buttons are consumed upstream and never set this.
			# But: emulate_mouse_from_touch hands us an LMB twin for EVERY
			# finger press, and it arrives BEFORE its ScreenTouch source —
			# which is why touching anywhere (and every PASS-filter wheel
			# button) used to fire the guns on its own. Ignore that twin; on
			# touch, firing is TouchControls' FIRE button and nothing else.
			if Input.is_emulating_mouse_from_touch():
				if Input.is_emulating_touch_from_mouse():
					if not _touch_twin_seen:
						return
				elif PlatformUtil.effective_mode() == PlatformUtil.InputMode.TOUCH:
					return
			_mouse_fire = true
	elif event is InputEventMouseMotion:
		if _mouse_look:
			_add_look((event as InputEventMouseMotion).relative)
	elif event is InputEventJoypadButton:
		var joy := event as InputEventJoypadButton
		# Pad B doubles as "back" outside of combat (combat B = ability).
		if joy.pressed and joy.button_index == JOY_BUTTON_B \
				and GameState.phase != GameState.Phase.COMBAT:
			Events.ui_back_requested.emit()

func _set_mouse_look(enabled: bool) -> void:
	if enabled == _mouse_look:
		return
	_mouse_look = enabled
	if not PlatformUtil.is_desktop():
		return
	Input.mouse_mode = Input.MOUSE_MODE_CAPTURED if enabled else Input.MOUSE_MODE_VISIBLE

func _notification(what: int) -> void:
	# Focus loss while dragging look must not leave the cursor captured.
	if what == NOTIFICATION_WM_WINDOW_FOCUS_OUT and _mouse_look:
		_set_mouse_look(false)
	if what == NOTIFICATION_WM_WINDOW_FOCUS_OUT:
		_mouse_fire = false
		_gamepad_trigger_fire = false

func _add_look(relative: Vector2) -> void:
	var scaled := relative / 420.0 * camera_sensitivity
	look_delta.x += scaled.x
	look_delta.y += scaled.y * (-1.0 if invert_look_y else 1.0)

func consume_look() -> Vector2:
	var value := look_delta
	look_delta = Vector2.ZERO
	return value

# Development-only one-liner for the input diagnostics overlay: every input
# source the router currently believes in, plus the live deadzones. Shown
# only when GameState.input_diagnostics is on AND this is a debug build.
func input_snapshot() -> String:
	var pad_text := "IDLE"
	if pad_connected:
		pad_text = "CAL" if not _pad_calibrated \
				else "TRG %.2f" % _pad_trigger_value
	var bits := PackedStringArray([
		"SRC %s" % PlatformUtil.mode_label(),
		"MV %.2f/%.2f" % [move_vector.x, move_vector.y],
		"FIRE %d%d%d%d" % [
			1 if Input.is_action_pressed(&"fire") else 0,
			1 if _mouse_fire else 0,
			1 if _virtual_fire else 0,
			1 if _gamepad_trigger_fire else 0],
		"PAD %s" % pad_text,
		"DZ %.2f/%.2f" % [pad_deadzone_left, pad_deadzone_right],
	])
	return "  ".join(bits)

func set_virtual_move(value: Vector2) -> void:
	_virtual_move = value.limit_length(1.0)

func set_virtual_fire(value: bool) -> void:
	_virtual_fire = value

func set_virtual_group(index: int, value: bool) -> void:
	if index >= 0 and index < _virtual_group.size():
		_virtual_group[index] = value

func set_virtual_slot(index: int, value: bool) -> void:
	if index >= 0 and index < _virtual_slot.size():
		_virtual_slot[index] = value

func request_ability() -> void:
	ability_requested = true

func request_secondary_ability() -> void:
	secondary_ability_requested = true

func clear_temporary() -> void:
	_virtual_move = Vector2.ZERO
	_virtual_fire = false
	_virtual_group[0] = false
	_virtual_group[1] = false
	for index in _virtual_slot.size():
		_virtual_slot[index] = false
	ability_requested = false
	secondary_ability_requested = false
	_gamepad_trigger_fire = false
	_mouse_fire = false
	_touch_twin_seen = false
	_set_mouse_look(false)
	look_delta = Vector2.ZERO
	look_touch_index = -1