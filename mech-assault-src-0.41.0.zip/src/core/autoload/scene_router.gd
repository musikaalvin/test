extends Node

const MENU_SCENE := "res://scenes/main_menu.tscn"
const GAME_SCENE := "res://scenes/game.tscn"

# Quiet-moment warm-up list: heavy match content requested in the background
# while the menu sits idle (and again while the loading screen is up), then
# parked in AssetLibrary so the arena build reads it from the resource cache
# instead of from disk.
const WARM_PATHS: Array[String] = [
	GAME_SCENE,
	"res://assets/models/ruins/glb/CathedralRuins_01.glb",
	"res://assets/textures/pbr/forest_ground/albedo.jpg",
	"res://assets/textures/pbr/forest_ground/normal.jpg",
	"res://assets/textures/pbr/rock/albedo.jpg",
	"res://assets/textures/pbr/rock/normal.jpg",
	"res://assets/textures/pbr/asphalt/albedo.jpg",
	"res://assets/textures/pbr/asphalt/normal.jpg",
]

# Progress bands. Every one of them reports work that has actually finished -
# there are no timers and no interpolation over wall-clock time anywhere in
# this state machine.
const WEIGHT_THREAD := 0.7		# threaded ResourceLoader progress	0 -> 70%
const WEIGHT_BUILD := 0.9		# instantiate + arena build done	70 -> 90%
const DEPLOY_FRAMES := 4		# player spawned + first frames		90 -> 100%

const STAGE_THREAD := 0
const STAGE_BUILD := 1
const STAGE_DEPLOY := 2
const STAGE_LIMIT := 600		# frames a stage may sit still before giving up
const CLEANUP_DELAY := 2		# frames after the menu swap before cache clear

var _switching: bool = false

var _loading: LoadingScreen = null
var _load_active: bool = false
var _load_path: String = ""
var _load_stage: int = STAGE_THREAD
var _load_wait: int = 0
var _deploy_frames: int = 0
var _previous_scene: Node = null
var _pending_packed: PackedScene = null

var _cleanup_pending: bool = false
var _cleanup_delay: int = 0
var _warm_pending: PackedStringArray = PackedStringArray()


func goto_menu() -> void:
	# A switch is already in flight (e.g. TO BATTLE mid-load): _change() would
	# be a no-op, so do not schedule the cache clear either - clearing while a
	# match is still spinning up would just throw its cache away.
	if _switching:
		return
	_change(MENU_SCENE)
	if _switching:
		_cleanup_pending = true
		_cleanup_delay = CLEANUP_DELAY


func goto_game() -> void:
	_change_with_loading(GAME_SCENE)


func restart_match() -> void:
	_change_with_loading(GAME_SCENE)


func quit_game() -> void:
	get_tree().quit()


func _process(_delta: float) -> void:
	if _load_active:
		_tick_loading()
	_tick_warm()
	_tick_cleanup()


func _change(scene_path: String) -> void:
	if _switching:
		return
	if not ResourceLoader.exists(scene_path):
		push_error("SceneRouter: missing scene %s" % scene_path)
		return
	_switching = true
	var error := get_tree().change_scene_to_file(scene_path)
	if error != OK:
		push_error("SceneRouter: change_scene_to_file failed with %d" % error)
		_switching = false
	else:
		_arm_switch_guard_clear()


# Switch into the match behind a loading overlay. The guard stays raised for
# the whole transition and is released through the same one-shot process_frame
# connection _change() uses, so the switch is still one frame wide.
func _change_with_loading(scene_path: String) -> void:
	if _switching:
		return
	if not ResourceLoader.exists(scene_path):
		push_error("SceneRouter: missing scene %s" % scene_path)
		return
	_switching = true
	_cleanup_pending = false
	_load_path = scene_path
	_load_stage = STAGE_THREAD
	_load_wait = 0
	_deploy_frames = 0
	_previous_scene = get_tree().current_scene
	# This switch owns the path now, so stop polling it as a warm-up. An
	# already-running warm task is reused - the subsequent get_status() sees it
	# instead of starting a second load of the same resource.
	_drop_warm_path(scene_path)
	if not AssetLibrary.is_held(scene_path) and DisplayServer.get_name() != "headless":
		ResourceLoader.load_threaded_request(scene_path)
	_loading = LoadingScreen.new()
	_loading.name = "LoadingScreen"
	get_tree().root.add_child(_loading)
	_load_active = true
	_loading.set_progress(0.0, "LOADING ASSETS")
	process_mode = Node.PROCESS_MODE_ALWAYS
	# Arena props and PBR maps stream in alongside the scene load.
	_warm_assets()


func _tick_loading() -> void:
	if not is_instance_valid(_loading):
		# Overlay freed from under us: drop the guard rather than deadlock.
		_release_overlay()
		_switching = false
		return
	_load_wait += 1
	match _load_stage:
		STAGE_THREAD:
			_tick_thread_stage()
		STAGE_BUILD:
			_tick_build_stage()
		STAGE_DEPLOY:
			_tick_deploy_stage()
	if _load_wait > STAGE_LIMIT:
		if _load_stage == STAGE_DEPLOY:
			push_warning("SceneRouter: deploy milestones timed out, releasing overlay")
			_finish_loading()
		else:
			push_error("SceneRouter: stuck on stage %d for %s" % [
					_load_stage, _load_path])
			_abort_loading()


# 0 -> 70%. Polls the threaded task every frame; a resident scene or a failed
# task both resolve to the build stage through real, completed work.
func _tick_thread_stage() -> void:
	var cached := AssetLibrary.held_resource(_load_path) as PackedScene
	if cached != null:
		_enter_build(cached)
		return
	if DisplayServer.get_name() == "headless":
		# Dummy renderer: no worker-thread path, load directly instead.
		_direct_build()
		return
	var progress: Array = []
	var status := ResourceLoader.load_threaded_get_status(_load_path, progress)
	match status:
		ResourceLoader.THREAD_LOAD_IN_PROGRESS:
			var ratio := 0.0
			if not progress.is_empty():
				ratio = clampf(float(progress[0]), 0.0, 1.0)
			_loading.set_progress(ratio * WEIGHT_THREAD, "LOADING ASSETS")
		ResourceLoader.THREAD_LOAD_LOADED:
			var packed := ResourceLoader.load_threaded_get(_load_path) as PackedScene
			if packed == null:
				_direct_build()
				return
			_enter_build(packed)
		_:
			# THREAD_LOAD_FAILED / THREAD_LOAD_INVALID_RESOURCE / no task.
			_direct_build()


func _direct_build() -> void:
	var packed := load(_load_path) as PackedScene
	if packed == null:
		push_error("SceneRouter: could not load %s" % _load_path)
		_abort_loading()
		return
	_enter_build(packed)


# Hands the PackedScene to the same engine swap _change() uses, but on the
# following frame: the label is written first so the BUILDING frame is the one
# actually drawn before the synchronous arena build blocks the thread.
func _enter_build(packed: PackedScene) -> void:
	_loading.set_progress(WEIGHT_THREAD, "BUILDING OPEN REALM")
	_pending_packed = packed
	_load_stage = STAGE_BUILD
	_load_wait = 0


# 70 -> 90%. Frame one starts the swap; later frames wait for it to be
# observable - the old scene is still current until the engine has freed it and
# installed the new instance.
func _tick_build_stage() -> void:
	if _pending_packed != null:
		var packed := _pending_packed
		_pending_packed = null
		var error := get_tree().change_scene_to_packed(packed)
		if error != OK:
			push_error("SceneRouter: change_scene_to_packed failed with %d" % error)
			_abort_loading()
		return
	var current := get_tree().current_scene
	if current == null or current == _previous_scene:
		return
	_loading.set_progress(WEIGHT_BUILD, "DEPLOYING")
	_load_stage = STAGE_DEPLOY
	_deploy_frames = 0
	_load_wait = 0


# 90 -> 100%. Milestones: session in tree, Player node present, grounded
# respawn_point written by GameSession._finish_spawn, then a few real frames
# of the running scene.
func _tick_deploy_stage() -> void:
	_deploy_frames += 1
	var ratio := WEIGHT_BUILD
	var session := get_tree().current_scene
	if session != null:
		ratio = 0.93
		var player := session.get_node_or_null("Player") as Node3D
		if player != null:
			ratio = 0.96
			var spawn: Variant = player.get("respawn_point")
			if spawn is Vector3 and (spawn as Vector3).length_squared() > 0.25:
				ratio = lerpf(0.96, 1.0, clampf(
						float(_deploy_frames) / float(DEPLOY_FRAMES), 0.0, 1.0))
	_loading.set_progress(ratio, "DEPLOYING")
	if ratio >= 1.0:
		_finish_loading()


func _finish_loading() -> void:
	if not _load_active:
		return
	_release_overlay()
	_arm_switch_guard_clear()


func _abort_loading() -> void:
	if not _load_active:
		return
	_release_overlay()
	_switching = false


func _release_overlay() -> void:
	if is_instance_valid(_loading):
		_loading.dismiss()
	_loading = null
	_load_active = false
	_load_stage = STAGE_THREAD
	_load_wait = 0
	_deploy_frames = 0
	_load_path = ""
	_previous_scene = null
	_pending_packed = null
	process_mode = Node.PROCESS_MODE_INHERIT


# Quiet moment after a match: once the swap has landed and nothing is loading,
# drop every cached Ref from the finished battle, then warm the next one.
func _tick_cleanup() -> void:
	if not _cleanup_pending:
		return
	if _switching or _load_active or not _warm_pending.is_empty():
		return
	_cleanup_delay -= 1
	if _cleanup_delay > 0:
		return
	_cleanup_pending = false
	AssetLibrary.clear_caches()
	_warm_assets()


func _warm_assets() -> void:
	for path in WARM_PATHS:
		if _load_active and path == _load_path:
			continue
		if AssetLibrary.is_held(path) or not ResourceLoader.exists(path):
			continue
		var status := ResourceLoader.load_threaded_get_status(path)
		if status == ResourceLoader.THREAD_LOAD_LOADED:
			var ready := ResourceLoader.load_threaded_get(path)
			if ready != null:
				AssetLibrary.hold(path, ready)
			continue
		if status == ResourceLoader.THREAD_LOAD_IN_PROGRESS:
			if not _warm_pending.has(path):
				_warm_pending.append(path)
			continue
		var error := ResourceLoader.load_threaded_request(path)
		if error == OK or error == ERR_BUSY:
			if not _warm_pending.has(path):
				_warm_pending.append(path)


func _tick_warm() -> void:
	if _warm_pending.is_empty():
		return
	var still := PackedStringArray()
	for path in _warm_pending:
		var status := ResourceLoader.load_threaded_get_status(path)
		match status:
			ResourceLoader.THREAD_LOAD_IN_PROGRESS:
				still.append(path)
			ResourceLoader.THREAD_LOAD_LOADED:
				var ready := ResourceLoader.load_threaded_get(path)
				if ready != null:
					AssetLibrary.hold(path, ready)
			_:
				# FAILED / no task: leave it to the arena's own load() call.
				pass
	_warm_pending = still


func _drop_warm_path(path: String) -> void:
	if _warm_pending.is_empty():
		return
	var remaining := PackedStringArray()
	for entry in _warm_pending:
		if entry != path:
			remaining.append(entry)
	_warm_pending = remaining


func _arm_switch_guard_clear() -> void:
	if not get_tree().process_frame.is_connected(_clear_switch_guard):
		get_tree().process_frame.connect(_clear_switch_guard, CONNECT_ONE_SHOT)


func _clear_switch_guard() -> void:
	_switching = false
