extends Node

const MAX_PLAYERS := 8
const MIX_RATE := 44100
const MUSIC_RATE := 22050
const MENU_MUSIC_DB := -14.0
const VARIANT_CHANCE := 0.45

const RECORDINGS: Dictionary = {
	&"cannon": "res://assets/sounds/cannon_a.wav",
	&"cannon_b": "res://assets/sounds/cannon_b.wav",
	&"scatter": "res://assets/sounds/shotgun_a.wav",
	&"rail": "res://assets/sounds/rail_crack_a.wav",
	&"beam": "res://assets/sounds/beam_a.wav",
	&"sonic": "res://assets/sounds/sonic_a.wav",
	&"impact_metal": "res://assets/sounds/impact_metal_a.wav",
	&"impact_metal_b": "res://assets/sounds/impact_metal_b.wav",
	&"zap": "res://assets/sounds/zap_a.ogg",
	&"launch": "res://assets/sounds/launch_a.ogg",
	&"thump": "res://assets/sounds/salvo_a.ogg",
	&"hiss": "res://assets/sounds/hiss_a.ogg",
	&"flame": "res://assets/sounds/flame_a.ogg",
	&"boom": "res://assets/sounds/explosion_a.ogg",
}

var _streams: Dictionary = {}
var _players: Array[AudioStreamPlayer] = []
var _player_cursor: int = 0
var _impact_clock: float = 0.0
var _engine_player: AudioStreamPlayer3D
var _bound_engine: Node3D
var _music_player: AudioStreamPlayer
var _music_target_db: float = -60.0

func _ready() -> void:
	_build_streams()
	_load_recordings()
	for index in MAX_PLAYERS:
		var player := AudioStreamPlayer.new()
		player.name = "Sfx_%d" % index
		add_child(player)
		_players.append(player)
	if AudioServer.get_bus_index("Music") < 0:
		AudioServer.add_bus()
		var music_bus := AudioServer.bus_count - 1
		AudioServer.set_bus_name(music_bus, "Music")
		AudioServer.set_bus_send(music_bus, "Master")
		AudioServer.set_bus_volume_db(music_bus,
				linear_to_db(maxf(GameState.music_volume, 0.001)))
	_music_player = AudioStreamPlayer.new()
	_music_player.name = "MenuMusic"
	_music_player.bus = "Music"
	_music_player.stream = _streams.get(&"menu_music")
	_music_player.volume_db = -60.0
	add_child(_music_player)
	Events.weapon_fired.connect(_on_weapon_fired)
	Events.weapon_reload_started.connect(_on_weapon_reload_started)
	Events.weapon_impact.connect(_on_weapon_impact)
	Events.damage_applied.connect(_on_damage_applied)
	Events.ability_phase_changed.connect(_on_ability_phase)
	Events.enemy_killed.connect(_on_enemy_killed)
	Events.match_started.connect(_on_match_started)

func set_menu_music(active: bool) -> void:
	_music_target_db = MENU_MUSIC_DB if active else -60.0
	if active and not _music_player.playing:
		_music_player.play()

func menu_music_active() -> bool:
	return _music_target_db > -55.0

func _on_match_started() -> void:
	set_menu_music(false)

func has_sound(id: StringName) -> bool:
	return _streams.has(id)

func _load_recordings() -> void:
	for id in RECORDINGS:
		var path := str(RECORDINGS[id])
		if not ResourceLoader.exists(path):
			continue
		var stream := load(path)
		if stream is AudioStreamWAV or stream is AudioStreamOggVorbis \
				or stream is AudioStreamMP3:
			_streams[id] = stream

func _variant_for(id: StringName) -> StringName:
	if randf() >= VARIANT_CHANCE:
		return id
	var alt := id
	match id:
		&"cannon":
			alt = &"cannon_b"
		&"impact_metal":
			alt = &"impact_metal_b"
		_:
			return id
	if _streams.has(alt):
		return alt
	return id

func play(id: StringName, volume_db: float = 0.0, pitch_jitter: float = 0.06,
		pitch_base: float = 1.0) -> void:
	if not _streams.has(id) or _players.is_empty():
		return
	var player := _players[_player_cursor]
	_player_cursor = (_player_cursor + 1) % _players.size()
	player.stream = _streams[_variant_for(id)]
	player.volume_db = volume_db
	player.pitch_scale = pitch_base + randf_range(-pitch_jitter, pitch_jitter)
	player.play()

func _engine_loop_id() -> StringName:
	# Each chassis gets its own hum: SCARAB 52 Hz, VORTEX 66, ZEPHYR 88,
	# PRAETOR 40. RAMPART is the internal id of ZEPHYR.
	match GameState.selected_robot:
		&"VORTEX":
			return &"engine_vortex"
		&"RAMPART":
			return &"engine_rampart"
		&"PRAETOR":
			return &"engine_praetor"
		_:
			return &"engine"

func _robot_voice() -> Vector2:
	# (pitch_mult, db_boost) — every fire sound carries the chassis's voice.
	match GameState.selected_robot:
		&"VORTEX":
			return Vector2(1.06, 0.5)
		&"RAMPART":
			return Vector2(1.18, -1.0)
		&"PRAETOR":
			return Vector2(0.82, 3.0)
		_:
			return Vector2(0.96, 1.0)

func bind_engine(target: Node3D) -> void:
	unbind_engine()
	_bound_engine = target
	_engine_player = AudioStreamPlayer3D.new()
	_engine_player.name = "EngineLoop"
	_engine_player.stream = _streams.get(_engine_loop_id())
	_engine_player.volume_db = -40.0
	_engine_player.unit_size = 10.0
	_engine_player.max_distance = 80.0
	add_child(_engine_player)
	_engine_player.global_position = target.global_position
	_engine_player.play()

func unbind_engine() -> void:
	if _engine_player != null:
		_engine_player.queue_free()
		_engine_player = null
	_bound_engine = null

func _process(delta: float) -> void:
	_impact_clock = maxf(_impact_clock - delta, 0.0)
	_tick_music(delta)
	if _engine_player == null:
		return
	if not is_instance_valid(_bound_engine):
		unbind_engine()
		return
	_engine_player.global_position = _bound_engine.global_position
	var ratio := 0.0
	if _bound_engine is PlayerRobot:
		var player := _bound_engine as PlayerRobot
		if player.health != null and not player.health.dead:
			ratio = player.speed_ratio
	var target_db := lerpf(-40.0, -6.0, clampf(ratio, 0.0, 1.0))
	_engine_player.volume_db = lerpf(_engine_player.volume_db, target_db,
			clampf(delta * 4.0, 0.0, 1.0))

func _on_weapon_fired(_mount_index: int, kind: int, family: StringName,
		size: int) -> void:
	var voice := _robot_voice()
	var db: float = KIND_DB.get(kind, -2.0) as float
	# Per-weapon report: archetype stream + the family's own character pitch,
	# then the chassis voice and the barrel size on top. No two guns in the
	# catalog sound the same.
	var pitch := (_family_pitch(family) + _size_pitch(size)) * voice.x
	play(_voice_stream(family, kind), db + voice.y, 0.07, pitch)

# Which synthesis archetype a weapon family reports with. Families missing
# here fall back to their Kind's archetype (see KIND_VOICE), so a new catalog
# entry is never silent or mis-voiced.
const FAMILY_VOICE := {
	&"RAZOR": &"cannon",
	&"GLADIUS": &"whip",
	&"PILUM": &"whip",
	&"ATOMIZER": &"cannon",
	&"JUGGERNAUT": &"clank",
	&"DEMOLISHER": &"clank",
	&"OVERLORD": &"clank",
	&"MAUL": &"scatter",
	&"HARMATTAN": &"scatter",
	&"VAJRA": &"scatter",
	&"MAHA-VAJRA": &"scatter",
	&"HAVOC": &"scatter",
	&"VOLT": &"zap",
	&"BARQ": &"zap",
	&"MUNINN": &"zap",
	&"HUGINN": &"zap",
	&"ARCSTING": &"zap",
	&"ARCLANCE": &"zap",
	&"CELERITY": &"whip",
	&"TORQ": &"rail",
	&"IARAGHI": &"rail",
	&"VOONITH": &"rail",
	&"URHAG": &"rail",
	&"SHANTAK": &"rail",
	&"STRIKER": &"rail",
	&"BREACH": &"launch",
	&"KSIPHOS": &"launch",
	&"LABRYS": &"launch",
	&"CESTUS": &"launch",
	&"VENIRE": &"launch",
	&"VINCERE": &"launch",
	&"EQUALIZER": &"launch",
	&"ARBITER": &"launch",
	&"FERRIC": &"hiss",
	&"LUMEN": &"beam",
	&"FURNACE": &"beam",
	&"TORCH": &"beam",
	&"PYRE": &"flame",
	&"CELSIUS": &"flame",
	&"FAHRENHEIT": &"flame",
	&"KELVIN": &"flame",
	&"VOLLEY": &"thump",
	&"ECHO": &"sonic",
	&"EVORA": &"sonic",
	&"VEYRON": &"sonic",
	&"VOID": &"clank",
	&"CHASH": &"clank",
	&"CHASM": &"clank",
}

# Hand-tuned character per family where the hash fallback would not land on
# the right register (light guns crack, heavy guns thud, rails ring bright).
const FAMILY_PITCH := {
	&"RAZOR": 1.0,
	&"GLADIUS": 1.1,
	&"PILUM": 0.95,
	&"ATOMIZER": 1.05,
	&"JUGGERNAUT": 0.8,
	&"DEMOLISHER": 0.84,
	&"OVERLORD": 0.88,
	&"MAUL": 1.0,
	&"HARMATTAN": 1.08,
	&"VAJRA": 0.86,
	&"MAHA-VAJRA": 0.82,
	&"VOLT": 1.12,
	&"TORQ": 0.92,
	&"BREACH": 0.96,
	&"FERRIC": 1.06,
	&"LUMEN": 1.16,
	&"PYRE": 0.9,
	&"VOLLEY": 1.02,
	&"ECHO": 0.86,
	&"VOID": 0.78,
	&"CHASH": 0.82,
	&"CHASM": 0.8,
	&"CELERITY": 1.18,
}

const KIND_DB := {
	WeaponData.Kind.AUTOCANNON: -2.0,
	WeaponData.Kind.SCATTERGUN: -1.5,
	WeaponData.Kind.ELECTRIC: -3.0,
	WeaponData.Kind.MAGNETIC: -2.5,
	WeaponData.Kind.BLAST: -3.0,
	WeaponData.Kind.CORROSION: -4.5,
	WeaponData.Kind.BEAM: -4.5,
	WeaponData.Kind.FLAME: -7.0,
	WeaponData.Kind.SALVO: -3.0,
	WeaponData.Kind.SONIC: -1.8,
}

const KIND_VOICE := {
	WeaponData.Kind.AUTOCANNON: &"cannon",
	WeaponData.Kind.SCATTERGUN: &"scatter",
	WeaponData.Kind.ELECTRIC: &"zap",
	WeaponData.Kind.MAGNETIC: &"rail",
	WeaponData.Kind.BLAST: &"launch",
	WeaponData.Kind.CORROSION: &"hiss",
	WeaponData.Kind.BEAM: &"beam",
	WeaponData.Kind.FLAME: &"flame",
	WeaponData.Kind.SALVO: &"thump",
	WeaponData.Kind.SONIC: &"sonic",
}

# Barrel size shifts the report: a light gun cracks higher, a titan barrel
# thuds lower. Purely relative — the family pitch is the identity.
const SIZE_PITCH := {
	WeaponData.Size.LIGHT: 0.14,
	WeaponData.Size.MEDIUM: 0.0,
	WeaponData.Size.HEAVY: -0.14,
	WeaponData.Size.ALPHA: -0.2,
	WeaponData.Size.BETA: -0.1,
}

func _voice_stream(family: StringName, kind: int) -> StringName:
	if FAMILY_VOICE.has(family):
		return FAMILY_VOICE[family] as StringName
	if KIND_VOICE.has(kind):
		return KIND_VOICE[kind] as StringName
	return &"cannon"

func _family_pitch(family: StringName) -> float:
	if FAMILY_PITCH.has(family):
		return FAMILY_PITCH[family] as float
	# Deterministic per-family character for the long tail of catalog names
	# that have no hand-tuned entry: spread over 0.88..1.12 by name hash so
	# every weapon still reports distinctly across reloads.
	var hashed := absi(String(family).hash() % 1000)
	return 0.88 + 0.24 * (float(hashed) / 999.0)

func _size_pitch(size: int) -> float:
	return SIZE_PITCH.get(size, 0.0) as float

func _on_weapon_reload_started() -> void:
	var voice := _robot_voice()
	play(&"reload", -8.0 + voice.y, 0.03, voice.x)

func _on_weapon_impact(_point: Vector3, _normal: Vector3, kind: int) -> void:
	if _impact_clock > 0.0:
		return
	_impact_clock = 0.09
	# Impact colour is sonic too: energy weapons leave their own signature on
	# the hull instead of one generic clang for everything.
	match kind:
		WeaponData.Kind.ELECTRIC:
			play(&"zap", -9.0, 0.2)
		WeaponData.Kind.MAGNETIC:
			play(&"rail", -11.0, 0.18)
		WeaponData.Kind.CORROSION:
			play(&"hiss", -12.0, 0.22)
		WeaponData.Kind.BEAM:
			play(&"beam", -13.0, 0.16)
		WeaponData.Kind.SONIC:
			play(&"sonic", -14.0, 0.14)
		WeaponData.Kind.FLAME:
			play(&"flame", -13.0, 0.2)
		_:
			play(&"impact_metal", -7.0, 0.14)

func _on_damage_applied(target: Node, _amount: float, _point: Vector3, _normal: Vector3) -> void:
	if target is PlayerRobot:
		play(&"hit", -2.0, 0.08)
	else:
		play(&"impact_metal", -6.0, 0.18)

func _on_ability_phase(phase_name: String) -> void:
	if phase_name == "DASHING":
		play(&"dash", -3.0, 0.05)

func _on_enemy_killed(_enemy_id: int) -> void:
	play(&"boom", -3.0, 0.1)

func _tick_music(delta: float) -> void:
	if _music_player == null:
		return
	if _music_target_db > -55.0 and not _music_player.playing:
		_music_player.play()
	var rate := 2.2 if _music_target_db > _music_player.volume_db else 3.0
	_music_player.volume_db = lerpf(_music_player.volume_db, _music_target_db,
			clampf(delta * rate, 0.0, 1.0))
	if _music_target_db <= -55.0 and _music_player.volume_db < -58.0 \
			and _music_player.playing:
		_music_player.stop()
		_music_player.volume_db = -60.0

# ---------------------------------------------------------------- synthesis --
#
# Realistic weapon voices are layered: a broadband muzzle blast (bright crack
# plus lowpassed expanding gas), a pitch-dropping body thump from the pressure
# wave, inharmonic metallic partials for barrel/spring ringing, a feedback
# slapback tail for space, and a tanh saturation stage for punch. Pure noise
# bursts alone read as "frying" — the structured layers are what make them
# sound like machines.

func _lcg(state: int) -> int:
	return (state * 1103515245 + 12345) & 0x7fffffff

func _white(state: int) -> float:
	return float(state % 20000 - 10000) / 10000.0

func _add_drop_sine(samples: PackedFloat32Array, high: float, low: float,
		sweep: float, gain: float, decay: float, start: float = 0.0) -> void:
	var first := int(start * MIX_RATE)
	var phase := 0.0
	for index in range(first, samples.size()):
		var t := float(index - first) / float(MIX_RATE)
		phase += TAU * (low + (high - low) * exp(-t * sweep)) / float(MIX_RATE)
		samples[index] += sin(phase) * gain * exp(-t * decay)

func _add_partial(samples: PackedFloat32Array, frequency: float, gain: float,
		decay: float, start: float = 0.0) -> void:
	var first := int(start * MIX_RATE)
	for index in range(first, samples.size()):
		var t := float(index - first) / float(MIX_RATE)
		samples[index] += sin(TAU * frequency * t) * gain * exp(-t * decay)

func _apply_tail(samples: PackedFloat32Array, delay_sec: float, feedback: float,
		tail_sec: float) -> void:
	var delay := maxi(int(delay_sec * MIX_RATE), 1)
	var old_size := samples.size()
	samples.resize(old_size + int(tail_sec * MIX_RATE))
	for index in range(delay, samples.size()):
		samples[index] += samples[index - delay] * feedback

func _saturate(samples: PackedFloat32Array, drive: float = 1.5) -> void:
	var norm := tanh(drive)
	for index in samples.size():
		samples[index] = tanh(samples[index] * drive) / norm

func _wav(samples: PackedFloat32Array, loop: bool = false,
		rate: int = MIX_RATE) -> AudioStreamWAV:
	var bytes := PackedByteArray()
	bytes.resize(samples.size() * 2)
	for index in samples.size():
		bytes.encode_s16(index * 2, int(clampf(samples[index], -1.0, 1.0) * 30000.0))
	var stream := AudioStreamWAV.new()
	stream.format = AudioStreamWAV.FORMAT_16_BITS
	stream.mix_rate = rate
	stream.stereo = false
	stream.data = bytes
	if loop:
		stream.loop_mode = AudioStreamWAV.LOOP_FORWARD
		stream.loop_begin = 0
		stream.loop_end = samples.size()
	return stream

func _build_streams() -> void:
	_streams[&"cannon"] = _make_cannon()
	_streams[&"scatter"] = _make_scatter()
	_streams[&"zap"] = _make_zap()
	_streams[&"rail"] = _make_rail()
	_streams[&"launch"] = _make_launch()
	_streams[&"hiss"] = _make_hiss()
	_streams[&"beam"] = _make_beam()
	_streams[&"flame"] = _make_flame()
	_streams[&"thump"] = _make_thump()
	_streams[&"sonic"] = _make_sonic()
	_streams[&"whip"] = _make_whip()
	_streams[&"clank"] = _make_clank()
	_streams[&"impact_metal"] = _make_impact()
	_streams[&"hit"] = _make_hit()
	_streams[&"dash"] = _make_dash()
	_streams[&"boom"] = _make_boom()
	_streams[&"ui"] = _make_ui()
	_streams[&"reload"] = _make_reload()
	_streams[&"engine"] = _make_engine_loop()
	_streams[&"engine_vortex"] = _make_engine_loop(66.0, 1.5, 2.1, 0.045)
	_streams[&"engine_rampart"] = _make_engine_loop(88.0, 1.6, 2.6, 0.05)
	_streams[&"engine_praetor"] = _make_engine_loop(40.0, 1.4, 0.9, 0.035)
	_streams[&"menu_music"] = _make_menu_music()

# Autocannon (RAZOR): mechanical action clack, bright muzzle crack, lowpassed
# gas blast, 165->52 Hz body thump, three inharmonic barrel rings, slapback.
func _make_cannon() -> AudioStreamWAV:
	var duration := 0.36
	var count := int(duration * MIX_RATE)
	var samples := PackedFloat32Array()
	samples.resize(count)
	var rng_state := 4241
	var lp := 0.0
	for index in count:
		var t := float(index) / float(MIX_RATE)
		rng_state = _lcg(rng_state)
		var white := _white(rng_state)
		lp += (white - lp) * (0.04 + 0.55 * exp(-t * 26.0))
		var crack := white * exp(-t * 70.0) * 0.85
		var gas := lp * exp(-t * 15.0) * 1.1
		var clack := 0.0
		if t < 0.014:
			clack = white * exp(-t * 260.0) * 0.4
		samples[index] = crack + gas + clack
	_add_drop_sine(samples, 165.0, 52.0, 20.0, 0.85, 14.0, 0.003)
	_add_partial(samples, 1750.0, 0.11, 26.0, 0.005)
	_add_partial(samples, 2680.0, 0.07, 30.0, 0.005)
	_add_partial(samples, 4150.0, 0.05, 36.0, 0.006)
	_apply_tail(samples, 0.05, 0.3, 0.14)
	_saturate(samples, 1.6)
	return _wav(samples)

# Scattergun (MAUL): brown-noise blast, snap, 95->42 Hz boom, pump-action
# clack on the fore-grip, room tail, heavy saturation.
func _make_scatter() -> AudioStreamWAV:
	var duration := 0.52
	var count := int(duration * MIX_RATE)
	var samples := PackedFloat32Array()
	samples.resize(count)
	var rng_state := 9173
	var brown := 0.0
	for index in count:
		var t := float(index) / float(MIX_RATE)
		rng_state = _lcg(rng_state)
		var white := _white(rng_state)
		brown = clampf(brown + white * 0.12, -1.0, 1.0) * 0.965
		var blast := brown * exp(-t * 12.0) * 1.5
		var snap := white * exp(-t * 110.0) * 0.45
		var fizz := white * exp(-t * 6.0) * 0.08
		samples[index] = blast + snap + fizz
	_add_drop_sine(samples, 95.0, 42.0, 9.0, 0.9, 8.0, 0.002)
	_add_partial(samples, 2150.0, 0.16, 60.0, 0.26)
	_add_partial(samples, 1310.0, 0.12, 55.0, 0.265)
	_apply_tail(samples, 0.06, 0.34, 0.18)
	_saturate(samples, 1.8)
	return _wav(samples)

# Electric (VOLT): swept carrier + gated crackle over a capacitor-discharge
# body tick and a bright arc ring.
func _make_zap() -> AudioStreamWAV:
	var duration := 0.26
	var count := int(duration * MIX_RATE)
	var samples := PackedFloat32Array()
	samples.resize(count)
	var rng_state := 8123
	var brown := 0.0
	var phase := 0.0
	for index in count:
		var t := float(index) / float(MIX_RATE)
		rng_state = _lcg(rng_state)
		var white := _white(rng_state)
		brown = clampf(brown + white * 0.15, -1.0, 1.0) * 0.94
		phase += TAU * (3200.0 - 2300.0 * minf(t * 3.5, 1.0)) / float(MIX_RATE)
		var env := exp(-t * 20.0)
		var carrier := sin(phase)
		var gate := 0.55 + 0.45 * absf(white)
		var crackle := white * gate * exp(-t * 15.0)
		var buzz := brown * exp(-t * 30.0) * 0.5
		var tick := sin(TAU * 5400.0 * t) * exp(-t * 55.0) * 0.35
		samples[index] = carrier * env * 0.5 + crackle * 0.7 + buzz + tick
	_add_drop_sine(samples, 130.0, 60.0, 24.0, 0.4, 20.0, 0.001)
	_add_partial(samples, 3300.0, 0.1, 40.0, 0.008)
	_apply_tail(samples, 0.03, 0.28, 0.08)
	_saturate(samples, 1.35)
	return _wav(samples)

# Magnetic railgun (TORQ): charging whine sweep, supersonic crack at the
# rail release, deep thump, ringing rails, long tail.
func _make_rail() -> AudioStreamWAV:
	var duration := 0.34
	var count := int(duration * MIX_RATE)
	var samples := PackedFloat32Array()
	samples.resize(count)
	var rng_state := 6491
	var phase := 0.0
	for index in count:
		var t := float(index) / float(MIX_RATE)
		var progress := t / duration
		rng_state = _lcg(rng_state)
		var white := _white(rng_state)
		phase += TAU * (420.0 + 2600.0 * progress * progress) / float(MIX_RATE)
		var whine_env := sin(PI * minf(progress / 0.62, 1.0))
		var whine := sin(phase) * whine_env * 0.5
		var crack := 0.0
		var crack_time := t - 0.17
		if crack_time >= 0.0:
			crack = white * exp(-crack_time * 70.0) * 0.9
		samples[index] = whine + crack
	_add_drop_sine(samples, 105.0, 48.0, 14.0, 0.75, 12.0, 0.165)
	_add_partial(samples, 940.0, 0.1, 22.0, 0.17)
	_add_partial(samples, 1890.0, 0.07, 26.0, 0.17)
	_apply_tail(samples, 0.05, 0.3, 0.12)
	_saturate(samples, 1.5)
	return _wav(samples)

# Rocket launcher (BREACH): tube pop, rising lowpass whoosh, fin/metal ring,
# vented tail.
func _make_launch() -> AudioStreamWAV:
	var duration := 0.45
	var count := int(duration * MIX_RATE)
	var samples := PackedFloat32Array()
	samples.resize(count)
	var rng_state := 5011
	var filtered := 0.0
	for index in count:
		var t := float(index) / float(MIX_RATE)
		var progress := t / duration
		rng_state = _lcg(rng_state)
		var white := _white(rng_state)
		filtered += (white - filtered) * (0.04 + 0.45 * progress)
		var env := sin(PI * progress)
		env *= env
		var pop := sin(TAU * 150.0 * t) * exp(-t * 26.0) * 0.55
		var whoosh := filtered * env * 1.5
		var rush := white * exp(-t * 9.0) * 0.12
		samples[index] = whoosh + pop + rush
	_add_drop_sine(samples, 150.0, 66.0, 18.0, 0.5, 12.0, 0.004)
	_add_partial(samples, 430.0, 0.14, 16.0, 0.02)
	_add_partial(samples, 780.0, 0.1, 20.0, 0.02)
	_apply_tail(samples, 0.07, 0.3, 0.14)
	_saturate(samples, 1.4)
	return _wav(samples)

# Corrosion sprayer (FERRIC): tremolo spray over a chemical gurgle sweep.
func _make_hiss() -> AudioStreamWAV:
	var duration := 0.34
	var count := int(duration * MIX_RATE)
	var samples := PackedFloat32Array()
	samples.resize(count)
	var rng_state := 7727
	for index in count:
		var t := float(index) / float(MIX_RATE)
		var progress := t / duration
		rng_state = _lcg(rng_state)
		var white := _white(rng_state)
		var tremolo := 0.5 + 0.5 * sin(TAU * 84.0 * t)
		var env := exp(-t * 8.5)
		var spray := white * tremolo * env * 0.9
		var gurgle := sin(TAU * (360.0 - 180.0 * progress) * t) * exp(-t * 12.0) * 0.3
		samples[index] = spray + gurgle
	_apply_tail(samples, 0.02, 0.16, 0.06)
	return _wav(samples)

# Beam rifle (LUMEN): attack tick, downward energy sweep, two beating
# shimmer partials (2100/2117 Hz), body hum, short tail.
func _make_beam() -> AudioStreamWAV:
	var duration := 0.3
	var count := int(duration * MIX_RATE)
	var samples := PackedFloat32Array()
	samples.resize(count)
	var rng_state := 4409
	var phase := 0.0
	for index in count:
		var t := float(index) / float(MIX_RATE)
		var progress := t / duration
		rng_state = _lcg(rng_state)
		var white := _white(rng_state)
		phase += TAU * (2100.0 - 1500.0 * minf(progress * 2.2, 1.0)) / float(MIX_RATE)
		var snap := sin(phase) * exp(-t * 14.0)
		var shimmer := sin(phase * 2.0) * exp(-t * 26.0) * 0.35
		var tick := white * exp(-t * 90.0) * 0.4
		samples[index] = snap * 0.6 + shimmer + tick
	_add_drop_sine(samples, 210.0, 150.0, 16.0, 0.3, 16.0, 0.002)
	_add_partial(samples, 2117.0, 0.1, 9.0, 0.02)
	_apply_tail(samples, 0.03, 0.3, 0.1)
	return _wav(samples)

# Flame thrower (PYRE): brown-noise roar with a hard attack and low
# turbulence loop-in surge.
func _make_flame() -> AudioStreamWAV:
	var duration := 0.4
	var count := int(duration * MIX_RATE)
	var samples := PackedFloat32Array()
	samples.resize(count)
	var rng_state := 9907
	var brown := 0.0
	var lp := 0.0
	for index in count:
		var t := float(index) / float(MIX_RATE)
		rng_state = _lcg(rng_state)
		var white := _white(rng_state)
		brown = clampf(brown + white * 0.12, -1.0, 1.0) * 0.965
		lp += (white - lp) * (0.1 + 0.3 * exp(-t * 6.0))
		var attack := minf(t / 0.03, 1.0)
		var env := attack * exp(-maxf(t - 0.03, 0.0) * 10.0)
		var roar := sin(TAU * 72.0 * t) * 0.3
		var turbine := lp * exp(-t * 7.0) * 0.5
		samples[index] = (brown * 1.6 + roar + turbine) * env
	_apply_tail(samples, 0.045, 0.2, 0.07)
	return _wav(samples)

# Salvo tubes (VOLLEY): deep pop, metallic tube clank, mid burst, vent tail.
func _make_thump() -> AudioStreamWAV:
	var duration := 0.5
	var count := int(duration * MIX_RATE)
	var samples := PackedFloat32Array()
	samples.resize(count)
	var rng_state := 3617
	for index in count:
		var t := float(index) / float(MIX_RATE)
		rng_state = _lcg(rng_state)
		var white := _white(rng_state)
		var pop := sin(TAU * 92.0 * t) * exp(-t * 13.0) * 0.85
		var burst := white * exp(-t * 38.0) * 0.45
		samples[index] = pop + burst
	_add_partial(samples, 620.0, 0.16, 18.0, 0.008)
	_add_partial(samples, 1180.0, 0.12, 26.0, 0.01)
	_apply_tail(samples, 0.07, 0.32, 0.16)
	_saturate(samples, 1.4)
	return _wav(samples)

# Sonic cannon (ECHO): shockwave whomp — mid pressure drop plus deep sub
# drop, body resonance, long air tail. Original design for the sonic family.
func _make_sonic() -> AudioStreamWAV:
	var duration := 0.55
	var count := int(duration * MIX_RATE)
	var samples := PackedFloat32Array()
	samples.resize(count)
	var rng_state := 5231
	var brown := 0.0
	for index in count:
		var t := float(index) / float(MIX_RATE)
		rng_state = _lcg(rng_state)
		var white := _white(rng_state)
		brown = clampf(brown + white * 0.1, -1.0, 1.0) * 0.97
		var air := brown * exp(-t * 5.5) * 1.0
		var pressure := white * exp(-t * 30.0) * 0.35
		samples[index] = air + pressure
	_add_drop_sine(samples, 190.0, 68.0, 14.0, 0.55, 9.0, 0.002)
	_add_drop_sine(samples, 95.0, 34.0, 5.0, 0.95, 4.5, 0.01)
	_add_partial(samples, 480.0, 0.14, 12.0, 0.01)
	_apply_tail(samples, 0.085, 0.42, 0.26)
	_saturate(samples, 1.7)
	return _wav(samples)

# Light kinetic whip (GLADIUS / PILUM / CELERITY): a razor-bright crack with
# almost no body — a small high-velocity barrel, deliberately higher and
# shorter than the heavy cannon voice so light guns do not sound like heavies.
func _make_whip() -> AudioStreamWAV:
	var duration := 0.2
	var count := int(duration * MIX_RATE)
	var samples := PackedFloat32Array()
	samples.resize(count)
	var rng_state := 5507
	var lp := 0.0
	for index in count:
		var t := float(index) / float(MIX_RATE)
		rng_state = _lcg(rng_state)
		var white := _white(rng_state)
		lp += (white - lp) * (0.12 + 0.6 * exp(-t * 60.0))
		var crack := white * exp(-t * 150.0) * 1.1
		var snap := lp * exp(-t * 45.0) * 0.8
		var tick := 0.0
		if t < 0.006:
			tick = white * exp(-t * 520.0) * 0.5
		samples[index] = crack + snap + tick
	_add_drop_sine(samples, 340.0, 110.0, 40.0, 0.45, 26.0, 0.002)
	_add_partial(samples, 2900.0, 0.1, 55.0, 0.004)
	_add_partial(samples, 4700.0, 0.07, 70.0, 0.004)
	_apply_tail(samples, 0.03, 0.22, 0.1)
	_saturate(samples, 1.5)
	return _wav(samples)

# Heavy titan clank (JUGGERNAUT / DEMOLISHER / OVERLORD / VOID): low hull
# thud plus a slow metal plate ring — several tonnes of gun cycling.
func _make_clank() -> AudioStreamWAV:
	var duration := 0.62
	var count := int(duration * MIX_RATE)
	var samples := PackedFloat32Array()
	samples.resize(count)
	var rng_state := 3391
	var brown := 0.0
	for index in count:
		var t := float(index) / float(MIX_RATE)
		rng_state = _lcg(rng_state)
		var white := _white(rng_state)
		brown = clampf(brown + white * 0.14, -1.0, 1.0) * 0.96
		var thud := brown * exp(-t * 9.0) * 1.5
		var strike := white * exp(-t * 90.0) * 0.5
		samples[index] = thud + strike
	_add_drop_sine(samples, 120.0, 38.0, 14.0, 0.95, 9.0, 0.004)
	_add_partial(samples, 96.0, 0.4, 7.0, 0.01)
	_add_partial(samples, 143.0, 0.22, 9.0, 0.03)
	_add_partial(samples, 211.0, 0.14, 12.0, 0.05)
	_add_partial(samples, 1180.0, 0.1, 34.0, 0.006)
	_apply_tail(samples, 0.05, 0.4, 0.3)
	_saturate(samples, 1.7)
	return _wav(samples)

# Metal impact: structured inharmonic clang (618/941/1487/2377 Hz), low
# thud, debris grit, short room tail — a clang, not frying rice.
func _make_impact() -> AudioStreamWAV:
	var duration := 0.26
	var count := int(duration * MIX_RATE)
	var samples := PackedFloat32Array()
	samples.resize(count)
	var rng_state := 5507
	for index in count:
		var t := float(index) / float(MIX_RATE)
		rng_state = _lcg(rng_state)
		var white := _white(rng_state)
		var grit := white * exp(-t * 70.0) * 0.3
		var debris := 0.0
		if t < 0.05:
			debris = white * exp(-t * 90.0) * 0.25
		samples[index] = grit + debris
	_add_drop_sine(samples, 150.0, 110.0, 20.0, 0.4, 30.0, 0.0)
	_add_partial(samples, 618.0, 0.5, 30.0, 0.002)
	_add_partial(samples, 941.0, 0.35, 38.0, 0.002)
	_add_partial(samples, 1487.0, 0.22, 46.0, 0.003)
	_add_partial(samples, 2377.0, 0.14, 60.0, 0.003)
	_apply_tail(samples, 0.038, 0.22, 0.09)
	_saturate(samples, 1.3)
	return _wav(samples)

# Player taking a hit: armour crunch, low body tone, struck plate ring.
func _make_hit() -> AudioStreamWAV:
	var duration := 0.22
	var count := int(duration * MIX_RATE)
	var samples := PackedFloat32Array()
	samples.resize(count)
	var rng_state := 3313
	for index in count:
		var t := float(index) / float(MIX_RATE)
		rng_state = _lcg(rng_state)
		var white := _white(rng_state)
		var crunch := white * exp(-t * 24.0) * 0.7
		var tone := sin(TAU * 150.0 * t) * exp(-t * 19.0) * 0.65
		samples[index] = crunch + tone
	_add_partial(samples, 700.0, 0.18, 34.0, 0.004)
	_apply_tail(samples, 0.03, 0.25, 0.1)
	_saturate(samples, 1.3)
	return _wav(samples)

# Shadow dash: filtered air rush with a Doppler-ish mid swell.
func _make_dash() -> AudioStreamWAV:
	var duration := 0.42
	var count := int(duration * MIX_RATE)
	var samples := PackedFloat32Array()
	samples.resize(count)
	var rng_state := 7717
	var filtered := 0.0
	for index in count:
		var t := float(index) / float(MIX_RATE)
		var progress := t / duration
		rng_state = _lcg(rng_state)
		var white := _white(rng_state)
		var cutoff := 0.08 + 0.5 * progress
		filtered += (white - filtered) * cutoff
		var envelope := sin(PI * progress)
		samples[index] = filtered * envelope * 1.4
	_apply_tail(samples, 0.05, 0.2, 0.1)
	return _wav(samples)

# Kill explosion: 95->36 Hz sub drop, debris crackle, struck-metal ring,
# long rumble tail.
func _make_boom() -> AudioStreamWAV:
	var duration := 0.9
	var count := int(duration * MIX_RATE)
	var samples := PackedFloat32Array()
	samples.resize(count)
	var rng_state := 6101
	var brown := 0.0
	var lp := 0.0
	for index in count:
		var t := float(index) / float(MIX_RATE)
		rng_state = _lcg(rng_state)
		var white := _white(rng_state)
		brown = clampf(brown + white * 0.1, -1.0, 1.0) * 0.98
		lp += (white - lp) * 0.25
		var rumble := brown * exp(-t * 4.5) * 1.1
		var debris := lp * exp(-t * 9.0) * 0.5
		samples[index] = rumble + debris
	_add_drop_sine(samples, 95.0, 36.0, 3.5, 0.9, 4.5, 0.01)
	_add_partial(samples, 520.0, 0.18, 10.0, 0.05)
	_add_partial(samples, 780.0, 0.12, 13.0, 0.05)
	_apply_tail(samples, 0.1, 0.4, 0.3)
	_saturate(samples, 1.4)
	return _wav(samples)

func _make_ui() -> AudioStreamWAV:
	var duration := 0.07
	var count := int(duration * MIX_RATE)
	var samples := PackedFloat32Array()
	samples.resize(count)
	for index in count:
		var t := float(index) / float(MIX_RATE)
		var progress := t / duration
		var frequency := lerpf(880.0, 640.0, progress)
		samples[index] = sin(TAU * frequency * t) * exp(-t * 46.0) * 0.6
	return _wav(samples)

func _make_reload() -> AudioStreamWAV:
	var duration := 0.34
	var count := int(duration * MIX_RATE)
	var samples := PackedFloat32Array()
	samples.resize(count)
	var rng_state := 4071
	for index in count:
		var t := float(index) / float(MIX_RATE)
		var clack_1 := exp(-t * 95.0) * sin(TAU * 190.0 * t)
		var ratchet := 0.0
		if t >= 0.13 and t < 0.22:
			var r_t := t - 0.13
			ratchet = exp(-r_t * 70.0) * sin(TAU * 340.0 * r_t)
		var slide := 0.0
		if t >= 0.22:
			var s_t := t - 0.22
			slide = exp(-s_t * 45.0) * sin(TAU * 150.0 * s_t)
		rng_state = _lcg(rng_state)
		samples[index] = (clack_1 + ratchet + slide + _white(rng_state) * 0.03) * 0.6
	return _wav(samples)

func _make_engine_loop(base_freq: float = 52.0, hum_mult: float = 1.5,
		wobble_hz: float = 1.7, texture: float = 0.04) -> AudioStreamWAV:
	var duration := 1.0
	var count := int(duration * MIX_RATE)
	var samples := PackedFloat32Array()
	samples.resize(count)
	var rng_state := 2207
	for index in count:
		var t := float(index) / float(MIX_RATE)
		rng_state = _lcg(rng_state)
		var white := _white(rng_state)
		var wobble := 0.85 + 0.15 * sin(TAU * wobble_hz * t)
		var hum := sin(TAU * base_freq * t) * 0.5 \
				+ sin(TAU * base_freq * hum_mult * t) * 0.3 \
				+ sin(TAU * base_freq * hum_mult * 2.0 * t) * 0.15
		var grain := white * texture
		samples[index] = (hum + grain) * wobble * 0.7
	return _wav(samples, true)

func _make_menu_music() -> AudioStreamWAV:
	var duration := 16.0
	var count := int(duration * MUSIC_RATE)
	var samples := PackedFloat32Array()
	samples.resize(count)
	# i - VI - III - VII in D minor: Dm, Bb, F, C (original composition)
	var chord_tones := [
		[146.83, 174.61, 220.00],
		[116.54, 146.83, 174.61],
		[174.61, 220.00, 261.63],
		[130.81, 164.81, 196.00],
	]
	var bass_roots := [73.42, 58.27, 87.31, 65.41]
	var arp_shape := [0, 1, 2, 1, 0, 2, 1, 2]
	var arp_freqs := PackedFloat32Array()
	arp_freqs.resize(128)
	for step in 128:
		var chord: Array = chord_tones[int(step / 32) % 4]
		arp_freqs[step] = float(chord[arp_shape[step % 8]]) * 2.0
	var rng_state := 3319
	for index in count:
		var t := float(index) / float(MUSIC_RATE)
		var seg := int(t / 4.0) % 4
		var seg_phase := fmod(t, 4.0)
		var fade := minf(minf(seg_phase, 4.0 - seg_phase) / 0.3, 1.0)
		var wave := 0.0
		var tones: Array = chord_tones[seg]
		for tone in tones.size():
			var frequency := float(tones[tone])
			var pad_env := fade * (0.11 - 0.02 * float(tone))
			wave += (sin(TAU * frequency * t) + 0.5 * sin(TAU * frequency * 2.0 * t)
					+ 0.28 * sin(TAU * frequency * 3.0 * t)) * pad_env
			wave += (sin(TAU * frequency * 1.002 * t)
					+ 0.4 * sin(TAU * frequency * 2.004 * t)) * pad_env * 0.6
		var bass := float(bass_roots[seg])
		var pulse_phase := fmod(t, 0.25)
		var pulse_env := minf(pulse_phase / 0.004, 1.0) * exp(-pulse_phase * 16.0)
		wave += (sin(TAU * bass * pulse_phase)
				+ 0.45 * sin(TAU * bass * 2.0 * pulse_phase)) * pulse_env * 0.30
		var kick_phase := fmod(t, 0.5)
		var kick_frequency := 48.0 + 90.0 * exp(-kick_phase * 34.0)
		wave += sin(TAU * kick_frequency * kick_phase) * exp(-kick_phase * 15.0) * 0.5
		rng_state = _lcg(rng_state)
		var white := _white(rng_state)
		var hat_phase := fmod(t + 0.25, 0.5)
		if hat_phase < 0.07:
			wave += white * exp(-hat_phase * 70.0) * 0.10
		var step := int(t / 0.125) % 128
		var arp_phase := fmod(t, 0.125)
		var arp_env := minf(arp_phase / 0.004, 1.0) * exp(-arp_phase * 24.0)
		var arp_frequency := arp_freqs[step]
		wave += (sin(TAU * arp_frequency * arp_phase)
				+ 0.3 * sin(TAU * arp_frequency * 2.0 * arp_phase)) * arp_env * 0.12
		var delay_time := maxf(t - 0.25, 0.0)
		var delay_step := int(delay_time / 0.125) % 128
		var delay_phase := fmod(delay_time, 0.125)
		var delay_env := minf(delay_phase / 0.004, 1.0) * exp(-delay_phase * 24.0)
		var delay_frequency := arp_freqs[delay_step]
		wave += (sin(TAU * delay_frequency * delay_phase)
				+ 0.3 * sin(TAU * delay_frequency * 2.0 * delay_phase)) * delay_env * 0.06
		samples[index] = clampf(wave, -1.0, 1.0)
	return _wav(samples, true, MUSIC_RATE)
