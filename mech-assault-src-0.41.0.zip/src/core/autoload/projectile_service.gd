class_name ProjectileService
extends Node3D

const CAPACITY := 96

var _pool: Array[Projectile] = []
var _impacts: int = 0
var _last_impact_point: Vector3 = Vector3.ZERO
var _splash_shape := SphereShape3D.new()

func _ready() -> void:
	var material := MeshUtil.make_material(Color( 1.0, 0.78, 0.35), 0.0, 0.35)
	material.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
	material.emission_enabled = true
	material.emission = Color(1.0, 0.78, 0.35)
	material.emission_energy_multiplier = 3.5
	for index in CAPACITY:
		var projectile := Projectile.new()
		projectile.name = "Projectile%d" % index
		projectile.prepare(material)
		add_child(projectile)
		_pool.append(projectile)

func fire(origin: Vector3, direction: Vector3, data: WeaponData, exclude: Array[RID],
		damage_override: float = -1.0) -> bool:
	for projectile in _pool:
		if projectile.is_active():
			continue
		projectile.launch(origin, direction, data, exclude, damage_override)
		return true
	return false

func active_count() -> int:
	var total: int = 0
	for projectile in _pool:
		if projectile.is_active():
			total += 1
	return total

# Drone companions fire through this pool too — exclude their rounds so tests
# about the player's own guns stay meaningful.
func active_player_count() -> int:
	var total: int = 0
	for projectile in _pool:
		if projectile.is_active() and not projectile.weapon_item_id().begins_with("DRONE-"):
			total += 1
	return total

func impact_count() -> int:
	return _impacts

func last_impact_point() -> Vector3:
	return _last_impact_point

func first_active_position() -> Vector3:
	for projectile in _pool:
		if projectile.is_active():
			return projectile.global_position
	return Vector3.ZERO

func _route_damage(projectile: Projectile) -> void:
	var damage := projectile.weapon_damage()
	if damage <= 0.0:
		return
	var collider := projectile.hit_collider
	if collider != null and collider is Node and (collider as Node).has_method("receive_damage"):
		(collider as Node).call("receive_damage", damage, projectile.hit_point,
				projectile.weapon_hull_fraction())
	var slow_factor := projectile.weapon_slow_factor()
	var slow_duration := projectile.weapon_slow_duration()
	if slow_duration > 0.0 and slow_factor < 1.0 and collider is Node \
			and (collider as Node).has_method("apply_slow"):
		(collider as Node).call("apply_slow", slow_duration, slow_factor)
	var corrosion_dps := projectile.weapon_corrosion_dps()
	if corrosion_dps > 0.0 and collider is Node \
			and (collider as Node).has_method("apply_corrosion"):
		(collider as Node).call("apply_corrosion",
				projectile.weapon_corrosion_duration(), corrosion_dps)
	if projectile.weapon_splash_radius() > 0.0:
		_apply_splash(projectile)
	_apply_chain(projectile)

# Lightning chain (WR chain-energy weapons): on an enemy hit the arc leaps to
# the nearest enemies within chain_range, half power per hop, and it will not
# cross walls (only real world geometry blocks the jump — enemy bodies are on
# their own layer). It never starts from the player hull, so incoming fire
# that strikes the shooter can not arc into their own squad.
func _apply_chain(projectile: Projectile) -> void:
	var bounces := projectile.weapon_chain_bounces()
	var radius := projectile.weapon_chain_range()
	if bounces <= 0 or radius <= 0.0:
		return
	var victim := projectile.hit_collider
	if victim == null or not (victim is Node) or not (victim as Node).is_in_group("enemy"):
		return
	var base := projectile.weapon_damage()
	if base <= 0.0:
		return
	var origin := projectile.hit_point
	var world := get_world_3d()
	if world == null:
		return
	var candidates: Array[Dictionary] = []
	for node in get_tree().get_nodes_in_group("enemy"):
		if node == victim or not (node is EnemyRobot):
			continue
		var enemy := node as EnemyRobot
		if enemy.health == null or enemy.health.dead:
			continue
		var dist := enemy.global_position.distance_to(origin)
		if dist <= radius:
			candidates.append({"node": enemy, "dist": dist})
	candidates.sort_custom(func(a: Dictionary, b: Dictionary) -> bool:
		return float(a["dist"]) < float(b["dist"]))
	var query := PhysicsRayQueryParameters3D.new()
	query.collision_mask = Layers.WORLD
	query.collide_with_areas = false
	query.collide_with_bodies = true
	query.from = origin
	var hop := 1
	for entry in candidates:
		if hop > bounces:
			break
		var target := entry["node"] as Node3D
		query.to = target.global_position + Vector3.UP * 1.0
		var wall := world.direct_space_state.intersect_ray(query)
		if not wall.is_empty():
			continue
		var jump := target.global_position + Vector3.UP * 1.0
		target.call("receive_damage", base * pow(0.5, float(hop)), jump,
				projectile.weapon_hull_fraction())
		Events.weapon_impact.emit(jump, Vector3.UP, projectile.weapon_kind())
		hop += 1

func _apply_splash(projectile: Projectile) -> void:
	var world := get_world_3d()
	if world == null:
		return
	_splash_shape.radius = projectile.weapon_splash_radius()
	var params := PhysicsShapeQueryParameters3D.new()
	params.shape = _splash_shape
	params.collision_mask = Layers.WORLD
	params.transform = Transform3D(Basis.IDENTITY, projectile.hit_point)
	params.collide_with_areas = false
	params.collide_with_bodies = true
	var direct := projectile.hit_collider
	if direct is CollisionObject3D:
		params.exclude = [(direct as CollisionObject3D).get_rid()]
	var results := world.direct_space_state.intersect_shape(params, 16)
	var splash_damage := projectile.weapon_damage() * 0.5
	if splash_damage <= 0.0:
		return
	for result in results:
		var body = result.get("collider")
		if body is Node and (body as Node).has_method("receive_damage"):
			(body as Node).call("receive_damage", splash_damage, projectile.hit_point,
					projectile.weapon_hull_fraction())

func clear() -> void:
	for projectile in _pool:
		projectile.deactivate()

func _physics_process(delta: float) -> void:
	if get_tree().paused:
		return
	var world := get_world_3d()
	if world == null:
		return
	var space := world.direct_space_state
	for projectile in _pool:
		if not projectile.is_active():
			continue
		if projectile.advance(delta, space):
			_impacts += 1
			_last_impact_point = projectile.hit_point
			Events.weapon_impact.emit(projectile.hit_point, projectile.hit_normal,
					projectile.weapon_kind())
			_route_damage(projectile)