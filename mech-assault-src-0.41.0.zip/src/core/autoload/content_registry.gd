extends Node

## Data-driven integration layer for the user's owned robot/weapon/pilot/drone
## assets. The visual/gameplay systems can ask for an asset hook without
## hard-coding project-specific filenames throughout the UI and rigs.
const CATALOG_PATH := "res://data/mech_assault_reference_12_4.json"

var _catalog: Dictionary = {}
var ready_ok: bool = false

func _ready() -> void:
	_load_catalog()

func _load_catalog() -> void:
	if not FileAccess.file_exists(CATALOG_PATH):
		push_warning("ContentRegistry: catalog missing: %s" % CATALOG_PATH)
		return
	var file := FileAccess.open(CATALOG_PATH, FileAccess.READ)
	if file == null:
		push_warning("ContentRegistry: could not open catalog")
		return
	var parsed: Variant = JSON.parse_string(file.get_as_text())
	if not (parsed is Dictionary):
		push_warning("ContentRegistry: catalog is not a JSON object")
		return
	_catalog = parsed as Dictionary
	ready_ok = true

func catalog() -> Dictionary:
	return _catalog.duplicate(true)

func section(section_name: StringName) -> Dictionary:
	var raw: Variant = _catalog.get(section_name, _catalog.get(String(section_name), {}))
	return raw as Dictionary if raw is Dictionary else {}

func profile(section_name: StringName, content_id: StringName) -> Dictionary:
	var bucket := section(section_name)
	var raw: Variant = bucket.get(content_id, bucket.get(String(content_id), {}))
	return raw as Dictionary if raw is Dictionary else {}

func robot_profile(robot_id: StringName) -> Dictionary:
	return profile(&"robots", robot_id)

func weapon_profile(weapon_id: StringName) -> Dictionary:
	return profile(&"weapons", weapon_id)

func pilot_profile(pilot_id: StringName) -> Dictionary:
	return profile(&"pilots", pilot_id)

func drone_profile(drone_id: StringName) -> Dictionary:
	return profile(&"drones", drone_id)

func asset_hooks(section_name: StringName, content_id: StringName) -> Dictionary:
	var data := profile(section_name, content_id)
	var raw: Variant = data.get("asset_hooks", {})
	return raw as Dictionary if raw is Dictionary else {}

func robot_asset_hooks(robot_id: StringName) -> Dictionary:
	return asset_hooks(&"robots", robot_id)

func weapon_asset_hooks(weapon_id: StringName) -> Dictionary:
	return asset_hooks(&"weapons", weapon_id)

func ui_asset_candidates(asset_name: StringName) -> Array[String]:
	var raw: Variant = _catalog.get("ui_assets", {})
	if not (raw is Dictionary):
		return []
	var candidates: Array[String] = []
	var values: Variant = (raw as Dictionary).get(asset_name, [])
	if values is String:
		candidates.append(values as String)
	elif values is Array:
		for value in values as Array:
			if value is String:
				candidates.append(value as String)
	return candidates

func resolve_asset(candidates: Variant) -> String:
	if candidates is String:
		var single := candidates as String
		return single if ResourceLoader.exists(single) else ""
	if not (candidates is Array):
		return ""
	for candidate in candidates as Array:
		if not (candidate is String):
			continue
		var path := candidate as String
		if ResourceLoader.exists(path):
			return path
	return ""

func resolve_hook(section_name: StringName, content_id: StringName, hook_name: StringName) -> String:
	var hooks := asset_hooks(section_name, content_id)
	var raw: Variant = hooks.get(hook_name, "")
	return resolve_asset(raw)

func resolve_robot_visual(robot_id: StringName) -> String:
	return resolve_hook(&"robots", robot_id, &"model_scene")

func resolve_weapon_visual(weapon_id: StringName) -> String:
	return resolve_hook(&"weapons", weapon_id, &"model_scene")

func resolve_ui_asset(asset_name: StringName) -> String:
	return resolve_asset(ui_asset_candidates(asset_name))

func instantiate_asset(parent: Node, path: String, node_name: StringName = &"") -> Node3D:
	if parent == null or path.is_empty():
		return null
	var packed := ResourceLoader.load(path) as PackedScene
	if packed == null:
		push_warning("ContentRegistry: asset is not an instantiable scene: %s" % path)
		return null
	var instance := packed.instantiate()
	if instance == null or not (instance is Node3D):
		if instance != null:
			instance.free()
		push_warning("ContentRegistry: visual asset must inherit Node3D: %s" % path)
		return null
	var visual := instance as Node3D
	if not node_name.is_empty():
		visual.name = node_name
	parent.add_child(visual)
	return visual

func instantiate_robot_visual(parent: Node, robot_id: StringName, node_name: StringName = &"AssetVisual") -> Node3D:
	return instantiate_asset(parent, resolve_robot_visual(robot_id), node_name)

func instantiate_ui_visual(parent: Node, asset_name: StringName, node_name: StringName = &"AssetVisual") -> Node3D:
	return instantiate_asset(parent, resolve_ui_asset(asset_name), node_name)

func integration_report() -> Dictionary:
	var report: Dictionary = {
		"catalog_loaded": ready_ok,
		"robots": 0,
		"robot_visuals_found": 0,
		"weapons": 0,
		"robot_weapons": 0,
		"titan_weapons": 0,
		"weapon_profiles_documented": 0,
		"pilots": 0,
		"drones": 0,
	}
	for robot_id in section(&"robots").keys():
		report["robots"] = int(report["robots"]) + 1
		if not resolve_robot_visual(StringName(str(robot_id))).is_empty():
			report["robot_visuals_found"] = int(report["robot_visuals_found"]) + 1
	report["weapons"] = section(&"weapons").size()
	var catalog_groups: Variant = _catalog.get("weapon_catalog", {})
	if catalog_groups is Dictionary:
		report["robot_weapons"] = (catalog_groups as Dictionary).get("robot_weapons", []).size()
		report["titan_weapons"] = (catalog_groups as Dictionary).get("titan_weapons", []).size()
	for weapon_id in section(&"weapons").keys():
		var profile_data: Dictionary = section(&"weapons").get(weapon_id, {})
		if profile_data.get("reference_status", "") in ["public_reference_snapshot", "mechanics_snapshot"]:
			report["weapon_profiles_documented"] = int(report["weapon_profiles_documented"]) + 1
	report["pilots"] = section(&"pilots").size()
	report["drones"] = section(&"drones").size()
	return report
