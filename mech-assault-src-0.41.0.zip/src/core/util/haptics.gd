class_name Haptics
extends RefCounted

static func available() -> bool:
	return OS.has_feature("mobile") or DisplayServer.is_touchscreen_available() \
			or not Input.get_connected_joypads().is_empty()

static func pulse(duration_ms: int, amplitude: float = 0.6) -> void:
	if not GameState.vibration_enabled:
		return
	if OS.has_feature("mobile") or DisplayServer.is_touchscreen_available():
		Input.vibrate_handheld(duration_ms, amplitude)
	# Wired/wireless pads rumble through the gamepad API on every platform.
	for device in Input.get_connected_joypads():
		Input.start_joy_vibration(device, amplitude * 0.5, amplitude,
				maxf(duration_ms / 1000.0, 0.05))
