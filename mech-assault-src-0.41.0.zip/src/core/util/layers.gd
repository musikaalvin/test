class_name Layers
extends RefCounted

const WORLD := 1
const PLAYER := 2
const ENEMY := 4
const PROJECTILE := 8
const PICKUP := 16
const HAZARD := 32
const LEG := 64

const WORLD_MASK := WORLD
const PLAYER_MASK := WORLD | PLAYER | ENEMY | HAZARD
const ENEMY_MASK := WORLD | PLAYER | ENEMY | ENEMY_BYPASS_OFFSET
const PROJECTILE_MASK := WORLD | PLAYER | ENEMY
const LEG_MASK := WORLD

const ENEMY_BYPASS_OFFSET := 0
