class_name Quality
extends RefCounted

enum Tier { LOW = 0, MEDIUM = 1, HIGH = 2, ULTRA = 3 }

const TIER_LABELS: Array[String] = ["LOW", "MEDIUM", "HIGH", "ULTRA"]

static var _detail_normals: Dictionary = {}

# AUTO mode: FPS-driven stepping that only ever moves within the range the
# hardware profile recommends (Hardware.recommended_tier).
static var _adapt_clock: float = 0.0
static var _adapt_low: int = 0
static var _adapt_high: int = 0
static var _last_env: Environment = null
static var _last_sun: DirectionalLight3D = null
static var _last_sun_yaw: float = 0.0

static func tier() -> int:
	return clampi(GameState.selected_quality, 0, 3)

static func tier_label() -> String:
	var label := TIER_LABELS[tier()]
	if GameState.quality_auto:
		return "AUTO·" + label
	return label

static func cycle_tier() -> int:
	# AUTO → LOW → MEDIUM → HIGH → ULTRA → AUTO
	if GameState.quality_auto:
		GameState.quality_auto = false
		GameState.selected_quality = Tier.LOW
		return tier()
	var next := tier() + 1
	if next > Tier.ULTRA:
		GameState.quality_auto = true
		GameState.selected_quality = Hardware.recommended_tier()
	else:
		GameState.selected_quality = next
	return tier()

static func tick_adaptation(delta: float) -> void:
	# Sample frame rate once a second; drop a tier after ~4 s of sustained
	# undershoot, climb back after ~15 s of comfortable headroom — never above
	# what the hardware profile recommends. Explicit user tiers are untouched.
	if not GameState.quality_auto:
		return
	_adapt_clock += delta
	if _adapt_clock < 1.0:
		return
	_adapt_clock = 0.0
	var fps := Engine.get_frames_per_second()
	if fps <= 0:
		return
	if fps < 38:
		_adapt_low += 1
		_adapt_high = 0
	elif fps > 56:
		_adapt_high += 1
		_adapt_low = 0
	else:
		_adapt_low = 0
		_adapt_high = 0
	if _adapt_low >= 4 and tier() > Tier.LOW:
		GameState.selected_quality = tier() - 1
		_adapt_low = 0
		reapply()
	elif _adapt_high >= 15 and tier() < Hardware.recommended_tier():
		GameState.selected_quality = tier() + 1
		_adapt_high = 0
		reapply()

static func reapply() -> void:
	var tree := Engine.get_main_loop() as SceneTree
	if tree != null and tree.root != null:
		apply_viewport(tree.root)
	if _last_env != null and is_instance_valid(_last_env):
		apply_environment(_last_env, _last_sun_yaw)
	if _last_sun != null and is_instance_valid(_last_sun):
		apply_sun(_last_sun)

static func apply_viewport(viewport: Viewport) -> void:
	match tier():
		Tier.LOW:
			viewport.msaa_3d = Viewport.MSAA_DISABLED
			viewport.scaling_3d_scale = 0.6
			viewport.screen_space_aa = Viewport.SCREEN_SPACE_AA_FXAA
		Tier.MEDIUM:
			viewport.msaa_3d = Viewport.MSAA_2X
			viewport.scaling_3d_scale = 0.85
			viewport.screen_space_aa = Viewport.SCREEN_SPACE_AA_FXAA
		Tier.ULTRA:
			viewport.msaa_3d = Viewport.MSAA_8X
			viewport.scaling_3d_scale = 1.0
			viewport.screen_space_aa = Viewport.SCREEN_SPACE_AA_DISABLED
		_:
			viewport.msaa_3d = Viewport.MSAA_4X
			viewport.scaling_3d_scale = 1.0
			viewport.screen_space_aa = Viewport.SCREEN_SPACE_AA_DISABLED

static func shadow_filter_quality() -> int:
	match tier():
		Tier.LOW:
			return RenderingServer.SHADOW_QUALITY_SOFT_VERY_LOW
		Tier.MEDIUM:
			return RenderingServer.SHADOW_QUALITY_SOFT_MEDIUM
		Tier.ULTRA:
			return RenderingServer.SHADOW_QUALITY_SOFT_ULTRA
		_:
			return RenderingServer.SHADOW_QUALITY_SOFT_HIGH

static func apply_sun(sun: DirectionalLight3D) -> void:
	_last_sun = sun
	RenderingServer.directional_soft_shadow_filter_set_quality(shadow_filter_quality())
	match tier():
		Tier.LOW:
			sun.shadow_enabled = false
		Tier.MEDIUM:
			sun.shadow_enabled = true
			sun.directional_shadow_max_distance = 55.0
			sun.directional_shadow_blend_splits = false
			sun.shadow_bias = 0.05
			sun.shadow_blur = 1.0
		Tier.ULTRA:
			sun.shadow_enabled = true
			sun.directional_shadow_max_distance = 160.0
			sun.directional_shadow_blend_splits = true
			sun.shadow_bias = 0.03
			sun.shadow_blur = 1.4
		_:
			sun.shadow_enabled = true
			sun.directional_shadow_max_distance = 110.0
			sun.directional_shadow_blend_splits = true
			sun.shadow_bias = 0.035
			sun.shadow_blur = 1.2

static func apply_environment(environment: Environment, sun_yaw_degrees: float = 0.0) -> void:
	_last_env = environment
	_last_sun_yaw = sun_yaw_degrees
	environment.sky_rotation = Vector3(0.0, deg_to_rad(sun_yaw_degrees), 0.0)
	environment.tonemap_mode = Environment.TONE_MAPPER_ACES
	environment.tonemap_white = 6.0
	environment.ssao_enabled = false
	environment.adjustment_enabled = true
	match tier():
		Tier.LOW:
			environment.tonemap_exposure = 1.35
			environment.adjustment_brightness = 1.08
			environment.adjustment_contrast = 1.0
			environment.adjustment_saturation = 1.0
			environment.glow_enabled = false
			environment.fog_density = 0.006
			environment.fog_sun_scatter = 0.2
			environment.fog_aerial_perspective = 0.0
		Tier.MEDIUM:
			environment.tonemap_exposure = 1.4
			environment.adjustment_brightness = 1.07
			environment.adjustment_contrast = 1.07
			environment.adjustment_saturation = 1.12
			environment.glow_enabled = true
			environment.glow_intensity = 0.65
			environment.glow_bloom = 0.08
			environment.glow_hdr_threshold = 1.0
			environment.fog_density = 0.004
			environment.fog_sun_scatter = 0.35
			environment.fog_aerial_perspective = 0.0
		Tier.ULTRA:
			environment.tonemap_exposure = 1.5
			environment.adjustment_brightness = 1.1
			environment.adjustment_contrast = 1.12
			environment.adjustment_saturation = 1.18
			environment.glow_enabled = true
			environment.glow_intensity = 1.1
			environment.glow_bloom = 0.16
			environment.glow_hdr_threshold = 0.9
			environment.fog_density = 0.002
			environment.fog_sun_scatter = 0.55
			environment.fog_aerial_perspective = 0.5
		_:
			environment.tonemap_exposure = 1.45
			environment.adjustment_brightness = 1.09
			environment.adjustment_contrast = 1.1
			environment.adjustment_saturation = 1.16
			environment.glow_enabled = true
			environment.glow_intensity = 0.9
			environment.glow_bloom = 0.13
			environment.glow_hdr_threshold = 0.95
			environment.fog_density = 0.0025
			environment.fog_sun_scatter = 0.5
			environment.fog_aerial_perspective = 0.4
	environment.fog_enabled = true
	environment.fog_light_color = Color(0.8, 0.84, 0.9)

static func make_sky() -> Sky:
	var material := ProceduralSkyMaterial.new()
	material.sky_top_color = Color(0.24, 0.46, 0.82)
	material.sky_horizon_color = Color(0.79, 0.86, 0.94)
	material.ground_horizon_color = Color(0.62, 0.65, 0.66)
	material.ground_bottom_color = Color(0.2, 0.19, 0.18)
	material.sky_energy_multiplier = 1.25
	var sky := Sky.new()
	sky.sky_material = material
	sky.radiance_size = Sky.RADIANCE_SIZE_256 if tier() >= Tier.HIGH else Sky.RADIANCE_SIZE_128
	return sky

static func decorate_material(material: StandardMaterial3D, kind: StringName, uv_scale: float = 1.0) -> void:
	if tier() < Tier.MEDIUM:
		return
	material.normal_enabled = true
	material.normal_texture = detail_normal(kind)
	material.normal_scale = 0.7
	if uv_scale != 1.0:
		material.uv1_scale = Vector3(uv_scale, uv_scale, uv_scale)

static func detail_normal(kind: StringName) -> Texture2D:
	if _detail_normals.has(kind):
		return _detail_normals[kind] as Texture2D
	const SIZE := 128
	var noise := FastNoiseLite.new()
	noise.seed = 1337
	noise.fractal_octaves = 4
	match kind:
		&"ground":
			noise.frequency = 0.06
			noise.fractal_gain = 0.55
		&"metal":
			noise.frequency = 0.14
			noise.noise_type = FastNoiseLite.TYPE_CELLULAR
		_:
			noise.frequency = 0.09
	var heights := PackedFloat32Array()
	heights.resize(SIZE * SIZE)
	for y in SIZE:
		for x in SIZE:
			var sample := noise.get_noise_2d(float(x), float(y))
			if kind == &"metal":
				sample += 0.5 * noise.get_noise_2d(float(x) * 0.2, float(y) * 3.0)
			heights[y * SIZE + x] = sample
	var image := Image.create(SIZE, SIZE, false, Image.FORMAT_RGB8)
	var strength := 5.0
	for y in SIZE:
		for x in SIZE:
			var left := heights[y * SIZE + ((x + SIZE - 1) % SIZE)]
			var right := heights[y * SIZE + ((x + 1) % SIZE)]
			var up := heights[((y + SIZE - 1) % SIZE) * SIZE + x]
			var down := heights[((y + 1) % SIZE) * SIZE + x]
			var normal := Vector3((left - right) * strength, (up - down) * strength, 1.0).normalized()
			image.set_pixel(x, y, Color(normal.x * 0.5 + 0.5, normal.y * 0.5 + 0.5, normal.z * 0.5 + 0.5))
	var texture := ImageTexture.create_from_image(image)
	_detail_normals[kind] = texture
	return texture
