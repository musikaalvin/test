class_name AssetLibrary
extends RefCounted

const ROCK_TEXTURES: Array[String] = [
	"res://assets/models/rocks/01/diffuse.tga",
	"res://assets/models/rocks/02/diffuse.tga",
	"res://assets/models/rocks/03/diffuse.tga",
	"res://assets/models/rocks/04/diffuse.tga",
	"res://assets/models/rocks/05/diffuse.tga",
]
const ROCK_NORMALS: Array[String] = [
	"res://assets/models/rocks/01/normal.tga",
	"res://assets/models/rocks/02/normal.tga",
	"res://assets/models/rocks/03/normal.tga",
	"res://assets/models/rocks/04/normal.tga",
	"res://assets/models/rocks/05/normal.tga",
]
const BUSH_TEXTURES: Array[String] = [
	"res://assets/models/nature/01/diffuse.tga",
	"res://assets/models/nature/02/diffuse.tga",
	"res://assets/models/nature/03/diffuse.tga",
	"res://assets/models/nature/04/diffuse.tga",
	"res://assets/models/nature/05/diffuse.tga",
]
const PBR_ROOT: String = "res://assets/textures/pbr/"
const PBR_SETS: Array[String] = [
	"forest_ground",
	"mud_leaves",
	"dirt",
	"rock",
	"asphalt",
]
const PBR_MAPS: Array[String] = ["albedo", "normal", "roughness", "ao"]

static var _mesh_cache: Dictionary = {}
static var _scene_cache: Dictionary = {}
static var _material_cache: Dictionary = {}
static var _pbr_cache: Dictionary = {}
# Resources SceneRouter pulled in through the quiet-moment warm-up. They sit
# outside the load() caches so a single clear_caches() drops them too.
static var _held: Dictionary = {}


static func hold(path: String, resource: Resource) -> void:
	if path.is_empty() or resource == null:
		return
	_held[path] = resource


static func is_held(path: String) -> bool:
	return _held.has(path)


static func held_resource(path: String) -> Resource:
	var resource := _held.get(path, null) as Resource
	return resource


# Frees every cached Ref (meshes, packed scenes, materials, PBR maps and the
# warm-up hold list). Called only from the menu, which never reads this
# library, so nothing can be left pointing at a freed resource.
static func clear_caches() -> void:
	_mesh_cache.clear()
	_scene_cache.clear()
	_material_cache.clear()
	_pbr_cache.clear()
	_held.clear()


static func mesh(path: String) -> Mesh:
	if _mesh_cache.has(path):
		return _mesh_cache[path] as Mesh
	var result: Mesh = null
	if ResourceLoader.exists(path):
		result = load(path) as Mesh
	_mesh_cache[path] = result
	return result


static func textured_material(albedo_path: String, normal_path: String = "",
		roughness: float = 0.9, metallic: float = 0.0,
		tint: Color = Color.WHITE, alpha_cut: bool = false) -> StandardMaterial3D:
	var key := "%s|%s|%.2f|%.2f|%s|%s" % [
			albedo_path, normal_path, roughness, metallic, tint.to_html(), alpha_cut]
	if _material_cache.has(key):
		return _material_cache[key] as StandardMaterial3D
	var material := StandardMaterial3D.new()
	material.roughness = roughness
	material.metallic = metallic
	material.albedo_color = tint
	if ResourceLoader.exists(albedo_path):
		material.albedo_texture = load(albedo_path) as Texture2D
	if normal_path != "" and ResourceLoader.exists(normal_path):
		var normal := load(normal_path) as Texture2D
		if normal != null:
			material.normal_enabled = true
			material.normal_texture = normal
			material.normal_scale = 1.4
	if alpha_cut:
		material.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA_SCISSOR
		material.alpha_scissor_threshold = 0.45
	_material_cache[key] = material
	return material


static func pbr_material(set_name: String, uv_scale: Vector2 = Vector2.ONE,
		tint: Color = Color.WHITE, roughness: float = 1.0,
		normal_strength: float = 1.0, metallic: float = 0.0) -> StandardMaterial3D:
	var key := "pbr|%s|%.3f,%.3f|%s|%.3f|%.3f|%.3f" % [
			set_name, uv_scale.x, uv_scale.y, tint.to_html(),
			roughness, normal_strength, metallic]
	if _pbr_cache.has(key):
		return _pbr_cache[key] as StandardMaterial3D
	var material := StandardMaterial3D.new()
	material.albedo_color = tint
	material.roughness = roughness
	material.metallic = metallic
	material.uv1_scale = Vector3(uv_scale.x, uv_scale.y, 1.0)
	var albedo := _pbr_texture(set_name, "albedo")
	if albedo != null:
		material.albedo_texture = albedo
	var normal := _pbr_texture(set_name, "normal")
	if normal != null and normal_strength > 0.0:
		material.normal_enabled = true
		material.normal_texture = normal
		material.normal_scale = normal_strength
	var roughness_map := _pbr_texture(set_name, "roughness")
	if roughness_map != null:
		material.roughness_texture = roughness_map
		material.roughness_texture_channel = BaseMaterial3D.TEXTURE_CHANNEL_GRAYSCALE
	var ao_map := _pbr_texture(set_name, "ao")
	if ao_map != null:
		material.ao_enabled = true
		material.ao_texture = ao_map
		material.ao_texture_channel = BaseMaterial3D.TEXTURE_CHANNEL_GRAYSCALE
		material.ao_light_affect = 0.6
	_pbr_cache[key] = material
	return material


static func pbr_set_path(set_name: String, map_name: String) -> String:
	return PBR_ROOT + set_name + "/" + map_name + ".jpg"


static func has_pbr_set(set_name: String) -> bool:
	return PBR_SETS.has(set_name) and ResourceLoader.exists(
			pbr_set_path(set_name, "albedo"))


static func _pbr_texture(set_name: String, map_name: String) -> Texture2D:
	var path := pbr_set_path(set_name, map_name)
	if not ResourceLoader.exists(path):
		return null
	return load(path) as Texture2D


static func plain_material(color: Color, roughness: float = 0.95,
		metallic: float = 0.0) -> StandardMaterial3D:
	var key := "plain|%s|%.2f|%.2f" % [color.to_html(), roughness, metallic]
	if _material_cache.has(key):
		return _material_cache[key] as StandardMaterial3D
	var material := MeshUtil.make_material(color, metallic, roughness)
	_material_cache[key] = material
	return material


static func place(parent: Node3D, path: String, pos: Vector3, target_size: float,
		yaw_degrees: float = 0.0, material: Material = null,
		collide: bool = false) -> Node3D:
	var bounds := AABB()
	var asset: Node3D = null
	var single_mesh: Mesh = null
	if path.ends_with(".glb") or path.ends_with(".gltf"):
		var packed := _packed(path)
		if packed == null:
			return null
		asset = packed.instantiate() as Node3D
		if asset == null:
			return null
		bounds = _combined_bounds(asset)
	else:
		var loaded := mesh(path)
		if loaded == null:
			return null
		single_mesh = loaded
		bounds = loaded.get_aabb()
	if bounds.size.x <= 0.0 or bounds.size.y <= 0.0 or bounds.size.z <= 0.0:
		if asset != null:
			asset.free()
		return null

	var largest := maxf(bounds.size.x, maxf(bounds.size.y, bounds.size.z))
	var scale_factor := target_size / largest
	var centre := bounds.position + bounds.size * 0.5

	var wrapper := Node3D.new()
	wrapper.name = String(path.get_file().get_basename())
	wrapper.position = pos
	wrapper.rotation.y = deg_to_rad(yaw_degrees)
	parent.add_child(wrapper)

	if single_mesh != null:
		var instance := MeshInstance3D.new()
		instance.mesh = single_mesh
		instance.scale = Vector3.ONE * scale_factor
		instance.position = Vector3(
				-centre.x * scale_factor,
				-bounds.position.y * scale_factor,
				-centre.z * scale_factor)
		if material != null:
			instance.material_override = material
		wrapper.add_child(instance)
		asset = instance
	else:
		asset.scale = Vector3.ONE * scale_factor
		asset.position = Vector3(
				-centre.x * scale_factor,
				-bounds.position.y * scale_factor,
				-centre.z * scale_factor)
		wrapper.add_child(asset)
		if material != null:
			for node in asset.find_children("*", "MeshInstance3D", true, false):
				if node is MeshInstance3D:
					(node as MeshInstance3D).material_override = material

	if collide:
		var body := StaticBody3D.new()
		body.name = "Body"
		body.collision_layer = Layers.WORLD
		body.collision_mask = Layers.WORLD
		var shape_node := CollisionShape3D.new()
		var box := BoxShape3D.new()
		box.size = bounds.size * scale_factor
		shape_node.shape = box
		# The visual was re-centred so the AABB sits at x/z 0 with its bottom at
		# y 0 in wrapper space; the shape must follow that frame, not mesh-local.
		shape_node.position = Vector3(0.0, bounds.size.y * 0.5 * scale_factor, 0.0)
		body.add_child(shape_node)
		wrapper.add_child(body)
	return wrapper


static func multimesh(parent: Node3D, path: String, points: Array,
		target_size: float, material: Material = null,
		cast_shadows: bool = false) -> MultiMeshInstance3D:
	var loaded := mesh(path)
	if loaded == null:
		return null
	var bounds := loaded.get_aabb()
	if bounds.size.x <= 0.0 or bounds.size.y <= 0.0 or bounds.size.z <= 0.0:
		return null
	var largest := maxf(bounds.size.x, maxf(bounds.size.y, bounds.size.z))
	var scale_factor := target_size / largest
	var centre := bounds.position + bounds.size * 0.5

	var multi := MultiMesh.new()
	multi.transform_format = MultiMesh.TRANSFORM_3D
	multi.mesh = loaded
	multi.instance_count = points.size()
	for index in points.size():
		var data: Array = points[index]
		var origin: Vector3 = data[0]
		var yaw := deg_to_rad(float(data[1])) if data.size() > 1 else 0.0
		var yaw_basis := Basis(Vector3.UP, yaw)
		var instance_scale := scale_factor * (float(data[2]) if data.size() > 2 else 1.0)
		var offset := yaw_basis * (Vector3(
				-centre.x, -bounds.position.y, -centre.z) * instance_scale)
		multi.set_instance_transform(index, Transform3D(
				yaw_basis.scaled(Vector3.ONE * instance_scale), origin + offset))

	var instance := MultiMeshInstance3D.new()
	instance.name = String(path.get_file().get_basename()) + "_mm"
	instance.multimesh = multi
	if material != null:
		instance.material_override = material
	if not cast_shadows:
		instance.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	parent.add_child(instance)
	return instance


static func _packed(path: String) -> PackedScene:
	if _scene_cache.has(path):
		return _scene_cache[path] as PackedScene
	var packed: PackedScene = null
	if ResourceLoader.exists(path):
		packed = load(path) as PackedScene
	_scene_cache[path] = packed
	return packed


static func _combined_bounds(root: Node3D) -> AABB:
	var result := AABB()
	var has_result := false
	for node in root.find_children("*", "MeshInstance3D", true, false):
		if not (node is MeshInstance3D):
			continue
		var instance := node as MeshInstance3D
		if instance.mesh == null:
			continue
		var transform := instance.transform
		var walk := instance.get_parent()
		while walk != null and walk != root:
			var node_3d := walk as Node3D
			if node_3d != null:
				transform = node_3d.transform * transform
			walk = walk.get_parent()
		var corners := instance.mesh.get_aabb()
		for endpoint in 8:
			var point := transform * corners.get_endpoint(endpoint)
			if not has_result:
				result = AABB(point, Vector3.ZERO)
				has_result = true
			else:
				result = result.expand(point)
	return result
