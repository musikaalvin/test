class_name PlatformUtil
extends RefCounted

# Real OS/platform detection (not screen size) plus live input-mode tracking.
# The mode tells the UI which control scheme to present: the touch rig, the
# keyboard hint strip, or controller glyphs. Input is only OBSERVED here,
# never consumed, so gameplay behaviour is untouched.

enum InputMode { TOUCH, KEYBOARD, GAMEPAD }

# Look / fire bindings live here so the hint text and InputRouter read one
# single source of truth (InputRouter already depends on this class).
const MOUSE_LOOK_BUTTON: MouseButton = MOUSE_BUTTON_RIGHT
const PAD_LOOK_AXIS_X: JoyAxis = JOY_AXIS_RIGHT_X
const PAD_LOOK_AXIS_Y: JoyAxis = JOY_AXIS_RIGHT_Y
const PAD_TRIGGER_FIRE_AXIS: JoyAxis = JOY_AXIS_TRIGGER_RIGHT
const MOVE_ACTIONS: Array[StringName] = [
	&"move_forward", &"move_left", &"move_back", &"move_right"]
const DPAD_LABELS: Array[String] = ["UP", "DOWN", "LEFT", "RIGHT"]
const HINT_JOIN := "  ·  "

const TOUCH_GRACE_MS := 400		# a tap's emulated mouse twin lands inside this
const MOUSE_LOCK_MS := 3000		# keyboard/mouse evidence keeps a PC out of touch
const PAD_SWITCH_DEADZONE := 0.3	# stick travel before a pad counts as used

static var current_mode: int = InputMode.TOUCH
static var _initialised: bool = false
static var _last_touch_ms: int = -100000
static var _last_desktop_ms: int = -100000

static func os_name() -> String:
	return OS.get_name()

static func is_windows() -> bool:
	return os_name() == "Windows"

static func is_android() -> bool:
	return os_name() == "Android"

static func is_ios() -> bool:
	return os_name() == "iOS"

static func is_desktop() -> bool:
	var name := os_name()
	return name == "Windows" or name == "Linux" or name == "macOS" \
			or name == "FreeBSD" or name == "X11" or name == "Wayland"

static func is_mobile_platform() -> bool:
	return is_android() or is_ios()

static func is_headless() -> bool:
	# --headless runs the headless DisplayServer. OS.has_feature("headless")
	# would also be true for a plain PC export, so never use it here: smoke
	# must always see the full touch rig.
	return DisplayServer.get_name() == "headless"

static func has_touch() -> bool:
	return DisplayServer.is_touchscreen_available()

static func pad_connected() -> bool:
	return not Input.get_connected_joypads().is_empty()

static func detect_mode() -> int:
	if is_headless():
		return InputMode.TOUCH
	if is_mobile_platform():
		return InputMode.TOUCH	# a phone is touch-first even with a pad paired
	if pad_connected():
		return InputMode.GAMEPAD
	# Desktop starts on keys/mouse. A genuine touchscreen can still flip it to
	# TOUCH in observe_event(), but a plain PC never sees the touch rig.
	return InputMode.KEYBOARD

static func prefers_touch_ui() -> bool:
	# The platform's AUTO rule, unchanged in spirit: headless (smoke) and
	# Android always get the touch rig, a plain desktop never does.
	return detect_mode() == InputMode.TOUCH

static func init() -> void:
	if _initialised:
		return
	_initialised = true
	current_mode = detect_mode()

static func set_mode(mode: int, force: bool = false) -> void:
	if mode == current_mode and not force:
		return
	current_mode = mode
	Events.mode_changed.emit(mode)

static func refresh_settings() -> void:
	# A CONTROLS override changed: listeners key off GameState.input_ui_mode
	# as well as current_mode, so nudge them all (force, no-op guard).
	set_mode(current_mode, true)

static func effective_mode() -> int:
	if GameState.input_ui_mode == GameState.UiMode.FORCE_TOUCH:
		return InputMode.TOUCH
	if GameState.input_ui_mode == GameState.UiMode.FORCE_OFF:
		return InputMode.KEYBOARD if current_mode == InputMode.TOUCH \
				else current_mode
	return current_mode

static func observe_event(event: InputEvent) -> void:
	if is_headless() or is_mobile_platform():
		return	# smoke stays TOUCH; a phone's touch rig never flickers off
	var now := Time.get_ticks_msec()
	if event is InputEventScreenTouch:
		var touch := event as InputEventScreenTouch
		if not touch.pressed:
			return
		# emulate_touch_from_mouse fires on every desktop click, so a touch
		# only counts on hardware that really reports a touchscreen, and only
		# while nothing points at the machine with keys/mouse.
		if not has_touch():
			return
		if Input.is_mouse_button_pressed(MOUSE_BUTTON_LEFT) \
				or Input.is_mouse_button_pressed(MOUSE_BUTTON_RIGHT) \
				or Input.is_mouse_button_pressed(MOUSE_BUTTON_MIDDLE):
			return	# the mouse owns this press
		if now - _last_desktop_ms < MOUSE_LOCK_MS:
			return	# a keyboard/mouse user — do not steal their UI
		_last_touch_ms = now
		set_mode(InputMode.TOUCH)
	elif event is InputEventMouseButton:
		_last_desktop_ms = now
		if now - _last_touch_ms < TOUCH_GRACE_MS:
			return	# emulate_mouse_from_touch: the tap already won
		set_mode(InputMode.KEYBOARD)
	elif event is InputEventKey:
		if (event as InputEventKey).pressed:
			_last_desktop_ms = now
			set_mode(InputMode.KEYBOARD)
	elif event is InputEventJoypadButton:
		if (event as InputEventJoypadButton).pressed:
			set_mode(InputMode.GAMEPAD)
	elif event is InputEventJoypadMotion:
		if absf((event as InputEventJoypadMotion).axis_value) >= PAD_SWITCH_DEADZONE:
			set_mode(InputMode.GAMEPAD)

# ---------------------------------------------------------------- control text

static func label() -> String:
	if is_android():
		return "ANDROID"
	if is_windows():
		return "WINDOWS"
	return os_name().to_upper()

static func mode_label() -> String:
	match effective_mode():
		InputMode.KEYBOARD:
			return "KEYS"
		InputMode.GAMEPAD:
			return "PAD"
		_:
			return "TOUCH"

static func activate_verb() -> String:
	match effective_mode():
		InputMode.KEYBOARD:
			return "CLICK"
		InputMode.GAMEPAD:
			return "SELECT"
		_:
			return "TAP"

static func accept_badge() -> String:
	return badge_for(&"ui_accept")

static func cancel_badge() -> String:
	var mode := effective_mode()
	if mode == InputMode.TOUCH:
		return ""
	if mode == InputMode.GAMEPAD:
		# B is the console "back" convention (bound alongside SELECT).
		var pad_label := _joy_button_label(&"ui_cancel", JOY_BUTTON_B)
		if pad_label.is_empty():
			pad_label = _first_joy_label(&"ui_cancel")
		return pad_label
	return _first_key_label(&"ui_cancel")

static func badge_for(action: StringName) -> String:
	var mode := effective_mode()
	if mode == InputMode.TOUCH:
		return ""
	if mode == InputMode.GAMEPAD:
		return _first_joy_label(action)
	return _first_key_label(action)

static func input_hint_lines(ability_label: String = "",
		secondary_label: String = "") -> PackedStringArray:
	# Text is always derived from InputMap: never invent a key that is not
	# actually bound. Touch keeps its one fixed line; keyboard and pad get a
	# pair built from the real bindings plus the robot's ability names.
	var ability := ability_label.strip_edges()
	if ability.is_empty():
		ability = "ABILITY"
	var secondary := secondary_label.strip_edges()
	match effective_mode():
		InputMode.TOUCH:
			return PackedStringArray([
					"STICK MOVE · DRAG LOOK · TAP SEGMENT = ONE GUN · RED = ALL · X = LOCK"])
		InputMode.GAMEPAD:
			return _pad_hint_lines(ability, secondary)
		_:
			return _keyboard_hint_lines(ability, secondary)

static func _keyboard_hint_lines(ability: String, secondary: String) -> PackedStringArray:
	var line_one := PackedStringArray()
	var move_keys := _move_keys_text()
	if not move_keys.is_empty():
		line_one.append("%s MOVE" % move_keys)
	var look_mouse := _mouse_button_text(MOUSE_LOOK_BUTTON)
	if not look_mouse.is_empty():
		line_one.append("%s DRAG LOOK" % look_mouse)
	var fire_keys := _keys_text(&"fire")
	var fire_mice := _mouse_buttons_text(&"fire")
	var fire := fire_keys
	if fire.is_empty():
		fire = fire_mice
	elif not fire_mice.is_empty():
		fire = "%s / %s" % [fire_keys, fire_mice]
	if not fire.is_empty():
		line_one.append("%s FIRE" % fire)
	var ability_keys := _keys_text(&"ability")
	if not ability_keys.is_empty():
		line_one.append("%s %s" % [ability_keys, ability])

	var line_two := PackedStringArray()
	var group_one := _first_key_label(&"weapon_1")
	var group_two := _first_key_label(&"weapon_2")
	if not group_one.is_empty() and not group_two.is_empty():
		line_two.append("%s / %s WEAPON GROUPS" % [group_one, group_two])
	if not secondary.is_empty():
		var secondary_keys := _keys_text(&"secondary_ability")
		if not secondary_keys.is_empty():
			line_two.append("%s %s" % [secondary_keys, secondary])
	var lock_key := _first_key_label(&"lock_cycle")
	if not lock_key.is_empty():
		line_two.append("%s LOCK" % lock_key)
	var restart_key := _first_key_label(&"restart")
	if not restart_key.is_empty():
		line_two.append("%s RESTART" % restart_key)
	var pause_key := _first_key_label(&"pause")
	if not pause_key.is_empty():
		line_two.append("%s PAUSE" % pause_key)
	return _pack_lines(line_one, line_two)

static func _pad_hint_lines(ability: String, secondary: String) -> PackedStringArray:
	var line_one := PackedStringArray()
	var move_axis := _first_axis_label(&"move_forward")
	if move_axis.is_empty():
		# Movement is polled raw (not bound) so a mis-centred pad can't drive
		# the robot; the hint still points at the left stick.
		move_axis = _joy_axis_text(JOY_AXIS_LEFT_X)
	if not move_axis.is_empty():
		line_one.append("%s MOVE" % move_axis)
	var look_axis := _joy_axis_text(PAD_LOOK_AXIS_X)
	if not look_axis.is_empty():
		line_one.append("%s LOOK" % look_axis)
	var fire_buttons := _first_joy_label(&"fire")
	var trigger := _joy_axis_text(PAD_TRIGGER_FIRE_AXIS)
	var fire := fire_buttons
	if fire.is_empty():
		fire = trigger
	elif not trigger.is_empty():
		fire = "%s / %s" % [fire_buttons, trigger]
	if not fire.is_empty():
		line_one.append("%s FIRE" % fire)
	var ability_button := _first_joy_label(&"ability")
	if not ability_button.is_empty():
		line_one.append("%s %s" % [ability_button, ability])

	var line_two := PackedStringArray()
	var group_one := _first_joy_label(&"weapon_1")
	var group_two := _first_joy_label(&"weapon_2")
	if not group_one.is_empty() and not group_two.is_empty():
		line_two.append("%s / %s WEAPON GROUPS" % [group_one, group_two])
	if not secondary.is_empty():
		var secondary_button := _first_joy_label(&"secondary_ability")
		if not secondary_button.is_empty():
			line_two.append("%s %s" % [secondary_button, secondary])
	var lock_button := _first_joy_label(&"lock_cycle")
	if not lock_button.is_empty():
		line_two.append("%s LOCK" % lock_button)
	var pause_button := _first_joy_label(&"pause")
	if not pause_button.is_empty():
		line_two.append("%s PAUSE" % pause_button)
	return _pack_lines(line_one, line_two)

static func _pack_lines(line_one: PackedStringArray,
		line_two: PackedStringArray) -> PackedStringArray:
	var lines := PackedStringArray([HINT_JOIN.join(line_one)])
	if not line_two.is_empty():
		lines.append(HINT_JOIN.join(line_two))
	return lines

# ---------------------------------------------------------------- InputMap reads

static func _move_keys_text() -> String:
	var text := ""
	for action: StringName in MOVE_ACTIONS:
		text += _first_key_label(action)
	return text

static func _keys_text(action: StringName) -> String:
	var labels := PackedStringArray()
	if not InputMap.has_action(action):
		return ""
	for event in InputMap.action_get_events(action):
		if event is InputEventKey:
			labels.append(_key_text(event as InputEventKey))
	return " / ".join(labels)

static func _mouse_buttons_text(action: StringName) -> String:
	var labels := PackedStringArray()
	if not InputMap.has_action(action):
		return ""
	for event in InputMap.action_get_events(action):
		if event is InputEventMouseButton:
			labels.append(_mouse_button_text((event as InputEventMouseButton).button_index))
	return " / ".join(labels)

static func _first_key_label(action: StringName) -> String:
	if not InputMap.has_action(action):
		return ""
	for event in InputMap.action_get_events(action):
		if event is InputEventKey:
			return _key_text(event as InputEventKey)
	return ""

static func _first_joy_label(action: StringName) -> String:
	if not InputMap.has_action(action):
		return ""
	for event in InputMap.action_get_events(action):
		if event is InputEventJoypadButton:
			return _joy_button_text((event as InputEventJoypadButton).button_index)
	return ""

static func _joy_button_label(action: StringName, button: JoyButton) -> String:
	if not InputMap.has_action(action):
		return ""
	for event in InputMap.action_get_events(action):
		if event is InputEventJoypadButton \
				and (event as InputEventJoypadButton).button_index == button:
			return _joy_button_text(button)
	return ""

static func _first_axis_label(action: StringName) -> String:
	if not InputMap.has_action(action):
		return ""
	for event in InputMap.action_get_events(action):
		if event is InputEventJoypadMotion:
			return _joy_axis_text((event as InputEventJoypadMotion).axis)
	return ""

static func _key_text(event: InputEventKey) -> String:
	var keycode := event.physical_keycode
	if keycode == KEY_NONE:
		keycode = event.keycode
	if keycode == KEY_NONE:
		return ""
	var text := OS.get_keycode_string(keycode).to_upper()
	if text == "ESCAPE":
		return "ESC"
	return text

static func _mouse_button_text(button: MouseButton) -> String:
	match button:
		MOUSE_BUTTON_LEFT:
			return "LMB"
		MOUSE_BUTTON_RIGHT:
			return "RMB"
		MOUSE_BUTTON_MIDDLE:
			return "MMB"
		MOUSE_BUTTON_WHEEL_UP:
			return "WHEEL UP"
		MOUSE_BUTTON_WHEEL_DOWN:
			return "WHEEL DOWN"
		_:
			return ""

static func _joy_button_text(button: JoyButton) -> String:
	match button:
		JOY_BUTTON_A:
			return "A"
		JOY_BUTTON_B:
			return "B"
		JOY_BUTTON_X:
			return "X"
		JOY_BUTTON_Y:
			return "Y"
		JOY_BUTTON_LEFT_SHOULDER:
			return "LB"
		JOY_BUTTON_RIGHT_SHOULDER:
			return "RB"
		JOY_BUTTON_LEFT_STICK:
			return "L3"
		JOY_BUTTON_RIGHT_STICK:
			return "R3"
		JOY_BUTTON_START:
			return "START"
		JOY_BUTTON_BACK:
			return "SELECT"
		JOY_BUTTON_GUIDE:
			return "GUIDE"
		JOY_BUTTON_TOUCHPAD:
			return "TOUCHPAD"
		_:
			if button >= JOY_BUTTON_DPAD_UP and button <= JOY_BUTTON_DPAD_RIGHT:
				return "D-%s" % DPAD_LABELS[int(button) - int(JOY_BUTTON_DPAD_UP)]
			return ""

static func _joy_axis_text(axis: JoyAxis) -> String:
	match axis:
		JOY_AXIS_LEFT_X, JOY_AXIS_LEFT_Y:
			return "LS"
		JOY_AXIS_RIGHT_X, JOY_AXIS_RIGHT_Y:
			return "RS"
		JOY_AXIS_TRIGGER_LEFT:
			return "LT"
		JOY_AXIS_TRIGGER_RIGHT:
			return "RT"
		_:
			return ""
