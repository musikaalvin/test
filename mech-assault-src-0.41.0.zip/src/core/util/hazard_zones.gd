class_name HazardZones
extends RefCounted

# Liquid hazard registry (drowning / magma pools). Arenas register their zones
# while building; player and enemies tick against them every physics frame.

static var zones: Array[Dictionary] = []

static func clear() -> void:
	zones.clear()

static func add(centre: Vector2, radius: float, level: float, dps: float,
		kind: StringName = &"water") -> void:
	zones.append({
		"centre": centre,
		"radius": radius,
		"level": level,
		"dps": dps,
		"kind": kind,
	})

static func zone_at(position: Vector3) -> Dictionary:
	var point := Vector2(position.x, position.z)
	for zone in zones:
		if point.distance_to(zone["centre"]) <= float(zone["radius"]) \
				and position.y < float(zone["level"]) + 0.4:
			return zone
	return {}

static func is_hazard(position: Vector3) -> bool:
	return not zone_at(position).is_empty()
