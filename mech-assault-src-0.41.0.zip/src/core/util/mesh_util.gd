class_name MeshUtil
extends RefCounted

const SEGMENTS_LOW := 8
const SEGMENTS_MED := 12

static func make_material(color: Color, metallic: float = 0.0, roughness: float = 0.8,
		emission: Color = Color.BLACK, emission_energy: float = 0.0) -> StandardMaterial3D:
	var material := StandardMaterial3D.new()
	material.albedo_color = color
	material.metallic = metallic
	material.roughness = roughness
	if emission_energy > 0.0:
		material.emission_enabled = true
		material.emission = emission
		material.emission_energy_multiplier = emission_energy
	return material

static func make_box(size: Vector3, material: Material, name_hint: String = "box") -> MeshInstance3D:
	var mesh := BoxMesh.new()
	mesh.size = size
	return _mesh_instance(mesh, material, name_hint)

static func make_cylinder(radius: float, height: float, material: Material,
		radial_segments: int = SEGMENTS_LOW, name_hint: String = "cyl") -> MeshInstance3D:
	var mesh := CylinderMesh.new()
	mesh.top_radius = radius
	mesh.bottom_radius = radius
	mesh.height = height
	mesh.radial_segments = radial_segments
	mesh.rings = 1
	return _mesh_instance(mesh, material, name_hint)

static func make_cone(bottom_radius: float, top_radius: float, height: float, material: Material,
		radial_segments: int = SEGMENTS_LOW, name_hint: String = "cone") -> MeshInstance3D:
	var mesh := CylinderMesh.new()
	mesh.bottom_radius = bottom_radius
	mesh.top_radius = top_radius
	mesh.height = height
	mesh.radial_segments = radial_segments
	mesh.rings = 1
	return _mesh_instance(mesh, material, name_hint)

static func make_sphere(radius: float, material: Material, radial_segments: int = SEGMENTS_LOW,
		rings: int = 6, name_hint: String = "sphere") -> MeshInstance3D:
	var mesh := SphereMesh.new()
	mesh.radius = radius
	mesh.height = radius * 2.0
	mesh.radial_segments = radial_segments
	mesh.rings = rings
	return _mesh_instance(mesh, material, name_hint)

static func make_capsule(radius: float, height: float, material: Material,
		radial_segments: int = SEGMENTS_LOW, name_hint: String = "capsule") -> MeshInstance3D:
	var mesh := CapsuleMesh.new()
	mesh.radius = radius
	mesh.height = maxf(height, radius * 2.0 + 0.01)
	mesh.radial_segments = radial_segments
	mesh.rings = 4
	return _mesh_instance(mesh, material, name_hint)

static func _mesh_instance(mesh: Mesh, material: Material, name_hint: String) -> MeshInstance3D:
	var instance := MeshInstance3D.new()
	instance.name = name_hint
	instance.mesh = mesh
	if material != null:
		instance.material_override = material
	instance.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_ON
	return instance

static func segment_basis(direction: Vector3) -> Basis:
	var y_axis := direction
	if y_axis.length_squared() < 0.000001:
		y_axis = Vector3.UP
	y_axis = y_axis.normalized()
	var x_axis := Vector3.FORWARD.cross(y_axis)
	if x_axis.length_squared() < 0.0001:
		x_axis = Vector3.RIGHT.cross(y_axis)
	x_axis = x_axis.normalized()
	var z_axis := x_axis.cross(y_axis).normalized()
	return Basis(x_axis, y_axis, z_axis)

static func segment_transform(from: Vector3, to: Vector3) -> Transform3D:
	var delta := to - from
	var length := delta.length()
	if length < 0.0001:
		return Transform3D(Basis(), from)
	var basis := segment_basis(delta / length)
	basis = basis.scaled(Vector3(1.0, length, 1.0))
	return Transform3D(basis, (from + to) * 0.5)

static func look_rotation_basis(forward: Vector3, up: Vector3) -> Basis:
	var z_axis := -forward
	if z_axis.length_squared() < 0.000001:
		return Basis()
	z_axis = z_axis.normalized()
	var x_axis := up.cross(z_axis)
	if x_axis.length_squared() < 0.0001:
		x_axis = Vector3.RIGHT.cross(z_axis)
	x_axis = x_axis.normalized()
	var y_axis := z_axis.cross(x_axis).normalized()
	return Basis(x_axis, y_axis, z_axis)

static func add_box_body(parent: Node3D, size: Vector3, position: Vector3, material: Material,
		collision_layer: int = 1, collision_mask: int = 1, yaw_degrees: float = 0.0,
		name_hint: String = "box_body") -> StaticBody3D:
	var body := StaticBody3D.new()
	body.name = name_hint
	body.collision_layer = collision_layer
	body.collision_mask = collision_mask
	body.position = position
	body.rotation_degrees.y = yaw_degrees
	var visual := make_box(size, material, "visual")
	body.add_child(visual)
	var shape := CollisionShape3D.new()
	var box_shape := BoxShape3D.new()
	box_shape.size = size
	shape.shape = box_shape
	body.add_child(shape)
	parent.add_child(body)
	return body

static func add_visual_box(parent: Node3D, size: Vector3, position: Vector3, material: Material,
		yaw_degrees: float = 0.0, name_hint: String = "box") -> MeshInstance3D:
	var visual := make_box(size, material, name_hint)
	visual.position = position
	visual.rotation_degrees.y = yaw_degrees
	parent.add_child(visual)
	return visual

static func add_visual_cylinder(parent: Node3D, radius: float, height: float, position: Vector3,
		material: Material, axis: Vector3 = Vector3.UP,
		name_hint: String = "cyl") -> MeshInstance3D:
	var visual := make_cylinder(radius, height, material, SEGMENTS_LOW, name_hint)
	parent.add_child(visual)
	visual.position = position
	visual.basis = segment_basis(axis)
	return visual

static func add_visual_cone(parent: Node3D, bottom_radius: float, top_radius: float, height: float,
		position: Vector3, material: Material, radial_segments: int = SEGMENTS_LOW,
		name_hint: String = "cone") -> MeshInstance3D:
	var visual := make_cone(bottom_radius, top_radius, height, material, radial_segments, name_hint)
	visual.position = position
	parent.add_child(visual)
	return visual

static func add_visual_sphere(parent: Node3D, radius: float, position: Vector3, material: Material,
		radial_segments: int = SEGMENTS_LOW, rings: int = 6,
		name_hint: String = "sphere") -> MeshInstance3D:
	var visual := make_sphere(radius, material, radial_segments, rings, name_hint)
	visual.position = position
	parent.add_child(visual)
	return visual
static func box_at(parent: Node3D, size: Vector3, pos: Vector3, rot_deg: Vector3,
		material: Material, node_name: String) -> MeshInstance3D:
	var mesh_instance := make_box(size, material, node_name)
	parent.add_child(mesh_instance)
	mesh_instance.position = pos
	mesh_instance.rotation_degrees = rot_deg
	return mesh_instance

static func cyl_at(parent: Node3D, radius: float, height: float, pos: Vector3, rot_deg: Vector3,
		material: Material, node_name: String) -> MeshInstance3D:
	var mesh_instance := make_cylinder(radius, height, material, SEGMENTS_LOW, node_name)
	parent.add_child(mesh_instance)
	mesh_instance.position = pos
	mesh_instance.rotation_degrees = rot_deg
	return mesh_instance

static func sph_at(parent: Node3D, radius: float, pos: Vector3, material: Material,
		node_name: String) -> MeshInstance3D:
	var mesh_instance := make_sphere(radius, material, SEGMENTS_LOW, 5, node_name)
	parent.add_child(mesh_instance)
	mesh_instance.position = pos
	return mesh_instance

static func cone_at(parent: Node3D, bottom_radius: float, top_radius: float, height: float,
		pos: Vector3, rot_deg: Vector3, material: Material, node_name: String) -> MeshInstance3D:
	var mesh_instance := make_cone(bottom_radius, top_radius, height, material, SEGMENTS_LOW, node_name)
	parent.add_child(mesh_instance)
	mesh_instance.position = pos
	mesh_instance.rotation_degrees = rot_deg
	return mesh_instance

static func make_bevel_box(size: Vector3, bevel: float, material: Material,
		name_hint: String = "bevel") -> MeshInstance3D:
	var b := clampf(bevel, 0.001, minf(size.x, minf(size.y, size.z)) * 0.45)
	var hx := size.x * 0.5
	var hy := size.y * 0.5
	var hz := size.z * 0.5
	var ix := hx - b
	var iy := hy - b
	var iz := hz - b
	var st := SurfaceTool.new()
	st.begin(Mesh.PRIMITIVE_TRIANGLES)
	var axes: Array[Vector3] = [Vector3.RIGHT, Vector3.UP, Vector3.FORWARD]
	var halves: Array[float] = [hx, hy, hz]
	var inners: Array[float] = [ix, iy, iz]
	for axis in 3:
		for sign in [1.0, -1.0]:
			var n: Vector3 = axes[axis] * sign
			var other := (axis + 1) % 3
			var third := (axis + 2) % 3
			var u := axes[other]
			var v := axes[third]
			if sign < 0.0:
				v = -v
			var center := n * halves[axis]
			var a := halves[other]
			var c := halves[third]
			_emit_quad(st, [
				center + u * a + v * c,
				center + u * a - v * c,
				center - u * a - v * c,
				center - u * a + v * c,
			], n)
	for pair in _bevel_edge_pairs():
		var axis1: int = pair.x
		var axis2: int = pair.y
		var axis3 := 3 - axis1 - axis2
		for s1 in [1.0, -1.0]:
			for s2 in [1.0, -1.0]:
				var n1 := Vector3.ZERO
				n1[axis1] = s1
				n1[axis2] = s2
				var normal := n1.normalized()
				var p: Array[Vector3] = []
				for s3 in [1.0, -1.0]:
					var full := Vector3.ZERO
					full[axis1] = s1 * halves[axis1]
					full[axis2] = s2 * inners[axis2]
					full[axis3] = s3 * inners[axis3]
					var inner := Vector3.ZERO
					inner[axis1] = s1 * inners[axis1]
					inner[axis2] = s2 * halves[axis2]
					inner[axis3] = s3 * inners[axis3]
					p.append(full)
					p.append(inner)
				_emit_quad(st, [p[0], p[2], p[3], p[1]], normal)
	for sx in [1.0, -1.0]:
		for sy in [1.0, -1.0]:
			for sz in [1.0, -1.0]:
				var normal := Vector3(sx, sy, sz).normalized()
				var a := Vector3(sx * hx, sy * iy, sz * iz)
				var bpt := Vector3(sx * ix, sy * hy, sz * iz)
				var cpt := Vector3(sx * ix, sy * iy, sz * hz)
				_emit_triangle(st, [a, bpt, cpt], normal)
	st.generate_tangents()
	return _mesh_instance(st.commit(), material, name_hint)

static func _bevel_edge_pairs() -> Array[Vector2i]:
	return [
		Vector2i(0, 1), Vector2i(1, 2), Vector2i(2, 0),
	]

static func _project_uv(normal: Vector3, p: Vector3) -> Vector2:
	var ax := absf(normal.x)
	var ay := absf(normal.y)
	var az := absf(normal.z)
	if ax >= ay and ax >= az:
		return Vector2(p.y, p.z)
	if ay >= az:
		return Vector2(p.x, p.z)
	return Vector2(p.x, p.y)

static func _emit_quad(st: SurfaceTool, corners: Array[Vector3], normal: Vector3) -> void:
	var p0 := corners[0]
	var p1 := corners[1]
	var p2 := corners[2]
	var p3 := corners[3]
	var cross := (p1 - p0).cross(p2 - p0)
	if cross.dot(normal) > 0.0:
		var tmp := p1
		p1 = p3
		p3 = tmp
	_emit_triangle(st, [p0, p1, p2], normal)
	_emit_triangle(st, [p0, p2, p3], normal)

static func _emit_triangle(st: SurfaceTool, points: Array[Vector3], normal: Vector3) -> void:
	var p0 := points[0]
	var p1 := points[1]
	var p2 := points[2]
	if (p1 - p0).cross(p2 - p0).dot(normal) > 0.0:
		var tmp := p1
		p1 = p2
		p2 = tmp
	for point in [p0, p1, p2]:
		st.set_normal(normal)
		st.set_uv(_project_uv(normal, point))
		st.add_vertex(point)

static func make_wedge(size: Vector3, material: Material,
		name_hint: String = "wedge") -> MeshInstance3D:
	var hx := size.x * 0.5
	var hy := size.y * 0.5
	var hz := size.z * 0.5
	var st := SurfaceTool.new()
	st.begin(Mesh.PRIMITIVE_TRIANGLES)
	_emit_quad(st, [
		Vector3(-hx, -hy, hz), Vector3(hx, -hy, hz),
		Vector3(hx, -hy, -hz), Vector3(-hx, -hy, -hz),
	], Vector3.DOWN)
	_emit_quad(st, [
		Vector3(-hx, hy, -hz), Vector3(hx, hy, -hz),
		Vector3(hx, -hy, -hz), Vector3(-hx, -hy, -hz),
	], Vector3(0.0, 0.0, -1.0))
	_emit_triangle(st, [
		Vector3(-hx, hy, -hz), Vector3(-hx, -hy, -hz), Vector3(-hx, -hy, hz),
	], Vector3.LEFT)
	_emit_triangle(st, [
		Vector3(hx, hy, -hz), Vector3(hx, -hy, hz), Vector3(hx, -hy, -hz),
	], Vector3.RIGHT)
	var slope_normal := Vector3(0.0, hz * 2.0, hy * 2.0).normalized()
	_emit_quad(st, [
		Vector3(-hx, hy, -hz), Vector3(hx, hy, -hz),
		Vector3(hx, -hy, hz), Vector3(-hx, -hy, hz),
	], slope_normal)
	st.generate_tangents()
	return _mesh_instance(st.commit(), material, name_hint)

static func bevel_at(parent: Node3D, size: Vector3, pos: Vector3, rot_deg: Vector3,
		material: Material, node_name: String, bevel: float = 0.03) -> MeshInstance3D:
	var mesh_instance := make_bevel_box(size, bevel, material, node_name)
	parent.add_child(mesh_instance)
	mesh_instance.position = pos
	mesh_instance.rotation_degrees = rot_deg
	return mesh_instance

static func wedge_at(parent: Node3D, size: Vector3, pos: Vector3, rot_deg: Vector3,
		material: Material, node_name: String) -> MeshInstance3D:
	var mesh_instance := make_wedge(size, material, node_name)
	parent.add_child(mesh_instance)
	mesh_instance.position = pos
	mesh_instance.rotation_degrees = rot_deg
	return mesh_instance
