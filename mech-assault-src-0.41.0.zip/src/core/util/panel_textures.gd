class_name PanelTextures
extends RefCounted

static var _cache: Dictionary = {}

static func apply(material: StandardMaterial3D, kind: StringName,
		uv_scale: float = 1.0) -> void:
	var textures := get_textures(kind)
	material.albedo_texture = textures[&"albedo"] as Texture2D
	material.roughness_texture = textures[&"rough"] as Texture2D
	material.normal_enabled = true
	material.normal_texture = textures[&"normal"] as Texture2D
	material.normal_scale = 0.7
	material.uv1_scale = Vector3(uv_scale, uv_scale, 1.0)

static func get_textures(kind: StringName) -> Dictionary:
	if _cache.has(kind):
		return _cache[kind]
	var built := _build(kind)
	_cache[kind] = built
	return built

static func _noise(seed_value: int, frequency: float, octaves: int) -> FastNoiseLite:
	var noise := FastNoiseLite.new()
	noise.seed = seed_value
	noise.frequency = frequency
	noise.fractal_octaves = octaves
	return noise

static func _hash(cell_x: int, cell_y: int, salt: int) -> int:
	var value := cell_x * 73856093 ^ cell_y * 19349663 ^ salt * 83492791
	return absi(value) % 1000

static func _build(kind: StringName) -> Dictionary:
	const SIZE := 192
	const CELL := 48
	var heights := PackedFloat32Array()
	heights.resize(SIZE * SIZE)
	var grain := PackedFloat32Array()
	grain.resize(SIZE * SIZE)
	var tones := PackedFloat32Array()
	tones.resize(SIZE * SIZE)
	var flags := PackedInt32Array()
	flags.resize(SIZE * SIZE)
	var grit := _noise(4211, 0.11, 4)
	var grime := _noise(907, 0.021, 3)
	var streaks := _noise(6151, 0.04, 2)
	var scratch := _noise(3313, 0.09, 3)
	for y in SIZE:
		for x in SIZE:
			var index := y * SIZE + x
			var g := grit.get_noise_2d(float(x), float(y))
			grain[index] = g
			var h := g * 0.12
			var seam := false
			var rivet := false
			var scratch_hit := false
			var dirt_hit := false
			var edge_worn := false
			match kind:
				&"armor":
					var cx := x / CELL
					var cy := y / CELL
					var lx := x % CELL
					var ly := y % CELL
					var seam_v := lx < 3 and _hash(cx, cy, 1) < 620
					var seam_h := ly < 3 and _hash(cx, cy, 2) < 620
					seam = seam_v or seam_h
					if seam:
						h = -0.85
						if lx < 2 and ly < 2:
							h = -1.1
					var corner := lx < 13 and ly < 13
					if corner and (seam_v or seam_h):
						var dx := lx - 6
						var dy := ly - 6
						if dx * dx + dy * dy <= 6:
							rivet = true
							h = 0.6
					if not seam:
						var diag := scratch.get_noise_2d(float(x) * 0.4 + float(y) * 0.25,
								float(y) * 2.6)
						if diag > 0.62:
							scratch_hit = true
							h = maxf(h, h - 0.25)
						if lx < 7 or ly < 7:
							edge_worn = true
					var dirt := streaks.get_noise_2d(float(x) * 0.5, float(y) * 0.12)
					if dirt > 0.42:
						dirt_hit = true
					tones[index] = 0.86 + float(_hash(cx, cy, 3) % 140) / 1000.0
				&"steel":
					var brush := grit.get_noise_2d(float(x) * 0.15, float(y) * 3.0)
					h = brush * 0.2
					if x % 48 < 1:
						h -= 0.4
						seam = true
					var brushed := scratch.get_noise_2d(float(x) * 1.8, float(y) * 0.3)
					if brushed > 0.58:
						scratch_hit = true
						h -= 0.15
					if grime.get_noise_2d(float(x), float(y)) > 0.48:
						dirt_hit = true
					tones[index] = 1.0
				&"rubber":
					h = g * 0.3
					if (x + y) % 8 < 2:
						h -= 0.18
						seam = true
					tones[index] = 1.0
				&"hazard":
					var stripe := (x + y) % 32 < 16
					h = g * 0.08
					tones[index] = 0.98 if stripe else 0.2
					if scratch.get_noise_2d(float(x) * 0.5, float(y) * 2.2) > 0.6:
						scratch_hit = true
						tones[index] = maxf(tones[index], 0.75)
						h -= 0.1
					if grime.get_noise_2d(float(x), float(y)) > 0.52:
						dirt_hit = true
				_:
					h = g * 0.5
					if grit.get_noise_2d(float(x) * 2.0, float(y) * 2.0) > 0.55:
						h += 0.3
					tones[index] = 1.0
			heights[index] = h
			var bits := 0
			if seam:
				bits |= 1
			if rivet:
				bits |= 2
			if scratch_hit:
				bits |= 4
			if dirt_hit:
				bits |= 8
			if edge_worn:
				bits |= 16
			flags[index] = bits
	var albedo := Image.create(SIZE, SIZE, false, Image.FORMAT_RGB8)
	var rough := Image.create(SIZE, SIZE, false, Image.FORMAT_RGB8)
	var normal := Image.create(SIZE, SIZE, false, Image.FORMAT_RGB8)
	for y in SIZE:
		for x in SIZE:
			var index := y * SIZE + x
			var h := heights[index]
			var g := grain[index]
			var bits := flags[index]
			var value := tones[index] + g * 0.05
			var roughness := 0.6 + g * 0.15
			if bits & 1:
				value = 0.4
				roughness = 0.9
			elif bits & 2:
				value = 1.0
				roughness = 0.5
			elif bits & 4:
				value = 1.0
				roughness = 0.3
			if bits & 16:
				value = minf(value * 1.14, 1.0)
				roughness = maxf(roughness - 0.15, 0.25)
			if bits & 8:
				value *= 0.68
				roughness = 0.95
			value = clampf(value * (1.0 + grime.get_noise_2d(float(x), float(y)) * 0.06), 0.0, 1.0)
			albedo.set_pixel(x, y, Color(value, value, value))
			rough.set_pixel(x, y, Color(roughness, roughness, roughness))
			var left := heights[y * SIZE + ((x + SIZE - 1) % SIZE)]
			var right := heights[y * SIZE + ((x + 1) % SIZE)]
			var up := heights[((y + SIZE - 1) % SIZE) * SIZE + x]
			var down := heights[((y + 1) % SIZE) * SIZE + x]
			var normal_x := (left - right) * 3.0
			var normal_y := (up - down) * 3.0
			var normal_z := 1.0
			var length := sqrt(normal_x * normal_x + normal_y * normal_y + normal_z * normal_z)
			normal.set_pixel(x, y, Color(
					normal_x / length * 0.5 + 0.5,
					normal_y / length * 0.5 + 0.5,
					normal_z / length * 0.5 + 0.5))
	return {
		&"albedo": ImageTexture.create_from_image(albedo),
		&"rough": ImageTexture.create_from_image(rough),
		&"normal": ImageTexture.create_from_image(normal),
	}
