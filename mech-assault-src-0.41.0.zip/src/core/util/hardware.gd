class_name Hardware
extends RefCounted

# One-shot hardware profile: what GPU/CPU/RAM this machine actually has, how
# strong they are relative to each other, and which quality tier + FX budget
# fits. Used by AUTO graphics mode, the debug overlay and adaptive stepping.

const NOMINAL_CPU_GHZ := 2.5

static var _profile: Dictionary = {}

static func profile() -> Dictionary:
	if not _profile.is_empty():
		return _profile
	var gpu_name := RenderingServer.get_video_adapter_name()
	var api := RenderingServer.get_video_adapter_api_version()
	var cores := maxi(OS.get_processor_count(), 1)
	var ghz := _cpu_ghz()
	var ram := _ram_gb()
	_profile = {
		"gpu": gpu_name,
		"api": api,
		"cores": cores,
		"ghz": ghz,
		"ram": ram,
		"gpu_score": _gpu_score(gpu_name),
		"cpu_class": _cpu_class(cores, ghz),
	}
	return _profile

static func gpu_score() -> int:
	return int(profile().get("gpu_score", 1))

static func cpu_class() -> int:
	return int(profile().get("cpu_class", 1))

static func cpu_cores() -> int:
	return int(profile().get("cores", 4))

static func fx_scale() -> float:
	# FX/particle budget: a strong CPU absorbs more particles and decals; a
	# weak CPU gets fewer even if the GPU is fine (frame time is shared).
	var scale := 1.0
	match cpu_class():
		0:
			scale = 0.65
		2:
			scale = 1.25
		_:
			scale = 1.0
	return clampf(scale, 0.5, 1.5)

static func recommended_tier() -> int:
	# 0=LOW 1=MEDIUM 2=HIGH 3=ULTRA. The GPU leads (it draws the frame); a
	# weak CPU caps a strong GPU because AI/particles/physics also cost time,
	# and a strong CPU can lift a mid GPU a little (its extra headroom shows
	# up as FX budget + stability, never beyond what the GPU can rasterise).
	var gpu := gpu_score()
	var cpu := cpu_class()
	match gpu:
		0:
			return 0
		1:
			return 1 if cpu >= 2 else 0
		2:
			return 1 if cpu == 0 else 2
		_:
			return 1 if cpu == 0 else (2 if cpu == 1 else 3)

static func short_label() -> String:
	var data := profile()
	var gpu := String(data.get("gpu", ""))
	if gpu.length() > 22:
		gpu = gpu.substr(0, 22)
	var ghz := float(data.get("ghz", NOMINAL_CPU_GHZ))
	return "%s · %d×%.1fGHz" % [gpu, cpu_cores(), ghz]

static func describe() -> String:
	var data := profile()
	var ram := float(data.get("ram", 0.0))
	var ram_text := ("%.0fGB" % ram) if ram > 0.0 else "n/a"
	return "GPU %s [%d] · CPU %d×%.2fGHz [%d] · RAM %s" % [
			String(data.get("gpu", "?")), gpu_score(),
			cpu_cores(), float(data.get("ghz", NOMINAL_CPU_GHZ)), cpu_class(),
			ram_text]

static func _cpu_ghz() -> float:
	if OS.has_method("get_processor_speed"):
		var hz := float(OS.call("get_processor_speed"))
		if hz > 1000.0:
			return hz / 1000.0 / 1000.0
		if hz > 100.0:
			return hz / 1000.0
	if FileAccess.file_exists("/proc/cpuinfo"):
		var file := FileAccess.open("/proc/cpuinfo", FileAccess.READ)
		if file != null:
			var max_mhz := 0.0
			while not file.eof_reached():
				var line := file.get_line()
				if line.begins_with("cpu MHz"):
					max_mhz = maxf(max_mhz, line.get_slice(":", 1).strip_edges().to_float())
			file.close()
			if max_mhz > 0.0:
				return max_mhz / 1000.0
	if PlatformUtil.is_windows():
		return _windows_cpu_ghz()
	return NOMINAL_CPU_GHZ

static func _windows_cpu_ghz() -> float:
	var output: Array = []
	var code := OS.execute("reg", [
			"query",
			r"HKLM\HARDWARE\DESCRIPTION\System\CentralProcessor\0",
			"/v", "~MHz"], output, true, false)
	if code != 0 or output.is_empty():
		return NOMINAL_CPU_GHZ
	var text := str(output[0])
	# The value is a hex REG_DWORD after the value name; grab any 0x… token.
	for part in String(text).split("\n"):
		var trimmed := part.strip_edges()
		var hex_at := trimmed.find("0x")
		if hex_at >= 0:
			var tokens := trimmed.substr(hex_at).split(" ", false)
			if tokens.is_empty():
				continue
			var hex := String(tokens[0])
			var mhz := hex.hex_to_int()
			if mhz > 200:
				return float(mhz) / 1000.0
	return NOMINAL_CPU_GHZ

static func _ram_gb() -> float:
	if FileAccess.file_exists("/proc/meminfo"):
		var file := FileAccess.open("/proc/meminfo", FileAccess.READ)
		if file != null:
			while not file.eof_reached():
				var line := file.get_line()
				if line.begins_with("MemTotal:"):
					var kb := line.get_slice(":", 1).strip_edges().to_float()
					file.close()
					if kb > 0.0:
						return kb / 1024.0 / 1024.0
			file.close()
	return 0.0

static func _gpu_score(gpu_name: String) -> int:
	var name := gpu_name.to_lower()
	if name.is_empty():
		return 1
	# Software rasterisers / ancient mobile parts: floor tier.
	for marker: String in ["llvmpipe", "swiftshader", "lavapipe", "softwar",
			"mali-4", "powervr sgx", "adreno 2", "adreno 3",
			"intel(r) hd 2", "intel(r) hd 3", "hd graphics 2", "hd graphics 3"]:
		if name.contains(marker):
			return 0
	# Strong desktop / modern mobile GPUs.
	for marker: String in ["rtx", "gtx 1", "gtx 2", "radeon rx", "arc a",
			"adreno 7", "adreno 64", "adreno 65", "adreno 66", "adreno 67",
			"adreno 68", "adreno 69", "mali-g7[89]", "mali-g[89]", "apple m",
			"quadro", "tesla"]:
		if name.contains(marker) or _contains_regex(name, marker):
			return 3
	# Mid tier: current consoles / mainstream laptops / upper mobile.
	for marker: String in ["gtx 7", "gtx 8", "gtx 9", "radeon r9", "radeon rx 4",
			"radeon rx 5", "uhd 6", "intel(r) hd 5", "intel(r) hd 6",
			"adreno 6", "mali-g7", "mali-g 7", "mali-g6", "mali-g52", "mali-g57",
			"geforce 9", "geforce 8"]:
		if name.contains(marker):
			return 2
	# Weak: older integrated / entry mobile.
	for marker: String in ["adreno 4", "adreno 5", "mali-t", "mali-g5", "mali-g3",
			"intel(r) hd 4", "hd graphics 4", "geforce 6", "geforce 7",
			"radeon r5", "radeon r7", "gt 7", "gt 6"]:
		if name.contains(marker):
			return 1
	return 2

static func _contains_regex(text: String, pattern: String) -> bool:
	if not pattern.contains("["):
		return false
	var regex := RegEx.new()
	if regex.compile(pattern) != OK:
		return false
	return regex.search(text) != null

static func _cpu_class(cores: int, ghz: float) -> int:
	# Rough compute budget: cores × clock.
	var score := float(cores) * maxf(ghz, 1.0)
	if score >= 16.0:
		return 2
	if score >= 8.0:
		return 1
	return 0
