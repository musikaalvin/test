class_name LoadingPoseDriver
extends Node3D

# Standalone copy of the hangar rig construction for the loading screen: the
# selected robot, posed idle on the pad with its feet probed onto the floor.
# HangarPoseDriver is not reused so the menu driver stays untouched.
const RIG_HEIGHT_RAISE := 0.45
const BODY_ORIGIN_HEIGHT := 1.65
const GROUND_CLEARANCE := 0.1
const PROBE_UP := 1.6
const PROBE_DOWN := 8.0
const FLOOR_Y := 0.0

var rig: RobotRig = null

var _probe_from := PhysicsRayQueryParameters3D.new()
var _probe_result: Dictionary = {}
var _ground_position: Vector3 = Vector3.ZERO
var _ground_pending: bool = false
var _ground_ok: bool = false

func _ready() -> void:
	position = Vector3(0.0, BODY_ORIGIN_HEIGHT, 0.0)
	_probe_from.collision_mask = Layers.WORLD
	_probe_from.collide_with_areas = false
	_probe_from.collide_with_bodies = true
	_build_rig()

func _physics_process(_delta: float) -> void:
	_ground_feet_once()

func _process(delta: float) -> void:
	_ground_feet_once()
	if rig == null:
		return
	var body_forward := -global_basis.z
	var body_up := global_basis.y
	for leg in rig.leg_units:
		var hip_world := leg.global_position
		var rest := _rest_foot(hip_world, leg)
		if _probe_ground(hip_world + Vector3.UP * PROBE_UP):
			rest.y = _ground_position.y + GROUND_CLEARANCE
		else:
			rest.y = FLOOR_Y + GROUND_CLEARANCE
		leg.update_gait(hip_world, rest, Vector3.ZERO, body_forward, body_up, delta)
	rig.update_animation(delta, Vector3.ZERO, 0.0, true, 0.0, 0.0)

func _build_rig() -> void:
	if rig != null:
		rig.free()
		rig = null
	var old_orbit := get_node_or_null("DroneOrbit")
	if old_orbit != null:
		old_orbit.free()
	if GameState.selected_robot == GameState.ROBOT_VORTEX:
		rig = VortexRig.new()
	elif GameState.selected_robot == GameState.ROBOT_RAMPART:
		rig = ZephyrRig.new()
	elif bool(GameState.robot_def().get("is_titan", false)):
		rig = TitanRig.new()
	else:
		rig = RobotRig.new()
	rig.name = "RobotRig"
	var visual_scale := float(GameState.robot_def().get("scale", 1.0))
	rig.visual_scale = visual_scale
	rig.position.y = RIG_HEIGHT_RAISE * (
			TitanRig.TITAN_SCALE
			if bool(GameState.robot_def().get("is_titan", false)) else visual_scale)
	add_child(rig)
	var drone_id := GameState.drone_for_robot(GameState.selected_robot)
	if not drone_id.is_empty() and GameState.owns_drone(drone_id):
		var orbit_script := preload("res://src/player/drone_orbit.gd")
		var orbit := orbit_script.new() as Node3D
		orbit.name = "DroneOrbit"
		orbit.position = Vector3(2.6, 2.3, -0.4) * visual_scale
		add_child(orbit)
	_ground_pending = true

func _ground_feet_once() -> void:
	if not _ground_pending or rig == null:
		return
	var points := _probe_feet()
	if _ground_ok:
		_ground_pending = false
	rig.reset_feet(points)

func _probe_feet() -> Array[Vector3]:
	var points: Array[Vector3] = []
	var all_hit := true
	for leg in rig.leg_units:
		var hip_world := leg.global_position
		var rest := _rest_foot(hip_world, leg)
		if _probe_ground(hip_world + Vector3.UP * PROBE_UP):
			rest.y = _ground_position.y + GROUND_CLEARANCE
		else:
			all_hit = false
			rest.y = FLOOR_Y + GROUND_CLEARANCE
		points.append(rest)
	_ground_ok = all_hit
	return points

func _rest_foot(hip_world: Vector3, leg: LegUnit) -> Vector3:
	var reach := leg.thigh_length + leg.shin_length
	var lateral := leg.outward
	lateral = lateral - Vector3.FORWARD * lateral.dot(Vector3.FORWARD)
	if lateral.length_squared() < 0.0001:
		lateral = Vector3.RIGHT
	lateral = lateral.normalized()
	return hip_world + lateral * (leg.coxa_length + reach * 0.55) * leg.rest_spread \
			+ Vector3.DOWN * reach * 0.92

func _probe_ground(from: Vector3) -> bool:
	var world := get_world_3d()
	if world == null or world.direct_space_state == null:
		return false
	_probe_from.from = from
	_probe_from.to = from + Vector3.DOWN * PROBE_DOWN
	_probe_result = world.direct_space_state.intersect_ray(_probe_from)
	if _probe_result.is_empty():
		return false
	_ground_position = _probe_result["position"] as Vector3
	return true
