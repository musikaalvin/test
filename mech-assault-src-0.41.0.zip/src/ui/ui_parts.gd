class_name UiParts
extends RefCounted

# Shared component factories for the crew UI (hangar, equipment, store...).
# Every screen builds from these so panels, buttons and headers keep one
# visual language across the whole app.

static func label(text: String, font_size: int, color: Color = UiTheme.TEXT,
		outline: bool = false) -> Label:
	var node := Label.new()
	node.text = text
	UiTheme.style_label(node, font_size, color, outline)
	node.mouse_filter = Control.MOUSE_FILTER_IGNORE
	return node

static func section(text: String) -> Label:
	var node := label(text, 13, UiTheme.AMBER, true)
	node.name = "SectionLabel"
	return node

static func button(text: String, accent: Color = UiTheme.CYAN,
		font_size: int = 16, min_size: Vector2 = Vector2.ZERO) -> Button:
	var node := Button.new()
	node.text = text
	if min_size != Vector2.ZERO:
		node.custom_minimum_size = min_size
	UiTheme.apply_to_button(node, accent, font_size)
	node.mouse_default_cursor_shape = Control.CURSOR_POINTING_HAND
	node.size_flags_vertical = Control.SIZE_SHRINK_CENTER
	return node

static func wire(button: Button, handler: Callable) -> void:
	button.pressed.connect(_play_then.bind(handler))

static func _play_then(handler: Callable) -> void:
	AudioEngine.play(&"ui")
	handler.call()

static func divider(height: float = 1.0) -> ColorRect:
	var node := ColorRect.new()
	node.color = Color(1.0, 1.0, 1.0, 0.08)
	node.custom_minimum_size = Vector2(0.0, height)
	node.mouse_filter = Control.MOUSE_FILTER_IGNORE
	return node

static func vbox(separation: float = 8.0) -> VBoxContainer:
	var node := VBoxContainer.new()
	node.add_theme_constant_override("separation", int(separation))
	return node

static func hbox(separation: float = 8.0) -> HBoxContainer:
	var node := HBoxContainer.new()
	node.add_theme_constant_override("separation", int(separation))
	return node

static func scroll() -> ScrollContainer:
	var node := ScrollContainer.new()
	node.horizontal_scroll_mode = ScrollContainer.SCROLL_MODE_DISABLED
	node.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	node.size_flags_vertical = Control.SIZE_EXPAND_FILL
	return node

# Full-screen backdrop for opaque screens: a dark panel that eats input so
# screens below it never see a click.
static func backdrop(alpha: float = 0.96) -> Panel:
	var node := Panel.new()
	node.name = "Backdrop"
	node.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	node.set_script(preload("res://src/ui/screen_backdrop.gd"))
	var style := StyleBoxFlat.new()
	style.bg_color = Color(UiTheme.BG.r, UiTheme.BG.g, UiTheme.BG.b, alpha)
	style.border_color = Color(UiTheme.CYAN.r, UiTheme.CYAN.g, UiTheme.CYAN.b, 0.18)
	style.border_width_top = 1
	node.add_theme_stylebox_override("panel", style)
	return node

# Size badge (LIGHT/MEDIUM/HEAVY/ALPHA/BETA) in its slot colour.
static func badge(text: String, color: Color, width: float = 76.0) -> Panel:
	var panel := Panel.new()
	panel.name = "Badge"
	panel.custom_minimum_size = Vector2(width, 22.0)
	panel.size_flags_vertical = Control.SIZE_SHRINK_CENTER
	panel.mouse_filter = Control.MOUSE_FILTER_IGNORE
	var style := StyleBoxFlat.new()
	style.bg_color = Color(color.r, color.g, color.b, 0.22)
	style.border_color = color
	style.set_border_width_all(1)
	style.set_corner_radius_all(4)
	panel.add_theme_stylebox_override("panel", style)
	var text_label := label(text, 11, color, true)
	text_label.name = "BadgeLabel"
	text_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	text_label.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	panel.add_child(text_label)
	return panel

# Header for a screen: [ < BACK ] TITLE. Back button only when a handler
# is supplied (Callable() is invalid → header-only).
static func header_row(title: String, back_handler: Callable = Callable()) -> HBoxContainer:
	var row := hbox(14.0)
	row.name = "HeaderRow"
	row.custom_minimum_size = Vector2(0.0, 50.0)
	if back_handler.is_valid():
		var back := button("< BACK", UiTheme.CYAN, 15, Vector2(124.0, 44.0))
		back.name = "BackButton"
		wire(back, back_handler)
		row.add_child(back)
	var title_label := label(title.to_upper(), 24, UiTheme.TEXT, true)
	title_label.name = "ScreenTitle"
	title_label.size_flags_vertical = Control.SIZE_SHRINK_CENTER
	row.add_child(title_label)
	return row

# Small amber badge showing an ability's short code; tooltip carries the
# full description.
static func ability_chip(short_text: String, tooltip: String) -> PanelContainer:
	var chip := PanelContainer.new()
	chip.name = "AbilityChip"
	var style := StyleBoxFlat.new()
	style.bg_color = Color(0.05, 0.06, 0.08, 0.92)
	style.border_color = Color(UiTheme.AMBER.r, UiTheme.AMBER.g, UiTheme.AMBER.b, 0.65)
	style.set_border_width_all(1)
	style.set_corner_radius_all(6)
	style.set_content_margin_all(5.0)
	chip.add_theme_stylebox_override("panel", style)
	var chip_label := label(short_text, 10, UiTheme.AMBER, true)
	chip_label.name = "ChipLabel"
	chip.add_child(chip_label)
	chip.tooltip_text = tooltip
	return chip

static func set_ability_chip(chip: Node, short_text: String, tooltip: String) -> void:
	var panel := chip as PanelContainer
	if panel == null:
		return
	panel.visible = not short_text.is_empty()
	panel.tooltip_text = tooltip
	var chip_label := panel.get_node_or_null("ChipLabel") as Label
	if chip_label != null:
		chip_label.text = short_text

# Caption + value row with an optional progress bar (stat blocks).
static func stat_row(row_name: String, caption: String, value_text: String,
		ratio: float, bar_color: Color) -> VBoxContainer:
	var column := vbox(3.0)
	column.name = row_name
	var top := hbox(8.0)
	top.name = "RowTop"
	var caption_label := label(caption, 11, UiTheme.MUTED)
	caption_label.name = "Caption"
	caption_label.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	top.add_child(caption_label)
	var value := label(value_text, 13, UiTheme.TEXT, true)
	value.name = "Value"
	top.add_child(value)
	column.add_child(top)
	var track := Panel.new()
	track.name = "Bar"
	track.custom_minimum_size = Vector2(0.0, 7.0)
	track.add_theme_stylebox_override("panel", UiTheme.bar_bg())
	track.mouse_filter = Control.MOUSE_FILTER_IGNORE
	var fill := ColorRect.new()
	fill.name = "Fill"
	fill.color = bar_color
	fill.mouse_filter = Control.MOUSE_FILTER_IGNORE
	fill.set_anchors_and_offsets_preset(Control.PRESET_LEFT_WIDE)
	fill.offset_right = 0.0
	track.add_child(fill)
	column.add_child(track)
	set_bar(fill, ratio)
	return column

static func set_bar(fill: ColorRect, ratio: float) -> void:
	# Anchor-based width: proportional to the track at any size, no re-layout
	# needed after a refresh (offsets would go stale on resize).
	fill.anchor_left = 0.0
	fill.anchor_right = clampf(ratio, 0.0, 1.0)
	fill.anchor_top = 0.0
	fill.anchor_bottom = 1.0
	fill.offset_left = 0.0
	fill.offset_right = 0.0
	fill.offset_top = 0.0
	fill.offset_bottom = 0.0

static func money(value: int) -> String:
	var digits := str(maxi(0, value))
	var formatted := ""
	var count := digits.length()
	for index in count:
		if index > 0 and (count - index) % 3 == 0:
			formatted += " "
		formatted += digits[index]
	return formatted
