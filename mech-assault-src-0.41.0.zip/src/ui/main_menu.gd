class_name MainMenu
extends Control

# Application shell — nothing but wiring. The old 5000-line monolith is
# gone: this scene provides the visual background, the build stamp and a
# single UIManager screen stack (see src/ui/ui_manager.gd), whose
# screens live in src/ui/screens/*. Every interactive element of the
# crew hub is registered there, never as popups on this node.

const TEAL_TOP := Color(0.05, 0.13, 0.16)
const TEAL_MID := Color(0.03, 0.08, 0.11)
const TEAL_LOW := Color(0.012, 0.028, 0.04)

var _ui: UIManager

func _ready() -> void:
	set_anchors_preset(Control.PRESET_FULL_RECT)
	_build_background()

	_ui = UIManager.new()
	_ui.name = "UI"
	add_child(_ui)

	Quality.apply_viewport(get_viewport())
	var hangar := _ui.screen(&"hangar") as HangarScreen
	if hangar != null and hangar.bay_viewport() != null:
		Quality.apply_viewport(hangar.bay_viewport())

	GameState.enter_menu()
	AudioEngine.set_menu_music(true)
	if OS.get_name() == "Android":
		OS.request_permission("POST_NOTIFICATIONS")

	Events.gamepad_connection_changed.connect(_on_gamepad_connection_changed)
	Events.mode_changed.connect(_on_mode_changed)
	GamepadNav.enable(self)
	_focus_start()

func _focus_start() -> void:
	if PlatformUtil.effective_mode() == PlatformUtil.InputMode.GAMEPAD:
		GamepadNav.focus_default(self, "StartButton")

func _on_mode_changed(_mode: int) -> void:
	GamepadNav.enable(self)
	_focus_start()

func _on_gamepad_connection_changed(_device: int, _connected: bool) -> void:
	GamepadNav.enable(self)
	_focus_start()

# ---------------------------------------------------------------- visuals

func _build_background() -> void:
	var background := ColorRect.new()
	background.name = "Background"
	background.color = UiTheme.BG
	background.mouse_filter = Control.MOUSE_FILTER_IGNORE
	background.set_anchors_preset(Control.PRESET_FULL_RECT)
	add_child(background)

	var gradient := GradientTexture2D.new()
	gradient.fill = GradientTexture2D.FILL_LINEAR
	gradient.fill_from = Vector2(0.0, 0.0)
	gradient.fill_to = Vector2(0.0, 1.0)
	gradient.gradient = _make_gradient()
	var backdrop := TextureRect.new()
	backdrop.name = "Backdrop"
	backdrop.texture = gradient
	backdrop.expand_mode = TextureRect.EXPAND_IGNORE_SIZE
	backdrop.stretch_mode = TextureRect.STRETCH_SCALE
	backdrop.mouse_filter = Control.MOUSE_FILTER_IGNORE
	backdrop.set_anchors_preset(Control.PRESET_FULL_RECT)
	add_child(backdrop)

	var grid := GridStripes.new()
	grid.name = "GridBackdrop"
	grid.line_color = Color(0.16, 0.44, 0.5, 0.14)
	grid.accent_color = Color(0.85, 0.68, 0.3, 0.08)
	grid.set_anchors_preset(Control.PRESET_FULL_RECT)
	add_child(grid)

func _make_gradient() -> Gradient:
	var gradient := Gradient.new()
	gradient.offsets = PackedFloat32Array([0.0, 0.5, 1.0])
	gradient.colors = PackedColorArray([TEAL_TOP, TEAL_MID, TEAL_LOW])
	return gradient
