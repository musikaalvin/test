class_name StatusFeed
extends Control

# War Robots-style battle status ticker: short red status lines stacked at
# the bottom centre of the screen — deployments, kills, death, secure.
# Distinct from the top-right kill feed (read-only summary); this is the
# "what is happening right now" band.

const MAX_LINES := 4
const LINE_LIFE := 4.0
const STATUS_RED := Color(1.0, 0.32, 0.28)
const LIVE_AMBER := Color(1.0, 0.74, 0.24)

var _stack: VBoxContainer
# Persistent WR-style status row: always-on battle readout under the event
# ticker (hostiles left, kills, live dot). The ticker alone faded out between
# events, so the bottom of the screen looked empty mid-fight on device.
var _bar: Panel
var _hostiles_label: Label
var _kills_label: Label
var _kills: int = 0

func _ready() -> void:
	mouse_filter = Control.MOUSE_FILTER_IGNORE
	_stack = VBoxContainer.new()
	_stack.name = "Lines"
	_stack.anchor_left = 0.0
	_stack.anchor_right = 1.0
	_stack.anchor_top = 0.0
	_stack.anchor_bottom = 1.0
	_stack.offset_left = 0.0
	_stack.offset_top = 0.0
	_stack.offset_right = 0.0
	_stack.offset_bottom = -26.0
	_stack.alignment = BoxContainer.ALIGNMENT_END
	_stack.add_theme_constant_override("separation", 2)
	_stack.mouse_filter = Control.MOUSE_FILTER_IGNORE
	add_child(_stack)
	_build_bar()
	Events.match_started.connect(_on_match_started)
	Events.enemy_killed.connect(_on_enemy_killed)
	Events.player_died.connect(_on_player_died)
	Events.all_enemies_defeated.connect(_on_all_defeated)

func _build_bar() -> void:
	_bar = Panel.new()
	_bar.name = "LiveBar"
	_bar.anchor_left = 0.0
	_bar.anchor_right = 1.0
	_bar.anchor_top = 1.0
	_bar.anchor_bottom = 1.0
	_bar.offset_left = 0.0
	_bar.offset_top = -24.0
	_bar.offset_right = 0.0
	_bar.offset_bottom = 0.0
	_bar.mouse_filter = Control.MOUSE_FILTER_IGNORE
	_bar.add_theme_stylebox_override("panel", UiTheme.panel(
			0.72, Color(1.0, 0.32, 0.28)))
	add_child(_bar)

	var row := HBoxContainer.new()
	row.name = "Row"
	row.anchor_right = 1.0
	row.offset_left = 10.0
	row.offset_right = -10.0
	row.offset_top = 2.0
	row.offset_bottom = -2.0
	row.alignment = BoxContainer.ALIGNMENT_CENTER
	row.add_theme_constant_override("separation", 18)
	row.mouse_filter = Control.MOUSE_FILTER_IGNORE
	_bar.add_child(row)

	var live := Label.new()
	live.name = "Live"
	live.text = "LIVE"
	UiTheme.style_label(live, 14, STATUS_RED, true)
	live.mouse_filter = Control.MOUSE_FILTER_IGNORE
	row.add_child(live)

	_hostiles_label = Label.new()
	_hostiles_label.name = "Hostiles"
	_hostiles_label.text = "HOSTILES 0"
	UiTheme.style_label(_hostiles_label, 14, LIVE_AMBER, true)
	_hostiles_label.mouse_filter = Control.MOUSE_FILTER_IGNORE
	row.add_child(_hostiles_label)

	_kills_label = Label.new()
	_kills_label.name = "Kills"
	_kills_label.text = "KILLS 0"
	UiTheme.style_label(_kills_label, 14, Color(0.85, 0.9, 0.95), true)
	_kills_label.mouse_filter = Control.MOUSE_FILTER_IGNORE
	row.add_child(_kills_label)

func _process(_delta: float) -> void:
	if _bar == null or not _bar.visible:
		return
	_hostiles_label.text = "HOSTILES %d" % maxi(0, GameState.remaining_enemies())
	_kills_label.text = "KILLS %d" % _kills

func push(text: String, color: Color = STATUS_RED) -> void:
	while _stack.get_child_count() >= MAX_LINES:
		var oldest := _stack.get_child(0) as Node
		if oldest == null:
			break
		_stack.remove_child(oldest)
		oldest.queue_free()
	var label := Label.new()
	label.name = "Status"
	label.text = text
	label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	UiTheme.style_label(label, 16, color, true)
	label.mouse_filter = Control.MOUSE_FILTER_IGNORE
	_stack.add_child(label)
	var tween := label.create_tween()
	tween.tween_interval(LINE_LIFE)
	tween.tween_property(label, "modulate:a", 0.0, 0.6)
	tween.tween_callback(label.queue_free)

func line_count() -> int:
	return _stack.get_child_count() if _stack != null else 0

func _on_match_started() -> void:
	_kills = 0
	var robot_name := String(GameState.robot_def().get("name", "ROBOT")).to_upper()
	push("DEPLOYED  %s" % robot_name)
	push("HOSTILE WAVE DEPLOYED  ·  %d" % GameState.remaining_enemies())

func _on_enemy_killed(_enemy_id: int) -> void:
	_kills += 1
	push("HOSTILE DESTROYED  ·  %d LEFT" % GameState.remaining_enemies())

func _on_player_died() -> void:
	push("UNIT DESTROYED")

func _on_all_defeated() -> void:
	push("AREA SECURED")
