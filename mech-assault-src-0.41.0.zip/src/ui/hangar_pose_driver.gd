class_name HangarPoseDriver
extends Node3D

# Physical hangar bay (prompt: hero platform + four staggered mech pads +
# one elevated titan pad at the rear). The bay is built ONCE in _ready
# (room + platforms + deck colliders); rebuild() only swaps which robot
# stands on which pad. Selected robot always occupies its class platform
# and keeps the `rig` property the rest of the UI drives; every other
# occupied pad holds a posed roster rig. No Label3D anywhere — pad
# identity chips are 2D Controls unprojected by HangarScreen, and the
# showroom never animates on its own (the director's "robot does nothing
# by itself" rule): rigs are posed once and only re-grounded.

const RIG_HEIGHT_RAISE := 0.45
const BODY_ORIGIN_HEIGHT := 1.65
const GROUND_CLEARANCE := 0.1
const PROBE_UP := 1.6
const PROBE_DOWN := 8.0
const FLOOR_Y := 0.0

var rig: RobotRig = null
var user_yaw: float = 0.0
var _assignment: Array[StringName] = []
var _slot_rigs: Array[RobotRig] = []
var _slots_root: Node3D = null
var _room_root: Node3D = null
var _platform_rims: Array[StandardMaterial3D] = []

var _probe_from := PhysicsRayQueryParameters3D.new()
var _probe_result: Dictionary = {}
var _ground_position: Vector3 = Vector3.ZERO
var _ground_pending: bool = false
var _ground_ok: bool = false

func _ready() -> void:
	position = Vector3(0.0, BODY_ORIGIN_HEIGHT, 0.0)
	_probe_from.collision_mask = Layers.WORLD
	_probe_from.collide_with_areas = false
	_probe_from.collide_with_bodies = true
	_build_room()
	_build_platforms()
	_build_rig()

func _physics_process(_delta: float) -> void:
	_ground_feet_once()

func _process(_delta: float) -> void:
	_ground_feet_once()

func rebuild() -> void:
	_build_rig()

# User drag rotates the selected MODEL (the camera never moves on its
# own). The offset survives rebuilds so switching away and back keeps
# the viewing angle the director dialled in.
func rotate_user(degrees: float) -> void:
	user_yaw = wrapf(user_yaw + degrees, -180.0, 180.0)
	if rig != null and is_instance_valid(rig):
		var base := float(HangarSlots.SLOTS[selected_slot()]["yaw"])
		rig.rotation_degrees.y = wrapf(base + user_yaw, -180.0, 180.0)

# World-space AABB of the selected robot — the camera frames THIS so the
# complete machine always fits the presentation region with margins.
func selected_bounds() -> AABB:
	if rig == null or not is_instance_valid(rig):
		return AABB(Vector3(-1.5, 0.0, -1.5), Vector3(3.0, 3.5, 3.0))
	var bounds := AABB()
	var first := true
	for mesh_node in rig.find_children("*", "MeshInstance3D", true, false):
		var mesh := mesh_node as MeshInstance3D
		if mesh == null or mesh.mesh == null:
			continue
		var world := mesh.global_transform * mesh.mesh.get_aabb()
		if first:
			bounds = world
			first = false
		else:
			bounds = bounds.merge(world)
	if first:
		return AABB(Vector3(-1.5, 0.0, -1.5), Vector3(3.0, 3.5, 3.0))
	return bounds

# ---------------------------------------------------------------- slot API

func slot_count() -> int:
	return HangarSlots.SLOTS.size()

func slot_robot(index: int) -> StringName:
	if index < 0 or index >= _assignment.size():
		return &""
	return _assignment[index]

func selected_slot() -> int:
	var index := _assignment.find(GameState.selected_robot)
	return HangarSlots.HERO if index < 0 else index

# Occupied anchors only — the hangar camera fits them so nobody crops.
func slot_points() -> Array[Vector3]:
	var points: Array[Vector3] = []
	for index in _assignment.size():
		if _assignment[index] == &"":
			continue
		var slot: Dictionary = HangarSlots.SLOTS[index]
		points.append(Vector3(float(slot["pos"].x), 0.0, float(slot["pos"].z)))
	return points

func slot_world_centre(index: int) -> Vector3:
	if index < 0 or index >= HangarSlots.SLOTS.size():
		return Vector3.ZERO
	return HangarSlots.slot_centre(index)

# Screen-space rect of a platform for pointer hit-testing. Returns an
# empty rect when the platform is behind the camera.
func slot_screen_rect(index: int, camera: Camera3D) -> Rect2:
	if camera == null or index < 0 or index >= HangarSlots.SLOTS.size():
		return Rect2()
	var slot: Dictionary = HangarSlots.SLOTS[index]
	var radius := float(slot["radius"]) * 1.05
	var base := Vector3(float(slot["pos"].x), 0.0, float(slot["pos"].z))
	var height := float(slot["top"]) + (6.8 if bool(slot["titan"]) else 4.6)
	var corners: Array[Vector3] = [
		base + Vector3(-radius, 0.0, -radius),
		base + Vector3(radius, 0.0, -radius),
		base + Vector3(-radius, 0.0, radius),
		base + Vector3(radius, 0.0, radius),
		base + Vector3(-radius, height, -radius),
		base + Vector3(radius, height, -radius),
		base + Vector3(-radius, height, radius),
		base + Vector3(radius, height, radius),
	]
	var minimum := Vector2(INF, INF)
	var maximum := Vector2(-INF, -INF)
	for corner in corners:
		var cam_space := camera.global_transform.affine_inverse() * corner
		if cam_space.z > -0.05:
			return Rect2()
		var projected := camera.unproject_position(corner)
		minimum = minimum.min(projected)
		maximum = maximum.max(projected)
	return Rect2(minimum, maximum - minimum)

# ------------------------------------------------------------------ build

func _build_room() -> void:
	_room_root = Node3D.new()
	_room_root.name = "HangarRoom"
	# Driver sits at the body-origin height: world floor plane == local 0
	# after this offset, so the room is authored in world coordinates.
	_room_root.position.y = -BODY_ORIGIN_HEIGHT
	add_child(_room_root)
	var floor_material := MeshUtil.make_material(Color(0.055, 0.065, 0.075), 0.4, 0.85)
	var floor := MeshUtil.make_box(Vector3(74.0, 0.2, 58.0), floor_material, "BayFloor")
	floor.position = Vector3(0.0, -0.1, -8.0)
	_room_root.add_child(floor)
	var lane_material := MeshUtil.make_material(Color(0.09, 0.11, 0.13), 0.2, 0.5,
			Color(0.3, 0.8, 1.0), 0.7)
	for lane_x in [-13.0, 13.0]:
		var lane := MeshUtil.make_box(Vector3(0.16, 0.03, 54.0), lane_material, "LaneStrip")
		lane.position = Vector3(float(lane_x), 0.02, -6.0)
		_room_root.add_child(lane)
	var wall_material := MeshUtil.make_material(Color(0.045, 0.05, 0.06), 0.3, 0.9)
	# Rear wall sits at z -34: the titan bay's zoomed-out camera reaches
	# z ~-30, and the old -25 wall was 1.8 m BEHIND it (its opaque back
	# face filled the whole viewport - the "empty slate bay" bug).
	var wall := MeshUtil.make_box(Vector3(74.0, 13.0, 0.8), wall_material, "RearWall")
	wall.position = Vector3(0.0, 6.5, -34.0)
	_room_root.add_child(wall)
	var strip_material := MeshUtil.make_material(Color(0.11, 0.13, 0.15), 0.2, 0.5,
			Color(0.35, 0.8, 1.0), 1.1)
	for strip_y in [2.4, 6.2, 9.4]:
		var strip := MeshUtil.make_box(Vector3(70.0, 0.14, 0.1), strip_material, "WallStrip")
		strip.position = Vector3(0.0, float(strip_y), -33.55)
		_room_root.add_child(strip)
	var column_material := MeshUtil.make_material(Color(0.07, 0.08, 0.095), 0.6, 0.55)
	for column_x in [-27.0, -16.0, 16.0, 27.0]:
		var column := MeshUtil.make_box(Vector3(1.5, 13.0, 1.5), column_material, "Column")
		column.position = Vector3(float(column_x), 6.5, -33.2)
		_room_root.add_child(column)
	for side in [-1.0, 1.0]:
		var side_wall := MeshUtil.make_box(Vector3(0.8, 9.0, 54.5), wall_material, "SideWall")
		side_wall.position = Vector3(35.0 * float(side), 4.5, -6.0)
		_room_root.add_child(side_wall)
	var crate_material := MeshUtil.make_material(Color(0.11, 0.1, 0.08), 0.5, 0.7)
	var crate_xz: Array[Vector2] = [
		Vector2(-25.0, -30.0), Vector2(-23.2, -31.4),
		Vector2(25.0, -29.4), Vector2(26.8, -30.8),
		Vector2(-29.5, -1.5), Vector2(29.5, 2.5),
	]
	for point in crate_xz:
		var size := Vector3(1.7, 1.05, 1.5)
		var crate := MeshUtil.make_bevel_box(size, 0.07, crate_material, "crate")
		crate.position = Vector3(point.x, size.y * 0.5, point.y)
		_room_root.add_child(crate)

func _build_platforms() -> void:
	_slots_root = Node3D.new()
	_slots_root.name = "Slots"
	_slots_root.position.y = -BODY_ORIGIN_HEIGHT
	add_child(_slots_root)
	for index in HangarSlots.SLOTS.size():
		_build_platform(index)

func _build_platform(index: int) -> void:
	var slot: Dictionary = HangarSlots.SLOTS[index]
	var radius := float(slot["radius"])
	var top := float(slot["top"])
	var is_titan := bool(slot["titan"])
	var role_name := String(HangarSlots.Role.keys()[int(slot["role"])])
	var platform := Node3D.new()
	platform.name = "Platform_%d_%s" % [index, role_name]
	platform.position = Vector3(float(slot["pos"].x), 0.0, float(slot["pos"].z))
	_slots_root.add_child(platform)
	# Deck physics: feet probes and the player-click proxy land here.
	var body := StaticBody3D.new()
	body.name = "DeckBody"
	body.collision_layer = Layers.WORLD
	body.collision_mask = 0
	platform.add_child(body)
	var shape := CollisionShape3D.new()
	var cylinder := CylinderShape3D.new()
	cylinder.radius = radius * 0.94
	cylinder.height = maxf(top, 0.12)
	shape.shape = cylinder
	shape.position = Vector3(0.0, top * 0.5, 0.0)
	body.add_child(shape)
	# Pedestal drum + deck plate + energised rim (the selection language).
	var base_material := MeshUtil.make_material(Color(0.07, 0.08, 0.1), 0.55, 0.6)
	var base := MeshUtil.make_cylinder(radius, maxf(top, 0.12), base_material, 48, "deck_base")
	base.position = Vector3(0.0, top * 0.5, 0.0)
	platform.add_child(base)
	var deck_material := MeshUtil.make_material(Color(0.11, 0.13, 0.15), 0.45, 0.55)
	var deck := MeshUtil.make_cylinder(radius * 0.98, 0.06, deck_material, 48, "deck_plate")
	deck.position = Vector3(0.0, top - 0.02, 0.0)
	platform.add_child(deck)
	var rim_material := MeshUtil.make_material(Color(0.1, 0.12, 0.15), 0.4, 0.45,
			Color(0.3, 0.75, 1.0), 0.5)
	_platform_rims.append(rim_material)
	var rim := MeshUtil.make_cylinder(radius + 0.24, 0.06, rim_material, 48, "deck_rim")
	rim.position = Vector3(0.0, top + 0.01, 0.0)
	platform.add_child(rim)
	if is_titan:
		# Hazard bands mark the titan pedestal as a different class.
		var hazard := MeshUtil.make_material(Color(0.9, 0.5, 0.15), 0.3, 0.6,
				Color(1.0, 0.55, 0.15), 0.6)
		for band_index in 2:
			var band := MeshUtil.make_cylinder(radius + 0.05, 0.1, hazard, 48, "hazard_band")
			band.position = Vector3(0.0, 0.32 + 0.5 * float(band_index), 0.0)
			platform.add_child(band)

func _build_rig() -> void:
	if rig != null:
		rig.free()
		rig = null
	for slot_rig in _slot_rigs:
		if slot_rig != null and is_instance_valid(slot_rig):
			slot_rig.free()
	_slot_rigs.clear()
	_assignment = HangarSlots.assignment()
	# Selection always stands: never let a pathological state drop it.
	if not _assignment.has(GameState.selected_robot):
		_assignment[HangarSlots.HERO] = GameState.selected_robot
	var selected_slot_index := _assignment.find(GameState.selected_robot)
	if selected_slot_index < 0:
		selected_slot_index = HangarSlots.HERO
	_slot_rigs.resize(HangarSlots.SLOTS.size())
	for index in HangarSlots.SLOTS.size():
		var slot: Dictionary = HangarSlots.SLOTS[index]
		var robot_id := _assignment[index]
		var occupied := robot_id != &""
		if not occupied:
			continue
		var target := _make_rig(robot_id)
		var is_selected := index == selected_slot_index
		target.name = "RobotRig" if is_selected else "SlotRig_%d" % index
		var slot_scale := _scale_for(robot_id)
		target.position = Vector3(
				float(slot["pos"].x),
				RIG_HEIGHT_RAISE * slot_scale + float(slot["top"]),
				float(slot["pos"].z))
		var yaw := float(slot["yaw"])
		if is_selected:
			yaw = wrapf(yaw + user_yaw, -180.0, 180.0)
		target.rotation_degrees.y = yaw
		add_child(target)
		_ground_rig_once(target)
		if is_selected:
			rig = target
		else:
			_slot_rigs[index] = target
	if rig == null:
		# Defensive: assignment guarantees selected placement; belt and braces.
		rig = _make_rig(GameState.selected_robot)
		rig.name = "RobotRig"
		rig.position = Vector3(0.0, RIG_HEIGHT_RAISE * _scale_for(
				GameState.selected_robot), 0.0)
		add_child(rig)
		_ground_rig_once(rig)
	var old_orbit := get_node_or_null("DroneOrbit")
	if old_orbit != null:
		old_orbit.free()
	var drone_id := GameState.drone_for_robot(GameState.selected_robot)
	if not drone_id.is_empty() and GameState.owns_drone(drone_id) and rig != null:
		var orbit_script := preload("res://src/player/drone_orbit.gd")
		var orbit := orbit_script.new() as Node3D
		orbit.name = "DroneOrbit"
		orbit.position = rig.position + Vector3(2.6, 2.3, -0.4) * _scale_for(
				GameState.selected_robot)
		add_child(orbit)
		# Showroom rule: nothing moves unless the user moves it. The pods
		# keep their built pose — no orbit, no bob.
		orbit.set_process(false)
		orbit.set_physics_process(false)
	_ground_pending = true
	_refresh_selection()

func _make_rig(robot_id: StringName) -> RobotRig:
	var def := GameState.robot_def(robot_id)
	var new_rig: RobotRig
	if robot_id == GameState.ROBOT_VORTEX:
		new_rig = VortexRig.new()
	elif robot_id == GameState.ROBOT_RAMPART:
		new_rig = ZephyrRig.new()
	elif bool(def.get("is_titan", false)):
		new_rig = TitanRig.new()
	else:
		new_rig = RobotRig.new()
	new_rig.visual_scale = float(def.get("scale", 1.0))
	return new_rig

func _scale_for(robot_id: StringName) -> float:
	var def := GameState.robot_def(robot_id)
	if bool(def.get("is_titan", false)):
		return TitanRig.TITAN_SCALE
	return float(def.get("scale", 1.0))

# Rim colours carry the state language: amber = selected, cyan =
# occupied, dim = empty.
func _refresh_selection() -> void:
	var selected := selected_slot()
	for index in _platform_rims.size():
		var rim := _platform_rims[index]
		if rim == null:
			continue
		var occupied := index < _assignment.size() and _assignment[index] != &""
		var is_selected := index == selected
		if is_selected:
			rim.emission = Color(1.0, 0.72, 0.25)
			rim.emission_energy_multiplier = 2.6
		elif occupied:
			rim.emission = Color(0.35, 0.8, 1.0)
			rim.emission_energy_multiplier = 1.0
		else:
			rim.emission = Color(0.3, 0.7, 0.9)
			rim.emission_energy_multiplier = 0.35

func _ground_feet_once() -> void:
	if not _ground_pending or rig == null:
		return
	var points := _probe_feet()
	if _ground_ok:
		_ground_pending = false
	rig.reset_feet(points)

func _ground_rig_once(target: RobotRig) -> void:
	if target == null:
		return
	var points: Array[Vector3] = []
	for leg in target.leg_units:
		var hip_world := leg.global_position
		var rest := _rest_foot(hip_world, leg)
		if _probe_ground(hip_world + Vector3.UP * PROBE_UP):
			rest.y = _ground_position.y + GROUND_CLEARANCE
		else:
			rest.y = FLOOR_Y + GROUND_CLEARANCE
		points.append(rest)
	target.reset_feet(points)

func _probe_feet() -> Array[Vector3]:
	var points: Array[Vector3] = []
	var all_hit := true
	for leg in rig.leg_units:
		var hip_world := leg.global_position
		var rest := _rest_foot(hip_world, leg)
		if _probe_ground(hip_world + Vector3.UP * PROBE_UP):
			rest.y = _ground_position.y + GROUND_CLEARANCE
		else:
			all_hit = false
			rest.y = FLOOR_Y + GROUND_CLEARANCE
		points.append(rest)
	_ground_ok = all_hit
	return points

func _rest_foot(hip_world: Vector3, leg: LegUnit) -> Vector3:
	var reach := leg.thigh_length + leg.shin_length
	var lateral := leg.outward
	lateral = lateral - Vector3.FORWARD * lateral.dot(Vector3.FORWARD)
	if lateral.length_squared() < 0.0001:
		lateral = Vector3.RIGHT
	lateral = lateral.normalized()
	return hip_world + lateral * (leg.coxa_length + reach * 0.55) * leg.rest_spread \
			+ Vector3.DOWN * reach * 0.92

func _probe_ground(from: Vector3) -> bool:
	_probe_from.from = from
	_probe_from.to = from + Vector3.DOWN * PROBE_DOWN
	_probe_result = get_world_3d().direct_space_state.intersect_ray(_probe_from)
	if _probe_result.is_empty():
		return false
	_ground_position = _probe_result["position"] as Vector3
	return true
