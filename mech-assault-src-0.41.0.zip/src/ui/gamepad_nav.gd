class_name GamepadNav
extends RefCounted

# Makes a menu tree navigable with a controller (d-pad / left stick + A + B).
# UiTheme.apply_to_button() forces FOCUS_NONE, so we re-enable focus here and
# place an initial cursor on a sensible default button.

static func enable(root: Node) -> void:
	if root == null:
		return
	_walk(root)

static func focus_default(root: Node, preferred: String = "") -> void:
	if root == null:
		return
	if not preferred.is_empty():
		var wanted := root.find_child(preferred, true, false)
		if wanted is Control and (wanted as Control).focus_mode != Control.FOCUS_NONE:
			(wanted as Control).grab_focus()
			return
	_grab_first(root)

static func _walk(node: Node) -> void:
	for child in node.get_children():
		if child is Button:
			var button := child as Button
			if button.focus_mode == Control.FOCUS_NONE and button.disabled:
				continue
			if button.focus_mode == Control.FOCUS_NONE:
				button.focus_mode = Control.FOCUS_ALL
		elif child is Container or child is Control:
			_walk(child)

static func _grab_first(node: Node) -> void:
	for child in node.get_children():
		if child is Button:
			var button := child as Button
			if button.visible and not button.disabled \
					and button.focus_mode != Control.FOCUS_NONE:
				button.grab_focus()
				return
		if child is Control or child is Container:
			_grab_first(child)
