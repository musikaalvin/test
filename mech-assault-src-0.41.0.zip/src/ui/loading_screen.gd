class_name LoadingScreen
extends CanvasLayer

# War Robots-style battle deploy screen, rebranded for MECH ASSAULT: the map
# name lands huge at the top with mode chips under it, the middle is a two
# column briefing (ALLIES card on the left, HOSTILES roster on the right) and
# the bottom carries the honest load progress, map line and rotating tips.
# Progress is written from outside by SceneRouter and only ever reports work
# that has completed: threaded load -> arena build -> deploy frames.
const LAYER := 100
const MARGIN := 44.0
const TOP_HEIGHT := 84.0
const HERO_HEIGHT := 92.0
const BOTTOM_HEIGHT := 216.0
const TIP_INTERVAL := 4.5
const MAP_LABEL := "MAP  //  OPEN REALM"
const MODE_LABEL := "SURVIVAL"
const ROUND_TIME := "05:00"

# Enemy roster preview: counts come from EnemyRobot.KIND_PATTERN, names and
# weapons from this table (must match EnemyRobot.kind_label / _make_weapon).
const HOSTILE_NAMES: Dictionary = {
	&"SCUTTLER": "ARACHNID",
	&"STALKER": "STALKER",
	&"BRUTE": "BRUTE",
	&"WASP": "WASP",
}
const HOSTILE_WEAPONS: Dictionary = {
	&"SCUTTLER": "ARACHNID SPITTER",
	&"STALKER": "OBSIDIAN LANCE",
	&"BRUTE": "FURNACE MAW",
	&"WASP": "ARC TESLA",
}
const KIND_ORDER: Array[StringName] = [
	&"SCUTTLER", &"STALKER", &"BRUTE", &"WASP",
]

const TIPS: Array[String] = [
	"SHADOW DASH cloaks you for the whole burst - disengage, reposition, then strike.",
	"Lock a hostile to mark it: a pinned target melts under focused fire.",
	"Watch the HEAT gauge - an overheated RAZOR goes silent exactly when you need it.",
	"SCARAB climbs sheer walls. Vertical routes beat the main lane every time.",
	"Take the high ground: hull-down shots are far harder for enemies to answer.",
	"Your drone's emergency repair fires when you drop critical - survive to earn it.",
	"Break line of sight between reloads - re-peek on your terms, not theirs.",
	"The volcano throws fire rocks across the realm - keep moving during an eruption.",
]

var _root: Control = null
var _fill: ColorRect = null
var _stage_label: Label = null
var _percent_label: Label = null
var _tip_label: Label = null

var _tip_clock: float = 0.0
var _tip_index: int = 0
var _ratio: float = -1.0
var _stage: String = ""


func _ready() -> void:
	layer = LAYER
	# This node only ever exists during a switch: keep the tips and progress
	# ticks running even if something pauses the scene tree mid-load.
	process_mode = Node.PROCESS_MODE_ALWAYS
	_build()
	set_progress(0.0, "LOADING ASSETS")
	_show_tip()


func _process(delta: float) -> void:
	_rotate_tip(delta)


## ratio is 0..1 of the whole transition; stage is the label for the band that
## ratio currently sits in. Called only with work that has actually finished.
func set_progress(ratio: float, stage: String) -> void:
	var clamped := clampf(ratio, 0.0, 1.0)
	if not is_equal_approx(clamped, _ratio):
		_ratio = clamped
		if _fill != null:
			_fill.anchor_right = _ratio
			_fill.color = UiTheme.CYAN.lerp(UiTheme.AMBER,
					clampf((_ratio - 0.65) / 0.35, 0.0, 1.0))
		if _percent_label != null:
			_percent_label.text = "%d%%" % int(_ratio * 100.0 + 0.5)
	if stage != _stage:
		_stage = stage
		if _stage_label != null:
			_stage_label.text = stage


func dismiss() -> void:
	visible = false
	queue_free()


func _rotate_tip(delta: float) -> void:
	if _tip_label == null:
		return
	_tip_clock += delta
	if _tip_clock < TIP_INTERVAL:
		return
	_tip_clock = 0.0
	_tip_index = (_tip_index + 1) % TIPS.size()
	_show_tip()


func _show_tip() -> void:
	if _tip_label != null:
		_tip_label.text = "TIP  //  " + TIPS[_tip_index]


func _build() -> void:
	var viewport_size := get_viewport().get_visible_rect().size
	var inset_left := MARGIN
	var inset_top := MARGIN
	var inset_right := MARGIN
	var inset_bottom := MARGIN
	var safe := DisplayServer.get_display_safe_area()
	if safe.size.x > 0 and safe.size.y > 0 and viewport_size.x > 0.0:
		var cap_x := viewport_size.x * 0.12
		var cap_y := viewport_size.y * 0.12
		inset_left = maxf(inset_left, clampf(float(safe.position.x), 0.0, cap_x))
		inset_top = maxf(inset_top, clampf(float(safe.position.y), 0.0, cap_y))
		inset_right = maxf(inset_right, clampf(
				viewport_size.x - float(safe.position.x + safe.size.x), 0.0, cap_x))
		inset_bottom = maxf(inset_bottom, clampf(
				viewport_size.y - float(safe.position.y + safe.size.y), 0.0, cap_y))

	_root = Control.new()
	_root.name = "LoadingRoot"
	_root.mouse_filter = Control.MOUSE_FILTER_STOP
	add_child(_root)
	_root.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)

	var background := ColorRect.new()
	background.name = "Background"
	background.color = Color(0.055, 0.07, 0.1)
	background.mouse_filter = Control.MOUSE_FILTER_IGNORE
	_root.add_child(background)
	background.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)

	var battle_background_path := ContentRegistry.resolve_ui_asset(&"loading_background")
	if not battle_background_path.is_empty():
		var battle_background_texture := load(battle_background_path) as Texture2D
		if battle_background_texture != null:
			var battle_background := TextureRect.new()
			battle_background.name = "BattleArtwork"
			battle_background.texture = battle_background_texture
			battle_background.expand_mode = TextureRect.EXPAND_IGNORE_SIZE
			battle_background.stretch_mode = TextureRect.STRETCH_KEEP_ASPECT_COVERED
			battle_background.modulate = Color(1.0, 1.0, 1.0, 0.42)
			battle_background.mouse_filter = Control.MOUSE_FILTER_IGNORE
			_root.add_child(battle_background)
			battle_background.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)

	var stripes := GridStripes.new()
	stripes.name = "Stripes"
	stripes.spacing = 72.0
	stripes.line_color = Color(0.3, 0.6, 0.75, 0.08)
	stripes.accent_color = Color(0.95, 0.62, 0.2, 0.07)
	stripes.mouse_filter = Control.MOUSE_FILTER_IGNORE
	_root.add_child(stripes)
	stripes.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	stripes.queue_redraw()

	var edge := ColorRect.new()
	edge.name = "EdgeStrip"
	edge.color = Color(UiTheme.CYAN.r, UiTheme.CYAN.g, UiTheme.CYAN.b, 0.6)
	edge.mouse_filter = Control.MOUSE_FILTER_IGNORE
	_root.add_child(edge)
	edge.anchor_left = 0.0
	edge.anchor_right = 0.0
	edge.anchor_top = 0.0
	edge.anchor_bottom = 1.0
	edge.offset_left = 0.0
	edge.offset_right = 4.0
	edge.offset_top = 0.0
	edge.offset_bottom = 0.0

	_build_top(inset_left, inset_right, inset_top, viewport_size)
	_build_roster(inset_left, inset_right, inset_top, viewport_size)
	_build_bottom(inset_left, inset_right, inset_bottom, viewport_size)


# Logo band + the hero line: map name huge on the left, mode chips under it,
# build stamp right-aligned — the War Robots "you are entering this map"
# composition with MECH ASSAULT info.
func _build_top(inset_left: float, inset_right: float, inset_top: float,
		viewport_size: Vector2) -> void:
	var top_bar := Control.new()
	top_bar.name = "TopBar"
	top_bar.mouse_filter = Control.MOUSE_FILTER_IGNORE
	_root.add_child(top_bar)
	top_bar.anchor_left = 0.0
	top_bar.anchor_right = 1.0
	top_bar.anchor_top = 0.0
	top_bar.anchor_bottom = 0.0
	top_bar.offset_left = inset_left
	top_bar.offset_right = -inset_right
	top_bar.offset_top = inset_top
	top_bar.offset_bottom = inset_top + TOP_HEIGHT

	var logo_texture := load("res://logo_menu.png") as Texture2D
	if logo_texture != null:
		var logo := TextureRect.new()
		logo.name = "Wordmark"
		logo.texture = logo_texture
		logo.expand_mode = TextureRect.EXPAND_IGNORE_SIZE
		logo.stretch_mode = TextureRect.STRETCH_KEEP_ASPECT_CENTERED
		logo.mouse_filter = Control.MOUSE_FILTER_IGNORE
		top_bar.add_child(logo)
		logo.anchor_left = 0.0
		logo.anchor_right = 0.0
		logo.anchor_top = 0.0
		logo.anchor_bottom = 0.0
		logo.offset_left = 0.0
		logo.offset_right = 360.0
		logo.offset_top = 0.0
		logo.offset_bottom = 54.0
	else:
		var wordmark := _label("MECH ASSAULT", 40, UiTheme.AMBER, true)
		wordmark.name = "Wordmark"
		top_bar.add_child(wordmark)
		wordmark.anchor_left = 0.0
		wordmark.anchor_right = 0.0
		wordmark.anchor_top = 0.0
		wordmark.anchor_bottom = 0.0
		wordmark.offset_left = 0.0
		wordmark.offset_right = 420.0
		wordmark.offset_top = 0.0
		wordmark.offset_bottom = 54.0

	var subtitle := _label("BATTLE DEPLOYMENT  //  %s" % GameState.BUILD_LABEL,
			14, UiTheme.MUTED, false)
	subtitle.name = "BuildLine"
	top_bar.add_child(subtitle)
	subtitle.anchor_left = 0.0
	subtitle.anchor_right = 0.0
	subtitle.anchor_top = 0.0
	subtitle.anchor_bottom = 0.0
	subtitle.offset_left = 2.0
	subtitle.offset_right = 560.0
	subtitle.offset_top = 56.0
	subtitle.offset_bottom = 84.0

	var hero_asset_path := ContentRegistry.resolve_ui_asset(&"loading_hero")
	if hero_asset_path.is_empty():
		var hook_variant: Variant = ContentRegistry.robot_asset_hooks(GameState.selected_robot).get("thumbnail", "")
		if hook_variant is String:
			var thumbnail_path := ContentRegistry.resolve_asset(hook_variant)
			if not thumbnail_path.is_empty():
				hero_asset_path = thumbnail_path
	if not hero_asset_path.is_empty():
		var hero_texture := load(hero_asset_path) as Texture2D
		if hero_texture != null:
			var hero_art := TextureRect.new()
			hero_art.name = "HeroRobotArt"
			hero_art.texture = hero_texture
			hero_art.expand_mode = TextureRect.EXPAND_IGNORE_SIZE
			hero_art.stretch_mode = TextureRect.STRETCH_KEEP_ASPECT_CENTERED
			hero_art.modulate = Color(1.0, 1.0, 1.0, 0.84)
			hero_art.mouse_filter = Control.MOUSE_FILTER_IGNORE
			top_bar.add_child(hero_art)
			hero_art.anchor_left = 1.0
			hero_art.anchor_right = 1.0
			hero_art.anchor_top = 0.0
			hero_art.anchor_bottom = 0.0
			hero_art.offset_left = -430.0
			hero_art.offset_right = -170.0
			hero_art.offset_top = -8.0
			hero_art.offset_bottom = 92.0

	var state := _label("DEPLOYING", 16, UiTheme.CYAN, true)
	state.name = "DeployState"
	state.horizontal_alignment = HORIZONTAL_ALIGNMENT_RIGHT
	top_bar.add_child(state)
	state.anchor_left = 1.0
	state.anchor_right = 1.0
	state.anchor_top = 0.0
	state.anchor_bottom = 0.0
	state.offset_left = -260.0
	state.offset_right = 0.0
	state.offset_top = 10.0
	state.offset_bottom = 40.0

	# Hero band: the map name, the single loudest thing on the screen.
	var hero := Control.new()
	hero.name = "HeroBand"
	hero.mouse_filter = Control.MOUSE_FILTER_IGNORE
	_root.add_child(hero)
	hero.anchor_left = 0.0
	hero.anchor_right = 1.0
	hero.anchor_top = 0.0
	hero.anchor_bottom = 0.0
	hero.offset_left = inset_left
	hero.offset_right = -inset_right
	hero.offset_top = inset_top + TOP_HEIGHT
	hero.offset_bottom = inset_top + TOP_HEIGHT + HERO_HEIGHT

	var map_name := _label("OPEN REALM", 46, UiTheme.AMBER, true)
	map_name.name = "MapName"
	hero.add_child(map_name)
	map_name.anchor_left = 0.0
	map_name.anchor_right = 0.0
	map_name.anchor_top = 0.0
	map_name.anchor_bottom = 0.0
	map_name.offset_left = 0.0
	map_name.offset_right = 560.0
	map_name.offset_top = 0.0
	map_name.offset_bottom = 54.0

	var chips := HBoxContainer.new()
	chips.name = "ModeChips"
	chips.add_theme_constant_override("separation", 10)
	chips.mouse_filter = Control.MOUSE_FILTER_IGNORE
	hero.add_child(chips)
	chips.anchor_left = 0.0
	chips.anchor_right = 0.0
	chips.anchor_top = 0.0
	chips.anchor_bottom = 0.0
	chips.offset_left = 0.0
	chips.offset_right = 720.0
	chips.offset_top = 56.0
	chips.offset_bottom = 88.0
	chips.add_child(_chip(MODE_LABEL, UiTheme.CYAN))
	chips.add_child(_chip("%d HOSTILES" % _hostile_total(), UiTheme.DANGER))
	chips.add_child(_chip(ROUND_TIME, UiTheme.AMBER))


# Two column briefing: who you are dropping as, and what is waiting out there.
func _build_roster(inset_left: float, inset_right: float, inset_top: float,
		viewport_size: Vector2) -> void:
	var top := inset_top + TOP_HEIGHT + HERO_HEIGHT + 8.0
	var bottom := maxf(top + 180.0,
			viewport_size.y - _block_height(viewport_size.y) - 16.0)

	var row := HBoxContainer.new()
	row.name = "RosterRow"
	row.add_theme_constant_override("separation", 18)
	row.mouse_filter = Control.MOUSE_FILTER_IGNORE
	_root.add_child(row)
	row.anchor_left = 0.0
	row.anchor_right = 1.0
	row.anchor_top = 0.0
	row.anchor_bottom = 0.0
	row.offset_left = inset_left
	row.offset_right = -inset_right
	row.offset_top = top
	row.offset_bottom = bottom

	var allies := PanelContainer.new()
	allies.name = "AlliesPanel"
	allies.add_theme_stylebox_override("panel", UiTheme.panel(0.5, UiTheme.CYAN))
	allies.mouse_filter = Control.MOUSE_FILTER_IGNORE
	allies.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	allies.size_flags_stretch_ratio = 0.92
	row.add_child(allies)
	allies.add_child(_build_allies_card())

	var hostiles := PanelContainer.new()
	hostiles.name = "HostilesPanel"
	hostiles.add_theme_stylebox_override("panel", UiTheme.panel(0.5, UiTheme.DANGER))
	hostiles.mouse_filter = Control.MOUSE_FILTER_IGNORE
	hostiles.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	hostiles.size_flags_stretch_ratio = 1.08
	row.add_child(hostiles)
	hostiles.add_child(_build_hostiles_card())


func _build_allies_card() -> VBoxContainer:
	var card := VBoxContainer.new()
	card.name = "AlliesCard"
	card.add_theme_constant_override("separation", 6)
	card.mouse_filter = Control.MOUSE_FILTER_IGNORE

	card.add_child(_label("ALLIES  //  1", 15, UiTheme.CYAN, true))

	var definition := GameState.robot_def()
	var name_label := _label(String(definition.get("name", "SCARAB")),
			27, UiTheme.AMBER, true)
	name_label.name = "RobotName"
	card.add_child(name_label)

	card.add_child(_label(String(definition.get("klass", "")), 14,
			UiTheme.MUTED, false))

	card.add_child(_kv_row("ARMOR",
			GameState.fmt_amount(float(definition.get("armor", 0.0)))))
	var ability_line := String(definition.get("ability", ""))
	var secondary := String(definition.get("secondary", ""))
	if not secondary.is_empty():
		ability_line += "  +  " + secondary
	card.add_child(_kv_row("ABILITY", ability_line))

	var families := _loadout_families()
	card.add_child(_kv_row("WEAPONS",
			"  ·  ".join(families) if families.size() > 0 else "—"))
	var builtin := String(definition.get("builtin", ""))
	if not builtin.is_empty():
		card.add_child(_kv_row("BUILT-IN", builtin))
	return card


func _build_hostiles_card() -> VBoxContainer:
	var card := VBoxContainer.new()
	card.name = "HostilesCard"
	card.add_theme_constant_override("separation", 6)
	card.mouse_filter = Control.MOUSE_FILTER_IGNORE

	card.add_child(_label("HOSTILES  //  %d" % _hostile_total(), 15,
			UiTheme.DANGER, true))

	var counts := _hostile_counts()
	for kind in KIND_ORDER:
		if not counts.has(kind):
			continue
		var count := int(counts[kind])
		if count <= 0:
			continue
		var row := HBoxContainer.new()
		row.add_theme_constant_override("separation", 10)
		row.mouse_filter = Control.MOUSE_FILTER_IGNORE
		var class_label := _label("%s  ×%d" % [
				String(HOSTILE_NAMES.get(kind, "HOSTILE")), count], 15,
				UiTheme.TEXT, false)
		class_label.size_flags_horizontal = Control.SIZE_EXPAND_FILL
		row.add_child(class_label)
		var weapon := _label(String(HOSTILE_WEAPONS.get(kind, "—")), 13,
				UiTheme.MUTED, false)
		weapon.horizontal_alignment = HORIZONTAL_ALIGNMENT_RIGHT
		row.add_child(weapon)
		card.add_child(row)
	return card


func _kv_row(key: String, value: String) -> HBoxContainer:
	var row := HBoxContainer.new()
	row.add_theme_constant_override("separation", 10)
	row.mouse_filter = Control.MOUSE_FILTER_IGNORE
	var key_label := _label(key, 13, UiTheme.MUTED, false)
	key_label.custom_minimum_size = Vector2(96.0, 0.0)
	row.add_child(key_label)
	var value_label := _label(value, 14, UiTheme.TEXT, false)
	value_label.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	value_label.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	row.add_child(value_label)
	return row


func _chip(text: String, accent: Color) -> PanelContainer:
	var chip := PanelContainer.new()
	chip.name = "Chip"
	chip.mouse_filter = Control.MOUSE_FILTER_IGNORE
	var style := StyleBoxFlat.new()
	style.bg_color = Color(0.05, 0.07, 0.09, 0.55)
	style.border_color = Color(accent.r, accent.g, accent.b, 0.7)
	style.set_border_width_all(1)
	style.set_corner_radius_all(6)
	style.content_margin_left = 12.0
	style.content_margin_right = 12.0
	style.content_margin_top = 4.0
	style.content_margin_bottom = 4.0
	chip.add_theme_stylebox_override("panel", style)
	chip.add_child(_label(text, 13, accent, true))
	return chip


func _loadout_families() -> PackedStringArray:
	var families := PackedStringArray()
	var loadout_variant: Variant = GameState.loadouts.get(
			GameState.selected_robot, [])
	if not (loadout_variant is Array):
		return families
	for item_value in loadout_variant as Array:
		var item_id := String(item_value)
		if item_id.is_empty():
			continue
		var family := GameState.item_family(item_id)
		if not family.is_empty() and not families.has(family):
			families.append(family)
	return families


func _hostile_counts() -> Dictionary:
	var counts := {}
	for kind in EnemyRobot.KIND_PATTERN:
		counts[kind] = int(counts.get(kind, 0)) + 1
	return counts


func _hostile_total() -> int:
	var total := 0
	for count in _hostile_counts().values():
		total += int(count)
	return total


func _build_bottom(inset_left: float, inset_right: float, inset_bottom: float,
		viewport_size: Vector2) -> void:
	var bottom := VBoxContainer.new()
	bottom.name = "BottomBlock"
	bottom.add_theme_constant_override("separation", 8)
	bottom.mouse_filter = Control.MOUSE_FILTER_IGNORE
	_root.add_child(bottom)
	bottom.anchor_left = 0.0
	bottom.anchor_right = 1.0
	bottom.anchor_top = 1.0
	bottom.anchor_bottom = 1.0
	bottom.offset_left = inset_left
	bottom.offset_right = -inset_right
	bottom.offset_top = -_block_height(viewport_size.y)
	bottom.offset_bottom = -inset_bottom

	var row := HBoxContainer.new()
	row.name = "StageRow"
	row.add_theme_constant_override("separation", 14)
	row.mouse_filter = Control.MOUSE_FILTER_IGNORE
	bottom.add_child(row)
	row.size_flags_horizontal = Control.SIZE_EXPAND_FILL

	_stage_label = Label.new()
	_stage_label.name = "StageLabel"
	_stage_label.text = "LOADING ASSETS"
	UiTheme.style_label(_stage_label, 16, UiTheme.CYAN, false)
	_stage_label.mouse_filter = Control.MOUSE_FILTER_IGNORE
	_stage_label.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	row.add_child(_stage_label)

	_percent_label = Label.new()
	_percent_label.name = "PercentLabel"
	_percent_label.text = "0%"
	UiTheme.style_label(_percent_label, 30, UiTheme.TEXT, true)
	_percent_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_RIGHT
	_percent_label.mouse_filter = Control.MOUSE_FILTER_IGNORE
	row.add_child(_percent_label)

	var track := Panel.new()
	track.name = "ProgressTrack"
	track.add_theme_stylebox_override("panel", UiTheme.bar_bg())
	track.custom_minimum_size = Vector2(0.0, 16.0)
	track.mouse_filter = Control.MOUSE_FILTER_IGNORE
	bottom.add_child(track)
	track.size_flags_horizontal = Control.SIZE_EXPAND_FILL

	_fill = ColorRect.new()
	_fill.name = "ProgressFill"
	_fill.color = UiTheme.CYAN
	_fill.mouse_filter = Control.MOUSE_FILTER_IGNORE
	track.add_child(_fill)
	_fill.anchor_left = 0.0
	_fill.anchor_right = 0.0
	_fill.anchor_top = 0.0
	_fill.anchor_bottom = 1.0
	_fill.offset_left = 0.0
	_fill.offset_right = 0.0
	_fill.offset_top = 0.0
	_fill.offset_bottom = 0.0

	var map_line := _label(MAP_LABEL, 15, UiTheme.AMBER, false)
	map_line.name = "MapLine"
	bottom.add_child(map_line)

	_tip_label = Label.new()
	_tip_label.name = "TipLine"
	UiTheme.style_label(_tip_label, 15, UiTheme.MUTED, false)
	_tip_label.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	_tip_label.mouse_filter = Control.MOUSE_FILTER_IGNORE
	_tip_label.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	bottom.add_child(_tip_label)


static func _block_height(viewport_height: float) -> float:
	return minf(BOTTOM_HEIGHT, maxf(140.0, viewport_height * 0.3))


func _label(text: String, size: int, color: Color, outline: bool) -> Label:
	var label := Label.new()
	label.text = text
	UiTheme.style_label(label, size, color, outline)
	label.mouse_filter = Control.MOUSE_FILTER_IGNORE
	return label
