class_name ItemPreview
extends Control

const _BG := Color(0.06, 0.075, 0.095)
const _EDGE := Color(0.3, 0.36, 0.42)
const _STEEL := Color(0.55, 0.6, 0.66)
const _DARK := Color(0.2, 0.23, 0.27)

var _robot: String = ""
var _weapon: String = ""
var _pilot: String = ""
var _drone: String = ""

func set_robot(robot_id: String) -> void:
	_robot = robot_id
	_weapon = ""
	_pilot = ""
	_drone = ""
	queue_redraw()

func set_weapon(item_id: String) -> void:
	_weapon = item_id
	_robot = ""
	_pilot = ""
	_drone = ""
	queue_redraw()

func set_pilot(pilot_id: String) -> void:
	_pilot = pilot_id
	_robot = ""
	_weapon = ""
	_drone = ""
	queue_redraw()

func set_drone(drone_id: String) -> void:
	_drone = drone_id
	_robot = ""
	_weapon = ""
	_pilot = ""
	queue_redraw()

func _draw() -> void:
	draw_rect(Rect2(Vector2.ZERO, size), _BG, true)
	if size.x < 8.0 or size.y < 8.0:
		return
	var scale_vec := Vector2(size.x / 120.0, size.y / 96.0)
	draw_set_transform(Vector2.ZERO, 0.0, scale_vec)
	draw_line(Vector2(4.0, 84.0), Vector2(116.0, 84.0), Color(1, 1, 1, 0.07), 2.0)
	if not _robot.is_empty():
		_draw_robot(_robot)
	elif not _weapon.is_empty():
		_draw_weapon(_weapon)
	elif not _pilot.is_empty():
		_draw_pilot(_pilot)
	elif not _drone.is_empty():
		_draw_drone(_drone)
	draw_set_transform(Vector2.ZERO, 0.0, Vector2.ONE)
	draw_rect(Rect2(Vector2.ZERO, size), _EDGE, false, 1.0)

# ---------------------------------------------------------------- robots

func _palette(robot_id: String) -> Array:
	match robot_id:
		"SCARAB":
			return [Color(0.82, 0.64, 0.24), Color(0.3, 0.27, 0.2), UiTheme.AMBER]
		"VORTEX":
			return [Color(0.5, 0.58, 0.72), Color(0.18, 0.22, 0.3), UiTheme.CYAN]
		"RAMPART":
			return [Color(0.36, 0.72, 0.6), Color(0.14, 0.26, 0.24),
					Color(0.5, 0.95, 0.8)]
		"PRAETOR":
			return [Color(0.7, 0.34, 0.28), Color(0.25, 0.2, 0.18), UiTheme.AMBER]
	return [_STEEL, _DARK, UiTheme.CYAN]

func _box(x: float, y: float, w: float, h: float, color: Color) -> void:
	draw_rect(Rect2(x, y, w, h), color, true)
	draw_rect(Rect2(x, y, w, h), color.darkened(0.55), false, 1.0)

func _limb(points: PackedVector2Array, width: float, color: Color) -> void:
	draw_polyline(points, color.darkened(0.55), width + 2.0)
	draw_polyline(points, color, width)

func _draw_robot(robot_id: String) -> void:
	var pal := _palette(robot_id)
	var main := pal[0] as Color
	var dark := pal[1] as Color
	var accent := pal[2] as Color
	match robot_id:
		"SCARAB":
			_limb(PackedVector2Array([Vector2(66, 58), Vector2(74, 71), Vector2(74, 84)]),
					4.0, dark)
			_limb(PackedVector2Array([Vector2(46, 58), Vector2(38, 71), Vector2(38, 84)]),
					4.0, dark)
			_limb(PackedVector2Array([Vector2(46, 56), Vector2(26, 34), Vector2(30, 20),
					Vector2(46, 17)]), 3.5, main)
			_box(46.0, 14.0, 7.0, 6.0, accent)
			draw_colored_polygon(PackedVector2Array([
				Vector2(36, 50), Vector2(44, 38), Vector2(72, 38),
				Vector2(82, 48), Vector2(72, 60), Vector2(44, 60)]), main)
			_box(40.0, 44.0, 34.0, 4.0, dark)
			_box(76.0, 42.0, 10.0, 9.0, main)
			_box(80.0, 44.0, 6.0, 3.0, accent)
			_limb(PackedVector2Array([Vector2(64, 59), Vector2(66, 72), Vector2(66, 84)]),
					4.5, main)
			_limb(PackedVector2Array([Vector2(48, 59), Vector2(44, 72), Vector2(44, 84)]),
					4.5, main)
		"VORTEX":
			_limb(PackedVector2Array([Vector2(48, 56), Vector2(44, 70), Vector2(48, 84)]),
					5.0, dark)
			_box(36.0, 28.0, 12.0, 16.0, dark)
			_box(68.0, 26.0, 14.0, 18.0, dark)
			_box(40.0, 30.0, 34.0, 27.0, main)
			_box(44.0, 34.0, 26.0, 5.0, accent.darkened(0.35))
			_box(56.0, 18.0, 11.0, 12.0, main)
			_box(58.0, 22.0, 9.0, 3.5, accent)
			_box(78.0, 32.0, 24.0, 5.0, _STEEL)
			_box(98.0, 30.0, 5.0, 9.0, _DARK)
			_limb(PackedVector2Array([Vector2(58, 56), Vector2(62, 70), Vector2(56, 84)]),
					5.5, main)
			_limb(PackedVector2Array([Vector2(58, 56), Vector2(62, 70), Vector2(56, 84)]),
					5.5, main)
		"RAMPART":
			_box(40.0, 44.0, 8.0, 6.0, dark)
			_box(32.0, 45.0, 8.0, 5.0, dark)
			_box(24.0, 46.0, 8.0, 4.0, dark)
			_box(16.0, 47.0, 8.0, 3.0, _STEEL)
			draw_colored_polygon(PackedVector2Array([
				Vector2(54, 41), Vector2(92, 24), Vector2(96, 30), Vector2(58, 46)]),
					Color(accent, 0.45))
			draw_colored_polygon(PackedVector2Array([
				Vector2(54, 47), Vector2(94, 58), Vector2(92, 63), Vector2(56, 52)]),
					Color(accent, 0.35))
			draw_colored_polygon(PackedVector2Array([
				Vector2(54, 40), Vector2(88, 20), Vector2(92, 25), Vector2(56, 44)]),
					Color(accent, 0.22))
			_box(46.0, 38.0, 24.0, 16.0, main)
			_box(68.0, 38.0, 11.0, 10.0, main)
			_box(72.0, 41.0, 7.0, 3.0, accent)
			_limb(PackedVector2Array([Vector2(52, 54), Vector2(50, 64), Vector2(56, 70)]),
					3.5, dark)
			_limb(PackedVector2Array([Vector2(64, 54), Vector2(66, 64), Vector2(60, 70)]),
					3.5, dark)
			_box(44.0, 30.0, 10.0, 6.0, dark)
		"PRAETOR":
			_limb(PackedVector2Array([Vector2(46, 56), Vector2(40, 72), Vector2(42, 84)]),
					7.0, dark)
			_box(30.0, 22.0, 13.0, 12.0, dark)
			_box(74.0, 20.0, 15.0, 13.0, dark)
			_box(84.0, 23.0, 24.0, 6.0, _STEEL)
			_box(104.0, 21.0, 6.0, 10.0, _DARK)
			_box(36.0, 26.0, 44.0, 31.0, main)
			_box(42.0, 31.0, 32.0, 6.0, accent.darkened(0.4))
			_box(48.0, 41.0, 20.0, 4.0, accent)
			_box(54.0, 12.0, 13.0, 11.0, main)
			_box(56.0, 15.0, 10.0, 3.5, accent)
			_limb(PackedVector2Array([Vector2(60, 57), Vector2(64, 72), Vector2(60, 84)]),
					7.5, main)
		_:
			_box(40.0, 34.0, 34.0, 24.0, main)
			_box(52.0, 24.0, 12.0, 10.0, main)
			_box(54.0, 27.0, 8.0, 3.0, accent)
			_limb(PackedVector2Array([Vector2(48, 58), Vector2(44, 72), Vector2(46, 84)]),
					5.0, dark)
			_limb(PackedVector2Array([Vector2(66, 58), Vector2(70, 72), Vector2(68, 84)]),
					5.0, dark)

# ---------------------------------------------------------------- weapons

func _family_color(family: String) -> Color:
	match family:
		"VOLT", "ARCLANCE", "DRONE":
			return Color(0.35, 0.9, 1.0)
		"TORQ", "LUMEN":
			return Color(0.55, 0.75, 1.0)
		"FERRIC":
			return Color(0.5, 0.85, 0.4)
		"PYRE":
			return Color(1.0, 0.6, 0.2)
		"VOLLEY", "BREACH", "DEMOLISHER", "JUGGERNAUT":
			return Color(1.0, 0.75, 0.3)
		"CELERITY", "OVERLORD":
			return Color(0.8, 0.9, 1.0)
	return UiTheme.AMBER

func _draw_weapon(item_id: String) -> void:
	var family := item_id.get_slice("-", 0)
	var accent := _family_color(family)
	draw_rect(Rect2(30.0, 62.0, 60.0, 4.0), Color(0, 0, 0, 0.35), true)
	_box(40.0, 40.0, 36.0, 16.0, _STEEL)
	draw_colored_polygon(PackedVector2Array([
		Vector2(46, 56), Vector2(56, 56), Vector2(54, 67), Vector2(46, 67)]), _DARK)
	match family:
		"RAZOR", "JUGGERNAUT":
			_box(74.0, 43.0, 26.0, 6.0, _STEEL)
			_box(96.0, 41.0, 6.0, 10.0, _DARK)
			_box(48.0, 52.0, 12.0, 12.0, _DARK)
			draw_circle(Vector2(54.0, 58.0), 7.0, accent.darkened(0.4))
			draw_circle(Vector2(54.0, 58.0), 3.0, accent)
			_box(60.0, 48.0, 10.0, 5.0, _DARK)
			if family == "JUGGERNAUT":
				_box(74.0, 34.0, 30.0, 5.0, _STEEL)
				_box(96.0, 32.0, 6.0, 9.0, _DARK)
		"MAUL", "HAVOC":
			if family == "HAVOC":
				_box(74.0, 38.0, 22.0, 5.0, _STEEL)
				_box(74.0, 45.0, 22.0, 5.0, _STEEL)
				_box(74.0, 52.0, 18.0, 5.0, _STEEL)
				_box(46.0, 52.0, 12.0, 12.0, _DARK)
				draw_circle(Vector2(52.0, 58.0), 7.0, accent.darkened(0.4))
			else:
				_box(74.0, 40.0, 22.0, 12.0, _STEEL)
				_box(88.0, 38.0, 4.0, 16.0, _DARK)
				_box(94.0, 38.0, 4.0, 16.0, _DARK)
				_box(44.0, 52.0, 14.0, 14.0, _DARK)
				draw_circle(Vector2(51.0, 59.0), 9.0, accent.darkened(0.45))
				draw_circle(Vector2(51.0, 59.0), 4.0, accent)
		"VOLT", "ARCLANCE":
			_box(74.0, 44.0, 20.0, 4.0, _STEEL)
			for i in 3:
				_box(76.0 + float(i) * 9.0, 37.0, 6.0, 6.0, accent.darkened(0.35))
			_limb(PackedVector2Array([Vector2(94, 44), Vector2(110, 39)]), 2.5, accent)
			_limb(PackedVector2Array([Vector2(94, 48), Vector2(110, 53)]), 2.5, accent)
			draw_circle(Vector2(111.0, 38.5), 3.0, accent)
			draw_circle(Vector2(111.0, 53.5), 3.0, accent)
			_box(48.0, 34.0, 16.0, 7.0, accent.darkened(0.5))
		"TORQ", "CELERITY":
			if family == "TORQ":
				_limb(PackedVector2Array([Vector2(76, 42), Vector2(108, 42)]), 3.0, accent)
				_limb(PackedVector2Array([Vector2(76, 50), Vector2(108, 50)]), 3.0, accent)
				_box(104.0, 38.0, 4.0, 14.0, _DARK)
				_box(46.0, 33.0, 7.0, 7.0, accent.darkened(0.4))
				_box(56.0, 33.0, 7.0, 7.0, accent.darkened(0.4))
			else:
				for i in 3:
					_limb(PackedVector2Array([
						Vector2(76, 42.0 + float(i) * 4.0),
						Vector2(104, 42.0 + float(i) * 4.0)]), 2.5, accent)
				_box(102.0, 39.0, 5.0, 14.0, _DARK)
		"BREACH", "DEMOLISHER", "VOLLEY":
			if family == "VOLLEY":
				_box(68.0, 34.0, 34.0, 26.0, _DARK)
				for i in 3:
					for row in 2:
						draw_circle(Vector2(76.0 + float(i) * 11.0,
								42.0 + float(row) * 12.0), 4.0, Color(0.1, 0.12, 0.14))
						draw_circle(Vector2(76.0 + float(i) * 11.0,
								42.0 + float(row) * 12.0), 4.0, _STEEL)
						draw_circle(Vector2(76.0 + float(i) * 11.0,
								42.0 + float(row) * 12.0), 2.4, Color(0.08, 0.1, 0.12))
				_box(44.0, 36.0, 16.0, 8.0, accent.darkened(0.5))
			elif family == "BREACH":
				_box(72.0, 38.0, 32.0, 14.0, _DARK)
				_box(68.0, 34.0, 5.0, 22.0, _STEEL)
				draw_colored_polygon(PackedVector2Array([
					Vector2(40, 40), Vector2(30, 34), Vector2(30, 46)]), accent.darkened(0.4))
				_box(96.0, 36.0, 6.0, 18.0, _STEEL)
			else:
				_box(68.0, 36.0, 36.0, 19.0, _DARK)
				_box(100.0, 33.0, 7.0, 25.0, _STEEL)
				_box(44.0, 38.0, 14.0, 8.0, accent.darkened(0.5))
		"FERRIC":
			_box(26.0, 38.0, 20.0, 22.0, accent.darkened(0.55))
			_box(28.0, 42.0, 16.0, 4.0, accent.darkened(0.3))
			_limb(PackedVector2Array([
				Vector2(46, 48), Vector2(58, 56), Vector2(70, 50)]), 3.0, _DARK)
			draw_colored_polygon(PackedVector2Array([
				Vector2(74, 43), Vector2(96, 39), Vector2(96, 53), Vector2(74, 49)]),
					accent.darkened(0.35))
			_box(94.0, 42.0, 4.0, 8.0, accent)
		"LUMEN":
			draw_colored_polygon(PackedVector2Array([
				Vector2(74, 40), Vector2(96, 35), Vector2(96, 57), Vector2(74, 52)]),
					_DARK)
			draw_circle(Vector2(96.0, 46.0), 8.0, Color(accent, 0.3))
			draw_circle(Vector2(96.0, 46.0), 5.0, accent)
			for i in 3:
				_box(44.0 + float(i) * 8.0, 33.0, 5.0, 7.0, _STEEL)
			_box(48.0, 54.0, 18.0, 6.0, accent.darkened(0.5))
		"PYRE":
			_box(74.0, 42.0, 14.0, 9.0, _DARK)
			_box(54.0, 32.0, 12.0, 9.0, accent.darkened(0.5))
			draw_colored_polygon(PackedVector2Array([
				Vector2(88, 43), Vector2(110, 47), Vector2(88, 51)]),
					Color(accent, 0.85))
			draw_colored_polygon(PackedVector2Array([
				Vector2(88, 45), Vector2(102, 47), Vector2(88, 49)]),
					Color(1.0, 0.9, 0.5, 0.9))
		"OVERLORD":
			_box(44.0, 33.0, 14.0, 8.0, accent.darkened(0.4))
			draw_circle(Vector2(64.0, 44.0), 6.0, accent.darkened(0.4))
			draw_circle(Vector2(64.0, 44.0), 3.0, accent)
			_box(74.0, 40.0, 30.0, 4.0, _STEEL)
			_box(74.0, 46.0, 30.0, 4.0, _STEEL)
			_box(98.0, 37.0, 6.0, 15.0, _DARK)
		_:
			_box(74.0, 43.0, 26.0, 6.0, _STEEL)
			_box(96.0, 41.0, 6.0, 10.0, _DARK)
			_box(50.0, 54.0, 12.0, 10.0, _DARK)
			draw_circle(Vector2(56.0, 59.0), 6.0, accent.darkened(0.4))

# ---------------------------------------------------------------- pilots

func _rarity_color(rarity: int) -> Color:
	match rarity:
		2: return Color(0.35, 0.85, 1.0)
		3: return Color(1.0, 0.82, 0.3)
	return Color(0.6, 0.66, 0.72)

func _draw_pilot(pilot_id: String) -> void:
	var rarity := 1
	var klass := "STRIKER"
	for definition in GameState.PILOT_DEFS:
		if String(definition.get("id", "")) == pilot_id:
			rarity = int(definition.get("rarity", 1))
			klass = String(definition.get("klass", ""))
			break
	var band := _rarity_color(rarity)
	# shoulder blocks
	_box(28.0, 56.0, 22.0, 22.0, _DARK)
	_box(70.0, 56.0, 22.0, 22.0, _DARK)
	_box(34.0, 58.0, 12.0, 5.0, band.darkened(0.4))
	_box(74.0, 58.0, 12.0, 5.0, band.darkened(0.4))
	# chest plate
	_box(44.0, 50.0, 32.0, 30.0, _STEEL)
	_box(47.0, 54.0, 26.0, 6.0, band)
	_box(47.0, 63.0, 26.0, 3.0, _DARK)
	# helmet
	_box(46.0, 24.0, 28.0, 26.0, _STEEL)
	_box(42.0, 30.0, 6.0, 14.0, _DARK)
	_box(72.0, 30.0, 6.0, 14.0, _DARK)
	_box(50.0, 34.0, 20.0, 8.0, Color(0.05, 0.08, 0.1))
	_box(50.0, 36.0, 20.0, 4.0, band)
	# rank chevrons
	for i in rarity:
		draw_colored_polygon(PackedVector2Array([
			Vector2(50.0 + float(i) * 7.0, 46.0),
			Vector2(53.5 + float(i) * 7.0, 42.0),
			Vector2(57.0 + float(i) * 7.0, 46.0)]), band)
	if klass == "TACTICIAN":
		_box(78.0, 44.0, 14.0, 4.0, band)

# ---------------------------------------------------------------- drones

func _draw_drone(drone_id: String) -> void:
	var accent := UiTheme.CYAN
	match drone_id:
		"bulwark": accent = Color(1.0, 0.78, 0.3)
		"patch": accent = Color(0.45, 0.9, 0.5)
		"kestrel": accent = Color(1.0, 0.55, 0.25)
	# dorsal wing pair
	draw_colored_polygon(PackedVector2Array([
		Vector2(56, 46), Vector2(24, 30), Vector2(30, 44), Vector2(54, 52)]),
			Color(accent, 0.45))
	draw_colored_polygon(PackedVector2Array([
		Vector2(56, 46), Vector2(92, 30), Vector2(88, 44), Vector2(58, 52)]),
			Color(accent, 0.3))
	# hull
	draw_colored_polygon(PackedVector2Array([
		Vector2(38, 50), Vector2(72, 44), Vector2(92, 52),
		Vector2(72, 62), Vector2(40, 60)]), _STEEL)
	_box(44.0, 52.0, 30.0, 5.0, _DARK)
	# eye + nozzle
	draw_circle(Vector2(88.0, 52.0), 5.0, accent.darkened(0.4))
	draw_circle(Vector2(88.0, 52.0), 2.6, accent)
	_box(30.0, 52.0, 10.0, 6.0, _DARK)
	_limb(PackedVector2Array([Vector2(50, 60), Vector2(48, 72), Vector2(56, 78)]), 3.0, _DARK)
	_limb(PackedVector2Array([Vector2(66, 60), Vector2(68, 72), Vector2(60, 78)]), 3.0, _DARK)
