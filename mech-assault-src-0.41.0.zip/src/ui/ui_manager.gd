class_name UIManager
extends Control

# App-shell screen manager: one stack of screens, persistent top chrome
# (resource bar), a toast line and the quit confirm. Screens are created
# lazily from SCREEN_SCRIPTS and live in the tree for the whole session.
#
# Navigation: push() opens a screen on top, pop() goes back (ui_cancel /
# BACK / Events.ui_back_requested all route through handle_back).
# Opaque screens hide everything below them; overlays (the equipment
# workspace) keep the hangar bay visible and interactive underneath.

signal screen_changed(screen: StringName)

# Scripts are loaded by path on first use (a parse-time preload of the
# screens would make a circular reference through UiScreen.setup()).
const SCREEN_SCRIPTS: Dictionary = {
	&"robot_equipment": "res://src/ui/screens/robot_screen.gd",
	&"settings_general": "res://src/ui/screens/mega_hub_screen.gd",
	&"settings_controls": "res://src/ui/screens/mega_hub_screen.gd",
	&"settings_aiming": "res://src/ui/screens/mega_hub_screen.gd",
	&"settings_battle_hud": "res://src/ui/screens/mega_hub_screen.gd",
	&"settings_graphics": "res://src/ui/screens/mega_hub_screen.gd",
	&"settings_audio": "res://src/ui/screens/mega_hub_screen.gd",
	&"settings_accessibility": "res://src/ui/screens/mega_hub_screen.gd",
	&"settings_notifications": "res://src/ui/screens/mega_hub_screen.gd",
	&"settings_language": "res://src/ui/screens/mega_hub_screen.gd",
	&"settings_account": "res://src/ui/screens/mega_hub_screen.gd",
	&"settings_social_privacy": "res://src/ui/screens/mega_hub_screen.gd",
	&"settings_about": "res://src/ui/screens/mega_hub_screen.gd",
	&"battle": "res://src/ui/screens/mega_hub_screen.gd",
	&"battle_robot_select": "res://src/ui/screens/mega_hub_screen.gd",
	&"battle_pause": "res://src/ui/screens/mega_hub_screen.gd",
	&"reward_claim": "res://src/ui/screens/mega_hub_screen.gd",
	&"loading": "res://src/ui/loading_screen.gd",
	&"errors": "res://src/ui/screens/mega_hub_screen.gd",
	&"tutorial": "res://src/ui/screens/mega_hub_screen.gd",
	&"confirmation": "res://src/ui/screens/mega_hub_screen.gd",
	&"toast": "res://src/ui/screens/mega_hub_screen.gd",
	&"notifications": "res://src/ui/screens/mega_hub_screen.gd",
	&"hangar": "res://src/ui/screens/hangar_screen.gd",
	&"robot": "res://src/ui/screens/robot_screen.gd",
	&"weapon_select": "res://src/ui/screens/weapon_select_screen.gd",
	&"weapon_detail": "res://src/ui/screens/weapon_detail_screen.gd",
	&"upgrade": "res://src/ui/screens/upgrade_screen.gd",
	&"pilot": "res://src/ui/screens/pilot_screen.gd",
	&"drone": "res://src/ui/screens/drone_screen.gd",
	&"spec": "res://src/ui/screens/spec_screen.gd",
	&"store": "res://src/ui/screens/store_screen.gd",
	&"inventory": "res://src/ui/screens/inventory_screen.gd",
	&"settings": "res://src/ui/screens/settings_screen.gd",
	&"stats": "res://src/ui/screens/stats_screen.gd",
	&"game_modes": "res://src/ui/screens/mega_hub_screen.gd",
	&"matchmaking": "res://src/ui/screens/mega_hub_screen.gd",
	&"deployment": "res://src/ui/screens/mega_hub_screen.gd",
	&"workshop": "res://src/ui/screens/mega_hub_screen.gd",
	&"collections": "res://src/ui/screens/mega_hub_screen.gd",
	&"events": "res://src/ui/screens/mega_hub_screen.gd",
	&"datapads": "res://src/ui/screens/mega_hub_screen.gd",
	&"operations": "res://src/ui/screens/mega_hub_screen.gd",
	&"missions": "res://src/ui/screens/mega_hub_screen.gd",
	&"leaderboards": "res://src/ui/screens/mega_hub_screen.gd",
	&"profile": "res://src/ui/screens/mega_hub_screen.gd",
	&"friends": "res://src/ui/screens/mega_hub_screen.gd",
	&"squad": "res://src/ui/screens/mega_hub_screen.gd",
	&"clan": "res://src/ui/screens/mega_hub_screen.gd",
	&"news": "res://src/ui/screens/mega_hub_screen.gd",
	&"hud_editor": "res://src/ui/screens/mega_hub_screen.gd",
	&"titan_equipment": "res://src/ui/screens/mega_hub_screen.gd",
	&"weapon_inventory": "res://src/ui/screens/mega_hub_screen.gd",
	&"robot_inventory": "res://src/ui/screens/mega_hub_screen.gd",
	&"pilot_inventory": "res://src/ui/screens/mega_hub_screen.gd",
	&"drone_inventory": "res://src/ui/screens/mega_hub_screen.gd",
	&"specialization": "res://src/ui/screens/mega_hub_screen.gd",
	&"starbase": "res://src/ui/screens/mega_hub_screen.gd",
	&"post_battle": "res://src/ui/screens/mega_hub_screen.gd",
	&"rewards": "res://src/ui/screens/mega_hub_screen.gd",
}

const SCREEN_NAMES: Dictionary = {
	&"robot_equipment": "RobotEquipmentScreen",
	&"settings_general": "GeneralSettingsScreen",
	&"settings_controls": "ControlsSettingsScreen",
	&"settings_aiming": "AimingSettingsScreen",
	&"settings_battle_hud": "BattleHudSettingsScreen",
	&"settings_graphics": "GraphicsSettingsScreen",
	&"settings_audio": "AudioSettingsScreen",
	&"settings_accessibility": "AccessibilitySettingsScreen",
	&"settings_notifications": "NotificationsSettingsScreen",
	&"settings_language": "LanguageSettingsScreen",
	&"settings_account": "AccountSettingsScreen",
	&"settings_social_privacy": "SocialPrivacySettingsScreen",
	&"settings_about": "AboutSettingsScreen",
	&"battle": "BattleScreen",
	&"battle_robot_select": "BattleRobotSelectScreen",
	&"battle_pause": "BattlePauseScreen",
	&"reward_claim": "RewardClaimScreen",
	&"loading": "LoadingScreen",
	&"errors": "ErrorScreen",
	&"tutorial": "TutorialScreen",
	&"confirmation": "ConfirmationScreen",
	&"toast": "ToastScreen",
	&"notifications": "NotificationCenterScreen",
	&"hangar": "HangarScreen",
	&"robot": "RobotScreen",
	&"weapon_select": "WeaponSelectScreen",
	&"weapon_detail": "WeaponDetailScreen",
	&"upgrade": "UpgradeScreen",
	&"pilot": "PilotScreen",
	&"drone": "DroneScreen",
	&"spec": "SpecScreen",
	&"store": "StoreScreen",
	&"inventory": "InventoryScreen",
	&"settings": "SettingsScreen",
	&"stats": "StatsScreen",
	&"game_modes": "GameModesScreen",
	&"matchmaking": "MatchmakingScreen",
	&"deployment": "DeploymentScreen",
	&"workshop": "WorkshopScreen",
	&"collections": "CollectionsScreen",
	&"events": "EventsScreen",
	&"datapads": "DataPadsScreen",
	&"operations": "OperationsScreen",
	&"missions": "MissionsScreen",
	&"leaderboards": "LeaderboardsScreen",
	&"profile": "ProfileScreen",
	&"friends": "FriendsScreen",
	&"squad": "SquadScreen",
	&"clan": "ClanScreen",
	&"news": "NewsScreen",
	&"hud_editor": "HudEditorScreen",
	&"titan_equipment": "TitanEquipmentScreen",
	&"weapon_inventory": "WeaponInventoryScreen",
	&"robot_inventory": "RobotInventoryScreen",
	&"pilot_inventory": "PilotInventoryScreen",
	&"drone_inventory": "DroneInventoryScreen",
	&"specialization": "SpecializationScreen",
	&"starbase": "StarbaseScreen",
	&"post_battle": "PostBattleScreen",
	&"rewards": "RewardsScreen",
}

const TOAST_DURATION := 1.8
const BAR_MARGIN := 18.0

var _screens: Dictionary = {}
var _stack: Array[StringName] = []
var _screens_root: Control
var _bar: ResourceBar
var _toast: Label
var _toast_time: float = 0.0
var _quit_panel: Panel
var _leaving: bool = false

func _init() -> void:
	set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	mouse_filter = Control.MOUSE_FILTER_IGNORE

func _ready() -> void:
	_screens_root = Control.new()
	_screens_root.name = "Screens"
	_screens_root.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	_screens_root.mouse_filter = Control.MOUSE_FILTER_IGNORE
	add_child(_screens_root)

	_bar = ResourceBar.new()
	add_child(_bar)

	var controller_prompts_script := preload("res://src/ui/controller_prompt_bar.gd")
	var controller_prompts := controller_prompts_script.new() as Control
	controller_prompts.name = "ControllerPromptBar"
	add_child(controller_prompts)
	controller_prompts.anchor_left = 0.0
	controller_prompts.anchor_right = 1.0
	controller_prompts.anchor_top = 1.0
	controller_prompts.anchor_bottom = 1.0
	controller_prompts.offset_left = BAR_MARGIN
	controller_prompts.offset_right = -BAR_MARGIN
	controller_prompts.offset_top = -52.0
	controller_prompts.offset_bottom = -BAR_MARGIN

	_build_toast()
	_build_quit_confirm()

	# Back routing: a single path only (this node's _unhandled_input on
	# ui_cancel). The pad-B Events.ui_back_requested emit would otherwise
	# double-pop, because JOY_BUTTON_B is bound to ui_cancel as well.
	push(&"hangar")

func _process(delta: float) -> void:
	if _toast_time > 0.0:
		_toast_time -= delta
		if _toast_time <= 0.0:
			_toast_time = 0.0
			_toast.visible = false

func _unhandled_input(event: InputEvent) -> void:
	if _leaving:
		return
	if event.is_action_pressed(&"ui_cancel"):
		handle_back()

# ------------------------------------------------------------ navigation

func current() -> StringName:
	if _stack.is_empty():
		return &""
	return _stack[_stack.size() - 1]

func stack_depth() -> int:
	return _stack.size()

func has_screen(screen: StringName) -> bool:
	return SCREEN_SCRIPTS.has(screen)

# Direct access to an already-created screen (screens below overlays need
# to coordinate — the equipment workspace pushes the bay camera close).
func screen(screen_name: StringName) -> UiScreen:
	return _screen_for(screen_name)

func push(screen: StringName, params: Dictionary = {}) -> void:
	var node := _screen_for(screen)
	if node == null:
		return
	if current() == screen:
		node.open(params)
		node.refresh()
		return
	AudioEngine.play(&"ui")
	_stack.append(screen)
	_screens_root.move_child(node, _screens_root.get_child_count() - 1)
	node.open(params)
	_apply_visibility()
	node.on_enter()
	_refresh_focus()
	screen_changed.emit(screen)

func pop() -> bool:
	if _stack.size() <= 1:
		return false
	var leaving_name: StringName = _stack[_stack.size() - 1]
	_stack.remove_at(_stack.size() - 1)
	var leaving_node := _screen_for(leaving_name)
	if leaving_node != null:
		leaving_node.on_exit()
	AudioEngine.play(&"ui")
	_apply_visibility()
	var top := current()
	var top_node := _screen_for(top)
	if top_node != null:
		top_node.on_enter()
	_refresh_focus()
	screen_changed.emit(top)
	return true

# BACK / ui_cancel: close the top screen; at the hangar root, ask to quit.
func handle_back() -> void:
	if _leaving:
		return
	if _quit_panel.visible:
		_hide_quit_confirm()
		return
	if _stack.size() > 1:
		pop()
	else:
		_show_quit_confirm()

func refresh() -> void:
	if _bar != null:
		_bar.refresh()
	for screen_name: StringName in _stack:
		var node := _screen_for(screen_name)
		if node != null:
			node.refresh()

func toast(text: String, error: bool = false) -> void:
	_toast.text = text
	_toast.add_theme_color_override(
			"font_color", UiTheme.DANGER if error else UiTheme.TEXT)
	_toast.visible = true
	_toast_time = TOAST_DURATION

func begin_leaving() -> void:
	_leaving = true

# Ask to quit from any depth (the confirm panel draws above the screens).
func request_quit() -> void:
	_show_quit_confirm()

# ------------------------------------------------------------ internals

func _screen_for(screen: StringName) -> UiScreen:
	if _screens.has(screen):
		return _screens[screen] as UiScreen
	var path: Variant = SCREEN_SCRIPTS.get(screen)
	if path == null:
		return null
	var script: Variant = load(String(path))
	if script == null:
		return null
	var node: UiScreen = script.new()
	node.name = String(SCREEN_NAMES.get(screen, String(screen)))
	node.setup(self)
	_screens[screen] = node
	_screens_root.add_child(node)
	return node

# Topmost screen visible; below that, only screens not covered by an
# opaque screen above them stay in the tree visible (overlays let the
# hangar bay show through). Screens no longer in the stack (popped) are
# hidden outright — they keep their last visible flag otherwise.
func _apply_visibility() -> void:
	var in_stack: Dictionary = {}
	for screen_name: StringName in _stack:
		in_stack[screen_name] = true
	for key: StringName in _screens:
		if not in_stack.has(key):
			(_screens[key] as UiScreen).visible = false
	var covered := false
	for index in range(_stack.size() - 1, -1, -1):
		var node := _screen_for(_stack[index])
		if node == null:
			continue
		if covered:
			node.visible = false
		else:
			node.visible = true
			if node.is_opaque():
				covered = true

func _refresh_focus() -> void:
	if PlatformUtil.effective_mode() != PlatformUtil.InputMode.GAMEPAD:
		return
	var node := _screen_for(current())
	if node == null:
		return
	var back := node.find_child("BackButton", true, false)
	if back is Control and (back as Control).focus_mode != Control.FOCUS_NONE:
		(back as Control).grab_focus()
		return
	var start := node.find_child("StartButton", true, false)
	if start is Control and (start as Control).focus_mode != Control.FOCUS_NONE:
		(start as Control).grab_focus()
		return
	GamepadNav.focus_default(node)

func _build_toast() -> void:
	_toast = Label.new()
	_toast.name = "ToastLabel"
	_toast.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	UiTheme.style_label(_toast, 20, UiTheme.TEXT, true)
	_toast.set_anchors_and_offsets_preset(Control.PRESET_CENTER_TOP)
	_toast.anchor_left = 0.5
	_toast.anchor_right = 0.5
	_toast.offset_top = 96.0
	_toast.offset_bottom = 130.0
	_toast.offset_left = -420.0
	_toast.offset_right = 420.0
	_toast.mouse_filter = Control.MOUSE_FILTER_IGNORE
	_toast.visible = false
	add_child(_toast)

func _build_quit_confirm() -> void:
	_quit_panel = Panel.new()
	_quit_panel.name = "QuitConfirm"
	_quit_panel.visible = false
	_quit_panel.set_anchors_and_offsets_preset(Control.PRESET_CENTER)
	_quit_panel.custom_minimum_size = Vector2(460.0, 220.0)
	_quit_panel.offset_left = -230.0
	_quit_panel.offset_right = 230.0
	_quit_panel.offset_top = -110.0
	_quit_panel.offset_bottom = 110.0
	_quit_panel.add_theme_stylebox_override("panel", UiTheme.panel(0.97, UiTheme.DANGER))
	add_child(_quit_panel)

	var column := UiParts.vbox(14.0)
	column.name = "QuitBox"
	column.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	column.offset_left = 24.0
	column.offset_top = 20.0
	column.offset_right = -24.0
	column.offset_bottom = -20.0
	_quit_panel.add_child(column)

	var title := UiParts.label("LEAVE MECH ASSAULT?", 22, UiTheme.TEXT, true)
	title.name = "QuitTitle"
	title.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	column.add_child(title)

	var hint := UiParts.label("PROGRESS IS SAVED AUTOMATICALLY", 12, UiTheme.MUTED)
	hint.name = "QuitHint"
	hint.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	column.add_child(hint)

	var row := UiParts.hbox(12.0)
	row.name = "QuitActions"
	column.add_child(row)

	var cancel := UiParts.button("CANCEL", UiTheme.CYAN, 16, Vector2(190.0, 52.0))
	cancel.name = "QuitCancelButton"
	UiParts.wire(cancel, _hide_quit_confirm)
	row.add_child(cancel)

	var confirm := UiParts.button("EXIT", UiTheme.DANGER, 16, Vector2(190.0, 52.0))
	confirm.name = "QuitConfirmButton"
	UiParts.wire(confirm, _on_quit_confirmed)
	row.add_child(confirm)

func _show_quit_confirm() -> void:
	AudioEngine.play(&"ui")
	_quit_panel.visible = true
	if PlatformUtil.effective_mode() == PlatformUtil.InputMode.GAMEPAD:
		GamepadNav.focus_default(_quit_panel, "QuitCancelButton")

func _hide_quit_confirm() -> void:
	_quit_panel.visible = false

func _on_quit_confirmed() -> void:
	AudioEngine.play(&"ui")
	_leaving = true
	get_tree().quit()
