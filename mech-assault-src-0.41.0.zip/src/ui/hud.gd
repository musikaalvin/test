class_name Hud
extends Control

const MARGIN := 18.0
const PANEL_COLOR := Color(0.02, 0.03, 0.045, 0.74)
const CYAN := Color(0.25, 0.9, 1.0)
const HEALTH_COLOR := Color(0.3, 0.95, 0.55)
const HEAT_COLOR := Color(1.0, 0.62, 0.18)
const DANGER := Color(1.0, 0.22, 0.16)
const EMPTY_COLOR := Color(1.0, 1.0, 1.0, 0.12)
const TIMER_COLOR := Color(0.86, 0.94, 1.0)
const MATCH_LENGTH := 600.0
const TIMER_WARN := 60.0
const TIMER_URGENT := 15.0
const HEALTH_SYNC_INTERVAL := 0.2
const HP_PANEL_WIDTH := 236.0
const HP_PANEL_HEIGHT := 66.0
const MENU_BUTTON_WIDTH := 96.0
const MENU_BUTTON_HEIGHT := 44.0
const TIMER_PANEL_WIDTH := 168.0
const TIMER_PANEL_HEIGHT := 72.0
const RADAR_SIZE := 150.0
const RADAR_RANGE := 55.0
const RADAR_SCAN_INTERVAL := 0.5
const FPS_INTERVAL := 0.4

var _safe := Vector2.ZERO

var _player: PlayerRobot
var _counter_label: Label
var _kills_label: Label
var _fps_label: Label
var _fps_clock: float = 0.0
var _locked_enemy: Node3D
var _radar: RadarScope
var _radar_clock: float = 0.0
var _kill_feed: KillFeed
var _status_feed: StatusFeed
var _health_label: Label
var _health_fill: ColorRect
var _health_missing: ColorRect
var _health_hull: ColorRect
var _heat_label: Label
var _heat_fill: ColorRect
var _overheat_label: Label
var _ammo_label: Label
var _group_labels: Array[Label] = []
var _critical_chip: Label
var _crit_pulse: float = 0.0
var _hp_panel: Panel
var _menu_button: Button
var _hint_strip: Panel
var _hint_label: Label
var _timer_panel: Panel
var _timer_label: Label
var _player_health: Health
var _time_left: float = MATCH_LENGTH
var _timed_out: bool = false
var _health_sync_clock: float = HEALTH_SYNC_INTERVAL
var _timer_shown: String = ""
var _timer_tint: Color = TIMER_COLOR
var _pip_fills: Array[ColorRect] = []
var _pip_ratio: Array[float] = []
var _pip_count: int = 0
var _phase_label: Label
var _primary_phase: String = ""
var _secondary_phase: String = ""
var _crosshair_mod: ColorRect
var _crosshair_ring: ColorRect
var _hitmarker: Control
var _vignette: ColorRect
var _stealth_chip: Label
var _hazard_chip: Label
var _prompt: Label
var _prompt_tween: Tween
var _lock_frame: Control
var _end_panel: Control
var _end_title: Label
var _end_stats: Label
var _end_subtitle: Label
var _report_values: Array[Label] = []
var _overheated: bool = false
var _blink_clock: float = 0.0
var _hit_tween: Tween
var _vignette_tween: Tween

func _ready() -> void:
	mouse_filter = Control.MOUSE_FILTER_IGNORE
	set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	var safe_area := DisplayServer.get_display_safe_area()
	_safe = Vector2(safe_area.position)
	_build_right_column()
	_build_player_vitals()
	_build_menu_button()
	_build_control_hints()
	_build_timer()
	_build_radar()
	_build_fps_chip()
	_build_crosshair()
	_build_overlays()
	_connect_events()
	_kill_feed = KillFeed.new()
	_kill_feed.name = "KillFeed"
	_place_right(_kill_feed, 196.0, 250.0, 78.0)
	add_child(_kill_feed)
	# War Robots-style red status ticker along the bottom centre.
	_status_feed = StatusFeed.new()
	_status_feed.name = "StatusFeed"
	_status_feed.anchor_left = 0.5
	_status_feed.anchor_right = 0.5
	_status_feed.anchor_top = 1.0
	_status_feed.anchor_bottom = 1.0
	_status_feed.offset_left = -260.0
	_status_feed.offset_right = 260.0
	_status_feed.offset_top = -150.0
	_status_feed.offset_bottom = -52.0
	add_child(_status_feed)
	var numbers := DamageNumbers.new()
	numbers.name = "DamageNumbers"
	add_child(numbers)
	var markers := EnemyMarkers.new()
	markers.name = "EnemyMarkers"
	add_child(markers)

func setup(player: PlayerRobot) -> void:
	if player == null:
		return
	_player = player
	_player_health = player.health
	if player.health != null:
		_set_health(player.health.current, player.health.max_health)
	if player.ability != null:
		_set_charges(player.ability.charges, player.ability.max_charges,
				player.ability.recharge_ratio())
		_set_phase(player.ability.phase_name)
	_counter_label.text = "HOSTILES %d" % GameState.remaining_enemies()

# ---------------------------------------------------------------- construction

func _place_right(control: Control, y: float, width: float, height: float) -> void:
	control.anchor_left = 1.0
	control.anchor_right = 1.0
	control.anchor_top = 0.0
	control.anchor_bottom = 0.0
	control.offset_left = -MARGIN - _safe.x - width
	control.offset_right = -MARGIN - _safe.x
	control.offset_top = MARGIN + _safe.y + y
	control.offset_bottom = MARGIN + _safe.y + y + height

func _build_right_column() -> void:
	var stats_panel := Panel.new()
	stats_panel.name = "StatsPanel"
	stats_panel.add_theme_stylebox_override("panel", UiTheme.panel(0.66))
	stats_panel.anchor_left = 1.0
	stats_panel.anchor_right = 1.0
	stats_panel.offset_left = -MARGIN - _safe.x - 258.0
	stats_panel.offset_right = -MARGIN - _safe.x + 14.0
	stats_panel.offset_top = MARGIN + _safe.y - 14.0
	stats_panel.offset_bottom = MARGIN + _safe.y + 196.0
	stats_panel.mouse_filter = Control.MOUSE_FILTER_IGNORE
	add_child(stats_panel)
	_counter_label = _make_label("HOSTILES 3", 22, CYAN)
	_place_right(_counter_label, 0.0, 240.0, 30.0)
	_counter_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_RIGHT

	_heat_label = _make_label("HEAT", 13, HEAT_COLOR)
	_place_right(_heat_label, 40.0, 240.0, 18.0)
	_heat_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_RIGHT

	_heat_fill = _make_bar(Vector2(240.0, 9.0), 64.0, HEAT_COLOR)

	_overheat_label = _make_label("OVERHEAT", 14, DANGER)
	_place_right(_overheat_label, 80.0, 240.0, 20.0)
	_overheat_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_RIGHT
	_overheat_label.visible = false

	_build_pips(106.0, _initial_ability_max())

	_phase_label = _make_label("", 13, Color(0.75, 0.82, 0.88))
	_place_right(_phase_label, 128.0, 240.0, 20.0)
	_phase_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_RIGHT

	# Weapon group readout (WR-style W1/W2), one label per fire group so a
	# stripped group can be greyed out on its own.
	_group_labels.clear()
	for group in 2:
		var group_label := _make_label("W%d 0/0" % (group + 1), 13,
				CYAN if group == 0 else UiTheme.AMBER)
		var group_width := 116.0
		_place_right(group_label, 150.0, group_width, 20.0)
		if group == 0:
			group_label.offset_left -= 124.0
			group_label.offset_right -= 124.0
		group_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_RIGHT
		_group_labels.append(group_label)

	# Magazine readout (VOID/CHASH titan guns only — hidden otherwise).
	_ammo_label = _make_label("", 13, Color(1.0, 0.74, 0.3))
	_place_right(_ammo_label, 174.0, 240.0, 20.0)
	_ammo_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_RIGHT
	_ammo_label.visible = false

func _build_player_vitals() -> void:
	_hp_panel = Panel.new()
	_hp_panel.name = "PlayerPanel"
	_hp_panel.add_theme_stylebox_override("panel", UiTheme.panel(0.72, UiTheme.HEALTH))
	_hp_panel.anchor_left = 0.0
	_hp_panel.anchor_right = 0.0
	_hp_panel.anchor_top = 0.0
	_hp_panel.anchor_bottom = 0.0
	_hp_panel.offset_left = MARGIN + _safe.x
	_hp_panel.offset_right = MARGIN + _safe.x + HP_PANEL_WIDTH
	_hp_panel.offset_top = MARGIN + _safe.y
	_hp_panel.offset_bottom = MARGIN + _safe.y + HP_PANEL_HEIGHT
	_hp_panel.mouse_filter = Control.MOUSE_FILTER_IGNORE
	add_child(_hp_panel)

	_health_label = Label.new()
	_health_label.name = "HealthReadout"
	_health_label.anchor_left = 0.0
	_health_label.anchor_right = 1.0
	_health_label.anchor_top = 0.0
	_health_label.anchor_bottom = 0.0
	_health_label.offset_left = 14.0
	_health_label.offset_right = -14.0
	_health_label.offset_top = 12.0
	_health_label.offset_bottom = 34.0
	UiTheme.style_label(_health_label, 17, HEALTH_COLOR, false)
	_health_label.mouse_filter = Control.MOUSE_FILTER_IGNORE
	_hp_panel.add_child(_health_label)

	var bar_back := Panel.new()
	bar_back.name = "HealthBar"
	bar_back.add_theme_stylebox_override("panel", UiTheme.bar_bg())
	bar_back.anchor_left = 0.0
	bar_back.anchor_right = 1.0
	bar_back.anchor_top = 0.0
	bar_back.anchor_bottom = 0.0
	bar_back.offset_left = 14.0
	bar_back.offset_right = -14.0
	bar_back.offset_top = 42.0
	bar_back.offset_bottom = 56.0
	bar_back.mouse_filter = Control.MOUSE_FILTER_IGNORE
	_hp_panel.add_child(bar_back)

	_health_fill = ColorRect.new()
	_health_fill.color = HEALTH_COLOR
	_health_fill.anchor_left = 0.0
	_health_fill.anchor_right = 1.0
	_health_fill.anchor_top = 0.0
	_health_fill.anchor_bottom = 1.0
	_health_fill.offset_left = 0.0
	_health_fill.offset_right = 0.0
	_health_fill.offset_top = 0.0
	_health_fill.offset_bottom = 0.0
	_health_fill.mouse_filter = Control.MOUSE_FILTER_IGNORE
	bar_back.add_child(_health_fill)

	# War Robots style durability bar: green = current, dark grey = repairable
	# damage, light grey = permanent hull damage that repairs cannot undo.
	_health_missing = ColorRect.new()
	_health_missing.name = "HealthRepairable"
	_health_missing.color = Color(0.26, 0.28, 0.3)
	_health_missing.anchor_left = 1.0
	_health_missing.anchor_right = 1.0
	_health_missing.anchor_top = 0.0
	_health_missing.anchor_bottom = 1.0
	_health_missing.mouse_filter = Control.MOUSE_FILTER_IGNORE
	bar_back.add_child(_health_missing)

	_health_hull = ColorRect.new()
	_health_hull.name = "HealthHull"
	_health_hull.color = Color(0.6, 0.62, 0.65)
	_health_hull.anchor_left = 1.0
	_health_hull.anchor_right = 1.0
	_health_hull.anchor_top = 0.0
	_health_hull.anchor_bottom = 1.0
	_health_hull.mouse_filter = Control.MOUSE_FILTER_IGNORE
	bar_back.add_child(_health_hull)

	var armor := float(GameState.robot_def().get("armor", 200.0))
	_health_label.text = "ARMOR %s / %s" % [
			GameState.fmt_amount(armor), GameState.fmt_amount(armor)]

func _build_menu_button() -> void:
	_menu_button = Button.new()
	_menu_button.name = "MenuButton"
	_menu_button.text = "MENU"
	_menu_button.focus_mode = Control.FOCUS_NONE
	_menu_button.anchor_left = 0.0
	_menu_button.anchor_right = 0.0
	_menu_button.anchor_top = 0.0
	_menu_button.anchor_bottom = 0.0
	_menu_button.offset_left = MARGIN + _safe.x + HP_PANEL_WIDTH + 10.0
	_menu_button.offset_top = MARGIN + _safe.y
	_menu_button.offset_right = _menu_button.offset_left + MENU_BUTTON_WIDTH
	_menu_button.offset_bottom = _menu_button.offset_top + MENU_BUTTON_HEIGHT
	UiTheme.apply_to_button(_menu_button, UiTheme.CYAN, 15)
	_menu_button.pressed.connect(_on_menu_pressed)
	add_child(_menu_button)

# Slim bottom-centre strip: what to press, in the language of whatever the
# player is actually holding. Touch mode hides it — the rig is self-labelled.
func _build_control_hints() -> void:
	_hint_strip = Panel.new()
	_hint_strip.name = "ControlHints"
	_hint_strip.anchor_left = 0.5
	_hint_strip.anchor_right = 0.5
	_hint_strip.anchor_top = 1.0
	_hint_strip.anchor_bottom = 1.0
	_hint_strip.offset_left = -520.0
	_hint_strip.offset_right = 520.0
	_hint_strip.offset_top = -50.0
	_hint_strip.offset_bottom = -6.0
	_hint_strip.mouse_filter = Control.MOUSE_FILTER_IGNORE
	_hint_strip.add_theme_stylebox_override("panel", UiTheme.panel(0.55))
	add_child(_hint_strip)

	_hint_label = Label.new()
	_hint_label.name = "HintText"
	_hint_label.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	_hint_label.offset_left = 12.0
	_hint_label.offset_right = -12.0
	_hint_label.offset_top = 5.0
	_hint_label.offset_bottom = -5.0
	_hint_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	_hint_label.vertical_alignment = VERTICAL_ALIGNMENT_TOP
	_hint_label.autowrap_mode = TextServer.AUTOWRAP_OFF
	_hint_label.mouse_filter = Control.MOUSE_FILTER_IGNORE
	UiTheme.style_label(_hint_label, 13, UiTheme.MUTED)
	_hint_strip.add_child(_hint_label)
	_sync_control_hints()

func _sync_control_hints() -> void:
	if _hint_strip == null or _hint_label == null:
		return
	var mode := PlatformUtil.effective_mode()
	_hint_strip.visible = mode != PlatformUtil.InputMode.TOUCH
	if _menu_button != null:
		var caption := _menu_caption(mode)
		_menu_button.text = caption
		# Widen when a key chip is appended so "MENU  START" never clips.
		var font := _menu_button.get_theme_font("font")
		if font != null:
			var font_size := _menu_button.get_theme_font_size("font_size")
			var needed := font.get_string_size(caption, HORIZONTAL_ALIGNMENT_LEFT,
					-1, font_size).x + 30.0
			_menu_button.offset_right = _menu_button.offset_left \
					+ maxf(MENU_BUTTON_WIDTH, needed)
	if not _hint_strip.visible:
		return
	_hint_label.text = "\n".join(PlatformUtil.input_hint_lines(
			String(GameState.robot_def().get("ability_short", "")),
			String(GameState.robot_def().get("secondary_short", ""))))

func _menu_caption(mode: int) -> String:
	if mode == PlatformUtil.InputMode.TOUCH:
		return "MENU"
	var key := PlatformUtil.badge_for(&"pause")
	if key.is_empty():
		return "MENU"
	return "MENU  %s" % key

func _on_menu_pressed() -> void:
	AudioEngine.play(&"ui")
	Events.menu_requested.emit()

func _build_timer() -> void:
	_timer_panel = Panel.new()
	_timer_panel.name = "TimerPanel"
	_timer_panel.add_theme_stylebox_override("panel", UiTheme.panel(0.66))
	_timer_panel.anchor_left = 0.5
	_timer_panel.anchor_right = 0.5
	_timer_panel.anchor_top = 0.0
	_timer_panel.anchor_bottom = 0.0
	_timer_panel.offset_left = -TIMER_PANEL_WIDTH * 0.5
	_timer_panel.offset_right = TIMER_PANEL_WIDTH * 0.5
	_timer_panel.offset_top = MARGIN + _safe.y
	_timer_panel.offset_bottom = MARGIN + _safe.y + TIMER_PANEL_HEIGHT
	_timer_panel.mouse_filter = Control.MOUSE_FILTER_IGNORE
	add_child(_timer_panel)

	_timer_label = Label.new()
	_timer_label.name = "TimerValue"
	_timer_label.anchor_left = 0.0
	_timer_label.anchor_right = 1.0
	_timer_label.anchor_top = 0.0
	_timer_label.anchor_bottom = 0.0
	_timer_label.offset_left = 0.0
	_timer_label.offset_right = 0.0
	_timer_label.offset_top = 4.0
	_timer_label.offset_bottom = 42.0
	_timer_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	_timer_label.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
	UiTheme.style_label(_timer_label, 30, TIMER_COLOR, true)
	_timer_label.mouse_filter = Control.MOUSE_FILTER_IGNORE
	_timer_panel.add_child(_timer_label)

	_kills_label = Label.new()
	_kills_label.name = "KillsRow"
	_kills_label.anchor_left = 0.0
	_kills_label.anchor_right = 1.0
	_kills_label.anchor_top = 0.0
	_kills_label.anchor_bottom = 0.0
	_kills_label.offset_left = 0.0
	_kills_label.offset_right = 0.0
	_kills_label.offset_top = 44.0
	_kills_label.offset_bottom = 68.0
	_kills_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	UiTheme.style_label(_kills_label, 13, UiTheme.MUTED)
	_kills_label.mouse_filter = Control.MOUSE_FILTER_IGNORE
	_timer_panel.add_child(_kills_label)
	_update_kills_label()
	_update_timer_label()

func _update_kills_label() -> void:
	if _kills_label == null:
		return
	var total := maxi(GameState.enemies_registered, GameState.enemies_killed)
	_kills_label.text = "NEUTRALISED  %d / %d" % [GameState.enemies_killed, total]

func _build_radar() -> void:
	var radar_panel := Panel.new()
	radar_panel.name = "Radar"
	radar_panel.add_theme_stylebox_override("panel", UiTheme.panel(0.7, UiTheme.CYAN))
	radar_panel.anchor_left = 0.0
	radar_panel.anchor_right = 0.0
	radar_panel.anchor_top = 0.0
	radar_panel.anchor_bottom = 0.0
	radar_panel.offset_left = MARGIN + _safe.x
	radar_panel.offset_right = MARGIN + _safe.x + RADAR_SIZE
	radar_panel.offset_top = MARGIN + _safe.y + HP_PANEL_HEIGHT + 12.0
	radar_panel.offset_bottom = radar_panel.offset_top + RADAR_SIZE
	radar_panel.mouse_filter = Control.MOUSE_FILTER_IGNORE
	add_child(radar_panel)

	_radar = RadarScope.new()
	_radar.name = "RadarScope"
	_radar.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	_radar.offset_left = 6.0
	_radar.offset_top = 6.0
	_radar.offset_right = -6.0
	_radar.offset_bottom = -6.0
	_radar.mouse_filter = Control.MOUSE_FILTER_IGNORE
	radar_panel.add_child(_radar)

func _build_fps_chip() -> void:
	_fps_label = _make_label("FPS 0", 13, UiTheme.MUTED)
	_fps_label.name = "FpsCounter"
	_fps_label.anchor_left = 0.5
	_fps_label.anchor_right = 0.5
	_fps_label.anchor_top = 0.0
	_fps_label.anchor_bottom = 0.0
	_fps_label.offset_left = -84.0
	_fps_label.offset_right = 84.0
	_fps_label.offset_top = MARGIN + _safe.y + TIMER_PANEL_HEIGHT + 4.0
	_fps_label.offset_bottom = _fps_label.offset_top + 18.0
	_fps_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	_fps_label.visible = GameState.fps_counter

func _initial_ability_max() -> int:
	if GameState.selected_robot == GameState.ROBOT_SCARAB:
		return 3
	return 1

func _build_pips(y: float, count: int = 3) -> void:
	if count < 1:
		count = 1
	var pip_width := 34.0
	var gap := 8.0
	var total := float(count) * pip_width + float(count - 1) * gap
	var start_x := -MARGIN - _safe.x - total
	for index in count:
		var box := ColorRect.new()
		box.color = PANEL_COLOR
		box.anchor_left = 1.0
		box.anchor_right = 1.0
		box.anchor_top = 0.0
		box.anchor_bottom = 0.0
		var x := start_x + float(index) * (pip_width + gap)
		box.offset_left = x
		box.offset_right = x + pip_width
		box.offset_top = MARGIN + _safe.y + y
		box.offset_bottom = box.offset_top + 16.0
		box.mouse_filter = Control.MOUSE_FILTER_IGNORE
		add_child(box)
		var fill := ColorRect.new()
		fill.color = CYAN
		fill.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
		fill.mouse_filter = Control.MOUSE_FILTER_IGNORE
		box.add_child(fill)
		_pip_fills.append(fill)
		_pip_ratio.append(0.0)
	_pip_count = count

func _rebuild_pips(count: int) -> void:
	for fill in _pip_fills:
		var box := fill.get_parent() as Node
		if box != null:
			box.queue_free()
	_pip_fills.clear()
	_pip_ratio.clear()
	_build_pips(106.0, count)

func _make_bar(size: Vector2, y: float, fill_color: Color) -> ColorRect:
	var bg := Panel.new()
	bg.add_theme_stylebox_override("panel", UiTheme.bar_bg())
	_place_right(bg, y, size.x, size.y)
	bg.mouse_filter = Control.MOUSE_FILTER_IGNORE
	add_child(bg)
	var fill := ColorRect.new()
	fill.color = fill_color
	fill.anchor_right = 1.0
	fill.anchor_bottom = 1.0
	fill.offset_right = 0.0
	fill.offset_bottom = 0.0
	fill.mouse_filter = Control.MOUSE_FILTER_IGNORE
	bg.add_child(fill)
	return fill

func _make_label(text: String, font_size: int, color: Color) -> Label:
	var label := Label.new()
	label.text = text
	UiTheme.style_label(label, font_size, color, false)
	label.mouse_filter = Control.MOUSE_FILTER_IGNORE
	add_child(label)
	return label

func _build_crosshair() -> void:
	var center := Control.new()
	center.name = "Crosshair"
	center.anchor_left = 0.5
	center.anchor_right = 0.5
	center.anchor_top = 0.5
	center.anchor_bottom = 0.5
	center.offset_left = -24.0
	center.offset_right = 24.0
	center.offset_top = -24.0
	center.offset_bottom = 24.0
	center.mouse_filter = Control.MOUSE_FILTER_IGNORE
	add_child(center)

	_crosshair_ring = ColorRect.new()
	_crosshair_ring.color = Color(1.0, 1.0, 1.0, 0.35)
	_crosshair_ring.anchor_left = 0.5
	_crosshair_ring.anchor_right = 0.5
	_crosshair_ring.anchor_top = 0.5
	_crosshair_ring.anchor_bottom = 0.5
	_crosshair_ring.offset_left = -3.0
	_crosshair_ring.offset_right = 3.0
	_crosshair_ring.offset_top = -18.0
	_crosshair_ring.offset_bottom = -14.0
	_crosshair_ring.mouse_filter = Control.MOUSE_FILTER_IGNORE
	center.add_child(_crosshair_ring)

	_crosshair_mod = ColorRect.new()
	_crosshair_mod.color = Color(1.0, 1.0, 1.0, 0.9)
	_crosshair_mod.anchor_left = 0.5
	_crosshair_mod.anchor_right = 0.5
	_crosshair_mod.anchor_top = 0.5
	_crosshair_mod.anchor_bottom = 0.5
	_crosshair_mod.offset_left = -2.0
	_crosshair_mod.offset_right = 2.0
	_crosshair_mod.offset_top = -2.0
	_crosshair_mod.offset_bottom = 2.0
	_crosshair_mod.mouse_filter = Control.MOUSE_FILTER_IGNORE
	center.add_child(_crosshair_mod)

	for side in [-1.0, 1.0]:
		var tick := ColorRect.new()
		tick.color = Color(1.0, 1.0, 1.0, 0.75)
		tick.anchor_left = 0.5
		tick.anchor_right = 0.5
		tick.anchor_top = 0.5
		tick.anchor_bottom = 0.5
		tick.offset_left = -1.0
		tick.offset_right = 1.0
		tick.offset_top = side * 8.0 - (1.0 if side < 0.0 else 14.0)
		tick.offset_bottom = side * 8.0 + (14.0 if side > 0.0 else 1.0) - 12.0
		if side < 0.0:
			tick.offset_top = -16.0
			tick.offset_bottom = -8.0
		else:
			tick.offset_top = 8.0
			tick.offset_bottom = 16.0
		tick.mouse_filter = Control.MOUSE_FILTER_IGNORE
		center.add_child(tick)
		var side_tick := ColorRect.new()
		side_tick.color = Color(1.0, 1.0, 1.0, 0.75)
		side_tick.anchor_left = 0.5
		side_tick.anchor_right = 0.5
		side_tick.anchor_top = 0.5
		side_tick.anchor_bottom = 0.5
		side_tick.offset_top = -1.0
		side_tick.offset_bottom = 1.0
		if side < 0.0:
			side_tick.offset_left = -16.0
			side_tick.offset_right = -8.0
		else:
			side_tick.offset_left = 8.0
			side_tick.offset_right = 16.0
		side_tick.mouse_filter = Control.MOUSE_FILTER_IGNORE
		center.add_child(side_tick)

	_hitmarker = Control.new()
	_hitmarker.anchor_left = 0.5
	_hitmarker.anchor_right = 0.5
	_hitmarker.anchor_top = 0.5
	_hitmarker.anchor_bottom = 0.5
	_hitmarker.offset_left = -14.0
	_hitmarker.offset_right = 14.0
	_hitmarker.offset_top = -14.0
	_hitmarker.offset_bottom = 14.0
	_hitmarker.modulate = Color(1.0, 1.0, 1.0, 0.0)
	_hitmarker.mouse_filter = Control.MOUSE_FILTER_IGNORE
	add_child(_hitmarker)
	for rotation_deg in [45.0, -45.0]:
		var slash := ColorRect.new()
		slash.color = Color(1.0, 0.95, 0.85)
		slash.anchor_left = 0.5
		slash.anchor_right = 0.5
		slash.anchor_top = 0.5
		slash.anchor_bottom = 0.5
		slash.offset_left = -10.0
		slash.offset_right = 10.0
		slash.offset_top = -1.5
		slash.offset_bottom = 1.5
		slash.rotation_degrees = rotation_deg
		slash.mouse_filter = Control.MOUSE_FILTER_IGNORE
		_hitmarker.add_child(slash)

	_stealth_chip = _make_label("STEALTH", 15, CYAN)
	_stealth_chip.anchor_left = 0.5
	_stealth_chip.anchor_right = 0.5
	_stealth_chip.anchor_top = 0.5
	_stealth_chip.anchor_bottom = 0.5
	_stealth_chip.offset_left = -60.0
	_stealth_chip.offset_right = 60.0
	_stealth_chip.offset_top = 46.0
	_stealth_chip.offset_bottom = 68.0
	_stealth_chip.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	_stealth_chip.visible = false

	# Critical-hull warning, mirrored above the crosshair (pulses in _process
	# while DamageReactionController reports a critical state).
	_critical_chip = _make_label("CRITICAL", 15, DANGER)
	_critical_chip.name = "CriticalChip"
	_critical_chip.anchor_left = 0.5
	_critical_chip.anchor_right = 0.5
	_critical_chip.anchor_top = 0.5
	_critical_chip.anchor_bottom = 0.5
	_critical_chip.offset_left = -80.0
	_critical_chip.offset_right = 80.0
	_critical_chip.offset_top = -76.0
	_critical_chip.offset_bottom = -54.0
	_critical_chip.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	_critical_chip.visible = false

	_hazard_chip = _make_label("", 15, HEAT_COLOR)
	_hazard_chip.anchor_left = 0.5
	_hazard_chip.anchor_right = 0.5
	_hazard_chip.anchor_top = 0.5
	_hazard_chip.anchor_bottom = 0.5
	_hazard_chip.offset_left = -70.0
	_hazard_chip.offset_right = 70.0
	_hazard_chip.offset_top = 74.0
	_hazard_chip.offset_bottom = 96.0
	_hazard_chip.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	_hazard_chip.visible = false
	_hazard_chip.name = "HazardChip"

	_lock_frame = Control.new()
	_lock_frame.name = "LockFrame"
	_lock_frame.anchor_left = 0.5
	_lock_frame.anchor_right = 0.5
	_lock_frame.anchor_top = 0.5
	_lock_frame.anchor_bottom = 0.5
	_lock_frame.offset_left = -30.0
	_lock_frame.offset_right = 30.0
	_lock_frame.offset_top = -30.0
	_lock_frame.offset_bottom = 30.0
	_lock_frame.visible = false
	_lock_frame.mouse_filter = Control.MOUSE_FILTER_IGNORE
	center.add_child(_lock_frame)
	var frame_specs := [
		Rect2(0.0, 0.0, 60.0, 2.0), Rect2(0.0, 58.0, 60.0, 2.0),
		Rect2(0.0, 0.0, 2.0, 60.0), Rect2(58.0, 0.0, 2.0, 60.0),
	]
	for spec in frame_specs:
		var edge := ColorRect.new()
		edge.color = DANGER
		edge.position = Vector2(spec.position)
		edge.size = Vector2(spec.size)
		edge.mouse_filter = Control.MOUSE_FILTER_IGNORE
		_lock_frame.add_child(edge)
	var lock_label := Label.new()
	lock_label.text = "TARGET"
	lock_label.add_theme_font_size_override("font_size", 12)
	lock_label.add_theme_color_override("font_color", DANGER)
	lock_label.add_theme_constant_override("outline_size", 3)
	lock_label.add_theme_color_override("font_outline_color", Color(0.01, 0.02, 0.03))
	lock_label.anchor_left = 0.5
	lock_label.anchor_right = 0.5
	lock_label.anchor_top = 0.5
	lock_label.anchor_bottom = 0.5
	lock_label.offset_left = -50.0
	lock_label.offset_right = 50.0
	lock_label.offset_top = 36.0
	lock_label.offset_bottom = 52.0
	lock_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	lock_label.mouse_filter = Control.MOUSE_FILTER_IGNORE
	_lock_frame.add_child(lock_label)

func _build_overlays() -> void:
	# Damage vignette: edge-only falloff. The old full-screen tint washed the
	# whole picture pink on device — the centre stays clear now, and the
	# flash tween keeps driving modulate:a exactly as before.
	_vignette = ColorRect.new()
	_vignette.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	_vignette.modulate = Color(1.0, 1.0, 1.0, 0.0)
	_vignette.mouse_filter = Control.MOUSE_FILTER_IGNORE
	var vignette_shader := Shader.new()
	vignette_shader.code = """
shader_type canvas_item;

uniform vec4 tint: source_color = vec4(0.85, 0.16, 0.12, 1.0);
uniform float inner: hint_range(0.0, 1.0) = 0.44;
uniform float outer: hint_range(0.0, 1.0) = 0.98;

void fragment() {
	vec2 p = UV - vec2(0.5);
	// normalized so the corners land near 1.0 at any aspect ratio
	float d = length(p * vec2(1.30, 1.0)) / 0.820;
	float edge = smoothstep(inner, outer, d);
	COLOR = vec4(tint.rgb, tint.a * edge * COLOR.a);
}
"""
	var vignette_material := ShaderMaterial.new()
	vignette_material.shader = vignette_shader
	_vignette.material = vignette_material
	add_child(_vignette)

	_prompt = _make_label("", 20, Color(0.85, 0.95, 1.0))
	_prompt.anchor_left = 0.5
	_prompt.anchor_right = 0.5
	_prompt.anchor_top = 0.0
	_prompt.anchor_bottom = 0.0
	_prompt.offset_left = -320.0
	_prompt.offset_right = 320.0
	_prompt.offset_top = MARGIN + _safe.y + TIMER_PANEL_HEIGHT + 26.0
	_prompt.offset_bottom = _prompt.offset_top + 30.0
	_prompt.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	_prompt.modulate = Color(1.0, 1.0, 1.0, 0.0)

	_build_end_panel()

func _build_end_panel() -> void:
	_end_panel = Control.new()
	_end_panel.name = "EndPanel"
	_end_panel.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	_end_panel.visible = false
	_end_panel.mouse_filter = Control.MOUSE_FILTER_STOP
	add_child(_end_panel)

	var backdrop := ColorRect.new()
	backdrop.color = Color(0.01, 0.015, 0.02, 0.86)
	backdrop.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	backdrop.mouse_filter = Control.MOUSE_FILTER_STOP
	_end_panel.add_child(backdrop)

	# Results card: title + subtitle, a BATTLE REPORT column on the left
	# and a REWARDS column on the right, then the two actions. Everything
	# sits directly on the panel (center-anchored) so node paths stay one
	# level deep for tooling.
	var end_box := Panel.new()
	end_box.name = "EndBox"
	end_box.add_theme_stylebox_override("panel", UiTheme.panel(0.94))
	end_box.anchor_left = 0.5
	end_box.anchor_right = 0.5
	end_box.anchor_top = 0.5
	end_box.anchor_bottom = 0.5
	end_box.offset_left = -470.0
	end_box.offset_right = 470.0
	end_box.offset_top = -215.0
	end_box.offset_bottom = 245.0
	end_box.mouse_filter = Control.MOUSE_FILTER_STOP
	_end_panel.add_child(end_box)

	_end_title = Label.new()
	_end_title.name = "EndTitle"
	_end_title.anchor_left = 0.5
	_end_title.anchor_right = 0.5
	_end_title.anchor_top = 0.5
	_end_title.anchor_bottom = 0.5
	_end_title.offset_left = -440.0
	_end_title.offset_right = 440.0
	_end_title.offset_top = -196.0
	_end_title.offset_bottom = -118.0
	_end_title.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	UiTheme.style_label(_end_title, 56, Color(0.93, 0.75, 0.32), true)
	_end_panel.add_child(_end_title)

	_end_subtitle = Label.new()
	_end_subtitle.name = "EndSubtitle"
	_end_subtitle.anchor_left = 0.5
	_end_subtitle.anchor_right = 0.5
	_end_subtitle.anchor_top = 0.5
	_end_subtitle.anchor_bottom = 0.5
	_end_subtitle.offset_left = -440.0
	_end_subtitle.offset_right = 440.0
	_end_subtitle.offset_top = -112.0
	_end_subtitle.offset_bottom = -88.0
	_end_subtitle.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	UiTheme.style_label(_end_subtitle, 15, UiTheme.MUTED)
	_end_panel.add_child(_end_subtitle)

	var report_header := _make_result_label(
			"ReportHeader", "BATTLE REPORT", 13, UiTheme.AMBER,
			Vector2(-440.0, -76.0), Vector2(-20.0, -54.0), true)
	report_header.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
	var rewards_header := _make_result_label(
			"RewardsHeader", "REWARDS", 13, UiTheme.AMBER,
			Vector2(20.0, -76.0), Vector2(440.0, -54.0), true)
	rewards_header.vertical_alignment = VERTICAL_ALIGNMENT_CENTER

	var report_rows := [
		["Report_Kills", "ReportValue_Kills", "HOSTILES DESTROYED"],
		["Report_Dealt", "ReportValue_Dealt", "DAMAGE DEALT"],
		["Report_Taken", "ReportValue_Taken", "DAMAGE TAKEN"],
		["Report_Time", "ReportValue_Time", "MISSION TIME"],
	]
	_report_values.clear()
	for row_index in report_rows.size():
		var row_y := -46.0 + 30.0 * float(row_index)
		var caption_row: Array = report_rows[row_index]
		var caption := _make_result_label(
				String(caption_row[0]), String(caption_row[2]), 14, UiTheme.MUTED,
				Vector2(-440.0, row_y), Vector2(-170.0, row_y + 26.0))
		caption.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
		var value := _make_result_label(
				String(caption_row[1]), "", 17, UiTheme.TEXT,
				Vector2(-160.0, row_y), Vector2(-20.0, row_y + 26.0))
		value.horizontal_alignment = HORIZONTAL_ALIGNMENT_RIGHT
		value.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
		_report_values.append(value)

	_end_stats = Label.new()
	_end_stats.name = "EndStats"
	_end_stats.anchor_left = 0.5
	_end_stats.anchor_right = 0.5
	_end_stats.anchor_top = 0.5
	_end_stats.anchor_bottom = 0.5
	_end_stats.offset_left = 20.0
	_end_stats.offset_right = 440.0
	_end_stats.offset_top = -46.0
	_end_stats.offset_bottom = 90.0
	_end_stats.horizontal_alignment = HORIZONTAL_ALIGNMENT_LEFT
	_end_stats.add_theme_font_size_override("font_size", 18)
	_end_stats.add_theme_color_override("font_color", Color(0.86, 0.9, 0.94))
	_end_panel.add_child(_end_stats)

	var retry := Button.new()
	retry.name = "RedeployButton"
	retry.text = "REDEPLOY"
	retry.anchor_left = 0.5
	retry.anchor_right = 0.5
	retry.anchor_top = 0.5
	retry.anchor_bottom = 0.5
	retry.offset_left = -220.0
	retry.offset_right = -20.0
	retry.offset_top = 150.0
	retry.offset_bottom = 206.0
	UiTheme.apply_to_button(retry, UiTheme.AMBER, 22)
	retry.pressed.connect(SceneRouter.restart_match)
	_end_panel.add_child(retry)

	var menu := Button.new()
	menu.name = "MainMenuButton"
	menu.text = "MAIN MENU"
	menu.anchor_left = 0.5
	menu.anchor_right = 0.5
	menu.anchor_top = 0.5
	menu.anchor_bottom = 0.5
	menu.offset_left = 20.0
	menu.offset_right = 220.0
	menu.offset_top = 150.0
	menu.offset_bottom = 206.0
	UiTheme.apply_to_button(menu, Color(0.5, 0.55, 0.6), 22)
	menu.pressed.connect(SceneRouter.goto_menu)
	_end_panel.add_child(menu)
	GamepadNav.enable(_end_panel)

# One label of the results card, positioned in center-relative space.
func _make_result_label(label_name: String, text: String, font_size: int,
		color: Color, top_left: Vector2, bottom_right: Vector2,
		bold: bool = false) -> Label:
	var label := Label.new()
	label.name = label_name
	label.text = text
	label.anchor_left = 0.5
	label.anchor_right = 0.5
	label.anchor_top = 0.5
	label.anchor_bottom = 0.5
	label.offset_left = top_left.x
	label.offset_top = top_left.y
	label.offset_right = bottom_right.x
	label.offset_bottom = bottom_right.y
	UiTheme.style_label(label, font_size, color, bold)
	_end_panel.add_child(label)
	return label

# ---------------------------------------------------------------- events

func _connect_events() -> void:
	Events.player_health_changed.connect(_set_health)
	Events.weapon_heat_changed.connect(_set_heat)
	Events.ability_charges_changed.connect(_set_charges)
	Events.ability_phase_changed.connect(_set_phase)
	Events.hazard_changed.connect(_on_hazard_changed)
	Events.secondary_ability_phase_changed.connect(_set_secondary_phase)
	Events.damage_applied.connect(_on_damage_applied)
	Events.enemy_killed.connect(_on_enemy_killed)
	Events.match_started.connect(_on_match_started)
	Events.all_enemies_defeated.connect(_on_all_defeated)
	Events.match_ended.connect(_on_match_ended)
	Events.prompt_message.connect(_show_prompt)
	Events.enemy_targeted.connect(_on_enemy_locked)
	Events.enemy_target_cleared.connect(_on_enemy_unlocked)
	Events.mode_changed.connect(_on_mode_changed)

func _on_mode_changed(_mode: int) -> void:
	_sync_control_hints()

func _on_enemy_locked(enemy: Node, _ratio: float) -> void:
	_locked_enemy = enemy as Node3D
	_update_lock_frame()

func _on_enemy_unlocked() -> void:
	_locked_enemy = null
	if _lock_frame != null:
		_lock_frame.visible = false

# The targeting bracket is drawn on the locked enemy itself (re-projected every
# frame).  It used to sit at screen centre, where in third person it rode the
# player's own robot instead of the hostile it was locked onto.
func _update_lock_frame() -> void:
	if _lock_frame == null:
		return
	if not is_instance_valid(_locked_enemy):
		_lock_frame.visible = false
		return
	var camera := get_viewport().get_camera_3d()
	if camera == null:
		_lock_frame.visible = false
		return
	var anchor: Vector3 = _locked_enemy.global_position + Vector3.UP * 1.5
	if camera.is_position_behind(anchor):
		_lock_frame.visible = false
		return
	var screen := camera.unproject_position(anchor)
	var viewport_size := get_viewport().get_visible_rect().size
	var margin := 90.0
	var on_screen := screen.x > -margin and screen.x < viewport_size.x + margin \
			and screen.y > -margin and screen.y < viewport_size.y + margin
	_lock_frame.visible = on_screen
	if on_screen:
		var half := _lock_frame.size * 0.5
		if half == Vector2.ZERO:
			half = Vector2(30.0, 30.0)
		_lock_frame.global_position = screen - half

func _scan_radar() -> void:
	if _radar == null:
		return
	_radar.player = _player
	_radar.locked = _locked_enemy
	var blips: Array[Node3D] = []
	for node in get_tree().get_nodes_in_group("enemy"):
		if not is_instance_valid(node):
			continue
		var enemy := node as EnemyRobot
		if enemy == null:
			continue
		if enemy.health != null and enemy.health.dead:
			continue
		blips.append(enemy)
	_radar.enemies = blips
	_radar.queue_redraw()

func _tick_fps(delta: float) -> void:
	if _fps_label == null or not _fps_label.visible:
		return
	_fps_clock -= delta
	if _fps_clock > 0.0:
		return
	_fps_clock = FPS_INTERVAL
	_fps_label.text = "FPS %d" % Engine.get_frames_per_second()

func _set_health(current: float, maximum: float) -> void:
	var ratio := clampf(current / maxf(maximum, 0.01), 0.0, 1.0)
	_health_fill.anchor_right = ratio
	var hull_ratio := 0.0
	if is_instance_valid(_player_health):
		hull_ratio = _player_health.hull_ratio()
	var repairable := clampf(1.0 - hull_ratio, ratio, 1.0)
	if _health_missing != null:
		_health_missing.anchor_left = ratio
		_health_missing.anchor_right = repairable
		_health_missing.visible = repairable - ratio > 0.004
	if _health_hull != null:
		_health_hull.anchor_left = repairable
		_health_hull.anchor_right = 1.0
		_health_hull.visible = hull_ratio > 0.004
	_health_label.text = "ARMOR %s / %s" % [
			GameState.fmt_amount(current), GameState.fmt_amount(maximum)]
	_health_fill.color = HEALTH_COLOR if ratio > 0.35 else DANGER
	_health_label.add_theme_color_override("font_color",
			HEALTH_COLOR if ratio > 0.35 else DANGER)

func _set_heat(heat_ratio: float, overheated: bool) -> void:
	_heat_fill.anchor_right = clampf(heat_ratio, 0.0, 1.0)
	_heat_fill.color = DANGER if overheated else HEAT_COLOR
	_heat_label.add_theme_color_override("font_color", DANGER if overheated else HEAT_COLOR)
	_overheated = overheated
	_overheat_label.visible = overheated

func _sync_ammo() -> void:
	if _ammo_label == null:
		return
	var system: WeaponSystem = null
	if _player != null and is_instance_valid(_player):
		system = _player.weapons
	if system == null or system.mounts.is_empty():
		_ammo_label.visible = false
		return
	var reloading := false
	var min_ammo := 999
	var has_magazine := false
	for mount in system.mounts:
		if mount == null or mount.data == null or mount.data.magazine <= 0:
			continue
		has_magazine = true
		if mount.is_reloading():
			reloading = true
		min_ammo = mini(min_ammo, mount.ammo_left())
	if not has_magazine:
		_ammo_label.visible = false
		return
	_ammo_label.visible = true
	if reloading:
		_ammo_label.text = "RELOADING"
		_ammo_label.add_theme_color_override("font_color", DANGER)
	else:
		_ammo_label.text = "AMMO %d" % min_ammo
		_ammo_label.add_theme_color_override("font_color", Color(1.0, 0.74, 0.3))

# Weapon group row: "W1 2/2" per fire group, greyed when that group's guns
# have all been blown off the hull.
func _sync_weapon_groups() -> void:
	var system: WeaponSystem = null
	if _player != null and is_instance_valid(_player):
		system = _player.weapons
	for group in _group_labels.size():
		var label := _group_labels[group]
		if label == null:
			continue
		if system == null or system.mounts.is_empty():
			label.visible = false
			continue
		var total := system.group_size(group)
		var alive := system.group_alive_count(group)
		label.visible = total > 0
		if total <= 0:
			continue
		label.text = "W%d %d/%d" % [group + 1, alive, total]
		if system.group_destroyed(group):
			label.add_theme_color_override("font_color", Color(1.0, 1.0, 1.0, 0.26))
		elif alive < total:
			label.add_theme_color_override("font_color", Color(1.0, 0.42, 0.3))
		else:
			label.add_theme_color_override("font_color",
					CYAN if group == 0 else UiTheme.AMBER)

func _sync_critical(delta: float) -> void:
	if _critical_chip == null:
		return
	var critical := _player != null and is_instance_valid(_player) \
			and _player.is_critical()
	_critical_chip.visible = critical
	if not critical:
		_crit_pulse = 0.0
		_critical_chip.modulate = Color.WHITE
		return
	_crit_pulse += delta
	_critical_chip.modulate = Color(1.0, 1.0, 1.0,
			0.55 + 0.45 * sin(_crit_pulse * 6.0))

func _set_charges(available: int, maximum: int, recharge_ratio: float) -> void:
	if maximum > 0 and maximum != _pip_count:
		_rebuild_pips(maximum)
	for index in _pip_fills.size():
		var fill := _pip_fills[index]
		if index < available:
			fill.anchor_right = 1.0
			fill.color = CYAN
		elif index == available:
			fill.anchor_right = clampf(recharge_ratio, 0.0, 1.0)
			fill.color = Color(CYAN.r, CYAN.g, CYAN.b, 0.5)
		else:
			fill.anchor_right = 0.0

func _set_phase(phase_name: String) -> void:
	_primary_phase = phase_name
	_update_phase_label()
	var stealth := phase_name == "STEALTH" or phase_name == "DASHING"
	var guarded := phase_name == "SHIELD" or phase_name == "JETPACK"
	_stealth_chip.text = phase_name
	_stealth_chip.visible = phase_name == "STEALTH" or guarded
	_crosshair_mod.color = CYAN if stealth or guarded else Color(1.0, 1.0, 1.0, 0.9)
	_crosshair_ring.color = Color(CYAN.r, CYAN.g, CYAN.b, 0.55) if stealth or guarded \
			else Color(1.0, 1.0, 1.0, 0.35)

func _set_secondary_phase(phase_name: String) -> void:
	_secondary_phase = phase_name
	_update_phase_label()

func _on_hazard_changed(kind: String) -> void:
	_hazard_chip.text = "! " + kind if not kind.is_empty() else ""
	_hazard_chip.visible = not kind.is_empty()

func _update_phase_label() -> void:
	if _phase_label == null:
		return
	if _secondary_phase.is_empty():
		_phase_label.text = _primary_phase
	else:
		_phase_label.text = "%s · %s" % [_primary_phase, _secondary_phase]

func _on_damage_applied(target: Node, amount: float, _point: Vector3, _normal: Vector3) -> void:
	if amount <= 0.0:
		return
	if target is PlayerRobot:
		_flash_vignette()
	else:
		_flash_hitmarker()

func _flash_hitmarker() -> void:
	_hitmarker.modulate = Color(1.0, 1.0, 1.0, 1.0)
	if _hit_tween != null and _hit_tween.is_valid():
		_hit_tween.kill()
	_hit_tween = create_tween()
	_hit_tween.tween_property(_hitmarker, "modulate:a", 0.0, 0.28)

func _flash_vignette() -> void:
	_vignette.modulate = Color(1.0, 1.0, 1.0, 0.4)
	if _vignette_tween != null and _vignette_tween.is_valid():
		_vignette_tween.kill()
	_vignette_tween = create_tween()
	_vignette_tween.tween_property(_vignette, "modulate:a", 0.0, 0.5)

func _on_enemy_killed(_enemy_id: int) -> void:
	_counter_label.text = "HOSTILES %d" % GameState.remaining_enemies()
	_update_kills_label()

func _on_match_started() -> void:
	_counter_label.text = "HOSTILES %d" % GameState.remaining_enemies()
	_update_kills_label()
	_end_panel.visible = false
	_time_left = MATCH_LENGTH
	_timed_out = false
	_update_timer_label()

func _on_all_defeated() -> void:
	_counter_label.text = "HOSTILES 0"
	_update_kills_label()

func _on_match_ended(victory: bool) -> void:
	if victory:
		_end_title.text = "VICTORY"
		_end_title.add_theme_color_override("font_color", CYAN)
	elif _timed_out:
		_end_title.text = "TIME EXPIRED"
		_end_title.add_theme_color_override("font_color", UiTheme.AMBER)
	else:
		_end_title.text = "DESTROYED"
		_end_title.add_theme_color_override("font_color", DANGER)
	if _end_subtitle != null:
		_end_subtitle.text = "%s  ·  OPEN REALM SURVIVAL" % String(
				GameState.robot_def().get("name", "SCARAB"))
	if _report_values.size() == 4:
		_report_values[0].text = "%d" % GameState.enemies_killed
		_report_values[1].text = GameState.fmt_amount(GameState.player_damage_dealt)
		_report_values[2].text = GameState.fmt_amount(GameState.player_damage_taken)
		_report_values[3].text = _format_time(GameState.match_time)
	_end_stats.text = "REWARDS  +%d SILVER   +%d GOLD   +%d PLAT\nPARTS  +%d   ·   CHIPS  +%d   ·   MODULES  +%d\nPILOT XP  +%d" % [
		GameState.match_reward_silver,
		GameState.match_reward_gold,
		GameState.match_reward_platinum,
		GameState.match_reward_parts,
		GameState.match_reward_chips,
		GameState.match_reward_modules,
		GameState.pilot_xp_gained,
	]
	_end_panel.visible = true
	if PlatformUtil.effective_mode() == PlatformUtil.InputMode.GAMEPAD:
		GamepadNav.focus_default(_end_panel)

func _format_time(seconds: float) -> String:
	var total := int(seconds)
	return "%02d:%02d" % [total / 60, total % 60]

func _show_prompt(text: String) -> void:
	_prompt.text = text
	_prompt.modulate = Color(1.0, 1.0, 1.0, 1.0)
	if _prompt_tween != null and _prompt_tween.is_valid():
		_prompt_tween.kill()
	_prompt_tween = create_tween()
	_prompt_tween.tween_interval(2.4)
	_prompt_tween.tween_property(_prompt, "modulate:a", 0.0, 0.7)

func _process(delta: float) -> void:
	_tick_timer(delta)
	_sync_health(delta)
	_update_lock_frame()
	_sync_ammo()
	_sync_weapon_groups()
	_sync_critical(delta)
	_radar_clock -= delta
	if _radar_clock <= 0.0:
		_radar_clock = RADAR_SCAN_INTERVAL
		_scan_radar()
	_tick_fps(delta)
	if _overheated:
		_blink_clock += delta
		_overheat_label.modulate = Color(1.0, 1.0, 1.0,
				0.55 + 0.45 * sin(_blink_clock * 12.0))
	else:
		_overheat_label.modulate = Color(1.0, 1.0, 1.0, 1.0)

func _tick_timer(delta: float) -> void:
	if GameState.phase != GameState.Phase.COMBAT:
		return
	if is_instance_valid(_player_health) and _player_health.dead:
		return
	_time_left = maxf(_time_left - delta, 0.0)
	_update_timer_label()
	if _time_left <= 0.0:
		_expire_match()

func _expire_match() -> void:
	if _timed_out:
		return
	_timed_out = true
	if is_instance_valid(_player_health) and not _player_health.dead:
		_player_health.apply_damage(1.0e9, Vector3.ZERO)
	else:
		GameState.notify_player_died()

func _update_timer_label() -> void:
	if _timer_label == null:
		return
	var text := _format_time(_time_left)
	var tint := TIMER_COLOR
	if _time_left <= TIMER_URGENT:
		tint = DANGER
	elif _time_left <= TIMER_WARN:
		tint = UiTheme.AMBER
	if text == _timer_shown and tint == _timer_tint:
		return
	_timer_shown = text
	_timer_tint = tint
	_timer_label.text = text
	_timer_label.add_theme_color_override("font_color", tint)

func _sync_health(delta: float) -> void:
	_health_sync_clock -= delta
	if _health_sync_clock > 0.0:
		return
	_health_sync_clock = HEALTH_SYNC_INTERVAL
	if not is_instance_valid(_player_health):
		return
	_set_health(_player_health.current, _player_health.max_health)

class RadarScope extends Control:
	const SCOPE_RANGE := 55.0
	var player: PlayerRobot
	var enemies: Array[Node3D] = []
	var locked: Node3D

	func _draw() -> void:
		var center := size * 0.5
		var radius := minf(size.x, size.y) * 0.5 - 2.0
		if radius <= 4.0:
			return
		draw_circle(center, radius, Color(0.02, 0.05, 0.07, 0.88))
		draw_arc(center, radius, 0.0, TAU, 56, Color(0.25, 0.9, 1.0, 0.5), 2.0)
		draw_arc(center, radius * 0.5, 0.0, TAU, 40, Color(0.25, 0.9, 1.0, 0.16), 1.0)
		if player == null:
			return
		var basis := Basis(Vector3.UP, player.aim_yaw)
		var forward := basis * Vector3.FORWARD
		var right := basis * Vector3.RIGHT
		draw_line(center, center + Vector2(0.0, -radius),
				Color(0.25, 0.9, 1.0, 0.28), 1.5)
		for enemy in enemies:
			if not is_instance_valid(enemy):
				continue
			var rel: Vector3 = enemy.global_position - player.global_position
			rel.y = 0.0
			var px := rel.dot(right) / SCOPE_RANGE * radius
			var py := -rel.dot(forward) / RADAR_RANGE * radius
			var offset := Vector2(px, py)
			var clamped := offset.length() > radius - 6.0
			var dot_pos := center + offset.limit_length(radius - 6.0)
			var is_locked := locked != null and enemy == locked
			var color := Color(1.0, 0.75, 0.25)
			if not is_locked:
				color = Color(1.0, 0.3, 0.24, 0.5 if clamped else 0.95)
			draw_circle(dot_pos, 5.0 if is_locked else 3.5, color)
		var arrow := PackedVector2Array([
			center + Vector2(0.0, -7.0),
			center + Vector2(5.0, 6.0),
			center + Vector2(0.0, 3.0),
			center + Vector2(-5.0, 6.0),
		])
		draw_colored_polygon(arrow, Color(0.5, 0.95, 1.0))
