class_name StatsScreen
extends UiScreen

# Combat stat report for the selected robot: every multiplier's base →
# final value with its sources (pilot / drone / spec / reactor). Ported
# from the old StatsPopup; reached from the equipment screen's STATS
# action.

var _robot: Label
var _rows: VBoxContainer

func _build() -> void:
	add_child(UiParts.backdrop(0.97))
	_build_header()
	_build_body()

func _build_header() -> void:
	var header := Control.new()
	header.name = "Header"
	header.anchor_left = 0.0
	header.anchor_top = 0.0
	header.anchor_right = 1.0
	header.anchor_bottom = 0.0
	header.offset_left = 18.0
	header.offset_top = 64.0
	header.offset_right = -18.0
	header.offset_bottom = 112.0
	header.mouse_filter = Control.MOUSE_FILTER_PASS
	add_child(header)

	var row := UiParts.header_row("COMBAT STATS", back)
	row.anchor_left = 0.0
	row.anchor_top = 0.0
	row.anchor_right = 1.0
	row.anchor_bottom = 1.0
	header.add_child(row)
	var title := row.get_node_or_null("ScreenTitle") as Label
	if title != null:
		title.size_flags_horizontal = Control.SIZE_EXPAND_FILL
		title.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER

func _build_body() -> void:
	var margin := MarginContainer.new()
	margin.name = "StatsMargin"
	margin.anchor_left = 0.0
	margin.anchor_top = 0.0
	margin.anchor_right = 1.0
	margin.anchor_bottom = 1.0
	margin.offset_left = 200.0
	margin.offset_top = 124.0
	margin.offset_right = -200.0
	margin.offset_bottom = -20.0
	margin.mouse_filter = Control.MOUSE_FILTER_PASS
	add_child(margin)

	var scroll := UiParts.scroll()
	scroll.name = "StatsScroll"
	margin.add_child(scroll)
	var column := UiParts.vbox(8.0)
	column.name = "StatsBody"
	column.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	scroll.add_child(column)

	_robot = UiParts.label("", 15, UiTheme.MUTED)
	_robot.name = "StatsRobot"
	_robot.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	column.add_child(_robot)
	var hint := UiParts.label(
			"BASE  →  WITH PILOT · DRONE · SPECIALIZATION", 11, UiTheme.MUTED)
	hint.name = "StatsHint"
	column.add_child(hint)
	_rows = UiParts.vbox(9.0)
	_rows.name = "StatsRows"
	_rows.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	column.add_child(_rows)

# ----------------------------------------------------------------- refresh

func refresh() -> void:
	if _rows == null:
		return
	for child in _rows.get_children():
		_rows.remove_child(child)
		child.queue_free()
	var definition := GameState.robot_def()
	_robot.text = "%s · %s   ·   POWER %s   ·   ARMOR %s" % [
			String(definition.get("name", "")),
			String(definition.get("klass", "")).to_upper(),
			GameState.fmt_amount(GameState.robot_power()),
			GameState.fmt_amount(int(round(float(definition.get("armor", 0.0)))))]
	for report_row in GameState.combat_stat_report():
		_rows.add_child(_report_row(report_row))

func _report_row(report_row: Dictionary) -> HBoxContainer:
	var stat_key := String(report_row.get("key", ""))
	var line := UiParts.hbox(8.0)
	line.name = "StatRow_" + stat_key
	var name_label := UiParts.label(String(report_row.get("label", "")),
			14, UiTheme.TEXT, true)
	name_label.name = "StatName"
	name_label.custom_minimum_size = Vector2(116.0, 0.0)
	line.add_child(name_label)
	var base := float(report_row.get("base", 1.0))
	var final := float(report_row.get("final", 1.0))
	var value_text := ""
	if stat_key == "regen":
		value_text = "%.2f%%/s  →  %.2f%%/s" % [base * 100.0, final * 100.0]
	else:
		value_text = "%.0f%%  →  %.0f%%" % [base * 100.0, final * 100.0]
	var value_label := UiParts.label(value_text, 14, UiTheme.AMBER, true)
	value_label.name = "StatValue"
	value_label.custom_minimum_size = Vector2(172.0, 0.0)
	line.add_child(value_label)
	var sources := report_row.get("sources", []) as Array
	var source_text := "—"
	if not sources.is_empty():
		source_text = " · ".join(sources)
	var source_label := UiParts.label(source_text, 11, UiTheme.MUTED)
	source_label.name = "StatSources"
	source_label.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	source_label.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	line.add_child(source_label)
	return line
