class_name SpecScreen
extends UiScreen

# Specialization workspace: hex-cell skill tree for the selected robot,
# ranked with module points. Wallet + hint line, tap a cell to rank up.
# Ported from the old SpecPopup panel.

const UPGRADE_ACCENT := Color(0.36, 0.86, 0.55)

var _wallet: Label
var _robot_line: Label
var _grid: SpecHexGrid
var _hint: Label

func _build() -> void:
	add_child(UiParts.backdrop(0.97))
	_build_header()
	_build_body()

func _build_header() -> void:
	var header := Control.new()
	header.name = "Header"
	header.anchor_left = 0.0
	header.anchor_top = 0.0
	header.anchor_right = 1.0
	header.anchor_bottom = 0.0
	header.offset_left = 18.0
	header.offset_top = 64.0
	header.offset_right = -18.0
	header.offset_bottom = 112.0
	header.mouse_filter = Control.MOUSE_FILTER_PASS
	add_child(header)

	var row := UiParts.header_row("SPECIALIZATION", back)
	row.anchor_left = 0.0
	row.anchor_top = 0.0
	row.anchor_right = 1.0
	row.anchor_bottom = 1.0
	header.add_child(row)
	var title := row.get_node_or_null("ScreenTitle") as Label
	if title != null:
		title.size_flags_horizontal = Control.SIZE_EXPAND_FILL
		title.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER

func _build_body() -> void:
	var body := UiParts.vbox(7.0)
	body.name = "SpecBody"
	body.anchor_left = 0.0
	body.anchor_top = 0.0
	body.anchor_right = 1.0
	body.anchor_bottom = 1.0
	body.offset_left = 18.0
	body.offset_top = 124.0
	body.offset_right = -18.0
	body.offset_bottom = -20.0
	body.mouse_filter = Control.MOUSE_FILTER_PASS
	add_child(body)

	_wallet = UiParts.label("", 13, UiTheme.AMBER, true)
	_wallet.name = "SpecWallet"
	body.add_child(_wallet)
	_robot_line = UiParts.label("", 12, UiTheme.MUTED)
	_robot_line.name = "SpecRobot"
	body.add_child(_robot_line)

	_grid = SpecHexGrid.new()
	_grid.name = "SpecGrid"
	_grid.size_flags_horizontal = Control.SIZE_SHRINK_CENTER
	_grid.size_flags_vertical = Control.SIZE_SHRINK_BEGIN
	_grid.node_pressed.connect(_on_node_pressed)
	_grid.node_hovered.connect(_on_node_hovered)
	body.add_child(_grid)

	_hint = UiParts.label("TAP A CELL TO RANK IT UP", 12, UiTheme.MUTED)
	_hint.name = "SpecHint"
	_hint.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	_hint.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	_hint.custom_minimum_size = Vector2(0.0, 32.0)
	body.add_child(_hint)

func refresh() -> void:
	if _wallet == null:
		return
	_wallet.text = "MODULE POINTS  %d" % GameState.module_points
	_robot_line.text = "TRACK FOR %s  ·  RANKS 0 / %d PER NODE" % [
			GameState.robot_def().get("name", "?"), GameState.SPEC_MAX_RANK]
	_grid.refresh(GameState.selected_robot, GameState.module_points)
	_set_hint("TAP A CELL TO RANK IT UP")

func _on_node_hovered(node_id: String) -> void:
	if node_id.is_empty():
		_set_hint("TAP A CELL TO RANK IT UP")
		return
	for node in GameState.spec_nodes(GameState.selected_robot):
		if String(node.get("id", "")) != node_id:
			continue
		var rank := GameState.spec_rank(GameState.selected_robot, node_id)
		var cost := GameState.spec_upgrade_cost(GameState.selected_robot, node_id)
		var next_line: String
		if cost <= 0:
			next_line = "MAX RANK"
		else:
			next_line = "NEXT  +%d PTS  ·  %d LEFT" % [cost, GameState.module_points]
		_set_hint("%s  ·  %s  ·  RANK %d/%d  ·  %s" % [
				String(node.get("name", node_id.to_upper())),
				String(node.get("desc", "")), rank, GameState.SPEC_MAX_RANK,
				next_line])
		return

func _set_hint(text: String) -> void:
	if _hint != null:
		_hint.text = text

func _on_node_pressed(node_id: String) -> void:
	if GameState.upgrade_spec(GameState.selected_robot, node_id):
		var node_name := node_id.to_upper()
		for node in GameState.spec_nodes(GameState.selected_robot):
			if String(node.get("id", "")) == node_id:
				node_name = String(node.get("name", node_name))
				break
		manager.toast("%s RANKED UP" % node_name)
	else:
		var cost := GameState.spec_upgrade_cost(GameState.selected_robot, node_id)
		if cost <= 0:
			manager.toast("ALREADY MAX RANK", true)
		else:
			manager.toast("NEED %d MODULE POINTS" % cost, true)
	manager.refresh()
