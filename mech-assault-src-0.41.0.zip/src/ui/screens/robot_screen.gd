class_name RobotScreen
extends UiScreen

# Equipment workspace — an overlay on top of the hangar: mech stats and
# crew on the left, the bay showing through the middle (camera pushed to
# a close-up), one row per hardpoint on the right, paint + hull upgrade
# on the bottom action bar. Weapon selection opens as full screens on top.

const HEAVY_ACCENT := Color(1.0, 0.42, 0.34)
const PANEL_WIDTH := 306.0
const RIGHT_WIDTH := 424.0
const MAX_SPEED := 7.0

var _title: Label
var _robot_chips: HBoxContainer
var _robot_name: Label
var _class_line: Label
var _power_value: Label
var _armor_value: Label
var _armor_fill: ColorRect
var _speed_value: Label
var _speed_fill: ColorRect
var _ability_line: Label
var _ability_chips: HBoxContainer
var _bonus_label: Label
var _pilot_line: Button
var _drone_line: Button
var _spec_line: Button
var _paint_button: Button
var _palette_row: HBoxContainer
var _swatch_buttons: Array[Button] = []
var _weapons_header: Label
var _eq_rows: Array[Panel] = []
var _eq_badges: Array[Panel] = []
var _eq_badge_labels: Array[Label] = []
var _eq_names: Array[Label] = []
var _eq_classes: Array[Label] = []
var _eq_stats: Array[Label] = []
var _eq_assigns: Array[Button] = []
var _eq_upgrades: Array[Button] = []

func is_opaque() -> bool:
	return false

func _build() -> void:
	_build_header()
	_build_left_panel()
	_build_right_panel()
	_build_bottom_bar()

func on_enter() -> void:
	_set_closeup(true)
	_set_hangar_chrome(false)
	refresh()

func on_exit() -> void:
	_set_closeup(false)
	_set_hangar_chrome(true)

func _set_closeup(on: bool) -> void:
	var bay := manager.screen(&"hangar") as HangarScreen
	if bay != null:
		bay.set_closeup(on)

# The workspace owns the screen; the bay stays (3D presentation) but the
# hangar's own chrome would ghost through this transparent overlay.
func _set_hangar_chrome(show_chrome: bool) -> void:
	var bay := manager.screen(&"hangar") as HangarScreen
	if bay != null:
		bay.set_chrome_visible(show_chrome)

# ---------------------------------------------------------------- chrome

func _build_header() -> void:
	var header := Control.new()
	header.name = "Header"
	header.anchor_left = 0.0
	header.anchor_top = 0.0
	header.anchor_right = 1.0
	header.anchor_bottom = 0.0
	header.offset_left = 18.0
	header.offset_top = 64.0
	header.offset_right = -18.0
	header.offset_bottom = 112.0
	header.mouse_filter = Control.MOUSE_FILTER_PASS
	add_child(header)

	var row := UiParts.header_row("EQUIPMENT", back)
	row.anchor_left = 0.0
	row.anchor_top = 0.0
	row.anchor_right = 1.0
	row.anchor_bottom = 1.0
	header.add_child(row)
	_title = row.get_node_or_null("ScreenTitle") as Label
	_build_robot_strip(header)

# img2: robot thumbnail strip + cycle arrows in the header.
func _build_robot_strip(header: Control) -> void:
	var strip := UiParts.hbox(6.0)
	strip.name = "RobotStrip"
	strip.anchor_left = 1.0
	strip.anchor_top = 0.0
	strip.anchor_right = 1.0
	strip.anchor_bottom = 1.0
	strip.offset_left = -680.0
	strip.offset_top = 4.0
	strip.offset_right = 0.0
	strip.offset_bottom = -4.0
	strip.alignment = BoxContainer.ALIGNMENT_END
	strip.mouse_filter = Control.MOUSE_FILTER_PASS
	header.add_child(strip)

	var prev := UiParts.button("<", UiTheme.STEEL, 15, Vector2(44.0, 40.0))
	prev.name = "PrevRobotButton"
	UiParts.wire(prev, _cycle_robot.bind(-1))
	strip.add_child(prev)

	_robot_chips = UiParts.hbox(6.0)
	_robot_chips.name = "RobotChips"
	strip.add_child(_robot_chips)

	var next := UiParts.button(">", UiTheme.STEEL, 15, Vector2(44.0, 40.0))
	next.name = "NextRobotButton"
	UiParts.wire(next, _cycle_robot.bind(1))
	strip.add_child(next)

func _refresh_robot_strip() -> void:
	if _robot_chips == null:
		return
	for child in _robot_chips.get_children():
		_robot_chips.remove_child(child)
		child.queue_free()
	for robot_id in _owned_robots():
		var selected := robot_id == GameState.selected_robot
		var definition := GameState.robot_def(robot_id)
		var chip := UiParts.button(
				String(definition.get("name", String(robot_id))),
				UiTheme.AMBER if selected else UiTheme.STEEL,
				12, Vector2(96.0, 40.0))
		chip.name = "RobotStrip_%s" % String(robot_id)
		if selected:
			chip.add_theme_stylebox_override("normal",
					UiTheme.glow_frame(UiTheme.AMBER, 2))
		UiParts.wire(chip, _select_robot.bind(robot_id))
		_robot_chips.add_child(chip)

func _owned_robots() -> Array[StringName]:
	var owned: Array[StringName] = []
	for robot_id in GameState.ROBOT_ORDER:
		if GameState.owns_robot(robot_id):
			owned.append(robot_id)
	return owned

func _cycle_robot(step: int) -> void:
	var owned := _owned_robots()
	if owned.size() < 2:
		return
	var at := owned.find(GameState.selected_robot)
	if at < 0:
		at = 0
	_select_robot(owned[(at + step + owned.size()) % owned.size()])

func _select_robot(robot_id: StringName) -> void:
	if robot_id == GameState.selected_robot or not GameState.owns_robot(robot_id):
		return
	GameState.select_robot(robot_id)
	var bay := manager.screen(&"hangar") as HangarScreen
	if bay != null:
		bay.rebuild_bay()
	manager.refresh()

func _build_left_panel() -> void:
	var panel := Panel.new()
	panel.name = "InfoPanel"
	panel.anchor_left = 0.0
	panel.anchor_top = 0.0
	panel.anchor_right = 0.0
	panel.anchor_bottom = 1.0
	panel.offset_left = 18.0
	panel.offset_top = 118.0
	panel.offset_right = 18.0 + PANEL_WIDTH
	panel.offset_bottom = -88.0
	panel.add_theme_stylebox_override("panel", UiTheme.panel(0.9))
	add_child(panel)

	var scroll := UiParts.scroll()
	scroll.name = "InfoScroll"
	scroll.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	scroll.offset_left = 14.0
	scroll.offset_top = 12.0
	scroll.offset_right = -14.0
	scroll.offset_bottom = -12.0
	panel.add_child(scroll)

	var column := UiParts.vbox(8.0)
	column.name = "InfoColumn"
	column.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	scroll.add_child(column)

	column.add_child(UiParts.section("MECH"))
	_robot_name = UiParts.label("SCARAB", 26, UiTheme.TEXT, true)
	_robot_name.name = "RobotTitle"
	column.add_child(_robot_name)
	_class_line = UiParts.label("ASSAULT", 12, UiTheme.MUTED)
	_class_line.name = "ClassLine"
	column.add_child(_class_line)
	_power_value = UiParts.label("POWER  0", 16, UiTheme.AMBER, true)
	_power_value.name = "PowerValue"
	column.add_child(_power_value)
	column.add_child(UiParts.divider())

	var armor_row := UiParts.stat_row("ArmorRow", "ARMOR", "0", 1.0,
			UiTheme.HEALTH)
	_armor_value = armor_row.get_node("RowTop/Value") as Label
	_armor_fill = armor_row.get_node("Bar/Fill") as ColorRect
	column.add_child(armor_row)
	var speed_row := UiParts.stat_row("SpeedRow", "SPEED", "0 M/S", 1.0,
			UiTheme.CYAN)
	_speed_value = speed_row.get_node("RowTop/Value") as Label
	_speed_fill = speed_row.get_node("Bar/Fill") as ColorRect
	column.add_child(speed_row)
	column.add_child(UiParts.divider())

	column.add_child(UiParts.section("SYSTEM"))
	_ability_line = UiParts.label("ABILITY", 13, UiTheme.TEXT)
	_ability_line.name = "AbilityLine"
	_ability_line.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	column.add_child(_ability_line)
	_ability_chips = UiParts.hbox(6.0)
	_ability_chips.name = "AbilityChips"
	column.add_child(_ability_chips)
	_ability_chips.add_child(UiParts.ability_chip("", ""))
	_ability_chips.add_child(UiParts.ability_chip("", ""))
	_bonus_label = UiParts.label("BONUS", 12, UiTheme.HEALTH)
	_bonus_label.name = "BonusLabel"
	_bonus_label.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	column.add_child(_bonus_label)
	column.add_child(UiParts.divider())

	column.add_child(UiParts.section("CREW"))
	_pilot_line = UiParts.button("PILOT  NONE", UiTheme.STEEL, 13)
	_pilot_line.name = "PilotLine"
	_pilot_line.alignment = HORIZONTAL_ALIGNMENT_LEFT
	UiParts.wire(_pilot_line, func() -> void: manager.push(&"pilot"))
	column.add_child(_pilot_line)
	_drone_line = UiParts.button("DRONE  NONE", UiTheme.STEEL, 13)
	_drone_line.name = "DroneLine"
	_drone_line.alignment = HORIZONTAL_ALIGNMENT_LEFT
	UiParts.wire(_drone_line, func() -> void: manager.push(&"drone"))
	column.add_child(_drone_line)
	_spec_line = UiParts.button("SPECIALISATION", UiTheme.STEEL, 13)
	_spec_line.name = "SpecLine"
	_spec_line.alignment = HORIZONTAL_ALIGNMENT_LEFT
	UiParts.wire(_spec_line, func() -> void: manager.push(&"spec"))
	column.add_child(_spec_line)

func _build_right_panel() -> void:
	var panel := Panel.new()
	panel.name = "EquipmentPanel"
	panel.anchor_left = 1.0
	panel.anchor_top = 0.0
	panel.anchor_right = 1.0
	panel.anchor_bottom = 1.0
	panel.offset_left = -18.0 - RIGHT_WIDTH
	panel.offset_top = 118.0
	panel.offset_right = -18.0
	panel.offset_bottom = -88.0
	panel.add_theme_stylebox_override("panel", UiTheme.panel(0.9))
	add_child(panel)

	var scroll := UiParts.scroll()
	scroll.name = "EquipmentScroll"
	scroll.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	scroll.offset_left = 14.0
	scroll.offset_top = 12.0
	scroll.offset_right = -14.0
	scroll.offset_bottom = -12.0
	panel.add_child(scroll)

	var column := UiParts.vbox(10.0)
	column.name = "EquipmentColumn"
	column.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	scroll.add_child(column)

	_weapons_header = UiParts.section("WEAPONS  0/0")
	_weapons_header.name = "WeaponsHeader"
	column.add_child(_weapons_header)

	for slot_index in GameState.SLOT_COUNT:
		column.add_child(_build_slot_row(slot_index))

func _build_slot_row(slot_index: int) -> Panel:
	var row := Panel.new()
	row.name = "EquipmentSlotRow%d" % slot_index
	row.custom_minimum_size = Vector2(0.0, 96.0)
	row.add_theme_stylebox_override("panel", UiTheme.panel(0.84))
	row.gui_input.connect(_on_slot_row_input.bind(slot_index))

	var layout := UiParts.hbox(10.0)
	layout.name = "SlotRowLayout"
	layout.anchor_left = 0.0
	layout.anchor_top = 0.0
	layout.anchor_right = 1.0
	layout.anchor_bottom = 1.0
	layout.offset_left = 12.0
	layout.offset_top = 8.0
	layout.offset_right = -12.0
	layout.offset_bottom = -8.0
	row.add_child(layout)

	var badge := UiParts.badge("", UiTheme.AMBER)
	badge.name = "EqBadge"
	layout.add_child(badge)
	var badge_label := badge.get_node_or_null("BadgeLabel") as Label
	if badge_label != null:
		badge_label.name = "EqBadgeLabel"

	var text_column := UiParts.vbox(2.0)
	text_column.name = "SlotText"
	text_column.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	text_column.size_flags_vertical = Control.SIZE_SHRINK_CENTER
	text_column.mouse_filter = Control.MOUSE_FILTER_IGNORE
	layout.add_child(text_column)
	var name_label := UiParts.label("", 16, UiTheme.TEXT)
	name_label.name = "EqName"
	text_column.add_child(name_label)
	var class_label := UiParts.label("", 11, UiTheme.MUTED)
	class_label.name = "EqClass"
	text_column.add_child(class_label)
	var stat_label := UiParts.label("", 11, UiTheme.AMBER)
	stat_label.name = "EqStat"
	text_column.add_child(stat_label)

	# Actions stack on the right (WR's rows carry one narrow action
	# column): side-by-side buttons blew the row past the viewport on
	# 1280-wide devices.
	var actions := UiParts.vbox(6.0)
	actions.name = "SlotActions"
	actions.alignment = BoxContainer.ALIGNMENT_CENTER
	actions.size_flags_vertical = Control.SIZE_SHRINK_CENTER
	actions.mouse_filter = Control.MOUSE_FILTER_IGNORE
	layout.add_child(actions)

	var assign_button := UiParts.button("SELECT", UiTheme.CYAN, 13,
			Vector2(104.0, 34.0))
	assign_button.name = "EqAssign%d" % slot_index
	UiParts.wire(assign_button, _open_select.bind(slot_index))
	actions.add_child(assign_button)

	var upgrade_button := UiParts.button("UPGRADE", UiTheme.CTA_GREEN, 13,
			Vector2(104.0, 34.0))
	upgrade_button.name = "EqUpgrade%d" % slot_index
	UiParts.wire(upgrade_button, _open_slot_upgrade.bind(slot_index))
	actions.add_child(upgrade_button)

	_eq_rows.append(row)
	_eq_badges.append(badge)
	_eq_badge_labels.append(badge_label)
	_eq_names.append(name_label)
	_eq_classes.append(class_label)
	_eq_stats.append(stat_label)
	_eq_assigns.append(assign_button)
	_eq_upgrades.append(upgrade_button)
	# A plain Panel doesn't propagate child minimums — and the stacked
	# actions measure small while off-tree (button theme mins resolve at
	# 11 px default font). Size to the real layout: two 63 px buttons
	# + 6 gap + 16 padding.
	row.custom_minimum_size.y = maxf(96.0, 148.0)
	return row

func _build_bottom_bar() -> void:
	var bar := Panel.new()
	bar.name = "BottomActions"
	bar.anchor_left = 0.0
	bar.anchor_right = 1.0
	bar.anchor_top = 1.0
	bar.anchor_bottom = 1.0
	bar.offset_left = 18.0
	bar.offset_right = -18.0
	bar.offset_top = -101.0
	bar.offset_bottom = -16.0
	bar.add_theme_stylebox_override("panel", UiTheme.panel(0.92))
	add_child(bar)

	var row := UiParts.hbox(10.0)
	row.name = "ActionRow"
	row.anchor_left = 0.0
	row.anchor_top = 0.0
	row.anchor_right = 1.0
	row.anchor_bottom = 1.0
	row.offset_left = 14.0
	row.offset_top = 8.0
	row.offset_right = -14.0
	row.offset_bottom = -8.0
	row.size_flags_vertical = Control.SIZE_SHRINK_CENTER
	bar.add_child(row)

	_paint_button = UiParts.button("PAINT", UiTheme.AMBER, 15,
			Vector2(120.0, 50.0))
	_paint_button.name = "PaintButton"
	UiParts.wire(_paint_button, _toggle_paint)
	row.add_child(_paint_button)

	_palette_row = UiParts.hbox(8.0)
	_palette_row.name = "PaletteRow"
	_palette_row.size_flags_vertical = Control.SIZE_SHRINK_CENTER
	_palette_row.visible = false
	row.add_child(_palette_row)
	for index in GameState.PALETTE_COUNT:
		var swatch := Button.new()
		swatch.name = "Swatch%d" % index
		swatch.custom_minimum_size = Vector2(46.0, 46.0)
		swatch.focus_mode = Control.FOCUS_NONE
		swatch.tooltip_text = GameState.PALETTE_NAMES[index]
		UiParts.wire(swatch, _on_swatch_pressed.bind(index))
		_palette_row.add_child(swatch)
		_swatch_buttons.append(swatch)

	var spacer := Control.new()
	spacer.name = "ActionSpacer"
	spacer.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	spacer.mouse_filter = Control.MOUSE_FILTER_IGNORE
	row.add_child(spacer)

	var hull_button := UiParts.button("HULL UPGRADE", Color(0.36, 0.86, 0.55),
			15, Vector2(190.0, 50.0))
	hull_button.name = "HullUpgradeButton"
	UiParts.wire(hull_button, _open_hull_upgrade)
	UiTheme.solid_cta(hull_button, UiTheme.CTA_GREEN, 15)
	row.add_child(hull_button)

	var change_button := UiParts.button("CHANGE ROBOT", UiTheme.CYAN, 15,
			Vector2(190.0, 50.0))
	change_button.name = "ChangeRobotButton"
	UiParts.wire(change_button, _on_change_robot_pressed)
	UiTheme.solid_cta(change_button, UiTheme.CTA_BLUE, 15)
	row.add_child(change_button)

	var stats_button := UiParts.button("STATS", UiTheme.AMBER, 15,
			Vector2(130.0, 50.0))
	stats_button.name = "StatsButton"
	UiParts.wire(stats_button, _on_stats_pressed)
	row.add_child(stats_button)

# ---------------------------------------------------------------- actions

func _on_slot_row_input(event: InputEvent, slot_index: int) -> void:
	if event is InputEventMouseButton:
		var mouse := event as InputEventMouseButton
		if mouse.pressed and mouse.button_index == MOUSE_BUTTON_LEFT:
			_open_select(slot_index)

func _open_select(slot_index: int) -> void:
	if slot_index >= GameState.slot_count():
		return
	manager.push(&"weapon_select", {
		"robot": GameState.selected_robot,
		"slot": slot_index,
	})

func _open_slot_upgrade(slot_index: int) -> void:
	var item_id := GameState.equipped_item(GameState.selected_robot, slot_index)
	if item_id.is_empty():
		manager.toast("NO WEAPON IN THAT HARDPOINT", true)
		return
	manager.push(&"upgrade", {
		"key": GameState.upgrade_key(GameState.selected_robot, slot_index),
		"is_body": false,
		"slot": slot_index,
	})

func _open_hull_upgrade() -> void:
	manager.push(&"upgrade", {
		"key": GameState.body_upgrade_key(GameState.selected_robot),
		"is_body": true,
		"slot": -1,
	})

func _on_change_robot_pressed() -> void:
	# Back to the bay: the deck strip is the robot selector.
	back()

func _on_stats_pressed() -> void:
	if manager != null:
		manager.push(&"stats")

func _toggle_paint() -> void:
	_palette_row.visible = not _palette_row.visible

func _on_swatch_pressed(index: int) -> void:
	if not GameState.paint_unlocked(index):
		var cost := GameState.paint_cost(index)
		if not GameState.unlock_paint(index):
			manager.toast("NEED %s SILVER" % UiParts.money(cost), true)
			return
		manager.toast("%s PAINT UNLOCKED" % GameState.PALETTE_NAMES[index])
	GameState.set_palette(index)
	refresh()

# ---------------------------------------------------------------- refresh

func refresh() -> void:
	if _robot_name == null:
		return
	var definition := GameState.robot_def()
	var robot_name := String(definition.get("name", "MECH"))
	_title.text = "EQUIPMENT  //  %s" % robot_name
	_robot_name.text = robot_name
	_class_line.text = _class_line_text(definition)
	_power_value.text = "POWER  %s" % GameState.fmt_amount(GameState.robot_power())

	var base_armor := float(definition.get("armor", 200.0))
	var armor_value := base_armor * GameState.body_mult()
	var armor_key := GameState.body_upgrade_key(GameState.selected_robot)
	var armor_max := base_armor * GameState.body_mult_at(armor_key,
			Vector2i(GameState.upgrade_mk_cap(armor_key),
					GameState.upgrade_level_cap(armor_key)))
	_armor_value.text = "ARMOR  %s" % GameState.fmt_amount(armor_value)
	UiParts.set_bar(_armor_fill, armor_value / maxf(armor_max, 1.0))
	var speed_value := float(definition.get("speed", 7.0))
	_speed_value.text = "SPEED  %.1f M/S" % speed_value
	UiParts.set_bar(_speed_fill, speed_value / MAX_SPEED)

	var ability_text := "ABILITY  %s" % String(definition.get("ability", ""))
	var secondary := String(definition.get("secondary", ""))
	if not secondary.is_empty():
		ability_text += "  +  %s" % secondary
	var builtin := String(definition.get("builtin", ""))
	if not builtin.is_empty():
		ability_text += "  ·  BUILT-IN  %s" % builtin
	_ability_line.text = ability_text
	var chips := _ability_chips.get_children()
	if chips.size() >= 2:
		UiParts.set_ability_chip(chips[0],
				String(definition.get("ability_short", "")),
				String(definition.get("ability_desc", "")))
		UiParts.set_ability_chip(chips[1],
				String(definition.get("secondary_short", "")),
				String(definition.get("secondary_desc", "")))
	_bonus_label.text = _bonus_text()
	_pilot_line.text = _pilot_text()
	_drone_line.text = _drone_text()
	_spec_line.text = _spec_text()

	_refresh_equipment()
	_refresh_palette()
	_refresh_robot_strip()

func _class_line_text(definition: Dictionary) -> String:
	var class_text := String(definition.get("klass", "ASSAULT"))
	if GameState.is_titan():
		class_text = "TITAN · %s" % class_text
	var role := String(definition.get("role", ""))
	if not role.is_empty():
		class_text += "  ·  %s" % role
	var key := GameState.body_upgrade_key(GameState.selected_robot)
	var state := GameState.upgrade_state(key)
	if GameState.upgrade_class(key) == GameState.UpgradeClass.STANDARD:
		class_text += "  ·  MK%d · LV%d" % [state.x, state.y]
	else:
		class_text += "  ·  LV%d" % state.y
	return class_text

func _bonus_text() -> String:
	var stats := GameState.combat_stats()
	var parts: Array[String] = []
	parts.append("HP %s" % _bonus_pct(float(stats.get("hp", 1.0))))
	parts.append("DMG %s" % _bonus_pct(float(stats.get("damage", 1.0))))
	parts.append("ROF %s" % _bonus_pct(float(stats.get("fire_rate", 1.0))))
	parts.append("SPD %s" % _bonus_pct(float(stats.get("speed", 1.0))))
	var resist := 1.0 - float(stats.get("defense", 1.0))
	if resist > 0.005:
		parts.append("RESIST +%d%%" % roundi(resist * 100.0))
	var cdr := 1.0 - float(stats.get("cooldown", 1.0))
	if cdr > 0.005:
		parts.append("CDR +%d%%" % roundi(cdr * 100.0))
	var repair := float(stats.get("regen", 0.0))
	if repair > 0.0001:
		parts.append("REP +%.1f%%/S" % (repair * 100.0))
	var line := "BONUS  "
	for index in parts.size():
		if index > 0:
			line += "  ·  "
		line += parts[index]
	return line

func _bonus_pct(value: float) -> String:
	var pct := roundi((value - 1.0) * 100.0)
	if pct >= 0:
		return "+%d%%" % pct
	return "%d%%" % pct

func _pilot_text() -> String:
	var pilot_id := GameState.assigned_pilot(GameState.selected_robot)
	if pilot_id.is_empty():
		return "PILOT  NONE"
	var pilot_info := GameState.pilot_def(pilot_id)
	var pilot_state := GameState.pilot_state(pilot_id)
	return "PILOT  %s  ·  LV %d  ·  T%d" % [
			String(pilot_info.get("name", "NONE")),
			int(pilot_state.get("level", 1)),
			int(pilot_state.get("tier", 1))]

func _drone_text() -> String:
	var drone_id := GameState.drone_for_robot(GameState.selected_robot)
	if drone_id.is_empty():
		return "DRONE  NONE"
	var drone_info := GameState.drone_def(drone_id)
	return "DRONE  %s  ·  LV %d" % [
			String(drone_info.get("name", drone_id.to_upper())),
			GameState.drone_level(drone_id)]

func _spec_text() -> String:
	var spent := 0
	for node in GameState.spec_nodes(GameState.selected_robot):
		spent += GameState.spec_rank(GameState.selected_robot,
				String(node.get("id", "")))
	return "SPECIALISATION  RANKS %d  ·  %d MODULE PTS" % [
			spent, GameState.module_points]

func _refresh_equipment() -> void:
	_weapons_header.text = "WEAPONS  %d/%d" % [GameState.filled_slots(),
			GameState.slot_count()]
	var count := GameState.slot_count()
	for index in GameState.SLOT_COUNT:
		_eq_rows[index].visible = index < count
		if index >= count:
			continue
		var slot_kind := GameState.slot_size(GameState.selected_robot, index)
		var item_id := GameState.equipped_item(GameState.selected_robot, index)
		var color := _slot_color(slot_kind)
		var badge := _eq_badges[index]
		if badge != null:
			badge.add_theme_stylebox_override("panel", _badge_style(color))
		var badge_label := _eq_badge_labels[index]
		if badge_label != null:
			badge_label.text = GameState.SLOT_LABELS[slot_kind]
			badge_label.add_theme_color_override("font_color", color)
		_eq_rows[index].add_theme_stylebox_override("panel",
				UiTheme.panel(0.8, color))
		_eq_upgrades[index].disabled = item_id.is_empty()
		_eq_assigns[index].disabled = false
		if item_id.is_empty():
			_eq_names[index].text = "EMPTY HARDPOINT"
			_eq_classes[index].text = "TAP SELECT TO FILL THIS SLOT"
			_eq_stats[index].text = "%s SLOT" % GameState.SLOT_LABELS[slot_kind]
		else:
			_eq_names[index].text = GameState.item_display_name(item_id)
			_eq_classes[index].text = GameState.item_class_label(item_id)
			_eq_stats[index].text = _item_stat_text(item_id, index)

func _item_stat_text(item_id: String, slot_index: int) -> String:
	var key := GameState.upgrade_key(GameState.selected_robot, slot_index)
	var state := GameState.upgrade_state(key)
	var level_text := ("LV%d" % state.y if GameState.upgrade_class(key)
			!= GameState.UpgradeClass.STANDARD else "MK%d · LV%d" % [state.x, state.y])
	var weapon := GameState.weapon_for_item(item_id) as WeaponData
	if weapon == null:
		return level_text
	var line := "%s · DMG %s" % [level_text, GameState.fmt_amount(weapon.damage)]
	var spares := GameState.free_copies(item_id)
	if spares > 0:
		line += " · ×%d" % spares
	return line

func _badge_style(color: Color) -> StyleBoxFlat:
	var style := StyleBoxFlat.new()
	style.bg_color = Color(color.r, color.g, color.b, 0.22)
	style.border_color = color
	style.set_border_width_all(1)
	style.set_corner_radius_all(4)
	return style

func _slot_color(slot_kind: int) -> Color:
	if slot_kind == GameState.SlotSize.ALPHA:
		return HEAVY_ACCENT
	if slot_kind == GameState.SlotSize.BETA:
		return UiTheme.CYAN
	if slot_kind == GameState.SlotSize.LIGHT:
		return UiTheme.CYAN
	if slot_kind == GameState.SlotSize.HEAVY:
		return HEAVY_ACCENT
	return UiTheme.AMBER

func _refresh_palette() -> void:
	for index in _swatch_buttons.size():
		_style_swatch(index)

func _style_swatch(index: int) -> void:
	var swatch := _swatch_buttons[index]
	var unlocked := GameState.paint_unlocked(index)
	var colors := GameState.palette_colors(index)
	var primary: Color = colors[0]
	var style := StyleBoxFlat.new()
	style.bg_color = primary
	style.set_corner_radius_all(6)
	if index == GameState.palette_for(GameState.selected_robot):
		style.border_color = UiTheme.AMBER
		style.set_border_width_all(3)
		swatch.add_theme_stylebox_override("normal", UiTheme.glow_frame(
				UiTheme.AMBER, 3))
		# Keep the paint colour visible under the glow: tinted background.
		style.bg_color = primary
		swatch.add_theme_stylebox_override("hover", style)
		swatch.add_theme_stylebox_override("pressed", style)
	else:
		style.border_color = Color(1.0, 1.0, 1.0, 0.35 if unlocked else 0.12)
		style.set_border_width_all(2)
		swatch.add_theme_stylebox_override("normal", style)
		swatch.add_theme_stylebox_override("hover", style)
		swatch.add_theme_stylebox_override("pressed", style)
	swatch.disabled = false
	swatch.modulate = Color(1.0, 1.0, 1.0, 1.0 if unlocked else 0.45)
	swatch.tooltip_text = "%s%s" % [
			GameState.PALETTE_NAMES[index],
			"" if unlocked else "  ·  %s SILVER" % UiParts.money(
					GameState.paint_cost(index))]
