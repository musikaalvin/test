class_name WeaponDetailScreen
extends UiScreen

# Full stats page for one weapon: big procedural preview, the numbers
# that matter (damage, rate, DPS, heat, special rules) and the actions —
# EQUIP into the slot you came from, UPGRADE when it is mounted there,
# BUY straight from the store tab.

var _title: Label
var _item: String = ""
var _robot: StringName = &""
var _slot: int = 0
var _from_tab: int = 0
var _preview: ItemPreview
var _badge: Label
var _stats: VBoxContainer
var _stat_index: int = 0
var _action: Button
var _buy_action: Button
var _upgrade_action: Button

func _build() -> void:
	add_child(UiParts.backdrop(0.97))
	_build_header()
	_build_body()
	_build_actions()

func _build_header() -> void:
	var header := Control.new()
	header.name = "Header"
	header.anchor_left = 0.0
	header.anchor_top = 0.0
	header.anchor_right = 1.0
	header.anchor_bottom = 0.0
	header.offset_left = 18.0
	header.offset_top = 64.0
	header.offset_right = -18.0
	header.offset_bottom = 112.0
	header.mouse_filter = Control.MOUSE_FILTER_PASS
	add_child(header)

	var row := UiParts.header_row("WEAPON", back)
	row.anchor_left = 0.0
	row.anchor_top = 0.0
	row.anchor_right = 1.0
	row.anchor_bottom = 1.0
	header.add_child(row)
	_title = row.get_node_or_null("ScreenTitle") as Label

func _build_body() -> void:
	var body := UiParts.hbox(18.0)
	body.name = "DetailBody"
	body.anchor_left = 0.0
	body.anchor_top = 0.0
	body.anchor_right = 1.0
	body.anchor_bottom = 1.0
	body.offset_left = 18.0
	body.offset_top = 118.0
	body.offset_right = -18.0
	body.offset_bottom = -96.0
	body.mouse_filter = Control.MOUSE_FILTER_PASS
	add_child(body)

	var preview_panel := Panel.new()
	preview_panel.name = "PreviewPanel"
	preview_panel.custom_minimum_size = Vector2(430.0, 0.0)
	preview_panel.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	preview_panel.add_theme_stylebox_override("panel", UiTheme.panel(0.88))
	body.add_child(preview_panel)

	var preview_column := UiParts.vbox(10.0)
	preview_column.name = "PreviewColumn"
	preview_column.anchor_left = 0.0
	preview_column.anchor_top = 0.0
	preview_column.anchor_right = 1.0
	preview_column.anchor_bottom = 1.0
	preview_column.offset_left = 16.0
	preview_column.offset_top = 16.0
	preview_column.offset_right = -16.0
	preview_column.offset_bottom = -16.0
	preview_column.alignment = BoxContainer.ALIGNMENT_CENTER
	preview_panel.add_child(preview_column)

	_preview = ItemPreview.new()
	_preview.name = "DetailPreview"
	_preview.custom_minimum_size = Vector2(0.0, 320.0)
	_preview.size_flags_vertical = Control.SIZE_EXPAND_FILL
	_preview.mouse_filter = Control.MOUSE_FILTER_IGNORE
	preview_column.add_child(_preview)

	_badge = UiParts.label("", 13, UiTheme.CYAN, true)
	_badge.name = "PreviewBadge"
	_badge.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	preview_column.add_child(_badge)

	var stats_panel := Panel.new()
	stats_panel.name = "StatsPanel"
	stats_panel.custom_minimum_size = Vector2(470.0, 0.0)
	stats_panel.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	stats_panel.add_theme_stylebox_override("panel", UiTheme.panel(0.88))
	body.add_child(stats_panel)

	var stats_scroll := UiParts.scroll()
	stats_scroll.name = "StatsScroll"
	stats_scroll.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	stats_scroll.offset_left = 18.0
	stats_scroll.offset_top = 16.0
	stats_scroll.offset_right = -18.0
	stats_scroll.offset_bottom = -16.0
	stats_panel.add_child(stats_scroll)

	_stats = UiParts.vbox(8.0)
	_stats.name = "StatRows"
	_stats.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	stats_scroll.add_child(_stats)

func _build_actions() -> void:
	var bar := Panel.new()
	bar.name = "ActionBar"
	bar.anchor_left = 0.0
	bar.anchor_right = 1.0
	bar.anchor_top = 1.0
	bar.anchor_bottom = 1.0
	bar.offset_left = 18.0
	bar.offset_right = -18.0
	bar.offset_top = -84.0
	bar.offset_bottom = -16.0
	bar.add_theme_stylebox_override("panel", UiTheme.panel(0.92))
	add_child(bar)

	var row := UiParts.hbox(12.0)
	row.name = "ActionRow"
	row.anchor_left = 0.0
	row.anchor_top = 0.0
	row.anchor_right = 1.0
	row.anchor_bottom = 1.0
	row.offset_left = 14.0
	row.offset_top = 8.0
	row.offset_right = -14.0
	row.offset_bottom = -8.0
	row.alignment = BoxContainer.ALIGNMENT_CENTER
	bar.add_child(row)

	_buy_action = UiParts.button("BUY", UiTheme.AMBER, 16, Vector2(230.0, 56.0))
	_buy_action.name = "BuyButton"
	UiParts.wire(_buy_action, _buy_pressed)
	row.add_child(_buy_action)

	_action = UiParts.button("EQUIP", UiTheme.CYAN, 16, Vector2(230.0, 56.0))
	_action.name = "EquipButton"
	UiParts.wire(_action, _equip_pressed)
	row.add_child(_action)

	_upgrade_action = UiParts.button("UPGRADE", Color(0.36, 0.86, 0.55), 16,
			Vector2(230.0, 56.0))
	_upgrade_action.name = "UpgradeButton"
	UiParts.wire(_upgrade_action, _upgrade_pressed)
	row.add_child(_upgrade_action)

func open(params: Dictionary = {}) -> void:
	_item = str(params.get("item", ""))
	_robot = params.get("robot", GameState.selected_robot) as StringName
	_slot = int(params.get("slot", 0))
	_from_tab = int(params.get("tab", 0))

func on_enter() -> void:
	refresh()

func refresh() -> void:
	if _title == null:
		return
	if _item.is_empty():
		return
	if _robot == &"":
		_robot = GameState.selected_robot
	_title.text = "WEAPON  //  %s" % _item
	_preview.set_weapon(_item)

	var size_kind := GameState.item_slot_size(_item)
	var size_label := GameState.SLOT_LABELS[size_kind]
	var family := GameState.item_family(_item)
	_badge.text = "%s  ·  %s  ·  %s" % [size_label, family,
			GameState.item_class_label(_item)]

	_rebuild_stats()

	var current := GameState.equipped_item(_robot, _slot)
	var mounted_here := current == _item and not _item.is_empty()
	var owned := GameState.pool_count(_item) > 0
	var wanted := GameState.slot_size(_robot, _slot)
	var fits := GameState.item_slot_size(_item) == wanted

	# BUY shows for unowned items (and, from the store tab, as a second
	# copy); EQUIP only for weapons actually in storage.
	_buy_action.visible = (not owned) or _from_tab == WeaponSelectScreen.TAB_STORE
	_buy_action.disabled = not _can_afford()
	_buy_action.text = _buy_label()

	_action.visible = owned
	_action.disabled = (not fits) or mounted_here
	_action.text = "EQUIPPED HERE" if mounted_here \
			else ("EQUIP" if fits else "WON'T FIT THIS SLOT")

	_upgrade_action.visible = mounted_here
	_upgrade_action.disabled = false

func _rebuild_stats() -> void:
	for child in _stats.get_children():
		_stats.remove_child(child)
		child.queue_free()
	_stat_index = 0

	var weapon := GameState.weapon_for_item(_item) as WeaponData
	if weapon == null:
		return

	_stats.add_child(UiParts.section("COMBAT"))
	var dps := weapon.damage * weapon.pellets * weapon.shots_per_minute / 60.0
	_stats.add_child(_stat_line("DAMAGE",
			GameState.fmt_amount(weapon.damage * weapon.pellets)))
	_stats.add_child(_stat_line("FIRE RATE", "%d RPM" % int(weapon.shots_per_minute)))
	_stats.add_child(_stat_line("DPS", GameState.fmt_amount(dps)))
	if weapon.pellets > 1:
		_stats.add_child(_stat_line("PELLETS", str(weapon.pellets)))
	_stats.add_child(_stat_line("HEAT / SHOT", "%.3f" % weapon.heat_per_shot))
	_stats.add_child(_stat_line("ACCURACY", "%s° SPREAD" % _num(weapon.spread_degrees, 1)))

	var has_special := false
	if weapon.splash_radius > 0.0:
		_stats.add_child(_stat_line("SPLASH RADIUS", "%.1f M" % weapon.splash_radius))
		has_special = true
	if weapon.corrosion_dps > 0.0:
		_stats.add_child(_stat_line("CORROSION", "%s / S FOR %.1f S" % [
				_num(weapon.corrosion_dps, 1), weapon.corrosion_duration]))
		has_special = true
	if weapon.chain_bounces > 0:
		_stats.add_child(_stat_line("CHAIN SHOCK", "%d BOUNCES · %.0f M" % [
				weapon.chain_bounces, weapon.chain_range]))
		has_special = true
	if weapon.lock_beam:
		_stats.add_child(_stat_line("LOCK BEAM", "%.0f M RANGE" % weapon.beam_range))
		has_special = true
	if weapon.magazine > 0:
		_stats.add_child(_stat_line("MAGAZINE", "%d ROUNDS · %.1f S RELOAD" % [
				weapon.magazine, weapon.reload_time]))
		has_special = true
	if weapon.hull_fraction >= 0.99:
		_stats.add_child(_stat_line("DAMAGE TYPE", "GREY — CANNOT BE REPAIRED"))
		has_special = true
	if weapon.slow_duration > 0.0 and weapon.slow_factor < 1.0:
		_stats.add_child(_stat_line("SLOW ON HIT", "%.0f%% FOR %.1f S" % [
				weapon.slow_factor * 100.0, weapon.slow_duration]))
		has_special = true
	if not has_special:
		_stats.add_child(_stat_line("SPECIAL", "DIRECT FIRE"))

	_stats.add_child(UiParts.divider())
	_stats.add_child(UiParts.section("SERVICE STATE"))
	_stats.add_child(_stat_line("OWNED", "×%d  (%d MOUNTED)" % [
			GameState.pool_count(_item), GameState.equipped_count(_item)]))
	_stats.add_child(_stat_line("IN STORAGE", str(GameState.free_copies(_item))))
	var mounted_here := (not _item.is_empty()) \
			and GameState.equipped_item(_robot, _slot) == _item
	if mounted_here:
		var key := GameState.upgrade_key(_robot, _slot)
		var state := GameState.upgrade_state(key)
		_stats.add_child(_stat_line("UPGRADE STATE",
				_mk_label(key, state.x, state.y)))
	_stats.add_child(_stat_line("SELL VALUE",
			"%s SILVER" % UiParts.money(_sell_value())))

func _mk_label(key: String, mk: int, lv: int) -> String:
	if GameState.upgrade_class(key) == GameState.UpgradeClass.STANDARD:
		return "MK%d · LV%d" % [mk, lv]
	return "LV%d" % lv

func _sell_value() -> int:
	# WR sells weapons at 40% of the store price, silver only.
	return int(roundi(GameState.weapon_buy_cost(_item) * 0.4))

func _stat_line(caption: String, value: String) -> HBoxContainer:
	var row := UiParts.hbox(8.0)
	# Godot uniquifies duplicate sibling names, so number them explicitly
	# (smoke and tools count them with a StatLine* glob).
	row.name = "StatLine%d" % _stat_index
	_stat_index += 1
	var caption_label := UiParts.label(caption, 13, UiTheme.MUTED)
	caption_label.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	row.add_child(caption_label)
	var value_label := UiParts.label(value, 14, UiTheme.TEXT, true)
	row.add_child(value_label)
	return row

func _num(value: float, decimals: int) -> String:
	return ("%." + str(decimals) + "f") % value

func _can_afford() -> bool:
	var cost := GameState.weapon_buy_cost(_item)
	if GameState.weapon_buy_currency(_item) == "plat":
		return GameState.platinum >= cost
	return GameState.silver >= cost

func _buy_label() -> String:
	var cost := GameState.weapon_buy_cost(_item)
	if GameState.weapon_buy_currency(_item) == "plat":
		return "BUY  %s PT" % UiParts.money(cost)
	return "BUY  %s SILVER" % UiParts.money(cost)

# ---------------------------------------------------------------- actions

func _equip_pressed() -> void:
	if GameState.equip_item(_robot, _slot, _item):
		manager.toast("%s MOUNTED" % _item)
		manager.refresh()
	else:
		manager.toast("CAN'T MOUNT THAT WEAPON", true)

func _buy_pressed() -> void:
	if GameState.buy_item(_item):
		manager.toast("%s PURCHASED" % _item)
		manager.refresh()
	else:
		manager.toast("NOT ENOUGH FUNDS", true)

func _upgrade_pressed() -> void:
	manager.push(&"upgrade", {
		"key": GameState.upgrade_key(_robot, _slot),
		"is_body": false,
		"slot": _slot,
	})
