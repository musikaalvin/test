class_name SettingsScreen
extends UiScreen

# Settings workspace: look / audio / gameplay / system rows in one full-
# screen column. Ported from the old centred SettingsPanel — same control
# names and handlers, laid out as a stack screen per the hierarchy rule.

var _sens_caption: Label
var _vol_caption: Label
var _music_caption: Label
var _dz_left_caption: Label
var _dz_right_caption: Label
var _controls_button: Button
var _graphics_button: Button
var _priority_button: Button

func _build() -> void:
	add_child(UiParts.backdrop(0.97))
	_build_header()
	_build_body()

func _build_header() -> void:
	var header := Control.new()
	header.name = "Header"
	header.anchor_left = 0.0
	header.anchor_top = 0.0
	header.anchor_right = 1.0
	header.anchor_bottom = 0.0
	header.offset_left = 18.0
	header.offset_top = 64.0
	header.offset_right = -18.0
	header.offset_bottom = 112.0
	header.mouse_filter = Control.MOUSE_FILTER_PASS
	add_child(header)

	var row := UiParts.header_row("SETTINGS", back)
	row.anchor_left = 0.0
	row.anchor_top = 0.0
	row.anchor_right = 1.0
	row.anchor_bottom = 1.0
	header.add_child(row)
	var title := row.get_node_or_null("ScreenTitle") as Label
	if title != null:
		title.size_flags_horizontal = Control.SIZE_EXPAND_FILL
		title.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER

func _build_body() -> void:
	var margin := MarginContainer.new()
	margin.name = "SettingsMargin"
	margin.anchor_left = 0.0
	margin.anchor_top = 0.0
	margin.anchor_right = 1.0
	margin.anchor_bottom = 1.0
	margin.offset_left = 240.0
	margin.offset_top = 124.0
	margin.offset_right = -240.0
	margin.offset_bottom = -20.0
	margin.add_theme_constant_override("margin_left", 0)
	margin.add_theme_constant_override("margin_right", 0)
	margin.add_theme_constant_override("margin_top", 0)
	margin.add_theme_constant_override("margin_bottom", 0)
	margin.mouse_filter = Control.MOUSE_FILTER_PASS
	add_child(margin)

	var scroll := UiParts.scroll()
	scroll.name = "SettingsScroll"
	margin.add_child(scroll)
	var column := UiParts.vbox(10.0)
	column.name = "SettingsBody"
	column.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	scroll.add_child(column)

	column.add_child(_section("LOOK", "Section_LOOK"))
	_sens_caption = UiParts.label("", 14, UiTheme.TEXT)
	_sens_caption.name = "SensitivityCaption"
	column.add_child(_sens_caption)
	var sens_slider := HSlider.new()
	sens_slider.name = "SensitivitySlider"
	sens_slider.min_value = 0.3
	sens_slider.max_value = 2.5
	sens_slider.step = 0.05
	sens_slider.value = GameState.look_sensitivity
	sens_slider.custom_minimum_size = Vector2(0.0, 30.0)
	UiTheme.style_slider(sens_slider, UiTheme.CYAN)
	sens_slider.value_changed.connect(_on_sensitivity_changed)
	column.add_child(sens_slider)

	# Analog sticks: one radial deadzone per stick, 0.05 .. 0.30.
	column.add_child(_section("CONTROLLER", "Section_CONTROLLER"))
	_dz_left_caption = UiParts.label("", 14, UiTheme.TEXT)
	_dz_left_caption.name = "DeadzoneLeftCaption"
	column.add_child(_dz_left_caption)
	var dz_left := HSlider.new()
	dz_left.name = "DeadzoneLeftSlider"
	dz_left.min_value = GameState.DEADZONE_MIN
	dz_left.max_value = GameState.DEADZONE_MAX
	dz_left.step = 0.01
	dz_left.value = GameState.pad_deadzone_left
	dz_left.custom_minimum_size = Vector2(0.0, 30.0)
	UiTheme.style_slider(dz_left, UiTheme.AMBER)
	dz_left.value_changed.connect(_on_deadzone_left_changed)
	column.add_child(dz_left)
	_dz_right_caption = UiParts.label("", 14, UiTheme.TEXT)
	_dz_right_caption.name = "DeadzoneRightCaption"
	column.add_child(_dz_right_caption)
	var dz_right := HSlider.new()
	dz_right.name = "DeadzoneRightSlider"
	dz_right.min_value = GameState.DEADZONE_MIN
	dz_right.max_value = GameState.DEADZONE_MAX
	dz_right.step = 0.01
	dz_right.value = GameState.pad_deadzone_right
	dz_right.custom_minimum_size = Vector2(0.0, 30.0)
	UiTheme.style_slider(dz_right, UiTheme.AMBER)
	dz_right.value_changed.connect(_on_deadzone_right_changed)
	column.add_child(dz_right)

	column.add_child(_section("AUDIO", "Section_AUDIO"))
	_vol_caption = UiParts.label("", 14, UiTheme.TEXT)
	_vol_caption.name = "VolumeCaption"
	column.add_child(_vol_caption)
	var vol_slider := HSlider.new()
	vol_slider.name = "VolumeSlider"
	vol_slider.min_value = 0.0
	vol_slider.max_value = 1.0
	vol_slider.step = 0.01
	vol_slider.value = GameState.master_volume
	vol_slider.custom_minimum_size = Vector2(0.0, 30.0)
	UiTheme.style_slider(vol_slider, UiTheme.AMBER)
	vol_slider.value_changed.connect(_on_volume_changed)
	column.add_child(vol_slider)
	_music_caption = UiParts.label("", 14, UiTheme.TEXT)
	_music_caption.name = "MusicCaption"
	column.add_child(_music_caption)
	var music_slider := HSlider.new()
	music_slider.name = "MusicSlider"
	music_slider.min_value = 0.0
	music_slider.max_value = 1.0
	music_slider.step = 0.01
	music_slider.value = GameState.music_volume
	music_slider.custom_minimum_size = Vector2(0.0, 30.0)
	UiTheme.style_slider(music_slider, UiTheme.CYAN)
	music_slider.value_changed.connect(_on_music_changed)
	column.add_child(music_slider)

	column.add_child(_section("GAMEPLAY", "Section_GAMEPLAY"))
	column.add_child(_check("InvertYCheck", "INVERT LOOK Y",
			GameState.invert_look_y, _on_invert_toggled))
	column.add_child(_check("DamageNumbersCheck", "DAMAGE NUMBERS",
			GameState.damage_numbers, _on_damage_numbers_toggled))
	column.add_child(_check("FpsCounterCheck", "FPS COUNTER",
			GameState.fps_counter, _on_fps_toggled))
	column.add_child(_check("VibrationCheck", "VIBRATION",
			GameState.vibration_enabled, _on_vibration_toggled))
	_priority_button = UiParts.button("", UiTheme.CYAN, 15,
			Vector2(0.0, 44.0))
	_priority_button.name = "TargetPriorityButton"
	UiParts.wire(_priority_button, _on_target_priority_pressed)
	column.add_child(_priority_button)

	column.add_child(_section("SYSTEM", "Section_SYSTEM"))
	var diagnostics_check := _check("InputDiagnosticsCheck", "INPUT DIAGNOSTICS",
			GameState.input_diagnostics, _on_input_diagnostics_toggled)
	column.add_child(diagnostics_check)
	var system_row := UiParts.hbox(10.0)
	system_row.name = "SettingsSystemRow"
	column.add_child(system_row)
	_controls_button = UiParts.button("", UiTheme.CYAN, 15,
			Vector2(0.0, 44.0))
	_controls_button.name = "ControlsModeButton"
	_controls_button.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	UiParts.wire(_controls_button, _on_controls_mode_pressed)
	system_row.add_child(_controls_button)
	_graphics_button = UiParts.button("", UiTheme.CYAN, 15,
			Vector2(0.0, 44.0))
	_graphics_button.name = "GraphicsSettingButton"
	_graphics_button.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	UiParts.wire(_graphics_button, _on_graphics_pressed)
	system_row.add_child(_graphics_button)

	var exit_button := UiParts.button("EXIT GAME", UiTheme.DANGER, 16,
			Vector2(0.0, 48.0))
	exit_button.name = "ExitGameButton"
	UiParts.wire(exit_button, _on_exit_pressed)
	column.add_child(exit_button)

	var close_button := UiParts.button("CLOSE", UiTheme.CYAN, 16,
			Vector2(0.0, 48.0))
	close_button.name = "CloseSettingsButton"
	UiParts.wire(close_button, back)
	column.add_child(close_button)

func _section(text: String, node_name: String) -> Label:
	var label := UiParts.section(text)
	label.name = node_name
	return label

func _check(check_name: String, text: String, pressed: bool,
		handler: Callable) -> CheckBox:
	var check := CheckBox.new()
	check.name = check_name
	check.text = text
	check.button_pressed = pressed
	check.add_theme_font_size_override("font_size", 16)
	check.add_theme_color_override("font_color", UiTheme.TEXT)
	check.toggled.connect(handler)
	return check

# ---------------------------------------------------------------- handlers

func _on_sensitivity_changed(value: float) -> void:
	GameState.set_look_sensitivity(value)
	_refresh_captions()

func _on_deadzone_left_changed(value: float) -> void:
	GameState.set_pad_deadzone_left(value)
	_refresh_captions()

func _on_deadzone_right_changed(value: float) -> void:
	GameState.set_pad_deadzone_right(value)
	_refresh_captions()

func _on_input_diagnostics_toggled(toggled_on: bool) -> void:
	GameState.set_input_diagnostics(toggled_on)

func _on_volume_changed(value: float) -> void:
	GameState.set_master_volume(value)
	_refresh_captions()

func _on_music_changed(value: float) -> void:
	GameState.set_music_volume(value)
	_refresh_captions()

func _on_invert_toggled(toggled_on: bool) -> void:
	GameState.set_invert_look(toggled_on)

func _on_damage_numbers_toggled(toggled_on: bool) -> void:
	GameState.set_damage_numbers(toggled_on)

func _on_fps_toggled(toggled_on: bool) -> void:
	GameState.set_fps_counter(toggled_on)

func _on_vibration_toggled(toggled_on: bool) -> void:
	GameState.set_vibration_enabled(toggled_on)

func _on_target_priority_pressed() -> void:
	GameState.cycle_target_priority()
	_refresh_captions()

func _on_controls_mode_pressed() -> void:
	GameState.cycle_input_ui_mode()
	PlatformUtil.refresh_settings()	# force-emits mode_changed -> labels refresh
	_refresh_captions()

func _on_graphics_pressed() -> void:
	GameState.cycle_graphics()
	Quality.apply_viewport(get_viewport())
	_refresh_captions()

func _on_exit_pressed() -> void:
	if manager != null:
		manager.request_quit()

# ----------------------------------------------------------------- refresh

func refresh() -> void:
	if _sens_caption == null:
		return
	_refresh_captions()

func _refresh_captions() -> void:
	_sens_caption.text = "LOOK SENSITIVITY  %.2f" % GameState.look_sensitivity
	_dz_left_caption.text = "LEFT STICK DEADZONE  %.2f" % GameState.pad_deadzone_left
	_dz_right_caption.text = "RIGHT STICK DEADZONE  %.2f" % GameState.pad_deadzone_right
	_vol_caption.text = "MASTER VOLUME  %d%%" % roundi(GameState.master_volume * 100.0)
	_music_caption.text = "MUSIC VOLUME  %d%%" % roundi(GameState.music_volume * 100.0)
	_controls_button.text = "CONTROLS: %s" % GameState.input_ui_mode_label()
	_graphics_button.text = "GRAPHICS: %s" % Quality.tier_label()
	_priority_button.text = "TARGET PRIORITY: %s" % GameState.target_priority_label()
