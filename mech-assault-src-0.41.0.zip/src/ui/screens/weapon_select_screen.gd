class_name WeaponSelectScreen
extends UiScreen

# Per-slot weapon catalogue: everything of the slot's size you own sits
# in STORAGE, everything you don't own yet sits in the STORE tab. Rows
# open the detail screen; EQUIP/BUY act in place.

const TAB_STORAGE := 0
const TAB_STORE := 1
const ROW_HEIGHT := 96.0
const SHEET_WIDTH := 332.0

var _title: Label
var _robot: StringName = &""
var _slot: int = 0
var _tab: int = TAB_STORAGE
var _tab_storage: Button
var _tab_store: Button
var _list: VBoxContainer
var _empty_label: Label
var _selected_item: String = ""
var _sheet: Panel
var _sheet_preview: ItemPreview
var _sheet_name: Label
var _sheet_class: Label
var _sheet_rows: VBoxContainer
var _sheet_state: Label
var _sheet_note: Label

func _build() -> void:
	add_child(UiParts.backdrop(0.97))
	_build_header()
	_build_tabs()
	_build_list()
	_build_stat_sheet()

func _build_header() -> void:
	var header := Control.new()
	header.name = "Header"
	header.anchor_left = 0.0
	header.anchor_top = 0.0
	header.anchor_right = 1.0
	header.anchor_bottom = 0.0
	header.offset_left = 18.0
	header.offset_top = 64.0
	header.offset_right = -18.0
	header.offset_bottom = 112.0
	header.mouse_filter = Control.MOUSE_FILTER_PASS
	add_child(header)

	var row := UiParts.header_row("SELECT WEAPON", back)
	row.anchor_left = 0.0
	row.anchor_top = 0.0
	row.anchor_right = 1.0
	row.anchor_bottom = 1.0
	header.add_child(row)
	_title = row.get_node_or_null("ScreenTitle") as Label

func _build_tabs() -> void:
	# WR-style: tabs right-aligned in the same band as the back/title row.
	var tabs := UiParts.hbox(8.0)
	tabs.name = "Tabs"
	tabs.anchor_left = 1.0
	tabs.anchor_top = 0.0
	tabs.anchor_right = 1.0
	tabs.anchor_bottom = 0.0
	tabs.offset_left = -366.0
	tabs.offset_top = 66.0
	tabs.offset_right = -18.0
	tabs.offset_bottom = 132.0
	tabs.mouse_filter = Control.MOUSE_FILTER_PASS
	add_child(tabs)

	_tab_storage = UiParts.button("INVENTORY", UiTheme.CYAN, 14,
			Vector2(170.0, 44.0))
	_tab_storage.name = "TabStorage"
	UiParts.wire(_tab_storage, _select_tab.bind(TAB_STORAGE))
	tabs.add_child(_tab_storage)

	_tab_store = UiParts.button("TO STORE", UiTheme.AMBER, 14,
			Vector2(170.0, 44.0))
	_tab_store.name = "TabStore"
	UiParts.wire(_tab_store, _select_tab.bind(TAB_STORE))
	tabs.add_child(_tab_store)

func _build_list() -> void:
	var panel := Panel.new()
	panel.name = "ListPanel"
	panel.anchor_left = 0.0
	panel.anchor_top = 0.0
	panel.anchor_right = 1.0
	panel.anchor_bottom = 1.0
	panel.offset_left = 18.0
	panel.offset_top = 141.0
	panel.offset_right = -(SHEET_WIDTH + 24.0)
	panel.offset_bottom = -18.0
	panel.add_theme_stylebox_override("panel", UiTheme.panel(0.88))
	add_child(panel)

	var scroll := UiParts.scroll()
	scroll.name = "ListScroll"
	scroll.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	scroll.offset_left = 14.0
	scroll.offset_top = 14.0
	scroll.offset_right = -14.0
	scroll.offset_bottom = -14.0
	panel.add_child(scroll)

	_list = UiParts.vbox(8.0)
	_list.name = "ItemRows"
	_list.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	scroll.add_child(_list)

	_empty_label = UiParts.label("", 15, UiTheme.MUTED)
	_empty_label.name = "EmptyLabel"
	_empty_label.visible = false
	_list.add_child(_empty_label)

func _build_stat_sheet() -> void:
	var sheet := Panel.new()
	sheet.name = "StatSheet"
	sheet.anchor_left = 1.0
	sheet.anchor_top = 0.0
	sheet.anchor_right = 1.0
	sheet.anchor_bottom = 1.0
	sheet.offset_left = -(SHEET_WIDTH + 18.0)
	sheet.offset_top = 141.0
	sheet.offset_right = -18.0
	sheet.offset_bottom = -18.0
	sheet.add_theme_stylebox_override("panel", UiTheme.panel(0.9, UiTheme.AMBER))
	add_child(sheet)
	_sheet = sheet

	var scroll := UiParts.scroll()
	scroll.name = "SheetScroll"
	scroll.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	scroll.offset_left = 14.0
	scroll.offset_top = 12.0
	scroll.offset_right = -14.0
	scroll.offset_bottom = -12.0
	sheet.add_child(scroll)

	var column := UiParts.vbox(8.0)
	column.name = "SheetColumn"
	column.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	scroll.add_child(column)

	_sheet_preview = ItemPreview.new()
	_sheet_preview.name = "SheetPreview"
	_sheet_preview.custom_minimum_size = Vector2(160.0, 110.0)
	_sheet_preview.size_flags_vertical = Control.SIZE_SHRINK_CENTER
	_sheet_preview.mouse_filter = Control.MOUSE_FILTER_IGNORE
	column.add_child(_sheet_preview)

	_sheet_name = UiParts.label("", 19, UiTheme.TEXT, true)
	_sheet_name.name = "SheetName"
	column.add_child(_sheet_name)
	_sheet_class = UiParts.label("", 12, UiTheme.MUTED)
	_sheet_class.name = "SheetClass"
	column.add_child(_sheet_class)
	column.add_child(UiParts.divider())

	_sheet_rows = UiParts.vbox(6.0)
	_sheet_rows.name = "SheetStatRows"
	_sheet_rows.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	column.add_child(_sheet_rows)
	column.add_child(UiParts.divider())

	_sheet_state = UiParts.label("", 14, UiTheme.AMBER, true)
	_sheet_state.name = "SheetState"
	column.add_child(_sheet_state)
	_sheet_note = UiParts.label("", 12, UiTheme.MUTED)
	_sheet_note.name = "SheetNote"
	_sheet_note.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	column.add_child(_sheet_note)

func open(params: Dictionary = {}) -> void:
	_robot = params.get("robot", GameState.selected_robot) as StringName
	_slot = int(params.get("slot", 0))
	_tab = TAB_STORAGE
	_selected_item = ""

func on_enter() -> void:
	refresh()

func refresh() -> void:
	if _title == null:
		return
	if _robot == &"":
		_robot = GameState.selected_robot
	var size_kind := GameState.slot_size(_robot, _slot)
	var size_label := GameState.SLOT_LABELS[size_kind]
	var robot_name := String(GameState.robot_def(_robot).get("name", ""))
	_title.text = "SELECT WEAPON  //  %s · %s SLOT %d" % [
			robot_name, size_label, _slot + 1]
	_tab_storage.add_theme_stylebox_override("normal",
			_tab_style(_tab == TAB_STORAGE, UiTheme.CYAN))
	_tab_store.add_theme_stylebox_override("normal",
			_tab_style(_tab == TAB_STORE, UiTheme.AMBER))
	_rebuild_rows()

func _tab_style(active: bool, accent: Color) -> StyleBoxFlat:
	var style := UiTheme.button_normal(accent)
	if active:
		style = UiTheme.glow_frame(accent, 2)
	return style

func _select_tab(tab: int) -> void:
	_tab = tab
	refresh()

# ------------------------------------------------------------------ rows

func _rebuild_rows() -> void:
	for child in _list.get_children():
		if child == _empty_label:
			continue
		_list.remove_child(child)
		child.queue_free()

	var wanted := GameState.slot_size(_robot, _slot)
	var current := GameState.equipped_item(_robot, _slot)
	var items: Array[String] = []
	for item_id in _matching_items(wanted):
		if _tab == TAB_STORAGE:
			if item_id == current or GameState.free_copies(item_id) > 0:
				items.append(item_id)
		else:
			if GameState.pool_count(item_id) == 0:
				items.append(item_id)

	if items.is_empty():
		_empty_label.visible = true
		_selected_item = ""
		if _tab == TAB_STORAGE:
			_empty_label.text = "NO WEAPONS FOR THIS SLOT YET — VISIT THE STORE"
		else:
			_empty_label.text = "EVERY WEAPON OF THIS SIZE IS OWNED"
		_refresh_sheet()
		return
	_empty_label.visible = false
	if not items.has(_selected_item):
		_selected_item = items[0]

	for item_id in items:
		_list.add_child(_make_row(item_id, item_id == current,
				item_id == _selected_item))
	_refresh_sheet()

func _matching_items(wanted: int) -> Array:
	var found: Array = []
	for item_id in GameState.ALL_ITEM_IDS:
		if GameState.item_slot_size(item_id) == wanted:
			found.append(item_id)
	for item_id in GameState.TITAN_ITEM_IDS:
		if GameState.item_slot_size(item_id) == wanted:
			found.append(item_id)
	found.sort()
	return found

func _make_row(item_id: String, is_current: bool, is_selected: bool) -> Panel:
	var row := Panel.new()
	row.name = "WeaponRow_%s" % item_id
	row.custom_minimum_size = Vector2(0.0, ROW_HEIGHT)
	row.add_theme_stylebox_override("panel", _row_style(is_selected))
	row.gui_input.connect(_on_row_input.bind(item_id))

	var layout := UiParts.hbox(14.0)
	layout.name = "RowLayout"
	layout.anchor_left = 0.0
	layout.anchor_top = 0.0
	layout.anchor_right = 1.0
	layout.anchor_bottom = 1.0
	layout.offset_left = 14.0
	layout.offset_top = 8.0
	layout.offset_right = -14.0
	layout.offset_bottom = -8.0
	row.add_child(layout)

	var preview := ItemPreview.new()
	preview.name = "RowPreview"
	preview.custom_minimum_size = Vector2(112.0, 76.0)
	preview.size_flags_vertical = Control.SIZE_SHRINK_CENTER
	preview.set_weapon(item_id)
	preview.mouse_filter = Control.MOUSE_FILTER_IGNORE
	layout.add_child(preview)

	var column := UiParts.vbox(2.0)
	column.name = "RowText"
	column.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	column.size_flags_vertical = Control.SIZE_SHRINK_CENTER
	column.mouse_filter = Control.MOUSE_FILTER_IGNORE
	layout.add_child(column)
	var name_label := UiParts.label(GameState.item_display_name(item_id), 17,
			UiTheme.TEXT, true)
	name_label.name = "RowName"
	column.add_child(name_label)
	var class_text := GameState.item_class_label(item_id)
	if _tab == TAB_STORAGE:
		class_text += "  ·  OWNED ×%d" % GameState.pool_count(item_id)
	var class_label := UiParts.label(class_text, 11, UiTheme.MUTED)
	class_label.name = "RowClass"
	column.add_child(class_label)
	var stat_label := UiParts.label(_stat_line(item_id), 12, UiTheme.AMBER)
	stat_label.name = "RowStat"
	column.add_child(stat_label)

	var action: Button
	if _tab == TAB_STORAGE:
		if is_current:
			action = UiParts.button("EQUIPPED", UiTheme.HEALTH, 14,
					Vector2(136.0, 52.0))
			action.disabled = true
		else:
			action = UiParts.button("EQUIP", UiTheme.CYAN, 15,
					Vector2(136.0, 52.0))
			UiParts.wire(action, _equip_item.bind(item_id))
	else:
		var currency := GameState.weapon_buy_currency(item_id)
		var cost := GameState.weapon_buy_cost(item_id)
		var currency_label := "PT" if currency == "plat" else "SILVER"
		action = UiParts.button("BUY  %s" % _grouped(cost, currency_label),
				UiTheme.AMBER, 14, Vector2(200.0, 52.0))
		var affordable := GameState.platinum >= cost if currency == "plat" \
				else GameState.silver >= cost
		if not affordable:
			action.add_theme_color_override("font_color", UiTheme.MUTED)
		UiParts.wire(action, _buy_item.bind(item_id))
	action.name = "RowAction"
	action.size_flags_vertical = Control.SIZE_SHRINK_CENTER
	layout.add_child(action)
	# Plain Panel: size the row to its tallest column so RowStat and the
	# action button never hang below the row's background.
	row.custom_minimum_size.y = maxf(ROW_HEIGHT,
			column.get_combined_minimum_size().y + 16.0)
	return row

func _tab_accent() -> Color:
	return UiTheme.AMBER if _tab == TAB_STORE else UiTheme.CYAN

func _row_style(is_selected: bool) -> StyleBoxFlat:
	if is_selected:
		return UiTheme.glow_frame(_tab_accent(), 2)
	return UiTheme.panel(0.82, _tab_accent())

# Restyle rows in place (never free — this runs inside a row's own
# gui_input signal) after the selection changes.
func _restyle_rows() -> void:
	for child in _list.get_children():
		var child_name := String(child.name)
		if not child_name.begins_with("WeaponRow_"):
			continue
		var row_id := child_name.trim_prefix("WeaponRow_")
		(child as Panel).add_theme_stylebox_override("panel",
				_row_style(row_id == _selected_item))

# ------------------------------------------------------------------ sheet

func _refresh_sheet() -> void:
	if _sheet == null:
		return
	if _selected_item.is_empty():
		_sheet.visible = false
		return
	_sheet.visible = true
	_sheet_preview.set_weapon(_selected_item)
	_sheet_name.text = GameState.item_display_name(_selected_item)
	_sheet_class.text = GameState.item_class_label(_selected_item)
	for child in _sheet_rows.get_children():
		_sheet_rows.remove_child(child)
		child.queue_free()
	var weapon := GameState.weapon_for_item(_selected_item) as WeaponData
	if weapon == null:
		_sheet_state.text = ""
		_sheet_note.text = ""
		return
	var dps := weapon.damage * weapon.pellets * weapon.shots_per_minute / 60.0
	var stats: Array = [
		["DAMAGE", GameState.fmt_amount(weapon.damage * weapon.pellets)],
		["RATE", "%d RPM" % int(weapon.shots_per_minute)],
		["DPS", GameState.fmt_amount(dps)],
		["RANGE", "%d M" % int(round(_range_of(weapon)))],
		["SPREAD", "%.1f°" % weapon.spread_degrees],
	]
	var special := _special_line(weapon)
	if not special.is_empty():
		stats.append(["SPECIAL", special])
	for index in stats.size():
		var stat: Array = stats[index]
		var row := UiParts.hbox(8.0)
		row.name = "SheetStat%d" % index
		row.size_flags_horizontal = Control.SIZE_EXPAND_FILL
		var caption := UiParts.label(String(stat[0]), 13, UiTheme.MUTED)
		caption.size_flags_horizontal = Control.SIZE_EXPAND_FILL
		row.add_child(caption)
		var value := UiParts.label(String(stat[1]), 13, UiTheme.AMBER, true)
		value.horizontal_alignment = HORIZONTAL_ALIGNMENT_RIGHT
		row.add_child(value)
		_sheet_rows.add_child(row)
	_sheet_state.text = _state_text()
	_sheet_note.text = "TAP THE SELECTED ROW AGAIN FOR THE FULL SHEET"

func _range_of(weapon: WeaponData) -> float:
	if weapon.kind == WeaponData.Kind.BEAM:
		return weapon.beam_range
	return weapon.projectile_speed * weapon.projectile_lifetime

func _special_line(weapon: WeaponData) -> String:
	var parts: Array[String] = []
	if weapon.pellets > 1:
		parts.append("×%d PELLETS" % weapon.pellets)
	if weapon.splash_radius > 0.0:
		parts.append("SPLASH %.1f M" % weapon.splash_radius)
	if weapon.corrosion_dps > 0.0:
		parts.append("CORRODE %d/S" % int(round(weapon.corrosion_dps)))
	if weapon.chain_bounces > 0:
		parts.append("CHAIN ×%d" % weapon.chain_bounces)
	if weapon.magazine > 0:
		parts.append("MAG %d" % weapon.magazine)
	if weapon.hull_fraction >= 1.0:
		parts.append("HULL DMG")
	var line := ""
	for index in parts.size():
		if index > 0:
			line += "  ·  "
		line += parts[index]
	return line

func _state_text() -> String:
	if _tab == TAB_STORE:
		var currency := GameState.weapon_buy_currency(_selected_item)
		var cost := GameState.weapon_buy_cost(_selected_item)
		var suffix := "PT" if currency == "plat" else "SILVER"
		return "IN THE STORE  ·  %s %s" % [UiParts.money(cost), suffix]
	var current := GameState.equipped_item(_robot, _slot)
	if _selected_item == current:
		return "EQUIPPED IN SLOT %d" % (_slot + 1)
	var spares := GameState.free_copies(_selected_item)
	if spares > 0:
		return "IN STORAGE  ·  ×%d SPARE" % spares
	return "MOUNTED ELSEWHERE"

func _stat_line(item_id: String) -> String:
	var weapon := GameState.weapon_for_item(item_id) as WeaponData
	if weapon == null:
		return ""
	var dps := weapon.damage * weapon.pellets * weapon.shots_per_minute / 60.0
	var line := "DMG %s · RPM %d · DPS %s" % [
			GameState.fmt_amount(weapon.damage * weapon.pellets),
			int(weapon.shots_per_minute),
			GameState.fmt_amount(dps)]
	if weapon.splash_radius > 0.0:
		line += " · SPLASH %.1f M" % weapon.splash_radius
	if weapon.pellets > 1:
		line += " · ×%d PELLETS" % weapon.pellets
	if weapon.magazine > 0:
		line += " · MAG %d" % weapon.magazine
	return line

func _grouped(value: int, suffix: String) -> String:
	return "%s %s" % [UiParts.money(value), suffix]

# ---------------------------------------------------------------- actions

func _on_row_input(event: InputEvent, item_id: String) -> void:
	if event is InputEventMouseButton:
		var mouse := event as InputEventMouseButton
		if mouse.pressed and mouse.button_index == MOUSE_BUTTON_LEFT:
			if item_id != _selected_item:
				# First tap selects the row and fills the stat sheet;
				# tapping the selected row again drills into the detail.
				_selected_item = item_id
				_restyle_rows()
				_refresh_sheet()
			else:
				manager.push(&"weapon_detail", {
					"item": item_id,
					"robot": _robot,
					"slot": _slot,
					"tab": _tab,
				})

func _equip_item(item_id: String) -> void:
	if GameState.equip_item(_robot, _slot, item_id):
		manager.toast("%s MOUNTED" % GameState.item_display_name(item_id))
		manager.refresh()
	else:
		manager.toast("CAN'T MOUNT THAT WEAPON", true)

func _buy_item(item_id: String) -> void:
	if GameState.buy_item(item_id):
		manager.toast("%s PURCHASED — NOW IN STORAGE" % item_id)
		refresh()
	else:
		var currency := GameState.weapon_buy_currency(item_id)
		if currency == "plat":
			manager.toast("NOT ENOUGH PLATINUM", true)
		else:
			manager.toast("NOT ENOUGH SILVER", true)
