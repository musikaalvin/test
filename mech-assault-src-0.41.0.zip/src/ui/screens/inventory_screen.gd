class_name InventoryScreen
extends UiScreen

# What you already own: robots split into ON THE BAY / IN STORAGE, plus
# the weapon storage with stock counts. Ported from the old InventoryPopup
# — section labels, page names and card behaviour kept.

var _tab: int = 0
var _tab_buttons: Array[Button] = []
var _pages: Array[ScrollContainer] = []
var _robot_rows: VBoxContainer
var _weapon_rows_box: VBoxContainer
var _wallet: Label
var _items: Array[String] = []

func _build() -> void:
	add_child(UiParts.backdrop(0.97))
	_build_header()
	_build_body()

func _build_header() -> void:
	var header := Control.new()
	header.name = "Header"
	header.anchor_left = 0.0
	header.anchor_top = 0.0
	header.anchor_right = 1.0
	header.anchor_bottom = 0.0
	header.offset_left = 18.0
	header.offset_top = 64.0
	header.offset_right = -18.0
	header.offset_bottom = 112.0
	header.mouse_filter = Control.MOUSE_FILTER_PASS
	add_child(header)

	var row := UiParts.header_row("INVENTORY", back)
	row.anchor_left = 0.0
	row.anchor_top = 0.0
	row.anchor_right = 1.0
	row.anchor_bottom = 1.0
	header.add_child(row)
	var title := row.get_node_or_null("ScreenTitle") as Label
	if title != null:
		title.size_flags_horizontal = Control.SIZE_EXPAND_FILL
		title.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	_wallet = UiParts.label("", 13, UiTheme.MUTED)
	_wallet.name = "InventoryWallet"
	_wallet.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
	row.add_child(_wallet)

func _build_body() -> void:
	var body := UiParts.vbox(7.0)
	body.name = "InventoryBody"
	body.anchor_left = 0.0
	body.anchor_top = 0.0
	body.anchor_right = 1.0
	body.anchor_bottom = 1.0
	body.offset_left = 18.0
	body.offset_top = 124.0
	body.offset_right = -18.0
	body.offset_bottom = -20.0
	body.mouse_filter = Control.MOUSE_FILTER_PASS
	add_child(body)

	var tabs := UiParts.hbox(10.0)
	tabs.name = "InventoryTabs"
	body.add_child(tabs)
	for tab_index in 2:
		var tab_button := UiParts.button(
				"ROBOTS" if tab_index == 0 else "WEAPONS",
				UiTheme.CYAN, 15, Vector2(170.0, 40.0))
		tab_button.name = "InvTabRobots" if tab_index == 0 \
				else "InvTabWeapons"
		UiParts.wire(tab_button, _on_tab_pressed.bind(tab_index))
		tabs.add_child(tab_button)
		_tab_buttons.append(tab_button)

	for page_index in 2:
		var page := UiParts.scroll()
		page.name = "InvRobotScroll" if page_index == 0 \
				else "InvWeaponScroll"
		page.visible = page_index == 0
		body.add_child(page)
		var rows := UiParts.vbox(8.0)
		rows.name = "InvRobotRows" if page_index == 0 else "InvWeaponRows"
		rows.size_flags_horizontal = Control.SIZE_EXPAND_FILL
		page.add_child(rows)
		_pages.append(page)
		if page_index == 0:
			_robot_rows = rows
		else:
			_weapon_rows_box = rows
	_apply_tab()

# ----------------------------------------------------------------- actions

func _on_tab_pressed(tab: int) -> void:
	_tab = clampi(tab, 0, _tab_buttons.size() - 1)
	_apply_tab()

func _apply_tab() -> void:
	for index in _pages.size():
		_pages[index].visible = index == _tab
	for index in _tab_buttons.size():
		UiTheme.apply_to_button(_tab_buttons[index],
				UiTheme.CYAN if index == _tab else UiTheme.STEEL, 15)

func _on_robot_action(robot_id: StringName) -> void:
	ItemCards.robot_action(robot_id, manager)

func _on_weapon_equip(item_id: String) -> void:
	var robot_id := GameState.selected_robot
	var slots := GameState.robot_slots(robot_id)
	var loadout := GameState.loadouts.get(robot_id, []) as Array
	var target := -1
	for index in slots.size():
		if GameState.item_slot_size(item_id) != slots[index]:
			continue
		var current := ""
		if index < loadout.size():
			current = String(loadout[index])
		if current == item_id:
			manager.toast("%s ALREADY MOUNTED" % item_id)
			return
		if current.is_empty() and target < 0:
			target = index
	if target < 0:
		for index in slots.size():
			if GameState.item_slot_size(item_id) == slots[index]:
				target = index
				break
	if target < 0:
		manager.toast("NO FITTING SLOT ON %s" % String(
				GameState.robot_def(robot_id).get("name", "MECH")), true)
		return
	if GameState.equip_item(robot_id, target, item_id):
		var hangar := manager.screen(&"hangar")
		if hangar != null and hangar.has_method("rebuild_bay"):
			hangar.call("rebuild_bay")
		manager.toast("%s MOUNTED" % item_id)
	else:
		manager.toast("NO FREE COPY OF %s" % item_id, true)
	manager.refresh()

# ----------------------------------------------------------------- refresh

func refresh() -> void:
	if _wallet == null:
		return
	_wallet.text = "SILVER  %s   ·   GOLD  %s   ·   PLATINUM  %d" % [
			UiParts.money(GameState.silver), UiParts.money(GameState.gold),
			GameState.platinum]
	_items.clear()
	for item_id in GameState.ALL_ITEM_IDS:
		_items.append(item_id)
	for item_id in GameState.TITAN_ITEM_IDS:
		_items.append(item_id)
	_rebuild(_robot_rows, _robot_cards())
	_rebuild(_weapon_rows_box, _weapon_cards())
	_apply_tab()

func _robot_cards() -> Array:
	var cards: Array = []
	var assignment := HangarSlots.assignment()
	cards.append(_section("ON THE BAY", "Section_ONTHEBAY"))
	for robot_id in GameState.ROBOT_ORDER:
		if GameState.owns_robot(robot_id) and assignment.has(robot_id):
			cards.append(ItemCards.robot_card(robot_id, true,
					_on_robot_action.bind(robot_id), manager))
	var storage: Array[StringName] = []
	for robot_id in GameState.ROBOT_ORDER:
		if GameState.owns_robot(robot_id) and not assignment.has(robot_id):
			storage.append(robot_id)
	if not storage.is_empty():
		cards.append(_section("IN STORAGE", "Section_INSTORAGE"))
		for robot_id in storage:
			cards.append(ItemCards.robot_card(robot_id, true,
					_on_robot_action.bind(robot_id), manager))
	return cards

func _weapon_cards() -> Array:
	var cards: Array = []
	cards.append(_section("WEAPON STORAGE", "Section_WEAPONSTORAGE"))
	for item_id in _items:
		if GameState.pool_count(item_id) > 0:
			cards.append(ItemCards.weapon_card(item_id, true,
					_on_weapon_equip.bind(item_id), manager))
	return cards

func _section(text: String, node_name: String) -> Label:
	var label := UiParts.section(text)
	label.name = node_name
	return label

# Unlink before free so a rebuild inside a card's own pressed signal never
# frees a locked object (same pattern as the pilot roster).
func _rebuild(box: VBoxContainer, cards: Array) -> void:
	for child in box.get_children():
		box.remove_child(child)
		child.queue_free()
	for card in cards:
		box.add_child(card)
