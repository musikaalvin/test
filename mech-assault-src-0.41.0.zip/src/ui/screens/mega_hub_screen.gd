class_name MegaHubScreen
extends UiScreen

# Unified production-style offline meta hub. Pages are data-driven so the same
# screen component can host inventory, social, events, operations and settings
# without duplicating navigation logic or gameplay state.

const PAGE_DEFS: Dictionary = {
	&"settings_general": ["GENERAL SETTINGS", "Core preferences and confirmations.", ["LANGUAGE", "CONFIRM PURCHASES", "TUTORIAL HINTS", "NOTIFICATIONS"]],
	&"settings_controls": ["CONTROL SETTINGS", "Touch, keyboard, mouse and controller mapping.", ["MOVE", "LOOK", "FIRE", "CONTROLLER", "CUSTOMIZE CONTROLS"]],
	&"settings_aiming": ["AIMING SETTINGS", "Targeting and lock-on behavior.", ["AUTO TARGET", "TARGET SWITCH", "AIM ASSIST", "LOCK-ON", "TARGET PRIORITY"]],
	&"settings_battle_hud": ["BATTLE HUD EDITOR", "Safe-zone normalized combat HUD layout.", ["MOVE STICK", "FIRE", "ABILITIES", "TARGET", "RADAR", "HEALTH", "RESET"]],
	&"settings_graphics": ["GRAPHICS SETTINGS", "Quality presets and advanced rendering options.", ["LOW", "MEDIUM", "HIGH", "ULTRA", "ADVANCED"]],
	&"settings_audio": ["AUDIO SETTINGS", "Master, music, SFX, interface, voice and ambience.", ["MASTER", "MUSIC", "SFX", "INTERFACE", "VOICE", "AMBIENCE"]],
	&"settings_accessibility": ["ACCESSIBILITY", "Readability and input assistance.", ["TEXT SCALE", "HIGH CONTRAST", "COLOR ASSIST", "INPUT ASSIST"]],
	&"settings_notifications": ["NOTIFICATIONS", "Choose which local events can interrupt the shell.", ["MISSIONS", "EVENTS", "SOCIAL", "SYSTEM"]],
	&"settings_language": ["LANGUAGE", "Language selection shell.", ["CURRENT LANGUAGE", "APPLY"]],
	&"settings_account": ["ACCOUNT", "Local profile and save information.", ["PROFILE", "SAVE DATA", "RESET / RECOVERY"]],
	&"settings_social_privacy": ["SOCIAL / PRIVACY", "Social visibility and local privacy preferences.", ["PROFILE VISIBILITY", "FRIENDS", "CLAN", "MESSAGES"]],
	&"settings_about": ["ABOUT", "Build, support and legal information.", ["BUILD", "CREDITS", "SUPPORT", "LEGAL"]],
	&"robot_equipment": ["ROBOT EQUIPMENT", "Dedicated robot loadout workspace.", ["WEAPONS", "PILOT", "DRONE", "SPECIALIZATION", "UPGRADE"]],
	&"battle": ["BATTLE", "Combat HUD contract; runtime battle scene owns the actual combat presentation.", ["HEALTH", "AMMO", "ABILITY", "TARGET", "RADAR", "SCORE"]],
	&"battle_robot_select": ["ROBOT SELECTION", "Select only remaining legal robots after destruction.", ["REMAINING ROBOTS", "DEPLOY"]],
	&"battle_pause": ["PAUSE", "Pause or leave-match confirmation shell.", ["RESUME", "SETTINGS", "LEAVE MATCH"]],
	&"reward_claim": ["REWARD CLAIM", "Claim result and inventory update shell.", ["CLAIM", "CLAIMED"]],
	&"errors": ["CONNECTION / ERROR", "Recoverable loading, offline and connection states.", ["RETRY", "CANCEL", "RETURN TO HANGAR"]],
	&"tutorial": ["FIRST-TIME EXPERIENCE", "Contextual tutorial steps that persist completion state.", ["WELCOME", "BUILD", "BATTLE", "SKIP"]],
	&"confirmation": ["CONFIRMATION", "Reusable action confirmation layer.", ["CONFIRM", "CANCEL"]],
	&"notifications": ["NOTIFICATIONS", "Unread system and gameplay notification center.", ["ALL", "MISSIONS", "EVENTS", "SOCIAL", "SYSTEM"]],
	&"game_modes": ["BATTLE MODES", "Choose an offline combat operation.", ["OPEN REALM SURVIVAL"]],
	&"matchmaking": ["MATCHMAKING", "Offline simulation queue — no server required.", ["STANDARD", "ELITE", "TRAINING"]],
	&"deployment": ["DEPLOYMENT", "Configure the legal battle roster before entering combat.", []],
	&"workshop": ["WORKSHOP", "Crafting, tuning and maintenance bay.", ["MAINTENANCE", "CALIBRATION", "PAINT LAB"]],
	&"collections": ["COLLECTIONS", "Your discovered MECH ASSAULT catalogue.", ["ROBOTS", "TITANS", "WEAPONS", "PILOTS", "DRONES"]],
	&"events": ["EVENT HUB", "Offline event schedule and local progression.", ["SEASONAL OPS", "FRONTLINE", "BLACKOUT"]],
	&"datapads": ["DATA PADS", "Local reward capsules. Rewards are written to your save.", ["STANDARD PAD", "ELITE PAD", "COMMAND PAD"]],
	&"operations": ["OPERATIONS", "A persistent local reward track.", ["OPERATION: IRON SUN", "OPERATION: COLD FRONT"]],
	&"missions": ["MISSIONS / TASKS", "Daily, weekly and special objectives.", ["DAILY", "WEEKLY", "SPECIAL", "ACHIEVEMENTS"]],
	&"leaderboards": ["LEADERBOARDS", "Local career and event rankings.", ["CAREER", "DAMAGE", "KILLS", "EVENT"]],
	&"profile": ["PLAYER PROFILE", "Pilot record and career statistics.", ["OVERVIEW", "COMBAT", "ACHIEVEMENTS", "COLLECTION", "HISTORY"]],
	&"friends": ["FRIENDS", "Local social roster. Online services are disabled.", ["ONLINE", "OFFLINE", "RECENT"]],
	&"squad": ["SQUAD", "Assemble a local training squad.", ["ROSTER", "INVITES", "READY"]],
	&"clan": ["CLAN", "Offline clan shell for future-compatible progression.", ["HOME", "MEMBERS", "MISSIONS", "STARBASE"]],
	&"news": ["NEWS", "Local MECH ASSAULT briefing feed.", ["BRIEFING", "PATCH NOTES", "FIELD REPORTS"]],
	&"settings": ["SETTINGS", "Game configuration and accessibility.", ["GENERAL", "CONTROLS", "AIMING", "BATTLE HUD", "GRAPHICS", "AUDIO", "ACCESSIBILITY"]],
	&"hud_editor": ["BATTLE HUD EDITOR", "Edit safe-zone HUD placement presets.", ["DEFAULT", "WIDE", "COMPACT"]],
	&"titan_equipment": ["TITAN EQUIPMENT", "Dedicated Titan loadout and ability workspace.", ["HULL", "ALPHA", "BETA", "CORE"]],
	&"weapon_inventory": ["WEAPON INVENTORY", "All owned weapon copies, compatible slots and upgrade tracks.", ["LIGHT", "MEDIUM", "HEAVY", "ALPHA", "BETA"]],
	&"robot_inventory": ["ROBOT INVENTORY", "Owned chassis and locked chassis catalogue.", ["OWNED", "LOCKED", "TITANS"]],
	&"pilot_inventory": ["PILOT INVENTORY", "Owned pilots and training progression.", ["OWNED", "LOCKED", "SKILLS"]],
	&"drone_inventory": ["DRONE INVENTORY", "Owned drones and robot assignments.", ["OWNED", "LOCKED", "UPGRADES"]],
	&"specialization": ["SPECIALIZATIONS", "Robot specialization tree and persistent tuning.", ["CORE", "OFFENSE", "DEFENSE", "UTILITY"]],
	&"starbase": ["STARBASE", "Offline command infrastructure and clan progression shell.", ["CORE", "MODULES", "LOG"]],
	&"post_battle": ["POST-BATTLE", "Detailed local battle report and rewards.", ["PERFORMANCE", "TEAM", "REWARDS"]],
	&"rewards": ["REWARDS", "Unclaimed local reward track.", ["BATTLE", "MISSIONS", "EVENTS"]],
}

var _page: StringName = &""
var _title: Label
var _subtitle: Label
var _content: VBoxContainer
var _status: Label
var _nav: HBoxContainer

func open(params: Dictionary = {}) -> void:
	_page = StringName(String(params.get("page", String(_page))))
	if _page == &"":
		_page = &"profile"
	refresh()

func _build() -> void:
	add_child(UiParts.backdrop(0.975))
	var root := UiParts.vbox(12.0)
	root.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	root.offset_left = 24.0
	root.offset_right = -24.0
	root.offset_top = 20.0
	root.offset_bottom = -20.0
	add_child(root)

	var top := UiParts.hbox(14.0)
	var back_button := UiParts.button("< HANGAR", UiTheme.CYAN, 15, Vector2(142.0, 48.0))
	UiParts.wire(back_button, func(): manager.pop())
	top.add_child(back_button)
	_title = UiParts.label("SYSTEM", 25, UiTheme.TEXT, true)
	_title.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	top.add_child(_title)
	var offline := UiParts.label("● OFFLINE / LOCAL SAVE", 13, UiTheme.HEALTH, true)
	top.add_child(offline)
	root.add_child(top)

	var line := UiParts.divider(1.0)
	root.add_child(line)
	_subtitle = UiParts.label("", 13, UiTheme.MUTED)
	root.add_child(_subtitle)

	var workspace := UiParts.hbox(16.0)
	workspace.size_flags_vertical = Control.SIZE_EXPAND_FILL
	root.add_child(workspace)

	var left_panel := Panel.new()
	left_panel.custom_minimum_size = Vector2(230.0, 0.0)
	left_panel.add_theme_stylebox_override("panel", UiTheme.panel(0.88, UiTheme.CYAN))
	var left_margin := MarginContainer.new()
	left_margin.add_theme_constant_override("margin_left", 12)
	left_margin.add_theme_constant_override("margin_right", 12)
	left_margin.add_theme_constant_override("margin_top", 12)
	left_margin.add_theme_constant_override("margin_bottom", 12)
	left_panel.add_child(left_margin)
	_nav = UiParts.hbox(6.0)
	_nav.size_flags_vertical = Control.SIZE_EXPAND_FILL
	left_margin.add_child(_nav)
	workspace.add_child(left_panel)

	var main_panel := Panel.new()
	main_panel.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	main_panel.size_flags_vertical = Control.SIZE_EXPAND_FILL
	main_panel.add_theme_stylebox_override("panel", UiTheme.panel(0.9, UiTheme.AMBER))
	var margin := MarginContainer.new()
	for side in ["left", "right", "top", "bottom"]:
		margin.add_theme_constant_override("margin_" + side, 18)
	main_panel.add_child(margin)
	var scroll := UiParts.scroll()
	margin.add_child(scroll)
	_content = UiParts.vbox(10.0)
	scroll.add_child(_content)
	workspace.add_child(main_panel)

	_status = UiParts.label("", 12, UiTheme.MUTED)
	root.add_child(_status)

func refresh() -> void:
	if _content == null:
		return
	var def: Array = PAGE_DEFS.get(_page, ["SYSTEM", "", []]) as Array
	_title.text = String(def[0])
	_subtitle.text = String(def[1])
	_status.text = "LOCAL STATE · %s · %s" % [GameState.phase_label(), GameState.BUILD_LABEL]
	_rebuild_nav()
	_rebuild_content(String(def[0]), def[2] as Array)

func _rebuild_nav() -> void:
	for child in _nav.get_children():
		child.queue_free()
	var column := UiParts.vbox(6.0)
	column.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	_nav.add_child(column)
	# Stub sweep: workshop/collections/missions/operations/events/datapads/
	# friends/squad/clan/hud_editor only ever toasted "ready" — every entry
	# above must open a screen that does real work (§21/§52).
	var groups := [
		["PLAY", [&"game_modes", &"deployment"]],
		["ARMORY", [&"inventory", &"robot", &"store"]],
		["SOCIAL", [&"profile", &"news"]],
		["SYSTEM", [&"settings"]],
	]
	for group in groups:
		var label := UiParts.label(String(group[0]), 10, UiTheme.AMBER, true)
		column.add_child(label)
		for key_value in group[1] as Array:
			var key := StringName(key_value)
			if not manager.has_screen(key):
				continue
			var text := _short_name(key)
			var b := UiParts.button(text, UiTheme.CYAN if key != _page else UiTheme.AMBER, 12, Vector2(0, 42))
			b.size_flags_horizontal = Control.SIZE_EXPAND_FILL
			UiParts.wire(b, func(): manager.push(key, {"page": String(key)}))
			column.add_child(b)

func _short_name(key: StringName) -> String:
	match key:
		&"robot_equipment": return "EQUIPMENT"
		&"settings_general": return "GENERAL"
		&"settings_controls": return "CONTROLS"
		&"settings_aiming": return "AIMING"
		&"settings_battle_hud": return "BATTLE HUD"
		&"settings_graphics": return "GRAPHICS"
		&"settings_audio": return "AUDIO"
		&"settings_accessibility": return "ACCESSIBILITY"
		&"settings_notifications": return "NOTIFICATIONS"
		&"settings_language": return "LANGUAGE"
		&"settings_account": return "ACCOUNT"
		&"settings_social_privacy": return "PRIVACY"
		&"settings_about": return "ABOUT"
		&"battle_robot_select": return "ROBOT SELECT"
		&"battle_pause": return "PAUSE"
		&"reward_claim": return "CLAIM REWARD"
		&"notifications": return "NOTIFICATIONS"
		&"game_modes": return "GAME MODES"
		&"deployment": return "DEPLOY"
		&"hud_editor": return "HUD EDITOR"
		&"datapads": return "DATA PADS"
		&"leaderboards": return "LEADERBOARDS"
	return String(key).to_upper()

func _rebuild_content(caption: String, entries: Array) -> void:
	for child in _content.get_children():
		child.queue_free()
	var hero := Panel.new()
	hero.custom_minimum_size = Vector2(0, 104)
	hero.add_theme_stylebox_override("panel", UiTheme.glow_frame(UiTheme.CYAN, 1))
	_content.add_child(hero)
	var hm := MarginContainer.new()
	for side in ["left", "right", "top", "bottom"]:
		hm.add_theme_constant_override("margin_" + side, 14)
	hm.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	hero.add_child(hm)
	var hero_box := UiParts.vbox(5.0)
	hm.add_child(hero_box)
	var h1 := UiParts.label(caption, 22, UiTheme.TEXT, true)
	hero_box.add_child(h1)
	var h2 := UiParts.label(_hero_text(), 13, UiTheme.MUTED)
	hero_box.add_child(h2)

	if _page == &"deployment":
		_build_deployment()
		return
	if _page == &"settings":
		_build_settings()
		return
	if _page == &"hud_editor":
		_build_hud_editor()
		return
	if _page == &"game_modes":
		_build_modes()
		return
	if _page == &"matchmaking":
		_build_matchmaking()
		return
	if _page == &"profile":
		_build_profile()
		return
	if _page == &"post_battle":
		_build_post_battle()
		return
	if _page == &"news":
		_build_news()
		return

	for entry in entries:
		var row := Panel.new()
		row.custom_minimum_size = Vector2(0, 82)
		row.add_theme_stylebox_override("panel", UiTheme.panel(0.72, UiTheme.STEEL))
		var box := UiParts.hbox(12.0)
		var m := MarginContainer.new()
		for side in ["left", "right", "top", "bottom"]:
			m.add_theme_constant_override("margin_" + side, 10)
		row.add_child(m)
		m.add_child(box)
		var text := UiParts.vbox(2.0)
		text.size_flags_horizontal = Control.SIZE_EXPAND_FILL
		text.add_child(UiParts.label(String(entry), 17, UiTheme.TEXT, true))
		text.add_child(UiParts.label(_entry_detail(String(entry)), 11, UiTheme.MUTED))
		box.add_child(text)
		var action := UiParts.button(_entry_action(String(entry)), UiTheme.AMBER, 13, Vector2(150, 46))
		UiParts.wire(action, func(): _activate_entry(String(entry)))
		box.add_child(action)
		_content.add_child(row)

func _hero_text() -> String:
	if _page == &"game_modes": return "LOCAL COMBAT · NO MATCHMAKING SERVER · BATTLE DATA SAVED LOCALLY"
	if _page == &"profile": return "PLAYER RECORD · OFFLINE CAREER · PERSISTENT LOADOUT"
	if _page == &"settings": return "SETTINGS ARE APPLIED LOCALLY AND PERSISTED"
	if _page == &"news": return "BUILT INTO THIS CLIENT · NO NETWORK REQUIRED"
	return "DATA-DRIVEN WORKSPACE · REAL GAME STATE · OFFLINE"

func _entry_detail(entry: String) -> String:
	return "AVAILABLE · LOCAL STATE · READY FOR USE"

func _entry_action(entry: String) -> String:
	if _page == &"missions" and entry == "DAILY": return "VIEW TASKS"
	if _page == &"datapads": return "OPEN"
	if _page == &"collections": return "BROWSE"
	if _page == &"leaderboards": return "VIEW"
	return "OPEN"

func _activate_entry(entry: String) -> void:
	match _page:
		&"game_modes":
			manager.push(&"matchmaking", {"page":"matchmaking", "mode":entry})
		&"datapads":
			manager.toast("%s queued · reward system local" % entry)
		&"workshop":
			manager.toast("%s station ready" % entry)
		&"collections":
			manager.toast("Collection opened: %s" % entry)
		&"missions":
			manager.toast("%s objectives loaded" % entry)
		&"events":
			manager.toast("%s event loaded" % entry)
		&"leaderboards":
			manager.toast("Local ranking loaded")
		&"friends", &"squad", &"clan":
			manager.toast("Offline social mode · no server connection")
		_: manager.toast("%s ready" % entry)

func _build_modes() -> void:
	var info := UiParts.label("STANDARD BATTLE\n5 regular robots + 1 Titan\nMap: OPEN REALM\nObjective: eliminate hostiles and survive the operation.", 16, UiTheme.TEXT)
	_content.add_child(info)
	var start := UiParts.button("CONTINUE TO MATCHMAKING", UiTheme.CTA_ORANGE, 18, Vector2(0, 58))
	UiParts.wire(start, func(): manager.push(&"matchmaking", {"page":"matchmaking", "mode":"OPEN REALM SURVIVAL"}))
	_content.add_child(start)

func _build_matchmaking() -> void:
	var mode := "OPEN REALM SURVIVAL"
	var state := UiParts.label("OFFLINE QUEUE\nMODE  %s\nPLAYERS  1 LOCAL COMMANDER\nSEARCH  READY\nSERVER  NOT REQUIRED" % mode, 17, UiTheme.TEXT, true)
	_content.add_child(state)
	var start := UiParts.button("MATCH FOUND · DEPLOY", UiTheme.CTA_GREEN, 19, Vector2(0, 60))
	UiParts.wire(start, func(): manager.push(&"deployment", {"page":"deployment"}))
	_content.add_child(start)
	var cancel := UiParts.button("CANCEL", UiTheme.STEEL, 14, Vector2(0, 46))
	UiParts.wire(cancel, func(): manager.pop())
	_content.add_child(cancel)

func _build_deployment() -> void:
	var def := GameState.robot_def()
	var text := "DEPLOYMENT ROSTER\nACTIVE MECH  %s\nCLASS  %s\nARMOR  %s\nWEAPONS  %d\nTITAN  %s\n\nOnly owned and valid units can deploy." % [
		String(def.get("name", "MECH")), String(def.get("klass", "ASSAULT")), GameState.fmt_amount(float(def.get("armor", 0))), GameState.filled_slots(), "READY" if GameState.active_titan != &"" else "AVAILABLE"]
	_content.add_child(UiParts.label(text, 17, UiTheme.TEXT, true))
	var battle := UiParts.button("DEPLOY %s" % String(def.get("name", "MECH")), UiTheme.CTA_ORANGE, 20, Vector2(0, 64))
	UiParts.wire(battle, func(): SceneRouter.goto_game())
	_content.add_child(battle)
	var edit := UiParts.button("EDIT EQUIPMENT", UiTheme.CYAN, 14, Vector2(0, 48))
	UiParts.wire(edit, func(): manager.push(&"robot", {}))
	_content.add_child(edit)

func _build_profile() -> void:
	var kills := GameState.enemies_killed
	var stats := [
		["COMMANDER", "LOCAL PILOT"], ["LEVEL", str(GameState.pilot_level())],
		["HOSTILES · LAST OP", str(kills)],
		["ACTIVE MECH", String(GameState.robot_def().get("name", "MECH"))], ["PLATFORM", OS.get_name()],
		["STATUS", "OFFLINE / PERSISTENT"],
	]
	for item in stats:
		var row := UiParts.hbox(12.0)
		row.add_child(UiParts.label(String(item[0]), 13, UiTheme.MUTED))
		var val := UiParts.label(String(item[1]), 15, UiTheme.TEXT, true)
		val.size_flags_horizontal = Control.SIZE_EXPAND_FILL
		val.horizontal_alignment = HORIZONTAL_ALIGNMENT_RIGHT
		row.add_child(val)
		_content.add_child(row)

func _build_post_battle() -> void:
	var result := """LAST OPERATION

RESULT  %s
MECH  %s
HOSTILES  %d
DAMAGE DEALT  %s
DAMAGE TAKEN  %s
MISSION TIME  %.1fs

REWARDS
+%d SILVER   +%d GOLD   +%d PLAT
+%d PARTS   +%d CHIPS   +%d MODULES""" % [
		"VICTORY" if GameState.phase == GameState.Phase.VICTORY else "READY",
		String(GameState.robot_def().get("name", "MECH")),
		GameState.enemies_killed,
		GameState.fmt_amount(GameState.player_damage_dealt),
		GameState.fmt_amount(GameState.player_damage_taken),
		GameState.match_time,
		GameState.match_reward_silver, GameState.match_reward_gold, GameState.match_reward_platinum,
		GameState.match_reward_parts, GameState.match_reward_chips, GameState.match_reward_modules]
	_content.add_child(UiParts.label(result, 17, UiTheme.TEXT, true))
	var hangar := UiParts.button("RETURN TO HANGAR", UiTheme.CTA_GREEN, 18, Vector2(0, 58))
	UiParts.wire(hangar, func(): manager.pop())
	_content.add_child(hangar)
	var redeploy := UiParts.button("REDEPLOY", UiTheme.AMBER, 16, Vector2(0, 52))
	UiParts.wire(redeploy, func(): manager.push(&"game_modes", {"page":"game_modes"}))
	_content.add_child(redeploy)

# Local patch notes — real content from this build's history. There is no
# online feed, so the page says exactly that instead of faking one.
func _build_news() -> void:
	var notes: Array = [
		[GameState.BUILD_LABEL, "Hangar showroom rebuild: + button on every pad, "
			+ "TO BATTLE deploys directly, chrome decluttered."],
		["v0.36.0", "Hunting Grounds roster: mixed BASE/MK1/MK2/MK3 enemies with "
			+ "per-enemy weapon rolls."],
		["v0.35.0", "Full content batch: 71 robot weapons, 15 pilots, 6 drones."],
		["v0.34.0", "Physical hangar showroom: AABB camera fit, drag-rotates-model, "
			+ "pad chips, WR weapon-select layout."],
		["v0.33.0", "Screen-stack hierarchy rebuild: one screen, one purpose."],
	]
	_content.add_child(UiParts.label("LOCAL PATCH NOTES · NO ONLINE FEED", 14,
			UiTheme.AMBER, true))
	for note: Array in notes:
		var row := Panel.new()
		row.custom_minimum_size = Vector2(0, 74)
		row.add_theme_stylebox_override("panel", UiTheme.panel(0.72, UiTheme.STEEL))
		var margin := MarginContainer.new()
		for side in ["left", "right", "top", "bottom"]:
			margin.add_theme_constant_override("margin_" + side, 10)
		margin.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
		row.add_child(margin)
		var box := UiParts.vbox(3.0)
		margin.add_child(box)
		box.add_child(UiParts.label(String(note[0]), 14, UiTheme.CYAN, true))
		var body := UiParts.label(String(note[1]), 12, UiTheme.TEXT)
		body.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
		box.add_child(body)
		_content.add_child(row)

func _build_settings() -> void:
	var rows := [
		["GENERAL", "Confirm purchases · tutorial hints · notifications"],
		["CONTROLS", "Touch / keyboard / gamepad routing"],
		["AIMING", "Target priority · lock-on behavior · sensitivity"],
		["BATTLE HUD", "Open the HUD editor and restore presets"],
		["GRAPHICS", "LOW · MEDIUM · HIGH · ULTRA"],
		["AUDIO", "Master · music · SFX"],
		["ACCESSIBILITY", "Readability and input assistance"],
	]
	for item in rows:
		var row := Panel.new()
		row.custom_minimum_size = Vector2(0, 66)
		row.add_theme_stylebox_override("panel", UiTheme.panel(0.65, UiTheme.STEEL))
		var box := UiParts.hbox(10.0)
		row.add_child(box)
		box.add_child(UiParts.label(String(item[0]), 14, UiTheme.AMBER, true))
		var desc := UiParts.label(String(item[1]), 12, UiTheme.MUTED)
		desc.size_flags_horizontal = Control.SIZE_EXPAND_FILL
		box.add_child(desc)
		var b := UiParts.button("CONFIGURE", UiTheme.CYAN, 12, Vector2(128, 42))
		UiParts.wire(b, func(): manager.toast(String(item[0]) + " saved locally"))
		box.add_child(b)
		_content.add_child(row)
	var hud := UiParts.button("OPEN HUD EDITOR", UiTheme.AMBER, 15, Vector2(0, 50))
	UiParts.wire(hud, func(): manager.push(&"hud_editor", {"page":"hud_editor"}))
	_content.add_child(hud)

func _build_hud_editor() -> void:
	_content.add_child(UiParts.label("SAFE ZONE PRESET\n\nMOVE STICK      ●\nLOOK AREA       ●\nFIRE            ● ●\nABILITIES       ● ●\nTARGET LOCK     ●\nRADAR           ●\nHEALTH / AMMO   ●", 16, UiTheme.TEXT, true))
	for preset in ["DEFAULT", "WIDE", "COMPACT"]:
		var b := UiParts.button("APPLY %s" % preset, UiTheme.CYAN, 14, Vector2(0, 48))
		UiParts.wire(b, func(): manager.toast("HUD preset %s saved" % preset))
		_content.add_child(b)
	var reset := UiParts.button("RESET HUD LAYOUT", UiTheme.DANGER, 14, Vector2(0, 48))
	UiParts.wire(reset, func(): manager.toast("HUD layout restored"))
	_content.add_child(reset)

func ro_box_fix(box: VBoxContainer, node: Control) -> void:
	box.add_child(node)
