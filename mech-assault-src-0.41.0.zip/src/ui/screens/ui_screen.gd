class_name UiScreen
extends Control

# Base class for every screen in the UIManager stack. Screens build their
# tree once in setup(), receive params through open(), and refresh their
# data on enter. Opaque screens hide everything below them; overlays
# (the equipment workspace) let the hangar bay show through.

var manager: UIManager

func setup(ui: UIManager) -> void:
	manager = ui
	set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	mouse_filter = Control.MOUSE_FILTER_PASS
	_build()

func _build() -> void:
	pass

# Params differ per screen (slot, item, key...). Called before the first
# enter and on every re-push with fresh params.
func open(_params: Dictionary = {}) -> void:
	pass

func refresh() -> void:
	pass

func on_enter() -> void:
	refresh()

func on_exit() -> void:
	pass

# Opaque screens cover the screens below them (their own backdrop eats
# input and hides the bay). Overlays keep the bay visible and interactive.
func is_opaque() -> bool:
	return true

func back() -> void:
	if manager != null:
		manager.pop()
