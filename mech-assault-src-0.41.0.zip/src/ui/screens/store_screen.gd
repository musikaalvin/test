class_name StoreScreen
extends UiScreen

# The store: five tabbed pages (robots / titans / weapons / pilots /
# drones) of ItemCards rows. Ported from the old StorePopup — tab state
# and page/row node names kept so tooling and smoke can address them.

const TAB_NAMES: Array[String] = [
	"StoreTabRobots", "StoreTabTitans", "StoreTabWeapons",
	"StoreTabPilots", "StoreTabDrones",
]
const PAGE_NAMES: Array[String] = [
	"StoreRobotScroll", "StoreTitanScroll", "StoreWeaponScroll",
	"StorePilotScroll", "StoreDroneScroll",
]
const ROW_NAMES: Array[String] = [
	"StoreRobotRows", "StoreTitanRows", "StoreWeaponRows",
	"StorePilotRows", "StoreDroneRows",
]

var _tab: int = 0
var _tab_buttons: Array[Button] = []
var _pages: Array[ScrollContainer] = []
var _row_boxes: Array[VBoxContainer] = []
var _wallet: Label
var _items: Array[String] = []
var _pilots: Array[String] = []
var _drones: Array[String] = []

func _build() -> void:
	add_child(UiParts.backdrop(0.97))
	_build_header()
	_build_body()

func _build_header() -> void:
	var header := Control.new()
	header.name = "Header"
	header.anchor_left = 0.0
	header.anchor_top = 0.0
	header.anchor_right = 1.0
	header.anchor_bottom = 0.0
	header.offset_left = 18.0
	header.offset_top = 64.0
	header.offset_right = -18.0
	header.offset_bottom = 112.0
	header.mouse_filter = Control.MOUSE_FILTER_PASS
	add_child(header)

	var row := UiParts.header_row("STORE", back)
	row.anchor_left = 0.0
	row.anchor_top = 0.0
	row.anchor_right = 1.0
	row.anchor_bottom = 1.0
	header.add_child(row)
	var title := row.get_node_or_null("ScreenTitle") as Label
	if title != null:
		title.size_flags_horizontal = Control.SIZE_EXPAND_FILL
		title.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	_wallet = UiParts.label("", 13, UiTheme.MUTED)
	_wallet.name = "StoreWallet"
	_wallet.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
	row.add_child(_wallet)

func _build_body() -> void:
	var body := UiParts.vbox(7.0)
	body.name = "StoreBody"
	body.anchor_left = 0.0
	body.anchor_top = 0.0
	body.anchor_right = 1.0
	body.anchor_bottom = 1.0
	body.offset_left = 18.0
	body.offset_top = 124.0
	body.offset_right = -18.0
	body.offset_bottom = -20.0
	body.mouse_filter = Control.MOUSE_FILTER_PASS
	add_child(body)

	var tabs := UiParts.hbox(8.0)
	tabs.name = "StoreTabs"
	body.add_child(tabs)
	for tab_index in TAB_NAMES.size():
		var tab_button := UiParts.button(_tab_label(tab_index), UiTheme.AMBER,
				14, Vector2(168.0, 40.0))
		tab_button.name = TAB_NAMES[tab_index]
		UiParts.wire(tab_button, store_tab_set.bind(tab_index))
		tabs.add_child(tab_button)
		_tab_buttons.append(tab_button)

	for page_index in PAGE_NAMES.size():
		var page := UiParts.scroll()
		page.name = PAGE_NAMES[page_index]
		page.visible = page_index == 0
		body.add_child(page)
		var rows := UiParts.vbox(8.0)
		rows.name = ROW_NAMES[page_index]
		rows.size_flags_horizontal = Control.SIZE_EXPAND_FILL
		page.add_child(rows)
		_pages.append(page)
		_row_boxes.append(rows)
	_apply_store_tab()

func _tab_label(tab_index: int) -> String:
	match tab_index:
		0: return "ROBOTS"
		1: return "TITANS"
		2: return "WEAPONS"
		3: return "PILOTS"
		_: return "DRONES"

# ----------------------------------------------------------------- actions

func open(params: Dictionary = {}) -> void:
	# Every open starts on the robots tab (the titan pad pushes tab 1).
	_tab = clampi(int(params.get("tab", 0)), 0, _tab_buttons.size() - 1)

func store_tab_set(tab: int) -> void:
	_tab = clampi(tab, 0, _tab_buttons.size() - 1)
	_apply_store_tab()

func _apply_store_tab() -> void:
	for index in _pages.size():
		_pages[index].visible = index == _tab
	for index in _tab_buttons.size():
		UiTheme.apply_to_button(_tab_buttons[index],
				UiTheme.AMBER if index == _tab else UiTheme.STEEL, 15)

# --------------------------------------------------------------- handlers

func _on_robot_action(robot_id: StringName) -> void:
	ItemCards.robot_action(robot_id, manager)

func _on_weapon_buy(item_id: String) -> void:
	if GameState.buy_item(item_id):
		manager.toast("%s PURCHASED" % item_id)
	else:
		var currency := "PLATINUM" if GameState.weapon_buy_currency(
				item_id) == "plat" else "SILVER"
		manager.toast("NOT ENOUGH %s" % currency, true)
	manager.refresh()

func _on_pilot_action(pilot_id: String) -> void:
	var definition := GameState.pilot_def(pilot_id)
	var pilot_name := String(definition.get("name", pilot_id.to_upper()))
	if not GameState.owns_pilot(pilot_id):
		if GameState.buy_pilot(pilot_id):
			manager.toast("%s HIRED" % pilot_name)
		else:
			var currency := "GOLD" if GameState.pilot_buy_currency(
					pilot_id) == "gold" else "SILVER"
			manager.toast("NOT ENOUGH %s" % currency, true)
		manager.refresh()
		return
	if GameState.assign_pilot(GameState.selected_robot, pilot_id):
		manager.toast("%s ASSIGNED" % pilot_name)
	else:
		manager.toast("COULD NOT ASSIGN PILOT", true)
	manager.refresh()

func _on_drone_action(drone_id: String) -> void:
	var definition := GameState.drone_def(drone_id)
	var drone_name := String(definition.get("name", drone_id.to_upper()))
	if not GameState.owns_drone(drone_id):
		if GameState.buy_drone(drone_id):
			manager.toast("%s PURCHASED" % drone_name)
		else:
			manager.toast("NOT ENOUGH MICROCHIPS", true)
		manager.refresh()
		return
	if GameState.select_drone(drone_id):
		manager.toast("%s EQUIPPED" % drone_name)
		var hangar := manager.screen(&"hangar")
		if hangar != null and hangar.has_method("rebuild_bay"):
			hangar.call("rebuild_bay")
	else:
		manager.toast("TITANS CARRY NO DRONE", true)
	manager.refresh()

func _on_drone_upgrade(drone_id: String) -> void:
	if GameState.upgrade_drone(drone_id):
		manager.toast("%s UPGRADED TO LV %d" % [
				GameState.drone_def(drone_id).get("name", drone_id.to_upper()),
				GameState.drone_level(drone_id)])
	else:
		manager.toast("NOT ENOUGH MICROCHIPS", true)
	manager.refresh()

# ----------------------------------------------------------------- refresh

func refresh() -> void:
	if _wallet == null:
		return
	_wallet.text = "SILVER  %s   ·   GOLD  %s   ·   PLATINUM  %d   ·   CHIPS  %d" % [
			UiParts.money(GameState.silver), UiParts.money(GameState.gold),
			GameState.platinum, GameState.microchips]
	_items.clear()
	for item_id in GameState.ALL_ITEM_IDS:
		_items.append(item_id)
	for item_id in GameState.TITAN_ITEM_IDS:
		_items.append(item_id)
	_pilots.clear()
	for definition in GameState.PILOT_DEFS:
		_pilots.append(String(definition.get("id", "")))
	_drones.clear()
	for definition in GameState.DRONE_DEFS:
		_drones.append(String(definition.get("id", "")))
	_rebuild_rows(_row_boxes[0], _owned_robots(false))
	_rebuild_rows(_row_boxes[1], _owned_robots(true))
	_rebuild_rows(_row_boxes[2], _weapon_rows())
	_rebuild_rows(_row_boxes[3], _pilot_rows())
	_rebuild_rows(_row_boxes[4], _drone_rows())
	_apply_store_tab()

func _owned_robots(titan: bool) -> Array:
	var rows: Array = []
	for robot_id in GameState.ROBOT_ORDER:
		if GameState.is_titan(robot_id) == titan:
			rows.append(ItemCards.robot_card(robot_id, false,
					_on_robot_action.bind(robot_id), manager))
	return rows

func _weapon_rows() -> Array:
	var rows: Array = []
	for item_id in _items:
		rows.append(ItemCards.weapon_card(item_id, false,
				_on_weapon_buy.bind(item_id), manager))
	return rows

func _pilot_rows() -> Array:
	var rows: Array = []
	for pilot_id in _pilots:
		rows.append(ItemCards.pilot_row(pilot_id,
				_on_pilot_action.bind(pilot_id), manager))
	return rows

func _drone_rows() -> Array:
	var rows: Array = []
	for drone_id in _drones:
		rows.append(ItemCards.drone_row(drone_id,
				_on_drone_action.bind(drone_id),
				_on_drone_upgrade.bind(drone_id), manager))
	return rows

# Cards are rebuilt in place: unlink first so a rebuild triggered from a
# card's own pressed signal never frees a locked object.
func _rebuild_rows(box: VBoxContainer, cards: Array) -> void:
	for child in box.get_children():
		box.remove_child(child)
		child.queue_free()
	for card in cards:
		box.add_child(card)
