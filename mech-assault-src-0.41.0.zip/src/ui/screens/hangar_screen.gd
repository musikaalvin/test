class_name HangarScreen
extends UiScreen

# Main hangar: the physical 3D bay under WR-style app chrome — one screen,
# one purpose (what am I using?). The bay is presentation ONLY: the camera
# frames the selected machine's real AABB and never moves on its own;
# dragging rotates the MODEL, wheel/pinch zoom stops dead on release.
# Chrome is deliberately lean (WR showroom layout): identity panel top-left,
# currency strip + gear/messages, TO BATTLE top-right, a "+" button on every
# pad (tap pad or + = select + open that mech's screen; empty pad = store),
# a small right rail (INVENTORY / ARMORY / COMMAND), COMBAT STATS bottom-left,
# STORE bottom-right and the green upgrade bubble over the selection.

const CAM_YAW := 2.35619449 # classic bay view direction (front-right)
const CAM_ELEV := 0.30 # radians above the horizon
const FIT_PAD := 24.0 # px of breathing room inside the safe rect
const FIT_MAX_DISTANCE := 60.0
const BAY_FOV := 46.0
const CLOSEUP_FOV := 40.0
const ZOOM_MIN := 0.7
const ZOOM_MAX := 1.9
const DRAG_YAW_DEG_PER_PX := 0.45
const WHEEL_ZOOM_RATIO := 1.12

var _bay: SubViewportContainer
var _bay_viewport: SubViewport
var _camera: Camera3D
var _driver: HangarPoseDriver
var _overlay: Control

var _orbit_dragging: bool = false
var _orbit_drag_travel: float = 0.0
var _closeup: bool = false
var _zoom: float = 1.0
var _fit_center := Vector3(0.0, 1.7, 0.0)
var _fit_distance: float = 10.0
var _look_shift_norm := Vector3.ZERO
var _view_distance: float = 10.0
var _fit_dirty: bool = true
var _last_viewport_size := Vector2i.ZERO
var _touch_points: Dictionary = {}
var _touch_travel: Dictionary = {}
var _pinch_distance: float = 0.0

var _info_name: Label
var _info_class: Label
var _info_power: Label
var _info_weapons: Label
var _info_status: Label
var _start_button: Button
var _slot_plus: Dictionary = {}
var _slot_signature: Array = []
var _bubble_panel: Panel
var _bubble_margin: MarginContainer
var _bubble_label: Label
var _leaving: bool = false

func is_opaque() -> bool:
	return false

func _build() -> void:
	_build_bay()
	_build_overlay()

func _process(delta: float) -> void:
	# Hidden behind an opaque screen: stop the 3D render target entirely
	# (a hidden SubViewportContainer with UPDATE_ALWAYS would keep burning
	# frames for a screen nobody can see).
	if not visible:
		if _bay_viewport != null \
				and _bay_viewport.render_target_update_mode \
				!= SubViewport.UPDATE_DISABLED:
			_bay_viewport.render_target_update_mode = SubViewport.UPDATE_DISABLED
		return
	if _bay_viewport != null \
			and _bay_viewport.render_target_update_mode \
			!= SubViewport.UPDATE_ALWAYS:
		_bay_viewport.render_target_update_mode = SubViewport.UPDATE_ALWAYS
	var viewport_size := Vector2i(_bay_viewport.size)
	if viewport_size != _last_viewport_size:
		_last_viewport_size = viewport_size
		_fit_dirty = true
	if _fit_dirty:
		_refit_camera()
	_apply_view(delta)
	_update_pins()

func _unhandled_input(event: InputEvent) -> void:
	if _leaving or manager == null:
		return
	if manager.current() != &"hangar":
		return
	if event.is_action_pressed(&"fire"):
		# LMB is bound to "fire" for in-match shooting; in the menu only
		# keyboard/pad fire (Space / A) starts a match — a stray click must not.
		if not (event is InputEventMouseButton or event is InputEventScreenTouch):
			_on_start_pressed()
	elif event is InputEventScreenTouch:
		_handle_screen_touch(event as InputEventScreenTouch)
	elif event is InputEventScreenDrag:
		_handle_screen_drag(event as InputEventScreenDrag)

# ---------------------------------------------------------------- 3D bay

func _build_bay() -> void:
	_bay = SubViewportContainer.new()
	_bay.name = "Bay"
	_bay.stretch = true
	_bay.mouse_filter = Control.MOUSE_FILTER_STOP
	_bay.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	_bay.gui_input.connect(_on_bay_input)
	add_child(_bay)

	_bay_viewport = SubViewport.new()
	_bay_viewport.name = "BayViewport"
	_bay_viewport.own_world_3d = true
	_bay_viewport.transparent_bg = true
	_bay_viewport.size = Vector2i(960, 540)
	_bay_viewport.render_target_update_mode = SubViewport.UPDATE_ALWAYS
	_bay.add_child(_bay_viewport)

	# Invisible floor over the whole bay (the physical platforms are built
	# by the pose driver; this catches probes that miss a deck).
	var platform := StaticBody3D.new()
	platform.name = "Platform"
	platform.collision_layer = Layers.WORLD
	platform.collision_mask = 0
	_bay_viewport.add_child(platform)
	var floor_shape := CollisionShape3D.new()
	floor_shape.name = "FloorShape"
	var floor_box := BoxShape3D.new()
	floor_box.size = Vector3(74.0, 1.0, 58.0)
	floor_shape.shape = floor_box
	floor_shape.position = Vector3(0.0, -0.5, -8.0)
	platform.add_child(floor_shape)

	var sun := DirectionalLight3D.new()
	sun.name = "KeyLight"
	sun.rotation_degrees = Vector3(-48.0, -34.0, 0.0)
	sun.light_energy = 2.5
	sun.light_color = Color(1.0, 0.95, 0.88)
	Quality.apply_sun(sun)
	_bay_viewport.add_child(sun)

	var fill_light := DirectionalLight3D.new()
	fill_light.name = "FillLight"
	fill_light.rotation_degrees = Vector3(-26.0, 148.0, 0.0)
	fill_light.light_energy = 0.9
	fill_light.light_color = Color(0.5, 0.8, 1.0)
	_bay_viewport.add_child(fill_light)

	var world_environment := WorldEnvironment.new()
	world_environment.name = "BayEnvironment"
	world_environment.environment = _make_environment()
	_bay_viewport.add_child(world_environment)

	_driver = HangarPoseDriver.new()
	_driver.name = "HangarPoseDriver"
	_bay_viewport.add_child(_driver)

	_camera = Camera3D.new()
	_camera.name = "Camera"
	_camera.current = true
	_camera.fov = BAY_FOV
	_camera.near = 0.1
	_bay_viewport.add_child(_camera)
	_fit_dirty = true

func _make_environment() -> Environment:
	var environment := Environment.new()
	environment.background_mode = Environment.BG_SKY
	environment.sky = Quality.make_sky()
	environment.ambient_light_source = Environment.AMBIENT_SOURCE_COLOR
	environment.ambient_light_color = Color(0.62, 0.66, 0.72)
	environment.ambient_light_energy = 1.2
	environment.tonemap_mode = Environment.TONE_MAPPER_ACES
	environment.tonemap_exposure = 1.3
	return environment

# ---------------------------------------------------------------- camera

# The presentation rect: the part of the screen no chrome occupies. The
# selected machine's AABB must fit inside it with FIT_PAD px to spare.
func _safe_rect(view: Vector2) -> Rect2:
	if _closeup:
		# Equipment workspace: clear of the 306 px left panel, the 424 px
		# right panel, the header (112) and the bottom action bar (~100).
		return Rect2(354.0, 130.0,
				maxf(view.x - 354.0 - 472.0, 120.0),
				maxf(view.y - 130.0 - 112.0, 120.0))
	# Bay: clear of the identity panel (left), the TO BATTLE CTA (top
	# right), the side columns (~176 px + margin each side) and the dock.
	return Rect2(300.0, 132.0,
			maxf(view.x - 300.0 - 212.0, 120.0),
			maxf(view.y - 132.0 - 212.0, 120.0))

func _refit_camera() -> void:
	_fit_dirty = false
	if _camera == null or _driver == null or _bay_viewport == null:
		return
	var view := Vector2(_bay_viewport.size)
	if view.x < 8.0 or view.y < 8.0:
		return
	var safe := _safe_rect(view)
	_camera.fov = CLOSEUP_FOV if _closeup else BAY_FOV
	var bounds := _driver.selected_bounds()
	_fit_center = bounds.get_center()
	var corners := _bounds_corners(bounds)
	var d := clampf(bounds.size.length() * 1.05, 4.0, 40.0)
	var shift := Vector3.ZERO
	# 1) distance: pull back until the whole machine fits the safe rect.
	for _iter in 10:
		_place_camera(d, shift)
		var rect := _project_rect(corners)
		if rect.size.x < 0.0:
			d = minf(d * 1.35 + 1.0, FIT_MAX_DISTANCE)
			continue
		var room := safe.size - Vector2(FIT_PAD * 2.0, FIT_PAD * 2.0)
		var ratio := maxf(rect.size.x / maxf(room.x, 1.0),
				rect.size.y / maxf(room.y, 1.0))
		if ratio <= 1.0:
			break
		d = clampf(d * maxf(ratio, 1.0) * 1.04 + 0.2, 3.0, FIT_MAX_DISTANCE)
	# 2) centre: slide the look target until the projected box sits in
	# the middle of the safe rect (full frames were off to one side).
	for _iter in 6:
		_place_camera(d, shift)
		var rect := _project_rect(corners)
		if rect.size.x < 0.0:
			break
		var delta_px := safe.get_center() - rect.get_center()
		if delta_px.length() < 4.0:
			break
		var basis := _camera.global_transform.basis
		var world_per_px := (2.0 * tan(deg_to_rad(_camera.fov * 0.5)) * d) \
				/ maxf(view.y, 1.0)
		shift += (-basis.x * delta_px.x + basis.y * delta_px.y) * world_per_px
	_fit_distance = maxf(d, 0.5)
	_look_shift_norm = shift / _fit_distance
	_view_distance = _fit_distance / maxf(_zoom, 0.01)
	_place_camera(_view_distance, _look_shift_norm * _view_distance)

func _place_camera(distance: float, shift: Vector3) -> void:
	var dir := Vector3(sin(CAM_YAW) * cos(CAM_ELEV), sin(CAM_ELEV),
			cos(CAM_YAW) * cos(CAM_ELEV))
	var target := _fit_center + shift
	_camera.look_at_from_position(target + dir * distance, target, Vector3.UP)

func _bounds_corners(bounds: AABB) -> Array[Vector3]:
	var corners: Array[Vector3] = []
	for i in 8:
		corners.append(Vector3(
				bounds.position.x + (bounds.size.x if (i & 1) != 0 else 0.0),
				bounds.position.y + (bounds.size.y if (i & 2) != 0 else 0.0),
				bounds.position.z + (bounds.size.z if (i & 4) != 0 else 0.0)))
	return corners

# Screen-rect of a set of world points; returns a sentinel (negative
# size) when any corner falls behind the camera.
func _project_rect(corners: Array[Vector3]) -> Rect2:
	var rect := Rect2()
	var first := true
	for corner in corners:
		if _camera.is_position_behind(corner):
			return Rect2(0.0, 0.0, -1.0, -1.0)
		var point := _camera.unproject_position(corner)
		if first:
			rect = Rect2(point, Vector2.ZERO)
			first = false
		else:
			rect = rect.expand(point)
	return rect

# Smooth zoom only — the fit itself snaps so projections are exact the
# moment a selection changes. At rest the placed transform is identical
# every frame (the showroom must never drift).
func _apply_view(delta: float) -> void:
	if _camera == null:
		return
	var target := _fit_distance / maxf(_zoom, 0.01)
	var next := lerpf(_view_distance, target, clampf(delta * 8.0, 0.0, 1.0))
	if absf(next - target) < 0.015:
		next = target
	_view_distance = next
	_place_camera(_view_distance, _look_shift_norm * _view_distance)

func _zoom_by(factor: float) -> void:
	_zoom = clampf(_zoom * factor, ZOOM_MIN, ZOOM_MAX)

# ---------------------------------------------------------------- input

func _on_bay_input(event: InputEvent) -> void:
	if event is InputEventMouseButton:
		var button := event as InputEventMouseButton
		match button.button_index:
			MOUSE_BUTTON_LEFT:
				if button.pressed:
					_orbit_dragging = true
					_orbit_drag_travel = 0.0
				elif _orbit_dragging:
					# A click (no real drag) picks a platform: robot behind
					# the cursor is selected (or its equipment opens), an
					# empty pad opens the robot store.
					_orbit_dragging = false
					if _orbit_drag_travel < 8.0:
						pick_slot(button.position)
			MOUSE_BUTTON_WHEEL_UP:
				if button.pressed:
					_zoom_by(WHEEL_ZOOM_RATIO)
			MOUSE_BUTTON_WHEEL_DOWN:
				if button.pressed:
					_zoom_by(1.0 / WHEEL_ZOOM_RATIO)
	elif event is InputEventMouseMotion and _orbit_dragging:
		# Drag rotates the MODEL. The camera never moves on its own or
		# under the user's hand.
		var motion := event as InputEventMouseMotion
		_orbit_drag_travel += absf(motion.relative.x) + absf(motion.relative.y)
		if _driver != null:
			_driver.rotate_user(-motion.relative.x * DRAG_YAW_DEG_PER_PX)
	elif event is InputEventScreenTouch:
		_handle_screen_touch(event as InputEventScreenTouch)
	elif event is InputEventScreenDrag:
		_handle_screen_drag(event as InputEventScreenDrag)

# Two fingers on the bay = pinch zoom. Handlers are idempotent if the
# event reaches both the gui and the unhandled path (the ratio is 1.0
# on a repeat) — rotation and tap-to-pick are deduplicated the same way:
# a state write that would be a no-op means the other path already ran.
# Emulated touches (project sets emulate_touch_from_mouse) would otherwise
# run every desktop mouse drag through the touch path as well and rotate the
# model twice — once per event kind. Touch handling is live only while touch
# is the actual input source.
func _touch_live() -> bool:
	return PlatformUtil.effective_mode() == PlatformUtil.InputMode.TOUCH

func _handle_screen_touch(event: InputEventScreenTouch) -> void:
	if not _touch_live():
		return
	if event.pressed:
		_touch_points[event.index] = event.position
		_touch_travel[event.index] = 0.0
		_update_pinch()
		return
	if not _touch_points.has(event.index):
		return	# already released by the gui path — do not pick twice
	var travel := float(_touch_travel.get(event.index, 0.0))
	_touch_points.erase(event.index)
	_touch_travel.erase(event.index)
	_update_pinch()
	# A tap (finger barely moved) selects the platform under it. The mouse
	# path does this on LMB release; touch never generates a mouse button
	# on Android, so without this the showroom was un-tappable by hand.
	if travel < 8.0:
		pick_slot(event.position)

func _handle_screen_drag(event: InputEventScreenDrag) -> void:
	if not _touch_live():
		return
	if not _touch_points.has(event.index):
		return
	var previous: Vector2 = _touch_points[event.index]
	_touch_points[event.index] = event.position
	_touch_travel[event.index] = float(_touch_travel.get(event.index, 0.0)) \
			+ event.relative.length()
	# Single finger rotates the MODEL. `previous` already equals the new
	# position if the gui path processed this same event, so the unhandled
	# copy is a no-op instead of double the rotation.
	if _touch_points.size() == 1 and previous != event.position and _driver != null:
		_driver.rotate_user(-event.relative.x * DRAG_YAW_DEG_PER_PX)
	_update_pinch()

func _update_pinch() -> void:
	if _touch_points.size() < 2:
		_pinch_distance = 0.0
		return
	var points := _touch_points.values()
	var distance := (points[0] as Vector2).distance_to(points[1] as Vector2)
	if _pinch_distance > 1.0 and distance > 1.0:
		_zoom_by(distance / _pinch_distance)
	_pinch_distance = distance

# Convert a press in bay-control space into a platform hit-test and act
# on it. Front-most platform (smallest camera depth) wins overlaps.
func pick_slot(press_position: Vector2) -> void:
	if _driver == null or _camera == null or _bay == null:
		return
	var view_size := Vector2(_bay_viewport.size) \
			if _bay_viewport != null else _bay.size
	if view_size.x < 1.0 or view_size.y < 1.0 \
			or _bay.size.x < 1.0 or _bay.size.y < 1.0:
		return
	var scale := Vector2(
			view_size.x / _bay.size.x, view_size.y / _bay.size.y)
	var scaled := press_position * scale
	var best_slot := -1
	var best_depth := INF
	for index in _driver.slot_count():
		var rect := _driver.slot_screen_rect(index, _camera)
		if rect.size.x <= 0.0 or not rect.grow(14.0).has_point(scaled):
			continue
		var depth := (_camera.global_transform.affine_inverse()
				* _driver.slot_world_centre(index)).z
		if depth < best_depth:
			best_depth = depth
			best_slot = index
	if best_slot < 0:
		return
	_on_slot_picked(best_slot)

func _on_slot_picked(index: int) -> void:
	var robot_id := _driver.slot_robot(index)
	if robot_id == &"":
		# Empty pad: the store is the picker (the titan pad lands on the
		# titans tab).
		if manager.has_screen(&"store"):
			var tab := 1 if bool(HangarSlots.SLOTS[index]["titan"]) else 0
			manager.push(&"store", {"tab": tab})
		return
	# Occupied pad (tap body or the +): make it the hero, then drill into
	# its detail screen — one tap = inner navigation, never a dead end.
	if robot_id != GameState.selected_robot and GameState.owns_robot(robot_id):
		GameState.select_robot(robot_id)
		_after_robot_selected(true)
	if manager.has_screen(&"robot"):
		manager.push(&"robot")

# ---------------------------------------------------------------- overlay

func _build_overlay() -> void:
	var overlay := Control.new()
	overlay.name = "BayOverlay"
	overlay.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	overlay.mouse_filter = Control.MOUSE_FILTER_PASS
	add_child(overlay)
	_overlay = overlay

	_build_info_panel(overlay)
	_build_top_actions(overlay)
	_build_top_utility(overlay)
	_build_right_grid(overlay)
	_build_bottom_actions(overlay)
	_build_upgrade_bubble(overlay)

func _build_info_panel(overlay: Control) -> void:
	var panel := Panel.new()
	panel.name = "InfoPanel"
	panel.anchor_left = 0.0
	panel.anchor_top = 0.0
	panel.anchor_right = 0.0
	panel.anchor_bottom = 0.0
	panel.offset_left = 18.0
	panel.offset_top = 70.0
	panel.custom_minimum_size = Vector2(268.0, 0.0)
	panel.mouse_filter = Control.MOUSE_FILTER_IGNORE
	panel.add_theme_stylebox_override("panel", UiTheme.panel(0.8))
	overlay.add_child(panel)

	var column := UiParts.vbox(3.0)
	column.name = "InfoColumn"
	column.anchor_left = 0.0
	column.anchor_top = 0.0
	column.anchor_right = 1.0
	column.anchor_bottom = 1.0
	column.offset_left = 16.0
	column.offset_top = 12.0
	column.offset_right = -16.0
	column.offset_bottom = -12.0
	column.mouse_filter = Control.MOUSE_FILTER_IGNORE
	panel.add_child(column)

	var hangar_label := UiParts.label("HANGAR BAY  //  LOCAL LOADOUT", 9, UiTheme.CYAN, true)
	hangar_label.name = "HangarStatus"
	column.add_child(hangar_label)

	_info_name = UiParts.label("SCARAB", 24, UiTheme.TEXT, true)
	_info_name.name = "SelectedName"
	column.add_child(_info_name)
	_info_class = UiParts.label("ASSAULT", 12, UiTheme.MUTED)
	_info_class.name = "SelectedClass"
	column.add_child(_info_class)
	_info_status = UiParts.label("READY FOR OFFLINE DEPLOYMENT", 10, UiTheme.HEALTH, true)
	_info_status.name = "SelectedStatus"
	column.add_child(_info_status)
	_info_power = UiParts.label("POWER  0", 14, UiTheme.AMBER, true)
	_info_power.name = "SelectedPower"
	column.add_child(_info_power)

	# One-line equipped-weapon summary — names and counts only. Full
	# weapon statistics live in the equipment/weapon screens (hierarchy
	# rule: the hangar never becomes a database dump).
	_info_weapons = UiParts.label("—", 12, UiTheme.MUTED)
	_info_weapons.name = "WeaponSummary"
	_info_weapons.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	column.add_child(_info_weapons)
	# Plain Panels do not size to their children — measure the column so
	# the identity card actually renders instead of collapsing to its
	# 26 px padding. Sum the children directly: an off-tree ANCHORED
	# container reports a stale zero minimum (anchor setters prime the
	# cache before the children exist), which is exactly what flattened
	# this card to h=26.
	var column_h := 0.0
	for child_index in column.get_child_count():
		var child := column.get_child(child_index) as Control
		column_h += child.get_combined_minimum_size().y
		if child_index > 0:
			column_h += 3.0
	panel.custom_minimum_size = Vector2(268.0, column_h + 26.0)

# Compact utility chrome sits on the CTA row (y 66..124), left of
# TO BATTLE — the currency strip owns y 6..64, so the old top-right
# placement drew the gear/messages straight over the OFFLINE badge.
func _build_top_utility(overlay: Control) -> void:
	var row := UiParts.hbox(8.0)
	row.name = "TopUtility"
	row.anchor_left = 1.0
	row.anchor_right = 1.0
	row.anchor_top = 0.0
	row.anchor_bottom = 0.0
	row.offset_left = -420.0
	row.offset_right = -278.0
	row.offset_top = 66.0
	row.offset_bottom = 124.0
	row.alignment = BoxContainer.ALIGNMENT_END
	row.mouse_filter = Control.MOUSE_FILTER_PASS
	overlay.add_child(row)

	var inbox := UiParts.button("✉", UiTheme.STEEL, 20, Vector2(54.0, 46.0))
	inbox.name = "InboxButton"
	inbox.tooltip_text = "MESSAGES"
	UiParts.wire(inbox, _on_nav_pressed.bind(&"news"))
	row.add_child(inbox)

	var settings := UiParts.button("⚙", UiTheme.STEEL, 20, Vector2(54.0, 46.0))
	settings.name = "SettingsTopButton"
	settings.tooltip_text = "SETTINGS"
	UiParts.wire(settings, _on_nav_pressed.bind(&"settings"))
	row.add_child(settings)


func _build_top_actions(overlay: Control) -> void:
	_start_button = UiParts.button("TO BATTLE", UiTheme.AMBER, 24,
			Vector2(250.0, 58.0))
	_start_button.name = "StartButton"
	_start_button.tooltip_text = "DEPLOY INTO AN OFFLINE LOCAL MATCH"
	_start_button.anchor_left = 1.0
	_start_button.anchor_right = 1.0
	_start_button.anchor_top = 0.0
	_start_button.anchor_bottom = 0.0
	_start_button.offset_left = -268.0
	_start_button.offset_right = -18.0
	_start_button.offset_top = 66.0
	_start_button.offset_bottom = 124.0
	UiParts.wire(_start_button, _on_start_pressed)
	UiTheme.solid_cta(_start_button, UiTheme.CTA_ORANGE, 24)
	overlay.add_child(_start_button)

# Right rail (WR's utility icons) — three destinations only: the pad "+"
# buttons cover EQUIPMENT (tap a mech) and the gear covers SETTINGS, so
# repeating them here would be duplicate chrome.
func _build_right_grid(overlay: Control) -> void:
	var grid := GridContainer.new()
	grid.name = "RightNav"
	grid.columns = 2
	grid.add_theme_constant_override("h_separation", 10)
	grid.add_theme_constant_override("v_separation", 10)
	grid.anchor_left = 1.0
	grid.anchor_right = 1.0
	grid.anchor_top = 1.0
	grid.anchor_bottom = 1.0
	grid.offset_left = -390.0
	grid.offset_right = -18.0
	grid.offset_top = -290.0
	grid.offset_bottom = -160.0
	grid.mouse_filter = Control.MOUSE_FILTER_PASS
	overlay.add_child(grid)

	_add_nav_to(grid, "InventoryButton", "INVENTORY", &"inventory")
	_add_nav_to(grid, "CommandButton", "COMMAND", &"profile")
	var armory := UiParts.button("ARMORY", UiTheme.STEEL, 13,
			Vector2(176.0, 55.0))
	armory.name = "ArmoryButton"
	armory.alignment = HORIZONTAL_ALIGNMENT_LEFT
	armory.tooltip_text = "OPEN LOCAL WEAPON ARMORY"
	UiTheme.compact_button(armory, UiTheme.STEEL, 13)
	UiParts.wire(armory, _on_armory_pressed)
	grid.add_child(armory)

# Bottom corners (WR reserves both): the real combat-stat report left,
# the single STORE entry right — there is no second store anywhere.
func _build_bottom_actions(overlay: Control) -> void:
	var stats := UiParts.button("★  COMBAT STATS", UiTheme.STEEL, 16,
			Vector2(240.0, 62.0))
	stats.name = "StatsRecordButton"
	stats.anchor_left = 0.0
	stats.anchor_right = 0.0
	stats.anchor_top = 1.0
	stats.anchor_bottom = 1.0
	stats.offset_left = 18.0
	stats.offset_right = 258.0
	stats.offset_top = -94.0
	stats.offset_bottom = -26.0
	UiParts.wire(stats, _on_nav_pressed.bind(&"stats"))
	overlay.add_child(stats)

	var store := UiParts.button("STORE  ◆", UiTheme.DANGER, 16,
			Vector2(240.0, 62.0))
	store.name = "StoreButton"
	store.anchor_left = 1.0
	store.anchor_right = 1.0
	store.anchor_top = 1.0
	store.anchor_bottom = 1.0
	store.offset_left = -258.0
	store.offset_right = -18.0
	store.offset_top = -94.0
	store.offset_bottom = -26.0
	UiTheme.solid_cta(store, UiTheme.CTA_RED, 16)
	UiParts.wire(store, _on_nav_pressed.bind(&"store"))
	overlay.add_child(store)


# Green bubble above the selected mech (WR's UPGRADE callout). Hidden
# when the hull is fully upgraded — no fake affordances.
func _build_upgrade_bubble(overlay: Control) -> void:
	var panel := Panel.new()
	panel.name = "UpgradeBubble"
	panel.size = Vector2(340.0, 82.0)
	panel.visible = false
	panel.mouse_filter = Control.MOUSE_FILTER_IGNORE
	panel.add_theme_stylebox_override("panel", UiTheme.panel(0.94, UiTheme.HEALTH))
	overlay.add_child(panel)
	_bubble_panel = panel

	var margin := MarginContainer.new()
	margin.name = "BubbleMargin"
	margin.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	margin.add_theme_constant_override("margin_left", 10.0)
	margin.add_theme_constant_override("margin_right", 8.0)
	margin.add_theme_constant_override("margin_top", 8.0)
	margin.add_theme_constant_override("margin_bottom", 8.0)
	panel.add_child(margin)
	_bubble_margin = margin

	var row := UiParts.hbox(10.0)
	row.name = "BubbleRow"
	margin.add_child(row)

	_bubble_label = UiParts.label("UPGRADE", 13, UiTheme.TEXT, true)
	_bubble_label.name = "BubbleCaption"
	_bubble_label.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	_bubble_label.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	row.add_child(_bubble_label)

	var button := UiParts.button("UPGRADE", UiTheme.HEALTH, 14,
			Vector2(120.0, 40.0))
	button.name = "UpgradeButton"
	button.size_flags_vertical = Control.SIZE_SHRINK_CENTER
	UiParts.wire(button, _on_upgrade_bubble_pressed)
	UiTheme.solid_cta(button, UiTheme.CTA_GREEN, 14)
	row.add_child(button)

# --------------------------------------------------------- projected UI

# One "+" button per pad, projected onto the platform front edge every
# frame. Tap (pad body or the +) = select + open that mech's screen; an
# empty pad opens the store. No name plates under the robots — the 3D
# machine is the identity, exactly like the WR showroom.
func _sync_slot_plus() -> void:
	if _driver == null or _overlay == null:
		return
	var signature: Array = [GameState.selected_robot]
	for index in _driver.slot_count():
		signature.append(_driver.slot_robot(index))
	if signature == _slot_signature:
		return
	_slot_signature = signature
	for key in _slot_plus.keys():
		var old_button := _slot_plus[key] as Control
		if old_button != null:
			_overlay.remove_child(old_button)
			old_button.queue_free()
	_slot_plus.clear()
	for index in _driver.slot_count():
		var button := _make_slot_plus(index, _driver.slot_robot(index))
		_overlay.add_child(button)
		_slot_plus[index] = button

func _make_slot_plus(slot_index: int, robot_id: StringName) -> Button:
	var button := UiParts.button("+", UiTheme.CYAN, 22, Vector2(46.0, 46.0))
	button.name = "SlotPlus_%d" % slot_index
	button.size = Vector2(46.0, 46.0)
	button.alignment = HORIZONTAL_ALIGNMENT_CENTER
	if robot_id == &"":
		var slot: Dictionary = HangarSlots.SLOTS[slot_index]
		button.tooltip_text = "ADD A TITAN" if bool(slot.get("titan", false)) \
				else "ADD A ROBOT"
		button.add_theme_color_override("font_color",
				Color(UiTheme.MUTED.r, UiTheme.MUTED.g, UiTheme.MUTED.b, 0.9))
	else:
		button.tooltip_text = "OPEN %s" % String(
				GameState.robot_def(robot_id).get("name", "MECH")).to_upper()
	var selected := robot_id == GameState.selected_robot and robot_id != &""
	var disc := StyleBoxFlat.new()
	disc.bg_color = Color(0.05, 0.09, 0.12, 0.94)
	disc.border_color = UiTheme.AMBER if selected \
			else (UiTheme.CYAN if robot_id != &"" else UiTheme.STEEL)
	disc.set_border_width_all(2)
	disc.set_corner_radius_all(23)
	button.add_theme_stylebox_override("normal", disc)
	var hover := disc.duplicate() as StyleBoxFlat
	hover.bg_color = Color(0.08, 0.14, 0.18, 0.96)
	button.add_theme_stylebox_override("hover", hover)
	var pressed_style := disc.duplicate() as StyleBoxFlat
	pressed_style.bg_color = Color(0.12, 0.2, 0.26, 0.98)
	button.add_theme_stylebox_override("pressed", pressed_style)
	UiParts.wire(button, _on_slot_picked.bind(slot_index))
	return button

func _update_pins() -> void:
	if _overlay == null or _camera == null or _driver == null:
		return
	var view := Vector2(_bay_viewport.size)
	if view.x < 1.0 or view.y < 1.0 or _overlay.size.x < 1.0:
		return
	var to_overlay := _overlay.size / view
	for index in _slot_plus:
		var chip := _slot_plus[index] as Button
		if chip == null:
			continue
		var slot: Dictionary = HangarSlots.SLOTS[index]
		var world := Vector3(float(slot["pos"].x), float(slot["top"]) + 0.14,
				float(slot["pos"].z))
		var toward := Vector3(_camera.global_position.x - world.x, 0.0,
				_camera.global_position.z - world.z)
		if toward.length_squared() > 0.04:
			world += toward.normalized() * (float(slot["radius"]) * 0.6)
		var show := not _closeup and not _camera.is_position_behind(world)
		if show:
			var point := _camera.unproject_position(world) * to_overlay
			var half := chip.size * 0.5
			show = point.x > -half.x and point.y > -half.y \
					and point.x < _overlay.size.x + half.x \
					and point.y < _overlay.size.y + half.y
			if show:
				chip.position = point - half
		chip.visible = show
	_update_bubble(to_overlay)

func _update_bubble(to_overlay: Vector2) -> void:
	if _bubble_panel == null or _camera == null or _driver == null:
		return
	var caption := "" if _closeup else _bubble_caption()
	if caption.is_empty():
		_bubble_panel.visible = false
		return
	_bubble_label.text = caption
	var bounds := _driver.selected_bounds()
	var anchor := Vector3(bounds.get_center().x, bounds.end.y + 0.7,
			bounds.get_center().z)
	if _camera.is_position_behind(anchor):
		_bubble_panel.visible = false
		return
	var point := _camera.unproject_position(anchor) * to_overlay
	# Re-fit to the caption every frame: the text changes with the mech's
	# upgrade state, and the fixed box let the wrapped label and the
	# UPGRADE button hang below the panel's background.
	var want := _bubble_margin.get_combined_minimum_size()
	_bubble_panel.size = Vector2(maxf(340.0, want.x + 18.0), want.y)
	var size := _bubble_panel.size
	_bubble_panel.visible = true
	_bubble_panel.position = Vector2(
			clampf(point.x - size.x * 0.5, 10.0,
					maxf(_overlay.size.x - size.x - 10.0, 10.0)),
			clampf(point.y - size.y - 8.0, 70.0,
					maxf(_overlay.size.y - size.y - 200.0, 70.0)))

# "" = fully upgraded (bubble hidden). Next level, or the next MK when
# the level cap is reached.
func _bubble_caption() -> String:
	var key := GameState.body_upgrade_key(GameState.selected_robot)
	var state := GameState.upgrade_state(key)
	var mech_name := String(GameState.robot_def().get("name", "MECH"))
	if state.y < GameState.upgrade_level_cap(key):
		return "UPGRADE %s TO LV %d" % [mech_name, state.y + 1]
	if state.x < GameState.upgrade_mk_cap(key):
		return "UPGRADE %s TO MK%d" % [mech_name, state.x + 1]
	return ""

# ---------------------------------------------------------------- actions

func _add_nav_to(parent: Control, button_name: String, text: String,
		screen: StringName) -> void:
	if manager == null or not manager.has_screen(screen):
		return
	var button := UiParts.button(text, UiTheme.STEEL, 13,
			Vector2(176.0, 55.0))
	button.name = button_name
	button.alignment = HORIZONTAL_ALIGNMENT_LEFT
	button.tooltip_text = "OPEN %s" % text
	UiTheme.compact_button(button, UiTheme.STEEL, 13)
	UiParts.wire(button, _on_nav_pressed.bind(screen))

	var strip := ColorRect.new()
	strip.name = "NavAccent"
	strip.color = UiTheme.CYAN
	strip.position = Vector2(8.0, 9.0)
	strip.size = Vector2(3.0, 37.0)
	strip.mouse_filter = Control.MOUSE_FILTER_IGNORE
	button.add_child(strip)

	var code := UiParts.label(_nav_code_for(button_name), 9, UiTheme.CYAN, true)
	code.name = "NavCode"
	code.anchor_left = 1.0
	code.anchor_top = 0.0
	code.anchor_right = 1.0
	code.anchor_bottom = 0.0
	code.offset_left = -34.0
	code.offset_top = 7.0
	code.offset_right = -10.0
	code.offset_bottom = 20.0
	code.horizontal_alignment = HORIZONTAL_ALIGNMENT_RIGHT
	code.mouse_filter = Control.MOUSE_FILTER_IGNORE
	button.add_child(code)
	parent.add_child(button)

func _nav_code_for(button_name: String) -> String:
	match button_name:
		"InventoryButton": return "I"
		"ArmoryButton": return "A"
		"CommandButton": return "P"
	return ""

func _on_nav_pressed(screen: StringName) -> void:
	if manager != null:
		# The page key matters for the shared hub screen (it remembers the
		# last page otherwise); every other screen ignores the extra key.
		manager.push(screen, {"page": String(screen)})

func _on_armory_pressed() -> void:
	if manager != null and manager.has_screen(&"store"):
		manager.push(&"store", {"tab": 2})

func _on_upgrade_bubble_pressed() -> void:
	if manager == null:
		return
	manager.push(&"upgrade", {
		"key": GameState.body_upgrade_key(GameState.selected_robot),
		"is_body": true,
		"slot": -1,
	})

func _on_start_pressed() -> void:
	# Direct match start (restored): the merged build pushed the "game
	# modes" hub instead, so TO BATTLE opened a menu inside the menu and
	# no match ever launched.
	if _leaving or manager == null:
		return
	_leaving = true
	AudioEngine.play(&"ui")
	InputRouter.clear_temporary()
	manager.begin_leaving()
	SceneRouter.goto_game()

func set_closeup(on: bool) -> void:
	if _closeup == on:
		return
	_closeup = on
	_fit_dirty = true
	_refit_camera()

# The equipment overlay keeps the 3D bay but none of the hangar chrome —
# WR's equipment screen shows only its own panels over the mech. Slot +
# buttons, info card, rails and the upgrade bubble all live in BayOverlay,
# so one toggle drives the whole set.
func set_chrome_visible(show_chrome: bool) -> void:
	if _overlay != null:
		_overlay.visible = show_chrome

func on_enter() -> void:
	# Returning to the hangar root always means the chrome belongs on.
	set_chrome_visible(true)
	refresh()

func on_exit() -> void:
	# A finger lifted off-screen (or a screen switch mid-drag) would otherwise
	# leave a stale touch point: the next single tap would be read as a pinch
	# and zoom the camera to a garbage ratio.
	_touch_points.clear()
	_touch_travel.clear()
	_pinch_distance = 0.0
	_orbit_dragging = false
	_orbit_drag_travel = 0.0

func refresh() -> void:
	if _info_name == null:
		return
	var definition := GameState.robot_def()
	_info_name.text = String(definition.get("name", "MECH"))
	_info_class.text = _class_line()
	_info_status.text = "TITAN READY FOR OFFLINE DEPLOYMENT" if GameState.is_titan() \
			else "READY FOR OFFLINE DEPLOYMENT"
	_info_power.text = "POWER  %s" % GameState.fmt_amount(GameState.robot_power())
	_info_weapons.text = _weapon_line()
	_sync_slot_plus()
	_fit_dirty = true
	_refit_camera()

# "RAZOR-M ×2 · MAUL-M ×2" — mounted families grouped, no stat numbers.
func _weapon_line() -> String:
	var counts := {}
	var order: Array[String] = []
	for item_id: String in GameState.equipped_items(GameState.selected_robot):
		if item_id.is_empty():
			continue
		if counts.has(item_id):
			counts[item_id] += 1
		else:
			counts[item_id] = 1
			order.append(item_id)
	if order.is_empty():
		return "NO WEAPONS MOUNTED"
	var parts: Array[String] = []
	for item_id in order:
		parts.append("%s ×%d" % [GameState.item_display_name(item_id),
				int(counts[item_id])])
	return String("  ·  ".join(parts))

func _class_line() -> String:
	var definition := GameState.robot_def()
	var class_text := String(definition.get("klass", "ASSAULT"))
	if GameState.is_titan():
		class_text = "TITAN · %s" % class_text
	return "%s  ·  %s" % [class_text, String(definition.get("role", ""))]

func _after_robot_selected(notify: bool) -> void:
	if notify:
		manager.toast("%s SELECTED" % String(GameState.robot_def().get("name", "")))
	if _driver != null:
		_driver.rebuild()
	# Refresh the whole stack: the equipment overlay (if open) shows the
	# same robot and must repaint with it.
	manager.refresh()

# Rebuild the posed rig (palette / drone / loadout changes that alter the
# preview geometry, e.g. equipping a drone with its orbit).
func rebuild_bay() -> void:
	if _driver != null:
		_driver.rebuild()
	_sync_slot_plus()
	_fit_dirty = true
	_refit_camera()

# Exposed for smoke: the bay must be laid out before projections work.
func bay_control() -> SubViewportContainer:
	return _bay

func bay_viewport() -> SubViewport:
	return _bay_viewport

func bay_camera() -> Camera3D:
	return _camera

func pose_driver() -> HangarPoseDriver:
	return _driver

# Exposed for smoke: framing contract (bounds inside the safe rect),
# zoom state and the motionless-at-rest guarantee.
func fit_safe_rect() -> Rect2:
	if _bay_viewport == null:
		return Rect2(0.0, 0.0, -1.0, -1.0)
	return _safe_rect(Vector2(_bay_viewport.size))

func projected_bounds_rect() -> Rect2:
	if _camera == null or _driver == null:
		return Rect2(0.0, 0.0, -1.0, -1.0)
	return _project_rect(_bounds_corners(_driver.selected_bounds()))

func fit_distance() -> float:
	return _fit_distance

func view_distance() -> float:
	return _view_distance

func zoom_level() -> float:
	return _zoom
