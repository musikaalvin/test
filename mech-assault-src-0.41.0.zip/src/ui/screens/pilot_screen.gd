class_name PilotScreen
extends UiScreen

# Crew workspace: owned-pilot roster on the left (tap to assign to the
# selected robot), full pilot detail on the right — portrait, level/xp,
# signature pairing, skill tier and the seven trainable skill rows.
# Ported from the old PilotPopup panel.

var _portrait: ItemPreview
var _roster_rows: VBoxContainer
var _name: Label
var _level: Label
var _signature: Label
var _xp_fill: ColorRect
var _xp_text: Label
var _tier_text: Label
var _tier_button: Button
var _skill_labels: Array[Label] = []
var _skill_infos: Array[Label] = []
var _skill_buttons: Array[Button] = []
var _select_label: Label

func _build() -> void:
	add_child(UiParts.backdrop(0.97))
	_build_header()
	_build_body()

func _build_header() -> void:
	var header := Control.new()
	header.name = "Header"
	header.anchor_left = 0.0
	header.anchor_top = 0.0
	header.anchor_right = 1.0
	header.anchor_bottom = 0.0
	header.offset_left = 18.0
	header.offset_top = 64.0
	header.offset_right = -18.0
	header.offset_bottom = 112.0
	header.mouse_filter = Control.MOUSE_FILTER_PASS
	add_child(header)

	var row := UiParts.header_row("PILOT", back)
	row.anchor_left = 0.0
	row.anchor_top = 0.0
	row.anchor_right = 1.0
	row.anchor_bottom = 1.0
	header.add_child(row)
	var title := row.get_node_or_null("ScreenTitle") as Label
	if title != null:
		title.size_flags_horizontal = Control.SIZE_EXPAND_FILL
		title.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	_portrait = ItemPreview.new()
	_portrait.name = "PilotPortrait"
	_portrait.custom_minimum_size = Vector2(76.0, 61.0)
	row.add_child(_portrait)

func _build_body() -> void:
	var columns := UiParts.hbox(18.0)
	columns.name = "PilotColumns"
	columns.anchor_left = 0.0
	columns.anchor_top = 0.0
	columns.anchor_right = 1.0
	columns.anchor_bottom = 1.0
	columns.offset_left = 18.0
	columns.offset_top = 124.0
	columns.offset_right = -18.0
	columns.offset_bottom = -20.0
	columns.mouse_filter = Control.MOUSE_FILTER_PASS
	add_child(columns)

	var left := UiParts.vbox(6.0)
	left.name = "PilotRoster"
	left.custom_minimum_size = Vector2(300.0, 0.0)
	left.size_flags_vertical = Control.SIZE_EXPAND_FILL
	columns.add_child(left)
	left.add_child(UiParts.section("YOUR CREW"))
	var roster_scroll := UiParts.scroll()
	roster_scroll.name = "PilotRosterScroll"
	roster_scroll.size_flags_vertical = Control.SIZE_EXPAND_FILL
	roster_scroll.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	left.add_child(roster_scroll)
	_roster_rows = UiParts.vbox(6.0)
	_roster_rows.name = "PilotRosterRows"
	_roster_rows.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	roster_scroll.add_child(_roster_rows)

	var detail_scroll := UiParts.scroll()
	detail_scroll.name = "PilotDetailScroll"
	detail_scroll.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	detail_scroll.size_flags_vertical = Control.SIZE_EXPAND_FILL
	columns.add_child(detail_scroll)
	var detail := UiParts.vbox(7.0)
	detail.name = "PilotDetail"
	detail.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	detail_scroll.add_child(detail)

	_name = UiParts.label("", 24, UiTheme.AMBER, true)
	_name.name = "PilotName"
	detail.add_child(_name)
	_level = UiParts.label("", 14, UiTheme.TEXT)
	_level.name = "PilotLevel"
	detail.add_child(_level)
	_signature = UiParts.label("", 12, UiTheme.MUTED)
	_signature.name = "PilotSignature"
	_signature.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	detail.add_child(_signature)

	var xp_bar := Panel.new()
	xp_bar.name = "PilotXpBar"
	xp_bar.add_theme_stylebox_override("panel", UiTheme.bar_bg())
	xp_bar.custom_minimum_size = Vector2(0.0, 12.0)
	xp_bar.mouse_filter = Control.MOUSE_FILTER_IGNORE
	var xp_fill := ColorRect.new()
	xp_fill.name = "Fill"
	xp_fill.color = UiTheme.CYAN
	xp_fill.anchor_right = 0.05
	xp_fill.anchor_bottom = 1.0
	xp_fill.mouse_filter = Control.MOUSE_FILTER_IGNORE
	xp_bar.add_child(xp_fill)
	_xp_fill = xp_fill
	detail.add_child(xp_bar)
	_xp_text = UiParts.label("", 12, UiTheme.MUTED)
	_xp_text.name = "PilotXpText"
	detail.add_child(_xp_text)

	var tier_row := UiParts.hbox(10.0)
	tier_row.name = "PilotTierRow"
	detail.add_child(tier_row)
	_tier_text = UiParts.label("", 15, UiTheme.TEXT, true)
	_tier_text.name = "PilotTierText"
	_tier_text.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	_tier_text.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
	tier_row.add_child(_tier_text)
	_tier_button = UiParts.button("TIER UP", UiTheme.HEALTH, 14,
			Vector2(210.0, 44.0))
	_tier_button.name = "PilotTierButton"
	UiParts.wire(_tier_button, _on_tier_pressed)
	tier_row.add_child(_tier_button)

	detail.add_child(UiParts.divider())

	for index in GameState.PILOT_SKILL_NAMES.size():
		var row := UiParts.hbox(10.0)
		row.name = "SkillRow%d" % index
		detail.add_child(row)
		var text_column := UiParts.vbox(2.0)
		text_column.name = "SkillText"
		text_column.size_flags_horizontal = Control.SIZE_EXPAND_FILL
		row.add_child(text_column)
		var name_label := UiParts.label(GameState.PILOT_SKILL_NAMES[index],
				14, UiTheme.TEXT, true)
		name_label.name = "SkillName%d" % index
		text_column.add_child(name_label)
		_skill_labels.append(name_label)
		var info_label := UiParts.label(GameState.PILOT_SKILL_DESC[index],
				11, UiTheme.MUTED)
		info_label.name = "SkillInfo%d" % index
		info_label.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
		text_column.add_child(info_label)
		_skill_infos.append(info_label)
		var train_button := UiParts.button("TRAIN", UiTheme.CYAN, 13,
				Vector2(168.0, 44.0))
		train_button.name = "TrainButton%d" % index
		UiParts.wire(train_button, _on_train_pressed.bind(index))
		row.add_child(train_button)
		_skill_buttons.append(train_button)

	var selector := UiParts.hbox(10.0)
	selector.name = "PilotSelector"
	detail.add_child(selector)
	var prev_button := UiParts.button("<", UiTheme.CYAN, 20, Vector2(52.0, 44.0))
	prev_button.name = "PilotPrevButton"
	UiParts.wire(prev_button, _on_cycle_pressed.bind(-1))
	selector.add_child(prev_button)
	_select_label = UiParts.label("", 15, UiTheme.TEXT, true)
	_select_label.name = "PilotSelectLabel"
	_select_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	_select_label.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
	_select_label.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	selector.add_child(_select_label)
	var next_button := UiParts.button(">", UiTheme.CYAN, 20, Vector2(52.0, 44.0))
	next_button.name = "PilotNextButton"
	UiParts.wire(next_button, _on_cycle_pressed.bind(1))
	selector.add_child(next_button)

func refresh() -> void:
	if _name == null:
		return
	var defs := GameState.PILOT_DEFS
	var pilot_id := _pilot_id_or_first()
	if pilot_id.is_empty():
		return
	var definition := GameState.pilot_def(pilot_id)
	var state := GameState.pilot_state(pilot_id)
	_portrait.set_pilot(pilot_id)
	var level := int(state.get("level", 1))
	var tier := int(state.get("tier", 1))
	var rarity := int(definition.get("rarity", 1))
	var rarity_label: String = ["", "STANDARD", "ELITE", "LEGENDARY"][
			clampi(rarity, 0, 3)]
	_name.text = "%s  ·  %s  ·  %s" % [
			String(definition.get("name", "PILOT")),
			String(definition.get("klass", "")), rarity_label]
	_level.text = "LEVEL %d / %d   ·   OWNED %d / %d" % [
			level, GameState.PILOT_MAX_LEVEL,
			GameState.owned_pilots.size(), GameState.PILOT_DEFS.size()]
	var sig_robot := String(definition.get("sig_robot", ""))
	if sig_robot.is_empty():
		_signature.text = "STANDARD PILOT — works on any robot"
		_signature.add_theme_color_override("font_color", UiTheme.MUTED)
	else:
		var matched := sig_robot == String(GameState.selected_robot)
		var robot_name := String(GameState.robot_def(
				StringName(sig_robot)).get("name", sig_robot))
		_signature.text = ("SPECIALIST OF %s — FULL POTENTIAL HERE" if matched
				else "SPECIALIST OF %s — pair to unlock full potential") % robot_name
		_signature.add_theme_color_override("font_color",
				UiTheme.AMBER if matched else UiTheme.MUTED)
	var need := GameState.pilot_xp_need(level)
	var xp := int(state.get("xp", 0))
	if level >= GameState.PILOT_MAX_LEVEL:
		_xp_fill.anchor_right = 1.0
		_xp_text.text = "MAX LEVEL"
	else:
		_xp_fill.anchor_right = clampf(float(xp) / float(maxi(need, 1)), 0.03, 1.0)
		_xp_text.text = "XP  %d / %d" % [xp, need]
	var max_tier := GameState.pilot_max_tier(pilot_id)
	_tier_text.text = "SKILL TIER   T%d / T%d" % [tier, max_tier]
	var tier_cost := GameState.pilot_tier_cost(pilot_id)
	if tier_cost <= 0:
		_tier_button.text = "MAX TIER"
		_tier_button.disabled = true
	else:
		_tier_button.text = "TIER UP · %d MEMOR" % tier_cost
		_tier_button.disabled = GameState.memorium < tier_cost
	var index := 0
	for def_index in defs.size():
		if String(defs[def_index].get("id", "")) == pilot_id:
			index = def_index
			break
	_select_label.text = "%s  ·  PILOT %d / %d  ·  %s" % [
			String(definition.get("name", "PILOT")), index + 1, defs.size(),
			"ASSIGNED" if GameState.assigned_pilot(
				GameState.selected_robot) == pilot_id else "NOT ASSIGNED"]
	for skill_index in GameState.PILOT_SKILL_NAMES.size():
		var unlocked := GameState.pilot_skill_unlocked(pilot_id, skill_index)
		var skill_level := GameState.pilot_skill_level(pilot_id, skill_index)
		_skill_labels[skill_index].text = "%s  ·  LV %d / 10" % [
				GameState.PILOT_SKILL_NAMES[skill_index], skill_level]
		if not unlocked:
			_skill_infos[skill_index].text = "UNLOCKS AT PILOT LV %d" % \
					GameState.PILOT_SLOT_LEVELS[skill_index]
		else:
			_skill_infos[skill_index].text = GameState.PILOT_SKILL_DESC[skill_index]
		var button := _skill_buttons[skill_index]
		if not unlocked:
			button.text = "LOCKED"
			button.disabled = true
		elif skill_level >= 10:
			button.text = "MAXED"
			button.disabled = true
		else:
			var cost := GameState.pilot_skill_cost(pilot_id, skill_index)
			button.text = "TRAIN · %d MEMOR" % cost
			button.disabled = GameState.memorium < cost
	_rebuild_roster()

func _rebuild_roster() -> void:
	for old in _roster_rows.get_children():
		# Unlink first so a rebuild during the chip's own pressed signal
		# neither double-lists old chips nor frees a locked object.
		_roster_rows.remove_child(old)
		old.queue_free()
	var assigned := GameState.assigned_pilot(GameState.selected_robot)
	for owned_id in GameState.owned_pilots:
		var owned_def := GameState.pilot_def(owned_id)
		var owned_chip := UiParts.button("%s  ·  LV %d" % [
				String(owned_def.get("name", owned_id)),
				int(GameState.pilot_state(owned_id).get("level", 1))],
				UiTheme.AMBER if assigned == owned_id else UiTheme.STEEL, 15)
		owned_chip.name = "PilotRoster_%s" % owned_id
		owned_chip.custom_minimum_size = Vector2(0.0, 50.0)
		owned_chip.alignment = HORIZONTAL_ALIGNMENT_LEFT
		UiParts.wire(owned_chip, _on_roster_pressed.bind(owned_id))
		_roster_rows.add_child(owned_chip)

func _pilot_id_or_first() -> String:
	var pilot_id := GameState.assigned_pilot(GameState.selected_robot)
	if not pilot_id.is_empty():
		return pilot_id
	var defs := GameState.PILOT_DEFS
	if defs.is_empty():
		return ""
	return String(defs[0].get("id", ""))

func _on_roster_pressed(pilot_id: String) -> void:
	GameState.assign_pilot(GameState.selected_robot, pilot_id)
	manager.refresh()

func _on_cycle_pressed(direction: int) -> void:
	# Only owned pilots can sit in a slot; the rest are bought in the store.
	var roster: Array[String] = []
	for def in GameState.PILOT_DEFS:
		if GameState.owns_pilot(String(def.get("id", ""))):
			roster.append(String(def.get("id", "")))
	if roster.is_empty():
		return
	var current := GameState.assigned_pilot(GameState.selected_robot)
	var index := 0
	for owned_index in roster.size():
		if roster[owned_index] == current:
			index = owned_index
			break
	index = (index + direction + roster.size()) % roster.size()
	GameState.assign_pilot(GameState.selected_robot, roster[index])
	manager.refresh()

func _on_train_pressed(skill_index: int) -> void:
	var pilot_id := GameState.assigned_pilot(GameState.selected_robot)
	if pilot_id.is_empty():
		manager.toast("NO PILOT ASSIGNED", true)
		return
	if GameState.train_pilot_skill(pilot_id, skill_index):
		manager.toast("%s TRAINED" % GameState.PILOT_SKILL_NAMES[skill_index])
	elif GameState.memorium < GameState.pilot_skill_cost(pilot_id, skill_index):
		manager.toast("NOT ENOUGH MEMORIUM", true)
	else:
		manager.toast("SKILL LOCKED OR MAXED", true)
	manager.refresh()

func _on_tier_pressed() -> void:
	var pilot_id := GameState.assigned_pilot(GameState.selected_robot)
	if pilot_id.is_empty():
		manager.toast("NO PILOT ASSIGNED", true)
		return
	if GameState.upgrade_pilot_tier(pilot_id):
		manager.toast("SKILL TIER UPGRADED")
	elif GameState.pilot_tier_cost(pilot_id) <= 0:
		manager.toast("MAX TIER REACHED", true)
	else:
		manager.toast("NOT ENOUGH MEMORIUM", true)
	manager.refresh()
