class_name UpgradeScreen
extends UiScreen

# MK/lv upgrade workspace: current vs next stat columns, the real cost
# with wallet, one confirm button (disabled while maxed or unaffordable).
# Works for hull keys ("robot:body"), normal weapons and titan ladders.

var _title: Label
var _ladder: HBoxContainer
var _current_panel: Panel
var _next_panel: Panel
var _current_state: Label
var _next_state: Label
var _current_stats: VBoxContainer
var _next_stats: VBoxContainer
var _cost_caption: Label
var _cost_value: Label
var _wallet_value: Label
var _confirm: Button

var _key: String = ""
var _is_body: bool = false

func _build() -> void:
	add_child(UiParts.backdrop(0.97))
	_build_header()
	_build_ladder()
	_build_columns()
	_build_cost_bar()

func _build_header() -> void:
	var header := Control.new()
	header.name = "Header"
	header.anchor_left = 0.0
	header.anchor_top = 0.0
	header.anchor_right = 1.0
	header.anchor_bottom = 0.0
	header.offset_left = 18.0
	header.offset_top = 64.0
	header.offset_right = -18.0
	header.offset_bottom = 112.0
	header.mouse_filter = Control.MOUSE_FILTER_PASS
	add_child(header)

	var row := UiParts.header_row("UPGRADE", back)
	row.anchor_left = 0.0
	row.anchor_top = 0.0
	row.anchor_right = 1.0
	row.anchor_bottom = 1.0
	header.add_child(row)
	_title = row.get_node_or_null("ScreenTitle") as Label

func _build_ladder() -> void:
	var bar := Panel.new()
	bar.name = "LadderPanel"
	bar.anchor_left = 0.0
	bar.anchor_right = 1.0
	bar.anchor_top = 0.0
	bar.anchor_bottom = 0.0
	bar.offset_left = 18.0
	bar.offset_right = -18.0
	bar.offset_top = 116.0
	bar.offset_bottom = 172.0
	bar.add_theme_stylebox_override("panel", UiTheme.panel(0.86))
	add_child(bar)

	_ladder = UiParts.hbox(10.0)
	_ladder.name = "LadderRow"
	_ladder.anchor_left = 0.0
	_ladder.anchor_top = 0.0
	_ladder.anchor_right = 1.0
	_ladder.anchor_bottom = 1.0
	_ladder.offset_left = 14.0
	_ladder.offset_top = 6.0
	_ladder.offset_right = -14.0
	_ladder.offset_bottom = -6.0
	_ladder.size_flags_vertical = Control.SIZE_SHRINK_CENTER
	bar.add_child(_ladder)

func _build_columns() -> void:
	var body := UiParts.hbox(18.0)
	body.name = "CompareBody"
	body.anchor_left = 0.0
	body.anchor_top = 0.0
	body.anchor_right = 1.0
	body.anchor_bottom = 1.0
	body.offset_left = 18.0
	body.offset_top = 184.0
	body.offset_right = -18.0
	body.offset_bottom = -104.0
	body.mouse_filter = Control.MOUSE_FILTER_PASS
	add_child(body)

	_current_panel = _make_column(body, "CURRENT", UiTheme.STEEL)
	_current_state = _current_panel.get_node_or_null(
			"Column/StateLine") as Label
	_current_stats = _current_panel.get_node_or_null(
			"Column/StatRows") as VBoxContainer

	_next_panel = _make_column(body, "NEXT", UiTheme.AMBER)
	_next_state = _next_panel.get_node_or_null("Column/StateLine") as Label
	_next_stats = _next_panel.get_node_or_null("Column/StatRows") as VBoxContainer

func _make_column(parent: Control, caption: String, accent: Color) -> Panel:
	var panel := Panel.new()
	panel.name = "%sPanel" % caption
	panel.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	panel.add_theme_stylebox_override("panel", UiTheme.panel(0.88, accent))
	parent.add_child(panel)

	var column := UiParts.vbox(10.0)
	column.name = "Column"
	column.anchor_left = 0.0
	column.anchor_top = 0.0
	column.anchor_right = 1.0
	column.anchor_bottom = 1.0
	column.offset_left = 18.0
	column.offset_top = 16.0
	column.offset_right = -18.0
	column.offset_bottom = -16.0
	panel.add_child(column)

	column.add_child(UiParts.section(caption))
	var state_line := UiParts.label("—", 16, accent, true)
	state_line.name = "StateLine"
	column.add_child(state_line)
	var stats := UiParts.vbox(8.0)
	stats.name = "StatRows"
	column.add_child(stats)
	return panel

func _build_cost_bar() -> void:
	var bar := Panel.new()
	bar.name = "CostBar"
	bar.anchor_left = 0.0
	bar.anchor_right = 1.0
	bar.anchor_top = 1.0
	bar.anchor_bottom = 1.0
	bar.offset_left = 18.0
	bar.offset_right = -18.0
	bar.offset_top = -92.0
	bar.offset_bottom = -16.0
	bar.add_theme_stylebox_override("panel", UiTheme.panel(0.92))
	add_child(bar)

	var row := UiParts.hbox(14.0)
	row.name = "CostRow"
	row.anchor_left = 0.0
	row.anchor_top = 0.0
	row.anchor_right = 1.0
	row.anchor_bottom = 1.0
	row.offset_left = 16.0
	row.offset_top = 8.0
	row.offset_right = -16.0
	row.offset_bottom = -8.0
	row.size_flags_vertical = Control.SIZE_SHRINK_CENTER
	bar.add_child(row)

	var cost_column := UiParts.vbox(2.0)
	cost_column.name = "CostColumn"
	cost_column.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	cost_column.mouse_filter = Control.MOUSE_FILTER_IGNORE
	row.add_child(cost_column)
	_cost_caption = UiParts.label("COST", 11, UiTheme.MUTED)
	_cost_caption.name = "CostCaption"
	cost_column.add_child(_cost_caption)
	_cost_value = UiParts.label("—", 17, UiTheme.TEXT, true)
	_cost_value.name = "CostValue"
	cost_column.add_child(_cost_value)

	var wallet_column := UiParts.vbox(2.0)
	wallet_column.name = "WalletColumn"
	wallet_column.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	wallet_column.mouse_filter = Control.MOUSE_FILTER_IGNORE
	row.add_child(wallet_column)
	var wallet_caption := UiParts.label("WALLET", 11, UiTheme.MUTED)
	wallet_caption.name = "WalletCaption"
	wallet_column.add_child(wallet_caption)
	_wallet_value = UiParts.label("—", 15, UiTheme.MUTED)
	_wallet_value.name = "WalletValue"
	wallet_column.add_child(_wallet_value)

	_confirm = UiParts.button("UPGRADE", Color(0.36, 0.86, 0.55), 18,
			Vector2(320.0, 60.0))
	_confirm.name = "ConfirmButton"
	_confirm.size_flags_vertical = Control.SIZE_SHRINK_CENTER
	UiParts.wire(_confirm, _confirm_pressed)
	row.add_child(_confirm)

func open(params: Dictionary = {}) -> void:
	_key = str(params.get("key", ""))
	_is_body = bool(params.get("is_body", false))

func on_enter() -> void:
	refresh()

func refresh() -> void:
	if _title == null or _key.is_empty():
		return

	var parts := _key.split(":", false, 2)
	var robot_id := StringName(parts[0]) if parts.size() >= 2 \
			else GameState.selected_robot
	var definition := GameState.robot_def(robot_id)
	var subject := String(definition.get("name", "MECH"))
	var item := ""
	if not _is_body and parts.size() == 2:
		item = GameState.equipped_item(robot_id, int(parts[1]))
		if not item.is_empty():
			subject = item
	_title.text = "%s  //  %s" % ["HULL" if _is_body else "WEAPON", subject]

	var class_kind := GameState.upgrade_class(_key)
	var state := GameState.upgrade_state(_key)
	var level_cap := GameState.upgrade_level_cap(_key)
	var mk_cap := GameState.upgrade_mk_cap(_key)

	# MK ladder chips (standard ladders only; titan ladders are one run).
	for child in _ladder.get_children():
		_ladder.remove_child(child)
		child.queue_free()
	if class_kind == GameState.UpgradeClass.STANDARD:
		for mk in GameState.MK_MAX:
			var chip := UiParts.button("MK%d" % (mk + 1), UiTheme.CYAN, 15,
					Vector2(120.0, 44.0))
			chip.name = "MkChip%d" % (mk + 1)
			chip.disabled = (mk + 1) > state.x
			_ladder.add_child(chip)
	else:
		var ladder_label := UiParts.label(
				"LV %d → %d" % [state.y, level_cap], 15, UiTheme.AMBER, true)
		ladder_label.name = "TitanLadder"
		ladder_label.size_flags_vertical = Control.SIZE_SHRINK_CENTER
		_ladder.add_child(ladder_label)

	_current_state.text = _state_label(state, level_cap, mk_cap)
	_fill_stats(_current_stats, robot_id, item, state, true)

	var maxed := state.y >= level_cap and state.x >= mk_cap
	var next := state
	if not maxed:
		if state.y >= level_cap:
			next = Vector2i(state.x + 1, 1)
		else:
			next = Vector2i(state.x, state.y + 1)
	if maxed:
		_next_state.text = "MAXIMUM"
		_next_panel.add_theme_stylebox_override("panel", UiTheme.panel(0.88,
				UiTheme.STEEL))
	else:
		_next_state.text = _state_label(next, level_cap, mk_cap)
		_next_panel.add_theme_stylebox_override("panel", UiTheme.panel(0.88,
				UiTheme.AMBER))
	_fill_stats(_next_stats, robot_id, item, next, false)

	var cost := GameState.upgrade_cost(_key)
	var cost_maxed := bool(cost["maxed"])
	var cost_text := ""
	if cost_maxed:
		cost_text = "MAXED"
	else:
		var pieces: Array[String] = []
		if int(cost["silver"]) > 0:
			pieces.append("%s SILVER" % UiParts.money(int(cost["silver"])))
		if int(cost["gold"]) > 0:
			pieces.append("%s GOLD" % UiParts.money(int(cost["gold"])))
		if int(cost["parts"]) > 0:
			pieces.append("%s PARTS" % UiParts.money(int(cost["parts"])))
		if int(cost["platinum"]) > 0:
			pieces.append("%s PLATINUM" % UiParts.money(int(cost["platinum"])))
		if pieces.is_empty():
			cost_text = "FREE"
		else:
			cost_text = "  +  ".join(pieces)
	_cost_caption.text = "COST  //  %s" % ("COMPLETE" if cost_maxed else "NEXT LEVEL")
	_cost_value.text = cost_text

	_wallet_value.text = "%s SILVER   ·   %s GOLD   ·   %s PARTS   ·   %s PT" % [
			UiParts.money(GameState.silver),
			UiParts.money(GameState.gold),
			UiParts.money(GameState.spare_parts),
			UiParts.money(GameState.platinum)]

	if cost_maxed:
		_confirm.text = "MAXED"
		_confirm.disabled = true
	else:
		_confirm.text = "UPGRADE"
		_confirm.disabled = not _can_afford(cost)

func _state_label(state: Vector2i, level_cap: int, mk_cap: int) -> String:
	if mk_cap <= 1:
		return "LV %d / %d" % [state.y, level_cap]
	return "MK%d   ·   LV %d / %d" % [state.x, state.y, level_cap]

func _fill_stats(column: VBoxContainer, robot_id: StringName, item: String,
		state: Vector2i, is_current: bool) -> void:
	for child in column.get_children():
		column.remove_child(child)
		child.queue_free()

	var key := _key
	if _is_body:
		var base_armor := float(GameState.robot_def(robot_id).get("armor", 200.0))
		var mult := GameState.body_mult_at(key, state)
		var caption := "ARMOR" if is_current else "ARMOR →"
		column.add_child(_value_row(caption,
				GameState.fmt_amount(base_armor * mult)))
		column.add_child(_value_row("DURABILITY ×",
				"%.3f" % mult))
		return

	if item.is_empty():
		column.add_child(_value_row("STATUS", "NO WEAPON MOUNTED"))
		return
	var weapon := GameState.weapon_for_item(item) as WeaponData
	if weapon == null:
		return
	var damage_mult := GameState.weapon_damage_mult_at(key, state)
	var perf_mult := GameState.weapon_performance_mult_at(key, state)
	var suffix := "" if is_current else " →"
	column.add_child(_value_row("DAMAGE%s" % suffix,
			GameState.fmt_amount(weapon.damage * damage_mult)))
	column.add_child(_value_row("RATE%s" % suffix,
			"%d RPM" % int(roundf(weapon.shots_per_minute * perf_mult))))
	column.add_child(_value_row("HEAT / SHOT%s" % suffix,
			"%.3f" % (weapon.heat_per_shot / perf_mult)))
	column.add_child(_value_row("DAMAGE ×", "%.3f" % damage_mult))

func _value_row(caption: String, value: String) -> HBoxContainer:
	var row := UiParts.hbox(8.0)
	row.name = "ValueRow"
	var caption_label := UiParts.label(caption, 14, UiTheme.MUTED)
	caption_label.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	row.add_child(caption_label)
	var value_label := UiParts.label(value, 15, UiTheme.TEXT, true)
	row.add_child(value_label)
	return row

func _can_afford(cost: Dictionary) -> bool:
	if int(cost["silver"]) > 0 and GameState.silver < int(cost["silver"]):
		return false
	if int(cost["gold"]) > 0 and GameState.gold < int(cost["gold"]):
		return false
	if int(cost["parts"]) > 0 and GameState.spare_parts < int(cost["parts"]):
		return false
	if int(cost["platinum"]) > 0 and GameState.platinum < int(cost["platinum"]):
		return false
	return true

func _confirm_pressed() -> void:
	if GameState.perform_upgrade(_key):
		manager.toast("UPGRADE COMPLETE")
		manager.refresh()
	else:
		manager.toast("NOT ENOUGH RESOURCES", true)
