class_name DroneScreen
extends UiScreen

# Drone bay: one row per drone definition — buy with microchips, equip
# to the selected robot, or upgrade its level (break points at lv 4 / 9).
# Ported from the old DronePopup panel.

const UPGRADE_ACCENT := Color(0.36, 0.86, 0.55)

var _wallet: Label
var _rows_box: VBoxContainer

func _build() -> void:
	add_child(UiParts.backdrop(0.97))
	_build_header()
	_build_body()

func _build_header() -> void:
	var header := Control.new()
	header.name = "Header"
	header.anchor_left = 0.0
	header.anchor_top = 0.0
	header.anchor_right = 1.0
	header.anchor_bottom = 0.0
	header.offset_left = 18.0
	header.offset_top = 64.0
	header.offset_right = -18.0
	header.offset_bottom = 112.0
	header.mouse_filter = Control.MOUSE_FILTER_PASS
	add_child(header)

	var row := UiParts.header_row("DRONES", back)
	row.anchor_left = 0.0
	row.anchor_top = 0.0
	row.anchor_right = 1.0
	row.anchor_bottom = 1.0
	header.add_child(row)
	var title := row.get_node_or_null("ScreenTitle") as Label
	if title != null:
		title.size_flags_horizontal = Control.SIZE_EXPAND_FILL
		title.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER

func _build_body() -> void:
	var body := UiParts.vbox(7.0)
	body.name = "DroneBody"
	body.anchor_left = 0.0
	body.anchor_top = 0.0
	body.anchor_right = 1.0
	body.anchor_bottom = 1.0
	body.offset_left = 18.0
	body.offset_top = 124.0
	body.offset_right = -18.0
	body.offset_bottom = -20.0
	body.mouse_filter = Control.MOUSE_FILTER_PASS
	add_child(body)

	_wallet = UiParts.label("", 13, UiTheme.AMBER, true)
	_wallet.name = "DroneWallet"
	body.add_child(_wallet)

	var hint := UiParts.label(
			"Combat companion with its own weapon · one active at a time · "
			+ "emergency repair at critical HP · break points at lv 4 / lv 9",
			11, UiTheme.MUTED)
	hint.name = "DroneHint"
	hint.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	body.add_child(hint)

	var scroll := UiParts.scroll()
	scroll.name = "DroneRowsScroll"
	scroll.size_flags_vertical = Control.SIZE_EXPAND_FILL
	scroll.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	body.add_child(scroll)
	_rows_box = UiParts.vbox(6.0)
	_rows_box.name = "DroneRows"
	_rows_box.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	scroll.add_child(_rows_box)

func refresh() -> void:
	if _wallet == null:
		return
	var active_drone := GameState.drone_for_robot(GameState.selected_robot)
	_wallet.text = "MICROCHIPS  %d   ·   %s DRONE  %s" % [
			GameState.microchips,
			String(GameState.robot_def().get("name", "MECH")),
			active_drone.to_upper() if not active_drone.is_empty() else "NONE"]
	for child in _rows_box.get_children():
		_rows_box.remove_child(child)
		child.queue_free()
	for definition in GameState.DRONE_DEFS:
		_rows_box.add_child(_make_row(definition, active_drone))

func _make_row(definition: Dictionary, active_drone: String) -> Panel:
	var drone_id := String(definition.get("id", ""))
	var owned := GameState.owns_drone(drone_id)
	var level := GameState.drone_level(drone_id)
	var row := Panel.new()
	row.name = "DroneRow_%s" % drone_id
	row.custom_minimum_size = Vector2(0.0, 78.0)
	row.add_theme_stylebox_override("panel", UiTheme.panel(0.6, UiTheme.STEEL))

	var row_box := UiParts.hbox(10.0)
	row_box.name = "RowBox"
	row_box.anchor_left = 0.0
	row_box.anchor_top = 0.0
	row_box.anchor_right = 1.0
	row_box.anchor_bottom = 1.0
	row_box.offset_left = 12.0
	row_box.offset_top = 8.0
	row_box.offset_right = -12.0
	row_box.offset_bottom = -8.0
	row_box.size_flags_vertical = Control.SIZE_SHRINK_CENTER
	row.add_child(row_box)

	var text_column := UiParts.vbox(2.0)
	text_column.name = "Text"
	text_column.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	row_box.add_child(text_column)
	var name_label := UiParts.label("%s  ·  %s" % [
			String(definition.get("name", "")), String(definition.get("klass", ""))],
			15, UiTheme.TEXT, true)
	name_label.name = "DroneName"
	text_column.add_child(name_label)
	var desc_label := UiParts.label(String(definition.get("desc", "")),
			11, UiTheme.MUTED)
	desc_label.name = "DroneDesc"
	desc_label.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	text_column.add_child(desc_label)
	var state_label := UiParts.label("", 12, UiTheme.CYAN)
	state_label.name = "DroneState"
	text_column.add_child(state_label)
	if owned:
		state_label.text = "LV %d / %d%s" % [
				level, GameState.DRONE_MAX_LEVEL,
				"   ·   ACTIVE" if active_drone == drone_id else ""]
	else:
		state_label.text = "NOT OWNED"

	var action := UiParts.button("BUY", UiTheme.CYAN, 14, Vector2(140.0, 48.0))
	action.name = "DroneAction"
	row_box.add_child(action)
	if not owned:
		var cost := GameState.drone_buy_cost(drone_id)
		action.text = "BUY %d CHIPS" % cost
		action.disabled = GameState.microchips < cost
	elif GameState.is_titan():
		action.text = "TITAN"
		action.disabled = true
	elif active_drone == drone_id:
		action.text = "ACTIVE"
		action.disabled = true
	else:
		action.text = "EQUIP"
		action.disabled = false
	UiParts.wire(action, _on_action_pressed.bind(drone_id))

	if owned:
		var upgrade := UiParts.button("UPGRADE", UPGRADE_ACCENT, 13,
				Vector2(150.0, 48.0))
		upgrade.name = "DroneUpgrade"
		row_box.add_child(upgrade)
		var up_cost := GameState.drone_upgrade_cost(drone_id)
		if up_cost <= 0:
			upgrade.text = "MAX LEVEL"
			upgrade.disabled = true
		else:
			upgrade.text = "UPGRADE %d" % up_cost
			upgrade.disabled = GameState.microchips < up_cost
		UiParts.wire(upgrade, _on_upgrade_pressed.bind(drone_id))
	return row

func _on_action_pressed(drone_id: String) -> void:
	if GameState.is_titan():
		manager.toast("TITANS CARRY NO DRONE", true)
		manager.refresh()
		return
	if not GameState.owns_drone(drone_id):
		if GameState.buy_drone(drone_id):
			manager.toast("%s PURCHASED" % GameState.drone_def(drone_id).get(
					"name", drone_id.to_upper()))
		else:
			manager.toast("NOT ENOUGH MICROCHIPS", true)
		manager.refresh()
		return
	if GameState.drone_for_robot(GameState.selected_robot) == drone_id:
		return
	GameState.select_drone(drone_id)
	manager.toast("%s EQUIPPED TO %s" % [
			GameState.drone_def(drone_id).get("name", drone_id.to_upper()),
			String(GameState.robot_def().get("name", "MECH"))])
	# The hangar rig carries the drone orbit — rebuild it so the preview
	# flies the newly equipped drone.
	var hangar := manager.screen(&"hangar")
	if hangar != null and hangar.has_method("rebuild_bay"):
		hangar.call("rebuild_bay")
	manager.refresh()

func _on_upgrade_pressed(drone_id: String) -> void:
	if GameState.upgrade_drone(drone_id):
		manager.toast("%s UPGRADED TO LV %d" % [
				GameState.drone_def(drone_id).get("name", drone_id.to_upper()),
				GameState.drone_level(drone_id)])
	else:
		manager.toast("NOT ENOUGH MICROCHIPS", true)
	manager.refresh()
