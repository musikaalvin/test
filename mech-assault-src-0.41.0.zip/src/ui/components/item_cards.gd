class_name ItemCards
extends RefCounted

# Shared card rows for the store and inventory screens. One builder per
# item class (robot / weapon / pilot / drone) renders the same panel in
# both contexts: `from_inventory` switches the state line and action verb
# (BUY vs EQUIP, price vs stock), and every action/cancel path funnels
# through the Callables the hosting screen passes in. SELL rows live here
# too so both screens share one price / block / confirm path.
#
# Ported from the old main_menu monolith (_make_robot_card, _make_weapon_card,
# _make_pilot_store_row, _make_drone_store_row, _add_sell_controls).

enum SellKind { ITEM, ROBOT, PILOT, DRONE }

# ------------------------------------------------------------------ robots

static func robot_card(robot_id: StringName, from_inventory: bool,
		on_action: Callable, ui: UIManager) -> PanelContainer:
	var definition := GameState.robot_def(robot_id)
	var owned := GameState.owns_robot(robot_id)
	var selected := GameState.selected_robot == robot_id
	var row := PanelContainer.new()
	row.name = "StoreRobot_%s" % String(robot_id)
	row.add_theme_stylebox_override("panel", UiTheme.panel(0.6, UiTheme.STEEL))
	var row_box := UiParts.hbox(10.0)
	row_box.name = "RowBox"
	row.add_child(row_box)
	var preview := ItemPreview.new()
	preview.name = "RobotPreview"
	preview.custom_minimum_size = Vector2(128.0, 100.0)
	preview.size_flags_vertical = Control.SIZE_SHRINK_CENTER
	preview.set_robot(String(robot_id))
	row_box.add_child(preview)
	var col := UiParts.vbox(2.0)
	col.name = "Text"
	col.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	row_box.add_child(col)
	var name_label := UiParts.label("%s  ·  %s" % [
			String(definition.get("name", "")), String(definition.get("klass", ""))],
			16, UiTheme.TEXT, true)
	name_label.name = "RobotName"
	col.add_child(name_label)
	var stats := UiParts.label("ARMOR %s   ·   SPEED %.1f" % [
			GameState.fmt_amount(float(definition.get("armor", 0.0))),
			float(definition.get("speed", 0.0))], 11, UiTheme.MUTED)
	stats.name = "RobotStats"
	col.add_child(stats)
	var slot_parts: Array[String] = []
	for slot in GameState.robot_slots(robot_id):
		slot_parts.append(GameState.SLOT_LABELS[clampi(int(slot), 0, 4)].left(1))
	var slots_label := UiParts.label("SLOTS  %s" % " · ".join(slot_parts),
			11, UiTheme.MUTED)
	slots_label.name = "RobotSlots"
	col.add_child(slots_label)
	var stat3_label := String(definition.get("stat3_label", ""))
	if not stat3_label.is_empty():
		var stat3 := UiParts.label("%s  ·  %s" % [
				stat3_label, String(definition.get("stat3_value", ""))],
				11, UiTheme.STEEL, true)
		stat3.name = "RobotStat3"
		col.add_child(stat3)
	var ability_line := "ABILITY  %s" % String(definition.get("ability", ""))
	var secondary := String(definition.get("secondary", ""))
	if not secondary.is_empty():
		ability_line += "   +   %s" % secondary
	var ability_label := UiParts.label(ability_line, 12, UiTheme.AMBER, true)
	ability_label.name = "RobotAbility"
	col.add_child(ability_label)
	var ability_icons := UiParts.hbox(6.0)
	ability_icons.name = "AbilityIcons"
	col.add_child(ability_icons)
	ability_icons.add_child(UiParts.ability_chip(String(definition.get(
			"ability_short", "")), String(definition.get("ability_desc", ""))))
	if not secondary.is_empty():
		ability_icons.add_child(UiParts.ability_chip(String(definition.get(
				"secondary_short", "")), String(definition.get("secondary_desc", ""))))
	var desc := UiParts.label(String(definition.get("ability_desc", "")),
			10, UiTheme.MUTED)
	desc.name = "RobotAbilityDesc"
	desc.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	col.add_child(desc)
	if not String(definition.get("secondary_desc", "")).is_empty():
		var desc2 := UiParts.label(String(definition.get("secondary_desc", "")),
				10, UiTheme.MUTED)
		desc2.name = "RobotSecondaryDesc"
		desc2.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
		col.add_child(desc2)
	var builtin := String(definition.get("builtin", ""))
	if not builtin.is_empty():
		var builtin_label := UiParts.label("BUILT-IN  %s" % builtin,
				11, UiTheme.CYAN)
		builtin_label.name = "RobotBuiltin"
		col.add_child(builtin_label)
	var weapons_box := UiParts.vbox(1.0)
	weapons_box.name = "RobotWeapons"
	var card_loadout: Array = GameState.loadouts.get(
			robot_id, GameState._default_loadout(robot_id))
	for weapon_index in card_loadout.size():
		var weapon_id := String(card_loadout[weapon_index])
		if weapon_id.is_empty():
			continue
		var weapon_row := UiParts.label("%s   ·   %s" % [
				GameState.item_display_name(weapon_id),
				String(GameState.SLOT_LABELS[clampi(weapon_index, 0, 4)])],
				10, UiTheme.MUTED)
		weapon_row.name = "WeaponRow%d" % weapon_index
		weapons_box.add_child(weapon_row)
	col.add_child(weapons_box)
	var pair := UiParts.label(pairing_text(robot_id), 11, UiTheme.CYAN)
	pair.name = "RobotPair"
	col.add_child(pair)
	var state_row := UiParts.hbox(8.0)
	state_row.name = "StateRow"
	col.add_child(state_row)
	var state_label := UiParts.label("", 12, UiTheme.MUTED)
	state_label.name = "RobotState"
	state_label.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	state_row.add_child(state_label)
	if owned:
		var pad_caption := "IN STORAGE"
		var bay_slot := HangarSlots.assignment().find(robot_id)
		if bay_slot >= 0:
			pad_caption = slot_caption(bay_slot)
		var state_text := "OWNED   ·   %s" % pad_caption
		if selected:
			state_text += "   ·   SELECTED"
		state_label.text = state_text
		state_label.add_theme_color_override("font_color", UiTheme.CYAN)
	else:
		var cost := GameState.robot_buy_cost(robot_id)
		if GameState.robot_buy_currency(robot_id) == "plat":
			state_label.text = "%d PLATINUM" % cost
		else:
			state_label.text = "%s SILVER" % UiParts.money(cost)
		state_label.add_theme_color_override("font_color", UiTheme.AMBER)
	var action := Button.new()
	action.name = "RobotAction"
	action.custom_minimum_size = Vector2(128.0, 44.0)
	if from_inventory or owned:
		action.text = "SELECTED" if selected else "SELECT"
	else:
		action.text = "BUY"
	action.disabled = owned and selected
	UiTheme.apply_to_button(action, UiTheme.CYAN if owned else UiTheme.AMBER, 15)
	UiParts.wire(action, on_action)
	state_row.add_child(action)
	if owned:
		make_sell_controls(col, state_row, SellKind.ROBOT, robot_id, ui)
	return row

# ----------------------------------------------------------------- weapons

static func weapon_card(item_id: String, from_inventory: bool,
		on_action: Callable, ui: UIManager) -> PanelContainer:
	var data := WeaponData.for_item(item_id)
	var size := GameState.item_slot_size(item_id)
	var owned_count := GameState.pool_count(item_id)
	var row := PanelContainer.new()
	row.name = "StoreItem_%s" % item_id
	row.add_theme_stylebox_override("panel", UiTheme.panel(0.6, UiTheme.STEEL))
	var row_box := UiParts.hbox(10.0)
	row_box.name = "RowBox"
	row.add_child(row_box)
	var preview := ItemPreview.new()
	preview.name = "WeaponPreview"
	preview.custom_minimum_size = Vector2(128.0, 92.0)
	preview.size_flags_vertical = Control.SIZE_SHRINK_CENTER
	preview.set_weapon(item_id)
	row_box.add_child(preview)
	var col := UiParts.vbox(2.0)
	col.name = "Text"
	col.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	row_box.add_child(col)
	var name_label := UiParts.label(item_id, 15, UiTheme.TEXT, true)
	name_label.name = "ItemName"
	col.add_child(name_label)
	var kind_label := UiParts.label("%s  ·  %s SIZE" % [
			weapon_kind_label(data), GameState.SLOT_LABELS[clampi(size, 0, 4)]],
			11, UiTheme.MUTED)
	kind_label.name = "ItemKind"
	col.add_child(kind_label)
	var damage_line := "DMG %d" % int(data.damage)
	if data.pellets > 1:
		damage_line += " × %d" % data.pellets
	damage_line += "   ·   RPM %d" % int(data.shots_per_minute)
	var stats := UiParts.label(damage_line, 12, UiTheme.TEXT)
	stats.name = "ItemStats"
	col.add_child(stats)
	var special := weapon_special_text(data)
	if not special.is_empty():
		var special_label := UiParts.label(special, 11, UiTheme.AMBER)
		special_label.name = "ItemSpecial"
		col.add_child(special_label)
	var state_row := UiParts.hbox(8.0)
	state_row.name = "StateRow"
	col.add_child(state_row)
	var state_label := UiParts.label("", 12, UiTheme.MUTED)
	state_label.name = "ItemState"
	state_label.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	state_row.add_child(state_label)
	if from_inventory:
		var mounted := GameState.equipped_count(item_id)
		var free := GameState.free_copies(item_id)
		state_label.text = "STOCK %d   ·   MOUNTED %d   ·   OWNED ×%d" % [
				free, mounted, owned_count]
		state_label.add_theme_color_override("font_color",
				UiTheme.CYAN if free > 0 else UiTheme.STEEL)
	else:
		var cost := GameState.weapon_buy_cost(item_id)
		if GameState.weapon_buy_currency(item_id) == "plat":
			state_label.text = "%d PLATINUM   ·   OWNED ×%d" % [cost, owned_count]
		else:
			state_label.text = "%s SILVER   ·   OWNED ×%d" % [
					UiParts.money(cost), owned_count]
		state_label.add_theme_color_override("font_color", UiTheme.AMBER)
	var action := Button.new()
	action.name = "ItemBuy"
	action.custom_minimum_size = Vector2(110.0, 44.0)
	if from_inventory:
		action.text = "EQUIP"
		if GameState.free_copies(item_id) < 1:
			action.text = "ALL MOUNTED"
			action.disabled = true
			action.tooltip_text = "EVERY COPY IS ALREADY MOUNTED"
	else:
		action.text = "BUY"
	UiTheme.apply_to_button(action, UiTheme.CYAN if from_inventory
			else UiTheme.AMBER, 15)
	UiParts.wire(action, on_action)
	state_row.add_child(action)
	if from_inventory:
		make_sell_controls(col, state_row, SellKind.ITEM, item_id, ui)
	return row

static func weapon_kind_label(data: WeaponData) -> String:
	match data.kind:
		WeaponData.Kind.AUTOCANNON: return "AUTOCANNON"
		WeaponData.Kind.SCATTERGUN: return "SCATTERGUN"
		WeaponData.Kind.ELECTRIC: return "ELECTRIC ARC"
		WeaponData.Kind.MAGNETIC: return "MAGNETIC RAIL"
		WeaponData.Kind.BLAST: return "HOMING SHELL"
		WeaponData.Kind.CORROSION: return "CORROSIVE"
		WeaponData.Kind.BEAM: return "ENERGY BEAM"
		WeaponData.Kind.FLAME: return "FLAME"
		WeaponData.Kind.SALVO: return "SALVO"
		WeaponData.Kind.SONIC: return "SONIC"
	return "WEAPON"

static func weapon_special_text(data: WeaponData) -> String:
	var parts: Array[String] = []
	if data.splash_radius > 0.0:
		parts.append("SPLASH %.1f M" % data.splash_radius)
	if data.corrosion_dps > 0.0:
		parts.append("CORRODE %.1f/s" % data.corrosion_dps)
	if data.chain_bounces > 0:
		parts.append("CHAIN ×%d · %.0f M" % [data.chain_bounces, data.chain_range])
	if data.kind == WeaponData.Kind.ELECTRIC:
		parts.append("DMG +137% CLOSE")
	if data.slow_duration > 0.0:
		parts.append("SLOWS TARGET")
	if data.pellets > 1:
		parts.append("%d PELLETS" % data.pellets)
	return " · ".join(parts)

# ------------------------------------------------------------------ pilots

static func pilot_row(pilot_id: String, on_action: Callable,
		ui: UIManager) -> PanelContainer:
	var definition := GameState.pilot_def(pilot_id)
	var row := PanelContainer.new()
	row.name = "StorePilot_%s" % pilot_id
	row.add_theme_stylebox_override("panel", UiTheme.panel(0.6, UiTheme.STEEL))
	if definition.is_empty():
		return row
	var owned := GameState.owns_pilot(pilot_id)
	var rarity := int(definition.get("rarity", 1))
	var rarity_label: String = ["", "STANDARD", "ELITE", "LEGENDARY"][
			clampi(rarity, 0, 3)]
	var row_box := UiParts.hbox(10.0)
	row_box.name = "RowBox"
	row.add_child(row_box)
	var preview := ItemPreview.new()
	preview.name = "PilotPreview"
	preview.custom_minimum_size = Vector2(128.0, 96.0)
	preview.size_flags_vertical = Control.SIZE_SHRINK_CENTER
	preview.set_pilot(pilot_id)
	row_box.add_child(preview)
	var col := UiParts.vbox(2.0)
	col.name = "Text"
	col.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	row_box.add_child(col)
	var name_label := UiParts.label("%s  ·  %s  ·  %s" % [
			String(definition.get("name", "PILOT")),
			String(definition.get("klass", "")), rarity_label],
			16, UiTheme.TEXT, true)
	name_label.name = "PilotName"
	col.add_child(name_label)
	var sig_robot := String(definition.get("sig_robot", ""))
	var sig_text := "STANDARD — works on any robot" if sig_robot.is_empty() \
			else "SPECIALIST OF %s — full potential there" % String(
			GameState.robot_def(StringName(sig_robot)).get("name", sig_robot))
	var sig := UiParts.label(sig_text, 11, UiTheme.CYAN)
	sig.name = "PilotSignature"
	col.add_child(sig)
	# Legendary WR pilots carry their signature skill; show it in place of
	# the generic skill-track caption.
	var unique_skill := String(definition.get("unique", ""))
	var perks := UiParts.label(
			"SKILLS  HP · ARMOR · DMG · RATE · REPAIR · CDR · SPEED"
			if unique_skill.is_empty() else unique_skill,
			11, UiTheme.MUTED)
	perks.name = "PilotPerks"
	if not unique_skill.is_empty():
		perks.tooltip_text = unique_skill
	col.add_child(perks)
	var state_row := UiParts.hbox(8.0)
	state_row.name = "StateRow"
	col.add_child(state_row)
	var state_label := UiParts.label("", 12, UiTheme.MUTED)
	state_label.name = "PilotState"
	state_label.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	state_row.add_child(state_label)
	if owned:
		var assigned_to := robot_name_holding_pilot(pilot_id)
		state_label.text = "HIRED"
		if not assigned_to.is_empty():
			state_label.text += "   ·   %s" % assigned_to
		state_label.add_theme_color_override("font_color", UiTheme.CYAN)
	else:
		var cost := GameState.pilot_buy_cost(pilot_id)
		if GameState.pilot_buy_currency(pilot_id) == "gold":
			state_label.text = "%d GOLD" % cost
		else:
			state_label.text = "%s SILVER" % UiParts.money(cost)
		state_label.add_theme_color_override("font_color", UiTheme.AMBER)
	var action := Button.new()
	action.name = "PilotAction"
	action.text = "ASSIGN" if owned else "HIRE"
	action.custom_minimum_size = Vector2(120.0, 44.0)
	UiTheme.apply_to_button(action, UiTheme.CYAN if owned else UiTheme.AMBER, 15)
	UiParts.wire(action, on_action)
	state_row.add_child(action)
	if owned:
		make_sell_controls(col, state_row, SellKind.PILOT, pilot_id, ui)
	return row

static func robot_name_holding_pilot(pilot_id: String) -> String:
	for robot_id in GameState.ROBOT_ORDER:
		if GameState.assigned_pilot(robot_id) == pilot_id:
			return String(GameState.robot_def(robot_id).get("name",
					String(robot_id)))
	return ""

# ------------------------------------------------------------------ drones

static func drone_row(drone_id: String, on_action: Callable,
		on_upgrade: Callable, ui: UIManager) -> PanelContainer:
	var definition := GameState.drone_def(drone_id)
	var row := PanelContainer.new()
	row.name = "StoreDrone_%s" % drone_id
	row.add_theme_stylebox_override("panel", UiTheme.panel(0.6, UiTheme.STEEL))
	if definition.is_empty():
		return row
	var owned := GameState.owns_drone(drone_id)
	var titan := GameState.is_titan()
	var active := GameState.drone_for_robot(GameState.selected_robot) == drone_id
	var row_box := UiParts.hbox(10.0)
	row_box.name = "RowBox"
	row.add_child(row_box)
	var preview := ItemPreview.new()
	preview.name = "DronePreview"
	preview.custom_minimum_size = Vector2(128.0, 96.0)
	preview.size_flags_vertical = Control.SIZE_SHRINK_CENTER
	preview.set_drone(drone_id)
	row_box.add_child(preview)
	var col := UiParts.vbox(2.0)
	col.name = "Text"
	col.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	row_box.add_child(col)
	var name_label := UiParts.label("%s  ·  %s  ·  R%d" % [
			String(definition.get("name", "DRONE")),
			String(definition.get("klass", "")),
			int(definition.get("rarity", 1))], 16, UiTheme.TEXT, true)
	name_label.name = "DroneName"
	col.add_child(name_label)
	var desc := UiParts.label(String(definition.get("desc", "")), 11,
			UiTheme.MUTED)
	desc.name = "DroneDesc"
	desc.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	col.add_child(desc)
	var state_row := UiParts.hbox(8.0)
	state_row.name = "StateRow"
	col.add_child(state_row)
	var state_label := UiParts.label("", 12, UiTheme.MUTED)
	state_label.name = "DroneState"
	state_label.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	state_row.add_child(state_label)
	if not owned:
		state_label.text = "%d MICROCHIPS" % GameState.drone_buy_cost(drone_id)
		state_label.add_theme_color_override("font_color", UiTheme.AMBER)
	else:
		state_label.text = "LV %d / %d%s" % [
				GameState.drone_level(drone_id), GameState.DRONE_MAX_LEVEL,
				"   ·   ACTIVE" if active else ""]
		state_label.add_theme_color_override("font_color", UiTheme.CYAN)
	var action := Button.new()
	action.name = "DroneAction"
	action.custom_minimum_size = Vector2(132.0, 44.0)
	if not owned:
		action.text = "BUY"
		UiTheme.apply_to_button(action, UiTheme.AMBER, 15)
		action.disabled = GameState.microchips < GameState.drone_buy_cost(drone_id)
	elif titan:
		action.text = "TITAN"
		UiTheme.apply_to_button(action, UiTheme.STEEL, 15)
		action.disabled = true
	elif active:
		action.text = "ACTIVE"
		UiTheme.apply_to_button(action, UiTheme.STEEL, 15)
		action.disabled = true
	else:
		action.text = "EQUIP"
		UiTheme.apply_to_button(action, UiTheme.CYAN, 15)
	UiParts.wire(action, on_action)
	state_row.add_child(action)
	if owned:
		var upgrade := Button.new()
		upgrade.name = "DroneUpgrade"
		upgrade.custom_minimum_size = Vector2(140.0, 44.0)
		UiTheme.apply_to_button(upgrade, UiTheme.HEALTH, 13)
		var up_cost := GameState.drone_upgrade_cost(drone_id)
		if up_cost <= 0:
			upgrade.text = "MAX LEVEL"
			upgrade.disabled = true
		else:
			upgrade.text = "UPGRADE %d" % up_cost
			upgrade.disabled = GameState.microchips < up_cost
		UiParts.wire(upgrade, on_upgrade)
		state_row.add_child(upgrade)
		make_sell_controls(col, state_row, SellKind.DRONE, drone_id, ui)
	return row

# ----------------------------------------------------------- card actions

# Buy-or-select a robot from either card context (store and inventory share
# it), rebuild the bay pose and refresh the whole stack.
static func robot_action(robot_id: StringName, ui: UIManager) -> void:
	var display := String(GameState.robot_def(robot_id).get("name", "MECH"))
	if GameState.owns_robot(robot_id):
		GameState.select_robot(robot_id)
		_notify_selection(ui, display, "SELECTED")
		return
	if GameState.buy_robot(robot_id):
		GameState.select_robot(robot_id)
		_notify_selection(ui, display, "PURCHASED")
	else:
		var currency := "PLATINUM" if GameState.robot_buy_currency(
				robot_id) == "plat" else "SILVER"
		ui.toast("NOT ENOUGH %s" % currency, true)

static func _notify_selection(ui: UIManager, display: String,
		verb: String) -> void:
	var hangar := ui.screen(&"hangar")
	if hangar != null and hangar.has_method("rebuild_bay"):
		hangar.call("rebuild_bay")
	ui.toast("%s %s" % [display, verb])
	ui.refresh()

# ------------------------------------------------------------ sell system

# Every sellable class shares one price / block / confirm path: the SELL
# button arms an inline CONFIRM row, GameState keeps the actual guard
# rules, and the hosting screen refreshes through `ui` after a sale.
static func make_sell_controls(col: VBoxContainer, state_row: HBoxContainer,
		kind: SellKind, target: Variant, ui: UIManager) -> void:
	var price := sell_price(kind, target)
	if price <= 0:
		return
	var display := sell_display(kind, target)
	var reason := sell_block(kind, target)
	# The state row becomes the first line of a shell so the confirm prompt
	# can drop under it without disturbing anything above.
	var shell := UiParts.vbox(6.0)
	shell.name = "RowShell"
	col.remove_child(state_row)
	col.add_child(shell)
	shell.add_child(state_row)

	var sell_button := UiParts.button("SELL", UiTheme.DANGER, 15,
			Vector2(96.0, 44.0))
	sell_button.name = "SellButton"
	sell_button.tooltip_text = "FOR %s SILVER" % UiParts.money(price)
	if not reason.is_empty():
		sell_button.disabled = true
		sell_button.tooltip_text = "%s · %s" % [sell_button.tooltip_text, reason]
	sell_button.set_meta("sell_blocked", not reason.is_empty())
	UiParts.wire(sell_button, _sell_arm.bind(shell))
	state_row.add_child(sell_button)

	var confirm := UiParts.hbox(8.0)
	confirm.name = "SellConfirm"
	confirm.visible = false
	confirm.size_flags_vertical = Control.SIZE_SHRINK_CENTER
	shell.add_child(confirm)
	var prompt := UiParts.label("SELL %s FOR %s SILVER?" % [display,
			UiParts.money(price)], 11, UiTheme.DANGER, true)
	prompt.name = "SellPrompt"
	prompt.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	prompt.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	confirm.add_child(prompt)
	var confirm_button := UiParts.button("CONFIRM", UiTheme.DANGER, 14,
			Vector2(96.0, 40.0))
	confirm_button.name = "SellConfirmButton"
	UiParts.wire(confirm_button, _sell_confirm.bind(kind, target, ui))
	confirm.add_child(confirm_button)
	var cancel_button := UiParts.button("KEEP", UiTheme.STEEL, 14,
			Vector2(78.0, 40.0))
	cancel_button.name = "SellCancelButton"
	UiParts.wire(cancel_button, _sell_cancel.bind(shell))
	confirm.add_child(cancel_button)

static func sell_price(kind: SellKind, target: Variant) -> int:
	match kind:
		SellKind.ITEM: return GameState.sell_price_item(String(target))
		SellKind.ROBOT: return GameState.sell_price_robot(StringName(target))
		SellKind.PILOT: return GameState.sell_price_pilot(String(target))
		SellKind.DRONE: return GameState.sell_price_drone(String(target))
	return 0

static func sell_block(kind: SellKind, target: Variant) -> String:
	# One exit per branch: compute the reason, then return it once.
	var reason := ""
	match kind:
		SellKind.ITEM:
			if GameState.free_copies(String(target)) < 1:
				reason = "NO SPARE COPY"
		SellKind.ROBOT:
			var robot_id := StringName(target)
			if robot_id == GameState.selected_robot:
				reason = "EQUIPPED"
			elif GameState.owned_robots.size() <= 1:
				reason = "LAST ROBOT"
		SellKind.PILOT:
			if GameState.is_pilot_assigned(String(target)):
				reason = "ASSIGNED"
		SellKind.DRONE:
			var drone_id := String(target)
			if GameState.is_drone_assigned(drone_id) \
					or GameState.selected_drone == drone_id:
				reason = "IN USE"
			elif GameState.owned_drones.size() <= 1:
				reason = "LAST DRONE"
	return reason

static func sell_display(kind: SellKind, target: Variant) -> String:
	match kind:
		SellKind.ROBOT:
			var robot_id := StringName(target)
			return String(GameState.robot_def(robot_id).get("name",
					String(robot_id)))
		SellKind.PILOT:
			var pilot_id := String(target)
			return String(GameState.pilot_def(pilot_id).get("name",
					pilot_id.to_upper()))
		SellKind.DRONE:
			var drone_id := String(target)
			return String(GameState.drone_def(drone_id).get("name",
					drone_id.to_upper()))
	return String(target)

static func _run_sell(kind: SellKind, target: Variant) -> bool:
	match kind:
		SellKind.ITEM: return GameState.sell_item(String(target))
		SellKind.ROBOT: return GameState.sell_robot(StringName(target))
		SellKind.PILOT: return GameState.sell_pilot(String(target))
		SellKind.DRONE: return GameState.sell_drone(String(target))
	return false

static func _sell_arm(shell: Control) -> void:
	# The SELL button lives inside the state row, so both lookups walk the
	# shell.
	var confirm := shell.find_child("SellConfirm", true, false) as Control
	var button := shell.find_child("SellButton", true, false) as Button
	if confirm != null:
		confirm.visible = true
	if button != null:
		button.disabled = true

static func _sell_cancel(shell: Control) -> void:
	var confirm := shell.find_child("SellConfirm", true, false) as Control
	var button := shell.find_child("SellButton", true, false) as Button
	if confirm != null:
		confirm.visible = false
	if button != null:
		button.disabled = bool(button.get_meta("sell_blocked", false))

static func _sell_confirm(kind: SellKind, target: Variant,
		ui: UIManager) -> void:
	var display := sell_display(kind, target)
	var price := sell_price(kind, target)
	var reason := sell_block(kind, target)
	if not reason.is_empty():
		ui.toast("%s · CANNOT SELL" % reason, true)
		return
	if not _run_sell(kind, target):
		ui.toast("COULD NOT SELL %s" % display, true)
		return
	ui.toast("%s SOLD · +%s SILVER" % [display, UiParts.money(price)])
	ui.refresh()

# -------------------------------------------------------------- shared text

static func pairing_text(robot_id: StringName) -> String:
	var pilot := GameState.signature_pilot_name_for(robot_id)
	var drone := GameState.signature_drone_name_for(robot_id)
	var families: Array[String] = []
	for item in GameState._default_loadout(robot_id) as Array:
		var family := String(item).get_slice("-", 0)
		if not families.has(family):
			families.append(family)
	return "PAIR  %s · %s · %s" % [
			pilot if not pilot.is_empty() else "—",
			drone if not drone.is_empty() else "—",
			" + ".join(families)]

static func slot_caption(index: int) -> String:
	var slot: Dictionary = HangarSlots.SLOTS[index]
	if bool(slot["titan"]):
		return "TITAN PAD"
	match int(slot["role"]):
		HangarSlots.Role.HERO:
			return "HERO PAD"
		HangarSlots.Role.FRONT_LEFT, HangarSlots.Role.BACK_LEFT:
			return "FLANK LEFT"
		_:
			return "FLANK RIGHT"
