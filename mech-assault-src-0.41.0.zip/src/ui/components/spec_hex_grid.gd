class_name SpecHexGrid
extends Control

# Hex-cell specialization tree (CORE / FIREPOWER / SURVIVAL / MOBILITY)
# drawn procedurally: flat-top cells with rank pips, hover highlight,
# tap a cell to rank it up. Extracted verbatim from the old monolith.

signal node_pressed(node_id: String)
signal node_hovered(node_id: String)

const HEX_R := 44.0
const HEX_GAP_X := 8.0
const BAND_HEADER := 16.0
const HEADER_GAP := 3.0
const BAND_GAP := 6.0
const CELL_PAD := 6.0
const NAME_FONT := 9
const RANK_FONT := 14
const PIP_SIZE := Vector2(7.0, 5.0)
const PIP_GAP := 3.0
const PIP_ROWS := 5

var robot_id: StringName = &"SCARAB"
var points: int = 0

var _bands: Array[Dictionary] = []
var _cells: Array[Dictionary] = []
var _grid_width: float = 0.0
var _grid_height: float = 0.0
var _hover: int = -1

func _init() -> void:
	mouse_filter = Control.MOUSE_FILTER_STOP
	mouse_entered.connect(_on_mouse_entered)
	mouse_exited.connect(_on_mouse_exited)

func refresh(robot: StringName, module_points: int) -> void:
	robot_id = robot
	points = module_points
	_rebuild()
	queue_redraw()

func _rebuild() -> void:
	_bands.clear()
	_cells.clear()
	_hover = -1
	var schools: Array[Dictionary] = [
		{"title": "CORE", "accent": UiTheme.STEEL,
			"effects": ["hp", "cooldown"]},
		{"title": "FIREPOWER", "accent": UiTheme.AMBER,
			"effects": ["damage", "fire_rate"]},
		{"title": "SURVIVAL", "accent": UiTheme.HEALTH,
			"effects": ["defense", "regen"]},
		{"title": "MOBILITY", "accent": UiTheme.CYAN, "effects": ["speed"]},
	]
	var nodes: Array = GameState.spec_nodes(robot_id)
	var cell_w := sqrt(3.0) * HEX_R
	var pitch_x := cell_w + HEX_GAP_X
	var max_cols := 1
	for school in schools:
		var wanted: Array = school["effects"]
		var count := 0
		for node in nodes:
			if String(node.get("effect", "")) in wanted:
				count += 1
		max_cols = maxi(max_cols, count)
	var row_w := float(max_cols - 1) * pitch_x + cell_w
	_grid_width = row_w + pitch_x * 0.5 + CELL_PAD * 2.0
	var centre_x := _grid_width * 0.5
	var y := CELL_PAD
	for school_index in schools.size():
		var school: Dictionary = schools[school_index]
		var wanted: Array = school["effects"]
		var accent: Color = school["accent"]
		var band_cells: Array[int] = []
		for node in nodes:
			if not (String(node.get("effect", "")) in wanted):
				continue
			var node_id := String(node.get("id", ""))
			band_cells.append(_cells.size())
			_cells.append({
				"id": node_id,
				"name": String(node.get("name", "")),
				"desc": String(node.get("desc", "")),
				"rank": GameState.spec_rank(robot_id, node_id),
				"cost": GameState.spec_upgrade_cost(robot_id, node_id),
				"school": accent,
				"centre": Vector2.ZERO,
				"poly": PackedVector2Array(),
			})
		var band_centre_x := centre_x + (pitch_x * 0.25 \
				if school_index % 2 == 1 else -pitch_x * 0.25)
		var count := band_cells.size()
		if count == 0:
			# No node in this school on this chassis: no header, no band.
			continue
		var hex_y := y + BAND_HEADER + HEADER_GAP + HEX_R
		for cell_index in count:
			var flat: int = band_cells[cell_index]
			var offset_x := (float(cell_index) - float(count - 1) * 0.5) \
					* pitch_x
			var centre := Vector2(band_centre_x + offset_x, hex_y)
			_cells[flat]["centre"] = centre
			_cells[flat]["poly"] = _hex_polygon(centre)
		_bands.append({
			"title": String(school["title"]),
			"accent": accent,
			"baseline": y + BAND_HEADER - 4.0,
			"first": band_cells[0],
			"count": count,
		})
		y += BAND_HEADER + HEADER_GAP + HEX_R * 2.0 + BAND_GAP
	_grid_height = y + CELL_PAD - BAND_GAP
	custom_minimum_size = Vector2(_grid_width, _grid_height)

func _hex_polygon(centre: Vector2) -> PackedVector2Array:
	var points := PackedVector2Array()
	for corner in 6:
		var angle := deg_to_rad(60.0 * float(corner) - 90.0)
		points.append(centre + Vector2(cos(angle), sin(angle)) * HEX_R)
	return points

func _draw() -> void:
	var font := get_theme_default_font()
	for band_index in _bands.size():
		var band: Dictionary = _bands[band_index]
		var accent: Color = band["accent"]
		draw_string(font, Vector2(CELL_PAD, float(band["baseline"])),
				String(band["title"]), HORIZONTAL_ALIGNMENT_LEFT, -1.0, 11,
				accent)
	for band_index in _bands.size():
		var band: Dictionary = _bands[band_index]
		var count := int(band["count"])
		var first := int(band["first"])
		for step in maxi(count - 1, 0):
			var start: Vector2 = _cells[first + step]["centre"]
			var finish: Vector2 = _cells[first + step + 1]["centre"]
			draw_line(start, finish, Color(1.0, 1.0, 1.0, 0.14), 2.0, true)
	for index in _cells.size():
		_draw_cell(font, index)

func _draw_cell(font: Font, index: int) -> void:
	var cell: Dictionary = _cells[index]
	var centre: Vector2 = cell["centre"]
	var poly: PackedVector2Array = cell["poly"]
	var rank := int(cell["rank"])
	var cost := int(cell["cost"])
	var palette := _palette(rank, cost, index == _hover)
	var accent: Color = palette["accent"]
	var fill: Color = palette["fill"]
	var text_color: Color = palette["text"]
	var width := float(palette["width"])
	draw_colored_polygon(poly, fill)
	var outline := poly.duplicate()
	outline.append(poly[0])
	draw_polyline(outline, accent, width, true)
	var lines := _wrap_name(String(cell["name"]), 11)
	if lines.size() >= 2:
		_draw_centred(font, centre, lines[0], -16.0, NAME_FONT, text_color)
		_draw_centred(font, centre, lines[1], -5.0, NAME_FONT, text_color)
	else:
		_draw_centred(font, centre, lines[0], -10.0, NAME_FONT, text_color)
	_draw_centred(font, centre, "%d/%d" % [rank, GameState.SPEC_MAX_RANK],
			13.0, RANK_FONT, accent)
	var pip_total := float(PIP_ROWS) * PIP_SIZE.x + float(PIP_ROWS - 1) \
			* PIP_GAP
	var pip_x := centre.x - pip_total * 0.5
	for pip in PIP_ROWS:
		var pip_color: Color = accent if pip < rank \
				else Color(1.0, 1.0, 1.0, 0.16)
		draw_rect(Rect2(pip_x + float(pip) * (PIP_SIZE.x + PIP_GAP),
				centre.y + 17.0, PIP_SIZE.x, PIP_SIZE.y), pip_color, true)

func _draw_centred(font: Font, centre: Vector2, text: String, dy: float,
		font_size: int, color: Color) -> void:
	draw_string(font, Vector2(centre.x - HEX_R, centre.y + dy), text,
			HORIZONTAL_ALIGNMENT_CENTER, HEX_R * 2.0, font_size, color)

func _palette(rank: int, cost: int, hovered: bool) -> Dictionary:
	var accent := UiTheme.STEEL
	var fill := Color(0.05, 0.065, 0.09, 0.96)
	var text_color := UiTheme.MUTED
	var width := 1.0
	if rank <= 0:
		if cost > 0 and points >= cost:
			accent = UiTheme.AMBER
			fill = Color(0.15, 0.10, 0.04, 0.96)
			text_color = UiTheme.AMBER
			width = 2.0
		else:
			accent = Color(UiTheme.STEEL.r, UiTheme.STEEL.g, UiTheme.STEEL.b,
					0.5)
	else:
		accent = UiTheme.HEALTH
		fill = Color(0.05, 0.14, 0.09, 0.96)
		text_color = UiTheme.TEXT
		width = 2.0
		if rank >= GameState.SPEC_MAX_RANK:
			fill = Color(0.10, 0.30, 0.18, 0.97)
			text_color = Color.WHITE
			width = 3.0
	if hovered:
		fill = fill.lightened(0.2)
		width += 1.0
	return {"accent": accent, "fill": fill, "text": text_color,
			"width": width}

func _wrap_name(text: String, max_chars: int) -> Array[String]:
	var words := text.split(" ", false)
	var lines: Array[String] = []
	var current := ""
	for word in words:
		var piece := String(word)
		if piece.length() > max_chars:
			piece = piece.left(max_chars)
		var candidate := piece if current.is_empty() \
				else "%s %s" % [current, piece]
		if candidate.length() <= max_chars:
			current = candidate
		else:
			if not current.is_empty():
				lines.append(current)
			current = piece
	if not current.is_empty():
		lines.append(current)
	if lines.is_empty():
		lines.append("")
	while lines.size() > 2:
		var extra: String = lines[lines.size() - 1]
		lines.remove_at(lines.size() - 1)
		lines[1] = "%s %s" % [lines[1], extra]
	return lines

func _cell_at(point: Vector2) -> int:
	for index in _cells.size():
		var poly: PackedVector2Array = _cells[index]["poly"]
		if Geometry2D.is_point_in_polygon(point, poly):
			return index
	return -1

func _gui_input(event: InputEvent) -> void:
	if event is InputEventMouseMotion:
		_set_hover(_cell_at(get_local_mouse_position()))
	elif event is InputEventMouseButton:
		var mouse := event as InputEventMouseButton
		if mouse.pressed and mouse.button_index == MOUSE_BUTTON_LEFT:
			var index := _cell_at(mouse.position)
			if index >= 0:
				AudioEngine.play(&"ui")
				node_pressed.emit(String(_cells[index].get("id", "")))

func _on_mouse_entered() -> void:
	_set_hover(_cell_at(get_local_mouse_position()))

func _on_mouse_exited() -> void:
	_set_hover(-1)

func _set_hover(index: int) -> void:
	if _hover == index:
		return
	_hover = index
	queue_redraw()
	node_hovered.emit("" if index < 0 else String(_cells[index].get("id", "")))

