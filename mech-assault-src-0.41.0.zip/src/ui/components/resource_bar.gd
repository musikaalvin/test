class_name ResourceBar
extends PanelContainer

# Persistent top chrome: profile level + every currency, one chip each.
# Lives outside the screen stack (UIManager) so it never repaints or
# re-allocates while navigating. Responsive: minor currencies hide when
# the window gets narrow.
#
# Chips are Panels sized to their content's minimum (fixed widths let
# long wallet values spill past the next chip's background, which read
# as clipped text). Captions follow WR's icon+number style: only the
# chips whose caption is load-bearing keep one (ACCOUNT, PLAT) — the
# other six values fit in 1244 px only without them.

var _title: Label
var _level_label: Label
var _chip_labels: Array[Label] = []
var _chip_inners: Array[HBoxContainer] = []
var _chips: Array[Panel] = []
var _responsive: bool = true

const BAR_HEIGHT := 58.0
const PROFILE_WIDTH := 230.0
const BADGE_WIDTH := 138.0

func _init() -> void:
	name = "ResourceBar"
	set_anchors_and_offsets_preset(Control.PRESET_TOP_WIDE)
	offset_top = 6.0
	offset_bottom = BAR_HEIGHT
	offset_left = 12.0
	offset_right = -12.0
	mouse_filter = Control.MOUSE_FILTER_IGNORE
	var style := UiTheme.panel(0.88)
	style.content_margin_left = 14.0
	style.content_margin_right = 14.0
	style.content_margin_top = 5.0
	style.content_margin_bottom = 5.0
	add_theme_stylebox_override("panel", style)
	_build()
	Events.wallet_changed.connect(refresh)
	Events.pilot_progress.connect(refresh)

func _build() -> void:
	var row := UiParts.hbox(8.0)
	row.name = "BarRow"
	row.mouse_filter = Control.MOUSE_FILTER_IGNORE
	add_child(row)

	var profile := Panel.new()
	profile.name = "PlayerBlock"
	profile.custom_minimum_size = Vector2(PROFILE_WIDTH, 42.0)
	profile.size_flags_vertical = Control.SIZE_SHRINK_CENTER
	profile.mouse_filter = Control.MOUSE_FILTER_IGNORE
	var profile_style := UiTheme.bar_bg()
	profile_style.border_color = Color(UiTheme.CYAN.r, UiTheme.CYAN.g, UiTheme.CYAN.b, 0.30)
	profile_style.set_border_width_all(1)
	profile.add_theme_stylebox_override("panel", profile_style)
	row.add_child(profile)

	var profile_margin := MarginContainer.new()
	profile_margin.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	profile_margin.add_theme_constant_override("margin_left", 9)
	profile_margin.add_theme_constant_override("margin_right", 9)
	profile_margin.add_theme_constant_override("margin_top", 4)
	profile_margin.add_theme_constant_override("margin_bottom", 4)
	profile.add_child(profile_margin)

	var profile_row := UiParts.hbox(8.0)
	profile_margin.add_child(profile_row)

	var avatar := Panel.new()
	avatar.name = "ProfileBadge"
	avatar.custom_minimum_size = Vector2(32.0, 32.0)
	avatar.size_flags_vertical = Control.SIZE_SHRINK_CENTER
	var avatar_style := UiTheme.glow_frame(UiTheme.CYAN, 1)
	avatar_style.bg_color = Color(0.03, 0.11, 0.15, 0.95)
	avatar.add_theme_stylebox_override("panel", avatar_style)
	profile_row.add_child(avatar)

	var avatar_text := UiParts.label("M", 15, UiTheme.CYAN, true)
	avatar_text.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	avatar_text.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
	avatar_text.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	avatar.add_child(avatar_text)

	var profile_col := UiParts.vbox(0.0)
	profile_col.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	profile_row.add_child(profile_col)

	_title = UiParts.label("MECH ASSAULT", 13, UiTheme.TEXT, true)
	_title.name = "AppTitle"
	profile_col.add_child(_title)
	var profile_sub := UiParts.label("LOCAL PILOT  ·  OFFLINE", 9, UiTheme.MUTED)
	profile_sub.name = "ProfileSub"
	profile_col.add_child(profile_sub)

	var spacer := Control.new()
	spacer.name = "Spacer"
	spacer.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	spacer.mouse_filter = Control.MOUSE_FILTER_IGNORE
	row.add_child(spacer)

	# Version stamp lives in the bar. It is intentionally tiny so the
	# persistent chrome reads like a game client, not a debug overlay.
	var stamp := Label.new()
	stamp.name = "BuildStamp"
	stamp.text = GameState.BUILD_LABEL
	UiTheme.style_label(stamp, 9, Color(0.42, 0.49, 0.54))
	stamp.size_flags_vertical = Control.SIZE_SHRINK_CENTER
	stamp.mouse_filter = Control.MOUSE_FILTER_IGNORE
	row.add_child(stamp)

	_add_chip(row, "ChipLevel", "ACCOUNT", "LV 1", UiTheme.CYAN)
	_add_chip(row, "ChipSilver", "", "0", Color(0.45, 0.9, 0.55))
	_add_chip(row, "ChipGold", "", "0", UiTheme.AMBER)
	_add_chip(row, "ChipPlatinum", "PLAT", "0", Color(0.78, 0.88, 1.0))
	_add_chip(row, "ChipParts", "", "0", Color(0.72, 0.56, 0.95))
	_add_chip(row, "ChipChips", "", "0", UiTheme.CYAN)
	_add_chip(row, "ChipModules", "", "0", UiTheme.HEALTH)
	_add_chip(row, "ChipMemor", "", "0", UiTheme.CYAN)

	var offline := Panel.new()
	offline.name = "OfflineBadge"
	offline.custom_minimum_size = Vector2(BADGE_WIDTH, 34.0)
	offline.size_flags_vertical = Control.SIZE_SHRINK_CENTER
	offline.mouse_filter = Control.MOUSE_FILTER_IGNORE
	offline.add_theme_stylebox_override("panel", UiTheme.solid_panel(UiTheme.CTA_GREEN, 0.16, 1))
	var offline_margin := MarginContainer.new()
	offline_margin.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	offline_margin.add_theme_constant_override("margin_left", 9)
	offline_margin.add_theme_constant_override("margin_right", 9)
	offline.add_child(offline_margin)
	var offline_row := UiParts.hbox(5.0)
	offline_margin.add_child(offline_row)
	var dot := ColorRect.new()
	dot.name = "OfflineDot"
	dot.color = UiTheme.HEALTH
	dot.custom_minimum_size = Vector2(7.0, 7.0)
	dot.size_flags_vertical = Control.SIZE_SHRINK_CENTER
	offline_row.add_child(dot)
	var offline_label := UiParts.label("OFFLINE  ·  LOCAL", 10, UiTheme.HEALTH, true)
	offline_label.name = "OfflineLabel"
	offline_row.add_child(offline_label)
	row.add_child(offline)
	refresh()

func _add_chip(row: HBoxContainer, chip_name: String, caption_text: String,
		value_text: String, dot_color: Color) -> void:
	# Plain Panel (smoke addresses these as type "Panel") sized to its
	# content's minimum — a fixed width let long wallet values spill past
	# the next chip's background, which read as clipped text.
	var chip := Panel.new()
	chip.name = chip_name
	chip.size_flags_vertical = Control.SIZE_SHRINK_CENTER
	chip.mouse_filter = Control.MOUSE_FILTER_IGNORE
	var style := UiTheme.panel(0.9)
	style.content_margin_left = 9.0
	style.content_margin_right = 9.0
	style.content_margin_top = 3.0
	style.content_margin_bottom = 3.0
	chip.add_theme_stylebox_override("panel", style)
	var inner := UiParts.hbox(6.0)
	inner.anchor_left = 0.0
	inner.anchor_top = 0.0
	inner.anchor_right = 1.0
	inner.anchor_bottom = 1.0
	inner.offset_left = 9.0
	inner.offset_top = 3.0
	inner.offset_right = -9.0
	inner.offset_bottom = -3.0
	inner.mouse_filter = Control.MOUSE_FILTER_IGNORE
	chip.add_child(inner)
	var dot := ColorRect.new()
	dot.color = dot_color
	dot.custom_minimum_size = Vector2(9.0, 9.0)
	dot.size_flags_vertical = Control.SIZE_SHRINK_CENTER
	dot.mouse_filter = Control.MOUSE_FILTER_IGNORE
	inner.add_child(dot)
	if not caption_text.is_empty():
		var caption := UiParts.label(caption_text, 10, UiTheme.MUTED)
		caption.name = "Caption"
		caption.size_flags_vertical = Control.SIZE_SHRINK_CENTER
		inner.add_child(caption)
	var value := UiParts.label(value_text, 13, UiTheme.TEXT, true)
	value.name = "Value"
	value.size_flags_vertical = Control.SIZE_SHRINK_CENTER
	inner.add_child(value)
	# Off-tree this measures placeholder metrics (fs16 / "0"); refresh()
	# re-measures in-tree where label minimums track the wallet text.
	_resize_chip(chip, inner)
	row.add_child(chip)
	_chips.append(chip)
	_chip_labels.append(value)
	_chip_inners.append(inner)

func _resize_chip(chip: Panel, inner: HBoxContainer) -> void:
	# Width from the children directly: an off-tree HBox reports a stale
	# (zero) combined minimum — its cache only dirties once the scene
	# tree lays it out, which would collapse the chip to the 20 px slack.
	var content_w := 0.0
	for child_index in inner.get_child_count():
		var child := inner.get_child(child_index) as Control
		content_w += child.get_combined_minimum_size().x
		if child_index > 0:
			content_w += 6.0
	chip.custom_minimum_size = Vector2(content_w + 20.0, 34.0)

func refresh() -> void:
	if _chip_labels.size() < 8:
		return
	_chip_labels[0].text = "LV %d" % GameState.pilot_level()
	_chip_labels[1].text = UiParts.money(GameState.silver)
	_chip_labels[2].text = UiParts.money(GameState.gold)
	_chip_labels[3].text = UiParts.money(GameState.platinum)
	_chip_labels[4].text = UiParts.money(GameState.spare_parts)
	_chip_labels[5].text = UiParts.money(GameState.microchips)
	_chip_labels[6].text = UiParts.money(GameState.module_points)
	_chip_labels[7].text = UiParts.money(GameState.memorium)
	for index in _chips.size():
		_resize_chip(_chips[index], _chip_inners[index])
	_apply_responsive()

func _refresh_when_settled() -> void:
	# Label minimums report unthemed placeholder metrics until the node
	# has processed one frame in-tree; measure for real afterwards.
	if not is_inside_tree():
		return
	await get_tree().process_frame
	if is_inside_tree():
		refresh()

# Keep the bar inside narrow windows: the tail currencies drop first.
func _apply_responsive() -> void:
	var width := size.x
	if width <= 1.0:
		return
	_responsive = width < 1150.0
	_chips[7].visible = width >= 1150.0
	_chips[6].visible = width >= 1010.0
	_chips[5].visible = width >= 900.0

func _notification(what: int) -> void:
	if what == NOTIFICATION_RESIZED:
		_apply_responsive()
	elif what == NOTIFICATION_ENTER_TREE:
		# Build measured placeholder text ("0", unthemed font); the wallet
		# values only fit the bar once the chips are re-measured in-tree.
		_refresh_when_settled()
