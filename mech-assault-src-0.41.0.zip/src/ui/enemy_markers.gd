class_name EnemyMarkers
extends Control

# Thin WR-style readout: effect chips, a name/hull line and a slim bar —
# the old 116x50 card (plus its 124x78 glass slab) obstructed the fight.
const MARKER_WIDTH := 76.0
const MARKER_HEIGHT := 48.0
const SCAN_INTERVAL := 0.5
# Only the end/death panel may hide a marker. The gameplay panels (HP, radar,
# stats, timer) are translucent — a marker behind one of them was invisible on
# device, which read as "the battle status over the bots is gone".
const OCCLUDER_PANELS: Array[String] = [
	"EndPanel",
]

var _markers: Dictionary = {}
var _locked_id: int = 0
var _scan_clock: float = 0.0
var _panels: Array[Control] = []
var _panels_cached: bool = false
# Cached glass frames: translucent so the battlefield stays readable behind
# the readout, a thin light rim at rest, a hot red rim while locked.
var _glass_normal: StyleBoxFlat = null
var _glass_locked: StyleBoxFlat = null

func _ready() -> void:
	mouse_filter = Control.MOUSE_FILTER_IGNORE
	set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	_glass_normal = _glass_style(Color(1.0, 1.0, 1.0, 0.24),
			Color(0.04, 0.06, 0.08, 0.40))
	_glass_locked = _glass_style(Color(1.0, 0.36, 0.3, 0.95),
			Color(0.1, 0.04, 0.04, 0.5))
	Events.enemy_targeted.connect(_on_targeted)
	Events.enemy_target_cleared.connect(_on_target_cleared)

func _glass_style(border: Color, background: Color) -> StyleBoxFlat:
	var style := StyleBoxFlat.new()
	style.bg_color = background
	style.border_color = border
	style.set_border_width_all(1)
	style.set_corner_radius_all(5)
	return style

func _on_targeted(enemy: Node, _ratio: float) -> void:
	_locked_id = enemy.get_instance_id()

func _on_target_cleared() -> void:
	_locked_id = 0

func _process(delta: float) -> void:
	_scan_clock -= delta
	if _scan_clock <= 0.0:
		_scan_clock = SCAN_INTERVAL
		_rescan()
	_update_positions()

func _rescan() -> void:
	var seen: Dictionary = {}
	for enemy in get_tree().get_nodes_in_group("enemy"):
		if enemy is EnemyRobot:
			seen[enemy.get_instance_id()] = enemy
	for id in _markers.keys():
		if not seen.has(id):
			_free_marker(id)
	for id in seen:
		if not _markers.has(id):
			_create_marker(seen[id] as EnemyRobot)

func _free_marker(id: int) -> void:
	var data: Dictionary = _markers[id]
	(data["root"] as Control).queue_free()
	_markers.erase(id)
	if _locked_id == id:
		_locked_id = 0

func _create_marker(enemy: EnemyRobot) -> void:
	var root := Control.new()
	root.name = "Marker"
	root.mouse_filter = Control.MOUSE_FILTER_IGNORE
	# Draw above the translucent HUD panels even when they overlap (sibling
	# order alone left markers underneath them on device).
	root.z_index = 8
	root.size = Vector2(MARKER_WIDTH, MARKER_HEIGHT)
	add_child(root)

	# Slim translucent backing behind the name line and bar — the single
	# HP/name readout (the old duplicate dialog box is gone); kept small so
	# the battlefield stays readable through it.
	var glass := Panel.new()
	glass.name = "Glass"
	glass.position = Vector2(-3.0, 17.0)
	glass.size = Vector2(MARKER_WIDTH + 6.0, 31.0)
	glass.mouse_filter = Control.MOUSE_FILTER_IGNORE
	glass.add_theme_stylebox_override("panel",
			_glass_locked if enemy.get_instance_id() == _locked_id else _glass_normal)
	root.add_child(glass)

	var name_label := Label.new()
	name_label.name = "Tag"
	name_label.text = enemy.kind_label()
	name_label.position = Vector2(1.0, 18.0)
	name_label.size = Vector2(50.0, 12.0)
	name_label.add_theme_font_size_override("font_size", 10)
	name_label.add_theme_color_override("font_color", Color(1.0, 0.5, 0.4))
	name_label.add_theme_constant_override("outline_size", 3)
	name_label.add_theme_color_override("font_outline_color", Color(0.02, 0.02, 0.03))
	name_label.mouse_filter = Control.MOUSE_FILTER_IGNORE
	root.add_child(name_label)

	# Hull readout right-aligned on the name line: raw number, kept small so
	# the bar below stays the at-a-glance signal.
	var hp_label := Label.new()
	hp_label.name = "Hp"
	hp_label.position = Vector2(51.0, 18.0)
	hp_label.size = Vector2(24.0, 12.0)
	hp_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_RIGHT
	hp_label.add_theme_font_size_override("font_size", 10)
	hp_label.add_theme_color_override("font_color", Color(1.0, 1.0, 1.0, 0.92))
	hp_label.add_theme_constant_override("outline_size", 3)
	hp_label.add_theme_color_override("font_outline_color", Color(0.02, 0.02, 0.03))
	hp_label.mouse_filter = Control.MOUSE_FILTER_IGNORE
	root.add_child(hp_label)

	var bar_bg := ColorRect.new()
	bar_bg.name = "BarBack"
	bar_bg.color = Color(0.02, 0.03, 0.045, 0.74)
	bar_bg.position = Vector2(0.0, 31.0)
	bar_bg.size = Vector2(MARKER_WIDTH, 6.0)
	bar_bg.mouse_filter = Control.MOUSE_FILTER_IGNORE
	root.add_child(bar_bg)

	var fill := ColorRect.new()
	fill.name = "BarFill"
	fill.color = Color(1.0, 0.4, 0.3)
	fill.size = Vector2(MARKER_WIDTH, 6.0)
	fill.mouse_filter = Control.MOUSE_FILTER_IGNORE
	bar_bg.add_child(fill)

	var dist_label := Label.new()
	dist_label.name = "Dist"
	dist_label.position = Vector2(0.0, 38.0)
	dist_label.size = Vector2(MARKER_WIDTH, 10.0)
	dist_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	dist_label.add_theme_font_size_override("font_size", 9)
	dist_label.add_theme_color_override("font_color", Color(1.0, 0.45, 0.38, 0.85))
	dist_label.add_theme_constant_override("outline_size", 3)
	dist_label.add_theme_color_override("font_outline_color", Color(0.02, 0.02, 0.03))
	dist_label.mouse_filter = Control.MOUSE_FILTER_IGNORE
	root.add_child(dist_label)

	# WR-style effect chips above the marker: white on application, filling to
	# half-red then full red as the effect accumulates.
	var status_row := Control.new()
	status_row.name = "StatusRow"
	status_row.position = Vector2(0.0, 0.0)
	status_row.size = Vector2(MARKER_WIDTH, 17.0)
	status_row.mouse_filter = Control.MOUSE_FILTER_IGNORE
	root.add_child(status_row)

	_markers[enemy.get_instance_id()] = {
		"enemy": enemy,
		"root": root,
		"glass": glass,
		"name": name_label,
		"hp": hp_label,
		"label": enemy.kind_label(),
		"fill": fill,
		"dist": dist_label,
		"status_row": status_row,
		"status_key": "",
		"locked": enemy.get_instance_id() == _locked_id,
	}

func _panel_rects() -> Array[Rect2]:
	if not _panels_cached:
		var host := get_parent() as Control
		if host == null:
			return []
		for panel_name: String in OCCLUDER_PANELS:
			var node := host.get_node_or_null(panel_name)
			if node is Control:
				_panels.append(node as Control)
		_panels_cached = true
	var rects: Array[Rect2] = []
	for panel: Control in _panels:
		if is_instance_valid(panel) and panel.is_visible_in_tree():
			rects.append(panel.get_global_rect())
	return rects

func _update_positions() -> void:
	var camera := get_viewport().get_camera_3d()
	var view_rect := get_viewport().get_visible_rect()
	var panel_rects := _panel_rects()
	for id in _markers.keys():
		var data: Dictionary = _markers[id]
		var root := data["root"] as Control
		var enemy_variant: Variant = data["enemy"]
		if not is_instance_valid(enemy_variant):
			# enemy node was freed after its death cleanup — drop the marker
			if is_instance_valid(root):
				root.queue_free()
			_markers.erase(id)
			continue
		var enemy := enemy_variant as EnemyRobot
		if camera == null \
				or enemy.state == EnemyRobot.State.DEAD or enemy.health == null \
				or enemy.health.dead:
			root.visible = false
			continue
		var anchor := enemy.eye_position() + Vector3.UP * 0.7
		if camera.is_position_behind(anchor):
			root.visible = false
			continue
		var screen := camera.unproject_position(anchor)
		root.position = screen + Vector2(-MARKER_WIDTH * 0.5, -MARKER_HEIGHT - 12.0)
		var marker_rect := root.get_global_rect()
		if not view_rect.encloses(marker_rect):
			root.visible = false
			continue
		var occluded := false
		for panel_rect: Rect2 in panel_rects:
			if marker_rect.intersects(panel_rect):
				occluded = true
				break
		if occluded:
			root.visible = false
			continue
		root.visible = true
		var flat := camera.global_position - enemy.global_position
		flat.y = 0.0
		var dist_label := data["dist"] as Label
		dist_label.text = "%dm" % roundi(flat.length())
		var ratio := enemy.health.ratio()
		var fill := data["fill"] as ColorRect
		fill.size.x = MARKER_WIDTH * clampf(ratio, 0.0, 1.0)
		var locked: bool = id == _locked_id
		var colour := Color(1.0, 0.3, 0.24) if ratio < 0.35 else Color(1.0, 0.62, 0.2)
		if locked:
			colour = Color(1.0, 0.3, 0.22)
		fill.color = colour
		var name_label := data["name"] as Label
		# Lock state shows as colour + red glass rim (the HUD's TARGET frame
		# carries the tag) — no "LOCK //" prefix to blow out the thin line.
		name_label.text = String(data.get("label", "HOSTILE"))
		name_label.add_theme_color_override("font_color", colour)
		# Hull number beside the name — same glass slab, no second dialog.
		var hp_label := data.get("hp") as Label
		if hp_label != null and is_instance_valid(hp_label):
			hp_label.text = GameState.fmt_amount(enemy.health.current)
		# Swap the glass rim to red only when the lock state actually changes.
		if bool(data.get("locked", false)) != locked:
			data["locked"] = locked
			var glass := data.get("glass") as Panel
			if glass != null and is_instance_valid(glass):
				glass.add_theme_stylebox_override("panel",
						_glass_locked if locked else _glass_normal)
		_sync_status(data, enemy)

func _sync_status(data: Dictionary, enemy: EnemyRobot) -> void:
	var row := data.get("status_row") as Control
	if row == null or not is_instance_valid(row):
		return
	var icons := enemy.status_icon_row()
	var parts := PackedStringArray()
	for icon: String in icons:
		parts.append("%s%d" % [icon, enemy.status_icon_stacks(icon)])
	var key := "|".join(parts)
	if key == String(data.get("status_key", "")):
		return
	data["status_key"] = key
	for child: Node in row.get_children():
		child.queue_free()
	var chip_x := 0.0
	for icon: String in icons:
		var stacks := enemy.status_icon_stacks(icon)
		var level := 1
		if stacks >= 6:
			level = 3
		elif stacks >= 3:
			level = 2
		var final_color := Color(1.0, 1.0, 1.0)
		if icon == "CR":
			# Critical hull: pinned to the hot end of the scale regardless of
			# stack count (there is only ever one of these).
			final_color = Color(1.0, 0.24, 0.2)
		elif level == 2:
			final_color = Color(1.0, 0.62, 0.2)
		elif level == 3:
			final_color = Color(1.0, 0.3, 0.24)
		var chip := _make_status_chip(icon, final_color)
		chip.position = Vector2(chip_x, 0.0)
		row.add_child(chip)
		chip_x += 20.0
		# Accumulation animation: white background eases to the level colour.
		var rect := chip.get_node_or_null("Bg") as ColorRect
		if rect != null:
			var tween := chip.create_tween()
			tween.tween_method(func(value: float) -> void:
				if not is_instance_valid(rect):
					return
				var c := Color.WHITE.lerp(final_color, value)
				rect.color = Color(c.r, c.g, c.b, 0.88),
				0.0, 1.0, 0.5)
		chip.pivot_offset = Vector2(8.5, 8.5)
		chip.scale = Vector2(1.3, 1.3)
		chip.create_tween().tween_property(chip, "scale", Vector2.ONE, 0.25)

func _make_status_chip(icon: String, color: Color) -> Control:
	var chip := Control.new()
	chip.name = "Chip"
	chip.size = Vector2(17.0, 17.0)
	chip.mouse_filter = Control.MOUSE_FILTER_IGNORE
	var bg := ColorRect.new()
	bg.name = "Bg"
	bg.color = Color(1.0, 1.0, 1.0, 0.88)
	bg.size = Vector2(17.0, 17.0)
	bg.mouse_filter = Control.MOUSE_FILTER_IGNORE
	chip.add_child(bg)
	var glyph := Label.new()
	glyph.name = "Glyph"
	glyph.text = icon
	glyph.position = Vector2(0.0, 0.0)
	glyph.size = Vector2(17.0, 17.0)
	glyph.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	glyph.add_theme_font_size_override("font_size", 11)
	glyph.add_theme_color_override("font_color", Color(0.05, 0.05, 0.06))
	glyph.add_theme_constant_override("outline_size", 2)
	glyph.add_theme_color_override("font_outline_color", Color(0.0, 0.0, 0.0, 0.6))
	glyph.mouse_filter = Control.MOUSE_FILTER_IGNORE
	chip.add_child(glyph)
	return chip
