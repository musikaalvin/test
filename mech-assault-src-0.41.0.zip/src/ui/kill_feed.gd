class_name KillFeed
extends Control

const MAX_LINES := 3
const LINE_LIFE := 3.0

func _ready() -> void:
	mouse_filter = Control.MOUSE_FILTER_IGNORE
	Events.enemy_killed.connect(_on_enemy_killed)
	Events.all_enemies_defeated.connect(_on_all_defeated)
	Events.match_ended.connect(_on_match_ended)

func add_line(text: String, color: Color) -> void:
	while get_child_count() >= MAX_LINES:
		var oldest := get_child(0) as Node
		if oldest == null:
			break
		remove_child(oldest)
		oldest.queue_free()
	var label := Label.new()
	label.text = text
	label.horizontal_alignment = HORIZONTAL_ALIGNMENT_RIGHT
	UiTheme.style_label(label, 15, color, true)
	label.mouse_filter = Control.MOUSE_FILTER_IGNORE
	add_child(label)
	var tween := label.create_tween()
	tween.tween_interval(LINE_LIFE)
	tween.tween_property(label, "modulate:a", 0.0, 0.6)
	tween.tween_callback(label.queue_free)

func _on_enemy_killed(_enemy_id: int) -> void:
	add_line("HOSTILE NEUTRALISED  %d" % GameState.enemies_killed,
			Color(1.0, 0.62, 0.28))

func _on_all_defeated() -> void:
	add_line("AREA SECURED", UiTheme.CYAN)

func _on_match_ended(victory: bool) -> void:
	if victory:
		add_line("MISSION COMPLETE", UiTheme.HEALTH)
	else:
		add_line("UNIT LOST", UiTheme.DANGER)
