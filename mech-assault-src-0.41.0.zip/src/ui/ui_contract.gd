class_name UiContract
extends RefCounted

## Production UI architecture contract generated from the full UI rebuild specification.
## This is metadata/state routing, not a duplicate gameplay-data system.

const CONTRACT_PATH := "res://data/mech_assault_full_ui_contract.json"
const STATES := ["DEFAULT", "LOADING", "EMPTY", "LOCKED", "DISABLED", "ERROR", "SUCCESS", "SELECTED", "HOVER", "PRESSED", "UPDATING", "OFFLINE", "SYNCING"]

static var _data: Dictionary = {}

static func data() -> Dictionary:
	if _data.is_empty():
		var file := FileAccess.open(CONTRACT_PATH, FileAccess.READ)
		if file != null:
			var parsed: Variant = JSON.parse_string(file.get_as_text())
			if parsed is Dictionary:
				_data = parsed
	return _data

static func has_screen(screen: StringName) -> bool:
	return data().get("screens", {}).has(String(screen))

static func description(screen: StringName) -> String:
	return String(data().get("screens", {}).get(String(screen), ""))

static func screen_states() -> Array:
	return data().get("screen_states", STATES) as Array

static func required_flow(name: String) -> Array:
	return data().get("flows", {}).get(name, []) as Array
