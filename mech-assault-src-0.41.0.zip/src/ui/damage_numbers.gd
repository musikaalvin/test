class_name DamageNumbers
extends Control

## War Robots "Damage Report" indicator: ONE accumulated number next to the
## hit target (not a stream of independent pops).  The counter grows while
## you keep shooting the same robot, fades out if you stop/lose it for a
## couple of seconds, and — if you find it again within the retention window —
## resumes from the previous total.  Colour codes the zone being chewed:
## white = hull, grey = physical, blue = Ancile, yellow = Aegis, purple =
## Absorber (WR settings: "Show extended information about the target").

const HIDE_AFTER := 2.0
const FORGET_AFTER := 15.0
const HIDE_FADE := 0.4
const SIDE_OFFSET := Vector2(56.0, -18.0)

var _accum: Dictionary = {}

func _ready() -> void:
	set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	mouse_filter = Control.MOUSE_FILTER_IGNORE
	Events.damage_applied.connect(_on_damage_applied)

func _on_damage_applied(target: Node, amount: float, point: Vector3,
		_normal: Vector3) -> void:
	if not GameState.damage_numbers or amount <= 0.0:
		return
	if target is PlayerRobot:
		return
	var id := target.get_instance_id()
	var zone := Health.Zone.HULL
	var enemy := target as EnemyRobot
	if enemy != null and enemy.health != null:
		zone = enemy.health.last_hit_zone
	var entry: Dictionary
	if _accum.has(id):
		entry = _accum[id] as Dictionary
	else:
		entry = {
			"hull": 0.0, "shield": 0.0, "zone": zone,
			"last": 0.0, "shown": false, "target": target,
			"hull_label": null, "shield_label": null,
		}
		_accum[id] = entry
		_mk_label(entry, "hull_label", Color(1.0, 1.0, 1.0))
		_mk_label(entry, "shield_label", Health.zone_color(zone))
	if zone == Health.Zone.HULL:
		entry["hull"] = float(entry["hull"]) + amount
	else:
		entry["shield"] = float(entry["shield"]) + amount
		entry["zone"] = zone
	entry["last"] = 0.0
	entry["point"] = point
	if not bool(entry["shown"]):
		entry["shown"] = true
		_set_visible(entry, true, true)
	_refresh_labels(entry)

func _mk_label(entry: Dictionary, key: String, color: Color) -> void:
	var label := Label.new()
	label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	label.mouse_filter = Control.MOUSE_FILTER_IGNORE
	UiTheme.style_label(label, 19, color, true)
	label.scale = Vector2.ONE
	add_child(label)
	entry[key] = label

func _refresh_labels(entry: Dictionary) -> void:
	var hull_label := entry.get("hull_label") as Label
	if hull_label != null and is_instance_valid(hull_label):
		hull_label.text = GameState.fmt_amount(float(entry["hull"]))
		hull_label.visible = float(entry["hull"]) > 0.0
	var shield_label := entry.get("shield_label") as Label
	if shield_label != null and is_instance_valid(shield_label):
		shield_label.text = GameState.fmt_amount(float(entry["shield"]))
		shield_label.visible = float(entry["shield"]) > 0.0
		UiTheme.style_label(shield_label, 19, Health.zone_color(int(entry["zone"])), true)

func _set_visible(entry: Dictionary, visible: bool, instant: bool = false) -> void:
	for key: String in ["hull_label", "shield_label"]:
		var label := entry.get(key) as Label
		if label == null or not is_instance_valid(label):
			continue
		if instant:
			label.modulate.a = 1.0 if visible else 0.0
			label.visible = visible
		else:
			var tween := label.create_tween()
			if visible:
				label.visible = true
				label.modulate.a = 0.0
				tween.tween_property(label, "modulate:a", 1.0, 0.15)
			else:
				tween.tween_property(label, "modulate:a", 0.0, HIDE_FADE)
				tween.tween_callback(func() -> void:
					if is_instance_valid(label):
						label.visible = false)

func _process(delta: float) -> void:
	var camera := get_viewport().get_camera_3d()
	if camera == null:
		return
	var viewport_size := get_viewport().get_visible_rect().size
	for id: int in _accum.keys():
		var entry := _accum.get(id) as Dictionary
		if entry == null:
			continue
		var target_variant: Variant = entry.get("target")
		if not is_instance_valid(target_variant):
			_drop_entry(id, entry, true)
			continue
		var target := target_variant as Node
		if target is EnemyRobot and (target as EnemyRobot).health.dead:
			_drop_entry(id, entry, true)
			continue
		entry["last"] = float(entry["last"]) + delta
		var last := float(entry["last"])
		if last >= FORGET_AFTER:
			_drop_entry(id, entry, false)
			continue
		var should_show := last < HIDE_AFTER and bool(entry["shown"])
		if last >= HIDE_AFTER and bool(entry["shown"]):
			entry["shown"] = false
			_set_visible(entry, false)
		if not should_show:
			continue
		var anchor: Vector3 = (target as Node3D).global_position + Vector3.UP * 1.5
		if camera.is_position_behind(anchor):
			for key: String in ["hull_label", "shield_label"]:
				var hidden := entry.get(key) as Label
				if hidden != null and is_instance_valid(hidden):
					hidden.visible = false
			continue
		var screen := camera.unproject_position(anchor) + SIDE_OFFSET
		var on_screen := screen.x > -80.0 and screen.x < viewport_size.x + 80.0 \
				and screen.y > -40.0 and screen.y < viewport_size.y + 40.0
		var hull_label := entry.get("hull_label") as Label
		var shield_label := entry.get("shield_label") as Label
		# Stack: shield colour on top (like WR shows shield damage above hull).
		if hull_label != null and is_instance_valid(hull_label):
			hull_label.visible = on_screen and float(entry["hull"]) > 0.0
			hull_label.position = screen - hull_label.size * 0.5
		if shield_label != null and is_instance_valid(shield_label):
			var lift := 0.0
			if hull_label != null and is_instance_valid(hull_label) \
					and hull_label.visible:
				lift = hull_label.size.y + 2.0
			shield_label.visible = on_screen and float(entry["shield"]) > 0.0
			shield_label.position = screen - shield_label.size * 0.5 \
					- Vector2(0.0, lift)

func _drop_entry(id: int, entry: Dictionary, instant: bool) -> void:
	var labels: Array[Label] = []
	for key: String in ["hull_label", "shield_label"]:
		var label := entry.get(key) as Label
		if label != null and is_instance_valid(label):
			labels.append(label)
		entry[key] = null
	_accum.erase(id)
	if instant:
		for label: Label in labels:
			label.queue_free()
		return
	for label: Label in labels:
		var fade := label.create_tween()
		fade.tween_property(label, "modulate:a", 0.0, HIDE_FADE)
	var cleanup := create_tween()
	cleanup.tween_interval(HIDE_FADE + 0.15)
	cleanup.tween_callback(func() -> void:
		for label: Label in labels:
			if is_instance_valid(label):
				label.queue_free())

func entry_count() -> int:
	return _accum.size()

func clear_entries() -> void:
	for id: int in _accum.keys():
		var entry := _accum.get(id) as Dictionary
		for key: String in ["hull_label", "shield_label"]:
			var label := entry.get(key) as Label
			if label != null and is_instance_valid(label):
				label.queue_free()
	_accum.clear()
