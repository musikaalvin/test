class_name UiTheme
extends RefCounted

const BG := Color(0.018, 0.027, 0.045)
const PANEL := Color(0.035, 0.055, 0.078, 0.91)
const AMBER := Color(1.0, 0.48, 0.12)
const CYAN := Color(0.20, 0.84, 0.98)
const DANGER := Color(1.0, 0.25, 0.18)
const HEALTH := Color(0.3, 0.95, 0.55)
const STEEL := Color(0.5, 0.56, 0.62)
const TEXT := Color(0.92, 0.96, 1.0)
const MUTED := Color(0.55, 0.62, 0.68)

# WR-style solid call-to-action fills: the accent IS the button face.
const CTA_ORANGE := Color(0.93, 0.45, 0.07)
const CTA_RED := Color(0.84, 0.16, 0.16)
const CTA_GREEN := Color(0.13, 0.66, 0.37)
const CTA_BLUE := Color(0.14, 0.52, 0.9)

# Cut-corner button profile (top-left + bottom-right rounded, opposite corners
# clipped) gives every control the angular mech-HUD silhouette.
const CUT_LARGE := 12
const CUT_SMALL := 3

static func panel(alpha: float = 0.78, accent: Color = CYAN) -> StyleBoxFlat:
	var style := StyleBoxFlat.new()
	style.bg_color = Color(PANEL.r, PANEL.g, PANEL.b, alpha)
	style.border_color = Color(accent.r, accent.g, accent.b, 0.55)
	style.set_border_width_all(1)
	style.border_width_left = 3
	style.corner_radius_top_left = 12
	style.corner_radius_top_right = 4
	style.corner_radius_bottom_left = 4
	style.corner_radius_bottom_right = 12
	style.set_content_margin_all(16.0)
	style.shadow_color = Color(0.0, 0.0, 0.0, 0.55)
	style.shadow_size = 12
	style.shadow_offset = Vector2(0.0, 4.0)
	return style

static func _cut_corners(style: StyleBoxFlat) -> void:
	style.corner_radius_top_left = CUT_LARGE
	style.corner_radius_bottom_right = CUT_LARGE
	style.corner_radius_top_right = CUT_SMALL
	style.corner_radius_bottom_left = CUT_SMALL

static func button_normal(accent: Color) -> StyleBoxFlat:
	var style := StyleBoxFlat.new()
	style.bg_color = Color(0.045, 0.065, 0.09, 0.98)
	style.border_color = Color(accent.r, accent.g, accent.b, 0.75)
	style.set_border_width_all(1)
	style.border_width_left = 3
	_cut_corners(style)
	style.set_content_margin_all(12.0)
	style.content_margin_left = 20.0
	style.content_margin_right = 20.0
	return style

static func button_hover(accent: Color) -> StyleBoxFlat:
	var style := button_normal(accent)
	style.bg_color = Color(0.11, 0.14, 0.18, 0.98)
	style.border_color = accent
	style.shadow_color = Color(accent.r, accent.g, accent.b, 0.35)
	style.shadow_size = 10
	return style

static func button_pressed(accent: Color) -> StyleBoxFlat:
	var style := button_normal(accent)
	style.bg_color = Color(accent.r * 0.35, accent.g * 0.35, accent.b * 0.35, 0.95)
	style.border_color = Color(accent.r, accent.g, accent.b, 1.0)
	style.content_margin_top = 15.0
	style.content_margin_bottom = 9.0
	return style

# Glowing frame: a panel that must read as "live" — the titan preview wash and
# the selected cell of the hangar robot strip.
static func glow_frame(accent: Color, border_width: int = 2) -> StyleBoxFlat:
	var style := StyleBoxFlat.new()
	style.bg_color = Color(accent.r, accent.g, accent.b, 0.10)
	style.border_color = accent
	style.set_border_width_all(border_width)
	style.corner_radius_top_left = 10
	style.corner_radius_top_right = 3
	style.corner_radius_bottom_left = 3
	style.corner_radius_bottom_right = 10
	style.shadow_color = Color(accent.r, accent.g, accent.b, 0.40)
	style.shadow_size = 18
	style.shadow_offset = Vector2.ZERO
	style.set_content_margin_all(6.0)
	return style

static func bar_bg() -> StyleBoxFlat:
	var style := StyleBoxFlat.new()
	style.bg_color = Color(0.018, 0.032, 0.048, 0.96)
	style.border_color = Color(1.0, 1.0, 1.0, 0.14)
	style.set_border_width_all(1)
	style.set_corner_radius_all(6)
	style.border_width_bottom = 2
	return style

static func apply_to_button(button: Button, accent: Color, font_size: int) -> void:
	button.add_theme_stylebox_override("normal", button_normal(accent))
	button.add_theme_stylebox_override("hover", button_hover(accent))
	button.add_theme_stylebox_override("pressed", button_pressed(accent))
	button.add_theme_stylebox_override("disabled", button_normal(Color(0.4, 0.42, 0.45)))
	button.add_theme_stylebox_override("focus", button_hover(accent))
	button.add_theme_font_size_override("font_size", font_size)
	button.add_theme_color_override("font_color", TEXT)
	button.add_theme_color_override("font_hover_color", Color.WHITE)
	button.add_theme_color_override("font_pressed_color", Color.WHITE)
	button.add_theme_color_override("font_focus_color", TEXT)
	button.add_theme_color_override("font_disabled_color", Color(0.5, 0.52, 0.55))
	button.focus_mode = Control.FOCUS_NONE


static func solid_panel(accent: Color, alpha: float = 0.16, border_width: int = 1) -> StyleBoxFlat:
	var style := StyleBoxFlat.new()
	style.bg_color = Color(accent.r, accent.g, accent.b, alpha)
	style.border_color = Color(accent.r, accent.g, accent.b, 0.65)
	style.set_border_width_all(border_width)
	style.set_corner_radius_all(6)
	style.set_content_margin_all(8.0)
	return style

# WR's primary actions are solid colour slabs, not dark panels with a
# coloured border. Restyles an already-built button in place (the
# cut-corner profile is kept so the family still reads as one theme).
static func solid_cta(button: Button, accent: Color, font_size: int = -1) -> void:
	var normal := button_normal(accent)
	normal.bg_color = accent
	normal.border_color = Color(accent.r * 0.8, accent.g * 0.8, accent.b * 0.8, 1.0)
	normal.set_border_width_all(0)
	var hover := button_normal(accent)
	hover.bg_color = Color(minf(accent.r * 1.18, 1.0),
			minf(accent.g * 1.18, 1.0), minf(accent.b * 1.18, 1.0))
	hover.set_border_width_all(0)
	hover.shadow_color = Color(accent.r, accent.g, accent.b, 0.55)
	hover.shadow_size = 14
	hover.shadow_offset = Vector2.ZERO
	var pressed := button_normal(accent)
	pressed.bg_color = Color(accent.r * 0.68, accent.g * 0.68, accent.b * 0.68)
	pressed.set_border_width_all(0)
	pressed.content_margin_top = 15.0
	pressed.content_margin_bottom = 9.0
	var disabled := button_normal(Color(0.4, 0.42, 0.45))
	disabled.bg_color = Color(0.16, 0.18, 0.21, 0.95)
	disabled.set_border_width_all(0)
	button.add_theme_stylebox_override("normal", normal)
	button.add_theme_stylebox_override("hover", hover)
	button.add_theme_stylebox_override("pressed", pressed)
	button.add_theme_stylebox_override("focus", hover)
	button.add_theme_stylebox_override("disabled", disabled)
	button.add_theme_color_override("font_color", Color.WHITE)
	button.add_theme_color_override("font_hover_color", Color.WHITE)
	button.add_theme_color_override("font_pressed_color", Color.WHITE)
	button.add_theme_color_override("font_focus_color", Color.WHITE)
	button.add_theme_color_override("font_disabled_color", Color(0.5, 0.52, 0.55))
	if font_size > 0:
		button.add_theme_font_size_override("font_size", font_size)

# Compact chrome button: same profile with tight vertical padding for
# stacked nav columns (font 13 => minimum height 55 instead of 69, so
# four left-column buttons fit the band between the info card and the
# deck dock on a 720p device).
static func compact_button(button: Button, accent: Color, font_size: int) -> void:
	var normal := button_normal(accent)
	normal.content_margin_top = 8.0
	normal.content_margin_bottom = 8.0
	var hover := button_hover(accent)
	hover.content_margin_top = 8.0
	hover.content_margin_bottom = 8.0
	var pressed := button_pressed(accent)
	pressed.content_margin_top = 11.0
	pressed.content_margin_bottom = 5.0
	button.add_theme_stylebox_override("normal", normal)
	button.add_theme_stylebox_override("hover", hover)
	button.add_theme_stylebox_override("pressed", pressed)
	button.add_theme_stylebox_override("focus", hover)
	if font_size > 0:
		button.add_theme_font_size_override("font_size", font_size)

static func style_label(label: Label, size: int, color: Color, outline: bool = false) -> void:
	label.add_theme_font_size_override("font_size", size)
	label.add_theme_color_override("font_color", color)
	label.add_theme_color_override("font_shadow_color", Color(0.0, 0.0, 0.0, 0.75))
	label.add_theme_constant_override("shadow_offset_x", 0)
	label.add_theme_constant_override("shadow_offset_y", 2)
	if outline:
		label.add_theme_constant_override("outline_size", 5)
		label.add_theme_color_override("font_outline_color", Color(0.01, 0.02, 0.03))


# Consistent high-contrast slider styling for settings and configuration screens.
static func style_slider(slider: Range, accent: Color) -> void:
	var track := StyleBoxFlat.new()
	track.bg_color = Color(0.035, 0.055, 0.075, 1.0)
	track.border_color = Color(accent.r, accent.g, accent.b, 0.36)
	track.set_border_width_all(1)
	track.set_corner_radius_all(5)
	track.content_margin_top = 4.0
	track.content_margin_bottom = 4.0
	var fill := StyleBoxFlat.new()
	fill.bg_color = accent
	fill.set_corner_radius_all(5)
	slider.add_theme_stylebox_override("slider", track)
	slider.add_theme_stylebox_override("grabber_area", track)
	slider.add_theme_stylebox_override("grabber_area_highlight", fill)
	slider.add_theme_icon_override("grabber", _make_grabber(accent))
	slider.add_theme_icon_override("grabber_highlight", _make_grabber(Color.WHITE))

static func _make_grabber(accent: Color) -> ImageTexture:
	var image := Image.create(18, 18, false, Image.FORMAT_RGBA8)
	image.fill(Color(0, 0, 0, 0))
	for y in range(18):
		for x in range(18):
			var dx := float(x) - 8.5
			var dy := float(y) - 8.5
			if dx * dx + dy * dy <= 45.0:
				image.set_pixel(x, y, accent)
	return ImageTexture.create_from_image(image)
