extends Control

## Controller prompt rail shared by Hangar and modal screens. InputRouter maps
## A/B/X/Y + LB/RB + Start/Back for generic XInput/PlayStation pads, so this
## UI stays platform-neutral while still giving console users visible prompts.

const HEIGHT := 34.0
var _label: Label = null
var _last_connected: bool = false

func _ready() -> void:
	z_index = 900
	mouse_filter = Control.MOUSE_FILTER_IGNORE
	_build()
	_refresh()
	if Events.gamepad_connection_changed.is_connected(_on_gamepad_connection) == false:
		Events.gamepad_connection_changed.connect(_on_gamepad_connection)

func _process(_delta: float) -> void:
	var connected := not Input.get_connected_joypads().is_empty()
	if connected != _last_connected:
		_refresh()

func _on_gamepad_connection(_device: int, _connected: bool) -> void:
	_refresh()

func _build() -> void:
	var panel := ColorRect.new()
	panel.name = "ControllerPromptPanel"
	panel.color = Color(0.02, 0.025, 0.035, 0.88)
	panel.mouse_filter = Control.MOUSE_FILTER_IGNORE
	add_child(panel)
	panel.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)

	_label = Label.new()
	_label.name = "ControllerPrompts"
	_label.add_theme_font_size_override("font_size", 13)
	_label.add_theme_color_override("font_color", UiTheme.TEXT)
	_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	_label.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
	_label.mouse_filter = Control.MOUSE_FILTER_IGNORE
	add_child(_label)
	_label.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)

func _refresh() -> void:
	_last_connected = not Input.get_connected_joypads().is_empty()
	visible = _last_connected
	if _label != null:
		_label.text = "GAMEPAD  ·  A SELECT  ·  B BACK  ·  LB/RB WEAPONS  ·  X ALT  ·  Y LOCK  ·  START PAUSE"
