class_name HangarSlots
extends RefCounted

# Data-driven hangar display anchors (prompt: HangarSlot with platform
# transform / robot transform / scale / label anchor / occupied / robot_id).
# Six physical platforms stand in the bay: five mech pads (hero centre +
# four staggered flanks, front pair nearer the camera) and one elevated
# titan pad at the rear. Positions are world-space preview coordinates
# (hangar floor at y = 0); the pose driver only offsets its own origin.

enum Role { HERO, FRONT_LEFT, FRONT_RIGHT, BACK_LEFT, BACK_RIGHT, TITAN }

const HERO := 0
const TITAN_SLOT := 5

# yaw: slight per-slot convergence so the roster reads as machines parked
# in a room, not six clones facing the same way.
const SLOTS: Array[Dictionary] = [
	{"role": Role.HERO, "pos": Vector3(0.0, 0.0, 0.0), "yaw": 0.0,
		"radius": 2.5, "top": 0.34, "titan": false},
	{"role": Role.FRONT_LEFT, "pos": Vector3(-5.4, 0.0, -3.0), "yaw": 15.0,
		"radius": 2.2, "top": 0.3, "titan": false},
	{"role": Role.FRONT_RIGHT, "pos": Vector3(5.4, 0.0, -3.0), "yaw": -15.0,
		"radius": 2.2, "top": 0.3, "titan": false},
	{"role": Role.BACK_LEFT, "pos": Vector3(-6.9, 0.0, -7.6), "yaw": 26.0,
		"radius": 2.2, "top": 0.3, "titan": false},
	{"role": Role.BACK_RIGHT, "pos": Vector3(6.9, 0.0, -7.6), "yaw": -26.0,
		"radius": 2.2, "top": 0.3, "titan": false},
	{"role": Role.TITAN, "pos": Vector3(0.0, 0.0, -13.5), "yaw": 0.0,
		"radius": 3.7, "top": 1.15, "titan": true},
]

# Which robot stands on which platform ("" = empty pad). The selected
# robot always occupies its class platform — mech -> hero, titan -> the
# dedicated titan pad — so previewing an unowned chassis from the store
# still stands somewhere believable. Remaining OWNED robots of each class
# fill the free pads of that class; robots not on a pad live in inventory
# (hangar shows the active roster, not the whole collection).
static func assignment() -> Array[StringName]:
	var result: Array[StringName] = []
	for slot in SLOTS:
		result.append(&"")
	var selected := GameState.selected_robot
	var selected_is_titan := GameState.is_titan(selected)
	var mechs: Array[StringName] = []
	for robot_id in GameState.ROBOT_ORDER:
		if GameState.is_titan(robot_id):
			continue
		if not GameState.owns_robot(robot_id) or robot_id == selected:
			continue
		mechs.append(robot_id)
	var next_mech := 0
	if not selected_is_titan:
		result[HERO] = selected
	elif not mechs.is_empty():
		result[HERO] = mechs[0]
		next_mech = 1
	for slot_index in [1, 2, 3, 4]:
		if next_mech >= mechs.size():
			break
		result[slot_index] = mechs[next_mech]
		next_mech += 1
	# Titan pad: the selected titan wins it, else the remembered active
	# titan, else the first owned titan in roster order.
	var titan_id: StringName = &""
	if selected_is_titan:
		titan_id = selected
	else:
		titan_id = GameState.active_titan
		if titan_id != &"" and not GameState.owns_robot(titan_id):
			titan_id = &""
		if titan_id == &"":
			for robot_id in GameState.ROBOT_ORDER:
				if GameState.is_titan(robot_id) and GameState.owns_robot(robot_id):
					titan_id = robot_id
					break
	result[TITAN_SLOT] = titan_id
	return result

# Slot centre in world space at mid-robot height — click hit-testing and
# camera focus both aim here.
static func slot_centre(index: int) -> Vector3:
	var slot: Dictionary = SLOTS[index]
	var height: float = (6.0 if bool(slot["titan"]) else 3.4) + float(slot["top"])
	return Vector3(float(slot["pos"].x), height * 0.5, float(slot["pos"].z))
