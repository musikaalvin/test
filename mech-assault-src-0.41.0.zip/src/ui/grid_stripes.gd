class_name GridStripes
extends Control

@export var spacing: float = 64.0
@export var line_color: Color = Color(0.22, 0.4, 0.5, 0.16)
@export var accent_color: Color = Color(0.85, 0.68, 0.3, 0.1)

func _ready() -> void:
	mouse_filter = Control.MOUSE_FILTER_IGNORE

func _draw() -> void:
	var size := get_rect().size
	var columns := int(size.x / spacing) + 1
	var rows := int(size.y / spacing) + 1
	for column in columns:
		var x := float(column) * spacing
		draw_line(Vector2(x, 0.0), Vector2(x, size.y), line_color, 1.0)
	for row in rows:
		var y := float(row) * spacing
		draw_line(Vector2(0.0, y), Vector2(size.x, y), line_color, 1.0)
	draw_rect(Rect2(Vector2.ZERO, size), accent_color, false, 3.0)