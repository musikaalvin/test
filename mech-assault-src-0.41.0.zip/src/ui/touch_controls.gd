class_name TouchControls
extends Control

# War Robots-style circular controller: one ring carries EVERYTHING — the
# robot's ability wedge (6 o'clock), an optional secondary-ability wedge for
# titans, one wedge per equipped weapon, a LOCK plate in the first gap, and
# the red fire-all button at the centre. No floating duplicate buttons beside
# the ring (the director's rule: if it is on the circular controller, it is
# only on the circular controller). Every wedge carries its weapon-family
# glyph and, while waiting, a live countdown. Everything drawn procedurally.

const STICK_RADIUS := 120.0
const LOOK_ZONE_RATIO := 0.35
const FIRE_SIZE := 130.0
const PANEL_RADIUS := 120.0		# mid radius of the segment ring
const WEDGE_INNER := 86.0		# ring inner edge (clears the heat arc)
const WEDGE_OUTER := 154.0		# ring outer edge
const SEG_SIZE := Vector2(84.0, 68.0)
const LOCK_SIZE := 64.0
const CHARGE_SYNC_TRIES := 300		# frames to wait for the ability setup emit
const TAP_GUARD_TIME := 0.3			# per-gesture dedupe: raw touch + emulated mouse
# War Robots style palette: dark glass shells, thin hot edges, muted steel text.
const GLASS_BG := Color(0.045, 0.07, 0.1, 0.52)
const GLASS_EDGE := Color(0.6, 0.85, 0.95, 0.5)
const FIRE_BG := Color(0.5, 0.1, 0.1, 0.62)
const FIRE_PRESSED_BG := Color(0.78, 0.18, 0.15, 0.8)
const FIRE_EDGE := Color(1.0, 0.6, 0.54, 0.9)
const FIRE_TEXT := Color(1.0, 0.93, 0.9)
const ABILITY_BG := Color(0.04, 0.3, 0.4, 0.62)
const ABILITY_EDGE := Color(0.45, 0.93, 1.0, 0.9)
const SECONDARY_BG := Color(0.4, 0.3, 0.06, 0.66)
const SECONDARY_EDGE := Color(1.0, 0.8, 0.36, 0.9)
const HOT_COLOR := Color(1.0, 0.68, 0.2)
const GROUP_COLORS: Array[Color] = [
	Color(0.45, 0.85, 1.0),		# group 0 / slots 0,1 - cyan
	Color(1.0, 0.72, 0.35),		# group 1 / slots 2,3 - amber
]

var _touch_index: int = -1
var _stick_origin: Vector2 = Vector2.ZERO
var _stick_value: Vector2 = Vector2.ZERO
var _fire_button: Button
var _ability_slice: Button
var _secondary_slice: Button
var _secondary_available: int = 0
var _segment_buttons: Array[Button] = []
var _segment_slots: Array[int] = []
var _seg_kinds: Array[int] = []
var _seg_families: Array[String] = []
var _seg_remaining: Array[float] = []
var _seg_ratio: Array[float] = []
var _seg_overheat: Array[bool] = []
# Wedges whose gun has been blown off the hull: drawn as a dead slot.
var _seg_dead: Array[bool] = []
var _lock_button: Button
var _held: Array[bool] = []
var _lock_pressed: bool = false
var _ability_ratio: float = 1.0
var _ability_available: int = 1
var _heat_ratio: float = 0.0
var _overheated: bool = false
var _firing: bool = false
var _pulse: float = 0.0
var _secondary_ratio: float = 1.0
var _chip_box: StyleBoxFlat = null
var _move_caption: Label = null
var _look_caption: Label = null
var _laid_out: Vector2 = Vector2(-1.0, -1.0)
var _layout_frames: int = 0
var _seat_controls: Array[Control] = []
var _seat_positions: Array[Vector2] = []
var _weapons: WeaponSystem = null
var _charge_sync_tries: int = 0
var _charges_synced: bool = false
# Raw multi-touch state: a second finger (while the stick is held) never
# reaches the Buttons, so every wheel widget is also claimed here directly
# from ScreenTouch. Button state and raw state are OR'd, taps are deduped.
var _button_fire: bool = false
var _raw_fire_count: int = 0
var _button_slots: Array[bool] = [false, false, false, false]
var _raw_slot_counts: Array[int] = [0, 0, 0, 0]
var _raw_roles: Dictionary = {}		# touch index -> "fire"/"lock"/"ability"/…
var _button_lock: bool = false
var _raw_lock_held: bool = false
var _tap_guards: Dictionary = {}	# action -> seconds left before next tap

static func should_show() -> bool:
	if PlatformUtil.is_headless():
		return true	# smoke always asserts the full rig on screen
	if GameState.input_ui_mode == GameState.UiMode.FORCE_TOUCH:
		return true
	if GameState.input_ui_mode == GameState.UiMode.FORCE_OFF:
		return false
	if PlatformUtil.is_mobile_platform():
		return true	# a phone's rig never disappears under a stray key
	return PlatformUtil.current_mode == PlatformUtil.InputMode.TOUCH

func _ready() -> void:
	set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	visible = should_show()
	mouse_filter = Control.MOUSE_FILTER_IGNORE
	_chip_box = _glass(Color(0.04, 0.07, 0.1, 0.55), GLASS_EDGE, 8, 1)
	_build_buttons()
	_build_look_zone()
	Events.ability_charges_changed.connect(_on_ability_charges)
	Events.secondary_ability_charges_changed.connect(_on_secondary_charges)
	Events.weapon_heat_changed.connect(_on_weapon_heat)
	Events.mode_changed.connect(_on_mode_changed)
	call_deferred("_reassert_layout")

func _on_mode_changed(_mode: int) -> void:
	var rig_visible := should_show()
	if visible == rig_visible:
		return
	visible = rig_visible
	if not visible:
		InputRouter.clear_temporary()	# a held stick drag must not stick on
		_reset_raw_state()
	queue_redraw()

func _reset_raw_state() -> void:
	_raw_roles.clear()
	_raw_fire_count = 0
	for index in _raw_slot_counts.size():
		_raw_slot_counts[index] = 0
	_button_fire = false
	for index in _button_slots.size():
		_button_slots[index] = false
	_button_lock = false
	_raw_lock_held = false
	_tap_guards.clear()
	_sync_fire()
	for index in _button_slots.size():
		_sync_slot(index)
	_sync_lock_visual()

func _on_weapon_heat(peak: float, overheated: bool) -> void:
	var ratio_changed := not is_equal_approx(_heat_ratio, peak)
	_heat_ratio = clampf(peak, 0.0, 1.0)
	if _overheated != overheated or ratio_changed:
		_overheated = overheated
		queue_redraw()

func _on_ability_charges(available: int, _maximum: int, recharge_ratio: float) -> void:
	_ability_available = available
	_ability_ratio = clampf(recharge_ratio, 0.0, 1.0)
	_charges_synced = true
	if _ability_slice != null:
		var base := String(GameState.robot_def().get("ability_short", "DASH"))
		_ability_slice.text = "%s ×%d" % [base, maxi(available, 0)]
	queue_redraw()

func _on_secondary_charges(available: int, _maximum: int, recharge_ratio: float) -> void:
	_secondary_available = available
	_secondary_ratio = clampf(recharge_ratio, 0.0, 1.0)
	_charges_synced = true
	if _secondary_slice != null:
		var base := String(GameState.robot_def().get("secondary_short", "SEC"))
		_secondary_slice.text = "%s ×%d" % [base, maxi(available, 0)]
	queue_redraw()

func _notification(what: int) -> void:
	if what == NOTIFICATION_RESIZED:
		queue_redraw()

func _reassert_layout() -> void:
	set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	queue_redraw()

func _process(delta: float) -> void:
	_layout_frames += 1
	if not _tap_guards.is_empty():
		var expired: Array = []
		for key: Variant in _tap_guards:
			var left := float(_tap_guards[key]) - delta
			if left <= 0.0:
				expired.append(key)
			else:
				_tap_guards[key] = left
		for key: Variant in expired:
			_tap_guards.erase(key)
	if (size.x < 100.0 or size.y < 100.0) and _layout_frames < 600:
		_reassert_layout()
	if size.x > 50.0 and size.y > 50.0 and (size != _laid_out or not _buttons_seated()):
		_layout_panel()
	if not _charges_synced and _charge_sync_tries < CHARGE_SYNC_TRIES:
		_try_sync_charges()
		queue_redraw()
	_refresh_cooldowns()
	if _ability_ratio < 0.999 or _secondary_ratio < 0.999:
		queue_redraw()
	var changed := false
	for index in _segment_slots.size():
		var slot := _segment_slots[index]
		var is_held := InputRouter.slot_held[slot] or InputRouter.group_held[slot >> 1]
		if _held.size() <= index:
			_held.append(is_held)
		elif _held[index] != is_held:
			_held[index] = is_held
			changed = true
	if changed:
		queue_redraw()
	if _overheated or _firing or _lock_pressed:
		_pulse = fmod(_pulse + delta, 1.0)
		queue_redraw()

# The ability setup emit fires before this control exists (the session builds
# the touch layer first), so read the charges straight off the pilot instead
# of waiting for an event that already went out.
func _try_sync_charges() -> void:
	_charge_sync_tries += 1
	var session := _find_session()
	if session == null or session.player == null or not is_instance_valid(session.player):
		return
	var pilot := session.player
	if pilot.ability != null:
		_on_ability_charges(pilot.ability.charges, pilot.ability.max_charges,
				pilot.ability.recharge_ratio())
	if pilot.ability2 != null:
		_on_secondary_charges(pilot.ability2.charges, pilot.ability2.max_charges,
				pilot.ability2.recharge_ratio())
	_charges_synced = true

func _find_session() -> GameSession:
	var node: Node = get_parent()
	while node != null:
		if node is GameSession:
			return node as GameSession
		node = node.get_parent()
	return null

func _resolve_weapons() -> WeaponSystem:
	if _weapons != null and is_instance_valid(_weapons):
		return _weapons
	var node: Node = get_parent()
	while node != null:
		if node is GameSession:
			var session := node as GameSession
			if session.player != null and is_instance_valid(session.player):
				_weapons = session.player.weapons
				return _weapons
		node = node.get_parent()
	return null

# Per-wedge cooldown: overheat drains heat at cooldown_rate * 1.7, magazine
# weapons count down _reload_left. Both totals are derived from WeaponData so
# the countdown on screen matches the mount exactly.
func _refresh_cooldowns() -> void:
	var weapon_system := _resolve_weapons()
	var changed := false
	for index in _segment_slots.size():
		var slot := _segment_slots[index]
		var remaining := 0.0
		var fraction := 0.0
		var hot := false
		var dead := false
		if weapon_system != null and slot < weapon_system.mounts.size():
			var mount := weapon_system.mounts[slot]
			if mount != null and mount.data != null:
				dead = mount.destroyed
				if not dead:
					hot = mount.is_overheated()
					remaining = _mount_wait(mount, hot)
					fraction = _mount_wait_fraction(mount, remaining)
		if remaining > 0.05 or _seg_remaining[index] > 0.05 or hot != _seg_overheat[index] \
				or dead != _seg_dead[index]:
			changed = true
		_seg_remaining[index] = remaining
		_seg_ratio[index] = fraction
		_seg_overheat[index] = hot
		_seg_dead[index] = dead
	if changed:
		queue_redraw()

func _mount_wait(mount: WeaponMount, hot: bool) -> float:
	if hot:
		var rate := mount.data.cooldown_rate * 1.7
		if rate <= 0.0:
			return 0.0
		return maxf(mount.heat - mount.data.overheat_lock, 0.0) / rate
	if mount.is_reloading() and mount.data.reload_time > 0.0:
		return (1.0 - mount.reload_ratio()) * mount.data.reload_time
	return 0.0

func _mount_wait_fraction(mount: WeaponMount, remaining: float) -> float:
	if remaining <= 0.001:
		return 0.0
	if mount.is_overheated():
		var rate := maxf(mount.data.cooldown_rate * 1.7, 0.0001)
		var total := maxf((1.0 - mount.data.overheat_lock) / rate, 0.0001)
		return clampf(remaining / total, 0.0, 1.0)
	if mount.data.reload_time > 0.0:
		return clampf(remaining / mount.data.reload_time, 0.0, 1.0)
	return 0.0

func _record_seat(button: Control) -> void:
	if button != null:
		_seat_controls.append(button)
		_seat_positions.append(button.position)

# Layout self-heal: a device that collapses the root (or shoves a button)
# shows up here as a drifted rect and gets re-laid out on the next frame.
func _buttons_seated() -> bool:
	if _seat_controls.is_empty():
		return false
	for index in _seat_controls.size():
		var node := _seat_controls[index]
		if not is_instance_valid(node):
			return false
		if node.position.distance_to(_seat_positions[index]) > 1.0:
			return false
	return true

func _glass(bg: Color, edge: Color, radius: int, edge_width: int = 2) -> StyleBoxFlat:
	var style := StyleBoxFlat.new()
	style.bg_color = bg
	style.set_corner_radius_all(radius)
	style.border_width_left = edge_width
	style.border_width_right = edge_width
	style.border_width_top = edge_width
	style.border_width_bottom = edge_width
	style.border_color = edge
	style.shadow_color = Color(0.0, 0.0, 0.0, 0.42)
	style.shadow_size = 6
	style.shadow_offset = Vector2(0.0, 3.0)
	style.anti_aliasing = true
	return style

# ---------------------------------------------------------------- panel layout

func _panel_center() -> Vector2:
	return Vector2(size.x - 185.0, size.y - 180.0)

func _slice_base() -> int:
	# Slice 0 = ability; slice 1 = secondary when the robot has one.
	return 2 if _secondary_slice != null else 1

func _segment_count() -> int:
	return _slice_base() + _segment_slots.size()

func _slice_button(index: int) -> Button:
	if index == 0:
		return _ability_slice
	if _secondary_slice != null and index == 1:
		return _secondary_slice
	var weapon := index - _slice_base()
	if weapon >= 0 and weapon < _segment_buttons.size():
		return _segment_buttons[weapon]
	return null

func _slice_angle(index: int) -> float:
	# Ability pinned at 6 o'clock; secondary (titans) and weapons follow.
	return PI * 0.5 + float(index) * TAU / float(_segment_count())

func _lock_angle() -> float:
	# Midpoint of the first wedge gap (between the ability and its neighbour).
	return PI * 0.5 + PI / float(_segment_count())

func _layout_panel() -> void:
	_laid_out = size
	_seat_controls.clear()
	_seat_positions.clear()
	var centre := _panel_center()
	_fire_button.size = Vector2(FIRE_SIZE, FIRE_SIZE)
	_fire_button.position = centre - Vector2(FIRE_SIZE, FIRE_SIZE) * 0.5
	_record_seat(_fire_button)
	for index in _segment_count():
		var button := _slice_button(index)
		if button == null:
			continue
		var direction := Vector2(cos(_slice_angle(index)), sin(_slice_angle(index)))
		button.size = SEG_SIZE
		button.position = centre + direction * PANEL_RADIUS - SEG_SIZE * 0.5
		_record_seat(button)
	# LOCK plate: seated in the first wedge gap below-left of FIRE.
	var lock_direction := Vector2(cos(_lock_angle()), sin(_lock_angle()))
	_lock_button.size = Vector2(LOCK_SIZE, LOCK_SIZE)
	_lock_button.position = centre + lock_direction * PANEL_RADIUS \
			- Vector2(LOCK_SIZE, LOCK_SIZE) * 0.5
	_record_seat(_lock_button)

func _build_buttons() -> void:
	_fire_button = Button.new()
	_fire_button.name = "FireButton"
	_fire_button.text = "FIRE"
	_fire_button.focus_mode = Control.FOCUS_NONE
	_fire_button.add_theme_font_size_override("font_size", 22)
	_fire_button.add_theme_color_override("font_color", FIRE_TEXT)
	_fire_button.add_theme_color_override("font_hover_color", FIRE_TEXT)
	_fire_button.add_theme_color_override("font_pressed_color", Color(1.0, 1.0, 1.0))
	var fire_style := _glass(FIRE_BG, FIRE_EDGE, 66, 3)
	_fire_button.add_theme_stylebox_override("normal", fire_style)
	var fire_pressed := _glass(FIRE_PRESSED_BG, Color(1.0, 0.86, 0.82, 1.0), 66, 3)
	_fire_button.add_theme_stylebox_override("pressed", fire_pressed)
	_fire_button.add_theme_stylebox_override("hover", fire_style)
	_fire_button.button_down.connect(_on_fire_down)
	_fire_button.button_up.connect(_on_fire_up)
	_fire_button.mouse_filter = Control.MOUSE_FILTER_PASS	# raw touch must fall through to us
	add_child(_fire_button)

	# Ability wedge (6 o'clock) and, for titans, the secondary wedge — both
	# live ON the ring; the wedge art draws their labels, so the native button
	# text stays invisible (kept for tools/smoke introspection).
	_ability_slice = Button.new()
	_ability_slice.name = "AbilitySliceButton"
	_ability_slice.focus_mode = Control.FOCUS_NONE
	_ability_slice.flat = true
	_ability_slice.text = String(GameState.robot_def().get("ability_short", "DASH"))
	_hide_button_label(_ability_slice)
	_ability_slice.mouse_filter = Control.MOUSE_FILTER_PASS
	_ability_slice.pressed.connect(_request_ability)
	add_child(_ability_slice)

	if not String(GameState.robot_def().get("secondary", "")).is_empty():
		_secondary_slice = Button.new()
		_secondary_slice.name = "SecondarySliceButton"
		_secondary_slice.focus_mode = Control.FOCUS_NONE
		_secondary_slice.flat = true
		_secondary_slice.text = String(GameState.robot_def().get(
				"secondary_short", "SEC"))
		_hide_button_label(_secondary_slice)
		_secondary_slice.mouse_filter = Control.MOUSE_FILTER_PASS
		_secondary_slice.pressed.connect(_request_secondary)
		add_child(_secondary_slice)

	# One flat hit-plate per equipped weapon; the wedge art is drawn underneath.
	for slot in GameState.slot_count():
		var item_id := String(GameState.equipped_item(GameState.selected_robot, slot))
		if item_id.is_empty():
			continue
		var button := Button.new()
		button.name = "WeaponSlot%d" % slot
		button.focus_mode = Control.FOCUS_NONE
		button.flat = true
		button.button_down.connect(_on_slot_down.bind(slot))
		button.button_up.connect(_on_slot_up.bind(slot))
		button.mouse_filter = Control.MOUSE_FILTER_PASS
		add_child(button)
		_segment_buttons.append(button)
		_segment_slots.append(slot)
		# Cached per wedge so the redraw path never allocates a WeaponData.
		var weapon := WeaponData.for_item(item_id)
		var family := GameState.item_family(item_id)
		var kind_value := -1
		if weapon != null:
			kind_value = int(weapon.kind)
			if family.is_empty():
				family = weapon.family
		_seg_kinds.append(kind_value)
		_seg_families.append(family if not family.is_empty() else "EMPTY")
	_seg_remaining.resize(_segment_slots.size())
	_seg_ratio.resize(_segment_slots.size())
	_seg_overheat.resize(_segment_slots.size())
	_seg_overheat.fill(false)
	_seg_dead.resize(_segment_slots.size())
	_seg_dead.fill(false)

	# Added after the wedges so the plate wins its few-pixel overlaps.
	_lock_button = Button.new()
	_lock_button.name = "LockButton"
	_lock_button.focus_mode = Control.FOCUS_NONE
	_lock_button.flat = true
	_lock_button.button_down.connect(_on_lock_down)
	_lock_button.button_up.connect(_on_lock_up)
	_lock_button.pressed.connect(_on_lock_pressed)
	_lock_button.mouse_filter = Control.MOUSE_FILTER_PASS
	add_child(_lock_button)

	_build_captions()


func _hide_button_label(button: Button) -> void:
	button.add_theme_color_override("font_color", Color(0.0, 0.0, 0.0, 0.0))
	button.add_theme_color_override("font_hover_color", Color(0.0, 0.0, 0.0, 0.0))
	button.add_theme_color_override("font_pressed_color", Color(0.0, 0.0, 0.0, 0.0))
	button.add_theme_color_override("font_focus_color", Color(0.0, 0.0, 0.0, 0.0))

func _on_slot_down(slot: int) -> void:
	_button_slots[slot] = true
	_sync_slot(slot)

func _on_slot_up(slot: int) -> void:
	_button_slots[slot] = false
	_sync_slot(slot)

func _sync_slot(slot: int) -> void:
	if slot < 0 or slot >= _raw_slot_counts.size():
		return
	InputRouter.set_virtual_slot(slot,
			_raw_slot_counts[slot] > 0 or _button_slots[slot])

func _on_lock_down() -> void:
	_button_lock = true
	_sync_lock_visual()

func _on_lock_up() -> void:
	_button_lock = false
	_sync_lock_visual()

func _on_lock_pressed() -> void:
	_request_lock()

func _request_lock() -> void:
	if _tap_guards.has(&"lock"):
		return
	_tap_guards[&"lock"] = TAP_GUARD_TIME
	Events.lock_cycle_requested.emit()

func _request_ability() -> void:
	if _tap_guards.has(&"ability"):
		return
	_tap_guards[&"ability"] = TAP_GUARD_TIME
	InputRouter.request_ability()

func _request_secondary() -> void:
	if _tap_guards.has(&"secondary"):
		return
	_tap_guards[&"secondary"] = TAP_GUARD_TIME
	InputRouter.request_secondary_ability()

func _segment_family(seg: int) -> String:
	if seg < 0 or seg >= _seg_families.size():
		return "EMPTY"
	return _seg_families[seg]

func _seg_kind(seg: int) -> int:
	if seg < 0 or seg >= _seg_kinds.size():
		return -1
	return _seg_kinds[seg]

func _build_captions() -> void:
	_add_caption("MOVE", Control.PRESET_BOTTOM_LEFT, Vector2(48.0, -96.0))
	_add_caption("LOOK", Control.PRESET_BOTTOM_RIGHT, Vector2(-370.0, -60.0))

func _add_caption(text: String, preset: Control.LayoutPreset, offset: Vector2) -> void:
	var caption := Label.new()
	caption.name = "%sHint" % text
	caption.text = text
	caption.add_theme_font_size_override("font_size", 15)
	caption.add_theme_color_override("font_color", Color(0.7, 0.85, 0.95, 0.4))
	caption.add_theme_constant_override("outline_size", 4)
	caption.add_theme_color_override("font_outline_color", Color(0.0, 0.0, 0.0, 0.5))
	caption.mouse_filter = Control.MOUSE_FILTER_IGNORE
	add_child(caption)
	caption.set_anchors_preset(preset)
	caption.position += offset
	if text == "MOVE":
		_move_caption = caption
	else:
		_look_caption = caption

func _build_look_zone() -> void:
	var look_zone := Control.new()
	look_zone.name = "LookZone"
	look_zone.anchor_left = LOOK_ZONE_RATIO
	look_zone.anchor_top = 0.0
	look_zone.anchor_right = 1.0
	look_zone.anchor_bottom = 1.0
	look_zone.offset_left = 0.0
	look_zone.offset_top = 0.0
	look_zone.offset_right = 0.0
	look_zone.offset_bottom = 0.0
	look_zone.mouse_filter = Control.MOUSE_FILTER_IGNORE
	add_child(look_zone)

func _unhandled_input(event: InputEvent) -> void:
	if not visible:
		return
	if event is InputEventScreenTouch:
		var touch := event as InputEventScreenTouch
		if touch.pressed:
			_raw_touch_down(touch)
		else:
			_raw_touch_up(touch)
	elif event is InputEventScreenDrag:
		var drag := event as InputEventScreenDrag
		if drag.index == _touch_index:
			_stick_value = ((drag.position - _stick_origin) / STICK_RADIUS).limit_length(1.0)
			if _stick_value.length() < 0.12:
				_stick_value = Vector2.ZERO
			InputRouter.set_virtual_move(Vector2(_stick_value.x, -_stick_value.y))
			queue_redraw()
		elif String(_raw_roles.get(drag.index, "")) == "fire" \
				and not _inside_fire(drag.position):
			_raw_roles.erase(drag.index)
			_end_role("fire", drag.position)

# A second finger never reaches the Buttons (the gui only routes the
# emulated mouse to them), so every wheel widget is claimed here straight
# from the raw ScreenTouch — hold for fire/segments, tap for ability and
# lock. Positions arrive in canvas space, same as the stick code.
func _raw_touch_down(touch: InputEventScreenTouch) -> void:
	if touch.index == _touch_index:
		return	# the move stick owns this finger
	var role := _role_at(touch.position)
	if role != "":
		_raw_roles[touch.index] = role
		_begin_role(role)
		return
	if _touch_index == -1 and touch.position.x < size.x * LOOK_ZONE_RATIO:
		_touch_index = touch.index
		_stick_origin = touch.position
		_stick_value = Vector2.ZERO
		InputRouter.set_virtual_move(Vector2.ZERO)
		queue_redraw()

func _raw_touch_up(touch: InputEventScreenTouch) -> void:
	if _raw_roles.has(touch.index):
		var role := String(_raw_roles[touch.index])
		_raw_roles.erase(touch.index)
		_end_role(role, touch.position)
		return
	if touch.index == _touch_index:
		_touch_index = -1
		_stick_value = Vector2.ZERO
		InputRouter.set_virtual_move(Vector2.ZERO)
		queue_redraw()

func _role_at(pos: Vector2) -> String:
	if _inside_fire(pos):
		return "fire"
	if _button_hit(_lock_button, pos):
		return "lock"
	if _button_hit(_ability_slice, pos):
		return "ability"
	if _button_hit(_secondary_slice, pos):
		return "secondary"
	for index in _segment_buttons.size():
		if _button_hit(_segment_buttons[index], pos):
			return "slot%d" % _segment_slots[index]
	return ""

func _button_hit(button: Control, pos: Vector2) -> bool:
	if button == null or not button.visible:
		return false
	return button.get_rect().has_point(pos)

func _inside_fire(pos: Vector2) -> bool:
	if _fire_button == null:
		return false
	var centre := _fire_button.position + _fire_button.size * 0.5
	return pos.distance_to(centre) <= _fire_button.size.x * 0.5 + 8.0

func _begin_role(role: String) -> void:
	if role.begins_with("slot"):
		var slot := int(role.substr(4))
		if slot >= 0 and slot < _raw_slot_counts.size():
			_raw_slot_counts[slot] += 1
			_sync_slot(slot)
	elif role == "fire":
		_raw_fire_count += 1
		_sync_fire()
	elif role == "lock":
		_raw_lock_held = true
		_sync_lock_visual()

func _end_role(role: String, at: Vector2) -> void:
	if role.begins_with("slot"):
		var slot := int(role.substr(4))
		if slot >= 0 and slot < _raw_slot_counts.size():
			_raw_slot_counts[slot] = maxi(_raw_slot_counts[slot] - 1, 0)
			_sync_slot(slot)
	elif role == "fire":
		_raw_fire_count = maxi(_raw_fire_count - 1, 0)
		_sync_fire()
	elif role == "lock":
		_raw_lock_held = false
		_sync_lock_visual()
	elif role == "ability":
		if _button_hit(_ability_slice, at):
			_request_ability()
	elif role == "secondary":
		if _button_hit(_secondary_slice, at):
			_request_secondary()

func _draw() -> void:
	_draw_caption_chips()
	_draw_stick()
	_draw_weapon_panel()
	_draw_fire_ring()

func _draw_caption_chips() -> void:
	if _chip_box == null:
		return
	for caption: Label in [_move_caption, _look_caption]:
		if caption == null:
			continue
		var rect := Rect2(caption.position + Vector2(-12.0, -7.0),
				caption.size + Vector2(24.0, 14.0))
		if rect.size.x <= 1.0 or rect.size.y <= 1.0:
			continue
		draw_style_box(_chip_box, rect)

func _draw_stick() -> void:
	var font := get_theme_default_font()
	var edge := Color(GLASS_EDGE.r, GLASS_EDGE.g, GLASS_EDGE.b, 0.5)
	if _touch_index == -1:
		var idle := Vector2(size.x * 0.17, size.y * 0.68)
		draw_circle(idle, STICK_RADIUS * 0.9,
				Color(GLASS_BG.r, GLASS_BG.g, GLASS_BG.b, 0.4))
		draw_arc(idle, STICK_RADIUS * 0.9, 0.0, TAU, 56, edge, 2.5)
		draw_arc(idle, STICK_RADIUS * 0.58, 0.0, TAU, 40, Color(1.0, 1.0, 1.0, 0.07), 1.5)
		for tick in 4:
			var dir := Vector2(cos(TAU * tick / 4.0), sin(TAU * tick / 4.0))
			draw_line(idle + dir * STICK_RADIUS * 0.76, idle + dir * STICK_RADIUS * 0.9,
					Color(edge.r, edge.g, edge.b, 0.75), 2.0)
		draw_string(font, idle + Vector2(-30.0, 8.0), "MOVE",
				HORIZONTAL_ALIGNMENT_CENTER, 60.0, 16, Color(0.75, 0.9, 1.0, 0.42))
		return
	draw_circle(_stick_origin, STICK_RADIUS, Color(0.05, 0.09, 0.13, 0.5))
	draw_arc(_stick_origin, STICK_RADIUS, 0.0, TAU, 56,
			Color(edge.r, edge.g, edge.b, 0.85), 3.5)
	var knob := _stick_origin + _stick_value * STICK_RADIUS
	if _stick_value.length() > 0.05:
		draw_line(_stick_origin, knob, Color(0.7, 0.95, 1.0, 0.28), 9.0)
	draw_circle(knob, 44.0, Color(0.85, 0.97, 1.0, 0.6))
	draw_arc(knob, 44.0, 0.0, TAU, 32, Color(1.0, 1.0, 1.0, 0.9), 2.5)
	draw_circle(knob, 15.0, Color(1.0, 1.0, 1.0, 0.8))

# ------------------------------------------------------------ weapon ring art

func _wedge_points(centre: Vector2, angle_mid: float, angle_half: float) -> PackedVector2Array:
	return _wedge_span(centre, angle_mid - angle_half, angle_mid + angle_half)

func _wedge_span(centre: Vector2, from_angle: float, to_angle: float) -> PackedVector2Array:
	var points := PackedVector2Array()
	const STEPS := 8
	for i in STEPS + 1:
		var angle := lerpf(from_angle, to_angle, float(i) / float(STEPS))
		points.append(centre + Vector2(cos(angle), sin(angle)) * WEDGE_OUTER)
	for i in STEPS + 1:
		var angle := lerpf(to_angle, from_angle, float(i) / float(STEPS))
		points.append(centre + Vector2(cos(angle), sin(angle)) * WEDGE_INNER)
	return points

# Dark overlay covering the still-waiting part of a wedge.
func _wedge_band(centre: Vector2, angle_mid: float, angle_half: float,
		fraction: float) -> PackedVector2Array:
	var span := angle_half * clampf(fraction, 0.0, 1.0)
	return _wedge_span(centre, angle_mid - angle_half,
			angle_mid - angle_half + span * 2.0)

func _group_color(group: int) -> Color:
	return GROUP_COLORS[clampi(group, 0, 1)]

func _draw_weapon_panel() -> void:
	var font := get_theme_default_font()
	var centre := _panel_center()
	if centre.x < WEDGE_OUTER or centre.y < WEDGE_OUTER:
		return
	var count := _segment_count()
	var half_span := TAU / float(count) * 0.44
	# Backing disc so the wedges read as one instrument.
	draw_circle(centre, WEDGE_OUTER + 6.0, Color(0.03, 0.05, 0.07, 0.55))
	draw_arc(centre, WEDGE_OUTER + 6.0, 0.0, TAU, 72, Color(0.5, 0.75, 0.85, 0.35), 2.0, true)
	for index in count:
		var angle := _slice_angle(index)
		var mid := Vector2(cos(angle), sin(angle)) * (WEDGE_INNER + WEDGE_OUTER) * 0.5
		var anchor := centre + mid
		if index == 0:
			_draw_ability_slice(centre, angle, half_span, anchor, font)
			continue
		if _secondary_slice != null and index == 1:
			_draw_secondary_slice(centre, angle, half_span, anchor, font)
			continue
		var seg := index - _slice_base()
		if seg >= 0 and seg < _seg_dead.size() and _seg_dead[seg]:
			var dead_slot := _segment_slots[seg] if seg < _segment_slots.size() else 0
			_draw_dead_slice(centre, angle, half_span, anchor, font, dead_slot)
			continue
		var held := seg < _held.size() and _held[seg]
		var seg_hot := seg < _seg_overheat.size() and _seg_overheat[seg]
		var group := _segment_slots[seg] >> 1
		var accent := _group_color(group)
		if seg_hot:
			accent = Color(1.0, 0.45, 0.3)
		if held:
			accent = Color.WHITE
		var colour := Color(accent.r * 0.16, accent.g * 0.16, accent.b * 0.16, 0.7)
		if seg_hot:
			colour = Color(0.4, 0.1, 0.08, 0.72)
		if held:
			colour = colour.lightened(0.35)
			colour.a = 0.9
		draw_colored_polygon(_wedge_points(centre, angle, half_span), colour)
		var remaining := _seg_remaining[seg]
		var wait_fraction := _seg_ratio[seg]
		if wait_fraction > 0.01:
			draw_colored_polygon(_wedge_band(centre, angle, half_span, wait_fraction),
					Color(0.0, 0.0, 0.0, 0.62))
		if remaining > 0.05:
			# Cooling: dimmed glyph, live countdown, family caption.
			var dim := Color(accent.r, accent.g, accent.b, 0.3)
			_draw_family_glyph(_seg_kind(seg), anchor + Vector2(0.0, -18.0), dim)
			var clock := Color(1.0, 0.78, 0.3)
			if _seg_overheat[seg]:
				clock = Color(1.0, 0.44, 0.26)
			draw_string(font, anchor + Vector2(-40.0, 14.0), "%.1f" % remaining,
					HORIZONTAL_ALIGNMENT_CENTER, 80.0, 16, clock)
			draw_string(font, anchor + Vector2(-40.0, 28.0), _segment_family(seg),
					HORIZONTAL_ALIGNMENT_CENTER, 80.0, 9, Color(1.0, 1.0, 1.0, 0.5))
		else:
			_draw_family_glyph(_seg_kind(seg), anchor + Vector2(0.0, -16.0), accent)
			draw_string(font, anchor + Vector2(-40.0, 10.0), _segment_family(seg),
					HORIZONTAL_ALIGNMENT_CENTER, 80.0, 11, accent)
			draw_string(font, anchor + Vector2(-40.0, 26.0),
					"%d" % (_segment_slots[seg] + 1),
					HORIZONTAL_ALIGNMENT_CENTER, 80.0, 10, Color(1.0, 1.0, 1.0, 0.55))
	_draw_lock_glyph(centre, font)

# Wedge for a gun that has been blown off the hull: damaged plate, dashed rim
# and a cross where the family glyph used to sit (the wedge stays in the ring
# so the layout never shifts under the player's thumb).
func _draw_dead_slice(centre: Vector2, angle: float, half_span: float,
		anchor: Vector2, font: Font, slot: int) -> void:
	draw_colored_polygon(_wedge_points(centre, angle, half_span),
			Color(0.05, 0.06, 0.07, 0.58))
	var rim := Color(1.0, 1.0, 1.0, 0.26)
	var steps := 10
	for step in steps:
		if step % 2 == 1:
			continue
		var a0 := angle - half_span + (2.0 * half_span) * (float(step) / float(steps))
		var a1 := angle - half_span + (2.0 * half_span) * (float(step + 1) / float(steps))
		draw_arc(centre, WEDGE_OUTER - 2.0, a0, a1, 5, rim, 2.0, true)
	var dead := Color(1.0, 1.0, 1.0, 0.32)
	var arm := 8.0
	var cross_y := anchor.y - 16.0
	draw_line(anchor + Vector2(-arm, cross_y - arm), anchor + Vector2(arm, cross_y + arm),
			dead, 2.5, true)
	draw_line(anchor + Vector2(-arm, cross_y + arm), anchor + Vector2(arm, cross_y - arm),
			dead, 2.5, true)
	draw_string(font, anchor + Vector2(-40.0, 10.0), "DAMAGED",
			HORIZONTAL_ALIGNMENT_CENTER, 80.0, 11, Color(1.0, 0.36, 0.3, 0.78))
	draw_string(font, anchor + Vector2(-40.0, 26.0), "%d" % (slot + 1),
			HORIZONTAL_ALIGNMENT_CENTER, 80.0, 10, Color(1.0, 1.0, 1.0, 0.4))

# Ability wedge: name, charge count and a recharge sweep along its rim.
func _draw_ability_slice(centre: Vector2, angle: float, half_span: float,
		anchor: Vector2, font: Font) -> void:
	var ready := _ability_available > 0
	var accent := ABILITY_EDGE
	var plate := Color(0.05, 0.24, 0.32, 0.74)
	if not ready:
		accent = Color(ABILITY_EDGE.r, ABILITY_EDGE.g, ABILITY_EDGE.b, 0.5)
		plate = Color(0.16, 0.15, 0.13, 0.6)
	draw_colored_polygon(_wedge_points(centre, angle, half_span), plate)
	if _ability_ratio < 0.999:
		draw_arc(centre, WEDGE_OUTER - 4.0, angle - half_span,
				angle - half_span + 2.0 * half_span * clampf(_ability_ratio, 0.0, 1.0),
				24, Color(accent.r, accent.g, accent.b, 0.95), 4.0, true)
	_draw_family_glyph(WeaponData.Kind.ELECTRIC, anchor + Vector2(0.0, -16.0), accent)
	var label_text := String(GameState.robot_def().get("ability_short", "DASH"))
	draw_string(font, anchor + Vector2(-40.0, 6.0), label_text,
			HORIZONTAL_ALIGNMENT_CENTER, 80.0, 13, accent)
	draw_string(font, anchor + Vector2(-40.0, 22.0), "×%d" % maxi(_ability_available, 0),
			HORIZONTAL_ALIGNMENT_CENTER, 80.0, 11, Color(1.0, 1.0, 1.0, 0.7))

# Secondary-ability wedge (titans): amber plate, name, charges, recharge arc.
func _draw_secondary_slice(centre: Vector2, angle: float, half_span: float,
		anchor: Vector2, font: Font) -> void:
	var ready := _secondary_available > 0
	var accent := SECONDARY_EDGE
	var plate := Color(0.22, 0.16, 0.03, 0.74)
	if not ready:
		accent = Color(SECONDARY_EDGE.r, SECONDARY_EDGE.g, SECONDARY_EDGE.b, 0.5)
		plate = Color(0.16, 0.14, 0.1, 0.6)
	draw_colored_polygon(_wedge_points(centre, angle, half_span), plate)
	if _secondary_ratio < 0.999:
		draw_arc(centre, WEDGE_OUTER - 4.0, angle - half_span,
				angle - half_span + 2.0 * half_span * clampf(_secondary_ratio, 0.0, 1.0),
				24, Color(accent.r, accent.g, accent.b, 0.95), 4.0, true)
	# Double chevron mark.
	for lift in [0.0, 9.0]:
		draw_line(anchor + Vector2(-9.0, -14.0 + lift),
				anchor + Vector2(0.0, -22.0 + lift), accent, 3.0)
		draw_line(anchor + Vector2(0.0, -22.0 + lift),
				anchor + Vector2(9.0, -14.0 + lift), accent, 3.0)
	var label_text := String(GameState.robot_def().get("secondary_short", "SEC"))
	draw_string(font, anchor + Vector2(-40.0, 6.0), label_text,
			HORIZONTAL_ALIGNMENT_CENTER, 80.0, 13, accent)
	draw_string(font, anchor + Vector2(-40.0, 22.0), "×%d" % maxi(_secondary_available, 0),
			HORIZONTAL_ALIGNMENT_CENTER, 80.0, 11, Color(1.0, 1.0, 1.0, 0.7))

# One glyph per weapon family, all pointing up so the ring reads at a glance.
func _draw_family_glyph(kind: int, at: Vector2, colour: Color) -> void:
	match kind:
		WeaponData.Kind.AUTOCANNON:
			for i in 3:
				var x := -7.0 + 7.0 * float(i)
				draw_line(at + Vector2(x, 9.0), at + Vector2(x, -8.0), colour, 3.0)
				draw_circle(at + Vector2(x, -10.0), 2.2, colour)
			draw_line(at + Vector2(-9.0, 5.0), at + Vector2(9.0, 5.0), colour, 3.0)
		WeaponData.Kind.SCATTERGUN:
			for i in 5:
				var dir := Vector2(-0.62 + 0.31 * float(i), -1.0).normalized()
				var tip := at + dir * 17.0 + Vector2(0.0, 8.0)
				draw_line(at + Vector2(0.0, 8.0), tip, colour, 2.2)
				draw_circle(tip, 2.0, colour)
		WeaponData.Kind.ELECTRIC:
			draw_colored_polygon(PackedVector2Array([
					at + Vector2(4.0, -14.0), at + Vector2(-6.0, 0.0),
					at + Vector2(1.0, 0.0), at + Vector2(-4.0, 14.0),
					at + Vector2(6.0, -1.0), at + Vector2(-1.0, -1.0)]), colour)
		WeaponData.Kind.MAGNETIC:
			draw_line(at + Vector2(0.0, -13.0), at + Vector2(0.0, 13.0), colour, 3.0)
			for i in 2:
				var ring_y := -6.0 + 12.0 * float(i)
				draw_arc(at + Vector2(0.0, ring_y), 7.0, -PI * 0.5, PI * 0.5, 16,
						colour, 2.4)
			draw_colored_polygon(PackedVector2Array([
					at + Vector2(-5.0, -8.0), at + Vector2(5.0, -8.0),
					at + Vector2(0.0, -15.0)]), colour)
		WeaponData.Kind.BLAST:
			for i in 8:
				var dir := Vector2(cos(TAU * float(i) / 8.0), sin(TAU * float(i) / 8.0))
				draw_line(at + dir * 5.0, at + dir * 14.0, colour, 2.4)
			draw_circle(at, 4.0, colour)
		WeaponData.Kind.CORROSION:
			draw_colored_polygon(PackedVector2Array([
					at + Vector2(0.0, -14.0), at + Vector2(8.0, -2.0),
					at + Vector2(8.0, 5.0), at + Vector2(0.0, 11.0),
					at + Vector2(-8.0, 5.0), at + Vector2(-8.0, -2.0)]), colour)
			draw_circle(at + Vector2(3.0, 3.0), 2.6, Color(0.0, 0.0, 0.0, 0.45))
		WeaponData.Kind.BEAM:
			draw_line(at + Vector2(0.0, -14.0), at + Vector2(0.0, 12.0), colour, 3.0)
			draw_line(at + Vector2(-5.0, -14.0), at + Vector2(-5.0, 4.0), colour, 2.0)
			draw_line(at + Vector2(5.0, -14.0), at + Vector2(5.0, 4.0), colour, 2.0)
			draw_colored_polygon(PackedVector2Array([
					at + Vector2(-7.0, 6.0), at + Vector2(7.0, 6.0),
					at + Vector2(0.0, 14.0)]), colour)
		WeaponData.Kind.FLAME:
			draw_colored_polygon(PackedVector2Array([
					at + Vector2(0.0, -14.0), at + Vector2(7.0, -3.0),
					at + Vector2(8.0, 6.0), at + Vector2(0.0, 13.0),
					at + Vector2(-8.0, 6.0), at + Vector2(-7.0, -3.0)]), colour)
			draw_circle(at + Vector2(0.0, 5.0), 3.6, Color(0.0, 0.0, 0.0, 0.35))
		WeaponData.Kind.SALVO:
			for i in 3:
				var x := -8.0 + 8.0 * float(i)
				draw_line(at + Vector2(x, 12.0), at + Vector2(x, -4.0), colour, 3.0)
				draw_colored_polygon(PackedVector2Array([
						at + Vector2(x - 4.0, -4.0), at + Vector2(x + 4.0, -4.0),
						at + Vector2(x, -14.0)]), colour)
		WeaponData.Kind.SONIC:
			for i in 3:
				draw_arc(at + Vector2(0.0, 6.0), 6.0 + 5.0 * float(i),
						-PI * 0.75, -PI * 0.25, 20, colour, 2.4)
			draw_circle(at + Vector2(0.0, 6.0), 3.0, colour)
		_:
			draw_line(at + Vector2(0.0, 11.0), at + Vector2(0.0, -11.0), colour, 3.0)

# LOCK plate seated in the ring notch: glass disc, crosshair, caption.
func _draw_lock_glyph(centre: Vector2, font: Font) -> void:
	var at := centre + Vector2(cos(_lock_angle()), sin(_lock_angle())) * PANEL_RADIUS
	var tint := Color(0.75, 0.95, 1.0, 0.95)
	if _lock_pressed:
		tint = Color(1.0, 1.0, 1.0, 0.5 + 0.5 * absf(sin(_pulse * TAU)))
	var disc := 27.0
	draw_circle(at, disc, Color(GLASS_BG.r, GLASS_BG.g, GLASS_BG.b, 0.74))
	draw_arc(at, disc, 0.0, TAU, 44, tint, 2.5, true)
	var ring := 19.0 if _lock_pressed else 16.0
	draw_arc(at, ring, 0.0, TAU, 32, tint, 2.0, true)
	for dir: Vector2 in [Vector2.UP, Vector2.DOWN, Vector2.LEFT, Vector2.RIGHT]:
		draw_line(at + dir * (ring - 7.0), at + dir * (ring + 7.0), tint, 2.0)
	draw_circle(at, 3.5, tint)
	draw_string(font, Vector2(at.x - 40.0, at.y + disc + 14.0), "LOCK",
			HORIZONTAL_ALIGNMENT_CENTER, 80.0, 11, Color(0.7, 0.9, 1.0, 0.7))

# Heat ring around FIRE: cyan while cool, amber as it climbs, red + OVERHEAT
# label (pulsing) while the guns are locked out.
func _draw_fire_ring() -> void:
	if _fire_button == null:
		return
	var center := _fire_button.position + _fire_button.size * 0.5
	var radius := _fire_button.size.x * 0.5 + 9.0
	draw_arc(center, radius, 0.0, TAU, 64, Color(0.0, 0.0, 0.0, 0.5), 7.0, true)
	var heat := clampf(_heat_ratio, 0.0, 1.0)
	var heat_color := Color(0.55, 0.9, 1.0, 0.7).lerp(HOT_COLOR, heat)
	if _overheated:
		heat_color = Color(1.0, 0.42, 0.18, 0.5 + 0.5 * absf(sin(_pulse * TAU)))
	if heat > 0.01:
		draw_arc(center, radius, -PI / 2.0, -PI / 2.0 + TAU * heat, 64,
				heat_color, 7.0, true)
	if _firing:
		draw_arc(center, radius + 9.0, 0.0, TAU, 64,
				Color(1.0, 0.85, 0.65, 0.35), 2.5, true)
	if _overheated:
		var font := get_theme_default_font()
		draw_string(font, Vector2(center.x - 60.0, center.y - radius - 14.0),
				"OVERHEAT", HORIZONTAL_ALIGNMENT_CENTER, 120.0, 14,
				Color(1.0, 0.6, 0.3, 0.6 + 0.4 * absf(sin(_pulse * TAU))))

func _on_fire_down() -> void:
	_button_fire = true
	_sync_fire()

func _on_fire_up() -> void:
	_button_fire = false
	_sync_fire()

func _sync_fire() -> void:
	var held := _raw_fire_count > 0 or _button_fire
	if _firing != held:
		_firing = held
		queue_redraw()
	InputRouter.set_virtual_fire(held)

func _sync_lock_visual() -> void:
	var pressed := _button_lock or _raw_lock_held
	if _lock_pressed != pressed:
		_lock_pressed = pressed
		queue_redraw()

func fire_button() -> Button:
	return _fire_button

func ability_button() -> Button:
	# The ability lives on the circular controller (6 o'clock wedge).
	return _ability_slice

func secondary_button() -> Button:
	# Titans only: the secondary wedge sits right after the ability wedge.
	return _secondary_slice

func razor_button() -> Button:
	# Legacy smoke accessor: first weapon segment (group 0 representative).
	return _segment_buttons[0] if _segment_buttons.size() > 0 else null

func maul_button() -> Button:
	# Legacy smoke accessor: first group-1 segment (slot 2 when present).
	if _segment_buttons.size() > 2:
		return _segment_buttons[2]
	return _segment_buttons.back() if _segment_buttons.size() > 0 else null

func lock_button() -> Button:
	return _lock_button

func segment_count() -> int:
	return _segment_buttons.size()
