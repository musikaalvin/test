extends Panel

# Shared premium sci-fi screen canvas. Drawn in 2D so it stays crisp and cheap
# on both Android and desktop; individual screen content remains interactive.
func _notification(what: int) -> void:
	if what == NOTIFICATION_RESIZED:
		queue_redraw()

func _ready() -> void:
	mouse_filter = Control.MOUSE_FILTER_STOP
	queue_redraw()

func _draw() -> void:
	var rect := Rect2(Vector2.ZERO, size)
	# Deep navy base with restrained radial-like bands.
	draw_rect(rect, Color(0.018, 0.027, 0.045, 1.0), true)
	draw_rect(Rect2(0.0, 0.0, size.x, size.y * 0.24), Color(0.025, 0.075, 0.105, 0.55), true)
	# Fine technical grid, fading visually toward the center by using low alpha.
	var step := 42.0
	var x := 0.0
	while x <= size.x:
		draw_line(Vector2(x, 0.0), Vector2(x, size.y), Color(0.22, 0.72, 0.83, 0.055), 1.0, true)
		x += step
	var y := 0.0
	while y <= size.y:
		draw_line(Vector2(0.0, y), Vector2(size.x, y), Color(0.22, 0.72, 0.83, 0.045), 1.0, true)
		y += step
	# Large restrained diagonal technical cuts at the corners.
	var cyan := Color(0.16, 0.78, 0.91, 0.34)
	var amber := Color(1.0, 0.43, 0.10, 0.36)
	draw_line(Vector2(0.0, size.y * 0.18), Vector2(size.x * 0.12, 0.0), cyan, 2.0, true)
	draw_line(Vector2(size.x * 0.78, size.y), Vector2(size.x, size.y * 0.78), amber, 2.0, true)
	draw_line(Vector2(0.0, size.y * 0.185), Vector2(size.x * 0.12, 0.005), Color(0.16, 0.78, 0.91, 0.12), 8.0, true)
	# Bottom status rail.
	draw_rect(Rect2(0.0, size.y - 3.0, size.x * 0.28, 3.0), Color(0.12, 0.78, 0.91, 0.82), true)
	draw_rect(Rect2(size.x * 0.28, size.y - 3.0, size.x * 0.07, 3.0), Color(1.0, 0.43, 0.10, 0.82), true)
