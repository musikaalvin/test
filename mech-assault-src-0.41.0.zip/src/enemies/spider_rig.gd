class_name SpiderRig
extends EnemyRig

var _leg_bases: Array[Vector3] = []
var _hull_base: Vector3 = Vector3.ZERO
var _bob_phase: float = 0.0
var _pitch: float = 0.0
var _roll: float = 0.0
var _dead: bool = false

var _shell: StandardMaterial3D
var _rust: StandardMaterial3D
var _joint: StandardMaterial3D
var _trim: StandardMaterial3D
var _sensor: StandardMaterial3D
var _dark: StandardMaterial3D

func _ready() -> void:
	_make_materials()
	_build_hull()
	_build_head()
	_build_legs()

func _make_materials() -> void:
	_shell = MeshUtil.make_material(Color(0.17, 0.14, 0.13), 0.15, 0.5)
	_rust = MeshUtil.make_material(Color(0.52, 0.2, 0.12), 0.5, 0.55)
	_joint = MeshUtil.make_material(Color(0.08, 0.07, 0.07), 0.0, 0.8)
	_trim = MeshUtil.make_material(Color(0.36, 0.34, 0.33), 0.95, 0.35)
	_sensor = MeshUtil.make_material(Color(1.0, 0.16, 0.1), 0.2, 0.2,
			Color(1.0, 0.12, 0.08), 3.4)
	_dark = MeshUtil.make_material(Color(0.05, 0.045, 0.045), 0.55, 0.75)
	PanelTextures.apply(_shell, &"armor", 1.5)
	PanelTextures.apply(_rust, &"steel", 1.4)
	PanelTextures.apply(_trim, &"steel", 1.6)
	PanelTextures.apply(_joint, &"rubber", 3.0)

func _build_hull() -> void:
	hull = Node3D.new()
	hull.name = "Hull"
	add_child(hull)
	_hull_base = hull.position

	var core := MeshUtil.make_cylinder(0.72, 1.7, _shell, 6, "spider_core")
	hull.add_child(core)
	core.position = Vector3(0.0, 0.1, 0.0)
	core.rotation_degrees = Vector3(90.0, 0.0, 0.0)
	core.scale = Vector3(1.18, 1.0, 0.62)

	MeshUtil.bevel_at(hull, Vector3(1.3, 0.16, 1.2), Vector3(0.0, 0.52, -0.05),
			Vector3(-5.0, 0.0, 0.0), _trim, "back_plate")
	MeshUtil.bevel_at(hull, Vector3(0.7, 0.2, 0.7), Vector3(0.0, 0.6, 0.3),
			Vector3.ZERO, _rust, "dorsal_hump")
	MeshUtil.cone_at(hull, 0.16, 0.02, 0.5, Vector3(0.0, 0.76, 0.42),
			Vector3(-14.0, 0.0, 0.0), _trim, "spike_0")
	MeshUtil.cone_at(hull, 0.13, 0.02, 0.42, Vector3(0.0, 0.7, 0.75),
			Vector3(-30.0, 0.0, 0.0), _trim, "spike_1")
	MeshUtil.bevel_at(hull, Vector3(1.1, 0.44, 0.7), Vector3(0.0, 0.08, 0.72),
			Vector3.ZERO, _shell, "abdomen")
	MeshUtil.bevel_at(hull, Vector3(0.8, 0.3, 0.35), Vector3(0.0, 0.02, 1.05),
			Vector3.ZERO, _rust, "abdomen_tip")
	for side in [-1.0, 1.0]:
		MeshUtil.bevel_at(hull, Vector3(0.14, 0.5, 1.25), Vector3(side * 0.82, 0.1, -0.05),
				Vector3(0.0, 0.0, side * -8.0), _rust, "flank_plate")
		MeshUtil.bevel_at(hull, Vector3(0.1, 0.28, 0.7), Vector3(side * 0.9, 0.06, -0.1),
				Vector3.ZERO, _dark, "flank_vent")
		MeshUtil.cyl_at(hull, 0.12, 0.5, Vector3(side * 0.4, 0.42, 0.85),
				Vector3(30.0, 0.0, 0.0), _trim, "rear_pipe")
	MeshUtil.bevel_at(hull, Vector3(1.0, 0.3, 0.5), Vector3(0.0, -0.3, 0.1),
			Vector3.ZERO, _dark, "underbelly")
	MeshUtil.bevel_at(hull, Vector3(1.2, 0.14, 0.9), Vector3(0.0, 0.4, -0.6),
			Vector3(-10.0, 0.0, 0.0), _shell, "shoulder_deck")

func _build_head() -> void:
	var head := Node3D.new()
	head.name = "HeadSensor"
	head.position = Vector3(0.0, 0.16, -0.92)
	hull.add_child(head)

	MeshUtil.bevel_at(head, Vector3(0.7, 0.4, 0.5), Vector3.ZERO, Vector3.ZERO,
			_shell, "head_shell")
	MeshUtil.bevel_at(head, Vector3(0.78, 0.12, 0.34), Vector3(0.0, 0.16, -0.12),
			Vector3(-14.0, 0.0, 0.0), _rust, "head_brow")
	MeshUtil.bevel_at(head, Vector3(0.5, 0.07, 0.06), Vector3(0.0, 0.0, -0.27),
			Vector3.ZERO, _sensor, "optic_bar")
	sensor_bar = head.get_node_or_null("optic_bar") as MeshInstance3D
	MeshUtil.sph_at(head, 0.06, Vector3(0.16, 0.0, -0.27), _sensor, "eye_r")
	MeshUtil.sph_at(head, 0.06, Vector3(-0.16, 0.0, -0.27), _sensor, "eye_l")
	for side in [-1.0, 1.0]:
		MeshUtil.cone_at(head, 0.09, 0.015, 0.44,
				Vector3(side * 0.2, -0.16, -0.3),
				Vector3(-105.0, 0.0, side * -10.0), _trim, "mandible")
		MeshUtil.bevel_at(head, Vector3(0.16, 0.26, 0.34), Vector3(side * 0.36, -0.02, -0.04),
				Vector3.ZERO, _rust, "head_cheek")

	var gun := Node3D.new()
	gun.name = "ChinGun"
	gun.position = Vector3(0.0, -0.3, -0.1)
	head.add_child(gun)
	MeshUtil.bevel_at(gun, Vector3(0.3, 0.24, 0.5), Vector3.ZERO, Vector3.ZERO,
			_dark, "gun_body")
	MeshUtil.cyl_at(gun, 0.07, 0.7, Vector3(0.0, 0.0, -0.42),
			Vector3(90.0, 0.0, 0.0), _trim, "gun_barrel")
	MeshUtil.cyl_at(gun, 0.1, 0.14, Vector3(0.0, 0.0, -0.74),
			Vector3(90.0, 0.0, 0.0), _dark, "gun_brake")
	muzzle = Marker3D.new()
	muzzle.name = "Muzzle"
	muzzle.position = Vector3(0.0, 0.0, -0.82)
	gun.add_child(muzzle)

func _build_legs() -> void:
	var hip_pos: Array[Vector3] = [
		Vector3(0.95, -0.18, -0.6), Vector3(1.04, -0.18, 0.0),
		Vector3(0.95, -0.18, 0.6), Vector3(-0.95, -0.18, -0.6),
		Vector3(-1.04, -0.18, 0.0), Vector3(-0.95, -0.18, 0.6),
	]
	var hip_out: Array[Vector3] = [
		Vector3(0.94, 0.0, -0.34), Vector3(1.0, 0.0, 0.0),
		Vector3(0.94, 0.0, 0.34), Vector3(-0.94, 0.0, -0.34),
		Vector3(-1.0, 0.0, 0.0), Vector3(-0.94, 0.0, 0.34),
	]
	var hip_phase: Array[float] = [0.0, 0.17, 0.34, 0.5, 0.67, 0.84]
	var hip_name: Array[String] = [
		"Leg_FR", "Leg_MR", "Leg_RR", "Leg_FL", "Leg_ML", "Leg_RL",
	]
	for index in hip_pos.size():
		var leg := LegUnit.new()
		leg.name = hip_name[index]
		leg.phase_offset = hip_phase[index]
		leg.outward = hip_out[index]
		leg.stride_length = 0.85
		leg.step_height = 0.45
		leg.reference_speed = 4.6
		leg.configure(_shell, _joint, _rust, _trim, _trim)
		leg.apply_scale(visual_scale)
		add_child(leg)
		leg.position = hip_pos[index]
		_leg_bases.append(hip_pos[index])
		legs.append(leg)
		MeshUtil.sph_at(self, 0.14, hip_pos[index], _joint, "hip_pod")

func update_animation(delta: float, velocity: Vector3, turn_rate: float, grounded: bool) -> void:
	var planar := Vector3(velocity.x, 0.0, velocity.z)
	var speed := planar.length()
	var speed_ratio := clampf(speed / 4.6, 0.0, 1.4)
	var target_pitch := clampf(velocity.dot(global_basis.z) * 0.014, -0.1, 0.1)
	var strafe := planar.dot(global_basis.x)
	var target_roll := clampf(turn_rate * 0.05 - strafe * 0.03, -0.15, 0.15)
	_pitch = lerpf(_pitch, target_pitch if grounded else 0.0, clampf(delta * 6.0, 0.0, 1.0))
	_roll = lerpf(_roll, target_roll if grounded else 0.0, clampf(delta * 6.0, 0.0, 1.0))

	_bob_phase += delta * (2.4 + speed_ratio * 8.0)
	var bob := sin(_bob_phase) * 0.045 * (0.3 + speed_ratio)
	if not grounded:
		bob = 0.0
	var offset := Vector3(0.0, bob, 0.0)
	var lean := Vector3(_pitch, 0.0, _roll)
	hull.position = _hull_base + offset
	hull.rotation = lean
	for index in legs.size():
		legs[index].position = _leg_bases[index] + offset

func reset_feet(ground_points: Array[Vector3]) -> void:
	for index in legs.size():
		if index < ground_points.size():
			legs[index].reset_gait(ground_points[index])
		else:
			legs[index].reset_gait(legs[index].global_position)

func set_dead() -> void:
	_dead = true
	_sensor.emission_energy_multiplier = 0.05
	_sensor.albedo_color = Color(0.3, 0.05, 0.04)
