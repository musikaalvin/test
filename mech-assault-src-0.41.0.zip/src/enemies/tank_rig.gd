class_name TankRig
extends EnemyRig

var _leg_bases: Array[Vector3] = []
var _hull_base: Vector3 = Vector3.ZERO
var _bob_phase: float = 0.0
var _pitch: float = 0.0
var _roll: float = 0.0

var _shell: StandardMaterial3D
var _armor: StandardMaterial3D
var _joint: StandardMaterial3D
var _trim: StandardMaterial3D
var _sensor: StandardMaterial3D
var _dark: StandardMaterial3D

func _ready() -> void:
	_make_materials()
	_build_hull()
	_build_legs()

func _make_materials() -> void:
	_shell = MeshUtil.make_material(Color(0.16, 0.18, 0.13), 0.15, 0.55)
	_armor = MeshUtil.make_material(Color(0.3, 0.32, 0.24), 0.3, 0.5)
	_joint = MeshUtil.make_material(Color(0.06, 0.06, 0.06), 0.0, 0.85)
	_trim = MeshUtil.make_material(Color(0.55, 0.16, 0.1), 0.25, 0.5)
	_sensor = MeshUtil.make_material(Color(1.0, 0.2, 0.12), 0.2, 0.2,
			Color(1.0, 0.15, 0.08), 3.8)
	_dark = MeshUtil.make_material(Color(0.04, 0.045, 0.04), 0.55, 0.75)
	PanelTextures.apply(_shell, &"armor", 1.3)
	PanelTextures.apply(_armor, &"steel", 1.5)
	PanelTextures.apply(_joint, &"rubber", 3.0)

func _build_hull() -> void:
	hull = Node3D.new()
	hull.name = "Hull"
	add_child(hull)
	_hull_base = hull.position

	MeshUtil.bevel_at(hull, Vector3(2.0, 0.55, 2.6), Vector3(0.0, 0.1, 0.0),
			Vector3.ZERO, _shell, "lower_hull")
	MeshUtil.wedge_at(hull, Vector3(1.9, 0.5, 1.0), Vector3(0.0, 0.3, -1.15),
			Vector3.ZERO, _armor, "glacis")
	MeshUtil.bevel_at(hull, Vector3(1.6, 0.4, 1.8), Vector3(0.0, 0.55, 0.1),
			Vector3.ZERO, _armor, "upper_deck")
	MeshUtil.bevel_at(hull, Vector3(1.1, 0.3, 1.1), Vector3(0.0, 0.85, 0.0),
			Vector3.ZERO, _shell, "turret_hump")
	MeshUtil.bevel_at(hull, Vector3(0.7, 0.1, 0.5), Vector3(0.0, 1.02, -0.2),
			Vector3.ZERO, _trim, "hatch")
	for side in [-1.0, 1.0]:
		MeshUtil.bevel_at(hull, Vector3(0.16, 0.5, 2.3), Vector3(side * 1.02, 0.05, 0.0),
				Vector3.ZERO, _armor, "side_skirt")
		MeshUtil.cyl_at(hull, 0.13, 0.7, Vector3(side * 0.5, 1.0, 0.75),
				Vector3(-12.0, 0.0, 0.0), _dark, "exhaust")
		MeshUtil.bevel_at(hull, Vector3(0.5, 0.3, 0.4), Vector3(side * 0.6, 0.3, -1.3),
				Vector3.ZERO, _dark, "gun_pod")
		MeshUtil.cyl_at(hull, 0.09, 1.0, Vector3(side * 0.6, 0.32, -1.75),
				Vector3(90.0, 0.0, 0.0), _trim, "barrel")
		MeshUtil.cyl_at(hull, 0.13, 0.18, Vector3(side * 0.6, 0.32, -2.2),
				Vector3(90.0, 0.0, 0.0), _dark, "brake")
	MeshUtil.bevel_at(hull, Vector3(1.3, 0.1, 0.4), Vector3(0.0, 0.78, -1.0),
			Vector3(-8.0, 0.0, 0.0), _shell, "brow")
	MeshUtil.bevel_at(hull, Vector3(0.9, 0.07, 0.1), Vector3(0.0, 0.7, -1.32),
			Vector3.ZERO, _sensor, "optic_bar")
	sensor_bar = hull.get_node_or_null("optic_bar") as MeshInstance3D

	muzzle = Marker3D.new()
	muzzle.name = "Muzzle"
	muzzle.position = Vector3(0.0, 0.32, -2.3)
	hull.add_child(muzzle)

func _build_legs() -> void:
	var hip_pos: Array[Vector3] = [
		Vector3(0.75, -0.05, -0.62), Vector3(0.75, -0.05, 0.62),
		Vector3(-0.75, -0.05, -0.62), Vector3(-0.75, -0.05, 0.62),
	]
	var hip_phase: Array[float] = [0.0, 0.33, 0.66, 0.17]
	var hip_name: Array[String] = ["Leg_FR", "Leg_RR", "Leg_FL", "Leg_RL"]
	for index in hip_pos.size():
		var leg := LegUnit.new()
		leg.name = hip_name[index]
		leg.phase_offset = hip_phase[index]
		var side := 1.0 if hip_pos[index].x > 0.0 else -1.0
		leg.outward = Vector3(side, 0.0, hip_pos[index].z * 0.35)
		leg.coxa_length = 0.26
		leg.thigh_length = 0.7
		leg.shin_length = 0.85
		leg.thigh_radius = 0.19
		leg.shin_radius = 0.14
		leg.hip_radius = 0.23
		leg.foot_size = Vector3(0.5, 0.14, 0.62)
		leg.stride_length = 0.7
		leg.step_height = 0.35
		leg.reference_speed = 3.2
		leg.configure(_shell, _joint, _trim, _armor, _trim)
		leg.apply_scale(visual_scale)
		add_child(leg)
		leg.position = hip_pos[index]
		_leg_bases.append(hip_pos[index])
		legs.append(leg)
		MeshUtil.sph_at(self, 0.18, hip_pos[index], _joint, "hip_pod")

func update_animation(delta: float, velocity: Vector3, turn_rate: float, grounded: bool) -> void:
	var planar := Vector3(velocity.x, 0.0, velocity.z)
	var speed := planar.length()
	var speed_ratio := clampf(speed / 3.2, 0.0, 1.4)
	var target_pitch := clampf(velocity.dot(global_basis.z) * 0.01, -0.06, 0.06)
	var strafe := planar.dot(global_basis.x)
	var target_roll := clampf(turn_rate * 0.04 - strafe * 0.03, -0.1, 0.1)
	_pitch = lerpf(_pitch, target_pitch if grounded else 0.0, clampf(delta * 5.0, 0.0, 1.0))
	_roll = lerpf(_roll, target_roll, clampf(delta * 5.0, 0.0, 1.0))

	_bob_phase += delta * (2.0 + speed_ratio * 6.5)
	var bob := sin(_bob_phase) * 0.04 * (0.3 + speed_ratio)
	if not grounded:
		bob = 0.0
	var offset := Vector3(0.0, bob, 0.0)
	hull.position = _hull_base + offset
	hull.rotation = Vector3(_pitch, 0.0, _roll)
	for index in legs.size():
		legs[index].position = _leg_bases[index] + offset

func reset_feet(ground_points: Array[Vector3]) -> void:
	for index in legs.size():
		if index < ground_points.size():
			legs[index].reset_gait(ground_points[index])
		else:
			legs[index].reset_gait(legs[index].global_position)

func set_dead() -> void:
	_sensor.emission_energy_multiplier = 0.05
	_sensor.albedo_color = Color(0.25, 0.06, 0.04)
