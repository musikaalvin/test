class_name EnemyRobot
extends CharacterBody3D

enum State { IDLE, SEARCH, CHASE, ATTACK, DEAD }

const KIND_SCUTTLER := &"SCUTTLER"
const KIND_STALKER := &"STALKER"
const KIND_BRUTE := &"BRUTE"
const KIND_WASP := &"WASP"
const KIND_PATTERN: Array[StringName] = [
	KIND_SCUTTLER, KIND_SCUTTLER, KIND_STALKER, KIND_BRUTE, KIND_WASP,
	KIND_SCUTTLER, KIND_STALKER, KIND_SCUTTLER, KIND_WASP, KIND_BRUTE,
	KIND_SCUTTLER, KIND_STALKER, KIND_WASP, KIND_SCUTTLER, KIND_BRUTE,
]
# Per-kind chassis scale: the roster must read as different machines, not one
# body with a new name (SCUTTLER scuttles small, BRUTE bulldozes large).
const KIND_SCALES: Dictionary = {
	KIND_SCUTTLER: 0.9, KIND_STALKER: 1.05, KIND_BRUTE: 1.3, KIND_WASP: 0.8,
}
# Hunting Grounds roster (War Robots Extermination flavour): every spawn rolls
# its own gun from a per-kind pool and carries a random MK tier, so the wave
# mixes BASE / MK1 / MK2 / MK3 machines instead of four identical templates.
# Token "&" entries build the classic named gun; anything else is an item id.
const WEAPON_POOLS: Dictionary = {
	KIND_SCUTTLER: [&"SPITTER", &"HARMATTAN-L", &"TOXIN-L", &"ULTIMATE-TOXIN-L"],
	KIND_STALKER: [&"LANCE", &"VOONITH-L", &"ECHO-L", &"MACHAIRA-M"],
	KIND_BRUTE: [&"MAW", &"KSIPHOS-L", &"BREACH-M", &"VOLLEY-M"],
	KIND_WASP: [&"TESLA", &"VOLT-L", &"URHAG-M", &"ECHO-M"],
}
# MK tier: durability climbs hard, firepower gently — a MK3 elite lasts about
# twice a BASE twin but only hits ~40% harder (keeps the solo-survival smoke
# invariant above the 15 s floor at MK3).
const MK_HP_MULT: Array[float] = [1.0, 1.25, 1.65, 2.2]
const MK_DMG_MULT: Array[float] = [1.0, 1.1, 1.25, 1.4]
# Fixed "random" mix: 5 BASE / 4 MK1 / 3 MK2 / 3 MK3 across the 15 spawns.
# Content is stable so headless smoke can assert every tier is present, while
# the per-kind spread still reads as a random pull.
const MK_BAG: Array[int] = [1, 0, 2, 0, 3, 1, 0, 2, 1, 3, 0, 2, 1, 3, 0]
# Weapon rolls are seeded per spawn index — deterministic across runs (smoke),
# varied across the roster.
const WEAPON_SEED := 20261008

const GROUND_CLEARANCE := 0.1
const PROBE_UP := 1.4
const PROBE_DOWN := 5.0
const SIGHT_INTERVAL := 0.2
# LUMEN Thermal Breach: every beam hit stacks a damage-taken amplifier that
# decays after a few seconds without beams (War Robots Lumen "breach" passive).
const BREACH_MAX := 10
const BREACH_PER_STACK := 0.04
const BREACH_LIFE := 4.0

const DEATH_EXPLOSION_DELAY := 0.3
const DEATH_POP_DELAY_A := 0.5
const DEATH_POP_DELAY_B := 1.1
const DEBRIS_MIN_LIFETIME := 4.0
const DEBRIS_MAX_LIFETIME := 6.0
const MAX_LIVE_DEBRIS := 24
# Component (weapon) damage — same shape as the player's: hull hits below the
# gate feed a stress pool, and a mount that blows its budget comes off for
# good. Enemies carry a single gun, so losing it switches them to pursuit only.
const COMPONENT_GATE_RATIO := 0.55
const COMPONENT_DESTROY_RATIO := 0.55
const COMPONENT_STRESS_MULT := 3.0

static var _live_debris: Array[RigidBody3D] = []
# Append-only tier log for headless assertions: the live roster churns (drones
# kill enemies mid-run), but every machine that ever spawned is recorded here.
static var spawned_tiers: PackedInt32Array = PackedInt32Array()

@export var kind: StringName = &"SCUTTLER"
# Set by GameSession before add_child (both feed _configure_kind/_make_weapon).
@export var spawn_index: int = 0
var mk_tier: int = 0
var _weapon_item: StringName = &""

@export var move_speed: float = 4.4
@export var accel: float = 14.0
@export var turn_speed: float = 3.2
@export var attack_range: float = 22.0
@export var standoff: float = 6.5
@export var search_time: float = 4.5
@export var fire_interval: float = 1.8
@export var burst_gap: float = 0.14
@export var pounce_speed: float = 10.0
@export var pounce_cooldown: float = 5.0
@export var max_health: float = 265000.0

var ai_enabled: bool = true
var state: State = State.IDLE
var rig: EnemyRig
var health: Health
var target: PlayerRobot
var spawn_origin: Vector3 = Vector3.ZERO

var _hovers: bool = false
var _can_pounce: bool = true
var _eye_height: float = 0.6
var _capsule_radius: float = 0.72
var _capsule_height: float = 1.5
var _capsule_y: float = 0.0
var _visual_scale: float = 1.0
var _spawn_hover: float = 1.5

var _weapon: WeaponData
var _fire_left: float = 1.0
var _burst_left: float = 0.0
var _pounce_left: float = 0.0
var _jam_left: float = 0.0
var _suppression_left: float = 0.0
var _fracture_left: float = 0.0
var _slow_left: float = 0.0
var _slow_factor: float = 1.0
var _corrosion_left: float = 0.0
var _corrosion_dps: float = 0.0
var _corrosion_acc: float = 0.0
var _breach_stacks: int = 0
var _breach_left: float = 0.0
var death_mark_left: float = 0.0
var death_mark_mult: float = 1.0
# CHALLENGE: a taunted hostile drops all caution - it keeps hunting the player
# even through stealth or broken line of sight instead of falling back to
# SEARCH, and it never fires without LOS (the taunt grants no wallhacks).
var taunted_left: float = 0.0
var taunted_by: PlayerRobot
var _hazard_acc: float = 0.0
var _sight_left: float = 0.0
var _has_los: bool = false
var _search_left: float = 0.0
var _death_left: float = 6.0
var _death_tilt: float = 1.25
var _was_airborne: float = 0.0
var _last_seen: Vector3 = Vector3.ZERO
# Component damage: hull damage taken below the gate, and whether the one
# gun this chassis carries has been blown off.
var _weapon_stress: float = 0.0
var _weapon_destroyed: bool = false
var _damage_reaction: DamageReactionController = null

var _probe_from := PhysicsRayQueryParameters3D.new()
var _sight_from := PhysicsRayQueryParameters3D.new()
var _probe_result := {}
var _ground_position: Vector3 = Vector3.ZERO
var _ground_found: bool = false

func _ready() -> void:
	collision_layer = Layers.ENEMY
	collision_mask = Layers.WORLD | Layers.PLAYER | Layers.ENEMY
	floor_max_angle = deg_to_rad(52.0)
	floor_snap_length = 1.1
	floor_stop_on_slope = true

	_configure_kind()

	var shape := CollisionShape3D.new()
	shape.name = "BodyShape"
	var capsule := CapsuleShape3D.new()
	capsule.radius = _capsule_radius
	capsule.height = _capsule_height
	shape.shape = capsule
	shape.position = Vector3(0.0, _capsule_y, 0.0)
	add_child(shape)

	rig = _make_rig()
	rig.name = "%sRig" % String(kind)
	rig.visual_scale = _visual_scale
	add_child(rig)

	health = Health.new()
	health.name = "Health"
	health.max_health = max_health
	add_child(health)
	health.died.connect(_on_died)
	# Critical-hull presentation (smoke + flames), tracked off the capsule so
	# it follows the body transform and survives the death animation.
	_damage_reaction = DamageReactionController.new()
	_damage_reaction.name = "DamageReaction"
	add_child(_damage_reaction)
	_damage_reaction.setup(self, health)
	_configure_shield()
	health.shield_changed.connect(_on_shield_changed)
	health.shield_broken.connect(_on_shield_broken)

	_make_weapon()

	_probe_from.collision_mask = Layers.WORLD
	_probe_from.collide_with_areas = false
	_probe_from.collide_with_bodies = true
	_probe_from.exclude = [get_rid()]
	_sight_from.collision_mask = Layers.WORLD
	_sight_from.collide_with_areas = false
	_sight_from.collide_with_bodies = true
	_sight_from.exclude = [get_rid()]

	add_to_group("enemy")

func _configure_kind() -> void:
	_visual_scale = float(KIND_SCALES.get(kind, 1.0))
	match kind:
		KIND_STALKER:
			move_speed = 5.0
			accel = 13.0
			attack_range = 52.0
			standoff = 34.0
			fire_interval = 2.4
			max_health = 300000.0
			_can_pounce = false
			_eye_height = 2.4
			_capsule_radius = 0.55
			_capsule_height = 3.0
			_capsule_y = 0.9
		KIND_BRUTE:
			move_speed = 2.9
			accel = 9.0
			attack_range = 15.0
			standoff = 5.5
			fire_interval = 1.7
			max_health = 430000.0
			_can_pounce = false
			_eye_height = 1.1
			_capsule_radius = 0.95
			_capsule_height = 1.8
			_capsule_y = 0.1
		KIND_WASP:
			move_speed = 7.4
			accel = 16.0
			attack_range = 32.0
			standoff = 11.0
			fire_interval = 0.95
			max_health = 230000.0
			_can_pounce = false
			_hovers = true
			_eye_height = 0.1
			_capsule_radius = 0.55
			_capsule_height = 1.1
			_capsule_y = 0.0
			_spawn_hover = DroneRig.HOVER_HEIGHT
		_:
			move_speed = 4.4
			accel = 14.0
			attack_range = 22.0
			standoff = 6.5
			fire_interval = 1.8
			max_health = 265000.0
			_can_pounce = true
			_eye_height = 0.6
			_capsule_radius = 0.72
			_capsule_height = 1.5
			_capsule_y = 0.0
	# Bake the kind scale into every measurement the body/capsule/ground code
	# uses, then hand it to the rig before it is added to the tree.
	_capsule_radius *= _visual_scale
	_capsule_height *= _visual_scale
	_capsule_y *= _visual_scale
	_eye_height *= _visual_scale
	_spawn_hover *= _visual_scale
	# Hunting Grounds MK tier (must run before Health is created / shields are
	# sized so durability and shield pools both scale with it).
	mk_tier = MK_BAG[spawn_index % MK_BAG.size()]
	max_health *= MK_HP_MULT[mk_tier]
	spawned_tiers.append(mk_tier)

var _shield_mesh: MeshInstance3D
var _shield_mat: StandardMaterial3D

# WR shield flavours per enemy class: BRUTE walks under a grey physical
# shell, STALKER carries a regenerating blue Ancile, WASP a yellow Aegis.
func _configure_shield() -> void:
	match kind:
		KIND_BRUTE:
			health.configure_shield(Health.Zone.PHYSICAL, max_health * 0.4, 0.0)
		KIND_STALKER:
			health.configure_shield(Health.Zone.ANCILE, max_health * 0.25,
					max_health * 0.02)
		KIND_WASP:
			health.configure_shield(Health.Zone.AEGIS, max_health * 0.3,
					max_health * 0.015)
	if not health.has_shield():
		return
	_shield_mesh = MeshInstance3D.new()
	_shield_mesh.name = "ShieldBubble"
	var sphere := SphereMesh.new()
	var radius := maxf(_capsule_radius, _capsule_height * 0.5) * 1.35 + 0.25
	sphere.radius = radius
	sphere.height = radius * 2.0
	sphere.radial_segments = 24
	sphere.rings = 12
	_shield_mat = StandardMaterial3D.new()
	var color := Health.zone_color(health.shield_kind)
	color.a = 0.22
	_shield_mat.albedo_color = color
	_shield_mat.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
	_shield_mat.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
	_shield_mat.emission_enabled = true
	_shield_mat.emission = Health.zone_color(health.shield_kind)
	_shield_mat.emission_energy_multiplier = 0.55
	sphere.material = _shield_mat
	_shield_mesh.mesh = sphere
	_shield_mesh.position = Vector3(0.0, _capsule_y, 0.0)
	_shield_mesh.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	add_child(_shield_mesh)

func _on_shield_changed(shield: float, _maximum: float, _kind: int) -> void:
	if _shield_mesh == null or not is_instance_valid(_shield_mesh):
		return
	if shield > 0.0 and not _shield_mesh.visible:
		_shield_mesh.visible = true
		_shield_mesh.scale = Vector3.ONE * 0.65
		_set_shield_alpha(0.0)
		var pop := create_tween()
		pop.set_parallel(true)
		pop.tween_property(_shield_mesh, "scale", Vector3.ONE, 0.22)
		pop.tween_method(func(value: float) -> void: _set_shield_alpha(value),
				0.0, 0.22, 0.22)

func _on_shield_broken(kind: int) -> void:
	if _shield_mesh == null or not is_instance_valid(_shield_mesh) \
			or not _shield_mesh.visible:
		return
	var burst := create_tween()
	burst.set_parallel(true)
	burst.tween_property(_shield_mesh, "scale", Vector3.ONE * 1.55, 0.3)
	burst.tween_method(func(value: float) -> void: _set_shield_alpha(value),
			_shield_mat.albedo_color.a, 0.0, 0.3)
	burst.chain().tween_callback(func() -> void:
		if is_instance_valid(_shield_mesh):
			_shield_mesh.visible = false
			_shield_mesh.scale = Vector3.ONE)

func _set_shield_alpha(alpha: float) -> void:
	if _shield_mat == null:
		return
	var color := _shield_mat.albedo_color
	color.a = clampf(alpha, 0.0, 1.0)
	_shield_mat.albedo_color = color

func status_icon_row() -> PackedStringArray:
	# Active combat effects for the WR-style accumulation icons above the bot.
	var icons := PackedStringArray()
	if is_critical():
		icons.append("CR")
	if death_mark_left > 0.0:
		icons.append("DM")
	if _breach_stacks > 0:
		icons.append("BR")
	if _corrosion_left > 0.0:
		icons.append("DO")
	if _suppression_left > 0.0:
		icons.append("SU")
	if _slow_left > 0.0:
		icons.append("SL")
	return icons

func status_icon_stacks(icon: String) -> int:
	match icon:
		"BR":
			return _breach_stacks
		"DO", "SU", "SL", "DM":
			return 1
	return 1

func _make_rig() -> EnemyRig:
	match kind:
		KIND_STALKER:
			return StriderRig.new()
		KIND_BRUTE:
			return TankRig.new()
		KIND_WASP:
			return DroneRig.new()
		_:
			return SpiderRig.new()

func _make_weapon() -> void:
	var pool: Array = WEAPON_POOLS.get(kind,
			WEAPON_POOLS[KIND_SCUTTLER]) as Array
	var rng := RandomNumberGenerator.new()
	rng.seed = WEAPON_SEED + spawn_index * 97
	_weapon_item = pool[rng.randi_range(0, pool.size() - 1)] as StringName
	match _weapon_item:
		&"LANCE":
			_weapon = WeaponData.autocannon()
			_weapon.display_name = "OBSIDIAN LANCE"
			_weapon.damage = 4250.0
			_weapon.shots_per_minute = 55.0
			_weapon.spread_degrees = 0.4
			_weapon.projectile_speed = 190.0
			_weapon.projectile_drop = 0.35
			_weapon.projectile_lifetime = 2.6
			_weapon.tracer_color = Color(1.0, 0.8, 0.45)
			_weapon.tracer_radius = 0.055
			_weapon.tracer_length = 2.4
		&"MAW":
			_weapon = WeaponData.scattergun()
			_weapon.display_name = "FURNACE MAW"
			_weapon.pellets = 4
			_weapon.damage = 1375.0
			_weapon.shots_per_minute = 85.0
			_weapon.spread_degrees = 6.5
			_weapon.projectile_speed = 78.0
			_weapon.projectile_drop = 3.4
			_weapon.projectile_lifetime = 0.9
			_weapon.tracer_color = Color(1.0, 0.45, 0.15)
			_weapon.tracer_radius = 0.07
			_weapon.tracer_length = 1.1
		&"TESLA":
			_weapon = WeaponData.for_item("VOLT-M")
			_weapon.display_name = "ARC TESLA"
			_weapon.pellets = 4
			_weapon.damage = 875.0
			_weapon.shots_per_minute = 260.0
			_weapon.spread_degrees = 5.5
			_weapon.projectile_speed = 95.0
			_weapon.projectile_drop = 0.0
			_weapon.projectile_lifetime = 0.8
			_weapon.tracer_color = Color(0.55, 0.8, 1.0)
			_weapon.tracer_radius = 0.05
			_weapon.tracer_length = 1.0
		&"SPITTER":
			_weapon = WeaponData.autocannon()
			_weapon.display_name = "ARACHNID SPITTER"
			_weapon.damage = 1125.0
			_weapon.shots_per_minute = 300.0
			_weapon.spread_degrees = 2.6
			_weapon.projectile_speed = 88.0
			_weapon.projectile_drop = 1.8
			_weapon.projectile_lifetime = 1.6
			_weapon.tracer_color = Color(1.0, 0.3, 0.2)
			_weapon.tracer_radius = 0.075
			_weapon.tracer_length = 1.4
		_:
			_weapon = WeaponData.for_item(String(_weapon_item))
	# MK firepower: scale the hit, never the cadence (kind identity owns fire
	# interval). Corrosion ticks scale with it so acid elites stay scarier too.
	_weapon.damage *= MK_DMG_MULT[mk_tier]
	if _weapon.corrosion_dps > 0.0:
		_weapon.corrosion_dps *= MK_DMG_MULT[mk_tier]

func _physics_process(delta: float) -> void:
	if state != State.DEAD and global_position.y < -30.0:
		global_position = spawn_origin
		velocity = Vector3.ZERO
	if state == State.DEAD:
		_update_death(delta)
		return
	_tick_status(delta)
	if not ai_enabled or GameState.phase != GameState.Phase.COMBAT or not _target_alive():
		_idle_brake(delta)
		_update_legs(delta, false)
		return

	_update_sight(delta)
	_think(delta)
	_apply_gravity(delta)
	move_and_slide()
	_update_legs(delta, true)

func setup(target_robot: PlayerRobot) -> void:
	target = target_robot
	_last_seen = target.global_position if target != null else global_position

func receive_damage(amount: float, point: Vector3,
		hull_fraction: float = Health.HULL_FRACTION) -> void:
	if health == null or health.dead:
		return
	amount *= breach_mult()
	if death_mark_left > 0.0:
		amount *= death_mark_mult
	var applied := health.apply_damage(amount, point, hull_fraction)
	if health.last_hit_total > 0.0:
		GameState.player_damage_dealt += applied
		Events.damage_applied.emit(self, health.last_hit_total, point, Vector3.UP)
		_spawn_hit_flash(point)
		if applied > 0.0 and not health.dead:
			take_component_damage(applied)

# --- component damage (the gun comes off) ----------------------------------
# Same gate as the player: only hull damage taken below 55% feeds the pool,
# and the chassis's one weapon explodes off at the budget with a spark burst.
# After that _fire_once is dead for good — the robot closes in silently.

func take_component_damage(amount: float) -> void:
	if _weapon_destroyed or amount <= 0.0 or health == null or health.dead:
		return
	if health.ratio() > COMPONENT_GATE_RATIO:
		return
	_weapon_stress += amount * COMPONENT_STRESS_MULT
	var threshold := health.max_health * COMPONENT_DESTROY_RATIO
	if threshold > 0.0 and _weapon_stress >= threshold:
		_destroy_weapon()

func is_weapon_destroyed() -> bool:
	return _weapon_destroyed

func is_critical() -> bool:
	return _damage_reaction != null and _damage_reaction.is_critical()

func _destroy_weapon() -> void:
	if _weapon_destroyed or health == null:
		return
	_weapon_destroyed = true
	_weapon_stress = 0.0
	var point := global_position + Vector3.UP * _eye_height
	if rig != null and rig.muzzle != null:
		point = rig.muzzle.global_position
	_hide_weapon_visual()
	var fx := _combat_fx()
	if fx != null:
		fx.spawn_weapon_burst(point, 0.45 + 0.2 * _visual_scale)
	Events.camera_shake_requested.emit(0.18, 0.12)

# Hides every gun part under the rig (ChinGun / ShoulderGun / gun_pod trees).
# Visual only: the muzzle marker keeps its transform so nothing else in the
# aim/fire path has to care that the weapon is gone.
func _hide_weapon_visual() -> void:
	if rig != null:
		_hide_weapon_branch(rig, false)

func _hide_weapon_branch(node: Node, armed: bool) -> void:
	if node == null:
		return
	var label := String(node.name).to_lower()
	var hit := armed or label.contains("gun") or label.contains("barrel") \
			or label.contains("brake")
	if hit:
		var body := node as Node3D
		if body != null:
			body.visible = false
			return
	for child in node.get_children():
		_hide_weapon_branch(child, hit)

func apply_system_jam(duration: float) -> void:
	_jam_left = maxf(_jam_left, duration)

# Void/Chash suppression core: while suppressed the robot deals half damage.
func apply_suppression(duration: float) -> void:
	_suppression_left = maxf(_suppression_left, duration)

func suppressed_mult() -> float:
	return 0.5 if _suppression_left > 0.0 else 1.0

func apply_grav_pulse(push: Vector3) -> void:
	_jam_left = maxf(_jam_left, 0.8)
	velocity += push
	apply_slow(2.5, 0.5)

func apply_armor_fracture(duration: float, strength: float) -> void:
	_fracture_left = maxf(_fracture_left, duration)
	health.defense = 1.0 / (1.0 + maxf(strength, 0.0))

func apply_thermal_breach(count: int = 1) -> void:
	if state == State.DEAD:
		return
	_breach_stacks = mini(_breach_stacks + count, BREACH_MAX)
	_breach_left = BREACH_LIFE

# DEATH MARK: the lock-on target takes amplified damage while marked. The
# session refreshes the mark every frame it stays locked, so the clock only
# runs down once the lock moves away or the target dies.
func apply_death_mark(duration: float, mult: float) -> void:
	if state == State.DEAD or health == null or health.dead:
		return
	death_mark_left = maxf(duration, 0.0)
	death_mark_mult = maxf(mult, 1.0)

func fade_death_mark(duration: float) -> void:
	if state == State.DEAD or death_mark_left <= 0.0:
		return
	death_mark_left = minf(death_mark_left, maxf(duration, 0.0))

func death_mark_active() -> bool:
	return death_mark_left > 0.0 and death_mark_mult > 1.0

func apply_taunt(duration: float, source: PlayerRobot) -> void:
	if state == State.DEAD:
		return
	taunted_left = maxf(duration, 0.0)
	taunted_by = source

func is_taunted() -> bool:
	return taunted_left > 0.0 and taunted_by != null and taunted_by._is_alive()

func breach_stacks() -> int:
	return _breach_stacks

func breach_mult() -> float:
	return 1.0 + BREACH_PER_STACK * float(_breach_stacks)

func eye_position() -> Vector3:
	return global_position + Vector3.UP * _eye_height

func kind_label() -> String:
	var base := ""
	match kind:
		KIND_STALKER:
			base = "STALKER"
		KIND_BRUTE:
			base = "BRUTE"
		KIND_WASP:
			base = "WASP"
		_:
			base = "ARACHNID"
	# Hunting Grounds: the marker/lock tag shows the tier (BASE stays clean).
	if mk_tier > 0:
		return "%s MK%d" % [base, mk_tier]
	return base

func ground_offset() -> float:
	return _spawn_hover

func _target_alive() -> bool:
	return target != null and target._is_alive()

func _tick_status(delta: float) -> void:
	if _jam_left > 0.0:
		_jam_left -= delta
	if _suppression_left > 0.0:
		_suppression_left -= delta
	if _fracture_left > 0.0:
		_fracture_left -= delta
		if _fracture_left <= 0.0:
			health.defense = 1.0
	if _slow_left > 0.0:
		_slow_left -= delta
		if _slow_left <= 0.0:
			_slow_factor = 1.0
	if _corrosion_left > 0.0 and state != State.DEAD:
		_corrosion_left -= delta
		_corrosion_acc += _corrosion_dps * delta
		if _corrosion_acc >= 1.0:
			var tick := _corrosion_acc
			_corrosion_acc = 0.0
			receive_damage(tick, global_position + Vector3.UP * 1.4)
		if _corrosion_left <= 0.0:
			_corrosion_dps = 0.0
			_corrosion_acc = 0.0
	if _breach_left > 0.0:
		_breach_left -= delta
		if _breach_left <= 0.0:
			_breach_stacks = 0
			_breach_left = 0.0
	if death_mark_left > 0.0:
		death_mark_left -= delta
		if death_mark_left <= 0.0:
			death_mark_left = 0.0
			death_mark_mult = 1.0
	if taunted_left > 0.0:
		taunted_left -= delta
	if _pounce_left > 0.0:
		_pounce_left -= delta
	if _fire_left > 0.0:
		_fire_left -= delta
	_tick_hazard(delta)

func _tick_hazard(delta: float) -> void:
	if state == State.DEAD or health == null or health.dead:
		return
	var zone := HazardZones.zone_at(global_position)
	if zone.is_empty():
		_hazard_acc = 0.0
		return
	_hazard_acc += float(zone["dps"]) * health.max_health * delta
	if _hazard_acc >= 1.0:
		var tick := _hazard_acc
		_hazard_acc = 0.0
		receive_damage(tick, global_position + Vector3.UP * 1.2)

func apply_slow(duration: float, factor: float) -> void:
	if state == State.DEAD:
		return
	_slow_left = maxf(_slow_left, duration)
	_slow_factor = minf(_slow_factor, clampf(factor, 0.1, 1.0))

func apply_corrosion(duration: float, dps: float) -> void:
	if state == State.DEAD:
		return
	_corrosion_left = maxf(_corrosion_left, duration)
	_corrosion_dps = maxf(_corrosion_dps, dps)

func _update_sight(delta: float) -> void:
	_sight_left -= delta
	if _sight_left > 0.0:
		return
	_sight_left = SIGHT_INTERVAL
	if not _target_alive():
		_has_los = false
		return
	_sight_from.from = eye_position()
	_sight_from.to = target.eye_position()
	var result := get_world_3d().direct_space_state.intersect_ray(_sight_from)
	_has_los = result.is_empty()
	if _has_los:
		_last_seen = target.global_position

func _think(delta: float) -> void:
	var to_target := target.global_position - global_position
	var distance := Vector3(to_target.x, 0.0, to_target.z).length()

	if (target.is_stealthed() or not _has_los) and not is_taunted():
		if state == State.CHASE or state == State.ATTACK:
			state = State.SEARCH
			_search_left = search_time
		if state == State.SEARCH:
			_search_left -= delta
			if _search_left <= 0.0:
				state = State.IDLE
			else:
				_step_toward(_last_seen, delta, move_speed)
				_face_toward(_last_seen, delta)
		else:
			_idle_brake(delta)
		return

	state = State.ATTACK if distance <= attack_range else State.CHASE
	_last_seen = target.global_position

	if state == State.CHASE:
		_step_toward(target.global_position, delta, move_speed)
		_face_toward(target.global_position, delta)
		_try_pounce(distance)
	elif state == State.ATTACK:
		_face_toward(target.global_position, delta)
		if distance < standoff:
			_brake_and_reverse(delta)
		else:
			_idle_brake(delta)
		_try_pounce(distance)
		_try_fire(delta)

func _try_pounce(distance: float) -> void:
	if not _can_pounce:
		return
	if not _has_los:
		return
	if _pounce_left > 0.0 or _jam_left > 0.0:
		return
	if distance < standoff + 1.0 or distance > attack_range * 0.75:
		return
	var direction := target.global_position - global_position
	direction.y = 0.0
	if direction.length_squared() < 0.01:
		return
	velocity += direction.normalized() * pounce_speed
	_pounce_left = pounce_cooldown

func _try_fire(delta: float) -> void:
	if not _has_los:
		return
	if _burst_left > 0.0:
		_burst_left -= delta
		if _burst_left <= 0.0:
			_fire_once()
			_burst_left = burst_gap
			if _fire_left > burst_gap:
				_burst_left = -1.0
		return
	if _fire_left > 0.0:
		return
	_fire_left = fire_interval
	_burst_left = burst_gap
	_fire_once()

func _fire_once() -> void:
	if _weapon_destroyed:
		return
	if rig == null or rig.muzzle == null or target == null:
		return
	var origin := rig.muzzle.global_position
	var aim := target.eye_position() - origin
	if aim.length_squared() < 0.01:
		return
	var direction := aim.normalized()
	var spread := deg_to_rad(_weapon.spread_degrees)
	var shots := maxi(1, _weapon.pellets)
	var damage_override := -1.0
	if suppressed_mult() < 1.0:
		damage_override = _weapon.damage * suppressed_mult()
	for _shot in shots:
		var shot_dir := direction.rotated(Vector3.UP, randf_range(-spread, spread))
		shot_dir = shot_dir.rotated(Vector3.RIGHT, randf_range(-spread, spread))
		Projectiles.fire(origin, shot_dir, _weapon, [get_rid()], damage_override)
	_spawn_muzzle_flash(origin)

func _face_toward(point: Vector3, delta: float) -> void:
	var flat := point - global_position
	flat.y = 0.0
	if flat.length_squared() < 0.001:
		return
	var desired := atan2(-flat.x, -flat.z)
	var previous := rotation.y
	rotation.y = previous + clampf(angle_difference(previous, desired),
			-turn_speed * delta, turn_speed * delta)

func _step_toward(point: Vector3, delta: float, speed: float) -> void:
	var direction := point - global_position
	direction.y = 0.0
	var distance := direction.length()
	if distance < 0.8:
		_idle_brake(delta)
		return
	var desired := direction / distance * speed * _slow_factor
	velocity.x = move_toward(velocity.x, desired.x, accel * delta)
	velocity.z = move_toward(velocity.z, desired.z, accel * delta)

func _brake_and_reverse(delta: float) -> void:
	var direction := global_position - target.global_position
	direction.y = 0.0
	direction = direction.normalized() * (move_speed * 0.5)
	velocity.x = move_toward(velocity.x, direction.x, accel * delta)
	velocity.z = move_toward(velocity.z, direction.z, accel * delta)

func _idle_brake(delta: float) -> void:
	velocity.x = move_toward(velocity.x, 0.0, accel * 1.6 * delta)
	velocity.z = move_toward(velocity.z, 0.0, accel * 1.6 * delta)

func _apply_gravity(delta: float) -> void:
	if _hovers and state != State.DEAD:
		if _probe_ground(global_position + Vector3.UP * 0.4):
			var target_y := _ground_position.y + rig.hover_height()
			velocity.y = clampf((target_y - global_position.y) * 3.0, -8.0, 8.0)
		else:
			velocity.y = move_toward(velocity.y, 0.0, 6.0 * delta)
		return
	if not is_on_floor():
		var gravity: float = ProjectSettings.get_setting("physics/3d/default_gravity", 22.0)
		velocity.y -= gravity * delta
	elif velocity.y < 0.0:
		velocity.y = 0.0

func _update_legs(delta: float, allow_steps: bool) -> void:
	if rig == null:
		return
	var grounded := is_on_floor()
	var turn := _turn_rate(delta)
	var forward := -global_basis.z
	var up := global_basis.y
	var leg_velocity := velocity if grounded and allow_steps else Vector3.ZERO

	for leg in rig.legs:
		var hip_world := leg.global_position
		var rest := _rest_foot(hip_world, leg, forward)
		if grounded and _probe_ground(hip_world + Vector3.UP * PROBE_UP) \
				and absf(rest.y - (_ground_position.y + GROUND_CLEARANCE)) < 1.7:
			rest.y = _ground_position.y + GROUND_CLEARANCE
		leg.update_gait(hip_world, rest, leg_velocity, forward, up, delta, turn,
				global_position)

	if not grounded:
		_was_airborne += delta
	elif _was_airborne > 0.3:
		rig.reset_feet(_probe_feet())
		_was_airborne = 0.0

	rig.update_animation(delta, velocity, turn, grounded)

var _turn_previous: float = 0.0

func _turn_rate(delta: float) -> float:
	var rate := wrapf(rotation.y - _turn_previous, -PI, PI) / maxf(delta, 0.0001)
	_turn_previous = rotation.y
	return rate

func _rest_foot(hip_world: Vector3, leg: LegUnit, forward: Vector3) -> Vector3:
	var reach := leg.thigh_length + leg.shin_length
	var lateral := global_basis * leg.outward
	lateral = lateral - forward * lateral.dot(forward)
	if lateral.length_squared() < 0.0001:
		lateral = global_basis.x
	lateral = lateral.normalized()
	return hip_world + lateral * (leg.coxa_length + reach * 0.55) + Vector3.DOWN * reach * 0.92

func _probe_feet() -> Array[Vector3]:
	var points: Array[Vector3] = []
	for leg in rig.legs:
		if not _probe_ground(leg.global_position + Vector3.UP * PROBE_UP):
			points.append(leg.global_position + Vector3.DOWN * 1.5)
		else:
			points.append(_ground_position + Vector3.UP * GROUND_CLEARANCE)
	return points

func _probe_ground(from: Vector3) -> bool:
	_probe_from.from = from
	_probe_from.to = from + Vector3.DOWN * PROBE_DOWN
	_probe_result = get_world_3d().direct_space_state.intersect_ray(_probe_from)
	_ground_found = not _probe_result.is_empty()
	if _ground_found:
		_ground_position = _probe_result["position"]
	return _ground_found

func _spawn_muzzle_flash(point: Vector3) -> void:
	var light := OmniLight3D.new()
	light.light_color = Color(1.0, 0.4, 0.3)
	light.omni_range = 4.0
	light.light_energy = 2.4
	light.position = to_local(point)
	add_child(light)
	var tween := create_tween()
	tween.tween_property(light, "light_energy", 0.0, 0.1)
	tween.tween_callback(light.queue_free)

func _spawn_hit_flash(point: Vector3) -> void:
	var light := OmniLight3D.new()
	light.light_color = Color(1.0, 0.7, 0.5)
	light.omni_range = 3.0
	light.light_energy = 3.0
	light.position = to_local(point)
	add_child(light)
	var tween := create_tween()
	tween.tween_property(light, "light_energy", 0.0, 0.12)
	tween.tween_callback(light.queue_free)

func _on_died() -> void:
	state = State.DEAD
	death_mark_left = 0.0
	death_mark_mult = 1.0
	taunted_left = 0.0
	taunted_by = null
	collision_layer = 0
	if rig != null:
		rig.set_dead()
	GameState.notify_enemy_killed()
	Events.enemy_killed.emit(get_instance_id())
	_begin_death_sequence()

func _begin_death_sequence() -> void:
	if not is_inside_tree():
		return
	var push := Vector3(randf_range(-1.0, 1.0), 0.0, randf_range(-1.0, 1.0))
	if push.length_squared() < 0.01:
		push = Vector3.BACK
	velocity += push.normalized() * 1.5 + Vector3.UP * 0.6
	Events.camera_shake_requested.emit(clampf(0.3 * _visual_scale, 0.2, 0.4), 0.28)
	var fx := _combat_fx()
	if fx != null:
		fx.spawn_rupture(global_position + Vector3.UP * _rupture_height())
	_spawn_death_smoke()
	_spawn_death_debris()
	var blast := get_tree().create_timer(DEATH_EXPLOSION_DELAY)
	blast.timeout.connect(_death_explosion.bind(_visual_scale))
	var pop_one := get_tree().create_timer(DEATH_POP_DELAY_A)
	pop_one.timeout.connect(_death_pop.bind(0.45))
	var pop_two := get_tree().create_timer(DEATH_POP_DELAY_B)
	pop_two.timeout.connect(_death_pop.bind(0.7))

func _death_explosion(size_scale: float) -> void:
	if state != State.DEAD or not is_inside_tree():
		return
	var fx := _combat_fx()
	if fx == null:
		return
	fx.spawn_explosion(global_position + Vector3.UP * _rupture_height(), size_scale)

func _death_pop(jitter: float) -> void:
	if state != State.DEAD or not is_inside_tree():
		return
	var fx := _combat_fx()
	if fx == null:
		return
	var point := global_position + Vector3.UP * _rupture_height()
	point += Vector3(randf_range(-jitter, jitter), randf_range(-0.1, 0.35),
			randf_range(-jitter, jitter)) * _visual_scale
	fx.spawn_pop(point, 0.4 + 0.2 * _visual_scale)

func _rupture_height() -> float:
	return maxf(_eye_height, 0.5)

func _combat_fx() -> CombatFx:
	if not is_inside_tree():
		return null
	return get_tree().get_first_node_in_group("combat_fx") as CombatFx

func _debris_parent() -> Node:
	if not is_inside_tree():
		return null
	var fx := _combat_fx()
	if fx != null:
		return fx
	return get_parent()

# Twisted hull chunks thrown clear of the wreck — destruction feedback.
func _spawn_death_debris() -> void:
	var debris := CPUParticles3D.new()
	debris.name = "DeathDebris"
	debris.one_shot = true
	debris.amount = 16
	debris.lifetime = 1.5
	debris.explosiveness = 1.0
	debris.direction = Vector3.UP
	debris.spread = 55.0
	debris.gravity = Vector3(0.0, -24.0, 0.0)
	debris.initial_velocity_min = 5.0
	debris.initial_velocity_max = 11.0
	debris.angular_velocity_min = -9.0
	debris.angular_velocity_max = 9.0
	debris.scale_amount_min = 0.4
	debris.scale_amount_max = 1.2
	debris.color = Color(0.24, 0.22, 0.2, 1.0)
	var chunk := BoxMesh.new()
	chunk.size = Vector3(0.34, 0.34, 0.34)
	var material := MeshUtil.make_material(Color(0.2, 0.19, 0.17), 0.7, 0.55)
	material.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
	material.vertex_color_use_as_albedo = true
	chunk.material = material
	debris.mesh = chunk
	debris.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	debris.position = Vector3(0.0, 1.4, 0.0)
	add_child(debris)
	debris.emitting = true
	var timer := get_tree().create_timer(2.2)
	timer.timeout.connect(debris.queue_free)
	_spawn_debris_chunks()

func _spawn_debris_chunks() -> void:
	var parent := _debris_parent()
	if parent == null:
		return
	var count := clampi(int(round(8.0 + 6.0 * (_visual_scale - 0.8) / 0.5)), 8, 14)
	_prune_debris()
	while _live_debris.size() + count > MAX_LIVE_DEBRIS and not _live_debris.is_empty():
		var oldest: RigidBody3D = _live_debris.pop_front()
		if is_instance_valid(oldest):
			oldest.queue_free()
	var hot_left := 2 if count >= 12 else 1
	var origin := global_position + Vector3.UP * _rupture_height()
	for index in count:
		var piece := RigidBody3D.new()
		piece.name = "DebrisChunk"
		piece.collision_layer = 0
		piece.collision_mask = Layers.WORLD
		var side := randf_range(0.14, 0.44) * _visual_scale
		var piece_size := Vector3(side, side * randf_range(0.45, 1.0),
				side * randf_range(0.5, 1.4))
		var hot := index < hot_left
		var piece_material := MeshUtil.make_material(Color(0.15, 0.14, 0.13), 0.7, 0.5,
				Color(1.0, 0.42, 0.1), 4.2 if hot else 3.4)
		var mesh := BoxMesh.new()
		mesh.size = piece_size
		mesh.material = piece_material
		var visual := MeshInstance3D.new()
		visual.name = "ChunkMesh"
		visual.mesh = mesh
		visual.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
		piece.add_child(visual)
		var shape := CollisionShape3D.new()
		shape.name = "ChunkShape"
		var solid := BoxShape3D.new()
		solid.size = piece_size
		shape.shape = solid
		piece.add_child(shape)
		parent.add_child(piece)
		piece.global_position = origin + Vector3(randf_range(-1.0, 1.0),
				randf_range(-0.7, 0.7), randf_range(-1.0, 1.0)) * 0.75 * _visual_scale
		var launch := Vector3(randf_range(-1.0, 1.0), randf_range(0.3, 1.1),
				randf_range(-1.0, 1.0)).normalized()
		piece.apply_central_impulse(launch * randf_range(4.0, 10.5) * _visual_scale)
		piece.angular_velocity = Vector3(randf_range(-9.0, 9.0),
				randf_range(-9.0, 9.0), randf_range(-9.0, 9.0))
		var life := DEBRIS_MAX_LIFETIME if hot \
				else randf_range(DEBRIS_MIN_LIFETIME, DEBRIS_MAX_LIFETIME)
		var life_timer := get_tree().create_timer(life)
		life_timer.timeout.connect(piece.queue_free)
		var tween := piece.create_tween()
		tween.tween_property(piece_material, "emission_energy_multiplier",
				1.0 if hot else 0.0, randf_range(1.1, 2.0))
		_live_debris.append(piece)

func _prune_debris() -> void:
	for index in range(_live_debris.size() - 1, -1, -1):
		if not is_instance_valid(_live_debris[index]):
			_live_debris.remove_at(index)

func _update_death(delta: float) -> void:
	_death_left -= delta
	rotation.z = lerpf(rotation.z, _death_tilt, clampf(delta * 2.4, 0.0, 1.0))
	velocity.x = move_toward(velocity.x, 0.0, 30.0 * delta)
	velocity.z = move_toward(velocity.z, 0.0, 30.0 * delta)
	_apply_gravity(delta)
	move_and_slide()
	if _death_left <= 0.0:
		queue_free()

func _spawn_death_smoke() -> void:
	var smoke := CPUParticles3D.new()
	smoke.name = "DeathSmoke"
	smoke.one_shot = true
	smoke.amount = 22
	smoke.lifetime = 1.6
	smoke.explosiveness = 0.7
	smoke.direction = Vector3.UP
	smoke.spread = 40.0
	smoke.gravity = Vector3(0.0, 1.4, 0.0)
	smoke.initial_velocity_min = 0.8
	smoke.initial_velocity_max = 2.2
	smoke.scale_amount_min = 0.3
	smoke.scale_amount_max = 0.9
	smoke.color = Color(0.12, 0.11, 0.11, 0.75)
	var ball := SphereMesh.new()
	ball.radius = 0.35
	ball.height = 0.7
	var material := MeshUtil.make_material(Color(0.1, 0.1, 0.1), 0.0, 1.0)
	material.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
	material.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
	material.vertex_color_use_as_albedo = true
	ball.material = material
	smoke.mesh = ball
	add_child(smoke)
	smoke.emitting = true
	var timer := get_tree().create_timer(2.0)
	timer.timeout.connect(smoke.queue_free)
