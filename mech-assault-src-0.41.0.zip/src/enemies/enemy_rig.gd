class_name EnemyRig
extends Node3D

var legs: Array[LegUnit] = []
var muzzle: Marker3D

# Uniform chassis scale. Set BEFORE the rig enters the tree so _build_legs can
# bake it into the IK lengths (same contract as RobotRig.visual_scale).
var visual_scale: float = 1.0:
	set(value):
		visual_scale = value
		scale = Vector3(value, value, value)
var hull: Node3D
var sensor_bar: MeshInstance3D


func update_animation(
		_delta: float, _velocity: Vector3, _turn_rate: float, _grounded: bool) -> void:
	pass


func reset_feet(_ground_points: Array[Vector3]) -> void:
	pass


func set_dead() -> void:
	pass


func hover_height() -> float:
	return 0.0
