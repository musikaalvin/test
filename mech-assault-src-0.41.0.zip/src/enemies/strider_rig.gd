class_name StriderRig
extends EnemyRig

var _leg_bases: Array[Vector3] = []
var _hull_base: Vector3 = Vector3.ZERO
var _bob_phase: float = 0.0
var _pitch: float = 0.0
var _roll: float = 0.0

var _shell: StandardMaterial3D
var _plate: StandardMaterial3D
var _joint: StandardMaterial3D
var _trim: StandardMaterial3D
var _sensor: StandardMaterial3D
var _dark: StandardMaterial3D

func _ready() -> void:
	_make_materials()
	_build_torso()
	_build_legs()

func _make_materials() -> void:
	_shell = MeshUtil.make_material(Color(0.2, 0.23, 0.29), 0.15, 0.5)
	_plate = MeshUtil.make_material(Color(0.55, 0.58, 0.62), 0.7, 0.4)
	_joint = MeshUtil.make_material(Color(0.07, 0.07, 0.08), 0.0, 0.8)
	_trim = MeshUtil.make_material(Color(0.85, 0.5, 0.12), 0.2, 0.5)
	_sensor = MeshUtil.make_material(Color(1.0, 0.72, 0.2), 0.2, 0.2,
			Color(1.0, 0.6, 0.15), 4.2)
	_dark = MeshUtil.make_material(Color(0.05, 0.05, 0.06), 0.55, 0.75)
	PanelTextures.apply(_shell, &"armor", 1.4)
	PanelTextures.apply(_plate, &"steel", 1.7)
	PanelTextures.apply(_joint, &"rubber", 3.0)

func _build_torso() -> void:
	hull = Node3D.new()
	hull.name = "Hull"
	add_child(hull)
	_hull_base = hull.position

	MeshUtil.bevel_at(hull, Vector3(0.85, 0.5, 0.7), Vector3(0.0, 0.5, 0.0),
			Vector3.ZERO, _shell, "pelvis")
	MeshUtil.bevel_at(hull, Vector3(0.7, 0.9, 0.55), Vector3(0.0, 1.15, -0.05),
			Vector3(4.0, 0.0, 0.0), _shell, "spine")
	MeshUtil.bevel_at(hull, Vector3(0.9, 0.6, 0.75), Vector3(0.0, 1.5, -0.1),
			Vector3(-6.0, 0.0, 0.0), _plate, "chest")
	MeshUtil.bevel_at(hull, Vector3(0.96, 0.14, 0.5), Vector3(0.0, 1.8, -0.14),
			Vector3(-14.0, 0.0, 0.0), _trim, "collar")
	for side in [-1.0, 1.0]:
		MeshUtil.bevel_at(hull, Vector3(0.3, 0.55, 0.6), Vector3(side * 0.55, 1.5, -0.05),
				Vector3.ZERO, _shell, "shoulder")
		MeshUtil.cone_at(hull, 0.14, 0.03, 0.5, Vector3(side * 0.6, 1.78, -0.1),
				Vector3(-16.0, 0.0, side * -12.0), _trim, "shoulder_spike")
		MeshUtil.cyl_at(hull, 0.07, 0.55, Vector3(side * 0.3, 0.85, 0.32),
				Vector3(18.0, 0.0, 0.0), _dark, "back_piston")

	MeshUtil.bevel_at(hull, Vector3(0.6, 0.32, 0.45), Vector3(0.0, 2.0, -0.12),
			Vector3.ZERO, _dark, "head_shell")
	MeshUtil.bevel_at(hull, Vector3(0.5, 0.08, 0.08), Vector3(0.0, 2.02, -0.34),
			Vector3.ZERO, _sensor, "optic_bar")
	sensor_bar = hull.get_node_or_null("optic_bar") as MeshInstance3D
	MeshUtil.cone_at(hull, 0.06, 0.01, 0.4, Vector3(0.0, 1.86, -0.3),
			Vector3(-95.0, 0.0, 0.0), _trim, "chin_blade")

	var gun := Node3D.new()
	gun.name = "ShoulderGun"
	gun.position = Vector3(0.45, 1.62, -0.45)
	hull.add_child(gun)
	MeshUtil.bevel_at(gun, Vector3(0.34, 0.3, 0.7), Vector3.ZERO, Vector3.ZERO,
			_dark, "gun_body")
	MeshUtil.cyl_at(gun, 0.06, 1.1, Vector3(0.0, 0.05, -0.65),
			Vector3(90.0, 0.0, 0.0), _trim, "gun_barrel")
	MeshUtil.cyl_at(gun, 0.09, 0.16, Vector3(0.0, 0.05, -1.16),
			Vector3(90.0, 0.0, 0.0), _dark, "gun_brake")
	muzzle = Marker3D.new()
	muzzle.name = "Muzzle"
	muzzle.position = Vector3(0.0, 0.05, -1.2)
	gun.add_child(muzzle)

func _build_legs() -> void:
	var hip_pos: Array[Vector3] = [
		Vector3(0.5, 0.28, 0.0), Vector3(-0.5, 0.28, 0.0),
	]
	var hip_phase: Array[float] = [0.0, 0.5]
	var hip_name: Array[String] = ["Leg_R", "Leg_L"]
	for index in hip_pos.size():
		var leg := LegUnit.new()
		leg.name = hip_name[index]
		leg.phase_offset = hip_phase[index]
		leg.outward = Vector3(1.0 if index == 0 else -1.0, 0.0, 0.0)
		leg.coxa_length = 0.3
		leg.thigh_length = 1.05
		leg.shin_length = 1.2
		leg.thigh_radius = 0.15
		leg.shin_radius = 0.11
		leg.hip_radius = 0.19
		leg.foot_size = Vector3(0.3, 0.1, 0.5)
		leg.stride_length = 1.0
		leg.step_height = 0.55
		leg.reference_speed = 5.0
		leg.configure(_shell, _joint, _plate, _trim, _trim)
		leg.apply_scale(visual_scale)
		add_child(leg)
		leg.position = hip_pos[index]
		_leg_bases.append(hip_pos[index])
		legs.append(leg)
		MeshUtil.sph_at(self, 0.16, hip_pos[index], _joint, "hip_pod")

func update_animation(delta: float, velocity: Vector3, turn_rate: float, grounded: bool) -> void:
	var planar := Vector3(velocity.x, 0.0, velocity.z)
	var speed := planar.length()
	var speed_ratio := clampf(speed / 5.0, 0.0, 1.4)
	var target_pitch := clampf(velocity.dot(global_basis.z) * 0.012, -0.08, 0.08)
	var strafe := planar.dot(global_basis.x)
	var target_roll := clampf(turn_rate * 0.05 - strafe * 0.035, -0.14, 0.14)
	_pitch = lerpf(_pitch, target_pitch if grounded else 0.0, clampf(delta * 6.0, 0.0, 1.0))
	_roll = lerpf(_roll, target_roll, clampf(delta * 6.0, 0.0, 1.0))

	_bob_phase += delta * (2.6 + speed_ratio * 7.0)
	var bob := sin(_bob_phase) * 0.035 * (0.3 + speed_ratio)
	if not grounded:
		bob = 0.0
	var offset := Vector3(0.0, bob, 0.0)
	hull.position = _hull_base + offset
	hull.rotation = Vector3(_pitch, 0.0, _roll)
	for index in legs.size():
		legs[index].position = _leg_bases[index] + offset

func reset_feet(ground_points: Array[Vector3]) -> void:
	for index in legs.size():
		if index < ground_points.size():
			legs[index].reset_gait(ground_points[index])
		else:
			legs[index].reset_gait(legs[index].global_position)

func set_dead() -> void:
	_sensor.emission_energy_multiplier = 0.05
	_sensor.albedo_color = Color(0.25, 0.2, 0.1)
