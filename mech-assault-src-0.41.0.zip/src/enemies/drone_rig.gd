class_name DroneRig
extends EnemyRig

const HOVER_HEIGHT := 4.2

var _rotors: Array[Node3D] = []
var _hull_base: Vector3 = Vector3.ZERO
var _bob_phase: float = 0.0
var _dead: bool = false

var _shell: StandardMaterial3D
var _accent: StandardMaterial3D
var _joint: StandardMaterial3D
var _trim: StandardMaterial3D
var _sensor: StandardMaterial3D
var _dark: StandardMaterial3D

func _ready() -> void:
	_make_materials()
	_build_body()
	_build_rotors()
	_build_gun()

func _make_materials() -> void:
	_shell = MeshUtil.make_material(Color(0.14, 0.15, 0.19), 0.2, 0.45)
	_accent = MeshUtil.make_material(Color(0.45, 0.18, 0.6), 0.25, 0.45)
	_joint = MeshUtil.make_material(Color(0.06, 0.06, 0.07), 0.0, 0.85)
	_trim = MeshUtil.make_material(Color(0.5, 0.52, 0.58), 0.95, 0.35)
	_sensor = MeshUtil.make_material(Color(0.7, 0.3, 1.0), 0.2, 0.2,
			Color(0.6, 0.25, 1.0), 4.5)
	_dark = MeshUtil.make_material(Color(0.04, 0.04, 0.05), 0.55, 0.75)
	PanelTextures.apply(_shell, &"armor", 1.6)
	PanelTextures.apply(_accent, &"armor", 1.8)

func _build_body() -> void:
	hull = Node3D.new()
	hull.name = "Hull"
	add_child(hull)
	_hull_base = hull.position

	var core := MeshUtil.make_cylinder(0.52, 0.3, _shell, 10, "drone_core")
	hull.add_child(core)
	MeshUtil.bevel_at(hull, Vector3(0.7, 0.18, 0.7), Vector3(0.0, 0.2, 0.0),
			Vector3.ZERO, _accent, "top_cover")
	MeshUtil.bevel_at(hull, Vector3(0.5, 0.2, 0.4), Vector3(0.0, -0.1, -0.4),
			Vector3.ZERO, _dark, "nose")
	MeshUtil.sph_at(hull, 0.13, Vector3(0.0, -0.05, -0.55), _sensor, "eye")
	sensor_bar = hull.get_node_or_null("eye") as MeshInstance3D
	MeshUtil.bevel_at(hull, Vector3(0.4, 0.06, 0.3), Vector3(0.0, -0.24, 0.05),
			Vector3.ZERO, _trim, "belly_plate")
	for side in [-1.0, 1.0]:
		MeshUtil.bevel_at(hull, Vector3(0.08, 0.3, 0.5), Vector3(side * 0.3, -0.28, 0.3),
				Vector3.ZERO, _trim, "skid")

func _build_rotors() -> void:
	for index in 4:
		var angle := deg_to_rad(45.0 + 90.0 * index)
		var dir := Vector3(cos(angle), 0.0, sin(angle))
		var arm := Node3D.new()
		arm.name = "Arm_%d" % index
		arm.position = dir * 0.45
		arm.rotation.y = -angle
		hull.add_child(arm)
		MeshUtil.bevel_at(arm, Vector3(0.5, 0.08, 0.14), Vector3(0.35, 0.06, 0.0),
				Vector3.ZERO, _shell, "arm")

		var rotor := Node3D.new()
		rotor.name = "Rotor_%d" % index
		rotor.position = Vector3(0.75, 0.12, 0.0)
		arm.add_child(rotor)
		var hub := MeshUtil.make_cylinder(0.07, 0.1, _joint, 8, "hub")
		rotor.add_child(hub)
		for blade_index in 2:
			var blade := MeshUtil.make_bevel_box(Vector3(0.9, 0.02, 0.1), 0.01,
					_trim, "blade_%d" % blade_index)
			rotor.add_child(blade)
			blade.rotation.y = deg_to_rad(90.0 * blade_index)
		var ring := MeshUtil.make_cylinder(0.42, 0.03, _accent, 12, "guard")
		rotor.add_child(ring)
		ring.position.y = -0.03
		_rotors.append(rotor)

func _build_gun() -> void:
	var gun := Node3D.new()
	gun.name = "ChinGun"
	gun.position = Vector3(0.0, -0.26, -0.35)
	hull.add_child(gun)
	MeshUtil.bevel_at(gun, Vector3(0.24, 0.2, 0.35), Vector3.ZERO, Vector3.ZERO,
			_dark, "gun_body")
	MeshUtil.cyl_at(gun, 0.05, 0.5, Vector3(0.0, 0.0, -0.35),
			Vector3(90.0, 0.0, 0.0), _trim, "gun_barrel")
	muzzle = Marker3D.new()
	muzzle.name = "Muzzle"
	muzzle.position = Vector3(0.0, 0.0, -0.62)
	gun.add_child(muzzle)

func update_animation(delta: float, velocity: Vector3, turn_rate: float, _grounded: bool) -> void:
	_bob_phase += delta * 3.2
	var bob := sin(_bob_phase) * 0.07
	hull.position = _hull_base + Vector3(0.0, bob, 0.0)
	hull.rotation = Vector3(
			clampf(-velocity.z * 0.02, -0.2, 0.2),
			0.0,
			clampf(-turn_rate * 0.06 + velocity.x * 0.02, -0.3, 0.3))
	if not _dead:
		for rotor in _rotors:
			rotor.rotation.y += delta * 42.0

func set_dead() -> void:
	_dead = true
	_sensor.emission_energy_multiplier = 0.05
	_sensor.albedo_color = Color(0.2, 0.1, 0.3)

func hover_height() -> float:
	return HOVER_HEIGHT * visual_scale
