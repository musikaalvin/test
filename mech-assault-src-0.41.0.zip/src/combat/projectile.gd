class_name Projectile
extends Node3D

const ARC_SEGMENTS := 6

var hit_point: Vector3 = Vector3.ZERO
var hit_normal: Vector3 = Vector3.UP
var hit_collider: Object = null

var _active: bool = false
var _velocity: Vector3 = Vector3.ZERO
var _life_left: float = 0.0
var _data: WeaponData = null
# Per-shot damage override (VOID/CHASH post-reload supercharge): > 0 wins
# over the shared WeaponData damage so boosts never mutate shared data.
var _damage_override: float = -1.0
# Muzzle position of the shot: electric rounds scale damage by the distance
# they have travelled since launch (WR lightning-arc range curve).
var _launch_origin: Vector3 = Vector3.ZERO
var _mesh: MeshInstance3D = null
var _material: StandardMaterial3D
var _trace_shape: int = WeaponData.TracerShape.STREAK
var _arc_segments: Array[MeshInstance3D] = []
var _query := PhysicsRayQueryParameters3D.new()

func prepare(material: StandardMaterial3D) -> void:
	_material = material.duplicate() as StandardMaterial3D
	_mesh = MeshUtil.make_box(Vector3.ONE, _material, "tracer")
	_mesh.visible = false
	add_child(_mesh)
	_query.collision_mask = Layers.PROJECTILE_MASK
	_query.collide_with_areas = false
	_query.collide_with_bodies = true
	visible = false

# Swaps the round's silhouette to match its weapon family: a bright orb for
# electric arcs and corrosive blobs, a fat short shell for launchers, a long
# streak for kinetic tracers. Called from launch() once the weapon is known.
func _ensure_tracer_shape() -> void:
	if _data == null or _mesh == null:
		return
	var shape := WeaponData.tracer_shape_for(_data.family, _data.kind)
	if shape == _trace_shape and _mesh.mesh != null:
		return
	_trace_shape = shape
	if shape == WeaponData.TracerShape.ORB:
		var orb := SphereMesh.new()
		orb.radius = 0.5
		orb.height = 1.0
		orb.radial_segments = MeshUtil.SEGMENTS_LOW
		orb.rings = 4
		orb.material = _material
		_mesh.mesh = orb
	else:
		var box := BoxMesh.new()
		box.size = Vector3.ONE
		box.material = _material
		_mesh.mesh = box

func is_active() -> bool:
	return _active

func weapon_damage() -> float:
	var base := _damage_override if _damage_override > 0.0 else \
			(_data.damage if _data != null else 0.0)
	if _data != null and _data.kind == WeaponData.Kind.ELECTRIC:
		# WR lightning arc: damage climbs sharply at close range (+137% at
		# 50 m) and fades far out (-77% at 600 m) — see arc_distance_mult.
		base *= WeaponData.arc_distance_mult(
				_launch_origin.distance_to(global_position))
	return base

func weapon_name() -> String:
	return _data.display_name if _data != null else ""

func weapon_slow_factor() -> float:
	return _data.slow_factor if _data != null else 1.0

func weapon_slow_duration() -> float:
	return _data.slow_duration if _data != null else 0.0

func weapon_splash_radius() -> float:
	return _data.splash_radius if _data != null else 0.0

func weapon_corrosion_dps() -> float:
	return _data.corrosion_dps if _data != null else 0.0

func weapon_corrosion_duration() -> float:
	return _data.corrosion_duration if _data != null else 0.0

func weapon_kind() -> int:
	return _data.kind if _data != null else -1

func weapon_hull_fraction() -> float:
	return _data.hull_fraction if _data != null else Health.HULL_FRACTION

func weapon_item_id() -> String:
	return _data.item_id if _data != null else ""

func weapon_chain_bounces() -> int:
	return _data.chain_bounces if _data != null else 0

func weapon_chain_range() -> float:
	return _data.chain_range if _data != null else 0.0

func launch(origin: Vector3, direction: Vector3, data: WeaponData, exclude: Array[RID],
		damage_override: float = -1.0) -> void:
	_data = data
	_damage_override = damage_override
	_launch_origin = origin
	_ensure_tracer_shape()
	if _material != null:
		_material.albedo_color = data.tracer_color
		_material.emission = data.tracer_color
		# A round that reads as a glowing ball needs far more emission than a
		# solid shell, or it washes out against the muzzle flash.
		match _trace_shape:
			WeaponData.TracerShape.ORB:
				_material.emission_energy_multiplier = 5.0
			WeaponData.TracerShape.NEEDLE:
				_material.emission_energy_multiplier = 4.2
			WeaponData.TracerShape.SHELL:
				_material.emission_energy_multiplier = 2.4
			_:
				_material.emission_energy_multiplier = 3.5
	_velocity = direction.normalized() * data.projectile_speed
	_life_left = data.projectile_lifetime
	hit_collider = null
	_active = true
	visible = true
	_mesh.visible = true
	global_position = origin
	_query.exclude = exclude
	_aim(origin + _velocity)
	_setup_arc()

func advance(delta: float, space: PhysicsDirectSpaceState3D) -> bool:
	if not _active or _data == null:
		return false
	_life_left -= delta
	if _life_left <= 0.0:
		deactivate()
		return false
	_velocity.y -= _data.projectile_drop * delta
	var from := global_position
	var to := from + _velocity * delta
	_query.from = from
	_query.to = to
	var result := space.intersect_ray(_query)
	if not result.is_empty():
		hit_point = result["position"]
		hit_normal = result["normal"]
		hit_collider = result["collider"]
		global_position = hit_point
		deactivate()
		return true
	global_position = to
	_aim(to)
	_refresh_arc()
	return false

func deactivate() -> void:
	_active = false
	visible = false
	if _mesh != null:
		_mesh.visible = false
	for segment in _arc_segments:
		segment.visible = false

func _setup_arc() -> void:
	if _data == null or _data.kind != WeaponData.Kind.ELECTRIC:
		for segment in _arc_segments:
			segment.visible = false
		return
	if _arc_segments.is_empty():
		var arc_material := MeshUtil.make_material(Color(0.78, 0.9, 1.0), 0.0, 0.25,
				Color(0.7, 0.88, 1.0), 5.0)
		arc_material.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
		for index in ARC_SEGMENTS:
			var segment := MeshUtil.make_box(Vector3.ONE, arc_material, "arc")
			segment.visible = false
			add_child(segment)
			_arc_segments.append(segment)
	for segment in _arc_segments:
		segment.visible = true
	_refresh_arc()

func _refresh_arc() -> void:
	if _arc_segments.is_empty() or _data == null or not _active:
		return
	var length := _data.tracer_length
	var radius := _data.tracer_radius
	var step := length / float(ARC_SEGMENTS)
	var points: Array[Vector3] = []
	for index in ARC_SEGMENTS + 1:
		var z := -length * 0.5 + step * float(index)
		var spread := radius * (0.35 if index == 0 or index == ARC_SEGMENTS else 1.7)
		points.append(Vector3(randf_range(-1.0, 1.0) * spread,
				randf_range(-1.0, 1.0) * spread, z))
	for index in ARC_SEGMENTS:
		var a := points[index]
		var b := points[index + 1]
		var mid := b - a
		var segment := _arc_segments[index]
		segment.position = (a + b) * 0.5
		if mid.length_squared() > 0.000001:
			segment.basis = MeshUtil.segment_basis(mid)
			segment.scale = Vector3(radius * 1.3, mid.length() * 1.35, radius * 1.3)

func _aim(target: Vector3) -> void:
	var direction := target - global_position
	if direction.length_squared() < 0.000001:
		return
	var up := Vector3.UP
	if absf(direction.normalized().dot(up)) > 0.999:
		up = Vector3.FORWARD
	look_at(target, up)
	match _trace_shape:
		WeaponData.TracerShape.ORB:
			# Round glowing bolt: scale is uniform so the sphere stays round
			# in the projectile's own (aimed) frame.
			var glow := _data.tracer_radius * 4.0
			_mesh.scale = Vector3(glow, glow, glow)
		WeaponData.TracerShape.NEEDLE:
			_mesh.scale = Vector3(_data.tracer_radius * 0.75,
					_data.tracer_radius * 0.75, _data.tracer_length * 1.3)
		WeaponData.TracerShape.SHELL:
			_mesh.scale = Vector3(_data.tracer_radius * 3.2,
					_data.tracer_radius * 3.2, _data.tracer_length * 0.6)
		_:
			_mesh.scale = Vector3(_data.tracer_radius * 2.0,
					_data.tracer_radius * 2.0, _data.tracer_length)