class_name HealFxController
extends Node3D

## War Robots-style repair presentation: an expanding green ground ring, hull
## sparkles, a soft repair flash and a floating cross, plus a beam that ties the
## companion drone to the hull while it channels its emergency repair. Attached
## by PlayerRobot._ready and wired through setup(host, health), exactly like
## DamageReactionController.
##
## Heals are detected from Events.player_health_changed by keeping the previous
## HP value: a positive delta is a repair, a negative one is damage. Ticks below
## 0.5% of max HP pile up for up to a second so passive regeneration breathes
## instead of strobing, a single 0.5%+ delta pulses straight away, and a 5%+
## delta (the drone's emergency burst) also drops the cross glyph.
##
## Ring / flash / cross / beam are pooled and driven by this node's own
## _process (no tweens), sparkles are one-shot systems freed by a tree timer,
## and everything goes with health.died. Every material is created here, so
## nothing the rig shares (palette colours, stealth alpha, panel textures) is
## ever written.

const PULSE_MIN_RATIO := 0.005
const ACCUM_RATIO := 0.005
const ACCUM_WINDOW := 1.0
const BURST_RATIO := 0.05
const RING_LIFE := 0.55
const RING_BURST_LIFE := 0.8
const RING_START_SCALE := 1.15
const RING_END_SCALE := 3.4
const RING_BURST_END_SCALE := 4.6
const RING_INNER := 0.88
const RING_OUTER := 1.0
const RING_MAIN_SEGMENTS := 44
const RING_TUBE_SEGMENTS := 6
const FLASH_LIFE := 0.4
const FLASH_ENERGY := 0.6
const FLASH_BURST_ENERGY := 0.95
const FLASH_RANGE := 3.6
const CROSS_LIFE := 0.55
const CROSS_SIZE := 0.62
const CROSS_THICK := 0.16
const CROSS_RISE := 0.4
const SPARK_COUNT := 8
const SPARK_COUNT_BURST := 18
const SPARK_LIFE := 0.5
const BEAM_THICKNESS := 0.07
const BEAM_ALPHA := 0.9
const BEAM_ENERGY := 5.0
const BEAM_FADE_IN := 6.0
const BEAM_FADE_OUT := 1.0

const HEAL_COLOR := Color(0.34, 1.0, 0.52)

var _health: Health = null
var _dead: bool = false
var _size_scale: float = 1.0
var _base_y: float = -1.5
var _centre_y: float = 0.0
var _top_y: float = 1.7

var _seeded: bool = false
var _last_hp: float = 0.0
var _pending: float = 0.0
var _pending_gap: float = 0.0

var _ring: MeshInstance3D = null
var _ring_material: StandardMaterial3D = null
var _ring_life: float = 0.0
var _ring_duration: float = RING_LIFE
var _ring_from: float = RING_START_SCALE
var _ring_to: float = RING_END_SCALE

var _flash: OmniLight3D = null
var _flash_life: float = 0.0
var _flash_peak: float = FLASH_ENERGY

var _cross: Node3D = null
var _cross_material: StandardMaterial3D = null
var _cross_life: float = 0.0

var _beam: MeshInstance3D = null
var _beam_material: StandardMaterial3D = null
var _beam_source: Node3D = null
var _beam_on: bool = false
var _beam_fade: float = 0.0

var _spark_mesh: BoxMesh = null
var _spark_ramp: Gradient = null

func setup(host: Node3D, health: Health) -> void:
	if host == null or health == null:
		return
	_health = health
	_measure_host(host)
	_build_nodes()
	_last_hp = health.current
	_seeded = true
	health.died.connect(_on_died)
	Events.player_health_changed.connect(note_health)

# Total is the post-change HP, so the repair amount is the positive part of the
# movement since the last sample; damage simply drops the accumulator and the
# HUD-only re-emits (same value twice) read as a zero delta and pulse nothing.
func note_health(total: float, maximum: float) -> void:
	if _dead:
		return
	if not _seeded:
		_seeded = true
		_last_hp = total
		return
	var delta := total - _last_hp
	_last_hp = total
	if maximum <= 0.0:
		return
	if delta <= 0.0:
		_pending = 0.0
		_pending_gap = 0.0
		return
	var ratio := delta / maximum
	if ratio >= PULSE_MIN_RATIO:
		_pending = 0.0
		_pending_gap = 0.0
		pulse(ratio)
		return
	_pending += delta
	_pending_gap = 0.0
	if _pending >= maximum * ACCUM_RATIO:
		var stacked := _pending
		_pending = 0.0
		pulse(stacked / maximum)

func pulse(amount_ratio: float) -> void:
	if _dead or not is_inside_tree():
		return
	if _health != null and _health.dead:
		return
	var ratio := clampf(amount_ratio, 0.0, 1.0)
	var burst := ratio >= BURST_RATIO
	_start_ring(burst)
	_start_flash(burst)
	_spawn_sparks(SPARK_COUNT_BURST if burst else SPARK_COUNT)
	if burst:
		_start_cross()

func set_beam_active(active: bool) -> void:
	if _dead:
		return
	_beam_on = active

func set_beam_source(source: Node3D) -> void:
	if _dead:
		return
	_beam_source = source

func _on_died() -> void:
	if _dead:
		return
	_dead = true
	_pending = 0.0
	_ring_life = 0.0
	_flash_life = 0.0
	_cross_life = 0.0
	_beam_on = false
	_beam_fade = 0.0
	_beam_source = null
	# Everything this controller owns lives under it, so one pass frees the
	# pooled meshes, the light and any spark system still in flight.
	for child in get_children():
		child.queue_free()
	_ring = null
	_ring_material = null
	_flash = null
	_cross = null
	_cross_material = null
	_beam = null
	_beam_material = null
	_spark_mesh = null
	_spark_ramp = null
	set_process(false)

func _process(delta: float) -> void:
	if _dead:
		return
	if _pending > 0.0:
		_pending_gap += delta
		if _pending_gap > ACCUM_WINDOW:
			_pending = 0.0
			_pending_gap = 0.0
	_tick_ring(delta)
	_tick_flash(delta)
	_tick_cross(delta)
	_tick_beam(delta)

func _tick_ring(delta: float) -> void:
	if _ring_life <= 0.0 or _ring == null or _ring_material == null:
		return
	_ring_life -= delta
	var ratio := clampf(_ring_life / maxf(_ring_duration, 0.01), 0.0, 1.0)
	var spread := 1.0 - ratio
	_ring.scale = Vector3.ONE * (lerpf(_ring_from, _ring_to, spread) * _size_scale)
	_apply_glow(_ring_material, ratio, 0.9, 5.0)
	if _ring_life <= 0.0:
		_ring.visible = false

func _tick_flash(delta: float) -> void:
	if _flash_life <= 0.0 or _flash == null:
		return
	_flash_life -= delta
	var ratio := clampf(_flash_life / FLASH_LIFE, 0.0, 1.0)
	_flash.light_energy = _flash_peak * ratio
	if _flash_life <= 0.0:
		_flash.visible = false
		_flash.light_energy = 0.0

func _tick_cross(delta: float) -> void:
	if _cross_life <= 0.0 or _cross == null or _cross_material == null:
		return
	_cross_life -= delta
	var ratio := clampf(_cross_life / CROSS_LIFE, 0.0, 1.0)
	_cross.position.y = _top_y + (1.0 - ratio) * CROSS_RISE
	_apply_glow(_cross_material, ratio, 0.95, 6.0)
	if _cross_life <= 0.0:
		_cross.visible = false

func _tick_beam(delta: float) -> void:
	if _beam == null or _beam_material == null:
		return
	# No source (drone swapped away or the hull died): there is nothing left to
	# aim at, so the beam drops instead of trying to read a freed position.
	if not is_instance_valid(_beam_source):
		_beam_on = false
		_beam_fade = 0.0
		_beam.visible = false
		return
	if _beam_on:
		_beam_fade = minf(_beam_fade + delta * BEAM_FADE_IN, 1.0)
	else:
		_beam_fade = maxf(_beam_fade - delta / BEAM_FADE_OUT, 0.0)
	if _beam_fade <= 0.0:
		_beam.visible = false
		return
	var start_point := to_local(_beam_source.global_position)
	var hull := Vector3(0.0, _centre_y, 0.0)
	var axis := hull - start_point
	var length := axis.length()
	if length < 0.1:
		_beam.visible = false
		return
	# A unit box laid along Y and scaled into the gap: same transform maths as
	# MeshUtil.segment_basis, with the cross-section pinned to BEAM_THICKNESS.
	# (Local is not called `basis` - that would shadow Node3D.basis, and this
	# project treats shadow warnings as errors.)
	var beam_basis := MeshUtil.segment_basis(axis / length).scaled(
			Vector3(BEAM_THICKNESS, length, BEAM_THICKNESS))
	_beam.transform = Transform3D(beam_basis, (start_point + hull) * 0.5)
	_beam.visible = true
	_apply_glow(_beam_material, _beam_fade, BEAM_ALPHA, BEAM_ENERGY)

func _start_ring(burst: bool) -> void:
	if _ring == null or _ring_material == null:
		return
	_ring_duration = RING_BURST_LIFE if burst else RING_LIFE
	_ring_life = _ring_duration
	_ring_from = RING_START_SCALE
	_ring_to = RING_BURST_END_SCALE if burst else RING_END_SCALE
	_ring.visible = true
	_ring.scale = Vector3.ONE * (_ring_from * _size_scale)
	_apply_glow(_ring_material, 1.0, 0.9, 5.0)

func _start_flash(burst: bool) -> void:
	if _flash == null:
		return
	_flash_peak = FLASH_BURST_ENERGY if burst else FLASH_ENERGY
	_flash_life = FLASH_LIFE
	_flash.visible = true
	_flash.light_energy = _flash_peak

func _start_cross() -> void:
	if _cross == null:
		return
	_cross_life = CROSS_LIFE
	_cross.position.y = _top_y
	_cross.visible = true
	_apply_glow(_cross_material, 1.0, 0.95, 6.0)

func _spawn_sparks(count: int) -> void:
	if _dead or not is_inside_tree() or _spark_mesh == null or _spark_ramp == null:
		return
	var sparks := CPUParticles3D.new()
	sparks.name = "RepairSparks"
	sparks.one_shot = true
	sparks.amount = maxi(1, count)
	sparks.lifetime = SPARK_LIFE
	sparks.explosiveness = 1.0
	sparks.direction = Vector3.UP
	sparks.spread = 55.0
	sparks.gravity = Vector3(0.0, 2.5, 0.0)
	sparks.initial_velocity_min = 1.6 * _size_scale
	sparks.initial_velocity_max = 4.2 * _size_scale
	sparks.scale_amount_min = 0.5
	sparks.scale_amount_max = 1.3
	sparks.mesh = _spark_mesh
	sparks.color_ramp = _spark_ramp
	sparks.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	sparks.position = Vector3(0.0, _base_y + 0.1, 0.0)
	add_child(sparks)
	sparks.emitting = true
	# Same cleanup as every other transient particle system in the project
	# (CombatFx / Nature): the SceneTreeTimer outlives a queue_free'd node and
	# drops the connection itself, so a plain bind is enough.
	var timer := get_tree().create_timer(SPARK_LIFE + 0.4)
	timer.timeout.connect(sparks.queue_free)

func _apply_glow(material: StandardMaterial3D, ratio: float, alpha: float,
		energy: float) -> void:
	material.albedo_color = Color(HEAL_COLOR, alpha * ratio)
	material.emission_energy_multiplier = energy * ratio

# Anchor every FX layer to the capsule so the ring sits on the foot plane and
# the cross clears the head, on any chassis (SCARAB 3.0 m .. PRAETOR 5.6 m).
func _measure_host(host: Node3D) -> void:
	var height := 0.0
	var centre_y := 0.0
	for child in host.get_children():
		var shape := child as CollisionShape3D
		if shape == null:
			continue
		var capsule := shape.shape as CapsuleShape3D
		if capsule != null and capsule.height > height:
			height = capsule.height
			centre_y = shape.position.y
	if height <= 0.0:
		height = 3.0
	_size_scale = clampf(height / 3.0, 0.5, 2.0)
	var half := height * 0.5
	_centre_y = centre_y
	_base_y = centre_y - half + 0.12
	_top_y = centre_y + half + 0.5

func _build_nodes() -> void:
	_ring_material = _make_glow_material()
	_ring = MeshInstance3D.new()
	_ring.name = "RepairRing"
	var torus := TorusMesh.new()
	torus.inner_radius = RING_INNER
	torus.outer_radius = RING_OUTER
	torus.rings = RING_MAIN_SEGMENTS
	torus.ring_segments = RING_TUBE_SEGMENTS
	_ring.mesh = torus
	_ring.material_override = _ring_material
	_ring.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	_ring.position = Vector3(0.0, _base_y, 0.0)
	_ring.visible = false
	add_child(_ring)

	_cross_material = _make_glow_material()
	_cross_material.billboard_mode = BaseMaterial3D.BILLBOARD_ENABLED
	_cross = Node3D.new()
	_cross.name = "RepairCross"
	_cross.position = Vector3(0.0, _top_y, 0.0)
	_cross.visible = false
	var bar_h := MeshUtil.make_box(
			Vector3(CROSS_SIZE, CROSS_THICK, CROSS_THICK), _cross_material, "cross_h")
	bar_h.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	var bar_v := MeshUtil.make_box(
			Vector3(CROSS_THICK, CROSS_SIZE, CROSS_THICK), _cross_material, "cross_v")
	bar_v.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	_cross.add_child(bar_h)
	_cross.add_child(bar_v)
	add_child(_cross)

	_flash = OmniLight3D.new()
	_flash.name = "RepairFlash"
	_flash.light_color = HEAL_COLOR
	_flash.omni_range = FLASH_RANGE * _size_scale
	_flash.light_energy = 0.0
	_flash.shadow_enabled = false
	_flash.visible = false
	_flash.position = Vector3(0.0, _centre_y, 0.0)
	add_child(_flash)

	_beam_material = _make_glow_material()
	var beam_mesh := BoxMesh.new()
	beam_mesh.size = Vector3.ONE
	_beam = MeshInstance3D.new()
	_beam.name = "RepairBeam"
	_beam.mesh = beam_mesh
	_beam.material_override = _beam_material
	_beam.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	_beam.visible = false
	add_child(_beam)

	_build_spark_resources()

func _build_spark_resources() -> void:
	var material := StandardMaterial3D.new()
	material.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
	material.albedo_color = Color.WHITE
	material.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
	material.depth_draw_mode = BaseMaterial3D.DEPTH_DRAW_DISABLED
	material.vertex_color_use_as_albedo = true
	_spark_mesh = BoxMesh.new()
	_spark_mesh.size = Vector3(0.05, 0.05, 0.05) * _size_scale
	_spark_mesh.material = material
	_spark_ramp = Gradient.new()
	_spark_ramp.colors = PackedColorArray([
			Color(HEAL_COLOR, 0.0),
			Color(HEAL_COLOR, 0.95),
			Color(HEAL_COLOR, 0.0)])
	_spark_ramp.offsets = PackedFloat32Array([0.0, 0.28, 1.0])

# One material recipe for ring / cross / beam: unshaded, alpha-faded and with
# emission driven per frame (the pattern BeamEffect already proves on the
# mobile renderer - GeometryInstance3D.transparency is Forward+ only here).
func _make_glow_material() -> StandardMaterial3D:
	var material := StandardMaterial3D.new()
	material.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
	material.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
	material.depth_draw_mode = BaseMaterial3D.DEPTH_DRAW_DISABLED
	material.cull_mode = BaseMaterial3D.CULL_DISABLED
	material.albedo_color = Color(HEAL_COLOR, 0.0)
	material.emission_enabled = true
	material.emission = HEAL_COLOR
	material.emission_energy_multiplier = 0.0
	return material
