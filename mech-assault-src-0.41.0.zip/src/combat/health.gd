class_name Health
extends Node

## War Robots style durability:
##  - `defense` is damage mitigation (1.0 = none, 0.5 = half damage, i.e. the
##    same shape as WR Defense Points where 100 DP halves incoming damage).
##  - 40% of every hit becomes HULL (gray) damage that repairs can never undo;
##    the remaining 60% stays repairable, exactly like WR's durability bar.
##  - Optional shield pool on top of the hull (Physical / Ancile / Aegis /
##    Absorber), soaked before hull damage — hit zone is recorded so the
##    damage indicator can colour-code like WR's Damage Report.

signal damaged(amount: float, applied: float, current: float, point: Vector3)
signal died()
signal shield_changed(shield: float, maximum: float, kind: int)
signal shield_broken(kind: int)

enum Zone { HULL = 0, PHYSICAL = 1, ANCILE = 2, AEGIS = 3, ABSORBER = 4 }

const HULL_FRACTION := 0.4
const SHIELD_REGEN_DELAY := 3.0

@export var max_health: float = 100.0
@export var defense: float = 1.0

var current: float = -1.0
var dead: bool = false
var damage_taken: float = 0.0
var hull: float = 0.0
var shield_mult: float = 1.0
var shield: float = 0.0
var shield_max: float = 0.0
var shield_kind: int = Zone.PHYSICAL
var shield_regen: float = 0.0
var last_hit_zone: int = Zone.HULL
var last_hit_total: float = 0.0

var _shield_regen_wait: float = 0.0

func _ready() -> void:
	if current < 0.0:
		current = max_health
	add_to_group("damageable")

func ratio() -> float:
	return clampf(current / maxf(max_health, 0.01), 0.0, 1.0)

# Ceiling healing can ever reach: max durability minus permanent hull damage.
func repairable_max() -> float:
	return maxf(max_health - hull, 0.0)

func hull_ratio() -> float:
	return clampf(hull / maxf(max_health, 0.01), 0.0, 1.0)

func apply_damage(amount: float, point: Vector3 = Vector3.ZERO,
		hull_fraction: float = HULL_FRACTION) -> float:
	if dead or amount <= 0.0:
		return 0.0
	var incoming := amount * maxf(defense, 0.0) * clampf(shield_mult, 0.0, 1.0)
	if incoming <= 0.0:
		return 0.0
	var absorbed := 0.0
	last_hit_zone = Zone.HULL
	if shield > 0.0:
		absorbed = minf(shield, incoming)
		shield -= absorbed
		incoming -= absorbed
		last_hit_zone = shield_kind
		_shield_regen_wait = SHIELD_REGEN_DELAY
		shield_changed.emit(shield, shield_max, shield_kind)
		if shield <= 0.001:
			shield = 0.0
			shield_broken.emit(shield_kind)
	last_hit_total = absorbed + incoming
	damaged.emit(amount, incoming, current, point)
	if incoming <= 0.0:
		return 0.0
	current = maxf(current - incoming, 0.0)
	hull = minf(hull + incoming * clampf(hull_fraction, 0.0, 1.0),
			maxf(max_health - current, 0.0))
	damage_taken += incoming
	if current <= 0.0 and not dead:
		dead = true
		died.emit()
	return incoming

# WR-style shield: kind = Zone.PHYSICAL/ANCILE/AEGIS/ABSORBER.
func configure_shield(kind: int, capacity: float, regen_per_sec: float = 0.0) -> void:
	shield_kind = kind
	shield_max = maxf(capacity, 0.0)
	shield = shield_max
	shield_regen = maxf(regen_per_sec, 0.0)
	_shield_regen_wait = 0.0
	shield_changed.emit(shield, shield_max, shield_kind)

func has_shield() -> bool:
	return shield_max > 0.0

# WR Damage Report colours: grey = physical, blue = Ancile, yellow = Aegis,
# purple = Absorber, white = hull/armor.
static func zone_color(zone: int) -> Color:
	match zone:
		Zone.PHYSICAL:
			return Color(0.78, 0.8, 0.84)
		Zone.ANCILE:
			return Color(0.34, 0.62, 1.0)
		Zone.AEGIS:
			return Color(1.0, 0.85, 0.28)
		Zone.ABSORBER:
			return Color(0.76, 0.4, 1.0)
		_:
			return Color(1.0, 1.0, 1.0)

func shield_ratio() -> float:
	return clampf(shield / maxf(shield_max, 0.01), 0.0, 1.0)

func _physics_process(delta: float) -> void:
	if dead or shield_max <= 0.0 or shield_regen <= 0.0:
		return
	if shield >= shield_max:
		return
	if _shield_regen_wait > 0.0:
		_shield_regen_wait -= delta
		return
	shield = minf(shield + shield_regen * delta, shield_max)
	shield_changed.emit(shield, shield_max, shield_kind)

func heal(amount: float) -> void:
	if dead:
		return
	current = minf(current + amount, repairable_max())

func reset() -> void:
	dead = false
	current = max_health
	damage_taken = 0.0
	hull = 0.0
	shield_mult = 1.0
	shield = shield_max
	_shield_regen_wait = 0.0
	last_hit_zone = Zone.HULL
	last_hit_total = 0.0
