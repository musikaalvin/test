class_name BeamEffect
extends Node3D

## Transient lock-on beam visual (War Robots Lumen feel): an emissive core
## with a wider halo, laid along the fired polyline. When the polyline bends
## around cover it is Chaikin-smoothed first, so the beam snakes around the
## obstacle as one continuous arc instead of kinking into a hard V. Segments
## then sweep outward from the muzzle before the whole strand fades, which
## makes rapid fire read as a lance travelling to the hull.

const LIFE := 0.30
const SEGMENTS := 16
const REVEAL_TIME := 0.07
const SMOOTH_ITERATIONS := 2
const CORE_ALPHA := 0.85
const GLOW_ALPHA := 0.30
const CORE_ENERGY := 7.0
const GLOW_ENERGY := 2.6

var _core_material: StandardMaterial3D
var _glow_material: StandardMaterial3D
var _pieces: Array[MeshInstance3D] = []
var _life_left: float = LIFE
var _revealed: int = 0

static func spawn(parent: Node, points: Array[Vector3], color: Color, radius: float) -> void:
	if parent == null or points.size() < 2:
		return
	var host := parent as Node3D
	if host == null:
		return
	var effect := BeamEffect.new()
	var smoothed := _smooth(points, SMOOTH_ITERATIONS)
	effect._core_material = _make_material(color, CORE_ALPHA, CORE_ENERGY)
	effect._glow_material = _make_material(color, GLOW_ALPHA, GLOW_ENERGY)
	var samples := _resample(smoothed, SEGMENTS)
	host.add_child(effect)
	var core_size := maxf(radius * 2.2, 0.05)
	var glow_size := maxf(core_size * 3.4, 0.16)
	for index in SEGMENTS:
		var from: Vector3 = host.to_local(samples[index])
		var to: Vector3 = host.to_local(samples[index + 1])
		var core := MeshUtil.make_box(Vector3.ONE, effect._core_material, "beam_core")
		core.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
		core.transform = MeshUtil.segment_transform(from, to)
		core.scale = Vector3(core_size, core.scale.y, core_size)
		var glow := MeshUtil.make_box(Vector3.ONE, effect._glow_material, "beam_glow")
		glow.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
		glow.transform = MeshUtil.segment_transform(from, to)
		glow.scale = Vector3(glow_size, glow.scale.y, glow_size)
		effect.add_child(core)
		effect.add_child(glow)
		effect._pieces.append(core)
		effect._pieces.append(glow)
	effect._apply_reveal(0)

static func _make_material(color: Color, alpha: float, energy: float) -> StandardMaterial3D:
	var material := MeshUtil.make_material(Color(color, alpha), 0.0, 0.2, color, energy)
	material.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
	material.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
	return material

## Chaikin corner cutting: turns the origin/bend/target kink produced by the
## cover-curving ray search into a smooth arc. Straight two-point beams are
## returned untouched, and the true muzzle and impact points stay pinned.
static func _smooth(src: Array[Vector3], iterations: int) -> Array[Vector3]:
	var current: Array[Vector3] = []
	current.assign(src)
	if current.size() < 3 or iterations <= 0:
		return current
	var head: Vector3 = current[0]
	var tail: Vector3 = current[current.size() - 1]
	for _iteration in iterations:
		var next: Array[Vector3] = [head]
		for index in range(current.size() - 1):
			var a: Vector3 = current[index]
			var b: Vector3 = current[index + 1]
			next.append(a.lerp(b, 0.25))
			next.append(a.lerp(b, 0.75))
		next.append(tail)
		current = next
	return current

static func _resample(points: Array[Vector3], count: int) -> Array[Vector3]:
	var lengths: Array[float] = [0.0]
	var total := 0.0
	for index in range(1, points.size()):
		total += points[index].distance_to(points[index - 1])
		lengths.append(total)
	var samples: Array[Vector3] = []
	if total < 0.0001:
		for index in count + 1:
			samples.append(points[0])
		return samples
	for index in count + 1:
		var want := total * float(index) / float(count)
		var segment := 1
		while segment < lengths.size() - 1 and lengths[segment] < want:
			segment += 1
		var span := lengths[segment] - lengths[segment - 1]
		var t := 0.0 if span < 0.0001 else (want - lengths[segment - 1]) / span
		samples.append(points[segment - 1].lerp(points[segment], t))
	return samples

func _process(delta: float) -> void:
	_life_left -= delta
	var age := LIFE - _life_left
	_apply_reveal(age / REVEAL_TIME)
	var ratio := clampf(_life_left / LIFE, 0.0, 1.0)
	if _core_material != null:
		_core_material.albedo_color.a = CORE_ALPHA * ratio
		_core_material.emission_energy_multiplier = CORE_ENERGY * ratio
	if _glow_material != null:
		_glow_material.albedo_color.a = GLOW_ALPHA * ratio
		_glow_material.emission_energy_multiplier = GLOW_ENERGY * ratio
	if _life_left <= 0.0:
		queue_free()

## Reveal pairs of core/glow segments outward from the muzzle over
## REVEAL_TIME seconds so the strand reads as travelling, not popping.
func _apply_reveal(progress: float) -> void:
	var want := clampi(int(floor(progress * float(SEGMENTS)) + 1), 0, SEGMENTS) * 2
	if want == _revealed:
		return
	_revealed = want
	for index in _pieces.size():
		_pieces[index].visible = index < want
