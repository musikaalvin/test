class_name WeaponData
extends Resource

# Family → War Robots 12.4 archetype (warrobots.com/en/posts/422, warrobots.wiki)
# with that archetype's real WR range in metres.  Effective range here is
# projectile_speed x projectile_lifetime (beams: beam_range); PYRE plays as a
# short flame cone, drone guns open fire to their drone_fire_range gate.
# Sizes: L/M/H = robot slot, A/B = titan slot.        range = WR metres
#   RAZOR     L/M/H  Punisher AC      500    MAUL       L/M/H  Hammer      350
#   VOLT      L/M/H  Spark arc        600    TORQ       L/M/H  Gauss rail  600
#   BREACH    L/M/H  Pinata rocket    500    FERRIC     L/M/H  Toxin       350
#   LUMEN     L/M/H  lock-on beam     500    PYRE       L/M/H  Ember       350
#   VOLLEY    L/M/H  Labrys salvo     500    ECHO       L/M/H  Havoc       350
#   JUGGERNAUT  A    titan MG         500    DEMOLISHER  A     titan blast 500
#   OVERLORD    A    titan rail       600    VOID         A     titan salvo 500
#   HAVOC       B    titan shotgun    500    ARCLANCE     B     titan arc   500
#   CELERITY    B    titan MG         500    CHASH        B     titan salvo 500
#   built-in: STINGER 350 · ARC NEEDLER 350 · WINDCUTTER 500 · BREACH MORTAR 500
#   drones: EMBERWIND 40 · ARCSTING 80 · CRYOSHARD 90 · SWARMLINE 100 (gates)
#
# v0.35 catalog expansion (War Robots 12.x, manifest + patch notes 414-422):
#   IARAGHI L charge burst         CELSIUS/FAHRENHEIT/KELVIN flame   GLADIUS L/PILUM H
#   HARMATTAN 12-pellet drum       VOONITH/URHAG/SHANTAK wave        ELOX L/MURIX M
#   TOXIN/VENOM/BANE corrosive     RIME/CRYO/GLACIER freeze          ATOMIZER M
#   VELOS/MACHAIRA/BASILEUS acid   HIPPO/KROKO/LIODARI breach        KSIPHOS/LABRYS/CESTUS
#   (v0.39: dropped the invented GLADIUS-H and IARAGHI-M/H sizes, plus the
#    "Ultimate *"/"_12_4" cosmetic duplicates — GT lists them as skins.)
#   titans: BARQ arc · VENIRE/VINCERE rocket · FURNACE/TORCH beam · CHASM salvo ·
#   MUNINN/HUGINN chain · EQUALIZER/ARBITER rocket · VAJRA/MAHA-VAJRA scatter ·
#   STRIKER rail · EVORA/VEYRON sonic · ANGUISHER/RUINER acid (see _catalog)
# Lightning arc family (VOLT / ARCLANCE / ARC NEEDLER) plays like WR's arc and
# chain energy weapons: damage scales with range through arc_distance_mult
# (+137% point-blank, baseline 400 m, -77% at 600 m), an ~8 s unload with a
# short overheat cool-down stands in for WR's magazine/reload, and chain
# shocks leap from the struck enemy to neighbours for half power per hop.

enum Kind {
	AUTOCANNON,
	SCATTERGUN,
	ELECTRIC,
	MAGNETIC,
	BLAST,
	CORROSION,
	BEAM,
	FLAME,
	SALVO,
	SONIC,
}

enum Size {
	LIGHT,
	MEDIUM,
	HEAVY,
	ALPHA,
	BETA,
}

var kind: Kind = Kind.AUTOCANNON
var size: Size = Size.MEDIUM
var family: String = "RAZOR"
var item_id: String = "RAZOR-M"
var display_name: String = "MACHARIA-M RAZOR"
var damage: float = 11000.0
var pellets: int = 1
var shots_per_minute: float = 620.0
var spread_degrees: float = 1.4
var projectile_speed: float = 130.0
var projectile_drop: float = 1.1
var projectile_lifetime: float = 1.4
var heat_per_shot: float = 0.05
var cooldown_rate: float = 0.34
var overheat_lock: float = 0.3
var recoil: float = 0.085
var muzzle_scale: float = 0.5
var tracer_length: float = 1.8
var tracer_radius: float = 0.07
var tracer_color: Color = Color(1.0, 0.74, 0.3)
var shake: float = 0.2
var barrel_length: float = 0.95
var drum_radius: float = 0.14
var slow_factor: float = 1.0
var slow_duration: float = 0.0
var splash_radius: float = 0.0
var corrosion_dps: float = 0.0
var corrosion_duration: float = 0.0
# War Robots-style lock-on beam (LUMEN): hitscan that tracks the locked hull
# and bends around cover, stacking Thermal Breach on the target.
var lock_beam: bool = false
var thermal_breach: bool = false
var breach_per_hit: float = 0.04
var beam_range: float = 180.0
# Fraction of each hit that becomes permanent (grey) damage, WR-style:
# normal weapons 0.4, the sonic family is 1.0 — its damage can never repair.
var hull_fraction: float = 0.4
# Magazine + reload (VOID / CHASH titan guns): magazine 0 = belt-fed, no
# reload. A full reload supercharges the next magazine (damage x mult).
var magazine: int = 0
var reload_time: float = 0.0
var supercharge_damage_mult: float = 1.0
# Reload-phase suppression pulse: while the magazine refills the mount
# pulses this often, damaging and suppressing enemies around the muzzle.
var suppression_radius: float = 0.0
var suppression_duration: float = 0.0
var suppression_pulse: float = 0.0
var suppression_damage: float = 0.0
# Lightning chain (WR chain-energy weapons): after a hit the arc leaps from
# the struck enemy to enemies within chain_range, each hop dealing half the
# curved damage of the previous one. chain_bounces 0 = no chain.
var chain_bounces: int = 0
var chain_range: float = 0.0

# ---------------------------------------------------------------- shot look --
# Every weapon class reads differently on screen in War Robots, and the
# colour of the muzzle bloom is the fastest cue the player has for which gun
# just fired. SHOT_LOOK_KIND owns the class-level shape/timing (what the
# flash physically does); SHOT_LOOK_COLOR keys the individual weapon family so
# two autocannons are not the same brass splash. Families absent from
# SHOT_LOOK_COLOR fall back to their kind's colour.
enum FlashShape { BALL, CONE, NEEDLE, DISC, PUFF }
enum TracerShape { STREAK, ORB, NEEDLE, SHELL }

const SHOT_LOOK_KIND := {
	Kind.AUTOCANNON: {
		"shape": FlashShape.BALL, "color": Color(1.0, 0.87, 0.56),
		"life": 0.05, "stretch": 2.6, "lrange": 5.5, "lenergy": 2.6,
		"trace": TracerShape.STREAK,
	},
	Kind.SCATTERGUN: {
		"shape": FlashShape.PUFF, "color": Color(1.0, 0.76, 0.42),
		"life": 0.07, "stretch": 1.4, "lrange": 6.0, "lenergy": 3.0,
		"trace": TracerShape.STREAK,
	},
	Kind.ELECTRIC: {
		"shape": FlashShape.BALL, "color": Color(0.6, 0.87, 1.0),
		"life": 0.045, "stretch": 1.2, "lrange": 5.0, "lenergy": 3.2,
		"trace": TracerShape.ORB,
	},
	Kind.MAGNETIC: {
		"shape": FlashShape.NEEDLE, "color": Color(0.78, 0.96, 1.0),
		"life": 0.05, "stretch": 3.0, "lrange": 6.5, "lenergy": 3.4,
		"trace": TracerShape.NEEDLE,
	},
	Kind.BLAST: {
		"shape": FlashShape.BALL, "color": Color(1.0, 0.6, 0.28),
		"life": 0.075, "stretch": 1.6, "lrange": 6.5, "lenergy": 3.0,
		"trace": TracerShape.SHELL,
	},
	Kind.CORROSION: {
		"shape": FlashShape.PUFF, "color": Color(0.72, 1.0, 0.45),
		"life": 0.065, "stretch": 1.5, "lrange": 5.0, "lenergy": 2.4,
		"trace": TracerShape.ORB,
	},
	Kind.BEAM: {
		"shape": FlashShape.DISC, "color": Color(0.65, 0.97, 1.0),
		"life": 0.05, "stretch": 1.0, "lrange": 6.0, "lenergy": 3.6,
		"trace": TracerShape.NEEDLE,
	},
	Kind.FLAME: {
		"shape": FlashShape.CONE, "color": Color(1.0, 0.55, 0.2),
		"life": 0.06, "stretch": 2.4, "lrange": 5.5, "lenergy": 2.4,
		"trace": TracerShape.STREAK,
	},
	Kind.SALVO: {
		"shape": FlashShape.BALL, "color": Color(1.0, 0.9, 0.45),
		"life": 0.06, "stretch": 1.8, "lrange": 6.0, "lenergy": 2.8,
		"trace": TracerShape.SHELL,
	},
	Kind.SONIC: {
		"shape": FlashShape.DISC, "color": Color(0.86, 0.8, 1.0),
		"life": 0.1, "stretch": 1.0, "lrange": 5.5, "lenergy": 3.0,
		"trace": TracerShape.ORB,
	},
}

const SHOT_LOOK_COLOR := {
	# kinetic autocannons — brass, steel, amber, orange by barrel mass
	"RAZOR": Color(1.0, 0.87, 0.56),
	"GLADIUS": Color(1.0, 0.93, 0.7),
	"PILUM": Color(1.0, 0.8, 0.45),
	"ATOMIZER": Color(1.0, 0.72, 0.35),
	"JUGGERNAUT": Color(1.0, 0.88, 0.6),
	# scatterguns — orange pump bloom, dust, white-hot titan shells
	"MAUL": Color(1.0, 0.76, 0.42),
	"HARMATTAN": Color(1.0, 0.88, 0.62),
	"VAJRA": Color(1.0, 0.95, 0.8),
	"MAHA-VAJRA": Color(1.0, 0.95, 0.8),
	"HAVOC": Color(1.0, 0.8, 0.5),
	# electric arcs — pale blue through cyan
	"VOLT": Color(0.6, 0.87, 1.0),
	"ARCLANCE": Color(0.75, 0.95, 1.0),
	"ARCSTING": Color(0.55, 0.8, 1.0),
	"BARQ": Color(0.5, 0.9, 1.0),
	"MUNINN": Color(0.65, 0.9, 1.0),
	"HUGINN": Color(0.65, 0.9, 1.0),
	"CELERITY": Color(0.7, 0.93, 1.0),
	# magnetic rails — white-cyan, mint, pale ice
	"TORQ": Color(0.78, 0.96, 1.0),
	"IARAGHI": Color(0.7, 0.98, 0.95),
	"VOONITH": Color(0.6, 0.95, 1.0),
	"URHAG": Color(0.68, 0.9, 1.0),
	"SHANTAK": Color(0.75, 1.0, 0.92),
	"STRIKER": Color(0.62, 0.98, 1.0),
	"OVERLORD": Color(0.85, 0.97, 1.0),
	# rockets and launchers — orange fireball through amber
	"BREACH": Color(1.0, 0.6, 0.28),
	"KSIPHOS": Color(1.0, 0.85, 0.4),
	"LABRYS": Color(1.0, 0.85, 0.4),
	"CESTUS": Color(1.0, 0.85, 0.4),
	"VENIRE": Color(1.0, 0.72, 0.3),
	"VINCERE": Color(1.0, 0.72, 0.3),
	"EQUALIZER": Color(1.0, 0.66, 0.34),
	"ARBITER": Color(1.0, 0.66, 0.34),
	"DEMOLISHER": Color(1.0, 0.68, 0.32),
	# corrosive sprays — acid greens, olive, yellow-green
	"FERRIC": Color(0.8, 1.0, 0.4),
	"TOXIN": Color(0.6, 1.0, 0.35),
	"VENOM": Color(0.7, 1.0, 0.3),
	"BANE": Color(0.55, 1.0, 0.42),
	"VELOS": Color(0.72, 1.0, 0.5),
	"MACHAIRA": Color(0.72, 1.0, 0.5),
	"BASILEUS": Color(0.72, 1.0, 0.5),
	"HIPPO": Color(0.65, 1.0, 0.38),
	"KROKO": Color(0.65, 1.0, 0.38),
	"LIODARI": Color(0.65, 1.0, 0.38),
	"ELOX": Color(0.78, 1.0, 0.45),
	"MURIX": Color(0.78, 1.0, 0.45),
	"ANGUISHER": Color(0.6, 0.95, 0.32),
	"RUINER": Color(0.6, 0.95, 0.32),
	# beams — white-cyan lance, orange furnace
	"LUMEN": Color(0.65, 0.97, 1.0),
	"FURNACE": Color(1.0, 0.78, 0.4),
	"TORCH": Color(1.0, 0.78, 0.4),
	# flamers — deep orange tongue
	"PYRE": Color(1.0, 0.55, 0.2),
	"CELSIUS": Color(1.0, 0.62, 0.24),
	"FAHRENHEIT": Color(1.0, 0.62, 0.24),
	"KELVIN": Color(1.0, 0.62, 0.24),
	# launchers / salvos — yellow-white pop
	"VOLLEY": Color(1.0, 0.9, 0.45),
	# sonic — violet pressure rings
	"ECHO": Color(0.86, 0.8, 1.0),
	"EVORA": Color(0.78, 0.7, 1.0),
	"VEYRON": Color(0.78, 0.7, 1.0),
	# freeze rounds ride the autocannon kind but must read icy, not brass
	"RIME": Color(0.72, 0.95, 1.0),
	"CRYO": Color(0.72, 0.95, 1.0),
	"GLACIER": Color(0.72, 0.95, 1.0),
	# void chasm titan guns — violet singularity cores
	"VOID": Color(0.72, 0.5, 1.0),
	"CHASH": Color(0.72, 0.5, 1.0),
	"CHASM": Color(0.72, 0.5, 1.0),
}

# Rare shape/timing overrides where the class default would read wrong.
const SHOT_LOOK_EXTRA := {
	"RIME": {"shape": FlashShape.BALL, "trace": TracerShape.ORB, "life": 0.06},
	"CRYO": {"shape": FlashShape.BALL, "trace": TracerShape.ORB, "life": 0.06},
	"GLACIER": {"shape": FlashShape.BALL, "trace": TracerShape.ORB, "life": 0.06},
	"VOID": {"shape": FlashShape.BALL, "trace": TracerShape.ORB, "life": 0.07,
			"lrange": 7.0, "lenergy": 3.4},
	"CHASH": {"shape": FlashShape.BALL, "trace": TracerShape.ORB, "life": 0.07,
			"lrange": 7.0, "lenergy": 3.4},
	"CHASM": {"shape": FlashShape.BALL, "trace": TracerShape.ORB, "life": 0.07,
			"lrange": 7.0, "lenergy": 3.4},
	"JUGGERNAUT": {"life": 0.07, "lrange": 7.0, "lenergy": 3.2},
	"DEMOLISHER": {"life": 0.08, "lrange": 7.0, "lenergy": 3.2},
	"OVERLORD": {"life": 0.06, "lrange": 7.0, "lenergy": 3.4},
	"LUMEN": {"shape": FlashShape.DISC, "trace": TracerShape.NEEDLE, "life": 0.04},
	"EVORA": {"shape": FlashShape.DISC, "trace": TracerShape.ORB, "life": 0.12},
	"VEYRON": {"shape": FlashShape.DISC, "trace": TracerShape.ORB, "life": 0.12},
}

# Merged appearance of one weapon's muzzle flash + tracer. Pure lookup, no
# allocation of WeaponData — weapon_mount calls this once from setup().
static func shot_look(family: String, kind: int) -> Dictionary:
	var look: Dictionary = SHOT_LOOK_KIND.get(kind,
			SHOT_LOOK_KIND[Kind.AUTOCANNON]) as Dictionary
	var color: Color = look["color"] as Color
	if SHOT_LOOK_COLOR.has(family):
		color = SHOT_LOOK_COLOR[family] as Color
	var merged := {
		"shape": look["shape"] as int,
		"color": color,
		"life": look["life"] as float,
		"stretch": look["stretch"] as float,
		"lrange": look["lrange"] as float,
		"lenergy": look["lenergy"] as float,
		"trace": look["trace"] as int,
	}
	if SHOT_LOOK_EXTRA.has(family):
		merged.merge(SHOT_LOOK_EXTRA[family] as Dictionary, true)
	return merged

# Tracer silhouette for a projectile: streak box, glowing orb, rail needle or
# fat launcher shell. weapon/projectile use this so rounds differ mid-flight.
static func tracer_shape_for(family: String, kind: int) -> int:
	return shot_look(family, kind)["trace"] as int

func shot_interval() -> float:
	return 60.0 / maxf(shots_per_minute, 1.0)

static func size_from_suffix(suffix: String) -> Size:
	match suffix:
		"L": return Size.LIGHT
		"H": return Size.HEAVY
		"A": return Size.ALPHA
		"B": return Size.BETA
	return Size.MEDIUM

# Multi-token catalog ids (MAHA-VAJRA-B, ANGUISHER-A, TOXIN-L, ...): the size
# is the trailing L/M/H/A/B token; the family is everything else. Removed ids
# (the invented GLADIUS-H / IARAGHI-M/H sizes, the "Ultimate *" and "*_12_4"
# cosmetic duplicates) are folded into the surviving ladder member by
# GameState.REMOVED_ITEM_IDS before anything parses them.
const ITEM_SIZE_TOKENS: Array[String] = ["L", "M", "H", "A", "B"]

static func item_family_of(id: String) -> String:
	var parts := id.split("-")
	if parts.size() > 1 and ITEM_SIZE_TOKENS.has(parts[parts.size() - 1]):
		parts.resize(parts.size() - 1)
		return "-".join(parts)
	return id

static func item_size_of(id: String) -> Size:
	return size_from_suffix(id.get_slice("-", id.get_slice_count("-") - 1))

# War Robots lightning-arc damage-by-distance table (Spark/Scourge/Calamity,
# measured on flat terrain): range in metres -> multiplier over the base
# damage (taken at the 400 m baseline). Interpolated linearly, clamped.
const ARC_DAMAGE_METRES: Array[float] = [
	50.0, 100.0, 150.0, 200.0, 250.0, 300.0, 350.0, 400.0, 450.0, 500.0, 550.0, 600.0,
]
const ARC_DAMAGE_MULTS: Array[float] = [
	2.37, 2.22, 1.83, 1.71, 1.60, 1.34, 1.11, 1.00, 0.77, 0.60, 0.40, 0.23,
]

static func arc_distance_mult(dist: float) -> float:
	if dist <= ARC_DAMAGE_METRES[0]:
		return ARC_DAMAGE_MULTS[0]
	var last := ARC_DAMAGE_METRES.size() - 1
	if dist >= ARC_DAMAGE_METRES[last]:
		return ARC_DAMAGE_MULTS[last]
	for index in range(1, ARC_DAMAGE_METRES.size()):
		if dist <= ARC_DAMAGE_METRES[index]:
			var prev_m := ARC_DAMAGE_METRES[index - 1]
			var next_m := ARC_DAMAGE_METRES[index]
			var t := (dist - prev_m) / (next_m - prev_m)
			return lerpf(ARC_DAMAGE_MULTS[index - 1], ARC_DAMAGE_MULTS[index], t)
	return 1.0

static func autocannon() -> WeaponData:
	return _razor(Size.MEDIUM)

static func scattergun() -> WeaponData:
	return _maul(Size.MEDIUM)

static func _builtin_windcutter() -> WeaponData:
	var data := WeaponData.new()
	data.kind = Kind.AUTOCANNON
	data.size = Size.MEDIUM
	data.family = "BUILTIN"
	data.item_id = "BUILTIN-WINDCUTTER"
	data.display_name = "WINDCUTTER"
	data.damage = 950.0
	data.shots_per_minute = 660.0
	data.spread_degrees = 1.4
	data.projectile_speed = 300.0
	data.projectile_drop = 0.015
	data.projectile_lifetime = 1.67
	data.heat_per_shot = 0.1
	data.cooldown_rate = 0.38
	data.recoil = 0.06
	data.shake = 0.1
	data.muzzle_scale = 0.4
	data.barrel_length = 0.9
	data.drum_radius = 0.12
	data.tracer_length = 3.0
	data.tracer_radius = 0.05
	data.tracer_color = Color(0.5, 1.0, 0.8)
	return data

static func builtin_for_robot(robot_id: StringName) -> WeaponData:
	if robot_id == &"VORTEX":
		return _builtin_needler()
	if robot_id == &"RAMPART":
		return _builtin_windcutter()
	return _builtin_stinger()

static func _builtin_stinger() -> WeaponData:
	var data := WeaponData.new()
	data.kind = Kind.BEAM
	data.size = Size.MEDIUM
	data.family = "BUILTIN"
	data.item_id = "BUILTIN-STINGER"
	data.display_name = "STINGER LANCE"
	data.damage = 2600.0
	data.shots_per_minute = 300.0
	data.spread_degrees = 0.4
	data.projectile_speed = 300.0
	data.projectile_drop = 0.0
	data.projectile_lifetime = 1.17
	data.beam_range = 350.0
	data.heat_per_shot = 0.03
	data.cooldown_rate = 0.4
	data.recoil = 0.05
	data.shake = 0.12
	data.muzzle_scale = 0.4
	data.barrel_length = 0.8
	data.drum_radius = 0.1
	data.tracer_length = 2.6
	data.tracer_radius = 0.06
	data.tracer_color = Color(0.4, 0.95, 1.0)
	return data

static func _builtin_needler() -> WeaponData:
	var data := WeaponData.new()
	data.kind = Kind.ELECTRIC
	data.size = Size.MEDIUM
	data.family = "BUILTIN"
	data.item_id = "BUILTIN-NEEDLER"
	data.display_name = "ARC NEEDLER"
	data.damage = 1400.0
	data.shots_per_minute = 460.0
	data.spread_degrees = 2.0
	data.projectile_speed = 300.0
	data.projectile_drop = 0.5
	data.projectile_lifetime = 1.17
	data.heat_per_shot = 0.032
	data.cooldown_rate = 0.4
	data.recoil = 0.05
	data.shake = 0.14
	data.muzzle_scale = 0.42
	data.barrel_length = 0.75
	data.drum_radius = 0.11
	data.tracer_length = 2.0
	data.tracer_radius = 0.06
	data.tracer_color = Color(0.55, 0.85, 1.0)
	data.chain_bounces = 2
	data.chain_range = 50.0
	return data

static func _builtin_mortar() -> WeaponData:
	var data := WeaponData.new()
	data.kind = Kind.BLAST
	data.size = Size.HEAVY
	data.family = "BUILTIN"
	data.item_id = "BUILTIN-MORTAR"
	data.display_name = "BREACH MORTAR"
	data.damage = 6500.0
	data.shots_per_minute = 72.0
	data.spread_degrees = 1.0
	data.projectile_speed = 200.0
	data.projectile_drop = 4.0
	data.projectile_lifetime = 2.5
	data.heat_per_shot = 0.1
	data.cooldown_rate = 0.3
	data.recoil = 0.16
	data.shake = 0.42
	data.muzzle_scale = 0.62
	data.barrel_length = 1.1
	data.drum_radius = 0.17
	data.splash_radius = 3.2
	data.tracer_length = 1.6
	data.tracer_radius = 0.1
	data.tracer_color = Color(1.0, 0.66, 0.3)
	return data

# ECHO — sonic cannon family (original design shaped by War Robots' sonic
# shotguns Scatter/Havoc/Devastator): multi-pellet shockwave on a ~0.5 s cycle
# whose damage is 100% permanent (grey), with WR's 1 : 1.5 : 2.19 ladder.
static func _echo(size: Size) -> WeaponData:
	var data := WeaponData.new()
	data.kind = Kind.SONIC
	data.family = "ECHO"
	data.size = size
	match size:
		Size.LIGHT:
			data.damage = 850.0
			data.pellets = 6
			data.shots_per_minute = 120.0
			data.spread_degrees = 9.0
			data.barrel_length = 0.52
			data.drum_radius = 0.14
			data.recoil = 0.15
			data.shake = 0.42
			data.muzzle_scale = 0.78
			data.heat_per_shot = 0.11
		Size.HEAVY:
			data.damage = 1220.0
			data.pellets = 11
			data.shots_per_minute = 100.0
			data.spread_degrees = 7.2
			data.barrel_length = 0.84
			data.drum_radius = 0.25
			data.recoil = 0.25
			data.shake = 0.85
			data.muzzle_scale = 1.12
			data.heat_per_shot = 0.17
		_:
			data.damage = 1040.0
			data.pellets = 8
			data.shots_per_minute = 110.0
			data.spread_degrees = 8.0
			data.barrel_length = 0.68
			data.drum_radius = 0.2
			data.recoil = 0.21
			data.shake = 0.66
			data.muzzle_scale = 0.96
			data.heat_per_shot = 0.14
	data.hull_fraction = 1.0
	data.projectile_speed = 300.0
	data.projectile_drop = 1.5
	data.projectile_lifetime = 1.17
	data.cooldown_rate = 0.36
	data.tracer_length = 1.2
	data.tracer_radius = 0.1
	data.tracer_color = Color(0.82, 0.95, 1.0)
	return data

# VOID — War Robots-style Alpha titan cannon: a gravitic shard launcher with
# an 8-round magazine, 7 s reload, post-reload supercharge, splash core and a
# suppression pulse that beats on nearby enemies while the magazine refills.
static func _void(size: Size) -> WeaponData:
	var data := WeaponData.new()
	data.kind = Kind.SALVO
	data.size = size
	data.family = "VOID"
	data.item_id = "VOID-A"
	data.display_name = "VOID"
	data.damage = 13000.0
	data.pellets = 3
	data.shots_per_minute = 75.0
	data.spread_degrees = 2.6
	data.projectile_speed = 200.0
	data.projectile_drop = 1.2
	data.projectile_lifetime = 2.5
	data.heat_per_shot = 0.12
	data.cooldown_rate = 0.34
	data.recoil = 0.3
	data.shake = 0.9
	data.muzzle_scale = 0.85
	data.barrel_length = 1.4
	data.drum_radius = 0.26
	data.splash_radius = 4.0
	data.magazine = 8
	data.reload_time = 7.0
	data.supercharge_damage_mult = 1.2
	data.suppression_radius = 40.0
	data.suppression_duration = 3.0
	data.suppression_pulse = 0.6
	data.suppression_damage = 1300.0
	data.tracer_length = 2.6
	data.tracer_radius = 0.12
	data.tracer_color = Color(0.68, 0.5, 1.0)
	return data

# CHASH — the Beta sibling: faster, tighter two-shard volley, same magazine,
# reload, supercharge and suppression core.
static func _chash(size: Size) -> WeaponData:
	var data := WeaponData.new()
	data.kind = Kind.SALVO
	data.size = size
	data.family = "CHASH"
	data.item_id = "CHASH-B"
	data.display_name = "CHASH"
	data.damage = 13000.0
	data.pellets = 2
	data.shots_per_minute = 75.0
	data.spread_degrees = 1.8
	data.projectile_speed = 300.0
	data.projectile_drop = 0.8
	data.projectile_lifetime = 1.67
	data.heat_per_shot = 0.1
	data.cooldown_rate = 0.36
	data.recoil = 0.24
	data.shake = 0.7
	data.muzzle_scale = 0.78
	data.barrel_length = 1.2
	data.drum_radius = 0.22
	data.splash_radius = 3.4
	data.magazine = 8
	data.reload_time = 7.0
	data.supercharge_damage_mult = 1.2
	data.suppression_radius = 30.0
	data.suppression_duration = 3.0
	data.suppression_pulse = 0.6
	data.suppression_damage = 1300.0
	data.tracer_length = 2.4
	data.tracer_radius = 0.11
	data.tracer_color = Color(0.62, 0.46, 1.0)
	return data

static func for_item(id: String) -> WeaponData:
	var family_name := item_family_of(id)
	var size := item_size_of(id)
	var data: WeaponData
	match family_name:
		"MAUL":
			data = _maul(size)
		"VOLT":
			data = _volt(size)
		"TORQ":
			data = _torq(size)
		"BREACH":
			data = _breach(size)
		"FERRIC":
			data = _ferric(size)
		"LUMEN":
			data = _lumen(size)
		"PYRE":
			data = _pyre(size)
		"VOLLEY":
			data = _volley(size)
		"ECHO":
			data = _echo(size)
		"VOID":
			data = _void(size)
		"CHASH", "CHASM":
			data = _chash(size)
		"JUGGERNAUT":
			data = _juggernaut(size)
		"DEMOLISHER":
			data = _demolisher(size)
		"OVERLORD":
			data = _overlord(size)
		"HAVOC":
			data = _havoc(size)
		"ARCLANCE":
			data = _arclance(size)
		"CELERITY":
			data = _celerity(size)
		_:
			var entry := _catalog().get(family_name, {}) as Dictionary
			if entry.is_empty():
				data = _razor(size)
			else:
				data = _catalog_weapon(family_name, size, entry)
	data.family = family_name
	data.item_id = id
	data.display_name = id
	return data

# ---------------------------------------------------------------------------
# v0.35 War Robots 12.x catalog (manifest data/mech_assault_reference_12_4.json
# + official patch notes 414/416/417/418/422 + warrobots.wiki stat tables).
# "dmg" is PER PELLET keyed by size token (L/M/H/A/B); volley = dmg x pellets.
# Per-pellet values sit inside the smoke WR bands (L<=7000, M<=12000,
# H<=32000, >=300); where raw WR figures exceed those envelopes the entry
# comment records the compression. rpm / mag+reload / corro [dps, s] /
# slow [factor, s] / chain [hops, m] mirror the published WR numbers.
static var _wr_catalog: Dictionary = {}

static func _catalog() -> Dictionary:
	if not _wr_catalog.is_empty():
		return _wr_catalog
	# RIME / CRYO / GLACIER share the WR freeze-rocket profile (12.4: 1250/
	# 1900/2400 per rocket, 700 rpm, splash + freeze slow 0.5 x 2.0 s).
	var freeze := {
		"kind": "blast", "rpm": 700.0, "pellets": 1, "spread": 2.2,
		"spd": 150.0, "drop": 2.0, "range_m": 350.0,
		"mag": 35, "reload": 0.3, "splash": 2.4, "slow": [0.5, 2.0],
		"tracer": Color(0.6, 0.85, 1.0),
		"dmg": {"L": 1250.0, "M": 1900.0, "H": 2400.0},
	}
	_wr_catalog = {
		# --- robot energy / kinetic -----------------------------------------
		"IARAGHI": {
			"kind": "magnetic", "rpm": 60.0, "pellets": 6, "spread": 3.5,
			"spd": 400.0, "drop": 0.2, "range_m": 600.0, "mag": 6, "reload": 10.0,
			"tracer": Color(0.72, 0.95, 1.0),
			# WR charged volley 45000 split over 6 particles (7500/pellet);
			# clamped to the 7000 per-pellet band ceiling. Light only.
			"dmg": {"L": 7000.0},
		},
		"HARMATTAN": {
			"kind": "scattergun", "rpm": 240.0, "pellets": 12, "spread": 9.0,
			"spd": 260.0, "drop": 0.9, "range_m": 350.0, "mag": 12, "reload": 7.0,
			"tracer": Color(1.0, 0.85, 0.55),
			# WR 250/450/650 x1.2 to clear the 300 per-pellet floor.
			"dmg": {"L": 300.0, "M": 540.0, "H": 780.0},
		},
		"CELSIUS": {
			"kind": "flame", "rpm": 857.0, "spread": 10.0, "spd": 90.0,
			"drop": 0.0, "range_m": 300.0, "corro": [280.0, 2.0],
			"tracer": Color(1.0, 0.62, 0.3), "dmg": {"L": 1350.0},
		},
		"FAHRENHEIT": {
			"kind": "flame", "rpm": 857.0, "spread": 10.0, "spd": 90.0,
			"drop": 0.0, "range_m": 300.0, "corro": [280.0, 2.0],
			"tracer": Color(1.0, 0.62, 0.3), "dmg": {"M": 2000.0},
		},
		"KELVIN": {
			"kind": "flame", "rpm": 857.0, "spread": 10.0, "spd": 90.0,
			"drop": 0.0, "range_m": 300.0, "corro": [280.0, 2.0],
			"tracer": Color(1.0, 0.62, 0.3), "dmg": {"H": 2650.0},
		},
		"VOONITH": {
			"kind": "magnetic", "rpm": 71.0, "pellets": 25, "spread": 4.0,
			"spd": 500.0, "drop": 0.05, "range_m": 1100.0, "mag": 12, "reload": 3.0,
			"tracer": Color(0.85, 0.8, 1.0),
			# WR wave volley totals 7500/12375/16500 split over 25 particles.
			"dmg": {"L": 300.0},
		},
		"URHAG": {
			"kind": "magnetic", "rpm": 71.0, "pellets": 25, "spread": 4.0,
			"spd": 500.0, "drop": 0.05, "range_m": 1100.0, "mag": 12, "reload": 3.0,
			"tracer": Color(0.85, 0.8, 1.0), "dmg": {"M": 495.0},
		},
		"SHANTAK": {
			"kind": "magnetic", "rpm": 71.0, "pellets": 25, "spread": 4.0,
			"spd": 500.0, "drop": 0.05, "range_m": 1100.0, "mag": 12, "reload": 3.0,
			"tracer": Color(0.85, 0.8, 1.0), "dmg": {"H": 660.0},
		},
		"ATOMIZER": {
			"kind": "autocannon", "rpm": 75.0, "spread": 1.6, "spd": 500.0,
			"drop": 0.1, "range_m": 500.0, "heat_bias": 0.5,
			"tracer": Color(0.8, 0.9, 1.0), "dmg": {"M": 2380.0},
		},
		"GLADIUS": {
			"kind": "autocannon", "rpm": 545.0, "spread": 1.0, "spd": 480.0,
			"drop": 0.15, "range_m": 600.0, "heat_bias": 1.0,
			"tracer": Color(0.7, 0.9, 1.0), "dmg": {"L": 5000.0},
		},
		"PILUM": {
			"kind": "autocannon", "rpm": 545.0, "spread": 1.0, "spd": 480.0,
			"drop": 0.15, "range_m": 600.0, "heat_bias": 1.0,
			"tracer": Color(0.7, 0.9, 1.0), "dmg": {"H": 10000.0},
		},
		"RIME": freeze,
		"CRYO": freeze,
		"GLACIER": freeze,
		"VELOS": {
			"kind": "corrosion", "rpm": 700.0, "spread": 3.0, "spd": 300.0,
			"drop": 0.5, "range_m": 350.0, "mag": 100, "reload": 5.0,
			"corro": [400.0, 3.0], "tracer": Color(0.7, 1.0, 0.5),
			"dmg": {"L": 350.0, "M": 350.0, "H": 800.0},
		},
		"MACHAIRA": {
			"kind": "corrosion", "rpm": 700.0, "spread": 3.0, "spd": 300.0,
			"drop": 0.5, "range_m": 350.0, "mag": 100, "reload": 5.0,
			"corro": [400.0, 3.0], "tracer": Color(0.7, 1.0, 0.5),
			"dmg": {"M": 350.0},
		},
		"BASILEUS": {
			"kind": "corrosion", "rpm": 700.0, "spread": 3.0, "spd": 300.0,
			"drop": 0.5, "range_m": 350.0, "mag": 100, "reload": 5.0,
			"corro": [400.0, 3.0], "tracer": Color(0.7, 1.0, 0.5),
			"dmg": {"H": 800.0},
		},
		# WR breach rockets (wiki 27500/36600/55000 volley) compressed /4 to
		# per-pellet values inside the LIGHT/MEDIUM bands.
		"HIPPO": {
			"kind": "corrosion", "rpm": 200.0, "spread": 1.8, "spd": 320.0,
			"drop": 0.4, "range_m": 350.0, "corro": [300.0, 2.5],
			"heat_bias": 1.0, "tracer": Color(0.75, 1.0, 0.5),
			"dmg": {"L": 6875.0},
		},
		"KROKO": {
			"kind": "corrosion", "rpm": 200.0, "spread": 1.8, "spd": 320.0,
			"drop": 0.4, "range_m": 350.0, "corro": [300.0, 2.5],
			"heat_bias": 1.0, "tracer": Color(0.75, 1.0, 0.5),
			"dmg": {"M": 9150.0},
		},
		"LIODARI": {
			"kind": "corrosion", "rpm": 200.0, "spread": 1.8, "spd": 320.0,
			"drop": 0.4, "range_m": 350.0, "corro": [300.0, 2.5],
			"heat_bias": 1.0, "tracer": Color(0.75, 1.0, 0.5),
			"dmg": {"H": 13750.0},
		},
		"ELOX": {
			"kind": "corrosion", "rpm": 162.0, "pellets": 10, "spread": 4.0,
			"spd": 300.0, "drop": 0.4, "range_m": 350.0,
			"corro": [400.0, 4.0], "heat_bias": 1.0,
			"tracer": Color(0.6, 1.0, 0.55),
			# 10-pellet volley totals 14000 like the WR burst.
			"dmg": {"L": 1400.0},
		},
		"MURIX": {
			"kind": "corrosion", "rpm": 162.0, "pellets": 20, "spread": 4.0,
			"spd": 300.0, "drop": 0.4, "range_m": 350.0,
			"corro": [550.0, 4.0], "heat_bias": 1.0,
			"tracer": Color(0.6, 1.0, 0.55), "dmg": {"M": 700.0},
		},
		"KSIPHOS": {
			"kind": "blast", "rpm": 500.0, "spread": 2.0, "spd": 130.0,
			"drop": 2.6, "range_m": 500.0, "mag": 25, "reload": 5.0, "splash": 5.0,
			"tracer": Color(1.0, 0.72, 0.4),
			"dmg": {"L": 1832.0},
		},
		"LABRYS": {
			"kind": "blast", "rpm": 500.0, "spread": 2.0, "spd": 130.0,
			"drop": 2.6, "range_m": 500.0, "mag": 25, "reload": 5.0, "splash": 5.0,
			"tracer": Color(1.0, 0.72, 0.4), "dmg": {"M": 2346.0},
		},
		"CESTUS": {
			"kind": "blast", "rpm": 500.0, "spread": 2.0, "spd": 130.0,
			"drop": 2.6, "range_m": 500.0, "mag": 25, "reload": 5.0, "splash": 5.0,
			"tracer": Color(1.0, 0.72, 0.4), "dmg": {"H": 3911.0},
		},
		"TOXIN": {
			"kind": "corrosion", "rpm": 700.0, "spread": 5.0, "spd": 140.0,
			"drop": 0.8, "range_m": 300.0, "mag": 120, "reload": 3.0,
			"corro": [90.0, 6.0], "tracer": Color(0.65, 1.0, 0.5),
			# WR 90/135/200 per liter compressed up to clear the 300 floor.
			"dmg": {"L": 310.0},
		},
		"VENOM": {
			"kind": "corrosion", "rpm": 700.0, "spread": 5.0, "spd": 140.0,
			"drop": 0.8, "range_m": 300.0, "mag": 120, "reload": 3.0,
			"corro": [135.0, 6.0], "tracer": Color(0.65, 1.0, 0.5),
			"dmg": {"M": 465.0},
		},
		"BANE": {
			"kind": "corrosion", "rpm": 700.0, "spread": 5.0, "spd": 140.0,
			"drop": 0.8, "range_m": 300.0, "mag": 120, "reload": 3.0,
			"corro": [200.0, 6.0], "tracer": Color(0.65, 1.0, 0.5),
			"dmg": {"H": 640.0},
		},
		# --- titan weapons ----------------------------------------------------
		"BARQ": {
			"kind": "electric", "rpm": 600.0, "pellets": 5, "spread": 7.0,
			"spd": 300.0, "drop": 0.2, "range_m": 200.0, "mag": 100, "reload": 7.0,
			"slow": [0.6, 1.5], "tracer": Color(0.55, 0.9, 1.0),
			"dmg": {"A": 720.0, "B": 480.0},
		},
		"VENIRE": {
			"kind": "blast", "rpm": 300.0, "spread": 2.5, "spd": 200.0,
			"drop": 1.5, "range_m": 600.0, "splash": 3.5, "heat_bias": 1.0,
			"tracer": Color(1.0, 0.66, 0.3), "dmg": {"A": 2250.0},
		},
		"VINCERE": {
			"kind": "blast", "rpm": 300.0, "spread": 2.5, "spd": 200.0,
			"drop": 1.5, "range_m": 600.0, "splash": 3.5, "heat_bias": 1.0,
			"tracer": Color(1.0, 0.66, 0.3), "dmg": {"B": 1925.0},
		},
		"FURNACE": {
			"kind": "beam", "rpm": 600.0, "spread": 1.0, "spd": 600.0,
			"drop": 0.0, "range_m": 800.0, "mag": 80, "reload": 9.0,
			"beam": true, "breach": true, "breach_per_hit": 0.15,
			"tracer": Color(1.0, 0.7, 0.35), "dmg": {"A": 1925.0},
		},
		"TORCH": {
			"kind": "beam", "rpm": 600.0, "spread": 1.0, "spd": 600.0,
			"drop": 0.0, "range_m": 800.0, "mag": 80, "reload": 9.0,
			"beam": true, "breach": true, "breach_per_hit": 0.15,
			"tracer": Color(1.0, 0.7, 0.35), "dmg": {"B": 1540.0},
		},
		"MUNINN": {
			"kind": "electric", "rpm": 600.0, "spread": 1.6, "spd": 420.0,
			"drop": 0.1, "range_m": 600.0, "chain": [3, 60.0], "heat_bias": 1.0,
			"tracer": Color(0.6, 0.8, 1.0), "dmg": {"A": 2570.0},
		},
		"HUGINN": {
			"kind": "electric", "rpm": 600.0, "spread": 1.6, "spd": 420.0,
			"drop": 0.1, "range_m": 600.0, "chain": [3, 60.0], "heat_bias": 1.0,
			"tracer": Color(0.6, 0.8, 1.0), "dmg": {"B": 1950.0},
		},
		"EQUALIZER": {
			"kind": "blast", "rpm": 300.0, "spread": 2.2, "spd": 260.0,
			"drop": 1.2, "range_m": 600.0, "splash": 4.0, "heat_bias": 0.6,
			"tracer": Color(1.0, 0.6, 0.35), "dmg": {"A": 3650.0},
		},
		"ARBITER": {
			"kind": "blast", "rpm": 300.0, "spread": 2.2, "spd": 260.0,
			"drop": 1.2, "range_m": 600.0, "splash": 4.0, "heat_bias": 0.6,
			"tracer": Color(1.0, 0.6, 0.35), "dmg": {"B": 2100.0},
		},
		"VAJRA": {
			"kind": "scattergun", "rpm": 300.0, "pellets": 8, "spread": 9.0,
			"spd": 300.0, "drop": 0.4, "range_m": 350.0, "heat_bias": 1.0,
			"tracer": Color(0.7, 0.9, 1.0),
			# WR volley 2980 split over 8 pellets.
			"dmg": {"A": 373.0},
		},
		"MAHA-VAJRA": {
			"kind": "scattergun", "rpm": 300.0, "pellets": 8, "spread": 9.0,
			"spd": 300.0, "drop": 0.4, "range_m": 350.0, "heat_bias": 1.0,
			"tracer": Color(0.7, 0.9, 1.0), "dmg": {"B": 373.0},
		},
		"STRIKER": {
			"kind": "magnetic", "rpm": 75.0, "spread": 0.5, "spd": 600.0,
			"drop": 0.05, "range_m": 1100.0, "mag": 8, "reload": 8.0,
			"tracer": Color(0.8, 0.7, 1.0), "dmg": {"A": 3480.0},
		},
		"EVORA": {
			"kind": "sonic", "rpm": 300.0, "pellets": 2, "spread": 2.5,
			"spd": 350.0, "drop": 0.3, "range_m": 250.0, "hull": 1.0,
			"heat_bias": 1.0, "tracer": Color(0.78, 0.95, 1.0),
			# WR unload 10s; rpm kept at the WR fire cadence (not 0.07 s).
			"dmg": {"A": 1720.0},
		},
		"VEYRON": {
			"kind": "sonic", "rpm": 300.0, "pellets": 2, "spread": 2.5,
			"spd": 350.0, "drop": 0.3, "range_m": 250.0, "hull": 1.0,
			"heat_bias": 1.0, "tracer": Color(0.78, 0.95, 1.0),
			"dmg": {"B": 1570.0},
		},
		# wiki volley 52050/34700 compressed x0.5 (dps envelope + 0.07s/shot
		# cadence would otherwise multiply it); 12 pellets keep the shotgun feel.
		"ANGUISHER": {
			"kind": "corrosion", "rpm": 60.0, "pellets": 12, "spread": 7.0,
			"spd": 260.0, "drop": 0.5, "range_m": 600.0, "mag": 6, "reload": 5.0,
			"corro": [920.0, 5.0], "tracer": Color(0.7, 1.0, 0.55),
			"dmg": {"A": 2170.0},
		},
		"RUINER": {
			"kind": "corrosion", "rpm": 60.0, "pellets": 12, "spread": 7.0,
			"spd": 260.0, "drop": 0.5, "range_m": 600.0, "mag": 6, "reload": 5.0,
			"corro": [920.0, 5.0], "tracer": Color(0.7, 1.0, 0.55),
			"dmg": {"B": 1460.0},
		},
	}
	return _wr_catalog

static func _catalog_weapon(family_name: String, size: Size,
		entry: Dictionary) -> WeaponData:
	var data := WeaponData.new()
	data.kind = _kind_from_name(String(entry.get("kind", "autocannon")))
	data.size = size
	var damage_table := entry.get("dmg", {}) as Dictionary
	var fallback := 1000.0
	if not damage_table.is_empty():
		fallback = float(damage_table.values()[0])
	data.damage = float(damage_table.get(_size_token(size), fallback))
	data.pellets = int(entry.get("pellets", 1))
	data.shots_per_minute = float(entry.get("rpm", 300.0))
	data.spread_degrees = float(entry.get("spread", 2.0))
	data.projectile_speed = float(entry.get("spd", 300.0))
	data.projectile_drop = float(entry.get("drop", 1.0))
	var range_m := float(entry.get("range_m", 400.0))
	data.projectile_lifetime = clampf(
			range_m / maxf(data.projectile_speed, 1.0), 0.4, 2.5)
	data.magazine = int(entry.get("mag", 0))
	data.reload_time = float(entry.get("reload", 0.0))
	data.splash_radius = float(entry.get("splash", 0.0))
	if entry.has("slow"):
		var slow := entry.get("slow") as Array
		data.slow_factor = float(slow[0])
		data.slow_duration = float(slow[1])
	if entry.has("corro"):
		var corro := entry.get("corro") as Array
		data.corrosion_dps = float(corro[0])
		data.corrosion_duration = float(corro[1])
	if entry.has("chain"):
		var chain := entry.get("chain") as Array
		data.chain_bounces = int(chain[0])
		data.chain_range = float(chain[1])
	if entry.has("hull"):
		data.hull_fraction = float(entry.get("hull"))
	if bool(entry.get("beam", false)):
		data.lock_beam = true
		data.thermal_breach = bool(entry.get("breach", true))
		data.breach_per_hit = float(entry.get("breach_per_hit", 0.15))
		data.beam_range = range_m
	# magazine guns gate on reload; belt guns overheat like WR bursts.
	if data.magazine > 0:
		data.heat_per_shot = clampf(0.55 / float(data.magazine), 0.004, 0.5)
	else:
		data.heat_per_shot = clampf(
				0.4 * float(entry.get("heat_bias", 1.05))
				/ (data.shots_per_minute / 60.0), 0.01, 0.6)
	data.cooldown_rate = float(entry.get("cooldown", 0.34))
	if entry.has("tracer"):
		var tracer: Color = entry.get("tracer")
		data.tracer_color = tracer
	_size_chrome(size, data)
	return data

static func _size_token(size: Size) -> String:
	match size:
		Size.LIGHT: return "L"
		Size.HEAVY: return "H"
		Size.ALPHA: return "A"
		Size.BETA: return "B"
	return "M"

static func _kind_from_name(name: String) -> Kind:
	match name:
		"scattergun": return Kind.SCATTERGUN
		"electric": return Kind.ELECTRIC
		"magnetic": return Kind.MAGNETIC
		"blast": return Kind.BLAST
		"corrosion": return Kind.CORROSION
		"beam": return Kind.BEAM
		"flame": return Kind.FLAME
		"salvo": return Kind.SALVO
		"sonic": return Kind.SONIC
	return Kind.AUTOCANNON

static func _size_chrome(size: Size, data: WeaponData) -> void:
	match size:
		Size.LIGHT:
			data.barrel_length = 0.7
			data.drum_radius = 0.11
			data.recoil = 0.06
			data.shake = 0.13
			data.muzzle_scale = 0.42
		Size.HEAVY:
			data.barrel_length = 1.2
			data.drum_radius = 0.18
			data.recoil = 0.12
			data.shake = 0.28
			data.muzzle_scale = 0.6
		Size.ALPHA, Size.BETA:
			data.barrel_length = 1.25
			data.drum_radius = 0.2
			data.recoil = 0.14
			data.shake = 0.32
			data.muzzle_scale = 0.66
		_:
			pass  # MEDIUM keeps the per-family builder defaults

static func _razor(size: Size) -> WeaponData:
	var data := WeaponData.new()
	data.kind = Kind.AUTOCANNON
	data.family = "RAZOR"
	data.size = size
	# WR autocannon: light/medium/heavy cycle-DPS ratio 1 : 1.6 : 2.8
	# (Punisher / Punisher T / Avenger), medium anchored at 24 800 DPS.
	match size:
		Size.LIGHT:
			data.damage = 1450.0
			data.shots_per_minute = 640.0
			data.heat_per_shot = 0.038
			data.barrel_length = 0.7
			data.drum_radius = 0.11
			data.recoil = 0.06
			data.shake = 0.13
			data.muzzle_scale = 0.42
		Size.HEAVY:
			data.damage = 4650.0
			data.shots_per_minute = 560.0
			data.heat_per_shot = 0.06
			data.barrel_length = 1.2
			data.drum_radius = 0.18
			data.recoil = 0.12
			data.shake = 0.32
			data.muzzle_scale = 0.62
		_:
			data.damage = 2400.0
			data.shots_per_minute = 620.0
			data.heat_per_shot = 0.05
			data.barrel_length = 0.95
			data.drum_radius = 0.14
			data.recoil = 0.085
			data.shake = 0.2
			data.muzzle_scale = 0.5
	data.pellets = 1
	data.spread_degrees = 1.4
	data.projectile_speed = 300.0
	data.projectile_drop = 0.8
	data.projectile_lifetime = 1.67
	data.cooldown_rate = 0.4
	data.tracer_length = 1.8
	data.tracer_radius = 0.07
	data.tracer_color = Color(1.0, 0.74, 0.3)
	return data

static func _maul(size: Size) -> WeaponData:
	var data := WeaponData.new()
	data.kind = Kind.SCATTERGUN
	data.family = "MAUL"
	data.size = size
	# WR Hammer-class shotgun: cycle-DPS ratio 1 : 1.43 : 1.9 (Cudgel/Mace/Hammer)
	# fired on a short ~0.25 s cycle instead of our old one-second pump.
	match size:
		Size.LIGHT:
			data.damage = 450.0
			data.pellets = 6
			data.shots_per_minute = 260.0
			data.spread_degrees = 8.5
			data.barrel_length = 0.5
			data.drum_radius = 0.13
			data.recoil = 0.16
			data.shake = 0.45
			data.muzzle_scale = 0.75
		Size.HEAVY:
			data.damage = 575.0
			data.pellets = 11
			data.shots_per_minute = 210.0
			data.spread_degrees = 7.0
			data.barrel_length = 0.82
			data.drum_radius = 0.24
			data.recoil = 0.26
			data.shake = 0.9
			data.muzzle_scale = 1.1
		_:
			data.damage = 520.0
			data.pellets = 8
			data.shots_per_minute = 240.0
			data.spread_degrees = 7.5
			data.barrel_length = 0.66
			data.drum_radius = 0.19
			data.recoil = 0.22
			data.shake = 0.7
			data.muzzle_scale = 0.95
	data.projectile_speed = 300.0
	data.projectile_drop = 1.5
	data.projectile_lifetime = 1.17
	data.heat_per_shot = 0.12
	data.cooldown_rate = 0.34
	data.tracer_length = 1.0
	data.tracer_radius = 0.09
	data.tracer_color = Color(1.0, 0.56, 0.22)
	return data

static func _volt(size: Size) -> WeaponData:
	var data := WeaponData.new()
	data.kind = Kind.ELECTRIC
	data.family = "VOLT"
	data.size = size
	# WR arc family (Spark/Scourge/Calamity): flat size ratio 1 : 1.12 : 1.74
	# with a fast ~0.3 s cycle — light arcs are nearly as hot as medium ones.
	# Heat is tuned for WR's ~8 s unload: net rate = heat x rpm/60 - cooling
	# stays ~0.125/s (burst ~8 s) before the short overheat cool-down.
	match size:
		Size.LIGHT:
			data.damage = 825.0
			data.pellets = 5
			data.shots_per_minute = 200.0
			data.spread_degrees = 10.0
			data.barrel_length = 0.55
			data.drum_radius = 0.12
			data.recoil = 0.07
			data.shake = 0.25
			data.muzzle_scale = 0.6
			data.heat_per_shot = 0.128
		Size.MEDIUM:
			data.damage = 730.0
			data.pellets = 7
			data.shots_per_minute = 180.0
			data.spread_degrees = 13.0
			data.barrel_length = 0.7
			data.drum_radius = 0.16
			data.recoil = 0.12
			data.shake = 0.45
			data.muzzle_scale = 0.8
			data.heat_per_shot = 0.14
		_:
			data.damage = 870.0
			data.pellets = 11
			data.shots_per_minute = 150.0
			data.spread_degrees = 20.0
			data.barrel_length = 0.95
			data.drum_radius = 0.22
			data.recoil = 0.3
			data.shake = 0.9
			data.muzzle_scale = 1.15
			data.heat_per_shot = 0.17
	data.projectile_speed = 300.0
	data.projectile_drop = 0.6
	data.projectile_lifetime = 2.0
	data.cooldown_rate = 0.3
	data.tracer_length = 1.3
	data.tracer_radius = 0.11
	data.tracer_color = Color(0.6, 0.85, 1.0)
	data.slow_factor = 0.5
	data.slow_duration = 2.0
	data.chain_bounces = 2
	data.chain_range = 50.0
	return data


static func _torq(size: Size) -> WeaponData:
	var data := WeaponData.new()
	data.kind = Kind.MAGNETIC
	data.family = "TORQ"
	data.size = size
	# WR railguns (Volt / Weber / Gauss) fire slow heavy slugs with a nearly
	# flat size ratio — our heavy lands Gauss' exact 1.0 s shot cycle.
	match size:
		Size.LIGHT:
			data.damage = 6900.0
			data.shots_per_minute = 145.0
			data.heat_per_shot = 0.05
			data.barrel_length = 0.6
			data.drum_radius = 0.12
			data.recoil = 0.07
			data.shake = 0.2
			data.muzzle_scale = 0.5
		Size.HEAVY:
			data.damage = 21000.0
			data.shots_per_minute = 60.0
			data.heat_per_shot = 0.075
			data.barrel_length = 1.1
			data.drum_radius = 0.19
			data.recoil = 0.14
			data.shake = 0.45
			data.muzzle_scale = 0.7
		_:
			data.damage = 11800.0
			data.shots_per_minute = 100.0
			data.heat_per_shot = 0.06
			data.barrel_length = 0.8
			data.drum_radius = 0.15
			data.recoil = 0.1
			data.shake = 0.3
			data.muzzle_scale = 0.6
	data.pellets = 1
	data.spread_degrees = 1.0
	data.projectile_speed = 300.0
	data.projectile_drop = 0.15
	data.projectile_lifetime = 2.0
	data.cooldown_rate = 0.4
	data.tracer_length = 2.4
	data.tracer_radius = 0.08
	data.tracer_color = Color(0.55, 0.9, 1.0)
	return data

static func _breach(size: Size) -> WeaponData:
	var data := WeaponData.new()
	data.kind = Kind.BLAST
	data.family = "BREACH"
	data.size = size
	# WR rocket family (Pinata/Orkan/Exodus): ratio 1 : 1.37 : 2.13 and a wide
	# blast footprint — our splash now scales toward WR's 10 m AOE.
	match size:
		Size.LIGHT:
			data.damage = 6800.0
			data.splash_radius = 4.5
			data.shots_per_minute = 80.0
			data.heat_per_shot = 0.11
			data.barrel_length = 0.55
			data.drum_radius = 0.16
			data.recoil = 0.2
			data.shake = 0.5
			data.muzzle_scale = 0.7
		Size.HEAVY:
			data.damage = 20600.0
			data.splash_radius = 6.5
			data.shots_per_minute = 56.0
			data.heat_per_shot = 0.16
			data.barrel_length = 0.9
			data.drum_radius = 0.26
			data.recoil = 0.34
			data.shake = 1.0
			data.muzzle_scale = 1.05
		_:
			data.damage = 11000.0
			data.splash_radius = 5.5
			data.shots_per_minute = 68.0
			data.heat_per_shot = 0.13
			data.barrel_length = 0.7
			data.drum_radius = 0.2
			data.recoil = 0.26
			data.shake = 0.7
			data.muzzle_scale = 0.85
	data.pellets = 1
	data.spread_degrees = 2.0
	data.projectile_speed = 200.0
	data.projectile_drop = 4.2
	data.projectile_lifetime = 2.5
	data.cooldown_rate = 0.3
	data.tracer_length = 1.2
	data.tracer_radius = 0.11
	data.tracer_color = Color(1.0, 0.5, 0.25)
	return data

static func _ferric(size: Size) -> WeaponData:
	var data := WeaponData.new()
	data.kind = Kind.CORROSION
	data.family = "FERRIC"
	data.size = size
	# WR corrosion family (Toxin/Venom/Bane): ratio 1 : 1.5 : 2.1, 3 s burn
	# ticks and a 300 m reach.
	match size:
		Size.LIGHT:
			data.damage = 2400.0
			data.corrosion_dps = 1600.0
			data.shots_per_minute = 170.0
			data.heat_per_shot = 0.05
			data.barrel_length = 0.5
			data.drum_radius = 0.12
			data.recoil = 0.05
			data.shake = 0.15
			data.muzzle_scale = 0.45
		Size.HEAVY:
			data.damage = 7000.0
			data.corrosion_dps = 3350.0
			data.shots_per_minute = 125.0
			data.heat_per_shot = 0.075
			data.barrel_length = 0.85
			data.drum_radius = 0.19
			data.recoil = 0.12
			data.shake = 0.4
			data.muzzle_scale = 0.65
		_:
			data.damage = 4150.0
			data.corrosion_dps = 2400.0
			data.shots_per_minute = 150.0
			data.heat_per_shot = 0.06
			data.barrel_length = 0.65
			data.drum_radius = 0.15
			data.recoil = 0.08
			data.shake = 0.25
			data.muzzle_scale = 0.55
	data.corrosion_duration = 3.0
	data.pellets = 1
	data.spread_degrees = 1.2
	data.projectile_speed = 200.0
	data.projectile_drop = 0.6
	data.projectile_lifetime = 1.75
	data.cooldown_rate = 0.36
	data.tracer_length = 1.6
	data.tracer_radius = 0.07
	data.tracer_color = Color(0.75, 0.95, 0.35)
	return data

static func _lumen(size: Size) -> WeaponData:
	var data := WeaponData.new()
	data.kind = Kind.BEAM
	data.family = "LUMEN"
	data.size = size
	data.lock_beam = true
	data.thermal_breach = true
	# WR Lumen (wiki ground truth, War Robots 12.2 robot Vulcan): homing beam
	# that curves around cover, 600 m range, 60-round magazine, 10 s reload,
	# unload 60 rounds in 15 s (= 240 rpm), base infobox damage 184/276/368
	# at Weapon Level 1 in a 1 : 1.5 : 2 ladder.
	#
	# Damage is the one value that cannot be copied raw: our arsenal runs on a
	# "every catalog weapon deals >= 300" band (tools/smoke_test.gd), so the
	# wiki ladder is lifted by the same uniform factor the rest of the catalog
	# already uses to clear that floor — 184 x 1.63 = 300, which lands the
	# ladder at exactly 300 / 450 / 600 with the WR 1 : 1.5 : 2 shape intact.
	# Range, fire rate, magazine and reload are taken verbatim.
	match size:
		Size.LIGHT:
			data.damage = 300.0
			data.heat_per_shot = 0.05
			data.barrel_length = 0.5
			data.drum_radius = 0.1
			data.recoil = 0.04
			data.shake = 0.14
			data.muzzle_scale = 0.5
		Size.HEAVY:
			data.damage = 600.0
			data.heat_per_shot = 0.062
			data.barrel_length = 0.95
			data.drum_radius = 0.17
			data.recoil = 0.1
			data.shake = 0.35
			data.muzzle_scale = 0.7
		_:
			data.damage = 450.0
			data.heat_per_shot = 0.055
			data.barrel_length = 0.7
			data.drum_radius = 0.13
			data.recoil = 0.07
			data.shake = 0.24
			data.muzzle_scale = 0.6
	# Verbatim WR stats, common to every LUMEN size.
	data.shots_per_minute = 240.0
	data.beam_range = 600.0
	data.magazine = 60
	data.reload_time = 10.0
	data.pellets = 1
	data.spread_degrees = 0.7
	data.projectile_speed = 320.0
	data.projectile_drop = 0.0
	data.projectile_lifetime = 0.9
	data.cooldown_rate = 0.5
	data.tracer_length = 3.2
	data.tracer_radius = 0.05
	data.tracer_color = Color(0.4, 0.95, 1.0)
	return data

static func _pyre(size: Size) -> WeaponData:
	var data := WeaponData.new()
	data.kind = Kind.FLAME
	data.family = "PYRE"
	data.size = size
	# WR flamers (Blaze/Igniter/Ember): ~0.07 s pour, ratio 1 : 1.38 : 1.88
	# direct output plus our sustained burn tick.
	match size:
		Size.LIGHT:
			data.damage = 375.0
			data.corrosion_dps = 2000.0
			data.shots_per_minute = 420.0
			data.heat_per_shot = 0.05
			data.barrel_length = 0.45
			data.drum_radius = 0.12
			data.recoil = 0.03
			data.shake = 0.12
			data.muzzle_scale = 0.55
		Size.HEAVY:
			data.damage = 765.0
			data.corrosion_dps = 4000.0
			data.shots_per_minute = 360.0
			data.heat_per_shot = 0.075
			data.barrel_length = 0.8
			data.drum_radius = 0.19
			data.recoil = 0.07
			data.shake = 0.3
			data.muzzle_scale = 0.8
		_:
			data.damage = 540.0
			data.corrosion_dps = 3000.0
			data.shots_per_minute = 390.0
			data.heat_per_shot = 0.06
			data.barrel_length = 0.6
			data.drum_radius = 0.15
			data.recoil = 0.05
			data.shake = 0.2
			data.muzzle_scale = 0.65
	data.corrosion_duration = 3.0
	data.pellets = 3
	data.spread_degrees = 7.0
	data.projectile_speed = 55.0
	data.projectile_drop = 0.4
	data.projectile_lifetime = 1.2
	data.cooldown_rate = 0.34
	data.tracer_length = 1.0
	data.tracer_radius = 0.12
	data.tracer_color = Color(1.0, 0.55, 0.2)
	return data

static func _volley(size: Size) -> WeaponData:
	var data := WeaponData.new()
	data.kind = Kind.SALVO
	data.family = "VOLLEY"
	data.size = size
	# WR grenade launchers (Ksiphos/Labrys/Cestus): ratio 1 : 1.48 : 1.89.
	match size:
		Size.LIGHT:
			data.damage = 3050.0
			data.splash_radius = 2.6
			data.shots_per_minute = 110.0
			data.heat_per_shot = 0.08
			data.barrel_length = 0.5
			data.drum_radius = 0.15
			data.recoil = 0.14
			data.shake = 0.4
			data.muzzle_scale = 0.6
		Size.HEAVY:
			data.damage = 8600.0
			data.splash_radius = 4.2
			data.shots_per_minute = 75.0
			data.heat_per_shot = 0.13
			data.barrel_length = 0.85
			data.drum_radius = 0.24
			data.recoil = 0.26
			data.shake = 0.8
			data.muzzle_scale = 0.95
		_:
			data.damage = 5500.0
			data.splash_radius = 3.4
			data.shots_per_minute = 90.0
			data.heat_per_shot = 0.1
			data.barrel_length = 0.65
			data.drum_radius = 0.19
			data.recoil = 0.2
			data.shake = 0.6
			data.muzzle_scale = 0.75
	data.pellets = 2
	data.spread_degrees = 5.0
	data.projectile_speed = 200.0
	data.projectile_drop = 3.0
	data.projectile_lifetime = 2.5
	data.cooldown_rate = 0.32
	data.tracer_length = 1.3
	data.tracer_radius = 0.09
	data.tracer_color = Color(1.0, 0.8, 0.35)
	return data


static func _juggernaut(size: Size) -> WeaponData:
	var data := WeaponData.new()
	data.kind = Kind.AUTOCANNON
	data.size = size
	data.family = "JUGGERNAUT"
	data.item_id = "JUGGERNAUT-A"
	data.display_name = "JUGGERNAUT"
	# WR Alpha MG (Vengeance): ~0.2 s cycle, sustained rather than bursty.
	data.damage = 4000.0
	data.pellets = 1
	data.shots_per_minute = 300.0
	data.spread_degrees = 1.2
	data.projectile_speed = 300.0
	data.projectile_drop = 0.8
	data.projectile_lifetime = 1.67
	data.heat_per_shot = 0.075
	data.cooldown_rate = 0.34
	data.recoil = 0.16
	data.shake = 0.4
	data.muzzle_scale = 0.75
	data.barrel_length = 1.35
	data.drum_radius = 0.24
	data.tracer_length = 2.4
	data.tracer_radius = 0.1
	data.tracer_color = Color(1.0, 0.82, 0.34)
	return data

static func _demolisher(size: Size) -> WeaponData:
	var data := WeaponData.new()
	data.kind = Kind.BLAST
	data.size = size
	data.family = "DEMOLISHER"
	data.item_id = "DEMOLISHER-A"
	data.display_name = "DEMOLISHER"
	data.damage = 25000.0
	data.pellets = 1
	data.shots_per_minute = 44.0
	data.spread_degrees = 1.6
	data.projectile_speed = 200.0
	data.projectile_drop = 4.0
	data.projectile_lifetime = 2.5
	data.heat_per_shot = 0.18
	data.cooldown_rate = 0.3
	data.recoil = 0.4
	data.shake = 1.2
	data.muzzle_scale = 1.2
	data.barrel_length = 1.2
	data.drum_radius = 0.34
	# WR alpha explosive guns blast a 7 m footprint.
	data.splash_radius = 7.0
	data.tracer_length = 1.6
	data.tracer_radius = 0.14
	data.tracer_color = Color(1.0, 0.55, 0.22)
	return data

static func _overlord(size: Size) -> WeaponData:
	var data := WeaponData.new()
	data.kind = Kind.MAGNETIC
	data.size = size
	data.family = "OVERLORD"
	data.item_id = "OVERLORD-A"
	data.display_name = "OVERLORD"
	# WR Gauss-class alpha rail: one 1.0 s slug per cycle, long flat reach.
	data.damage = 19000.0
	data.pellets = 1
	data.shots_per_minute = 60.0
	data.spread_degrees = 0.8
	data.projectile_speed = 300.0
	data.projectile_drop = 0.15
	data.projectile_lifetime = 2.0
	data.heat_per_shot = 0.09
	data.cooldown_rate = 0.4
	data.recoil = 0.18
	data.shake = 0.55
	data.muzzle_scale = 0.72
	data.barrel_length = 1.3
	data.drum_radius = 0.26
	data.tracer_length = 3.0
	data.tracer_radius = 0.1
	data.tracer_color = Color(0.5, 0.92, 1.0)
	return data

static func _havoc(size: Size) -> WeaponData:
	var data := WeaponData.new()
	data.kind = Kind.SCATTERGUN
	data.size = size
	data.family = "HAVOC"
	data.item_id = "HAVOC-B"
	data.display_name = "HAVOC"
	# WR Beta shotgun (Squall): one 1.0 s volley of many pellets.
	data.damage = 1150.0
	data.pellets = 14
	data.shots_per_minute = 58.0
	data.spread_degrees = 7.5
	data.projectile_speed = 300.0
	data.projectile_drop = 0.8
	data.projectile_lifetime = 1.67
	data.heat_per_shot = 0.15
	data.cooldown_rate = 0.34
	data.recoil = 0.34
	data.shake = 1.1
	data.muzzle_scale = 1.3
	data.barrel_length = 1.0
	data.drum_radius = 0.3
	data.tracer_length = 1.1
	data.tracer_radius = 0.12
	data.tracer_color = Color(1.0, 0.6, 0.24)
	return data

static func _arclance(size: Size) -> WeaponData:
	var data := WeaponData.new()
	data.kind = Kind.ELECTRIC
	data.size = size
	data.family = "ARCLANCE"
	data.item_id = "ARCLANCE-B"
	data.display_name = "ARC LANCE"
	data.damage = 900.0
	data.pellets = 14
	data.shots_per_minute = 78.0
	data.spread_degrees = 18.0
	data.projectile_speed = 300.0
	data.projectile_drop = 0.8
	data.projectile_lifetime = 1.67
	# Titan arc: same ~8 s unload rhythm as the VOLT family (0.33 x 1.3 - 0.3
	# = 0.129 heat/s -> ~7.8 s burst), and it chains three hops at half power.
	data.heat_per_shot = 0.33
	data.cooldown_rate = 0.3
	data.recoil = 0.3
	data.shake = 0.9
	data.muzzle_scale = 1.1
	data.barrel_length = 0.95
	data.drum_radius = 0.26
	data.tracer_length = 1.4
	data.tracer_radius = 0.13
	data.tracer_color = Color(0.55, 0.85, 1.0)
	data.slow_factor = 0.5
	data.slow_duration = 2.0
	data.chain_bounces = 3
	data.chain_range = 50.0
	return data

static func _celerity(size: Size) -> WeaponData:
	var data := WeaponData.new()
	data.kind = Kind.AUTOCANNON
	data.size = size
	data.family = "CELERITY"
	data.item_id = "CELERITY-B"
	data.display_name = "CELERITY"
	# WR Beta MG (Retaliator): 0.1 s cycle, long sustained bursts.
	data.damage = 1200.0
	data.pellets = 1
	data.shots_per_minute = 600.0
	data.spread_degrees = 1.6
	data.projectile_speed = 300.0
	data.projectile_drop = 0.8
	data.projectile_lifetime = 1.67
	data.heat_per_shot = 0.05
	data.cooldown_rate = 0.36
	data.recoil = 0.1
	data.shake = 0.24
	data.muzzle_scale = 0.56
	data.barrel_length = 1.1
	data.drum_radius = 0.18
	data.tracer_length = 2.2
	data.tracer_radius = 0.08
	data.tracer_color = Color(1.0, 0.74, 0.3)
	return data

# Scaled-down built-in weapons carried by companion drones (one per drone kind).
static func drone_for(drone_id: String) -> WeaponData:
	var data := WeaponData.new()
	data.size = Size.LIGHT
	data.item_id = "DRONE-" + drone_id.to_upper()
	match drone_id:
		"bulwark":
			# freeze rockets — arcing shells that chill the target on a direct hit
			data.kind = Kind.BLAST
			data.family = "CRYOSHARD"
			data.display_name = "BULWARK CRYOSHARD"
			data.damage = 700.0
			data.splash_radius = 2.8
			data.shots_per_minute = 75.0
			data.spread_degrees = 1.2
			data.projectile_speed = 60.0
			data.projectile_drop = 1.5
			data.projectile_lifetime = 2.4
			data.slow_factor = 0.4
			data.slow_duration = 2.5
			data.tracer_length = 1.4
			data.tracer_radius = 0.07
			data.tracer_color = Color(0.6, 0.86, 1.0)
		"patch":
			# flamethrower — short-range cone that burns over time
			data.kind = Kind.FLAME
			data.family = "EMBERWIND"
			data.display_name = "PATCH EMBERWIND"
			data.damage = 180.0
			data.pellets = 3
			data.spread_degrees = 8.0
			data.corrosion_dps = 350.0
			data.corrosion_duration = 3.0
			data.shots_per_minute = 380.0
			data.projectile_speed = 40.0
			data.projectile_drop = 0.4
			data.projectile_lifetime = 1.5
			data.tracer_length = 1.0
			data.tracer_radius = 0.11
			data.tracer_color = Color(1.0, 0.55, 0.2)
		"kestrel":
			# target-seeking minigun — sustained independent fire
			data.kind = Kind.AUTOCANNON
			data.family = "SWARMLINE"
			data.display_name = "KESTREL SWARMLINE"
			data.damage = 420.0
			data.shots_per_minute = 540.0
			data.spread_degrees = 2.2
			data.projectile_speed = 150.0
			data.projectile_drop = 1.0
			data.projectile_lifetime = 1.2
			data.tracer_length = 1.6
			data.tracer_radius = 0.05
			data.tracer_color = Color(1.0, 0.85, 0.4)
		_:
			# electric shocks — zap that briefly chills the target
			data.kind = Kind.ELECTRIC
			data.family = "ARCSTING"
			data.display_name = "WISP ARCSTING"
			data.damage = 520.0
			data.shots_per_minute = 300.0
			data.spread_degrees = 1.5
			data.projectile_speed = 115.0
			data.projectile_drop = 0.0
			data.projectile_lifetime = 1.0
			data.slow_factor = 0.6
			data.slow_duration = 1.0
			data.tracer_length = 1.5
			data.tracer_radius = 0.05
			data.tracer_color = Color(0.62, 0.9, 1.0)
	return data

static func drone_fire_range(drone_id: String) -> float:
	match drone_id:
		"patch": return 40.0
		"bulwark": return 90.0
		"kestrel": return 100.0
	return 80.0
