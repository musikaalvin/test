class_name CombatFx
extends Node3D

const SPARK_LIFETIME := 0.4
const FLASH_LIFETIME := 0.12
const MAX_LIGHTS := 6
const SCORCH_LIFETIME := 9.0
const MAX_SCORCHES := 14
const RUPTURE_FLASH_LIFETIME := 0.1
const BURST_FLASH_LIFETIME := 0.26
const POP_FLASH_LIFETIME := 0.16
const BURST_SPARK_LIFETIME := 0.55
const BURST_SMOKE_LIFETIME := 1.5

var _flash_pool: Array[OmniLight3D] = []
var _scorch_queue: Array[MeshInstance3D] = []
var _scorch_material: StandardMaterial3D
var _bursting: bool = false

func _ready() -> void:
	add_to_group("combat_fx")
	Events.weapon_impact.connect(_on_weapon_impact)

func spawn_rupture(point: Vector3) -> void:
	_burst_flash(point, Color(1.0, 0.9, 0.7), 7.5, 5.5, RUPTURE_FLASH_LIFETIME)

func spawn_explosion(point: Vector3, size_scale: float = 1.0) -> void:
	var size := clampf(size_scale, 0.5, 2.0)
	_bursting = true
	_burst_flash(point, Color(1.0, 0.64, 0.3), 5.5 * size, 5.0 * size,
			BURST_FLASH_LIFETIME)
	_burst_sparks(point, int(round(26.0 * size)))
	_burst_smoke(point, size)
	var ground := _ground_point(point)
	if not ground.is_zero_approx():
		_spawn_scorch(ground, Vector3.UP)
	Events.weapon_impact.emit(point, Vector3.UP, WeaponData.Kind.BLAST)
	_bursting = false

func spawn_pop(point: Vector3, size_scale: float = 0.5) -> void:
	var size := clampf(size_scale, 0.25, 1.0)
	_bursting = true
	_burst_flash(point, Color(1.0, 0.55, 0.22), 2.2 * size + 0.6, 3.2 * size,
			POP_FLASH_LIFETIME)
	_burst_sparks(point, int(round(9.0 * size + 4.0)))
	Events.weapon_impact.emit(point, Vector3.UP, WeaponData.Kind.BLAST)
	_bursting = false

# Weapon torn off the hull: hot flash + spark shower + smoke puff, routed
# through the impact signal so audio/scorch listeners treat it like a hit.
func spawn_weapon_burst(point: Vector3, size_scale: float = 0.6) -> void:
	var size := clampf(size_scale, 0.3, 1.5)
	_bursting = true
	_burst_flash(point, Color(1.0, 0.7, 0.32), 4.4 * size, 3.4 * size,
			BURST_FLASH_LIFETIME)
	_burst_sparks(point, int(round(16.0 * size)))
	_burst_smoke(point, size * 0.85)
	Events.weapon_impact.emit(point, Vector3.UP, WeaponData.Kind.BLAST)
	_bursting = false

# Tumbling hunk of blown-off hardware. Layer 0 keeps robots and projectiles
# from ever clipping it; the mask still lets it land on the world.
func spawn_debris(point: Vector3, size: Vector3, material: Material,
		life: float = 1.7) -> void:
	var chunk := RigidBody3D.new()
	chunk.name = "DebrisChunk"
	chunk.collision_layer = 0
	chunk.collision_mask = Layers.WORLD
	chunk.mass = maxf(size.x * size.y * size.z * 420.0, 1.0)
	var mesh := MeshUtil.make_bevel_box(size,
			minf(size.x, minf(size.y, size.z)) * 0.22, material, "debris_chunk")
	chunk.add_child(mesh)
	add_child(chunk)
	chunk.global_position = point
	chunk.linear_velocity = Vector3(randf_range(-2.8, 2.8), randf_range(4.0, 8.0),
			randf_range(-2.8, 2.8))
	chunk.angular_velocity = Vector3(randf_range(-10.0, 10.0),
			randf_range(-10.0, 10.0), randf_range(-10.0, 10.0))
	get_tree().create_timer(life).timeout.connect(chunk.queue_free)

func _ground_point(point: Vector3) -> Vector3:
	if not is_inside_tree():
		return Vector3.ZERO
	var query := PhysicsRayQueryParameters3D.create(point + Vector3.UP * 0.5,
			point + Vector3.DOWN * 9.0)
	query.collision_mask = Layers.WORLD
	query.collide_with_areas = false
	query.collide_with_bodies = true
	var hit := get_world_3d().direct_space_state.intersect_ray(query)
	if hit.is_empty():
		return Vector3.ZERO
	return hit["position"] as Vector3

func _burst_flash(point: Vector3, color: Color, energy: float, radius: float,
		duration: float) -> void:
	var light := OmniLight3D.new()
	light.light_color = color
	light.omni_range = radius
	light.light_energy = energy
	add_child(light)
	light.global_position = point
	var tween := create_tween()
	tween.tween_property(light, "light_energy", 0.0, duration)
	tween.tween_callback(light.queue_free)

func _burst_sparks(point: Vector3, amount: int) -> void:
	var sparks := CPUParticles3D.new()
	sparks.name = "BurstSparks"
	sparks.one_shot = true
	sparks.amount = maxi(amount, 4)
	sparks.lifetime = BURST_SPARK_LIFETIME
	sparks.explosiveness = 1.0
	sparks.direction = Vector3.UP
	sparks.spread = 180.0
	sparks.gravity = Vector3(0.0, -20.0, 0.0)
	sparks.initial_velocity_min = 5.5
	sparks.initial_velocity_max = 14.0
	sparks.angular_velocity_min = -16.0
	sparks.angular_velocity_max = 16.0
	sparks.mesh = _spark_box()
	sparks.color = Color(1.0, 0.68, 0.3, 1.0)
	sparks.position = point
	add_child(sparks)
	sparks.emitting = true
	var timer := get_tree().create_timer(BURST_SPARK_LIFETIME + 0.3)
	timer.timeout.connect(sparks.queue_free)

func _burst_smoke(point: Vector3, size: float) -> void:
	var smoke := CPUParticles3D.new()
	smoke.name = "BurstSmoke"
	smoke.one_shot = true
	# Godot rejects amount < 1 outright ("Amount of particles must be
	# greater than 0"), so a tiny burst size can never crash the emitter.
	smoke.amount = maxi(1, int(round(16.0 * size)))
	smoke.lifetime = BURST_SMOKE_LIFETIME
	smoke.explosiveness = 0.85
	smoke.direction = Vector3.UP
	smoke.spread = 55.0
	smoke.gravity = Vector3(0.0, 2.4, 0.0)
	smoke.initial_velocity_min = 1.5
	smoke.initial_velocity_max = 3.8
	smoke.scale_amount_min = 0.5 * size
	smoke.scale_amount_max = 1.5 * size
	smoke.color = Color(0.15, 0.13, 0.12, 0.7)
	var ball := SphereMesh.new()
	ball.radius = 0.4 * size
	ball.height = 0.8 * size
	var material := MeshUtil.make_material(Color(0.12, 0.11, 0.1), 0.0, 1.0)
	material.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
	material.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
	material.vertex_color_use_as_albedo = true
	ball.material = material
	smoke.mesh = ball
	smoke.position = point
	add_child(smoke)
	smoke.emitting = true
	var timer := get_tree().create_timer(BURST_SMOKE_LIFETIME + 0.5)
	timer.timeout.connect(smoke.queue_free)

func _on_weapon_impact(point: Vector3, normal: Vector3, kind: int) -> void:
	if _bursting:
		return
	# Every weapon class leaves a different mark: electric arcs shard into
	# blue sparks, rails punch a white-hot crater, rockets bloom orange,
	# acid eats green, flamers ember, sonic rings violet, kinetic shells
	# throw brass and scorch.
	match kind:
		WeaponData.Kind.ELECTRIC:
			_spawn_arc_burst(point, normal)
			_spawn_flash(point, Color(0.55, 0.8, 1.0))
			return
		WeaponData.Kind.MAGNETIC:
			_spawn_sparks(point, normal, Color(0.78, 0.96, 1.0), 14)
			_spawn_flash(point, Color(0.8, 0.97, 1.0))
			return
		WeaponData.Kind.BLAST:
			_spawn_sparks(point, normal, Color(1.0, 0.62, 0.28), 16)
			_spawn_flash(point, Color(1.0, 0.6, 0.28))
			_spawn_scorch(point, normal)
			return
		WeaponData.Kind.SALVO:
			_spawn_sparks(point, normal, Color(1.0, 0.88, 0.45), 12)
			_spawn_flash(point, Color(1.0, 0.9, 0.45))
			_spawn_scorch(point, normal)
			return
		WeaponData.Kind.SCATTERGUN:
			_spawn_sparks(point, normal, Color(1.0, 0.78, 0.44), 12)
			_spawn_flash(point, Color(1.0, 0.76, 0.42))
			_spawn_scorch(point, normal)
			return
		WeaponData.Kind.BEAM:
			_spawn_flash(point, Color(0.5, 0.95, 1.0))
			_spawn_sparks(point, normal, Color(0.6, 0.95, 1.0), 5)
			return
		WeaponData.Kind.CORROSION:
			_spawn_sparks(point, normal, Color(0.7, 1.0, 0.4), 8)
			_spawn_flash(point, Color(0.7, 1.0, 0.45))
			return
		WeaponData.Kind.FLAME:
			_spawn_sparks(point, normal, Color(1.0, 0.58, 0.22), 7)
			_spawn_flash(point, Color(1.0, 0.6, 0.25))
			_spawn_scorch(point, normal)
			return
		WeaponData.Kind.SONIC:
			_spawn_sparks(point, normal, Color(0.85, 0.78, 1.0), 6)
			_spawn_flash(point, Color(0.86, 0.8, 1.0))
			return
	_spawn_sparks(point, normal)
	_spawn_flash(point)
	_spawn_scorch(point, normal)

# Arc bursts used to build 7 new BoxMesh + a fresh material per electric
# impact — with chain shocks that is hundreds of allocations per second and it
# hitch-froze low-end devices. One shared mesh + material now, and a hard cap
# on simultaneous shards (visual-only drop under extreme fire).
var _arc_mesh: BoxMesh = null
var _arc_material: StandardMaterial3D = null
var _arc_alive: int = 0

const ARC_MAX_ALIVE := 48

func _arc_assets() -> BoxMesh:
	if _arc_mesh == null:
		_arc_mesh = BoxMesh.new()
		_arc_mesh.size = Vector3.ONE
		_arc_material = MeshUtil.make_material(Color(0.78, 0.9, 1.0), 0.0, 0.3,
				Color(0.65, 0.85, 1.0), 5.0)
		_arc_material.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
		_arc_mesh.material = _arc_material
	return _arc_mesh

func _arc_shard_done(shard: MeshInstance3D) -> void:
	_arc_alive -= 1
	if is_instance_valid(shard):
		shard.queue_free()

func _spawn_arc_burst(point: Vector3, normal: Vector3) -> void:
	if _arc_alive >= ARC_MAX_ALIVE:
		return
	var mesh := _arc_assets()
	for index in 7:
		if _arc_alive >= ARC_MAX_ALIVE:
			break
		_arc_alive += 1
		var direction := (normal + Vector3(randf_range(-1.0, 1.0), randf_range(-1.0, 1.0),
				randf_range(-1.0, 1.0)) * 0.75).normalized()
		var length := randf_range(0.4, 0.95)
		var shard := MeshInstance3D.new()
		shard.name = "arc_burst"
		shard.mesh = mesh
		shard.position = point + normal * 0.05
		add_child(shard)
		var up := Vector3.RIGHT if absf(direction.y) > 0.95 else Vector3.UP
		shard.look_at(point + normal * 0.05 + direction, up)
		shard.scale = Vector3(0.035, 0.035, length)
		var tween := create_tween()
		tween.tween_property(shard, "scale", Vector3(0.005, 0.005, length * 0.3),
				0.16).set_trans(Tween.TRANS_QUAD).set_ease(Tween.EASE_IN)
		tween.tween_callback(_arc_shard_done.bind(shard))

func _spawn_sparks(point: Vector3, normal: Vector3, color: Color = Color(1.0, 0.82, 0.42),
		amount: int = 10) -> void:
	var sparks := CPUParticles3D.new()
	sparks.name = "ImpactSparks"
	sparks.one_shot = true
	sparks.amount = maxi(1, amount)
	sparks.lifetime = SPARK_LIFETIME
	sparks.explosiveness = 1.0
	sparks.direction = normal
	sparks.spread = 65.0
	sparks.gravity = Vector3(0.0, -14.0, 0.0)
	sparks.initial_velocity_min = 2.5
	sparks.initial_velocity_max = 6.0
	sparks.mesh = _spark_box()
	sparks.color = color
	sparks.position = point + normal * 0.04
	add_child(sparks)
	sparks.emitting = true
	var timer := get_tree().create_timer(SPARK_LIFETIME + 0.25)
	timer.timeout.connect(sparks.queue_free)

var _spark_cache: BoxMesh = null

func _spark_box() -> BoxMesh:
	if _spark_cache == null:
		_spark_cache = BoxMesh.new()
		_spark_cache.size = Vector3(0.05, 0.05, 0.05)
		var material := MeshUtil.make_material(Color(1.0, 0.8, 0.4), 0.0, 0.4,
				Color(1.0, 0.75, 0.3), 2.5)
		material.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
		_spark_cache.material = material
	return _spark_cache

func _spawn_flash(point: Vector3, color: Color = Color(1.0, 0.8, 0.5)) -> void:
	var light: OmniLight3D
	if _flash_pool.size() < MAX_LIGHTS:
		light = OmniLight3D.new()
		light.light_color = color
		light.omni_range = 3.5
		_flash_pool.append(light)
		add_child(light)
	else:
		light = _flash_pool[randi() % _flash_pool.size()]
		light.light_color = color
	light.global_position = point
	light.light_energy = 2.6
	var tween := create_tween()
	tween.tween_property(light, "light_energy", 0.0, FLASH_LIFETIME)

func _spawn_scorch(point: Vector3, normal: Vector3) -> void:
	if Quality.tier() < Quality.Tier.HIGH:
		return
	for index in range(_scorch_queue.size() - 1, -1, -1):
		if not is_instance_valid(_scorch_queue[index]):
			_scorch_queue.remove_at(index)
	# Decal budget scales with CPU headroom (fewer scorch marks on weak CPUs).
	var scorch_cap := maxi(4, roundi(float(MAX_SCORCHES) * Hardware.fx_scale()))
	if _scorch_queue.size() >= scorch_cap:
		var oldest := _scorch_queue.pop_front() as MeshInstance3D
		oldest.queue_free()
	var scorch := MeshInstance3D.new()
	scorch.name = "Scorch"
	var quad := PlaneMesh.new()
	quad.orientation = PlaneMesh.FACE_Z
	quad.size = Vector2(1.7, 1.7)
	scorch.mesh = quad
	scorch.material_override = _scorch_material_instance()
	scorch.position = point + normal * 0.04
	add_child(scorch)
	var up := Vector3.RIGHT if absf(normal.y) > 0.95 else Vector3.UP
	scorch.look_at(point + normal, up)
	_scorch_queue.append(scorch)
	get_tree().create_timer(SCORCH_LIFETIME).timeout.connect(scorch.queue_free)

func _scorch_material_instance() -> StandardMaterial3D:
	if _scorch_material != null:
		return _scorch_material
	_scorch_material = StandardMaterial3D.new()
	_scorch_material.albedo_texture = _make_scorch_texture()
	_scorch_material.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
	_scorch_material.cull_mode = BaseMaterial3D.CULL_DISABLED
	_scorch_material.roughness = 1.0
	return _scorch_material

func _make_scorch_texture() -> ImageTexture:
	const SIZE := 64
	var image := Image.create(SIZE, SIZE, false, Image.FORMAT_RGBA8)
	for y in SIZE:
		for x in SIZE:
			var distance := Vector2(float(x) - 31.5, float(y) - 31.5).length() / 31.5
			var alpha := clampf(1.0 - distance, 0.0, 1.0)
			alpha = alpha * alpha
			image.set_pixel(x, y, Color(0.07, 0.06, 0.05, alpha * 0.8))
	return ImageTexture.create_from_image(image)
