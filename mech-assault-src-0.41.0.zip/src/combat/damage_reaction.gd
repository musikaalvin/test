class_name DamageReactionController
extends Node3D

## Critical-damage presentation: smoke plumes plus licking flames at one to
## three hull attach points while the host sits at or below `crit_ratio`, and a
## clean clear once it climbs back to `clear_ratio` (hysteresis, so a single
## heal cannot flicker the effect). Attached by PlayerRobot / EnemyRobot in
## _ready and wired through setup(host, health).
##
## Every particle material is built here per controller, so nothing the rig
## shares (palette colours, stealth alpha, panel textures) is ever written.

const MAX_ATTACH_POINTS := 3
const SPARK_INTERVAL_MIN := 0.55
const SPARK_INTERVAL_MAX := 1.4
const SPARK_LIFETIME := 0.4
const FLICKER_RATE := 13.0
const SMOKE_BASE := 14
const FIRE_BASE := 6
const SMOKE_RAMP := 0.55
const FIRE_RAMP := 0.5

@export var crit_ratio: float = 0.30
@export var clear_ratio: float = 0.40

var _host: Node3D = null
var _health: Health = null
var _points: Array[Node3D] = []
var _smoke: Array[CPUParticles3D] = []
var _fire: Array[CPUParticles3D] = []
var _fire_material: StandardMaterial3D = null
var _fire_energy_base: float = 3.2
var _active: bool = false
var _dead: bool = false
var _poll_clock: float = 0.0
var _spark_clock: float = 0.8
var _flicker: float = 0.0
var _size_scale: float = 1.0

func setup(host: Node3D, health: Health) -> void:
	if host == null or health == null:
		return
	_host = host
	_health = health
	_build_attach_points()
	health.damaged.connect(_on_damaged)
	health.died.connect(_on_died)
	set_process(false)

func is_critical() -> bool:
	return _active

# 0.0 when comfortably repaired, 1.0 at an empty tank.
func intensity() -> float:
	if _health == null:
		return 0.0
	return clampf((crit_ratio - _health.ratio()) / maxf(crit_ratio, 0.01), 0.0, 1.0)

# The Health.damaged payload carries the PRE-hit current, so the post-hit
# ratio comes straight from the two numbers instead of a reread that would
# race the deduction two lines below.
func _on_damaged(_amount: float, applied: float, current: float, _point: Vector3) -> void:
	if _health == null or _dead:
		return
	var after := maxf(current - applied, 0.0)
	_evaluate(after / maxf(_health.max_health, 0.01))

func _on_died() -> void:
	_dead = true
	_stop()

func _evaluate(ratio: float) -> void:
	if _dead or _host == null or _health == null or _health.dead:
		if not _dead:
			_stop()
		return
	if ratio <= 0.001:
		_stop()
		return
	if not _active and ratio <= crit_ratio:
		_start()
	elif _active and ratio >= clear_ratio:
		_stop()
	if _active:
		_apply_intensity(ratio)

func _process(delta: float) -> void:
	if not _active:
		return
	_poll_clock -= delta
	if _poll_clock <= 0.0:
		# Healing raises the ratio without emitting anything, so the clear
		# condition has to be polled rather than only event-driven.
		_poll_clock = 0.15
		_evaluate(_health.ratio() if _health != null else 1.0)
		if not _active:
			return
	_flicker += delta
	if _fire_material != null:
		_fire_material.emission_energy_multiplier = _fire_energy_base \
				* (0.7 + 0.4 * absf(sin(_flicker * FLICKER_RATE)))
	_spark_clock -= delta
	if _spark_clock <= 0.0:
		_spark_clock = randf_range(SPARK_INTERVAL_MIN, SPARK_INTERVAL_MAX)
		_burst_sparks()

func _start() -> void:
	if _active:
		return
	_active = true
	if _points.is_empty():
		_build_attach_points()
	for index in _points.size():
		var point := _points[index]
		if point == null:
			continue
		var smoke := _make_smoke()
		point.add_child(smoke)
		smoke.emitting = true
		_smoke.append(smoke)
		var fire := _make_fire()
		point.add_child(fire)
		fire.emitting = true
		_fire.append(fire)
	_apply_intensity(_health.ratio() if _health != null else 0.0, true)
	_flicker = 0.0
	_spark_clock = randf_range(0.2, 0.5)
	set_process(true)

func _stop() -> void:
	if not _active:
		set_process(false)
		return
	_active = false
	for system: CPUParticles3D in _smoke:
		if is_instance_valid(system):
			system.queue_free()
	for system: CPUParticles3D in _fire:
		if is_instance_valid(system):
			system.queue_free()
	_smoke.clear()
	_fire.clear()
	set_process(false)

func _apply_intensity(ratio: float, seed: bool = false) -> void:
	if _health == null:
		return
	# Scaled from the shortfall below the crit line so a nearly-dead mech
	# smokes harder than one that just crossed the threshold. Only size and
	# speed are retargeted live: changing `amount` restarts the emission
	# cycle, so the particle count is fixed once when the state begins.
	var t := clampf((crit_ratio - ratio) / maxf(crit_ratio, 0.01), 0.0, 1.0)
	for system: CPUParticles3D in _smoke:
		if not is_instance_valid(system):
			continue
		if seed:
			system.amount = maxi(6, roundi(float(SMOKE_BASE)
					* (SMOKE_RAMP + (1.0 - SMOKE_RAMP) * t)))
		system.scale_amount_max = (1.1 + 0.7 * t) * _size_scale
		system.initial_velocity_max = (1.9 + 0.9 * t) * _size_scale
	for system: CPUParticles3D in _fire:
		if not is_instance_valid(system):
			continue
		if seed:
			system.amount = maxi(3, roundi(float(FIRE_BASE)
					* (FIRE_RAMP + (1.0 - FIRE_RAMP) * t)))
		system.initial_velocity_max = (2.6 + 1.4 * t) * _size_scale

func _build_attach_points() -> void:
	if _host == null or not _points.is_empty():
		return
	var radius := 0.7
	var height := -1.0
	var centre_y := 0.0
	for child in _host.get_children():
		var shape := child as CollisionShape3D
		if shape == null:
			continue
		var capsule := shape.shape as CapsuleShape3D
		if capsule != null and capsule.height > height:
			height = capsule.height
			radius = capsule.radius
			centre_y = shape.position.y
	if height <= 0.0:
		height = 2.0
	_size_scale = clampf(height / 3.0, 0.45, 1.6)
	var half := height * 0.5
	var specs := [
		Vector3(0.0, centre_y + half * 0.6, -radius * 0.4),
		Vector3(radius * 0.6, centre_y + half * 0.35, radius * 0.5),
		Vector3(-radius * 0.55, centre_y + half * 0.15, -radius * 0.5),
	]
	for index in mini(MAX_ATTACH_POINTS, specs.size()):
		var point := Node3D.new()
		point.name = "CritPoint_%d" % (index + 1)
		point.position = specs[index]
		add_child(point)
		_points.append(point)

func _make_smoke() -> CPUParticles3D:
	var smoke := CPUParticles3D.new()
	smoke.name = "CritSmoke"
	smoke.amount = SMOKE_BASE
	smoke.lifetime = 1.5
	smoke.preprocess = 0.4
	smoke.direction = Vector3.UP
	smoke.spread = 42.0
	smoke.gravity = Vector3(0.0, 2.0, 0.0)
	smoke.initial_velocity_min = 0.7 * _size_scale
	smoke.initial_velocity_max = 1.9 * _size_scale
	smoke.scale_amount_min = 0.5 * _size_scale
	smoke.scale_amount_max = 1.2 * _size_scale
	var fade := Gradient.new()
	fade.colors = PackedColorArray([
			Color(0.24, 0.22, 0.21, 0.6), Color(0.16, 0.15, 0.14, 0.32),
			Color(0.1, 0.1, 0.1, 0.0)])
	fade.offsets = PackedFloat32Array([0.0, 0.5, 1.0])
	smoke.color_ramp = fade
	var puff := SphereMesh.new()
	puff.radius = 0.17 * _size_scale
	puff.height = 0.34 * _size_scale
	puff.radial_segments = 6
	puff.rings = 3
	var material := StandardMaterial3D.new()
	material.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
	material.albedo_color = Color(0.3, 0.28, 0.27, 1.0)
	material.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
	material.vertex_color_use_as_albedo = true
	material.depth_draw_mode = BaseMaterial3D.DEPTH_DRAW_DISABLED
	puff.material = material
	smoke.mesh = puff
	smoke.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	return smoke

func _make_fire() -> CPUParticles3D:
	var fire := CPUParticles3D.new()
	fire.name = "CritFire"
	fire.amount = FIRE_BASE
	fire.lifetime = 0.6
	fire.preprocess = 0.2
	fire.direction = Vector3.UP
	fire.spread = 24.0
	fire.gravity = Vector3(0.0, 5.5, 0.0)
	fire.initial_velocity_min = 1.2 * _size_scale
	fire.initial_velocity_max = 2.6 * _size_scale
	fire.scale_amount_min = 0.3 * _size_scale
	fire.scale_amount_max = 0.75 * _size_scale
	if _fire_material == null:
		_fire_material = StandardMaterial3D.new()
		_fire_material.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
		_fire_material.albedo_color = Color(1.0, 0.42, 0.1, 1.0)
		_fire_material.emission_enabled = true
		_fire_material.emission = Color(1.0, 0.5, 0.12)
		_fire_material.emission_energy_multiplier = _fire_energy_base
		_fire_material.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
		_fire_material.blend_mode = BaseMaterial3D.BLEND_MODE_ADD
		_fire_material.vertex_color_use_as_albedo = true
	var flame := SphereMesh.new()
	flame.radius = 0.1 * _size_scale
	flame.height = 0.2 * _size_scale
	flame.radial_segments = 6
	flame.rings = 3
	flame.material = _fire_material
	fire.mesh = flame
	fire.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	return fire

# Occasional one-shot spark shower so the state reads as live damage rather
# than a static decal.
func _burst_sparks() -> void:
	if _points.is_empty() or not is_inside_tree():
		return
	var host := _points[randi() % _points.size()]
	if host == null:
		return
	var sparks := CPUParticles3D.new()
	sparks.name = "CritSparks"
	sparks.one_shot = true
	sparks.amount = 7
	sparks.lifetime = SPARK_LIFETIME
	sparks.explosiveness = 1.0
	sparks.direction = Vector3.UP
	sparks.spread = 130.0
	sparks.gravity = Vector3(0.0, -16.0, 0.0)
	sparks.initial_velocity_min = 2.0 * _size_scale
	sparks.initial_velocity_max = 5.0 * _size_scale
	var spark_mesh := BoxMesh.new()
	spark_mesh.size = Vector3(0.05, 0.05, 0.05) * _size_scale
	var material := StandardMaterial3D.new()
	material.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
	material.albedo_color = Color(1.0, 0.72, 0.28)
	material.emission_enabled = true
	material.emission = Color(1.0, 0.66, 0.22)
	material.emission_energy_multiplier = 3.4
	spark_mesh.material = material
	sparks.mesh = spark_mesh
	sparks.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	host.add_child(sparks)
	sparks.emitting = true
	var timer := get_tree().create_timer(SPARK_LIFETIME + 0.3)
	# The host may be freed (enemy death) while the timer is still pending, so
	# the cleanup call has to be validity-guarded rather than a direct bind.
	timer.timeout.connect(func() -> void:
		if is_instance_valid(sparks):
			sparks.queue_free())
