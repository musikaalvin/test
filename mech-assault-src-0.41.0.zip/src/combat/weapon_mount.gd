class_name WeaponMount
extends Node3D

const FLASH_TIME := 0.055
const RECOIL_STIFFNESS := 210.0
const RECOIL_DAMPING := 16.0

var mount_index: int = 0
var data: WeaponData = null
var muzzle: Marker3D = null
var heat: float = 0.0
var overheated: bool = false
# Set when the gun is blown off the hull: the visual subtree is hidden, the
# mount can never fire or build heat again, and the HUD/touch ring draw it as
# an empty slot. The node itself is kept so the rig still reports its muzzle.
var destroyed: bool = false

var _side: float = 1.0
var _cooldown: float = 0.0
var _recoil: float = 0.0
var _recoil_velocity: float = 0.0
var _flash: MeshInstance3D = null
var _flash_light: OmniLight3D = null
var _flash_time: float = 0.0
var _smoke: CPUParticles3D = null
# Per-weapon muzzle appearance (WeaponData.shot_look): what shape the bloom
# is, how long it lives, how far it stretches down the barrel, and how big
# the flash light is. Every family gets its own combination so two guns of
# the same class never flash identically.
var _flash_shape: int = WeaponData.FlashShape.BALL
var _flash_life: float = FLASH_TIME
var _flash_stretch: float = 1.7
var _flash_lrange: float = 5.5
var _flash_lenergy: float = 2.6

# Per-weapon firing animation. Each family moves one distinctive part so shots
# read differently: a spinning barrel cluster, a pump slide, a throbbed energy
# core, a blinking tube rack or a wobbling gauge needle. Animations are
# transform-only -- materials are shared with the robot rig (and mutated by
# RobotRig.set_stealth), so no weapon animation may write material state.
enum Anim {
	NONE,
	SPIN_BARRELS,
	PUMP_SLIDE,
	CORE_THROB,
	TUBE_SEQUENCE,
	NEEDLE_WOBBLE,
	FLAME_FLICKER,
}

const ANIM_PULSE_DECAY := 9.0
const ANIM_SPIN_KICK := 26.0
const ANIM_SPIN_DECAY := 42.0
const ANIM_SPIN_IDLE := 3.0
const ANIM_PUMP_TRAVEL := 0.14
const ANIM_PUMP_DURATION := 0.26

var _anim_kind: Anim = Anim.NONE
var _anim_parts: Array[Node3D] = []
var _anim_rest_pos: Array[Vector3] = []
var _anim_rest_rot: Array[Vector3] = []
var _anim_rest_scale: Array[Vector3] = []
var _anim_material: StandardMaterial3D = null
var _anim_material_base: float = 0.0
var _anim_timer: float = 9.0
var _anim_phase: float = 0.0
var _anim_speed: float = 0.0
var _anim_index: int = 0

# Magazine + reload (VOID/CHASH titan guns): ammo counts down per shot,
# hitting 0 starts a reload that refills the magazine and supercharges the
# next one. While reloading, a suppression pulse beats on nearby enemies.
var _ammo: int = 0
var _reload_left: float = 0.0
var _reload_pulse: float = 0.0
var _supercharged: bool = false
var _suppression_shape := SphereShape3D.new()

# Lock-on beam state (LUMEN): aim + curve rays reuse one query, and the last
# hit is stashed here so _beam_path/_beam_strike stay single-return.
var _beam_query := PhysicsRayQueryParameters3D.new()
var _beam_clear_query := PhysicsRayQueryParameters3D.new()
var _beam_collider: Variant = null
var _beam_point := Vector3.ZERO
var _beam_normal := Vector3.UP

const BEAM_BEND_HEIGHTS: Array[float] = [3.0, 6.0, 10.0, 14.0, 19.0, 24.0]
const BEAM_BEND_SIDES: Array[float] = [2.5, 5.0, 8.0, 13.0, 20.0]
const BEAM_SEGMENT_SAMPLES: int = 4

func setup(index: int, weapon_data: WeaponData, side: float, materials: Dictionary) -> void:
	mount_index = index
	data = weapon_data
	_side = side
	_ammo = weapon_data.magazine if weapon_data != null else 0
	var axis := Vector3(side, 0.0, 0.0)
	muzzle = Marker3D.new()
	muzzle.name = "Muzzle"
	if data == null:
		muzzle.position = axis * 0.7
		add_child(muzzle)
		return
	var dark := materials["dark"] as StandardMaterial3D
	var joint := materials["joint"] as StandardMaterial3D
	var trim := materials["trim"] as StandardMaterial3D
	var glow := materials.get("sensor", trim) as StandardMaterial3D
	var barrel_length: float = data.barrel_length
	var drum_radius: float = data.drum_radius
	# Per-weapon muzzle look: colour, silhouette and timing all come from the
	# weapon's own family so every gun flashes differently (see weapon_data).
	var look := WeaponData.shot_look(data.family, data.kind)
	var flash_tint := look["color"] as Color
	_flash_shape = look["shape"] as int
	_flash_life = maxf(look["life"] as float, 0.01)
	_flash_stretch = look["stretch"] as float
	_flash_lrange = look["lrange"] as float
	_flash_lenergy = look["lenergy"] as float
	var flash_material := MeshUtil.make_material(flash_tint, 0.0, 0.2)
	flash_material.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
	flash_material.emission_enabled = true
	flash_material.emission = flash_tint
	flash_material.emission_energy_multiplier = 6.0
	MeshUtil.add_visual_cylinder(self, 0.19, 0.3, axis * 0.1, joint, axis, "mount_base")
	MeshUtil.add_visual_box(self, Vector3(0.34, 0.26, 0.5), axis * 0.2 + Vector3.UP * 0.04,
			dark, 0.0, "mount_cradle")
	if data.family == "VOID" or data.family == "CHASH" \
			or data.family == "CHASM":
		_build_void(axis, dark, joint, trim, glow, barrel_length, drum_radius)
	else:
		match data.kind:
			WeaponData.Kind.ELECTRIC:
				_build_electric(axis, dark, joint, trim, glow, barrel_length, drum_radius)
			WeaponData.Kind.SCATTERGUN:
				_build_scattergun(axis, dark, joint, trim, barrel_length, drum_radius)
			WeaponData.Kind.MAGNETIC:
				_build_magnetic(axis, dark, joint, trim, glow, barrel_length, drum_radius)
			WeaponData.Kind.BLAST:
				_build_breach(axis, dark, joint, trim, glow, barrel_length, drum_radius)
			WeaponData.Kind.CORROSION:
				_build_ferric(axis, dark, joint, trim, glow, barrel_length, drum_radius)
			WeaponData.Kind.BEAM:
				_build_lumen(axis, dark, joint, trim, glow, barrel_length, drum_radius)
			WeaponData.Kind.FLAME:
				_build_pyre(axis, dark, joint, trim, glow, barrel_length, drum_radius)
			WeaponData.Kind.SALVO:
				_build_volley(axis, dark, joint, trim, glow, barrel_length, drum_radius)
			WeaponData.Kind.SONIC:
				_build_sonic(axis, dark, joint, trim, glow, barrel_length, drum_radius)
			_:
				_build_autocannon(axis, dark, joint, trim, barrel_length, drum_radius)
	muzzle.position = axis * (0.44 + barrel_length)
	add_child(muzzle)
	# The flash silhouette itself: a brass ball for autocannons, a fat
	# bloom for scatterguns, a forward cone for flamers, a thin rail needle
	# and a flat shock disc for sonic rings. Non-spherical shapes are built
	# along +Y and re-aimed at the shot direction when the gun fires.
	match _flash_shape:
		WeaponData.FlashShape.CONE:
			_flash = MeshUtil.make_cone(0.9, 0.12, 1.6, flash_material,
					MeshUtil.SEGMENTS_LOW, "muzzle_flash")
		WeaponData.FlashShape.NEEDLE:
			_flash = MeshUtil.make_cylinder(0.28, 1.8, flash_material,
					MeshUtil.SEGMENTS_LOW, "muzzle_flash")
		WeaponData.FlashShape.DISC:
			_flash = MeshUtil.make_cylinder(1.0, 0.16, flash_material,
					MeshUtil.SEGMENTS_LOW, "muzzle_flash")
		_:
			_flash = MeshUtil.make_sphere(1.0, flash_material, MeshUtil.SEGMENTS_LOW,
					4, "muzzle_flash")
	_flash.position = muzzle.position
	_flash.visible = false
	add_child(_flash)
	_flash_light = OmniLight3D.new()
	_flash_light.name = "MuzzleLight"
	_flash_light.position = muzzle.position
	_flash_light.light_color = flash_tint
	_flash_light.omni_range = _flash_lrange
	_flash_light.light_energy = 0.0
	add_child(_flash_light)

func _build_autocannon(axis: Vector3, dark: StandardMaterial3D, joint: StandardMaterial3D,
		trim: StandardMaterial3D, barrel_length: float, drum_radius: float) -> void:
	MeshUtil.add_visual_cylinder(self, drum_radius, 0.34, axis * 0.16 + Vector3.DOWN * 0.2,
			joint, axis, "ammo_drum")
	MeshUtil.add_visual_box(self, Vector3(0.1, 0.2, 0.28), axis * 0.3 + Vector3.UP * 0.19,
			dark, 0.0, "heat_sink")
	for sink in 3:
		MeshUtil.add_visual_box(self, Vector3(0.16, 0.04, 0.3),
				axis * (0.22 + 0.07 * float(sink)) + Vector3.UP * 0.27,
				trim, 0.0, "sink_fin_%d" % sink)
	MeshUtil.add_visual_box(self, Vector3(0.2, 0.06, 0.34), axis * 0.3,
			joint, 0.0, "feed_chute")
	MeshUtil.add_visual_box(self, Vector3(0.4, 0.05, 0.1), axis * 0.28 + Vector3.UP * 0.16,
			dark, 0.0, "sight_rail")
	MeshUtil.add_visual_box(self, Vector3(0.26, 0.2, 0.045),
			axis * 0.24 + Vector3(0.0, 0.02, 0.16), trim, 0.0, "side_plate")
	MeshUtil.add_visual_cylinder(self, 0.07, 0.22, axis * -0.02,
			joint, axis, "buffer_tube")
	var cluster := Node3D.new()
	cluster.name = "BarrelCluster"
	add_child(cluster)
	for spin in 4:
		var spoke := TAU * float(spin) / 4.0
		var offset := Vector3(0.0, sin(spoke), cos(spoke)) * 0.062
		MeshUtil.add_visual_cylinder(cluster, 0.026, barrel_length,
				offset, joint, axis, "barrel_%d" % spin)
	MeshUtil.add_visual_cylinder(cluster, 0.104, barrel_length * 0.5,
			axis * (0.45 + barrel_length * 0.32), dark, axis, "heat_shroud")
	for port in 3:
		MeshUtil.add_visual_box(cluster, Vector3(0.05, 0.05, 0.05),
				axis * (0.5 + barrel_length * (0.18 + 0.16 * float(port)))
						+ Vector3.UP * 0.12,
				joint, 0.0, "shroud_port_%d" % port)
	MeshUtil.add_visual_cylinder(cluster, 0.14, 0.16, axis * (0.36 + barrel_length),
			trim, axis, "muzzle_brake")
	for side_port in [1.0, -1.0]:
		MeshUtil.add_visual_box(cluster, Vector3(0.09, 0.07, 0.04),
				axis * (0.4 + barrel_length) + Vector3(0.0, 0.0, side_port * 0.13),
				joint, 0.0, "brake_vent")
	MeshUtil.add_visual_box(self, Vector3(0.05, 0.1, 0.03),
			axis * (0.44 + barrel_length) + Vector3.UP * 0.14, trim, 0.0, "front_sight")
	_bind_anim(Anim.SPIN_BARRELS, [cluster])

func _build_scattergun(axis: Vector3, dark: StandardMaterial3D, joint: StandardMaterial3D,
		trim: StandardMaterial3D, barrel_length: float, drum_radius: float) -> void:
	MeshUtil.add_visual_cylinder(self, drum_radius, 0.4, axis * 0.14 + Vector3.DOWN * 0.18,
			joint, axis, "ammo_drum")
	var drum_center := axis * 0.14 + Vector3.DOWN * 0.18
	for shell in 5:
		var angle := TAU * float(shell) / 5.0
		var ring := Vector3(0.0, sin(angle), cos(angle)) * drum_radius * 0.92
		MeshUtil.add_visual_cylinder(self, 0.042, 0.14, drum_center + ring,
				trim, axis, "shell_%d" % shell)
	MeshUtil.add_visual_box(self, Vector3(0.3, 0.24, 0.4), axis * 0.42,
			dark, 0.0, "barrel_shroud")
	var pump := MeshUtil.add_visual_box(self, Vector3(0.24, 0.1, 0.16),
			axis * 0.46 + Vector3.DOWN * 0.15, joint, 0.0, "pump_grip")
	for grip in 3:
		MeshUtil.add_visual_box(self, Vector3(0.05, 0.12, 0.17),
				axis * (0.4 + 0.06 * float(grip)) + Vector3.DOWN * 0.15,
				trim, 0.0, "grip_ring_%d" % grip)
	MeshUtil.add_visual_box(self, Vector3(0.42, 0.05, 0.12), axis * 0.34 + Vector3.UP * 0.17,
			dark, 0.0, "top_rib")
	for offset in [0.1, -0.06, -0.14]:
		var stub_axis := Vector3(axis.x, 0.0, offset)
		MeshUtil.add_visual_cylinder(self, 0.05, barrel_length,
				axis * (0.44 + barrel_length * 0.5) + Vector3(0.0, 0.06, offset),
				trim, stub_axis.normalized(), "barrel_%s" % str(offset))
		MeshUtil.add_visual_cylinder(self, 0.062, 0.06,
				axis * (0.42 + barrel_length) + Vector3(0.0, 0.06, offset),
				dark, stub_axis.normalized(), "choke_%s" % str(offset))
	MeshUtil.add_visual_cylinder(self, 0.17, 0.1, axis * (0.4 + barrel_length),
			trim, axis, "muzzle_brake")
	MeshUtil.add_visual_box(self, Vector3(0.28, 0.18, 0.04),
			axis * 0.3 + Vector3(0.0, 0.0, 0.19), trim, 0.0, "side_plate")
	_bind_anim(Anim.PUMP_SLIDE, [pump])

func _build_electric(axis: Vector3, dark: StandardMaterial3D, joint: StandardMaterial3D,
		trim: StandardMaterial3D, glow: StandardMaterial3D, barrel_length: float,
		drum_radius: float) -> void:
	MeshUtil.add_visual_box(self, Vector3(0.4, 0.34, 0.46), axis * 0.18 + Vector3.UP * 0.05,
			dark, 0.0, "coil_housing")
	for cap_side in [1.0, -1.0]:
		MeshUtil.add_visual_cylinder(self, 0.085, 0.3,
				axis * 0.16 + Vector3.UP * 0.26 + Vector3(0.0, 0.0, cap_side * 0.13),
				joint, Vector3.UP, "capacitor")
		MeshUtil.add_visual_cylinder(self, 0.095, 0.05,
				axis * 0.16 + Vector3.UP * 0.42 + Vector3(0.0, 0.0, cap_side * 0.13),
				trim, Vector3.UP, "capacitor_cap")
		MeshUtil.add_visual_box(self, Vector3(0.16, 0.1, 0.07),
				axis * 0.2 + Vector3(0.0, 0.0, cap_side * 0.24), joint, 0.0,
				"bus_block")
	var core := MeshUtil.add_visual_cylinder(self, 0.065, barrel_length * 0.92,
			axis * (0.42 + barrel_length * 0.5), glow, axis, "energy_core")
	var coils := 4
	for index in coils:
		var t := 0.18 + 0.68 * (float(index) / float(maxi(coils - 1, 1)))
		MeshUtil.add_visual_cylinder(self, drum_radius * 0.72 + 0.06, 0.06,
				axis * (0.42 + barrel_length * t), trim, axis, "coil_ring")
	MeshUtil.add_visual_box(self, Vector3(0.3, 0.3, 0.06), axis * 0.3,
			joint, 0.0, "vent_plate")
	for fin in 3:
		MeshUtil.add_visual_box(self, Vector3(0.03, 0.16, 0.1),
				axis * (0.24 + 0.07 * float(fin)) + Vector3.UP * 0.14,
				trim, 0.0, "cool_fin_%d" % fin)
	MeshUtil.add_visual_cylinder(self, 0.15, 0.1, axis * (0.38 + barrel_length),
			trim, axis, "emitter_ring")
	MeshUtil.add_visual_cylinder(self, 0.1, 0.03, axis * (0.42 + barrel_length),
			glow, axis, "emitter_glow")
	for prong in [1.0, -1.0]:
		var prong_dir := (axis + Vector3(0.0, 0.22, prong * 0.3)).normalized()
		MeshUtil.add_visual_cylinder(self, 0.025, 0.3,
				axis * (0.44 + barrel_length) + prong_dir * 0.14,
				trim, prong_dir, "electrode_prong")
		MeshUtil.sph_at(self, 0.045,
				axis * (0.44 + barrel_length) + prong_dir * 0.3,
				glow, "prong_ball")
	_bind_anim(Anim.CORE_THROB, [core])

func heat_ratio() -> float:
	return heat

func is_overheated() -> bool:
	return overheated

# Hull side this mount fires from (+1 right / -1 left) — the component-damage
# router uses it to decide which guns a flank hit shakes apart.
func side() -> float:
	return _side

func is_destroyed() -> bool:
	return destroyed

# Blows the gun off the hull: quenches heat/reload state, kills the flash and
# hides every visual. Never frees the node (muzzle marker + rig arrays keep
# pointing at it), so the rest of the combat code can treat it as inert.
func mark_destroyed() -> void:
	if destroyed:
		return
	destroyed = true
	heat = 0.0
	overheated = false
	_reload_left = 0.0
	_flash_time = 0.0
	_recoil = 0.0
	_recoil_velocity = 0.0
	if _flash != null:
		_flash.visible = false
	if _flash_light != null:
		_flash_light.light_energy = 0.0
	if _smoke != null:
		_smoke.emitting = false
	visible = false

func is_reloading() -> bool:
	return _reload_left > 0.0

func ammo_left() -> int:
	return _ammo

func is_supercharged() -> bool:
	return _supercharged

func reload_ratio() -> float:
	if data == null or data.reload_time <= 0.0 or _reload_left <= 0.0:
		return 0.0
	return clampf(1.0 - _reload_left / data.reload_time, 0.0, 1.0)

func try_fire(exclude: Array[RID], camera_dir: Vector3 = Vector3.ZERO,
		lock_anchor: Variant = null) -> bool:
	if destroyed or data == null or overheated or _cooldown > 0.0 or _reload_left > 0.0 \
			or muzzle == null:
		return false
	if data.magazine > 0 and _ammo <= 0:
		_begin_reload()
		return false
	var origin := muzzle.global_position
	var direction: Vector3
	if lock_anchor != null:
		direction = ((lock_anchor as Vector3) - origin).normalized()
	elif camera_dir.length_squared() > 0.0001:
		direction = camera_dir.normalized()
	else:
		direction = (global_basis * Vector3(_side, 0.0, 0.0)).normalized()
	var fired: int = 0
	var beam_points: Array[Vector3] = []
	if data.lock_beam:
		beam_points = _beam_path(origin, direction, lock_anchor, exclude)
		if not beam_points.is_empty():
			_beam_strike()
			fired = 1
	else:
		var shot_damage := -1.0
		if _supercharged and data.supercharge_damage_mult != 1.0:
			shot_damage = data.damage * data.supercharge_damage_mult
		for pellet in data.pellets:
			if Projectiles.fire(origin, _spread(direction), data, exclude, shot_damage):
				fired += 1
	if fired == 0:
		return false
	if data.magazine > 0:
		_ammo = maxi(_ammo - 1, 0)
		if _ammo <= 0:
			_begin_reload()
	heat = minf(1.0, heat + data.heat_per_shot)
	_cooldown = data.shot_interval()
	_recoil_velocity -= data.recoil * RECOIL_STIFFNESS
	_flash_time = _flash_life
	_flash.visible = true
	_aim_flash(direction)
	_flash_light.light_energy = _flash_lenergy
	_puff_muzzle_smoke()
	_kick_animation()
	if not beam_points.is_empty():
		BeamEffect.spawn(self, beam_points, data.tracer_color, data.tracer_radius)
	Events.weapon_fired.emit(mount_index, data.kind, StringName(data.family),
			int(data.size))
	Events.camera_shake_requested.emit(data.shake, 0.08)
	return true

# Points the muzzle bloom down the barrel: every flash silhouette is built so
# that +Y is the "long" axis, so the shape (and its stretch) follows the shot
# instead of the mount's rest frame.
func _aim_flash(direction: Vector3) -> void:
	var local := global_basis.inverse() * direction
	if local.length_squared() < 0.000001:
		_flash.basis = Basis()
		return
	_flash.basis = MeshUtil.segment_basis(local.normalized())

# Propellant smoke puff at the barrel — one reusable one-shot system.
func _puff_muzzle_smoke() -> void:
	if _smoke == null:
		_smoke = CPUParticles3D.new()
		_smoke.name = "MuzzleSmoke"
		_smoke.one_shot = true
		_smoke.amount = 10
		_smoke.lifetime = 0.55
		_smoke.explosiveness = 1.0
		_smoke.spread = 70.0
		_smoke.gravity = Vector3(0.0, 1.8, 0.0)
		_smoke.initial_velocity_min = 1.4
		_smoke.initial_velocity_max = 3.4
		_smoke.scale_amount_min = 0.5
		_smoke.scale_amount_max = 1.5
		var fade := Gradient.new()
		fade.colors = PackedColorArray([Color(1.0, 1.0, 1.0, 0.55),
				Color(1.0, 1.0, 1.0, 0.3), Color(1.0, 1.0, 1.0, 0.0)])
		fade.offsets = PackedFloat32Array([0.0, 0.5, 1.0])
		_smoke.color_ramp = fade
		var material := StandardMaterial3D.new()
		material.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
		material.albedo_color = Color(0.32, 0.3, 0.29, 1.0)
		material.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
		material.vertex_color_use_as_albedo = true
		material.depth_draw_mode = BaseMaterial3D.DEPTH_DRAW_DISABLED
		var puff := SphereMesh.new()
		puff.radius = 0.22
		puff.height = 0.44
		puff.radial_segments = 6
		puff.rings = 3
		puff.material = material
		_smoke.mesh = puff
		_smoke.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
		_smoke.position = muzzle.position
		add_child(_smoke)
	_smoke.direction = Vector3(float(_side), 0.25, 0.0).normalized()
	_smoke.restart()
	_smoke.emitting = true

# War Robots LUMEN behaviour: the beam aims straight at the locked hull and,
# when cover sits on that line, bends over/around it to keep contact.
# Returns the polyline (origin first) to draw, or an empty array when blocked.
func _beam_path(origin: Vector3, direction: Vector3, lock_anchor: Variant,
		exclude: Array[RID]) -> Array[Vector3]:
	_beam_collider = null
	var locked := lock_anchor != null
	var aim := origin + direction * data.beam_range
	if locked:
		aim = lock_anchor as Vector3
	var hit := _beam_ray(origin, aim, exclude)
	var collider: Variant = hit.get("collider") if not hit.is_empty() else null
	if _beam_damageable(collider):
		_take_beam_hit(hit)
		return [origin, _beam_point]
	if locked:
		var bent := _beam_curve(origin, aim, exclude)
		if not bent.is_empty():
			return bent
	if not hit.is_empty():
		return [origin, hit["position"]]
	return [origin, aim]

func _beam_curve(origin: Vector3, target: Vector3, exclude: Array[RID]) -> Array[Vector3]:
	var flat := Vector3(target.x - origin.x, 0.0, target.z - origin.z)
	var side := flat.cross(Vector3.UP)
	side = side.normalized() if side.length_squared() > 0.0001 else Vector3.RIGHT
	var spawn := origin.lerp(target, 0.45)
	var bends: Array[Vector3] = []
	for height in BEAM_BEND_HEIGHTS:
		bends.append(spawn + Vector3.UP * height)
	for distance in BEAM_BEND_SIDES:
		bends.append(spawn + side * distance)
		bends.append(spawn - side * distance)
	var best_hit := Dictionary()
	var best_bend := Vector3.ZERO
	var best_length := INF
	for bend: Vector3 in bends:
		var nodes := PackedVector3Array([bend])
		var hit := _beam_probe(origin, nodes, target, exclude)
		if hit.is_empty():
			continue
		var length: float = origin.distance_to(bend) + bend.distance_to(target)
		if length < best_length:
			best_length = length
			best_hit = hit
			best_bend = bend
	if best_hit.is_empty():
		return _beam_s_curve(origin, target, side, spawn, exclude)
	_take_beam_hit(best_hit)
	return [origin, best_bend, _beam_point]

func _beam_s_curve(origin: Vector3, target: Vector3, side: Vector3, spawn: Vector3,
		exclude: Array[RID]) -> Array[Vector3]:
	var rises: Array[Vector3] = []
	var bends: Array[Vector3] = []
	for height in BEAM_BEND_HEIGHTS:
		var rise := spawn + Vector3.UP * height
		for distance in BEAM_BEND_SIDES:
			rises.append(rise)
			bends.append(rise + side * distance)
			rises.append(rise)
			bends.append(rise - side * distance)
	var best_hit := Dictionary()
	var best_rise := Vector3.ZERO
	var best_bend := Vector3.ZERO
	var best_length := INF
	for index in rises.size():
		var rise: Vector3 = rises[index]
		var bend: Vector3 = bends[index]
		var nodes := PackedVector3Array([rise, bend])
		var hit := _beam_probe(origin, nodes, target, exclude)
		if hit.is_empty():
			continue
		var length: float = origin.distance_to(rise) + rise.distance_to(bend) \
				+ bend.distance_to(target)
		if length < best_length:
			best_length = length
			best_hit = hit
			best_rise = rise
			best_bend = bend
	if best_hit.is_empty():
		return []
	_take_beam_hit(best_hit)
	return [origin, best_rise, best_bend, _beam_point]

func _beam_probe(origin: Vector3, nodes: PackedVector3Array, target: Vector3,
		exclude: Array[RID]) -> Dictionary:
	var previous := origin
	for node: Vector3 in nodes:
		if not _beam_segment_clear(previous, node, exclude):
			return {}
		previous = node
	if not _beam_segment_clear(previous, target, exclude):
		return {}
	var hit := _beam_ray(previous, target, exclude)
	var collider: Variant = hit.get("collider") if not hit.is_empty() else null
	if not _beam_damageable(collider):
		return {}
	return hit

func _beam_segment_clear(from: Vector3, to: Vector3, exclude: Array[RID]) -> bool:
	if not _beam_clear(from, to, exclude):
		return false
	for step in BEAM_SEGMENT_SAMPLES:
		var a: Vector3 = from.lerp(to, float(step) / float(BEAM_SEGMENT_SAMPLES))
		var b: Vector3 = from.lerp(to, float(step + 1) / float(BEAM_SEGMENT_SAMPLES))
		if not _beam_clear(a, b, exclude):
			return false
	return true

func _beam_strike() -> void:
	if _beam_collider == null:
		return
	var node := _beam_collider as Node
	if node != null and node.has_method("receive_damage"):
		node.call("receive_damage", data.damage, _beam_point)
		if data.thermal_breach and node.has_method("apply_thermal_breach"):
			node.call("apply_thermal_breach", 1)
	Events.weapon_impact.emit(_beam_point, _beam_normal, data.kind)

func _beam_damageable(collider: Variant) -> bool:
	return collider is Node and (collider as Node).has_method("receive_damage")

func _take_beam_hit(hit: Dictionary) -> void:
	_beam_collider = hit.get("collider")
	_beam_point = hit["position"]
	_beam_normal = hit["normal"]

func _beam_ray(from: Vector3, to: Vector3, exclude: Array[RID]) -> Dictionary:
	var world := get_world_3d()
	if world == null:
		return {}
	_beam_query.from = from
	_beam_query.to = to
	_beam_query.collision_mask = Layers.PROJECTILE_MASK
	_beam_query.collide_with_areas = false
	_beam_query.collide_with_bodies = true
	_beam_query.exclude = exclude
	return world.direct_space_state.intersect_ray(_beam_query)

func _beam_clear(from: Vector3, to: Vector3, exclude: Array[RID]) -> bool:
	var world := get_world_3d()
	if world == null:
		return false
	_beam_clear_query.from = from
	_beam_clear_query.to = to
	_beam_clear_query.collision_mask = Layers.WORLD
	_beam_clear_query.collide_with_areas = false
	_beam_clear_query.collide_with_bodies = true
	_beam_clear_query.exclude = exclude
	return world.direct_space_state.intersect_ray(_beam_clear_query).is_empty()

func _begin_reload() -> void:
	if data == null or data.reload_time <= 0.0 or _reload_left > 0.0:
		return
	_reload_left = data.reload_time
	_reload_pulse = 0.0
	Events.weapon_reload_started.emit()

# Reload-phase suppression core (VOID/CHASH): the refilling gun beats on
# everything enemy within suppression_radius — damage + Suppression debuff.
func _pulse_suppression() -> void:
	var world := get_world_3d()
	if world == null or muzzle == null:
		return
	_suppression_shape.radius = data.suppression_radius
	var params := PhysicsShapeQueryParameters3D.new()
	params.shape = _suppression_shape
	params.collision_mask = Layers.ENEMY
	params.transform = Transform3D(Basis.IDENTITY, muzzle.global_position)
	params.collide_with_areas = false
	params.collide_with_bodies = true
	var results := world.direct_space_state.intersect_shape(params, 16)
	for result in results:
		var body: Variant = result.get("collider")
		if body is EnemyRobot:
			var enemy := body as EnemyRobot
			enemy.apply_suppression(data.suppression_duration)
			enemy.receive_damage(data.suppression_damage,
					enemy.global_position + Vector3.UP * 1.4)

func _physics_process(delta: float) -> void:
	if data == null or destroyed:
		return
	_cooldown = maxf(_cooldown - delta, 0.0)
	if _reload_left > 0.0:
		_reload_left = maxf(_reload_left - delta, 0.0)
		if data.suppression_radius > 0.0:
			_reload_pulse -= delta
			if _reload_pulse <= 0.0:
				_reload_pulse = maxf(data.suppression_pulse, 0.1)
				_pulse_suppression()
		if _reload_left <= 0.0:
			_ammo = data.magazine
			_supercharged = true
	var cooling: float = data.cooldown_rate * delta
	if overheated:
		cooling *= 1.7
	if not overheated and heat >= 1.0:
		overheated = true
	heat = maxf(heat - cooling, 0.0)
	if overheated and heat <= data.overheat_lock:
		overheated = false

func _process(delta: float) -> void:
	if data == null or destroyed:
		return
	_recoil_velocity -= _recoil * RECOIL_STIFFNESS * delta
	_recoil_velocity *= clampf(1.0 - RECOIL_DAMPING * delta, 0.0, 1.0)
	_recoil = clampf(_recoil + _recoil_velocity * delta, -data.recoil * 0.5, data.recoil * 1.5)
	position = Vector3(_side * _recoil, 0.0, 0.0)
	rotation.z = -_recoil * 0.9
	if _flash_time > 0.0:
		_flash_time -= delta
		var ratio := clampf(_flash_time / _flash_life, 0.0, 1.0)
		var base := data.muzzle_scale
		# Mesh-local Y is the shot direction (set by _aim_flash), so the
		# stretch always runs down the barrel. Each silhouette grows and
		# fades on its own curve: a bloom expands, a cone flares then dies,
		# a rail needle snaps, a sonic disc rings outward.
		match _flash_shape:
			WeaponData.FlashShape.PUFF:
				var puff := base * (0.7 + 0.9 * (1.0 - ratio))
				_flash.scale = Vector3(puff * 1.35, puff * _flash_stretch * 0.7,
						puff * 1.35)
			WeaponData.FlashShape.CONE:
				var cone := base * (0.6 + 0.7 * ratio)
				_flash.scale = Vector3(cone * 0.9, cone * _flash_stretch,
						cone * 0.9)
			WeaponData.FlashShape.NEEDLE:
				var needle := base * (0.85 + 0.5 * ratio)
				_flash.scale = Vector3(needle * 0.5, needle * _flash_stretch,
						needle * 0.5)
			WeaponData.FlashShape.DISC:
				var ring := base * (0.75 + 1.0 * (1.0 - ratio))
				_flash.scale = Vector3(ring * 1.6, ring * 0.22, ring * 1.6)
			_:
				var ball := base * (0.55 + 0.75 * ratio)
				_flash.scale = Vector3(ball, ball * _flash_stretch, ball)
		_flash_light.light_energy = ratio * _flash_lenergy
		if _flash_time <= 0.0:
			_flash.visible = false
			_flash_light.light_energy = 0.0
	_animate(delta)

# Records the parts a family animates and their rest transforms. The optional
# material is only safe for builder-local materials (VOID's violet), never for
# the rig-shared sensor/trim materials.
func _bind_anim(kind: Anim, parts: Array[Node3D], material: StandardMaterial3D = null) -> void:
	_anim_kind = kind
	_anim_parts = parts
	_anim_rest_pos.clear()
	_anim_rest_rot.clear()
	_anim_rest_scale.clear()
	for part in parts:
		_anim_rest_pos.append(part.position)
		_anim_rest_rot.append(part.rotation)
		_anim_rest_scale.append(part.scale)
	_anim_material = material
	if material != null:
		_anim_material_base = material.emission_energy_multiplier

# Restarts the family's cycle on a successful shot.
func _kick_animation() -> void:
	_anim_timer = 0.0
	if _anim_kind == Anim.TUBE_SEQUENCE and not _anim_parts.is_empty():
		_anim_index = (_anim_index + 1) % _anim_parts.size()
	elif _anim_kind == Anim.SPIN_BARRELS:
		_anim_speed = maxf(_anim_speed, ANIM_SPIN_KICK)

func _animate(delta: float) -> void:
	if _anim_kind == Anim.NONE or _anim_parts.is_empty():
		return
	_anim_timer += delta
	_anim_phase += delta
	var since := _anim_timer
	var pulse := exp(-since * ANIM_PULSE_DECAY)
	match _anim_kind:
		Anim.SPIN_BARRELS:
			# Each shot kicks the cluster up to burst speed; it coasts back down
			# to a slow idle spin between bursts like a rotary cannon.
			_anim_speed = maxf(_anim_speed - ANIM_SPIN_DECAY * delta, ANIM_SPIN_IDLE)
			for index in _anim_parts.size():
				var part := _anim_parts[index]
				part.rotation.x += _anim_speed * delta
		Anim.PUMP_SLIDE:
			var travel := sin(clampf(since / ANIM_PUMP_DURATION, 0.0, 1.0) * PI)
			var offset := travel * ANIM_PUMP_TRAVEL
			var part := _anim_parts[0]
			part.position = _anim_rest_pos[0] + Vector3(_side * offset, 0.0, 0.0)
		Anim.CORE_THROB:
			var hold := clampf(_flash_time / FLASH_TIME, 0.0, 1.0)
			var swell := 1.0 + 0.4 * maxf(pulse, hold)
			for index in _anim_parts.size():
				_anim_parts[index].scale = _anim_rest_scale[index] * swell
			if _anim_material != null:
				_anim_material.emission_energy_multiplier = \
						_anim_material_base * (1.0 + 1.6 * maxf(pulse, hold))
		Anim.TUBE_SEQUENCE:
			var count := _anim_parts.size()
			var step := _anim_index
			if pulse > 0.15:
				step = int(_anim_phase * 9.0) % count
			for index in count:
				var lit := 1.0
				if index == step:
					lit = lerpf(2.1, 1.0, clampf(since * 4.0, 0.0, 1.0))
				_anim_parts[index].scale = _anim_rest_scale[index] * lit
		Anim.NEEDLE_WOBBLE:
			# Needle rests deflected by weapon heat and jitters after each shot.
			var wobble := sin(since * 44.0) * 0.5 * pulse + heat * 0.7
			var part := _anim_parts[0]
			part.rotation.z = _anim_rest_rot[0].z + wobble
		Anim.FLAME_FLICKER:
			var flicker := 1.0 + 0.24 * sin(_anim_phase * 29.0) \
					+ 0.14 * sin(_anim_phase * 63.0)
			_anim_parts[0].scale = _anim_rest_scale[0] * maxf(flicker, 0.25) \
					* (1.0 + 0.35 * pulse)

func _spread(direction: Vector3) -> Vector3:
	var frame := MeshUtil.segment_basis(direction)
	var angle := deg_to_rad(data.spread_degrees)
	var offset := frame.x * randf_range(-angle, angle) + frame.z * randf_range(-angle, angle)
	return (direction + offset).normalized()

func _build_magnetic(axis: Vector3, dark: StandardMaterial3D, joint: StandardMaterial3D,
		trim: StandardMaterial3D, glow: StandardMaterial3D, barrel_length: float,
		drum_radius: float) -> void:
	MeshUtil.add_visual_box(self, Vector3(0.36, 0.3, 0.44), axis * 0.16,
			dark, 0.0, "rail_base")
	MeshUtil.add_visual_box(self, Vector3(0.5, 0.07, 0.16),
			axis * 0.34 + Vector3.UP * 0.18, trim, 0.0, "rail_spine")
	for side in [1.0, -1.0]:
		MeshUtil.add_visual_cylinder(self, 0.045, barrel_length,
				axis * (0.42 + barrel_length * 0.5) + Vector3(0.0, 0.1, side * 0.1),
				trim, axis, "rail_prong")
		MeshUtil.add_visual_box(self, Vector3(0.2, 0.06, 0.05),
				axis * 0.3 + Vector3(0.0, 0.1, side * 0.16), joint, 0.0, "prong_brace")
		MeshUtil.sph_at(self, 0.035,
				axis * (0.42 + barrel_length) + Vector3(0.0, 0.1, side * 0.1),
				glow, "prong_tip")
	for coil_index in 3:
		var t := 0.25 + 0.25 * float(coil_index)
		MeshUtil.add_visual_cylinder(self, drum_radius * 0.55 + 0.05, 0.07,
				axis * (0.42 + barrel_length * t), joint, axis, "coil_ring")
	for bank in 3:
		MeshUtil.add_visual_cylinder(self, 0.055, 0.18,
				axis * (0.1 + 0.1 * float(bank)) + Vector3.DOWN * 0.14
				+ Vector3(0.0, 0.0, 0.2),
				joint, Vector3.UP, "cell_bank_%d" % bank)
	var orb := MeshUtil.sph_at(self, 0.11, axis * (0.42 + barrel_length), glow,
			"charge_orb")
	MeshUtil.add_visual_box(self, Vector3(0.26, 0.22, 0.3), axis * 0.2 + Vector3.DOWN * 0.16,
			joint, 0.0, "cap_bank")
	MeshUtil.add_visual_box(self, Vector3(0.1, 0.14, 0.05),
			axis * -0.04 + Vector3.UP * 0.14, dark, 0.0, "rear_block")
	MeshUtil.cone_at(self, 0.09, 0.04, 0.12,
			axis * -0.1, Vector3(0.0, 0.0, 90.0 * axis.x), joint, "rear_vent")
	for fin in 2:
		MeshUtil.add_visual_box(self, Vector3(0.04, 0.14, 0.03),
				axis * (0.4 + barrel_length * (0.35 + 0.45 * float(fin)))
						+ Vector3.UP * 0.12 + Vector3(0.0, 0.0, 0.1),
				trim, 0.0, "sight_fin_%d" % fin)
	_bind_anim(Anim.CORE_THROB, [orb])

func _build_breach(axis: Vector3, dark: StandardMaterial3D, joint: StandardMaterial3D,
		trim: StandardMaterial3D, glow: StandardMaterial3D, barrel_length: float,
		drum_radius: float) -> void:
	MeshUtil.add_visual_cylinder(self, drum_radius + 0.03, 0.44, axis * 0.14,
			joint, axis, "shell_drum")
	MeshUtil.add_visual_box(self, Vector3(0.4, 0.36, 0.5), axis * 0.3,
			dark, 0.0, "breech_block")
	for shell in 4:
		var angle := TAU * float(shell) / 4.0 + 0.4
		var ring := Vector3(0.0, sin(angle), cos(angle)) * (drum_radius + 0.04)
		MeshUtil.add_visual_cylinder(self, 0.05, 0.2, axis * 0.14 + ring,
				trim, axis, "spare_shell_%d" % shell)
	MeshUtil.add_visual_box(self, Vector3(0.6, 0.06, 0.18),
			axis * (0.4 + barrel_length * 0.4) + Vector3.DOWN * 0.14, trim, 0.0, "launch_rail")
	MeshUtil.add_visual_box(self, Vector3(0.08, 0.3, 0.14),
			axis * 0.1 + Vector3.DOWN * 0.22, joint, 0.0, "grip_fin")
	MeshUtil.add_visual_cylinder(self, 0.14, barrel_length,
			axis * (0.46 + barrel_length * 0.5), trim, axis, "short_barrel")
	MeshUtil.add_visual_cylinder(self, 0.2, 0.18,
			axis * (0.4 + barrel_length), trim, axis, "breach_muzzle")
	for vent in [1.0, -1.0]:
		MeshUtil.add_visual_box(self, Vector3(0.1, 0.08, 0.16),
				axis * 0.34 + Vector3(0.0, 0.2, vent * 0.14), joint, 0.0, "vent")
	MeshUtil.add_visual_box(self, Vector3(0.2, 0.16, 0.24),
			axis * 0.22 + Vector3.DOWN * 0.2, glow, 0.0, "warhead_glow")
	MeshUtil.add_visual_box(self, Vector3(0.05, 0.26, 0.34),
			axis * (0.34 + barrel_length * 0.75), trim, 0.0, "blast_shield")
	MeshUtil.add_visual_box(self, Vector3(0.14, 0.1, 0.4),
			axis * 0.24 + Vector3.UP * 0.2, joint, 0.0, "sight_box")

func _build_ferric(axis: Vector3, dark: StandardMaterial3D, joint: StandardMaterial3D,
		trim: StandardMaterial3D, glow: StandardMaterial3D, barrel_length: float,
		drum_radius: float) -> void:
	MeshUtil.add_visual_box(self, Vector3(0.32, 0.28, 0.42), axis * 0.16,
			dark, 0.0, "corroder_body")
	var tank_center := axis * 0.12 + Vector3.DOWN * 0.14
	MeshUtil.add_visual_cylinder(self, drum_radius * 0.8, 0.3, tank_center,
			joint, axis, "agent_tank")
	for strap in [0.1, -0.1]:
		MeshUtil.add_visual_cylinder(self, drum_radius * 0.8 + 0.015, 0.035,
				tank_center + axis * strap, trim, axis, "tank_strap")
	for hose_index in 4:
		var t := float(hose_index) / 3.0
		MeshUtil.add_visual_cylinder(self, 0.028, 0.1,
				axis * (0.2 + 0.12 * t) + Vector3(0.0, 0.13, 0.2 - 0.05 * float(hose_index)),
				trim, Vector3(axis.x, 0.2, 0.0).normalized(), "hose_%d" % hose_index)
	MeshUtil.add_visual_cylinder(self, 0.06, barrel_length,
			axis * (0.44 + barrel_length * 0.5), glow, axis, "etch_barrel")
	for band in [0.3, 0.55, 0.8]:
		MeshUtil.add_visual_cylinder(self, 0.09, 0.05,
				axis * (0.44 + barrel_length * band), trim, axis, "band")
	MeshUtil.add_visual_cylinder(self, 0.12, 0.1,
			axis * (0.4 + barrel_length), joint, axis, "nozzle")
	MeshUtil.sph_at(self, 0.07, axis * (0.44 + barrel_length), glow, "drip_glow")
	MeshUtil.add_visual_cylinder(self, 0.07, 0.02,
			axis * 0.2 + Vector3.UP * 0.19, trim, Vector3.UP, "gauge_dial")
	var needle := MeshUtil.add_visual_box(self, Vector3(0.03, 0.06, 0.03),
			axis * 0.2 + Vector3.UP * 0.22, joint, 0.0, "gauge_needle")
	MeshUtil.add_visual_box(self, Vector3(0.24, 0.05, 0.1),
			axis * 0.34 + Vector3.UP * 0.18, dark, 0.0, "top_rail")
	_bind_anim(Anim.NEEDLE_WOBBLE, [needle])

func _build_lumen(axis: Vector3, dark: StandardMaterial3D, joint: StandardMaterial3D,
		trim: StandardMaterial3D, glow: StandardMaterial3D, barrel_length: float,
		drum_radius: float) -> void:
	MeshUtil.add_visual_box(self, Vector3(0.3, 0.26, 0.4), axis * 0.16,
			dark, 0.0, "emitter_base")
	MeshUtil.add_visual_cylinder(self, 0.07, barrel_length,
			axis * (0.42 + barrel_length * 0.5), trim, axis, "emitter_tube")
	MeshUtil.add_visual_cylinder(self, drum_radius * 0.7, 0.22, axis * 0.12 + Vector3.DOWN * 0.1,
			joint, axis, "capacitor")
	MeshUtil.add_visual_box(self, Vector3(0.34, 0.1, 0.08),
			axis * 0.16 + Vector3(0.0, 0.06, 0.2), glow, 0.0, "glow_strip_side")
	MeshUtil.add_visual_box(self, Vector3(0.34, 0.1, 0.08),
			axis * 0.16 + Vector3(0.0, 0.06, -0.2), glow, 0.0, "glow_strip_side2")
	for ring in [0.35, 0.65, 0.9]:
		MeshUtil.add_visual_cylinder(self, 0.1, 0.05,
				axis * (0.42 + barrel_length * ring), glow, axis, "lumen_ring")
	for fin in 3:
		MeshUtil.add_visual_box(self, Vector3(0.04, 0.18, 0.05),
				axis * (0.06 + 0.07 * float(fin)) + Vector3.UP * 0.2,
				trim, 0.0, "vent_fin_%d" % fin)
	var lens := MeshUtil.cone_at(self, 0.12, 0.045, 0.16,
			axis * (0.42 + barrel_length - 0.08),
			Vector3(0.0, 0.0, -90.0 * axis.x), glow, "lens_cone")
	var tip := MeshUtil.sph_at(self, 0.09, axis * (0.42 + barrel_length), glow,
			"emitter_tip")
	MeshUtil.add_visual_box(self, Vector3(0.16, 0.2, 0.24),
			axis * 0.24 + Vector3.DOWN * 0.14, joint, 0.0, "coil_pack")
	MeshUtil.add_visual_cylinder(self, 0.045, 0.24,
			axis * 0.4 + Vector3.DOWN * 0.13, trim, axis, "foregrip")
	_bind_anim(Anim.CORE_THROB, [lens, tip])

# ECHO sonic cannon: resonator drum with emitter coils, driver block, wave
# guide and a flared pressure horn that opens toward the muzzle.
func _build_sonic(axis: Vector3, dark: StandardMaterial3D, joint: StandardMaterial3D,
		trim: StandardMaterial3D, glow: StandardMaterial3D, barrel_length: float,
		drum_radius: float) -> void:
	var drum := MeshUtil.add_visual_cylinder(self, drum_radius + 0.02, 0.4, axis * 0.14,
			joint, axis, "resonator_drum")
	for ring in 3:
		MeshUtil.add_visual_cylinder(self, drum_radius * (1.22 - 0.1 * float(ring)),
				0.05, axis * (0.28 + 0.13 * float(ring)), trim, axis,
				"sonic_ring_%d" % ring)
	MeshUtil.add_visual_box(self, Vector3(0.3, 0.24, 0.38), axis * 0.3 + Vector3.UP * 0.05,
			dark, 0.0, "driver_block")
	MeshUtil.add_visual_cylinder(self, 0.05, barrel_length,
			axis * (0.46 + barrel_length * 0.5), trim, axis, "wave_guide")
	for flare in 3:
		MeshUtil.add_visual_cylinder(self, 0.06 + 0.05 * float(flare), 0.07,
				axis * (0.44 + barrel_length - 0.21 + 0.07 * float(flare)),
				joint, axis, "horn_flare_%d" % flare)
	MeshUtil.add_visual_cylinder(self, 0.17, 0.05,
			axis * (0.44 + barrel_length), glow, axis, "horn_mouth")
	for fin in 3:
		MeshUtil.add_visual_box(self, Vector3(0.05, 0.16, 0.06),
				axis * (0.1 + 0.08 * float(fin)) + Vector3.UP * 0.22,
				trim, 0.0, "sonic_fin_%d" % fin)
	MeshUtil.add_visual_box(self, Vector3(0.2, 0.18, 0.24),
			axis * 0.2 + Vector3.DOWN * 0.18, joint, 0.0, "pulse_cell")
	MeshUtil.sph_at(self, 0.06, axis * (0.34 + drum_radius), glow, "charge_lens")
	_bind_anim(Anim.CORE_THROB, [drum])

# VOID / CHASH gravitic cannon: grav cell with a glowing singularity core,
# twin gravity coils, stabiliser fins and a twin-ring yoke at the muzzle.
func _build_void(axis: Vector3, dark: StandardMaterial3D, joint: StandardMaterial3D,
		trim: StandardMaterial3D, glow: StandardMaterial3D, barrel_length: float,
		drum_radius: float) -> void:
	var violet := MeshUtil.make_material(Color(0.5, 0.34, 1.0), 0.2, 0.35,
			Color(0.6, 0.4, 1.0), 3.0)
	MeshUtil.add_visual_cylinder(self, drum_radius + 0.03, 0.44, axis * 0.16,
			joint, axis, "grav_cell")
	var core := MeshUtil.sph_at(self, 0.15, axis * 0.28 + Vector3.UP * 0.06, violet,
			"singularity_core")
	for coil in 2:
		MeshUtil.add_visual_cylinder(self, 0.11, barrel_length * 0.55,
				axis * (0.5 + barrel_length * 0.28)
						+ Vector3(0.0, 0.08, (float(coil) - 0.5) * 0.22),
				trim, axis, "gravity_coil_%d" % coil)
	MeshUtil.add_visual_box(self, Vector3(0.32, 0.3, 0.42), axis * 0.44,
			dark, 0.0, "emitter_housing")
	for fin in 4:
		MeshUtil.add_visual_box(self, Vector3(0.16, 0.06, 0.05),
				axis * (0.4 + 0.12 * float(fin)) + Vector3.UP * 0.24,
				trim, 0.0, "stabiliser_fin_%d" % fin)
	for ring_at in [0.62, 0.95]:
		MeshUtil.add_visual_cylinder(self, 0.16, 0.07,
				axis * (0.44 + barrel_length * ring_at), violet, axis, "yoke_ring")
	MeshUtil.add_visual_cylinder(self, 0.06, barrel_length * 0.7,
			axis * (0.5 + barrel_length * 0.5), trim, axis, "wave_barrel")
	MeshUtil.add_visual_box(self, Vector3(0.22, 0.2, 0.3),
			axis * 0.16 + Vector3.DOWN * 0.2, joint, 0.0, "capacitor_pack")
	var muzzle_core := MeshUtil.sph_at(self, 0.07, axis * (0.44 + barrel_length), violet,
			"muzzle_core")
	_bind_anim(Anim.CORE_THROB, [core, muzzle_core], violet)

func _build_pyre(axis: Vector3, dark: StandardMaterial3D, joint: StandardMaterial3D,
		trim: StandardMaterial3D, glow: StandardMaterial3D, barrel_length: float,
		drum_radius: float) -> void:
	MeshUtil.add_visual_cylinder(self, drum_radius + 0.02, 0.34, axis * 0.14,
			joint, axis, "fuel_drum")
	MeshUtil.add_visual_cylinder(self, drum_radius + 0.03, 0.04, axis * 0.14 + axis * 0.1,
			trim, axis, "drum_cap")
	MeshUtil.add_visual_box(self, Vector3(0.28, 0.24, 0.36), axis * 0.3,
			dark, 0.0, "igniter_block")
	MeshUtil.add_visual_cylinder(self, 0.055, barrel_length,
			axis * (0.44 + barrel_length * 0.5), trim, axis, "flame_tube")
	MeshUtil.add_visual_cylinder(self, 0.075, barrel_length * 0.4,
			axis * (0.48 + barrel_length * 0.35), joint, axis, "perforated_band")
	MeshUtil.add_visual_cylinder(self, 0.11, 0.12,
			axis * (0.4 + barrel_length), joint, axis, "nozzle_ring")
	var pilot := MeshUtil.sph_at(self, 0.07, axis * (0.44 + barrel_length), glow,
			"pilot_flame")
	for spark in [1.0, -1.0]:
		var spark_dir := (axis + Vector3(0.0, 0.1, spark * 0.22)).normalized()
		MeshUtil.add_visual_cylinder(self, 0.018, 0.14,
				axis * (0.42 + barrel_length) + spark_dir * 0.08,
				trim, spark_dir, "igniter_electrode")
	for hose in [1.0, -1.0]:
		MeshUtil.add_visual_box(self, Vector3(0.08, 0.08, 0.2),
				axis * 0.2 + Vector3(0.0, hose * 0.14, 0.0), trim, 0.0, "fuel_line")
	for post in [1.0, -1.0]:
		MeshUtil.add_visual_box(self, Vector3(0.05, 0.14, 0.05),
				axis * 0.22 + Vector3(0.0, 0.2, post * 0.16), joint, 0.0, "handle_post")
	MeshUtil.add_visual_box(self, Vector3(0.3, 0.05, 0.08),
			axis * 0.22 + Vector3.UP * 0.28, trim, 0.0, "carry_handle")
	_bind_anim(Anim.FLAME_FLICKER, [pilot])

func _build_volley(axis: Vector3, dark: StandardMaterial3D, joint: StandardMaterial3D,
		trim: StandardMaterial3D, glow: StandardMaterial3D, barrel_length: float,
		drum_radius: float) -> void:
	MeshUtil.add_visual_box(self, Vector3(0.4, 0.34, 0.5), axis * 0.2,
			dark, 0.0, "pod_body")
	var ready_lights: Array[Node3D] = []
	for row in [-1.0, 0.0, 1.0]:
		for column in [1.0, -1.0]:
			var offset := Vector3(0.0, row * 0.13, column * 0.12)
			MeshUtil.add_visual_cylinder(self, 0.06, barrel_length,
					axis * (0.42 + barrel_length * 0.5) + offset,
					trim, axis, "launch_tube")
			ready_lights.append(MeshUtil.sph_at(self, 0.05,
					axis * (0.42 + barrel_length) + offset,
					glow, "tube_ready"))
			MeshUtil.add_visual_box(self, Vector3(0.09, 0.05, 0.03),
					axis * (0.34 + barrel_length) + offset + Vector3.UP * 0.06,
					joint, 0.0, "tube_fin")
	for side in [1.0, -1.0]:
		MeshUtil.add_visual_box(self, Vector3(0.5, 0.36, 0.05),
				axis * 0.3 + Vector3(0.0, 0.0, side * 0.2), trim, 0.0, "rack_rail")
	MeshUtil.add_visual_box(self, Vector3(0.3, 0.16, 0.34), axis * 0.16 + Vector3.DOWN * 0.2,
			joint, 0.0, "pod_rack")
	MeshUtil.add_visual_box(self, Vector3(0.16, 0.12, 0.3),
			axis * 0.34 + Vector3.UP * 0.18, dark, 0.0, "targeting_block")
	MeshUtil.sph_at(self, 0.05,
			axis * 0.42 + Vector3.UP * 0.18, glow, "targeting_lens")
	_bind_anim(Anim.TUBE_SEQUENCE, ready_lights)
