class_name WeaponSystem
extends Node3D

# Fallback aim height (metres above an enemy origin) when no collision
# capsule can be found — inside every enemy kind's hitbox.
const LOCK_AIM_FALLBACK_Y := 0.3

var rig: RobotRig = null
var mounts: Array[WeaponMount] = []
var builtin: WeaponMount = null
var builtin_requires_field: bool = false
var shots_fired: int = 0
var enabled: bool = true

var _max_heat: float = 0.0
var _overheated: bool = false

func bind(robot_rig: RobotRig) -> void:
	rig = robot_rig
	mounts = robot_rig.mounts
	_max_heat = 0.0
	_overheated = false

func total_heat() -> float:
	return _max_heat

func is_overheated() -> bool:
	return _overheated

func reload_ratio() -> float:
	# Max reload fraction across all mounts + builtin drives the rig's reload
	# brace pose (magazine weapons only; heat weapons always return 0).
	var peak := 0.0
	for mount in mounts:
		if mount == null or mount.destroyed:
			continue
		peak = maxf(peak, mount.reload_ratio())
	if builtin != null and not builtin.destroyed:
		peak = maxf(peak, builtin.reload_ratio())
	return peak

# --- blown-off weapon bookkeeping ------------------------------------------
# A destroyed mount is inert: it never fires, never builds heat, and shows as
# an empty slot on the touch ring / HUD group row. Only the scene rebuild that
# respawns the robot brings it back.

func mount_destroyed(index: int) -> bool:
	if index < 0 or index >= mounts.size():
		return false
	var mount := mounts[index]
	return mount != null and mount.destroyed

func destroyed_mount_count() -> int:
	var count := 0
	for index in mounts.size():
		if mount_destroyed(index):
			count += 1
	return count

# Guns still able to shoot (loaded chassis mounts + the built-in), which is
# what the "never strip the robot's last weapon" rule counts against.
func functional_weapon_count() -> int:
	var count := 0
	for mount in mounts:
		if mount != null and mount.data != null and not mount.destroyed:
			count += 1
	if builtin != null and builtin.data != null and not builtin.destroyed:
		count += 1
	return count

# True when every gun mounted in a fire group (slots 0-1 / 2-3) is gone:
# pressing that group is a dead trigger and must not light up the heat bar.
func group_destroyed(group: int) -> bool:
	var any_gun := false
	for index in mounts.size():
		if index >> 1 != group:
			continue
		var mount := mounts[index]
		if mount == null or mount.data == null:
			continue
		any_gun = true
		if not mount.destroyed:
			return false
	return any_gun

# Surviving guns in a fire group, for the HUD group row ("W1 1/2").
func group_alive_count(group: int) -> int:
	var alive := 0
	for index in mounts.size():
		if index >> 1 != group:
			continue
		var mount := mounts[index]
		if mount != null and mount.data != null and not mount.destroyed:
			alive += 1
	return alive

# Total loaded guns in a fire group (empty loadout slots do not count).
func group_size(group: int) -> int:
	var total := 0
	for index in mounts.size():
		if index >> 1 != group:
			continue
		var mount := mounts[index]
		if mount != null and mount.data != null:
			total += 1
	return total

func _physics_process(_delta: float) -> void:
	if mounts.is_empty() and builtin == null:
		return
	var can_fire := enabled and GameState.phase == GameState.Phase.COMBAT
	var any_wanted := false
	var exclude: Array[RID] = _exclude_rids()
	var camera_dir := _camera_direction()
	var parent := get_parent() as PlayerRobot
	# One aim point shared by every mount AND the built-in gun: when a live
	# lock exists all kinds converge on the target's hitbox instead of flying
	# along raw camera-forward (see _locked_enemy/_hitbox_anchor).
	var lock_anchor: Variant = null
	var locked := _locked_enemy()
	if locked != null:
		lock_anchor = _hitbox_anchor(locked)
	var peak: float = 0.0
	var overheated: bool = false
	for index in mounts.size():
		var mount := mounts[index]
		if mount == null or mount.destroyed:
			# Blown-off gun: no trigger, no heat contribution — the group it
			# belongs to is a dead trigger until the robot respawns.
			continue
		var wanted := can_fire and (InputRouter.fire_held or InputRouter.group_held[index >> 1] \
				or (index < InputRouter.slot_held.size() and InputRouter.slot_held[index]))
		any_wanted = any_wanted or wanted
		if wanted and mount.try_fire(exclude, camera_dir, lock_anchor):
			shots_fired += 1
		peak = maxf(peak, mount.heat_ratio())
		overheated = overheated or mount.is_overheated()
	if builtin != null and builtin.data != null and not builtin.destroyed:
		var field_ok := not builtin_requires_field \
			or (parent != null and parent.ability != null \
			and parent.ability.is_field_active())
		var builtin_wanted := can_fire and InputRouter.fire_held and field_ok
		any_wanted = any_wanted or builtin_wanted
		if builtin_wanted and builtin.try_fire(exclude, camera_dir, lock_anchor):
			shots_fired += 1
		peak = maxf(peak, builtin.heat_ratio())
		overheated = overheated or builtin.is_overheated()
	if any_wanted and get_parent().has_method("notify_weapon_fired"):
		get_parent().call("notify_weapon_fired")
	if absf(peak - _max_heat) > 0.01 or overheated != _overheated:
		_max_heat = peak
		_overheated = overheated
		Events.weapon_heat_changed.emit(_max_heat, _overheated)

# Lock source, read fresh at every shot.
# GameSession.get_lock_target() is the authoritative answer: the session
# re-runs its screen-centre cone + line-of-sight ray every frame, so it is
# already "alive and visible" by construction. PlayerRobot.locked_enemy is
# only the cached copy of Events.enemy_targeted and is used as a fallback
# when the session node cannot be walked up to (or reports nothing aimable).
func _locked_enemy() -> EnemyRobot:
	var node: Node = get_parent()
	while node != null:
		if node.has_method("get_lock_target"):
			var live := _aimable(node.call("get_lock_target"))
			if live != null:
				return live
			break
		node = node.get_parent()
	var parent := get_parent() as PlayerRobot
	if parent != null:
		return _aimable(parent.locked_enemy)
	return null

# Variant in because the candidate may be null or a freed instance.
func _aimable(candidate: Variant) -> EnemyRobot:
	if not (candidate is EnemyRobot):
		return null
	var enemy := candidate as EnemyRobot
	if not is_instance_valid(enemy) or enemy.state == EnemyRobot.State.DEAD:
		return null
	return enemy

# Where the rounds must actually go: inside the enemy's collision capsule,
# two fifths of its height up from the centre (upper body, clear of the
# ground). The previous anchor was a DISPLAY point (origin + 1.4 m) chosen
# to match the HUD's floating lock frame — it sits ABOVE the capsule top of
# ARACHNID (0.68 m), WASP (0.44 m) and BRUTE (1.30 m), so lock-aimed rounds
# sailed clean over those targets while the red frame glowed above them.
# Capsule centre + 0.4 * height stays inside the (convex) hitbox for every
# kind (0.5 would be the exact top), so no amount of spread or drop can turn
# a locked shot into a miss, and the impact puff lands on the hull instead of
# half a metre in front of it.
func _hitbox_anchor(enemy: EnemyRobot) -> Vector3:
	var best_height := -1.0
	var centre_y := 0.0
	for child in enemy.get_children():
		var shape := child as CollisionShape3D
		if shape == null:
			continue
		var capsule := shape.shape as CapsuleShape3D
		if capsule != null and capsule.height > best_height:
			# Read the LIVE height: CapsuleShape3D clamps height to >= 2 * radius
			# (BRUTE is authored 2.34 over a 2.47 diameter), so the stored value
			# already matches the shape the projectiles will actually sweep.
			best_height = capsule.height
			centre_y = shape.position.y
	if best_height > 0.0:
		# Shape nodes are yaw-only children of the body, so local y is the
		# world offset of the capsule centre.
		return enemy.global_position + Vector3.UP * (centre_y + best_height * 0.4)
	return enemy.global_position + Vector3.UP * LOCK_AIM_FALLBACK_Y

func _exclude_rids() -> Array[RID]:
	var rids: Array[RID] = []
	var body := get_parent() as CollisionObject3D
	if body != null:
		rids.append(body.get_rid())
	return rids

func _camera_direction() -> Vector3:
	var camera := get_viewport().get_camera_3d()
	if camera != null:
		var dir := -camera.global_transform.basis.z
		if dir.length_squared() > 0.0001:
			return dir.normalized()
	var parent := get_parent() as Node3D
	if parent != null:
		return -parent.global_transform.basis.z
	return Vector3.FORWARD
