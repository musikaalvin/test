class_name GameSession
extends Node3D

const LOCK_RADIUS_RATIO := 0.24
# DEATH MARK on the locked target: amplified incoming damage while it stays
# locked, a short fade once the lock moves on.
const DEATH_MARK_DURATION := 5.0
const DEATH_MARK_FADE := 1.5
const DEATH_MARK_MULT := 1.3

var arena: CombatArena
var player: PlayerRobot
var follow_camera: FollowCamera
var enemies: Array[EnemyRobot] = []
var hud: Hud

var _debug_label: Label
var _canvas: CanvasLayer
var _hint_time: float = 8.0
var _lock_target: EnemyRobot = null
var _lock_pinned: EnemyRobot = null
var _spawn_pending: bool = false
var _foot_dust: CPUParticles3D
var _spawn_verify_steps: Array[float] = [0.5, 1.5, 3.0]
var _spawn_verify_clock: float = 0.0

func _ready() -> void:
	_build_touch_controls()
	arena = _build_arena()
	player = get_node_or_null("Player") as PlayerRobot
	follow_camera = get_node_or_null("CameraRig") as FollowCamera
	if follow_camera != null:
		# Camera rides higher over a bigger chassis, lower over a small one.
		var cam_scale := float(GameState.robot_def().get("scale", 1.0))
		if bool(GameState.robot_def().get("is_titan", false)):
			follow_camera.height_offset = 1.85 * TitanRig.BULK
		else:
			follow_camera.height_offset = 1.15 * cam_scale
	if player == null or arena == null:
		push_error("GameSession: missing Player or Arena node")
		return
	Quality.apply_viewport(get_viewport())
	_spawn_pending = true
	GameState.begin_combat()
	_spawn_enemies()
	var combat_fx := CombatFx.new()
	combat_fx.name = "CombatFx"
	add_child(combat_fx)
	var nature := Nature.new()
	nature.name = "Nature"
	nature.setup(arena.get_node_or_null("WorldEnvironment") as WorldEnvironment,
			false, true)
	# Backdrop mountains / volcano must sit on the real map terrain.
	nature.ground_fn = Callable(OpenRealm, "terrain_height")
	add_child(nature)
	var crater := nature.crater_hazard()
	HazardZones.add(crater["centre"] as Vector2, float(crater["radius"]),
			float(crater["level"]), float(crater["dps"]),
			crater["kind"] as StringName)
	AudioEngine.bind_engine(player)
	_connect_session_events()
	_build_foot_dust()
	_build_debug_overlay()
	_build_hud()

func _exit_tree() -> void:
	AudioEngine.unbind_engine()

func _physics_process(delta: float) -> void:
	if _spawn_pending:
		_spawn_pending = false
		_finish_spawn()
	if _spawn_verify_steps.is_empty() or player == null:
		return
	_spawn_verify_clock += delta
	while not _spawn_verify_steps.is_empty() \
			and _spawn_verify_clock >= _spawn_verify_steps[0]:
		_spawn_verify_steps.pop_front()
		_verify_spawn()
	if _spawn_verify_steps.is_empty():
		Events.prompt_message.emit("%s · %s · SPAWN y=%.1f" % [
				GameState.BUILD_LABEL, map_label(), player.global_position.y])

func _verify_spawn() -> void:
	if player == null or not is_instance_valid(player):
		return
	var query := PhysicsRayQueryParameters3D.new()
	query.collision_mask = Layers.WORLD
	query.collide_with_areas = false
	query.collide_with_bodies = true
	var blockers: Array[RID] = [player.get_rid()]
	for enemy in enemies:
		if is_instance_valid(enemy):
			blockers.append(enemy.get_rid())
	query.exclude = blockers
	query.from = player.global_position + Vector3.DOWN * 0.4
	query.to = player.global_position + Vector3.UP * 6.0
	var overhead := get_world_3d().direct_space_state.intersect_ray(query)
	if not overhead.is_empty():
		var surface := overhead["position"] as Vector3
		var above := surface.y - player.global_position.y
		if above > 0.3 and above < 2.0:
			player.global_position = Vector3(player.global_position.x,
					surface.y + 1.6, player.global_position.z)
			player.velocity = Vector3.ZERO
			player.respawn_point = player.global_position
			player._feet_initialised = false
			return
	if player.global_position.y < -6.0:
		player.global_position = _grounded_spawn()
		player.velocity = Vector3.ZERO
		player.respawn_point = player.global_position
		player._feet_initialised = false

func _finish_spawn() -> void:
	var spawn := _grounded_spawn()
	player.global_position = spawn
	player.velocity = Vector3.ZERO
	player.respawn_point = spawn
	_ground_enemies()
	Events.prompt_message.emit("%s · %s · SPAWN y=%.1f" % [
			GameState.BUILD_LABEL, map_label(), player.global_position.y])

func _ground_enemies() -> void:
	for enemy in enemies:
		if not is_instance_valid(enemy):
			continue
		enemy.spawn_origin = enemy.global_position
		var query := PhysicsRayQueryParameters3D.new()
		query.from = enemy.global_position + Vector3.UP * 40.0
		query.to = enemy.global_position + Vector3.DOWN * 80.0
		query.collision_mask = Layers.WORLD
		query.collide_with_areas = false
		var hit := get_world_3d().direct_space_state.intersect_ray(query)
		if hit.is_empty():
			continue
		enemy.global_position = (hit["position"] as Vector3) + Vector3.UP * enemy.ground_offset()
		enemy.spawn_origin = enemy.global_position

func map_label() -> String:
	return "OPEN REALM"

func _build_arena() -> CombatArena:
	var realm := OpenRealm.new()
	realm.name = "OpenRealm"
	add_child(realm)
	return realm

func _grounded_spawn() -> Vector3:
	var query := PhysicsRayQueryParameters3D.new()
	query.from = arena.player_spawn + Vector3.UP * 40.0
	query.to = arena.player_spawn + Vector3.DOWN * 80.0
	query.collision_mask = Layers.WORLD
	query.collide_with_areas = false
	var hit := get_world_3d().direct_space_state.intersect_ray(query)
	var point: Vector3 = arena.player_spawn
	if not hit.is_empty():
		point = hit["position"] as Vector3
	var chassis_scale := float(GameState.robot_def().get("scale", 1.0))
	var lift := (3.6 * TitanRig.BULK) \
			if bool(GameState.robot_def().get("is_titan", false)) else 2.5 * chassis_scale
	return point + Vector3.UP * lift

func _spawn_enemies() -> void:
	var count := mini(15, arena.enemy_spawns.size())
	for index in count:
		var enemy := EnemyRobot.new()
		enemy.kind = EnemyRobot.KIND_PATTERN[index % EnemyRobot.KIND_PATTERN.size()]
		enemy.spawn_index = index
		enemy.name = "%s_%02d" % [String(enemy.kind), index + 1]
		add_child(enemy)
		enemy.global_position = arena.enemy_spawns[index]
		enemy.spawn_origin = arena.enemy_spawns[index]
		enemy.setup(player)
		GameState.register_enemy()
		enemies.append(enemy)

func _build_hud() -> void:
	var hud_layer := CanvasLayer.new()
	hud_layer.name = "HudLayer"
	hud_layer.layer = 10
	add_child(hud_layer)
	hud = Hud.new()
	hud.name = "Hud"
	hud_layer.add_child(hud)
	hud.setup(player)

func _build_foot_dust() -> void:
	_foot_dust = CPUParticles3D.new()
	_foot_dust.name = "FootDust"
	_foot_dust.amount = 12
	_foot_dust.lifetime = 0.55
	_foot_dust.local_coords = false
	_foot_dust.emission_shape = CPUParticles3D.EMISSION_SHAPE_BOX
	_foot_dust.emission_box_extents = Vector3(1.1, 0.1, 1.5)
	_foot_dust.direction = Vector3.UP
	_foot_dust.spread = 35.0
	_foot_dust.gravity = Vector3(0.0, -2.2, 0.0)
	_foot_dust.initial_velocity_min = 1.0
	_foot_dust.initial_velocity_max = 2.0
	_foot_dust.scale_amount_min = 0.3
	_foot_dust.scale_amount_max = 0.8
	_foot_dust.color = Color(0.5, 0.46, 0.4, 0.4)
	var puff := SphereMesh.new()
	puff.radius = 0.3
	puff.height = 0.6
	var material := MeshUtil.make_material(Color(0.5, 0.46, 0.4), 0.0, 1.0)
	material.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
	material.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
	material.vertex_color_use_as_albedo = true
	puff.material = material
	_foot_dust.mesh = puff
	_foot_dust.emitting = false
	player.add_child(_foot_dust)
	_foot_dust.position = Vector3(0.0, 0.3, 0.0)

func _connect_session_events() -> void:
	Events.weapon_fired.connect(_on_weapon_fired_haptic)
	Events.damage_applied.connect(_on_damage_haptic)
	Events.enemy_killed.connect(_on_enemy_killed_haptic)
	Events.menu_requested.connect(_open_exit_confirm)
	Events.lock_cycle_requested.connect(_on_lock_cycle_requested)
	Events.ui_back_requested.connect(_on_ui_back)
	Events.mode_changed.connect(_on_mode_changed)

func _on_mode_changed(_mode: int) -> void:
	# Controls language changed mid-match: re-label the pause menu.
	_refresh_pause_hint()

func _on_ui_back() -> void:
	# Pad B outside combat: close pause if open (menus handle their own back).
	if _exit_confirm != null and _exit_confirm.visible:
		_close_pause()

func _on_weapon_fired_haptic(mount_index: int, _kind: int,
		_family: StringName, _size: int) -> void:
	if mount_index < 0:
		return  # drone shot: sound plays, no constant buzzing on the phone
	Haptics.pulse(16, 0.35)

func _on_damage_haptic(target: Node, _amount: float, _point: Vector3, _normal: Vector3) -> void:
	if target == player:
		Haptics.pulse(70, 0.9)

func _on_enemy_killed_haptic(_enemy_id: int) -> void:
	Haptics.pulse(70, 0.75)

func get_lock_target() -> EnemyRobot:
	return _lock_target

func _update_targeting() -> void:
	if GameState.phase != GameState.Phase.COMBAT or player == null \
			or player.health == null or player.health.dead:
		_lock_pinned = null
		_set_lock(null)
		return
	var candidates := _cone_candidates()
	# A manually cycled (pinned) target sticks while it stays in the cone.
	if _lock_pinned != null:
		if candidates.find(_lock_pinned) < 0:
			_lock_pinned = null
		else:
			_set_lock(_lock_pinned)
			return
	_set_lock(candidates[0] if not candidates.is_empty() else null)

func _cone_candidates() -> Array[EnemyRobot]:
	# Enemies near screen centre with a clear line of sight, closest first.
	var result: Array[EnemyRobot] = []
	if GameState.phase != GameState.Phase.COMBAT or player == null \
			or player.health == null or player.health.dead:
		return result
	var camera := get_viewport().get_camera_3d()
	if camera == null:
		return result
	var viewport_size := get_viewport().get_visible_rect().size
	var centre := viewport_size * 0.5
	var radius := minf(viewport_size.x, viewport_size.y) * LOCK_RADIUS_RATIO
	var scored: Array[Array] = []
	var query := PhysicsRayQueryParameters3D.new()
	query.collision_mask = Layers.WORLD
	query.collide_with_areas = false
	query.collide_with_bodies = true
	var blockers: Array[RID] = [player.get_rid()]
	for enemy in enemies:
		if is_instance_valid(enemy) and enemy.state != EnemyRobot.State.DEAD:
			blockers.append(enemy.get_rid())
	query.exclude = blockers
	for enemy in enemies:
		if not is_instance_valid(enemy) or enemy.state == EnemyRobot.State.DEAD:
			continue
		var anchor := enemy.global_position + Vector3.UP * 1.4
		if camera.is_position_behind(anchor):
			continue
		var screen := camera.unproject_position(anchor)
		var distance := screen.distance_to(centre)
		if distance > radius:
			continue
		query.from = camera.global_position
		query.to = anchor
		var hit := get_world_3d().direct_space_state.intersect_ray(query)
		if not hit.is_empty():
			continue
		# Lock order follows the player's targeting preference: CROSSHAIR
		# sorts by screen-centre distance, NEAREST by hull distance.
		var score := distance
		if GameState.target_priority == 1:
			score = player.global_position.distance_to(enemy.global_position)
		scored.append([score, enemy])
	scored.sort_custom(func(a: Array, b: Array) -> bool: return a[0] < b[0])
	for entry in scored:
		result.append(entry[1] as EnemyRobot)
	return result

func _on_lock_cycle_requested() -> void:
	# Crosshair-segment tap: step through nearby enemies, wrapping around.
	if GameState.phase != GameState.Phase.COMBAT or player == null \
			or player.health == null or player.health.dead:
		return
	var candidates := _cone_candidates()
	if candidates.is_empty():
		_lock_pinned = null
		_set_lock(null)
		return
	var index := candidates.find(_lock_target)
	var next := candidates[(index + 1) % candidates.size()]
	_lock_pinned = next
	_set_lock(next)

func _set_lock(next: EnemyRobot) -> void:
	if next == _lock_target:
		# Still locked on the same robot: keep its death mark topped up.
		_refresh_death_mark()
		return
	if _lock_target != null and is_instance_valid(_lock_target):
		# The lock moved on, so the old mark runs out as a short fade.
		_lock_target.fade_death_mark(DEATH_MARK_FADE)
	_lock_target = next
	_refresh_death_mark()
	if _lock_target != null:
		Events.enemy_targeted.emit(_lock_target, _lock_target.health.ratio())
	else:
		Events.enemy_target_cleared.emit()

# Called from _set_lock on every lock refresh (auto-lock, pin, cycle and
# clear alike), so the mark lives for as long as _lock_target does.
func _refresh_death_mark() -> void:
	if _lock_target == null or not is_instance_valid(_lock_target):
		return
	if _lock_target.state == EnemyRobot.State.DEAD:
		return
	# Never downgrade a mark another system applied (CHALLENGE lasts longer
	# with a weaker amplifier than the session's lock mark).
	_lock_target.apply_death_mark(
			maxf(DEATH_MARK_DURATION, _lock_target.death_mark_left),
			maxf(DEATH_MARK_MULT, _lock_target.death_mark_mult))

func _build_debug_overlay() -> void:
	_canvas = CanvasLayer.new()
	_canvas.name = "DebugLayer"
	add_child(_canvas)
	var safe_area := DisplayServer.get_display_safe_area()
	var viewport_size := DisplayServer.window_get_size()
	var margin := Vector2(24.0, 24.0)
	if viewport_size.x > 0 and viewport_size.y > 0:
		margin.x = maxf(margin.x, (viewport_size.x - safe_area.position.x) + 16.0)
		margin.y = maxf(margin.y, (viewport_size.y - safe_area.position.y) + 16.0)
	margin.y = maxf(margin.y, 104.0)
	_debug_label = Label.new()
	_debug_label.name = "DebugLabel"
	_debug_label.position = margin
	_debug_label.add_theme_font_size_override("font_size", 15)
	_debug_label.add_theme_color_override("font_color", Color(0.6, 0.78, 0.86))
	_debug_label.add_theme_constant_override("outline_size", 4)
	_debug_label.add_theme_color_override("font_outline_color", Color(0.02, 0.03, 0.04))
	_canvas.add_child(_debug_label)

func _build_touch_controls() -> void:
	var touch_layer := CanvasLayer.new()
	touch_layer.name = "TouchLayer"
	touch_layer.layer = 30
	touch_layer.visible = true
	add_child(touch_layer)
	touch_layer.add_child(TouchControls.new())

var _exit_confirm: CanvasLayer

func _hint_lines() -> PackedStringArray:
	return PlatformUtil.input_hint_lines(
			String(GameState.robot_def().get("ability_short", "")),
			String(GameState.robot_def().get("secondary_short", "")))

func _hint_text() -> String:
	return "  ·  ".join(_hint_lines())

func _refresh_pause_hint() -> void:
	if _exit_confirm == null:
		return
	var hint := _exit_confirm.get_node_or_null("PauseBox/PauseHint") as Label
	if hint != null:
		hint.text = _hint_text()

func _open_exit_confirm() -> void:
	if _exit_confirm == null:
		_build_exit_confirm()
	InputRouter.clear_temporary()
	_exit_confirm.visible = true
	get_tree().paused = true
	GamepadNav.enable(_exit_confirm)
	if PlatformUtil.effective_mode() == PlatformUtil.InputMode.GAMEPAD:
		GamepadNav.focus_default(_exit_confirm, "ResumeButton")

func _close_pause() -> void:
	if _exit_confirm != null:
		_exit_confirm.visible = false
	get_tree().paused = false

func _build_exit_confirm() -> void:
	_exit_confirm = CanvasLayer.new()
	_exit_confirm.name = "ExitConfirm"
	_exit_confirm.layer = 40
	_exit_confirm.visible = false
	_exit_confirm.process_mode = Node.PROCESS_MODE_ALWAYS
	add_child(_exit_confirm)

	var input_handler := PauseInputHandler.new()
	input_handler.name = "PauseInput"
	input_handler.session = self
	input_handler.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	input_handler.mouse_filter = Control.MOUSE_FILTER_IGNORE
	_exit_confirm.add_child(input_handler)

	var backdrop := ColorRect.new()
	backdrop.color = Color(0.0, 0.0, 0.0, 0.66)
	backdrop.set_anchors_preset(Control.PRESET_FULL_RECT)
	_exit_confirm.add_child(backdrop)

	var box := Panel.new()
	box.name = "PauseBox"
	box.add_theme_stylebox_override("panel", UiTheme.panel(0.96, UiTheme.AMBER))
	box.anchor_left = 0.5
	box.anchor_right = 0.5
	box.anchor_top = 0.5
	box.anchor_bottom = 0.5
	box.offset_left = -250.0
	box.offset_right = 250.0
	box.offset_top = -214.0
	box.offset_bottom = 214.0
	_exit_confirm.add_child(box)

	var title := Label.new()
	title.name = "PauseTitle"
	title.text = "PAUSE"
	title.anchor_left = 0.0
	title.anchor_right = 1.0
	title.anchor_top = 0.0
	title.anchor_bottom = 0.0
	title.offset_left = 0.0
	title.offset_right = 0.0
	title.offset_top = 26.0
	title.offset_bottom = 74.0
	title.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	UiTheme.style_label(title, 34, UiTheme.AMBER, true)
	box.add_child(title)

	var hint := Label.new()
	hint.name = "PauseHint"
	hint.anchor_left = 0.0
	hint.anchor_right = 1.0
	hint.anchor_top = 0.0
	hint.anchor_bottom = 0.0
	hint.offset_left = 34.0
	hint.offset_right = -34.0
	hint.offset_top = 78.0
	hint.offset_bottom = 138.0
	hint.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	hint.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	hint.text = _hint_text()
	UiTheme.style_label(hint, 13, UiTheme.MUTED)
	box.add_child(hint)

	var resume := Button.new()
	resume.name = "ResumeButton"
	resume.text = "RESUME"
	resume.anchor_left = 0.5
	resume.anchor_right = 0.5
	resume.anchor_top = 0.0
	resume.anchor_bottom = 0.0
	resume.offset_left = -200.0
	resume.offset_right = 200.0
	resume.offset_top = 146.0
	resume.offset_bottom = 200.0
	UiTheme.apply_to_button(resume, UiTheme.CYAN, 20)
	resume.pressed.connect(_close_pause)
	box.add_child(resume)

	var restart := Button.new()
	restart.name = "RestartButton"
	restart.text = "RESTART MATCH"
	restart.anchor_left = 0.5
	restart.anchor_right = 0.5
	restart.anchor_top = 0.0
	restart.anchor_bottom = 0.0
	restart.offset_left = -200.0
	restart.offset_right = 200.0
	restart.offset_top = 210.0
	restart.offset_bottom = 258.0
	UiTheme.apply_to_button(restart, UiTheme.STEEL, 17)
	restart.pressed.connect(func() -> void:
		get_tree().paused = false
		SceneRouter.restart_match())
	box.add_child(restart)

	var graphics := Button.new()
	graphics.name = "GraphicsButton"
	graphics.text = "GRAPHICS: %s" % Quality.tier_label()
	graphics.anchor_left = 0.5
	graphics.anchor_right = 0.5
	graphics.anchor_top = 0.0
	graphics.anchor_bottom = 0.0
	graphics.offset_left = -200.0
	graphics.offset_right = 200.0
	graphics.offset_top = 268.0
	graphics.offset_bottom = 316.0
	UiTheme.apply_to_button(graphics, UiTheme.CYAN, 17)
	graphics.pressed.connect(func() -> void:
		GameState.cycle_graphics()
		Quality.apply_viewport(get_viewport())
		graphics.text = "GRAPHICS: %s" % Quality.tier_label())
	box.add_child(graphics)

	var leave := Button.new()
	leave.name = "LeaveButton"
	leave.text = "LEAVE MATCH"
	leave.anchor_left = 0.5
	leave.anchor_right = 0.5
	leave.anchor_top = 0.0
	leave.anchor_bottom = 0.0
	leave.offset_left = -200.0
	leave.offset_right = 200.0
	leave.offset_top = 326.0
	leave.offset_bottom = 374.0
	UiTheme.apply_to_button(leave, UiTheme.DANGER, 17)
	leave.pressed.connect(func() -> void:
		get_tree().paused = false
		SceneRouter.goto_menu())
	box.add_child(leave)

class PauseInputHandler extends Control:
	var session: Node

	func _unhandled_input(event: InputEvent) -> void:
		if event.is_action_pressed(&"ui_cancel") or event.is_action_pressed(&"pause"):
			if session != null and session.has_method("_close_pause"):
				session.call("_close_pause")
				get_viewport().set_input_as_handled()

func _process(delta: float) -> void:
	if Input.is_action_just_pressed(&"restart"):
		SceneRouter.restart_match()
		return
	_hint_time = maxf(_hint_time - delta, 0.0)
	if GameState.phase == GameState.Phase.COMBAT:
		GameState.match_time += delta
		_update_targeting()
		Quality.tick_adaptation(delta)
	_update_dust()
	_update_debug(delta)

func _unhandled_input(event: InputEvent) -> void:
	# Open-only: closing is handled by the pause layer's inner input handler
	# (which marks the event handled), so ESC/Select/BACK can never bounce the
	# menu open again on the same press. While paused this node does not run.
	# ui_cancel opens only for keyboard/back-key presses — pad B (bound to
	# ui_cancel for menus) must keep firing the combat ability instead.
	if event.is_action_pressed(&"pause") \
			or (event.is_action_pressed(&"ui_cancel") and event is InputEventKey):
		if not get_tree().paused:
			_open_exit_confirm()

func _update_dust() -> void:
	if _foot_dust == null or player == null:
		return
	_foot_dust.emitting = GameState.phase == GameState.Phase.COMBAT \
			and player.health != null and not player.health.dead \
			and player.is_on_floor() and player.planar_speed > 1.5

func _update_debug(delta: float) -> void:
	if _debug_label == null:
		return
	var frames := Engine.get_frames_per_second()
	var grounded := player.is_on_floor()
	var lines := PackedStringArray([
		"MECH ASSAULT %s // %s   GFX %s" % [GameState.BUILD_LABEL, map_label(), Quality.tier_label()],
		"FPS %d   SPD %.1f m/s   %s" % [frames, player.planar_speed, "GROUND" if grounded else "AIR"],
		"SYS %s   IN %s" % [Hardware.short_label(), PlatformUtil.mode_label()],
		"POS %.0f, %.0f, %.0f   YAW %d" % [player.global_position.x, player.global_position.y,
				player.global_position.z, rad_to_deg(player.rotation.y)],
	])
	if player.rig is IsoMechRig:
		lines.append((player.rig as IsoMechRig).texture_report())
	# Development-only input diagnostics (settings toggle + debug build): live
	# sources, combined move vector, which fire path is armed, stick deadzones.
	if GameState.input_diagnostics and OS.is_debug_build():
		lines.append("")
		lines.append(InputRouter.input_snapshot())
	if _hint_time > 0.0:
		lines.append("")
		for hint_line in _hint_lines():
			lines.append(hint_line)
	_debug_label.text = "\n".join(lines)
