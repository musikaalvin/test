class_name VolcanoActivity
extends Node3D

## Living-map eruption cycle for the Nature volcano: lava fountain, flowing
## molten ribbons on the cone, and ballistic fire rocks that crash into the
## play field for area damage. All original procedural geometry + synth audio.

const ERUPT_DURATION := 9.0
const IMPACT_RADIUS := 8.0
const IMPACT_FRACTION := 0.07
const ROCK_COUNT := 12
const FLOW_RIM_GAP := 1.5
const FLOW_END := 70.0
const FLOW_LIFT := 0.5

var nature: Nature

var _crater := Vector3.ZERO
var _erupt_in := 26.0
var _erupt_left := 0.0
var _rock_clock := 0.0
var _rocks_to_spawn := 0
var _rocks: Array[Dictionary] = []
var _fountain: CPUParticles3D
var _plume: CPUParticles3D
var _crater_light: OmniLight3D
var _flow_material: ShaderMaterial
var _rumble_player: AudioStreamPlayer

func setup(host: Nature, crater: Vector3) -> void:
	nature = host
	_crater = crater

func _ready() -> void:
	_fountain = _build_fountain()
	add_child(_fountain)
	_plume = _build_plume()
	add_child(_plume)
	_flow_material = _build_flows()
	_rumble_player = AudioStreamPlayer.new()
	_rumble_player.name = "VolcanoRumble"
	_rumble_player.volume_db = -10.0
	_rumble_player.stream = _make_rumble_loop()
	add_child(_rumble_player)
	if nature != null:
		_crater_light = nature.get_node_or_null("CraterLight") as OmniLight3D
	# First eruption lands early so the living map reads as alive in-match.
	_erupt_in = randf_range(10.0, 16.0)

# Always-on ash column: the cone keeps smoking between eruptions so the
# backdrop volcano reads as active from anywhere on the map.
func _build_plume() -> CPUParticles3D:
	var plume := CPUParticles3D.new()
	plume.name = "AshPlume"
	plume.amount = 80
	plume.lifetime = 9.0
	plume.emission_shape = CPUParticles3D.EMISSION_SHAPE_BOX
	plume.emission_box_extents = Vector3(5.0, 2.0, 5.0)
	plume.direction = Vector3.UP
	plume.spread = 12.0
	plume.gravity = Vector3(0.5, 1.1, 0.25)
	plume.initial_velocity_min = 4.0
	plume.initial_velocity_max = 8.0
	plume.scale_amount_min = 1.0
	plume.scale_amount_max = 2.6
	var fade := Gradient.new()
	fade.colors = PackedColorArray([Color(1.0, 1.0, 1.0, 0.5),
			Color(1.0, 1.0, 1.0, 0.34), Color(1.0, 1.0, 1.0, 0.0)])
	fade.offsets = PackedFloat32Array([0.0, 0.45, 1.0])
	plume.color_ramp = fade
	var material := StandardMaterial3D.new()
	material.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
	material.albedo_color = Color(0.24, 0.22, 0.21, 1.0)
	material.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
	material.vertex_color_use_as_albedo = true
	material.depth_draw_mode = BaseMaterial3D.DEPTH_DRAW_DISABLED
	var puff := SphereMesh.new()
	puff.radius = 1.1
	puff.height = 2.2
	puff.radial_segments = 6
	puff.rings = 3
	puff.material = material
	plume.mesh = puff
	plume.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	plume.position = _crater + Vector3(0.0, 20.0, 0.0)
	plume.emitting = true
	return plume

func _build_fountain() -> CPUParticles3D:
	var fountain := CPUParticles3D.new()
	fountain.name = "LavaFountain"
	fountain.amount = 340
	fountain.lifetime = 3.6
	fountain.emission_shape = CPUParticles3D.EMISSION_SHAPE_BOX
	fountain.emission_box_extents = Vector3(4.5, 1.5, 4.5)
	fountain.direction = Vector3.UP
	fountain.spread = 16.0
	fountain.gravity = Vector3(0.0, -22.0, 0.0)
	fountain.initial_velocity_min = 26.0
	fountain.initial_velocity_max = 46.0
	fountain.scale_amount_min = 0.4
	fountain.scale_amount_max = 1.9
	var fade := Gradient.new()
	fade.colors = PackedColorArray([Color(6.5, 3.2, 0.85), Color(3.2, 1.0, 0.14),
			Color(1.4, 0.28, 0.03), Color(0.35, 0.04, 0.01, 0.0)])
	fade.offsets = PackedFloat32Array([0.0, 0.28, 0.65, 1.0])
	fountain.color_ramp = fade
	var material := StandardMaterial3D.new()
	material.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
	material.albedo_color = Color.WHITE
	material.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
	material.vertex_color_use_as_albedo = true
	var chunk := SphereMesh.new()
	chunk.radius = 0.42
	chunk.height = 0.84
	chunk.radial_segments = 5
	chunk.rings = 3
	chunk.material = material
	fountain.mesh = chunk
	fountain.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	fountain.position = _crater + Vector3(0.0, 2.5, 0.0)
	fountain.emitting = false
	return fountain

func _build_flows() -> ShaderMaterial:
	var shader := Shader.new()
	shader.code = """
shader_type spatial;

uniform vec4 hot_color : source_color = vec4(1.0, 0.34, 0.03, 1.0);
uniform vec4 crust_color : source_color = vec4(0.1, 0.06, 0.05, 1.0);
uniform float glow : hint_range(0.0, 4.0) = 0.7;

varying vec2 v_uv;

void vertex() {
	v_uv = UV;
}

void fragment() {
	float t = TIME;
	float flow = fract(v_uv.y * 3.0 + t * 0.22);
	float veins = smoothstep(0.35, 0.85, flow + 0.25 * sin(v_uv.x * 9.0 + t * 1.6));
	vec3 col = mix(crust_color.rgb, hot_color.rgb, veins);
	ALBEDO = col;
	EMISSION = hot_color.rgb * veins * glow;
	ROUGHNESS = 0.8;
}
"""
	var mesh := ArrayMesh.new()
	if nature != null:
		var surface := SurfaceTool.new()
		surface.begin(Mesh.PRIMITIVE_TRIANGLES)
		var base_angle := atan2(-_crater.z, -_crater.x)
		var origin := Vector2(_crater.x, _crater.z)
		for ribbon in 3:
			var azimuth := base_angle + float(ribbon - 1) * 0.52
			var dir := Vector2(cos(azimuth), sin(azimuth))
			var side := Vector2(-dir.y, dir.x)
			var segments := 16
			var width_start := 2.2 + float(ribbon) * 0.9
			var flow_start := nature.volcano_rim_radius(azimuth) + FLOW_RIM_GAP
			var path_a: Array[Vector3] = []
			var path_b: Array[Vector3] = []
			for index in segments + 1:
				var t := float(index) / float(segments)
				var radius := lerpf(flow_start, FLOW_END, t)
				var width := width_start * (0.4 + 0.6 * t)
				var mid := origin + dir * radius
				var edge_flat_a := mid + side * width * 0.5
				var edge_flat_b := mid - side * width * 0.5
				path_a.append(Vector3(edge_flat_a.x,
						nature.volcano_point_height(edge_flat_a.x, edge_flat_a.y)
						+ FLOW_LIFT, edge_flat_a.y))
				path_b.append(Vector3(edge_flat_b.x,
						nature.volcano_point_height(edge_flat_b.x, edge_flat_b.y)
						+ FLOW_LIFT, edge_flat_b.y))
			_lift_flow_path(path_a)
			_lift_flow_path(path_b)
			var previous: Array = []
			for index in segments:
				var t := float(index) / float(segments)
				var v_coord := 1.0 - t
				var edge_a: Vector3 = path_a[index]
				var edge_b: Vector3 = path_b[index]
				if not previous.is_empty():
					var pa: Vector3 = previous[0]
					var pb: Vector3 = previous[1]
					var va: float = previous[2]
					surface.set_uv(Vector2(0.0, va))
					surface.add_vertex(pa)
					surface.set_uv(Vector2(1.0, va))
					surface.add_vertex(pb)
					surface.set_uv(Vector2(1.0, v_coord))
					surface.add_vertex(edge_b)
					surface.set_uv(Vector2(0.0, va))
					surface.add_vertex(pa)
					surface.set_uv(Vector2(1.0, v_coord))
					surface.add_vertex(edge_b)
					surface.set_uv(Vector2(0.0, v_coord))
					surface.add_vertex(edge_a)
				previous = [edge_a, edge_b, v_coord]
		surface.generate_normals()
		mesh = surface.commit()
	var instance := MeshInstance3D.new()
	instance.name = "LavaFlows"
	instance.mesh = mesh
	var material_override := ShaderMaterial.new()
	material_override.shader = shader
	instance.material_override = material_override
	instance.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	add_child(instance)
	return material_override

func _lift_flow_path(path: Array[Vector3]) -> void:
	if nature == null:
		return
	var neighbors: Array[int] = [-1, 1]
	var fractions: Array[float] = [0.25, 0.5, 0.75]
	for index in path.size():
		var point: Vector3 = path[index]
		var lift := 0.0
		for neighbor in neighbors:
			var other: int = index + neighbor
			if other < 0 or other >= path.size():
				continue
			var target: Vector3 = path[other]
			for fraction in fractions:
				var sample_x := lerpf(point.x, target.x, fraction)
				var sample_z := lerpf(point.z, target.z, fraction)
				lift = maxf(lift, nature.volcano_point_height(sample_x, sample_z)
						+ FLOW_LIFT - point.y)
		if lift > 0.0:
			path[index] = Vector3(point.x, point.y + lift, point.z)

func _process(delta: float) -> void:
	_advance_rocks(delta)
	if _erupt_left > 0.0:
		_erupt_left -= delta
		_rock_clock -= delta
		if _rocks_to_spawn > 0 and _rock_clock <= 0.0:
			_rock_clock = 0.3
			_rocks_to_spawn -= 1
			_launch_rock()
		if _erupt_left <= 0.0:
			_finish_eruption()
	else:
		_erupt_in -= delta
		if _erupt_in <= 0.0:
			force_eruption()

func force_eruption() -> void:
	if _erupt_left > 0.0:
		return
	_erupt_left = ERUPT_DURATION
	_erupt_in = randf_range(26.0, 40.0)
	_rock_clock = 0.0
	_rocks_to_spawn = ROCK_COUNT
	if _fountain != null:
		_fountain.emitting = true
	if _crater_light != null:
		_crater_light.light_energy = 9.5
	if _flow_material != null:
		_flow_material.set_shader_parameter("glow", 2.4)
	if nature != null:
		nature.set_crater_glow(3.6)
	if _rumble_player != null and not _rumble_player.playing:
		_rumble_player.play()
	Events.camera_shake_requested.emit(0.7, 0.6)
	AudioEngine.play(&"boom", -4.0, 0.1)

func _finish_eruption() -> void:
	_erupt_left = 0.0
	_rocks_to_spawn = 0
	if _fountain != null:
		_fountain.emitting = false
	if _crater_light != null:
		_crater_light.light_energy = 4.0
	if _flow_material != null:
		_flow_material.set_shader_parameter("glow", 0.7)
	if nature != null:
		nature.set_crater_glow(1.4)
	if _rumble_player != null:
		_rumble_player.stop()

func _launch_rock() -> void:
	var angle := randf_range(0.0, TAU)
	var distance := randf_range(60.0, 150.0)
	var target_x := cos(angle) * distance
	var target_z := sin(angle) * distance
	var query := PhysicsRayQueryParameters3D.create(
			Vector3(target_x, 240.0, target_z), Vector3(target_x, -60.0, target_z))
	query.collision_mask = Layers.WORLD
	var space := get_world_3d().direct_space_state
	var hit := space.intersect_ray(query)
	var landing := Vector3(target_x, 0.0, target_z)
	if not hit.is_empty():
		landing = (hit["position"] as Vector3) + Vector3.UP * 0.2
	var start := _crater + Vector3(randf_range(-4.0, 4.0), randf_range(-1.0, 2.0),
			randf_range(-4.0, 4.0))
	var flight := randf_range(3.0, 4.0)
	var gravity := 22.0
	var velocity := (landing - start) / flight
	velocity.y += 0.5 * gravity * flight

	var rock := Node3D.new()
	rock.name = "FireRock"
	var material := StandardMaterial3D.new()
	material.albedo_color = Color(0.5, 0.17, 0.06)
	material.metallic = 0.1
	material.roughness = 0.9
	material.emission_enabled = true
	material.emission = Color(1.0, 0.42, 0.06)
	material.emission_energy_multiplier = 3.6
	var chunk := MeshUtil.make_bevel_box(Vector3(1.7, 1.25, 1.4), 0.18, material, "chunk")
	chunk.rotation = Vector3(randf_range(0.0, TAU), randf_range(0.0, TAU),
			randf_range(0.0, TAU))
	rock.add_child(chunk)
	rock.add_child(_build_embers())
	rock.position = start
	add_child(rock)
	_rocks.append({"node": rock, "start": start, "velocity": velocity,
			"target": landing, "time": 0.0, "flight": flight})
	AudioEngine.play(&"launch", -7.0, 0.14)

func _build_embers() -> CPUParticles3D:
	var embers := CPUParticles3D.new()
	embers.name = "Embers"
	embers.amount = 10
	embers.lifetime = 0.9
	embers.emission_shape = CPUParticles3D.EMISSION_SHAPE_BOX
	embers.emission_box_extents = Vector3(0.75, 0.7, 0.7)
	embers.direction = Vector3.UP
	embers.spread = 70.0
	embers.gravity = Vector3(0.0, -10.0, 0.0)
	embers.initial_velocity_min = 1.5
	embers.initial_velocity_max = 5.0
	embers.scale_amount_min = 0.1
	embers.scale_amount_max = 0.38
	var fade := Gradient.new()
	fade.colors = PackedColorArray([Color(5.0, 2.0, 0.4), Color(1.6, 0.3, 0.03),
			Color(0.2, 0.02, 0.0, 0.0)])
	fade.offsets = PackedFloat32Array([0.0, 0.4, 1.0])
	embers.color_ramp = fade
	var material := StandardMaterial3D.new()
	material.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
	material.albedo_color = Color.WHITE
	material.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
	material.vertex_color_use_as_albedo = true
	var spark := SphereMesh.new()
	spark.radius = 0.3
	spark.height = 0.6
	spark.radial_segments = 4
	spark.rings = 2
	spark.material = material
	embers.mesh = spark
	embers.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	embers.emitting = true
	return embers

func _advance_rocks(delta: float) -> void:
	for index in range(_rocks.size() - 1, -1, -1):
		var entry: Dictionary = _rocks[index]
		var time := float(entry["time"]) + delta
		entry["time"] = time
		var node := entry["node"] as Node3D
		if not is_instance_valid(node):
			_rocks.remove_at(index)
			continue
		var flight := float(entry["flight"])
		if time >= flight:
			impact_at(entry["target"] as Vector3)
			node.queue_free()
			_rocks.remove_at(index)
			continue
		var velocity := entry["velocity"] as Vector3
		var start := entry["start"] as Vector3
		node.position = start + velocity * time + Vector3(0.0, -11.0, 0.0) * time * time
		node.rotation.x += delta * 4.0
		node.rotation.y += delta * 2.5
		node.rotation.z += delta * 3.0

func impact_at(point: Vector3) -> void:
	Events.weapon_impact.emit(point, Vector3.UP, WeaponData.Kind.BLAST)
	Events.camera_shake_requested.emit(0.5, 0.32)
	AudioEngine.play(&"boom", -6.0, 0.16)
	var radius := IMPACT_RADIUS
	var tree := get_tree()
	if tree == null:
		return
	var amount := 0.0
	for node in tree.get_nodes_in_group("enemy"):
		var enemy := node as EnemyRobot
		if enemy == null or enemy.state == EnemyRobot.State.DEAD:
			continue
		var distance := point.distance_to(enemy.global_position + Vector3.UP * 1.2)
		if distance >= radius:
			continue
		amount = IMPACT_FRACTION * enemy.health.max_health * (1.0 - distance / radius)
		if amount > 0.0:
			enemy.receive_damage(amount, point)
	var player := tree.get_first_node_in_group("player") as PlayerRobot
	if player != null and player.health != null and not player.health.dead:
		var player_distance := point.distance_to(player.global_position + Vector3.UP * 1.0)
		if player_distance < radius:
			amount = IMPACT_FRACTION * player.health.max_health * (1.0 - player_distance / radius)
			if amount > 0.0:
				player.health.apply_damage(amount, point)
				Events.player_health_changed.emit(player.health.current, player.health.max_health)
				Events.damage_applied.emit(player, amount, point, Vector3.UP)

func _make_rumble_loop() -> AudioStreamWAV:
	var mix_rate := 22050
	var duration := 3.0
	var sample_count := int(duration * float(mix_rate))
	var bytes := PackedByteArray()
	bytes.resize(sample_count * 2)
	var seed_value := 2479
	var brown := 0.0
	for index in sample_count:
		var t := float(index) / float(mix_rate)
		seed_value = (seed_value * 1103515245 + 12345) & 0x7fffffff
		var white := float(seed_value % 20000 - 10000) / 10000.0
		brown = clampf(brown + white * 0.08, -1.0, 1.0) * 0.995
		var throb := 0.6 + 0.4 * sin(TAU * 4.0 * t / duration)
		var sample := clampf(brown * 2.0 * throb * 0.7, -1.0, 1.0)
		bytes.encode_s16(index * 2, int(sample * 26000.0))
	var stream := AudioStreamWAV.new()
	stream.format = AudioStreamWAV.FORMAT_16_BITS
	stream.mix_rate = mix_rate
	stream.stereo = false
	stream.data = bytes
	stream.loop_mode = AudioStreamWAV.LOOP_FORWARD
	stream.loop_begin = 0
	stream.loop_end = sample_count
	return stream

