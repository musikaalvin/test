class_name CombatArena
extends Node3D

var player_spawn: Vector3 = Vector3.ZERO
var enemy_spawns: Array[Vector3] = []
var _kit_serial: int = 0

func _kit_mesh(path: String) -> Mesh:
	var scene := load(path) as PackedScene
	if scene == null:
		push_warning("Arena: missing kit scene %s" % path)
		return null
	var inst := scene.instantiate()
	var mesh: Mesh = null
	if inst is MeshInstance3D:
		mesh = (inst as MeshInstance3D).mesh
	if mesh == null:
		for node in inst.find_children("*", "MeshInstance3D", true, false):
			if node is MeshInstance3D and (node as MeshInstance3D).mesh != null:
				mesh = (node as MeshInstance3D).mesh
				break
	inst.free()
	return mesh

func _kit_place(path: String, position: Vector3, yaw_degrees: float,
		scale: float, collide: bool, cast_shadow: bool = true) -> void:
	var scene := load(path) as PackedScene
	if scene == null:
		push_warning("Arena: missing kit scene %s" % path)
		return
	var inst := scene.instantiate() as Node3D
	if inst == null:
		return
	inst.position = position
	inst.rotation.y = deg_to_rad(yaw_degrees)
	inst.scale = Vector3.ONE * scale
	if not cast_shadow:
		for node in inst.find_children("*", "MeshInstance3D", true, false):
			if node is MeshInstance3D:
				(node as MeshInstance3D).cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	add_child(inst)
	if not collide:
		return
	var body := StaticBody3D.new()
	body.name = "%s_%d_body" % [
			String(scene.resource_path.get_file().get_basename()), _kit_serial]
	_kit_serial += 1
	body.position = position
	body.rotation.y = deg_to_rad(yaw_degrees)
	body.collision_layer = Layers.WORLD
	body.collision_mask = Layers.WORLD
	add_child(body)
	var to_body := body.global_transform.affine_inverse()
	var box := AABB()
	var has_box := false
	for node in inst.find_children("*", "MeshInstance3D", true, false):
		if not (node is MeshInstance3D):
			continue
		var mesh_instance := node as MeshInstance3D
		if mesh_instance.mesh == null:
			continue
		var aabb := mesh_instance.get_aabb()
		var to_body_xf := to_body * mesh_instance.global_transform
		for corner in 8:
			var local := Vector3(
					aabb.position.x + (aabb.size.x if corner & 1 else 0.0),
					aabb.position.y + (aabb.size.y if corner & 2 else 0.0),
					aabb.position.z + (aabb.size.z if corner & 4 else 0.0))
			var point := to_body_xf * local
			if not has_box:
				box = AABB(point, Vector3.ZERO)
				has_box = true
			else:
				box = box.expand(point)
	if inst is MeshInstance3D and (inst as MeshInstance3D).mesh != null:
		var aabb := (inst as MeshInstance3D).get_aabb()
		var to_body_xf := to_body * inst.global_transform
		for corner in 8:
			var local := Vector3(
					aabb.position.x + (aabb.size.x if corner & 1 else 0.0),
					aabb.position.y + (aabb.size.y if corner & 2 else 0.0),
					aabb.position.z + (aabb.size.z if corner & 4 else 0.0))
			var point := to_body_xf * local
			if not has_box:
				box = AABB(point, Vector3.ZERO)
				has_box = true
			else:
				box = box.expand(point)
	if not has_box or box.size.length() < 0.05:
		body.queue_free()
		return
	var shape := CollisionShape3D.new()
	var box_shape := BoxShape3D.new()
	box_shape.size = box.size
	shape.shape = box_shape
	shape.position = box.get_center()
	body.add_child(shape)
