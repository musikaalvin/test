class_name Nature
extends Node3D

const GROUND_SIZE := 170.0
const CLOUD_WRAP := 280.0
const RIM_INNER := 62.0
const RIM_OUTER := 150.0
const RIM_TOP := 21.0

const VOLCANO_XY := Vector2(165.0, -195.0)
const VOLCANO_RADIUS := 72.0
const VOLCANO_RIM_R := 16.0
const VOLCANO_HEIGHT := 86.0
const VOLCANO_FLOOR_DROP := 18.0
const VOLCANO_BOWL_FLOOR_B := 0.55
const VOLCANO_POOL_R := 8.8
const VOLCANO_SEGMENTS := 64
const VOLCANO_FLANK_RINGS := 16
const VOLCANO_BOWL_RINGS := 8

var _environment: Environment
var _skip_base_ground: bool = false
var _distant_only: bool = false
# Real ground height provider. The map injects its own terrain function so
# backdrop mountains / the volcano sit ON the actual ground instead of the
# legacy Cinder Valley rim profile (which left them floating 12-18 m up).
var ground_fn: Callable = Callable()
var _clouds: Array[Node3D] = []
var _cloud_speed: Array[float] = []
var _strike_clock: float = 8.0
var _flash_lights: Array[OmniLight3D] = []
var _bolt_serial: int = 0
var _thunder_streams: Array[AudioStreamWAV] = []
var _thunder_player: AudioStreamPlayer
var _ambient_base: float = 0.55
var wind_scale: float = 1.0

var _bolt_material: StandardMaterial3D
var _halo: Texture2D = null
var _crater_pool_material: ShaderMaterial

func setup(world_environment: WorldEnvironment, include_ground: bool = true,
		distant_only: bool = false) -> void:
	if world_environment != null:
		_environment = world_environment.environment
		_ambient_base = _environment.ambient_light_energy
	_skip_base_ground = not include_ground
	_distant_only = distant_only

func _ready() -> void:
	_make_materials()
	if not _skip_base_ground:
		_build_base_ground()
	if not _distant_only:
		_build_valley_rim()
		_build_hills()
		_build_lake()
	_build_mountains()
	_build_volcano()
	_build_clouds()
	_build_sun_disk()
	if _distant_only:
		_build_void_ground()
	_thunder_player = AudioStreamPlayer.new()
	_thunder_player.name = "Thunder"
	_thunder_player.volume_db = 2.0
	add_child(_thunder_player)
	_strike_clock = randf_range(4.0, 8.0)
	_build_thunder_streams()
	var crater := Vector3(VOLCANO_XY.x, _volcano_pool_y(), VOLCANO_XY.y)
	var volcano := VolcanoActivity.new()
	volcano.name = "VolcanoActivity"
	volcano.setup(self, crater)
	add_child(volcano)
	var weather := WeatherSystem.new()
	weather.name = "WeatherSystem"
	weather.setup(self, _environment, _ambient_base)
	add_child(weather)

func strike_lightning() -> void:
	_strike_lightning()

func set_ambient_level(energy: float) -> void:
	_ambient_base = energy
	if _environment != null:
		_environment.ambient_light_energy = energy

func _make_materials() -> void:
	_bolt_material = MeshUtil.make_material(Color(0.9, 0.95, 1.0), 0.0, 0.2,
			Color(0.75, 0.85, 1.0), 7.0)
	_bolt_material.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED

func _build_base_ground() -> void:
	var grass := MeshUtil.make_material(Color(0.15, 0.2, 0.14), 0.0, 1.0)
	var mesh := BoxMesh.new()
	mesh.size = Vector3(GROUND_SIZE, 1.0, GROUND_SIZE)
	mesh.material = grass
	var instance := MeshInstance3D.new()
	instance.name = "NatureGround"
	instance.mesh = mesh
	instance.position = Vector3(0.0, -0.56, 0.0)
	add_child(instance)

	var body := StaticBody3D.new()
	body.name = "NatureGroundBody"
	body.collision_layer = Layers.WORLD
	body.collision_mask = Layers.WORLD
	var shape := CollisionShape3D.new()
	var box := BoxShape3D.new()
	box.size = Vector3(GROUND_SIZE, 1.0, GROUND_SIZE)
	shape.shape = box
	shape.position = Vector3(0.0, -0.56, 0.0)
	body.add_child(shape)
	add_child(body)

func _rim_height(radius: float) -> float:
	if radius <= RIM_INNER:
		return -1.0
	if radius <= RIM_OUTER:
		return -1.0 + (radius - RIM_INNER) / (RIM_OUTER - RIM_INNER) * (RIM_TOP + 1.0)
	return RIM_TOP - 24.0 * (radius - RIM_OUTER) / 180.0

# Real ground height for backdrop props: uses the map's own terrain function
# when injected, otherwise falls back to the legacy rim profile.
func _ground_y(x: float, z: float) -> float:
	if ground_fn.is_valid():
		var value = ground_fn.call(x, z)
		if value is float or value is int:
			return float(value)
	return _rim_height(Vector2(x, z).length())

# A dark base disc reaches well past the terrain edge so the backdrop
# mountains (which straddle the map boundary, base radius up to 80 m) never
# float over the void behind the rim.
func _build_void_ground() -> void:
	var material := MeshUtil.make_material(Color(0.075, 0.085, 0.095), 0.0, 1.0)
	var disc := MeshUtil.make_cylinder(430.0, 2.0, material, 28, "VoidGround")
	disc.position = Vector3(0.0, -9.4, 0.0)
	add_child(disc)

func _build_valley_rim() -> void:
	var grass := MeshUtil.make_material(Color(0.17, 0.22, 0.15), 0.0, 1.0)
	grass.cull_mode = BaseMaterial3D.CULL_DISABLED
	var inner := MeshUtil.make_cylinder(RIM_INNER, RIM_TOP + 1.0, grass, 14, "valley_inner")
	inner.scale = Vector3(1.0, 1.0, 1.0)
	inner.position = Vector3(0.0, (RIM_TOP - 1.0) * 0.5, 0.0)
	var inner_mesh := inner.mesh as CylinderMesh
	inner_mesh.top_radius = RIM_OUTER
	inner_mesh.bottom_radius = RIM_INNER
	inner_mesh.radial_segments = 14
	add_child(inner)

	var earth := MeshUtil.make_material(Color(0.2, 0.19, 0.16), 0.0, 1.0)
	earth.cull_mode = BaseMaterial3D.CULL_DISABLED
	var outer := MeshUtil.make_cylinder(RIM_OUTER, 24.0, earth, 14, "valley_outer")
	var outer_mesh := outer.mesh as CylinderMesh
	outer_mesh.bottom_radius = 330.0
	outer_mesh.top_radius = RIM_OUTER
	outer.position = Vector3(0.0, RIM_TOP - 12.0 + 9.0, 0.0)
	add_child(outer)

func _build_hills() -> void:
	var hill_colors: Array[Color] = [
		Color(0.2, 0.28, 0.16), Color(0.17, 0.24, 0.15), Color(0.24, 0.3, 0.18),
	]
	var count := 16
	for index in count:
		var angle := TAU * float(index) / float(count) + randf_range(-0.1, 0.1)
		var radius := randf_range(72.0, 138.0)
		var hill := MeshUtil.make_sphere(1.0,
				MeshUtil.make_material(hill_colors[index % hill_colors.size()], 0.0, 1.0), 9, 7)
		hill.name = "Hill_%02d" % index
		var width := randf_range(20.0, 42.0)
		var height := randf_range(16.0, 34.0)
		hill.scale = Vector3(width, height, width * randf_range(0.75, 1.3))
		hill.position = Vector3(cos(angle) * radius,
				_rim_height(radius) - height * 0.35, sin(angle) * radius)
		hill.rotation.y = randf_range(0.0, TAU)
		add_child(hill)

	for index in 7:
		var shore := MeshUtil.make_sphere(1.0,
				MeshUtil.make_material(Color(0.3, 0.3, 0.24), 0.0, 1.0), 7, 5)
		shore.name = "Boulder_%d" % index
		var size := randf_range(1.4, 3.6)
		shore.scale = Vector3(size, size * 0.7, size)
		shore.position = Vector3(randf_range(-46.0, 30.0), 15.4,
				randf_range(-134.0, -86.0))
		add_child(shore)

func _build_mountains() -> void:
	var mountain_color := MeshUtil.make_material(Color(0.2, 0.23, 0.28), 0.0, 1.0)
	var snow_color := MeshUtil.make_material(Color(0.82, 0.86, 0.9), 0.0, 0.9)
	var volcano_xy := Vector2(165.0, -195.0)
	var volcano_radius := 72.0
	var placed_centres: Array[Vector2] = []
	var placed_bases: Array[float] = []
	for index in 9:
		var slot := TAU * float(index) / 9.0 + 0.35
		var radius := randf_range(196.0, 224.0)
		var base := randf_range(40.0, 58.0)
		var height := randf_range(55.0, 110.0)
		# Nudge the slot off the volcano and off already-placed peaks; when no
		# angle fits, drop the peak so nothing intersects (the volcano keeps
		# its own clear stretch of horizon).
		var px := 0.0
		var pz := 0.0
		var settled := false
		for attempt in 9:
			var delta := 0.0
			if attempt > 0:
				delta = (8.0 * deg_to_rad(1.0)) * float((attempt + 1) / 2) \
						* (1.0 if attempt % 2 == 1 else -1.0)
			var angle := slot + delta
			px = cos(angle) * radius
			pz = sin(angle) * radius
			var centre := Vector2(px, pz)
			if centre.distance_to(volcano_xy) < volcano_radius + base + 6.0:
				continue
			var fits := true
			for other in placed_centres.size():
				if centre.distance_to(placed_centres[other]) \
						< base + placed_bases[other] + 6.0:
					fits = false
					break
			if fits:
				settled = true
				break
		if not settled:
			continue
		# Sink the flat cone base to the LOWEST terrain under the whole
		# footprint (multi-radius ring sample) instead of the centre point —
		# the old placement left the base hanging up to 31 m above the rim
		# slope on the map-edge side.
		var ground_y := _ground_y(px, pz)
		var min_ground := ground_y
		for sample_radius in [base * 0.45, base * 0.7, base]:
			for step in 12:
				var sa := TAU * float(step) / 12.0
				min_ground = minf(min_ground,
						_ground_y(px + cos(sa) * sample_radius,
								pz + sin(sa) * sample_radius))
		var bottom := min_ground - 1.0
		var peak := ground_y + height - 2.0
		var eff_height := maxf(peak - bottom, height * 0.5)
		var mountain := MeshUtil.make_cone(base, 0.0, eff_height, mountain_color, 7, "mountain")
		mountain.name = "Mountain_%02d" % index
		mountain.position = Vector3(px, bottom + eff_height * 0.5, pz)
		mountain.rotation.y = randf_range(0.0, TAU)
		add_child(mountain)
		placed_centres.append(Vector2(px, pz))
		placed_bases.append(base)
		# Backdrop mountains are solid so the player can never walk through them.
		var body := StaticBody3D.new()
		body.name = "MountainBody_%02d" % index
		body.collision_layer = Layers.WORLD
		body.collision_mask = Layers.WORLD
		body.position = Vector3(px, 0.0, pz)
		var shape := CollisionShape3D.new()
		var cone_shape := CylinderShape3D.new()
		cone_shape.radius = base
		cone_shape.height = eff_height
		shape.shape = cone_shape
		shape.position = Vector3(0.0, bottom + eff_height * 0.5, 0.0)
		body.add_child(shape)
		add_child(body)
		if height > 80.0:
			var cap_height := height * 0.26
			var cap := MeshUtil.make_cone(base * 0.32, 0.0, cap_height, snow_color, 7, "snowcap")
			cap.name = "Snowcap_%02d" % index
			cap.position = Vector3(mountain.position.x,
					peak - cap_height * 0.45,
					mountain.position.z)
			add_child(cap)

func _build_lake() -> void:
	var shelf_material := MeshUtil.make_material(Color(0.24, 0.22, 0.17), 0.0, 1.0)
	var shelf := MeshUtil.make_cylinder(40.0, 9.0, shelf_material, 12, "lake_shelf")
	shelf.position = Vector3(-8.0, 11.0, -110.0)
	add_child(shelf)

	var lake := MeshInstance3D.new()
	lake.name = "Lake"
	var mesh := PlaneMesh.new()
	mesh.size = Vector2(56.0, 34.0)
	mesh.material = _water_material()
	lake.mesh = mesh
	lake.position = Vector3(-8.0, 15.55, -110.0)
	add_child(lake)

func _water_material() -> ShaderMaterial:
	var shader := Shader.new()
	shader.code = """
shader_type spatial;

uniform vec4 shallow_color : source_color = vec4(0.2, 0.45, 0.48, 1.0);
uniform vec4 deep_color : source_color = vec4(0.03, 0.1, 0.15, 1.0);

void vertex() {
	float t = TIME * 0.8;
	VERTEX.y += sin(VERTEX.x * 0.32 + t) * 0.07
			+ sin(VERTEX.z * 0.27 + t * 1.4) * 0.06;
}

void fragment() {
	float fresnel = pow(1.0 - clamp(abs(dot(NORMAL, VIEW)), 0.0, 1.0), 2.2);
	vec3 col = mix(deep_color.rgb, shallow_color.rgb, fresnel);
	float sparkle = sin((VERTEX.x + VERTEX.z) * 1.7 + TIME * 2.4) * 0.035;
	ALBEDO = col + sparkle;
	ROUGHNESS = mix(0.2, 0.06, fresnel);
	METALLIC = 0.15;
}
"""
	var material := ShaderMaterial.new()
	material.shader = shader
	return material

func _build_volcano() -> void:
	var basalt := MeshUtil.make_material(Color(1.0, 1.0, 1.0), 0.0, 0.96)
	basalt.vertex_color_use_as_albedo = true
	var surface := SurfaceTool.new()
	surface.begin(Mesh.PRIMITIVE_TRIANGLES)
	var ring_count := VOLCANO_FLANK_RINGS + VOLCANO_BOWL_RINGS + 1
	var rings: Array[PackedVector3Array] = []
	for k in ring_count:
		var ring := PackedVector3Array()
		for i in VOLCANO_SEGMENTS:
			ring.append(_volcano_vertex(k, i))
		rings.append(ring)
	for k in ring_count - 1:
		var outer_ring := rings[k]
		var inner_ring := rings[k + 1]
		var last_band := k == ring_count - 2
		for i in VOLCANO_SEGMENTS:
			var next_i := (i + 1) % VOLCANO_SEGMENTS
			var p0 := outer_ring[i]
			var p1 := outer_ring[next_i]
			var p2 := inner_ring[next_i]
			_emit_volcano_vertex(surface, p0)
			_emit_volcano_vertex(surface, p1)
			_emit_volcano_vertex(surface, p2)
			if not last_band:
				_emit_volcano_vertex(surface, p0)
				_emit_volcano_vertex(surface, p2)
				_emit_volcano_vertex(surface, inner_ring[i])
	var shell_mesh := surface.commit()
	var shell := MeshInstance3D.new()
	shell.name = "Volcano"
	shell.mesh = shell_mesh
	shell.material_override = basalt
	add_child(shell)

	var body := StaticBody3D.new()
	body.name = "VolcanoBody"
	body.collision_layer = Layers.WORLD
	body.collision_mask = Layers.WORLD
	var collider := CollisionShape3D.new()
	var concave := shell_mesh.create_trimesh_shape()
	concave.backface_collision = true
	collider.shape = concave
	body.add_child(collider)
	add_child(body)

	_crater_pool_material = _lava_pool_material()
	var pool := MeshInstance3D.new()
	pool.name = "LavaPool"
	var pool_mesh := CylinderMesh.new()
	pool_mesh.top_radius = VOLCANO_POOL_R
	pool_mesh.bottom_radius = VOLCANO_POOL_R
	pool_mesh.height = 0.5
	pool_mesh.radial_segments = 32
	pool_mesh.rings = 1
	pool_mesh.material = _crater_pool_material
	pool.mesh = pool_mesh
	pool.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	pool.position = Vector3(VOLCANO_XY.x, _volcano_pool_y() + 0.3, VOLCANO_XY.y)
	add_child(pool)

	var glow := OmniLight3D.new()
	glow.name = "CraterLight"
	glow.light_color = Color(1.0, 0.4, 0.1)
	glow.light_energy = 4.0
	glow.omni_range = 90.0
	glow.position = Vector3(VOLCANO_XY.x, _volcano_pool_y() + 9.0, VOLCANO_XY.y)
	add_child(glow)

	var smoke := CPUParticles3D.new()
	smoke.name = "VolcanoSmoke"
	smoke.amount = 14
	smoke.lifetime = 9.0
	smoke.direction = Vector3.UP
	smoke.spread = 14.0
	smoke.gravity = Vector3(0.4, 2.4, 0.0)
	smoke.initial_velocity_min = 2.0
	smoke.initial_velocity_max = 4.5
	smoke.scale_amount_min = 4.0
	smoke.scale_amount_max = 9.0
	smoke.color = Color(0.24, 0.22, 0.22, 0.5)
	var puff := SphereMesh.new()
	puff.radius = 1.0
	puff.height = 2.0
	var puff_material := MeshUtil.make_material(Color(0.26, 0.24, 0.24), 0.0, 1.0)
	puff_material.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
	puff_material.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
	puff_material.vertex_color_use_as_albedo = true
	puff.material = puff_material
	smoke.mesh = puff
	smoke.position = Vector3(VOLCANO_XY.x, _volcano_pool_y() + 26.0, VOLCANO_XY.y)
	add_child(smoke)
	smoke.emitting = true

func _volcano_vertex(k: int, i: int) -> Vector3:
	var angle := TAU * float(i) / float(VOLCANO_SEGMENTS)
	var rim_radius := volcano_rim_radius(angle)
	var radius: float
	var height: float
	if k <= VOLCANO_FLANK_RINGS:
		var u := float(k) / float(VOLCANO_FLANK_RINGS)
		radius = lerpf(VOLCANO_RADIUS, rim_radius, u)
		height = _volcano_rim_height(angle) * _volcano_flank_profile(u) \
				* (1.0 + _volcano_relief(angle, u))
	else:
		var j := float(k - VOLCANO_FLANK_RINGS)
		var b := 1.0 - j / float(VOLCANO_BOWL_RINGS)
		radius = rim_radius * b
		height = _volcano_bowl_height(angle, b)
	var x := VOLCANO_XY.x + cos(angle) * radius
	var z := VOLCANO_XY.y + sin(angle) * radius
	if k == 0:
		return Vector3(x, minf(_ground_y(x, z), _volcano_base_y()) - 4.0, z)
	return Vector3(x, _volcano_base_y() + height, z)

func volcano_rim_radius(angle: float) -> float:
	return VOLCANO_RIM_R * (1.0 + 0.15 * sin(5.0 * angle + 0.7)
			+ 0.08 * sin(9.0 * angle + 2.3) + 0.05 * sin(13.0 * angle + 1.1))

func _volcano_rim_height(angle: float) -> float:
	return VOLCANO_HEIGHT * (1.0 + 0.045 * sin(5.0 * angle + 2.1)
			+ 0.03 * sin(11.0 * angle + 0.4))

func _volcano_flank_profile(u: float) -> float:
	return 0.94 * pow(u, 1.3) + 0.06 * u

func _volcano_bowl_height(angle: float, b: float) -> float:
	var floor_height := VOLCANO_HEIGHT - VOLCANO_FLOOR_DROP
	var rim := _volcano_rim_height(angle) * (1.0 + _volcano_relief(angle, 1.0))
	return floor_height + (rim - floor_height) * smoothstep(VOLCANO_BOWL_FLOOR_B, 1.0, b)

func _volcano_relief(angle: float, u: float) -> float:
	var gully := 0.55 * sin(7.0 * angle + 1.9) + 0.35 * sin(12.0 * angle + 0.6) \
			+ 0.3 * sin(3.0 * angle + 2.8)
	return 0.055 * gully * (0.35 + 0.65 * u)

func _volcano_base_y() -> float:
	return _ground_y(VOLCANO_XY.x, VOLCANO_XY.y)

func _volcano_pool_y() -> float:
	return _volcano_base_y() + VOLCANO_HEIGHT - VOLCANO_FLOOR_DROP

func _volcano_slope(angle: float, dist: float) -> float:
	var rim_radius := volcano_rim_radius(angle)
	if dist >= rim_radius:
		var span := VOLCANO_RADIUS - rim_radius
		var u := clampf((VOLCANO_RADIUS - dist) / span, 0.0, 1.0)
		var profile := 1.222 * pow(u, 0.3) + 0.06
		return -_volcano_rim_height(angle) * (1.0 + _volcano_relief(angle, u)) \
				* profile / span
	var b := clampf(dist / rim_radius, 0.0, 1.0)
	if b <= VOLCANO_BOWL_FLOOR_B:
		return 0.0
	var bowl_span := 1.0 - VOLCANO_BOWL_FLOOR_B
	var s := (b - VOLCANO_BOWL_FLOOR_B) / bowl_span
	var floor_height := VOLCANO_HEIGHT - VOLCANO_FLOOR_DROP
	var rim := _volcano_rim_height(angle) * (1.0 + _volcano_relief(angle, 1.0))
	return (rim - floor_height) * (6.0 * s * (1.0 - s) / bowl_span) / rim_radius

func _volcano_normal(angle: float, dist: float) -> Vector3:
	var radial := Vector3(cos(angle), 0.0, sin(angle))
	return (Vector3.UP - radial * _volcano_slope(angle, dist)).normalized()

func _emit_volcano_vertex(surface: SurfaceTool, point: Vector3) -> void:
	var offset := Vector2(point.x - VOLCANO_XY.x, point.z - VOLCANO_XY.y)
	var angle := atan2(offset.y, offset.x)
	surface.set_normal(_volcano_normal(angle, offset.length()))
	surface.set_color(_volcano_color(point.y, point.x, point.z))
	surface.add_vertex(point)

func _volcano_color(y: float, x: float, z: float) -> Color:
	var t := clampf((y - _volcano_base_y()) / VOLCANO_HEIGHT, 0.0, 1.0)
	var streak := 0.5 + 0.5 * sin(x * 0.42 + z * 0.31)
	var warm := clampf(t * 0.8 + streak * 0.3 * t, 0.0, 1.0)
	return Color(0.07, 0.065, 0.065).lerp(Color(0.2, 0.12, 0.085), warm)

func volcano_surface_height(angle: float, dist: float) -> float:
	var rim_radius := volcano_rim_radius(angle)
	var height: float
	if dist >= rim_radius:
		var span := VOLCANO_RADIUS - rim_radius
		var u := clampf((VOLCANO_RADIUS - dist) / span, 0.0, 1.0)
		height = _volcano_rim_height(angle) * _volcano_flank_profile(u) \
				* (1.0 + _volcano_relief(angle, u))
	else:
		var b := clampf(dist / rim_radius, 0.0, 1.0)
		height = _volcano_bowl_height(angle, b)
	var x := VOLCANO_XY.x + cos(angle) * dist
	var z := VOLCANO_XY.y + sin(angle) * dist
	return maxf(_volcano_base_y() + height, _ground_y(x, z))

func volcano_point_height(x: float, z: float) -> float:
	var offset := Vector2(x - VOLCANO_XY.x, z - VOLCANO_XY.y)
	return volcano_surface_height(atan2(offset.y, offset.x), offset.length())

func crater_hazard() -> Dictionary:
	return {
		"centre": VOLCANO_XY,
		"radius": VOLCANO_RIM_R * 1.25,
		"level": _volcano_pool_y() + 2.0,
		"dps": 0.12,
		"kind": &"magma",
	}

func set_crater_glow(value: float) -> void:
	if _crater_pool_material != null:
		_crater_pool_material.set_shader_parameter("glow", value)

func _lava_pool_material() -> ShaderMaterial:
	var shader := Shader.new()
	shader.code = """
shader_type spatial;

uniform float glow : hint_range(0.0, 6.0) = 1.4;

varying vec3 v_local;

void vertex() {
	v_local = VERTEX;
}

void fragment() {
	float veins = 0.5 + 0.5 * sin(v_local.x * 0.7 + TIME * 0.6)
			* sin(v_local.z * 0.62 - TIME * 0.8);
	float crust = smoothstep(0.1, 0.7, veins);
	vec3 hot = vec3(1.0, 0.34, 0.03);
	vec3 cool = vec3(0.26, 0.04, 0.01);
	ALBEDO = mix(cool, hot, crust);
	EMISSION = hot * (0.3 + crust) * glow;
	ROUGHNESS = 0.6;
}
"""
	var material := ShaderMaterial.new()
	material.shader = shader
	return material

func _build_clouds() -> void:
	var cloud_material := MeshUtil.make_material(Color(1.0, 1.0, 1.0), 0.0, 1.0,
			Color(1.0, 1.0, 1.0), 0.7)
	for index in 14:
		var cloud := MeshUtil.make_sphere(1.0, cloud_material, 8, 6)
		cloud.name = "Cloud_%02d" % index
		var width := randf_range(16.0, 38.0)
		cloud.scale = Vector3(width, randf_range(3.0, 5.5), width * randf_range(0.5, 0.9))
		cloud.position = Vector3(randf_range(-CLOUD_WRAP, CLOUD_WRAP),
				randf_range(52.0, 86.0), randf_range(-240.0, 160.0))
		cloud.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
		add_child(cloud)
		_clouds.append(cloud)
		_cloud_speed.append(randf_range(0.5, 1.4))

func _build_sun_disk() -> void:
	var yaw := 0.0
	if _environment != null:
		yaw = _environment.sky_rotation.y
	var sun_root := Node3D.new()
	sun_root.name = "SunDisk"
	sun_root.rotation_degrees = Vector3(-60.0, yaw, 0.0)
	add_child(sun_root)
	var disk_material := StandardMaterial3D.new()
	disk_material.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
	disk_material.albedo_color = Color(1.0, 0.98, 0.9)
	disk_material.emission_enabled = true
	disk_material.emission = Color(1.0, 0.97, 0.85)
	disk_material.emission_energy_multiplier = 9.0
	var disk := MeshInstance3D.new()
	disk.name = "SunCore"
	var sphere := SphereMesh.new()
	sphere.radius = 15.0
	sphere.height = 30.0
	sphere.radial_segments = 16
	sphere.rings = 8
	disk.mesh = sphere
	disk.material_override = disk_material
	disk.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	disk.position = Vector3(0.0, 0.0, -460.0)
	sun_root.add_child(disk)
	var halo_material := StandardMaterial3D.new()
	halo_material.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
	halo_material.albedo_texture = _halo_texture()
	halo_material.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
	halo_material.blend_mode = BaseMaterial3D.BLEND_MODE_ADD
	halo_material.billboard_mode = BaseMaterial3D.BILLBOARD_ENABLED
	var halo := MeshInstance3D.new()
	halo.name = "SunHalo"
	var quad := QuadMesh.new()
	quad.size = Vector2(150.0, 150.0)
	quad.material = halo_material
	halo.mesh = quad
	halo.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	halo.position = Vector3(0.0, 0.0, -459.0)
	sun_root.add_child(halo)

func _halo_texture() -> Texture2D:
	if _halo != null:
		return _halo
	var size := 64
	var image := Image.create(size, size, false, Image.FORMAT_RGBA8)
	var center := float(size) * 0.5
	for y in size:
		for x in size:
			var dx := (float(x) + 0.5 - center) / center
			var dy := (float(y) + 0.5 - center) / center
			var r := sqrt(dx * dx + dy * dy)
			var falloff := clampf(1.0 - r, 0.0, 1.0)
			falloff = falloff * falloff
			image.set_pixel(x, y, Color(1.0, 0.96, 0.85, falloff))
	_halo = ImageTexture.create_from_image(image)
	return _halo

func _process(delta: float) -> void:
	for index in _clouds.size():
		var cloud := _clouds[index]
		cloud.position.x += _cloud_speed[index] * delta * wind_scale
		if cloud.position.x > CLOUD_WRAP:
			cloud.position.x = -CLOUD_WRAP
	_strike_clock -= delta
	if _strike_clock <= 0.0:
		_strike_clock = randf_range(7.0, 13.0)
		_strike_lightning()

func _strike_lightning() -> void:
	var angle := randf_range(0.0, TAU)
	var distance := randf_range(70.0, 170.0)
	# Centre the strike on the player so thunder is always visible in-match
	# instead of flashing somewhere behind the rim.
	var centre := Vector2.ZERO
	var player := get_tree().get_first_node_in_group("player") as Node3D
	if player != null:
		centre = Vector2(player.global_position.x, player.global_position.z)
	var strike := Vector3(centre.x + cos(angle) * distance, 0.0,
			centre.y + sin(angle) * distance)
	_spawn_bolt(strike)
	_spawn_flash(strike)
	_pulse_ambient()
	var delay := clampf(distance / 340.0, 0.35, 1.4)
	var timer := get_tree().create_timer(delay)
	timer.timeout.connect(_play_thunder)

func _spawn_bolt(strike: Vector3) -> void:
	var bolt := Node3D.new()
	# Unique serial: two bolts alive at once (auto-strike + manual test strike)
	# would collide and Godot would rename the newcomer, hiding it from the
	# "LightningBolt*" lookups.
	bolt.name = "LightningBolt%d" % _bolt_serial
	_bolt_serial += 1
	var point := strike + Vector3(0.0, 95.0, 0.0)
	var segments := 7
	for index in segments:
		var next := strike + Vector3(randf_range(-6.0, 6.0),
				95.0 - 95.0 * float(index + 1) / float(segments),
				randf_range(-6.0, 6.0))
		var mid := (point + next) * 0.5
		var length := point.distance_to(next)
		var piece := MeshUtil.make_box(Vector3(0.5, length, 0.5), _bolt_material, "bolt")
		piece.position = mid
		piece.basis = MeshUtil.segment_basis(next - point)
		bolt.add_child(piece)
		point = next
	add_child(bolt)
	var timer := get_tree().create_timer(0.3)
	timer.timeout.connect(bolt.queue_free)

func _spawn_flash(strike: Vector3) -> void:
	var light := OmniLight3D.new()
	light.name = "StrikeFlash"
	light.light_color = Color(0.8, 0.88, 1.0)
	light.light_energy = 30.0
	light.omni_range = 320.0
	light.shadow_enabled = false
	light.position = strike + Vector3(0.0, 70.0, 0.0)
	add_child(light)
	_flash_lights.append(light)
	var tween := create_tween()
	tween.tween_property(light, "light_energy", 0.0, 0.45)
	tween.tween_callback(_forget_flash.bind(light))

func _forget_flash(light: OmniLight3D) -> void:
	_flash_lights.erase(light)

func _pulse_ambient() -> void:
	if _environment == null:
		return
	_environment.ambient_light_energy = 1.7
	var tween := create_tween()
	tween.tween_property(_environment, "ambient_light_energy", _ambient_base, 0.55)

func _play_thunder() -> void:
	if _thunder_streams.is_empty():
		_build_thunder_streams()
	if _thunder_streams.is_empty():
		return
	_thunder_player.stream = _thunder_streams[randi() % _thunder_streams.size()]
	_thunder_player.pitch_scale = randf_range(0.85, 1.12)
	_thunder_player.volume_db = randf_range(-4.0, 3.0)
	_thunder_player.play()

func _build_thunder_streams() -> void:
	var mix_rate := 22050
	for variant_index in 3:
		var duration := randf_range(1.8, 2.8)
		var sample_count := int(duration * float(mix_rate))
		var bytes := PackedByteArray()
		bytes.resize(sample_count * 2)
		var brown := 0.0
		var envelope := 0.0
		var seed_value := 7919 * (variant_index + 1)
		for index in sample_count:
			var t := float(index) / float(mix_rate)
			seed_value = (seed_value * 1103515245 + 12345) & 0x7fffffff
			var white := float(seed_value % 20000 - 10000) / 10000.0
			brown = clampf(brown + white * 0.06, -1.0, 1.0) * 0.985
			var attack := clampf(t / 0.03, 0.0, 1.0)
			var decay := exp(-t * 1.4)
			var rumble := 0.55 + 0.45 * sin(TAU * 0.9 * t + float(variant_index))
			envelope = attack * decay * rumble
			var crack := 0.0
			if t < 0.14:
				crack = white * 0.6 * (1.0 - t / 0.14)
			var sample := clampf((brown * 1.4 + crack) * envelope, -1.0, 1.0)
			var value := int(sample * 30000.0)
			bytes.encode_s16(index * 2, value)
		var stream := AudioStreamWAV.new()
		stream.format = AudioStreamWAV.FORMAT_16_BITS
		stream.mix_rate = mix_rate
		stream.stereo = false
		stream.data = bytes
		_thunder_streams.append(stream)

