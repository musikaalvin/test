class_name WeatherSystem
extends Node3D

## Living-map weather: a player-relative storm cell (rain or snow) plus PERMANENT
## regional micro-climates over each district, so different parts of the map
## always show different weather at the same time. Fully original procedural
## synthesis — particle meshes and looped noise WAVs, no external assets.

enum State { CLEAR, RAIN, SNOW }

const CELL_WRAP := 210.0

# Regional micro-climates: PERMANENT weather stations over each realm district
# so different parts of the map always have different weather (industrial rain,
# ruin snow, clear hub/city/volcano). They run independently of the global
# storm schedule, so a clear day still shows rain over the factory district.
const ZONES: Array[Dictionary] = [
	{"name": "INDUSTRIAL", "centre": Vector2(95.0, -70.0), "extent": 62.0,
			"kind": State.RAIN},
	{"name": "RUINS", "centre": Vector2(-95.0, -55.0), "extent": 62.0,
			"kind": State.SNOW},
	{"name": "HUB", "centre": Vector2(0.0, 34.0), "extent": 55.0,
			"kind": State.CLEAR},
	{"name": "CITY", "centre": Vector2(75.0, 85.0), "extent": 58.0,
			"kind": State.CLEAR},
	{"name": "VOLCANO", "centre": Vector2(165.0, -195.0), "extent": 70.0,
			"kind": State.CLEAR},
]

var state: int = State.CLEAR
var nature: Nature

var _env: Environment
var _ambient_true: float = 1.0
var _state_left: float = 16.0
var _storm_clock: float = 5.0
var _first_event_done: bool = false
var _cell := Vector2(-40.0, -20.0)
var _cell_velocity := Vector2(6.5, 4.5)
var _t := 0.0
var _rain: CPUParticles3D
var _snow: CPUParticles3D
var _zones: Array[CPUParticles3D] = []
var _zone_bases: Array[Vector2] = []
var _zone_uses: Array[bool] = []
var _rain_player: AudioStreamPlayer
var _wind_player: AudioStreamPlayer
var _fog_stored := false
var _fog_enabled_base := false
var _fog_density_base := 0.01

func setup(host: Nature, environment: Environment, ambient_base: float) -> void:
	nature = host
	_env = environment
	_ambient_true = ambient_base
	# First change comes quick so a 5-minute match always shows weather.
	_state_left = randf_range(6.0, 10.0)
	if _env != null:
		_fog_enabled_base = _env.fog_enabled
		_fog_density_base = _env.fog_density

func _ready() -> void:
	_rain = _build_precip(true)
	_snow = _build_precip(false)
	_rain.emitting = false
	_snow.emitting = false
	add_child(_rain)
	add_child(_snow)
	for index in ZONES.size():
		var zone := ZONES[index]
		var zone_cell := _build_precip(int(zone["kind"]) == State.RAIN, true)
		zone_cell.name = "Zone%s" % zone["name"]
		zone_cell.position = Vector3((zone["centre"] as Vector2).x, 34.0,
				(zone["centre"] as Vector2).y)
		zone_cell.emission_box_extents.x = float(zone["extent"])
		zone_cell.emission_box_extents.z = float(zone["extent"])
		var precipitating := int(zone["kind"]) != State.CLEAR
		# CPUParticles3D.amount must be >= 1 or the renderer logs an error on
		# every startup; a CLEAR zone keeps the minimum and stays un-emitting.
		zone_cell.amount = 1
		if precipitating:
			if int(zone["kind"]) == State.RAIN:
				zone_cell.amount = 420
			else:
				zone_cell.amount = 280
		zone_cell.emitting = precipitating
		add_child(zone_cell)
		_zones.append(zone_cell)
		_zone_bases.append(zone["centre"] as Vector2)
		_zone_uses.append(precipitating)
	_rain_player = AudioStreamPlayer.new()
	_rain_player.name = "RainLoop"
	_rain_player.volume_db = -12.0
	_rain_player.stream = _make_noise_loop(2.0, false)
	add_child(_rain_player)
	_wind_player = AudioStreamPlayer.new()
	_wind_player.name = "WindLoop"
	_wind_player.volume_db = -16.0
	_wind_player.stream = _make_noise_loop(3.0, true)
	add_child(_wind_player)

func _build_precip(is_rain: bool, is_zone: bool = false) -> CPUParticles3D:
	var cell := CPUParticles3D.new()
	cell.name = "RainCell" if is_rain else "SnowCell"
	# Precipitation is CPUParticles — budget it against CPU headroom.
	cell.amount = maxi(120, roundi((900.0 if is_rain else 550.0) * Hardware.fx_scale()))
	cell.lifetime = 1.5 if is_rain else 7.0
	cell.emission_shape = CPUParticles3D.EMISSION_SHAPE_BOX
	cell.emission_box_extents = Vector3(45.0, 16.0, 45.0)
	if is_rain:
		cell.direction = Vector3(-0.28, -1.0, 0.1).normalized()
		cell.spread = 2.0
		cell.gravity = Vector3.ZERO
		cell.initial_velocity_min = 20.0
		cell.initial_velocity_max = 28.0
	else:
		cell.direction = Vector3(0.0, -1.0, 0.0)
		cell.spread = 16.0
		cell.gravity = Vector3(0.6, -1.6, 0.2)
		cell.initial_velocity_min = 1.6
		cell.initial_velocity_max = 3.2
	if is_zone:
		# Regional cells are lighter: slower fall, same look. Amount is set by
		# the caller per zone (0 for clear zones).
		cell.initial_velocity_min *= 0.7
		cell.initial_velocity_max *= 0.7
	var material := StandardMaterial3D.new()
	material.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
	if is_rain:
		var streak := BoxMesh.new()
		streak.size = Vector3(0.05, 0.65, 0.05)
		material.albedo_color = Color(0.72, 0.84, 1.0, 0.5)
		material.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
		material.vertex_color_use_as_albedo = false
		streak.material = material
		cell.mesh = streak
	else:
		var flake := SphereMesh.new()
		flake.radius = 0.07
		flake.height = 0.14
		flake.radial_segments = 5
		flake.rings = 3
		material.albedo_color = Color(0.96, 0.98, 1.0, 0.9)
		material.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
		flake.material = material
		cell.mesh = flake
	cell.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	cell.position = Vector3(0.0, 34.0, 0.0)
	return cell

func _process(delta: float) -> void:
	_cell += _cell_velocity * delta
	if _cell.x > CELL_WRAP:
		_cell.x = -CELL_WRAP
	if _cell.y > CELL_WRAP:
		_cell.y = -CELL_WRAP
	_rain.position = Vector3(_cell.x, 34.0, _cell.y)
	_snow.position = Vector3(_cell.x, 34.0, _cell.y)

	_t += delta
	for index in _zones.size():
		if not _zone_uses[index]:
			continue
		var base := _zone_bases[index]
		var sway := Vector2(sin(_t * 0.12 + float(index) * 2.1),
				cos(_t * 0.09 + float(index) * 1.7)) * 4.0
		_zones[index].position = Vector3(base.x + sway.x, 34.0, base.y + sway.y)

	_state_left -= delta
	if _state_left <= 0.0:
		_advance_schedule()
	if state == State.RAIN:
		_storm_clock -= delta
		if _storm_clock <= 0.0:
			_storm_clock = randf_range(4.0, 7.0)
			if nature != null:
				nature.strike_lightning()

func _advance_schedule() -> void:
	match state:
		State.CLEAR:
			# Guarantee a rainstorm first (visible lightning early in the
			# match), then alternate rain / snow.
			if not _first_event_done:
				_first_event_done = true
				_enter_state(State.RAIN, randf_range(30.0, 45.0))
			elif randf() < 0.5:
				_enter_state(State.RAIN, randf_range(30.0, 45.0))
			else:
				_enter_state(State.SNOW, randf_range(25.0, 40.0))
		State.RAIN:
			_enter_state(State.CLEAR, randf_range(28.0, 45.0))
		State.SNOW:
			_enter_state(State.CLEAR, randf_range(28.0, 45.0))

## Deterministic override for tests / director previews.
func force_state(state_name: String) -> void:
	match state_name.to_lower():
		"rain":
			_enter_state(State.RAIN, 9999.0)
		"snow":
			_enter_state(State.SNOW, 9999.0)
		_:
			_enter_state(State.CLEAR, 9999.0)

func state_name() -> String:
	match state:
		State.RAIN:
			return "RAIN"
		State.SNOW:
			return "SNOW"
	return "CLEAR"

# Place the precipitation cell upwind of the player (cell drifts +x/+y) so
# every storm actually crosses the fight instead of falling over the void.
func _snap_cell_to_player() -> void:
	var tree := get_tree()
	if tree == null:
		return
	var player := tree.get_first_node_in_group("player") as Node3D
	if player == null:
		return
	var px := player.global_position.x
	var pz := player.global_position.z
	if Vector2(_cell.x - px, _cell.y - pz).length() > 150.0:
		_cell = Vector2(px, pz) + Vector2(randf_range(-85.0, -35.0),
				randf_range(-75.0, -30.0))

func _enter_state(next: int, duration: float) -> void:
	state = next
	_state_left = duration
	var raining := next == State.RAIN
	var snowing := next == State.SNOW
	if raining or snowing:
		_snap_cell_to_player()
	_rain.emitting = raining
	_snow.emitting = snowing
	if _rain_player != null:
		if raining:
			if not _rain_player.playing:
				_rain_player.play()
		else:
			_rain_player.stop()
	if _wind_player != null:
		if raining or snowing:
			if not _wind_player.playing:
				_wind_player.play()
		else:
			_wind_player.stop()
	_apply_environment()
	_apply_wind()
	_apply_water(raining)
	_storm_clock = randf_range(3.0, 6.0)

func _apply_environment() -> void:
	if nature == null:
		return
	var factor := 1.0
	if state == State.RAIN:
		factor = 0.62
	elif state == State.SNOW:
		factor = 0.82
	nature.set_ambient_level(_ambient_true * factor)
	if _env == null:
		return
	if state == State.CLEAR:
		_env.fog_enabled = _fog_enabled_base
		_env.fog_density = _fog_density_base
	else:
		if not _fog_stored:
			_fog_enabled_base = _env.fog_enabled
			_fog_density_base = _env.fog_density
			_fog_stored = true
		_env.fog_enabled = true
		_env.fog_density = 0.012 if state == State.RAIN else 0.008

func _apply_wind() -> void:
	if nature == null:
		return
	match state:
		State.RAIN:
			nature.wind_scale = 2.3
		State.SNOW:
			nature.wind_scale = 1.5
		_:
			nature.wind_scale = 1.0

func _apply_water(raining: bool) -> void:
	if nature == null:
		return
	var water := nature.get_tree().get_first_node_in_group("water") as MeshInstance3D
	if water == null:
		return
	var material := water.material_override
	if material == null and water.mesh is PlaneMesh:
		material = (water.mesh as PlaneMesh).material
	var shader := material as ShaderMaterial
	if shader == null:
		return
	shader.set_shader_parameter("rain_strength", 1.0 if raining else 0.0)

## Looping noise: wind = deep brown howl with an integer-cycle amplitude LFO
## (seamless), rain = bright filtered patter. Original synthesis.
func _make_noise_loop(duration: float, wind: bool) -> AudioStreamWAV:
	var mix_rate := 22050
	var sample_count := int(duration * float(mix_rate))
	var bytes := PackedByteArray()
	bytes.resize(sample_count * 2)
	var seed_value := 6151 if wind else 4243
	var lp := 0.0
	var brown := 0.0
	var lfo_cycles := 3.0 if wind else 2.0
	for index in sample_count:
		var t := float(index) / float(mix_rate)
		seed_value = (seed_value * 1103515245 + 12345) & 0x7fffffff
		var white := float(seed_value % 20000 - 10000) / 10000.0
		var sample := 0.0
		if wind:
			brown = clampf(brown + white * 0.05, -1.0, 1.0) * 0.99
			lp = lp * 0.9 + brown * 0.1
			var lfo := 0.55 + 0.45 * sin(TAU * lfo_cycles * t / duration)
			sample = lp * 2.4 * lfo * 0.6
		else:
			lp = lp * 0.86 + white * 0.14
			var patter := white * 0.6 + lp * 0.9
			var gust := 0.75 + 0.25 * sin(TAU * lfo_cycles * t / duration)
			sample = patter * gust * 0.55
		bytes.encode_s16(index * 2, int(clampf(sample, -1.0, 1.0) * 27000.0))
	var stream := AudioStreamWAV.new()
	stream.format = AudioStreamWAV.FORMAT_16_BITS
	stream.mix_rate = mix_rate
	stream.stereo = false
	stream.data = bytes
	stream.loop_mode = AudioStreamWAV.LOOP_FORWARD
	stream.loop_begin = 0
	stream.loop_end = sample_count
	return stream
