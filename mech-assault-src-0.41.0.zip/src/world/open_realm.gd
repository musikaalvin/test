class_name OpenRealm
extends CombatArena

const TERRAIN_EXTENT := 230.0
const TERRAIN_CELLS := 160
const SUN_YAW_DEGREES := 210.0
const LAKE_CENTRE := Vector2(-90.0, 60.0)
const WATER_LEVEL := -1.6
const MAGMA_CENTRE := Vector2(110.0, -130.0)
const MAGMA_LEVEL := -0.5

# Sci-fi transit tunnel (the map's "cave" replacement): a bored corridor cut
# into the heightfield north of the hub, shell/ribs/lights built in code.
const TUNNEL_START := Vector2(0.0, 118.0)
const TUNNEL_END := Vector2(0.0, 168.0)
const TUNNEL_HALF_WIDTH := 5.5
const TUNNEL_SLOPE := 2.5
const TUNNEL_DEPTH := 6.6
const TUNNEL_FLOOR := -5.8
const TUNNEL_RAMP := 10.0
const TUNNEL_SEGMENT := 5.0
const TUNNEL_WALL_X := 5.6
const TUNNEL_SKIRT := 9.0

const HUB := Vector2(0.0, 34.0)
const INDUSTRIAL := Vector2(95.0, -70.0)
const RUINS_CENTRE := Vector2(-95.0, -55.0)
const CITY := Vector2(75.0, 85.0)

const KIT := "res://assets/maps/kit/"
const DOWNTOWN_KIT := "res://assets/maps/downtown/Exports/glTF (Godot)/"
const RUINS := "res://assets/models/ruins/glb/"
const VILLAGE := "res://assets/models/village/Modular Village/"
const ROADS := "res://assets/models/roads/Models/"
const BEACH := "res://assets/models/terrain/Modular Terrain Beach/"
const HILLY := "res://assets/models/terrain/Modular Terrain Hilly/"
const DUNGEON := "res://assets/models/dungeon/Dungeon Set 2/"
const SCIFI := "res://assets/models/scifi_props/"
const BUILDING_SCALE := 8.0
const PROP_SCALE := 6.0

# Ground cover is a zero-thickness plane. Grass_Flat.obj is an 8-vertex
# 1 x 0.2 x 1 box: instanced at the old 2.4 m target every tuft stood
# 0.5-1.6 m proud of the terrain and read as a placeholder slab, so cover is
# now a flat patch seated a few centimetres above the surface — it can never
# grow a side wall, whatever the slope under it does.
const COVER_LIFT := 0.06
const COVER_WIDTH_MIN := 1.6
const COVER_WIDTH_MAX := 3.6

var _ground_material: StandardMaterial3D
var _rock_material: StandardMaterial3D
var _asphalt_material: StandardMaterial3D
var _cobble_material: StandardMaterial3D
var _stone_material: StandardMaterial3D
var _wood_material: StandardMaterial3D
var _sand_material: StandardMaterial3D
var _grass_material: StandardMaterial3D
var _cover_material: StandardMaterial3D
var _rust_material: StandardMaterial3D
var _structure_spots: Array[Vector3] = []

func _ready() -> void:
	_make_materials()
	_build_environment()
	_build_terrain()
	_build_water()
	_build_magma()
	_build_hub()
	_build_bunkers()
	_build_climb_wall()
	_build_tunnel()
	_build_industrial()
	_build_ruins_district()
	_build_lake_shore()
	_build_city()
	_define_spawns()
	_build_wilderness()
	_build_rim()
	_register_hazards()
	_build_district_cover()
	_build_district_edges()
	_build_district_plateaus()

static func terrain_height(x: float, z: float) -> float:
	var height := 1.1 * sin(x * 0.026) * cos(z * 0.022)
	height += 0.75 * sin((x * 0.7 + z * 1.3) * 0.017)
	height += 0.5 * sin(x * 0.05 + 1.4) * sin(z * 0.041 - 0.6)
	height += 6.5 * exp(-((x - 70.0) * (x - 70.0) + (z + 120.0) * (z + 120.0)) / 2600.0)
	height += 5.0 * exp(-((x + 40.0) * (x + 40.0) + (z + 150.0) * (z + 150.0)) / 1800.0)
	height += 3.5 * exp(-((x - 150.0) * (x - 150.0) + (z + 30.0) * (z + 30.0)) / 2200.0)
	height += 4.2 * exp(-((x + 150.0) * (x + 150.0) + (z - 150.0) * (z - 150.0)) / 2400.0)
	var lake_dx := x - LAKE_CENTRE.x
	var lake_dz := z - LAKE_CENTRE.y
	height -= 7.5 * exp(-(lake_dx * lake_dx + lake_dz * lake_dz) / 2400.0)
	var magma_dx := x - MAGMA_CENTRE.x
	var magma_dz := z - MAGMA_CENTRE.y
	height -= 9.0 * exp(-(magma_dx * magma_dx + magma_dz * magma_dz) / 1600.0)
	height = _flatten(height, x, z, HUB, 44.0, 1.2)
	height = _flatten(height, x, z, INDUSTRIAL, 58.0, 2.2)
	height = _flatten(height, x, z, RUINS_CENTRE, 48.0, 3.4)
	height = _flatten(height, x, z, CITY, 62.0, 1.8)
	height = _carve_tunnel(height, x, z)
	var radius := sqrt(x * x + z * z)
	if radius > 185.0:
		height = lerpf(height, 30.0, clampf((radius - 185.0) / 30.0, 0.0, 1.0))
	if radius > 216.0:
		height = lerpf(height, -8.0, clampf((radius - 216.0) / 14.0, 0.0, 1.0))
	return height

static func _flatten(height: float, x: float, z: float, centre: Vector2,
		radius: float, target: float) -> float:
	var distance := Vector2(x, z).distance_to(centre)
	return lerpf(height, target, 1.0 - smoothstep(radius * 0.62, radius, distance))

static func _seam_weight(x: float, z: float, centre: Vector2, radius: float) -> float:
	return 1.0 - smoothstep(radius * 0.62, radius, Vector2(x, z).distance_to(centre))

static func _ground_tint(x: float, z: float) -> Color:
	var weight := 0.0
	weight = maxf(weight, _seam_weight(x, z, HUB, 44.0))
	weight = maxf(weight, _seam_weight(x, z, INDUSTRIAL, 58.0))
	weight = maxf(weight, _seam_weight(x, z, RUINS_CENTRE, 48.0))
	weight = maxf(weight, _seam_weight(x, z, CITY, 62.0))
	return Color(1.0, 1.0, 1.0).lerp(Color(0.8, 0.75, 0.6), weight)

# Rectangular trench with sloped shoulders and an entrance ramp at each end.
# Full depth only in the middle of the span; the shell builder matches it.
static func _carve_tunnel(height: float, x: float, z: float) -> float:
	var outer := TUNNEL_HALF_WIDTH + TUNNEL_SLOPE
	if absf(x) > outer or z < TUNNEL_START.y or z > TUNNEL_END.y:
		return height
	var lateral := 1.0 - smoothstep(TUNNEL_HALF_WIDTH, outer, absf(x))
	var along := smoothstep(0.0, TUNNEL_RAMP,
			minf(z - TUNNEL_START.y, TUNNEL_END.y - z))
	if lateral <= 0.001 or along <= 0.001:
		return height
	var profile := lateral * along
	var dug := height - TUNNEL_DEPTH * profile
	return lerpf(dug, TUNNEL_FLOOR, profile * 0.9)

func _make_materials() -> void:
	if AssetLibrary.has_pbr_set("forest_ground"):
		_ground_material = AssetLibrary.pbr_material("forest_ground",
				Vector2(0.125, 0.125))
		_ground_material.cull_mode = BaseMaterial3D.CULL_DISABLED
		_ground_material.vertex_color_use_as_albedo = true
	else:
		_ground_material = MeshUtil.make_material(Color(0.19, 0.24, 0.16), 0.0, 1.0)
		_ground_material.cull_mode = BaseMaterial3D.CULL_DISABLED
		_ground_material.vertex_color_use_as_albedo = true
	if AssetLibrary.has_pbr_set("rock"):
		_rock_material = AssetLibrary.pbr_material("rock", Vector2.ONE,
				Color(0.8, 0.8, 0.8), 1.0, 0.9)
	else:
		_rock_material = AssetLibrary.textured_material(
				AssetLibrary.ROCK_TEXTURES[0], AssetLibrary.ROCK_NORMALS[0], 0.95)
	if AssetLibrary.has_pbr_set("asphalt"):
		_asphalt_material = AssetLibrary.pbr_material("asphalt", Vector2.ONE,
				Color(0.75, 0.75, 0.78))
	else:
		_asphalt_material = MeshUtil.make_material(Color(0.13, 0.13, 0.14), 0.0, 0.92)
	_cobble_material = MeshUtil.make_material(Color(0.36, 0.33, 0.29), 0.0, 0.9)
	_stone_material = MeshUtil.make_material(Color(0.46, 0.44, 0.4), 0.0, 0.9)
	_wood_material = MeshUtil.make_material(Color(0.3, 0.22, 0.15), 0.0, 1.0)
	_sand_material = MeshUtil.make_material(Color(0.55, 0.48, 0.33), 0.0, 1.0)
	if AssetLibrary.has_pbr_set("forest_ground"):
		_grass_material = AssetLibrary.pbr_material("forest_ground",
				Vector2(0.5, 0.5), Color(0.78, 0.95, 0.62), 1.0, 0.8)
	else:
		_grass_material = MeshUtil.make_material(Color(0.24, 0.33, 0.16), 0.0, 1.0)
	if AssetLibrary.has_pbr_set("dirt"):
		_cover_material = AssetLibrary.pbr_material("dirt", Vector2(0.4, 0.4))
	else:
		_cover_material = MeshUtil.make_material(Color(0.33, 0.28, 0.2), 0.0, 1.0)
	_rust_material = MeshUtil.make_material(Color(0.42, 0.25, 0.16), 0.4, 0.85)
	if _ground_material.albedo_texture == null:
		Quality.decorate_material(_ground_material, &"ground", 10.0)
	Quality.decorate_material(_stone_material, &"metal", 2.0)
	Quality.decorate_material(_cobble_material, &"ground", 5.0)

func _build_environment() -> void:
	var world_environment := WorldEnvironment.new()
	world_environment.name = "WorldEnvironment"
	var environment := Environment.new()
	environment.background_mode = Environment.BG_SKY
	environment.sky = Quality.make_sky()
	environment.ambient_light_source = Environment.AMBIENT_SOURCE_COLOR
	environment.ambient_light_color = Color(0.72, 0.7, 0.64)
	environment.ambient_light_energy = 1.3
	environment.fog_light_color = Color(0.74, 0.76, 0.72)
	environment.fog_sky_affect = 0.1
	Quality.apply_environment(environment, SUN_YAW_DEGREES)
	world_environment.environment = environment
	add_child(world_environment)

	var sun := DirectionalLight3D.new()
	sun.name = "Sun"
	sun.rotation_degrees = Vector3(-57.0, SUN_YAW_DEGREES, 0.0)
	sun.light_energy = 3.2
	sun.light_color = Color(1.0, 0.94, 0.82)
	add_child(sun)
	Quality.apply_sun(sun)

	var fill := DirectionalLight3D.new()
	fill.name = "Fill"
	fill.rotation_degrees = Vector3(-22.0, 40.0, 0.0)
	fill.light_energy = 0.55
	fill.light_color = Color(0.65, 0.78, 0.72)
	fill.shadow_enabled = false
	add_child(fill)

	var probe := ReflectionProbe.new()
	probe.name = "ReflectionProbe"
	probe.position = Vector3(0.0, 14.0, 0.0)
	probe.size = Vector3(460.0, 70.0, 460.0)
	probe.box_projection = true
	probe.update_mode = ReflectionProbe.UPDATE_ONCE
	probe.visible = Quality.tier() >= Quality.Tier.MEDIUM
	add_child(probe)

func _build_terrain() -> void:
	var step := TERRAIN_EXTENT * 2.0 / float(TERRAIN_CELLS)
	var surface := SurfaceTool.new()
	surface.begin(Mesh.PRIMITIVE_TRIANGLES)
	for iz in TERRAIN_CELLS:
		for ix in TERRAIN_CELLS:
			var x0 := -TERRAIN_EXTENT + float(ix) * step
			var z0 := -TERRAIN_EXTENT + float(iz) * step
			var x1 := x0 + step
			var z1 := z0 + step
			var v00 := Vector3(x0, terrain_height(x0, z0), z0)
			var v10 := Vector3(x1, terrain_height(x1, z0), z0)
			var v01 := Vector3(x0, terrain_height(x0, z1), z1)
			var v11 := Vector3(x1, terrain_height(x1, z1), z1)
			var c00 := _ground_tint(x0, z0)
			var c10 := _ground_tint(x1, z0)
			var c01 := _ground_tint(x0, z1)
			var c11 := _ground_tint(x1, z1)
			surface.set_uv(Vector2(x0, z0))
			surface.set_color(c00)
			surface.add_vertex(v00)
			surface.set_uv(Vector2(x1, z1))
			surface.set_color(c11)
			surface.add_vertex(v11)
			surface.set_uv(Vector2(x1, z0))
			surface.set_color(c10)
			surface.add_vertex(v10)
			surface.set_uv(Vector2(x0, z0))
			surface.set_color(c00)
			surface.add_vertex(v00)
			surface.set_uv(Vector2(x0, z1))
			surface.set_color(c01)
			surface.add_vertex(v01)
			surface.set_uv(Vector2(x1, z1))
			surface.set_color(c11)
			surface.add_vertex(v11)
	surface.generate_normals()
	var mesh := surface.commit()

	var instance := MeshInstance3D.new()
	instance.name = "RealmTerrain"
	instance.mesh = mesh
	instance.material_override = _ground_material
	instance.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_ON
	add_child(instance)

	var body := StaticBody3D.new()
	body.name = "RealmTerrainBody"
	body.collision_layer = Layers.WORLD
	body.collision_mask = Layers.WORLD
	var shape := CollisionShape3D.new()
	var terrain_shape := mesh.create_trimesh_shape()
	terrain_shape.backface_collision = true
	shape.shape = terrain_shape
	body.add_child(shape)
	add_child(body)

func _build_water() -> void:
	var water := MeshInstance3D.new()
	water.name = "RealmWater"
	var mesh := PlaneMesh.new()
	mesh.size = Vector2(92.0, 92.0)
	mesh.material = _water_material()
	water.mesh = mesh
	water.position = Vector3(LAKE_CENTRE.x, WATER_LEVEL, LAKE_CENTRE.y)
	water.add_to_group("water")
	add_child(water)

func _build_magma() -> void:
	var magma := MeshInstance3D.new()
	magma.name = "RealmMagma"
	var mesh := PlaneMesh.new()
	mesh.size = Vector2(64.0, 64.0)
	mesh.material = _magma_material()
	magma.mesh = mesh
	magma.position = Vector3(MAGMA_CENTRE.x, MAGMA_LEVEL, MAGMA_CENTRE.y)
	add_child(magma)

	var glow := OmniLight3D.new()
	glow.name = "MagmaGlow"
	glow.light_color = Color(1.0, 0.45, 0.12)
	glow.light_energy = 2.6
	glow.omni_range = 60.0
	glow.shadow_enabled = false
	glow.position = Vector3(MAGMA_CENTRE.x, MAGMA_LEVEL + 4.0, MAGMA_CENTRE.y)
	add_child(glow)

	for index in 14:
		var angle := TAU * float(index) / 14.0
		var radius := 32.0 + float(index % 3) * 2.2
		var px := MAGMA_CENTRE.x + cos(angle) * radius
		var pz := MAGMA_CENTRE.y + sin(angle) * radius
		var size := 2.0 + float(index % 4) * 0.7
		AssetLibrary.place(self,
				"res://assets/models/rocks/0%d/rock_0%d.obj" % [(index % 5) + 1, (index % 5) + 1],
				Vector3(px, _ground_at(px, pz) + 0.1, pz), size,
				float(index) * 27.0, _rock_material, true)

func _register_hazards() -> void:
	HazardZones.clear()
	HazardZones.add(LAKE_CENTRE, 44.0, WATER_LEVEL, 0.04, &"water")
	HazardZones.add(MAGMA_CENTRE, 30.0, MAGMA_LEVEL, 0.07, &"magma")

func _water_material() -> ShaderMaterial:
	var shader := Shader.new()
	shader.code = """
shader_type spatial;
render_mode cull_disabled;

uniform vec4 shallow_color : source_color = vec4(0.3, 0.48, 0.45, 1.0);
uniform vec4 deep_color : source_color = vec4(0.03, 0.11, 0.13, 1.0);
uniform vec4 foam_color : source_color = vec4(0.92, 0.98, 1.0, 1.0);
uniform sampler2D scene_depth : hint_depth_texture, filter_linear_mipmap;
uniform float wave_scale = 1.0;
uniform float rain_strength : hint_range(0.0, 1.0) = 0.0;

varying vec3 v_world;
varying float v_height;

float hash(vec2 p) {
	return fract(sin(dot(p, vec2(127.1, 311.7))) * 43758.5453);
}

float noise(vec2 p) {
	vec2 i = floor(p);
	vec2 f = fract(p);
	f = f * f * (3.0 - 2.0 * f);
	return mix(mix(hash(i), hash(i + vec2(1.0, 0.0)), f.x),
			mix(hash(i + vec2(0.0, 1.0)), hash(i + vec2(1.0, 1.0)), f.x), f.y);
}

float wave_height(vec2 p, float t) {
	float h = sin(p.x * 0.34 + t * 0.9) * 0.1;
	h += sin(p.y * 0.27 - t * 0.7) * 0.09;
	h += sin((p.x + p.y) * 0.21 + t * 1.3) * 0.06;
	h += noise(p * 0.18 + vec2(t * 0.25, -t * 0.18)) * 0.17;
	h += noise(p * 0.55 + vec2(-t * 0.5, t * 0.4)) * 0.05;
	return h * wave_scale;
}

void vertex() {
	float t = TIME;
	vec2 p = VERTEX.xz;
	v_height = wave_height(p, t);
	VERTEX.y += v_height;
	float e = 0.35;
	float hx = wave_height(p + vec2(e, 0.0), t);
	float hz = wave_height(p + vec2(0.0, e), t);
	NORMAL = normalize(vec3(-(hx - v_height) / e, 1.0, -(hz - v_height) / e));
	v_world = (MODEL_MATRIX * vec4(VERTEX, 1.0)).xyz;
}

void fragment() {
	float t = TIME;
	float view_dist = -(INV_VIEW_MATRIX * vec4(v_world, 1.0)).z;
	float raw_depth = texture(scene_depth, SCREEN_UV).r;
	vec3 ndc = vec3(SCREEN_UV * 2.0 - 1.0, raw_depth);
	vec4 view_pos = INV_PROJECTION_MATRIX * vec4(ndc, 1.0);
	view_pos.xyz /= view_pos.w;
	float scene_dist = -view_pos.z;
	float depth_diff = max(scene_dist - view_dist, 0.0);
	float depth_factor = 1.0 - exp(-depth_diff * 0.32);

	float fresnel = pow(1.0 - clamp(abs(dot(NORMAL, VIEW)), 0.0, 1.0), 2.4);
	vec3 col = mix(deep_color.rgb, shallow_color.rgb, fresnel * 0.85 + depth_factor * 0.3);
	float sparkle = step(0.985, noise(v_world.xz * 3.0 + vec2(t * 1.3, -t * 0.9)));
	col += sparkle * (0.35 + rain_strength * 0.25);
	float ripple = noise(v_world.xz * 6.0 + vec2(t * 3.1, t * 2.7));
	col += ripple * 0.05 * rain_strength;

	float shore_foam = (1.0 - smoothstep(0.0, 1.7, depth_diff)) * 0.9;
	float crest_foam = smoothstep(0.16, 0.3, v_height) * 0.5;
	float foam = clamp(shore_foam + crest_foam, 0.0, 1.0);
	col = mix(col, foam_color.rgb, foam * 0.8);

	ALBEDO = col;
	ROUGHNESS = mix(0.16, 0.04, fresnel);
	METALLIC = 0.25;
	ALPHA = clamp(mix(0.78, 0.97, depth_factor) + foam * 0.2, 0.0, 1.0);
}
"""
	var material := ShaderMaterial.new()
	material.shader = shader
	return material

func _magma_material() -> ShaderMaterial:
	var shader := Shader.new()
	shader.code = """
shader_type spatial;
render_mode cull_disabled;

uniform vec4 hot_color : source_color = vec4(1.0, 0.42, 0.04, 1.0);
uniform vec4 crust_color : source_color = vec4(0.07, 0.05, 0.05, 1.0);

varying vec3 v_world;

float hash(vec2 p) {
	return fract(sin(dot(p, vec2(127.1, 311.7))) * 43758.5453);
}

float noise(vec2 p) {
	vec2 i = floor(p);
	vec2 f = fract(p);
	f = f * f * (3.0 - 2.0 * f);
	return mix(mix(hash(i), hash(i + vec2(1.0, 0.0)), f.x),
			mix(hash(i + vec2(0.0, 1.0)), hash(i + vec2(1.0, 1.0)), f.x), f.y);
}

void vertex() {
	float t = TIME;
	VERTEX.y += sin(VERTEX.x * 0.4 + t * 0.8) * 0.05
			+ sin(VERTEX.z * 0.33 - t * 0.6) * 0.05;
	v_world = (MODEL_MATRIX * vec4(VERTEX, 1.0)).xyz;
}

void fragment() {
	float t = TIME;
	vec2 flow = v_world.xz * 0.16 + vec2(t * 0.05, t * 0.035);
	float n = noise(flow);
	n += noise(flow * 2.7 - vec2(t * 0.09, t * 0.06)) * 0.5;
	float veins = smoothstep(0.55, 0.95, n + 0.18 * sin(t * 1.4 + v_world.x * 0.3));
	float crust = smoothstep(0.2, 0.6, n);
	vec3 col = mix(crust_color.rgb, hot_color.rgb * 0.5, crust * 0.5);
	col = mix(col, hot_color.rgb, veins);
	ALBEDO = col;
	EMISSION = hot_color.rgb * veins * (2.0 + 0.8 * sin(t * 1.7 + v_world.z * 0.4));
	ROUGHNESS = 0.85;
	METALLIC = 0.0;
}
"""
	var material := ShaderMaterial.new()
	material.shader = shader
	return material

func _ground_at(x: float, z: float) -> float:
	return terrain_height(x, z)

# Lowest ground under a footprint of the given radius — props seated on this
# never hang in the air over a slope (rim ridge / cliffs are ~43 deg).
func _ground_min(x: float, z: float, radius: float) -> float:
	var lowest := terrain_height(x, z)
	for index in 12:
		var angle := TAU * float(index) / 12.0
		lowest = minf(lowest, terrain_height(
				x + cos(angle) * radius, z + sin(angle) * radius))
	return lowest

func _build_hub() -> void:
	var centre := Vector3(HUB.x, 0.0, HUB.y)
	var base_y := _ground_at(centre.x, centre.z)
	_mark_structure(centre.x, centre.z, 21.0)
	_mark_structure(centre.x + 36.0, centre.z, 21.0)
	for ix in range(-3, 4):
		for iz in range(-2, 3):
			var px := centre.x + float(ix) * 5.6
			var pz := centre.z + float(iz) * 5.6
			AssetLibrary.place(self, VILLAGE + "Cobblestone_Floor_1.obj",
					Vector3(px, _ground_at(px, pz) + 0.03, pz), 5.4,
					float((ix + iz) * 7 % 90), _cobble_material, false)
	for index in 8:
		var path_x := centre.x + 18.0 + float(index) * 5.2
		AssetLibrary.place(self, VILLAGE + "Dirt_Gathered_Corner.obj",
				Vector3(path_x, _ground_at(path_x, centre.z) + 0.03, centre.z),
				5.0, 0.0, _sand_material, false)

	var prop_spots := [
		[VILLAGE + "Prop_Well_1.obj", Vector2(-8.0, -6.0), 2.6, 20.0],
		[VILLAGE + "Prop_Barrel_1.obj", Vector2(7.0, -8.0), 0.95, 0.0],
		[VILLAGE + "Prop_Barrel_2.obj", Vector2(8.4, -7.0), 0.95, 40.0],
		[VILLAGE + "Prop_Barrel_1_Open.obj", Vector2(-9.5, 5.0), 0.95, 120.0],
		[VILLAGE + "Prop_Crate_1.obj", Vector2(9.0, 6.5), 1.1, 15.0],
		[VILLAGE + "Prop_Crate_1_Open.obj", Vector2(-7.0, 8.0), 1.1, -30.0],
		[VILLAGE + "Prop_Ladder_1.obj", Vector2(12.0, 2.0), 3.0, 80.0],
		[DUNGEON + "prop_floor_brazier.obj", Vector2(-13.0, -3.0), 1.5, 0.0],
		[DUNGEON + "prop_floor_brazier.obj", Vector2(13.0, -4.0), 1.5, 180.0],
		[DUNGEON + "prop_floor_crate.obj", Vector2(11.0, -10.0), 1.2, 25.0],
	]
	for entry in prop_spots:
		var path := String(entry[0])
		var offset: Vector2 = entry[1]
		var px := centre.x + offset.x
		var pz := centre.z + offset.y
		AssetLibrary.place(self, path, Vector3(px, _ground_at(px, pz) + 0.04, pz),
				float(entry[2]), float(entry[3]), null, true)

	for lamp_index in 4:
		var angle := TAU * float(lamp_index) / 4.0 + 0.6
		var px := centre.x + cos(angle) * 20.0
		var pz := centre.z + sin(angle) * 16.0
		AssetLibrary.place(self, VILLAGE + "Prop_Lamp_Street.obj",
				Vector3(px, _ground_at(px, pz) + 0.04, pz), 4.0,
				rad_to_deg(angle) + 180.0, null, true)

	var road_points: Array = []
	for strip in 2:
		var axis := Vector2(1.0, 0.0) if strip == 0 else Vector2(0.0, 1.0)
		for tile in range(-6, 7):
			if strip == 1 and tile >= -1 and tile <= 1:
				continue
			var px := centre.x + axis.x * float(tile) * 3.0
			var pz := centre.z + axis.y * float(tile) * 3.0
			var yaw := 0.0 if strip == 0 else 90.0
			road_points.append([Vector3(px, _ground_at(px, pz) + 0.05, pz), yaw])
	AssetLibrary.multimesh(self, ROADS + "roadTile_001.obj", road_points,
			3.0, _asphalt_material, false)

	var bush_material := AssetLibrary.textured_material(
			AssetLibrary.BUSH_TEXTURES[1], "", 0.9, 0.0, Color.WHITE, true)
	var bush_points: Array = []
	for index in 6:
		var angle := TAU * float(index) / 6.0 + 1.9
		var px := centre.x + cos(angle) * 24.0
		var pz := centre.z + sin(angle) * 20.0
		bush_points.append([Vector3(px, _ground_at(px, pz), pz), rad_to_deg(angle)])
	AssetLibrary.multimesh(self,
			"res://assets/models/nature/02/bush_02.obj", bush_points, 1.8,
			bush_material, false)

func _build_climb_wall() -> void:
	# Concrete practice wall on the hub's north edge: wall-climb staging in the
	# smoke test raycasts south from (0, ~4, -38) and needs a face around z = -45.
	var ground_y := _ground_at(0.0, -45.0)
	_mark_structure(0.0, -45.0, 9.0)
	var size := Vector3(13.0, 7.0, 1.6)
	var body := StaticBody3D.new()
	body.name = "ClimbWall"
	var mesh_node := MeshInstance3D.new()
	mesh_node.name = "ClimbWallMesh"
	var mesh := BoxMesh.new()
	mesh.size = size
	mesh_node.mesh = mesh
	mesh_node.material_override = _stone_material
	mesh_node.position = Vector3(0.0, ground_y + 3.5, -45.0)
	body.add_child(mesh_node)
	var shape := BoxShape3D.new()
	shape.size = size
	var collider := CollisionShape3D.new()
	collider.shape = shape
	collider.position = mesh_node.position
	body.add_child(collider)
	add_child(body)

# --- Sci-fi transit tunnel -------------------------------------------------
# Ceiling/wall panels are placed per 5 m segment and seated against the local
# terrain at the skirt (|x| = 9), so the slab is always buried outside the
# trench and the corridor keeps headroom over the flat floor.
func _build_tunnel() -> void:
	var z0 := TUNNEL_START.y + TUNNEL_RAMP
	var z1 := TUNNEL_END.y - TUNNEL_RAMP
	if z1 - z0 < TUNNEL_SEGMENT * 2.0:
		return
	var metal := MeshUtil.make_material(Color(0.16, 0.17, 0.19), 0.85, 0.42)
	var dark := MeshUtil.make_material(Color(0.09, 0.1, 0.12), 0.6, 0.62)
	var glow := MeshUtil.make_material(Color(0.05, 0.12, 0.16), 0.1, 0.4,
			Color(0.35, 0.95, 1.0), 3.4)
	var warm := MeshUtil.make_material(Color(0.18, 0.12, 0.04), 0.3, 0.6,
			Color(1.0, 0.62, 0.15), 2.8)
	var ceiling := StaticBody3D.new()
	ceiling.name = "TunnelCeiling"
	ceiling.collision_layer = Layers.WORLD
	ceiling.collision_mask = Layers.WORLD
	add_child(ceiling)
	var shell := StaticBody3D.new()
	shell.name = "TunnelShell"
	shell.collision_layer = Layers.WORLD
	shell.collision_mask = Layers.WORLD
	add_child(shell)

	var segments := int(round((z1 - z0) / TUNNEL_SEGMENT))
	var index := 0
	var z := z0
	while index < segments:
		var zc := z + TUNNEL_SEGMENT * 0.5
		var top := minf(_ground_at(-TUNNEL_SKIRT, zc), _ground_at(TUNNEL_SKIRT, zc)) - 0.25
		var bottom := maxf(top - 0.6, TUNNEL_FLOOR + 2.7)
		_tunnel_box(ceiling, Vector3(TUNNEL_SKIRT * 2.0, 0.6, TUNNEL_SEGMENT + 0.2),
				Vector3(0.0, bottom + 0.3, zc), metal, "TunnelSlab")
		for side in [-1.0, 1.0]:
			var wall_bottom := TUNNEL_FLOOR - 0.3
			var wall_height := bottom - wall_bottom
			_tunnel_box(shell, Vector3(0.5, wall_height, TUNNEL_SEGMENT + 0.2),
					Vector3(side * TUNNEL_WALL_X, wall_bottom + wall_height * 0.5, zc),
					dark, "TunnelWall")
			_tunnel_visual(shell, Vector3(0.16, 0.2, TUNNEL_SEGMENT - 0.6),
					Vector3(side * (TUNNEL_WALL_X - 0.32), bottom - 0.35, zc),
					glow, "TunnelStrip")
		# Portal rib at every segment joint: posts + beam, purely visual.
		for side in [-1.0, 1.0]:
			var post_height := bottom - TUNNEL_FLOOR
			_tunnel_visual(shell, Vector3(0.45, post_height, 0.45),
					Vector3(side * (TUNNEL_WALL_X - 0.05),
							TUNNEL_FLOOR + post_height * 0.5, z),
					dark, "TunnelRibPost")
		_tunnel_visual(shell, Vector3(TUNNEL_WALL_X * 2.0 + 0.5, 0.4, 0.5),
				Vector3(0.0, bottom - 0.1, z), dark, "TunnelRibBeam")
		index += 1
		z += TUNNEL_SEGMENT

	# Entrance gantries at both mouths (amber lintel light marks the way in).
	_tunnel_gantry(z0, warm, dark, "TunnelGantryA")
	_tunnel_gantry(z1, warm, dark, "TunnelGantryB")
	# Glowing guide posts beside both mouths so the passage reads from afar.
	_tunnel_marker(z0, dark, glow, warm, "TunnelMarkerA")
	_tunnel_marker(z1, dark, glow, warm, "TunnelMarkerB")
	var lamp_index := 1
	for fraction in [0.28, 0.5, 0.72]:
		var lz := lerpf(z0, z1, fraction)
		var lamp := OmniLight3D.new()
		lamp.name = "TunnelLamp%d" % lamp_index
		lamp_index += 1
		lamp.position = Vector3(0.0, TUNNEL_FLOOR + 3.0, lz)
		lamp.light_color = Color(0.62, 0.86, 1.0)
		lamp.light_energy = 1.6
		lamp.omni_range = 16.0
		lamp.shadow_enabled = false
		add_child(lamp)

func _tunnel_gantry(z: float, warm: Material, dark: Material,
		gantry_name: String) -> void:
	var ground := _ground_at(0.0, z)
	var frame := Node3D.new()
	frame.name = gantry_name
	frame.position = Vector3(0.0, ground, z)
	add_child(frame)
	for side in [-1.0, 1.0]:
		_tunnel_visual(frame, Vector3(0.6, 4.4, 0.6),
				Vector3(side * (TUNNEL_WALL_X + 0.4), 2.2, 0.0), dark, "gantry_post")
	_tunnel_visual(frame, Vector3(TUNNEL_WALL_X * 2.0 + 2.0, 0.7, 0.9),
			Vector3(0.0, 4.5, 0.0), dark, "gantry_beam")
	_tunnel_visual(frame, Vector3(TUNNEL_WALL_X * 2.0 - 1.0, 0.18, 0.3),
			Vector3(0.0, 3.9, 0.0), warm, "gantry_light")
	var beacon := OmniLight3D.new()
	beacon.name = "TunnelBeacon"
	beacon.position = Vector3(0.0, 3.6, 0.0)
	beacon.light_color = Color(1.0, 0.7, 0.3)
	beacon.light_energy = 1.4
	beacon.omni_range = 14.0
	beacon.shadow_enabled = false
	frame.add_child(beacon)

func _tunnel_box(parent: Node3D, size: Vector3, position: Vector3, material: Material,
		name_hint: String) -> void:
	MeshUtil.add_box_body(parent, size, position, material,
			Layers.WORLD, Layers.WORLD, 0.0, name_hint)

# Tall glowing guide post outside each tunnel mouth — visible from across
# the hub so players discover the underground passage.
func _tunnel_marker(z: float, dark: Material, glow: Material, warm: Material,
		marker_name: String) -> void:
	var lateral := TUNNEL_SKIRT + 3.5
	for side in [-1.0, 1.0]:
		var ground := _ground_at(side * lateral, z)
		var suffix := "L" if side < 0.0 else "R"
		var frame := Node3D.new()
		frame.name = marker_name + suffix
		frame.position = Vector3(side * lateral, ground, z)
		add_child(frame)
		_tunnel_visual(frame, Vector3(0.5, 7.5, 0.5),
				Vector3(0.0, 3.75, 0.0), dark, "marker_post")
		for band_height in [1.6, 4.2, 6.6]:
			_tunnel_visual(frame, Vector3(0.62, 0.5, 0.62),
					Vector3(0.0, band_height, 0.0), glow, "marker_band")
		_tunnel_visual(frame, Vector3(0.7, 0.3, 0.7),
				Vector3(0.0, 7.6, 0.0), warm, "marker_cap")
		var light := OmniLight3D.new()
		light.name = "MarkerLight"
		light.position = Vector3(0.0, 7.4, 0.0)
		light.light_color = Color(1.0, 0.7, 0.3)
		light.light_energy = 1.8
		light.omni_range = 22.0
		light.shadow_enabled = false
		frame.add_child(light)

func _tunnel_visual(parent: Node3D, size: Vector3, position: Vector3, material: Material,
		name_hint: String) -> void:
	MeshUtil.add_visual_box(parent, size, position, material, 0.0, name_hint)

# --- Enterable field bunkers ----------------------------------------------
# Procedural interiors with a real doorway gap (kit buildings stay solid — their
# meshes have no openings, so a hollow collider there would read as cheating).
func _build_bunkers() -> void:
	_build_bunker(-34.0, 10.0, HUB, "BunkerHub")
	_build_bunker(30.0, -18.0, Vector2.ZERO, "BunkerWild")

func _build_bunker(x: float, z: float, face_towards: Vector2,
		bunker_name: String) -> void:
	var ground := _ground_min(x, z, 6.0)
	_mark_structure(x, z, 9.0)
	var toward := (face_towards - Vector2(x, z)).normalized()
	var yaw := rad_to_deg(atan2(-toward.x, -toward.y))
	var root := Node3D.new()
	root.name = bunker_name
	root.position = Vector3(x, ground, z)
	root.rotation_degrees.y = yaw
	add_child(root)

	var wall_mat := MeshUtil.make_material(Color(0.27, 0.28, 0.3), 0.2, 0.72)
	var trim_mat := MeshUtil.make_material(Color(0.12, 0.13, 0.15), 0.75, 0.45)
	var floor_mat := MeshUtil.make_material(Color(0.2, 0.21, 0.23), 0.4, 0.6)
	var glow_mat := MeshUtil.make_material(Color(0.05, 0.1, 0.14), 0.1, 0.4,
			Color(0.35, 0.95, 1.0), 3.0)

	var width := 11.0
	var depth := 8.0
	var height := 3.4
	var thickness := 0.4
	var door := 5.0 # wide enough for the titan capsule (2 x 2.31 m)
	var front_z := -(depth * 0.5 - thickness * 0.5)
	_bunker_box(root, Vector3(width, 0.3, depth),
			Vector3(0.0, 0.15, 0.0), floor_mat, true)
	_bunker_box(root, Vector3(width, height, thickness),
			Vector3(0.0, height * 0.5, depth * 0.5 - thickness * 0.5),
			wall_mat, true)
	for side in [-1.0, 1.0]:
		_bunker_box(root, Vector3(thickness, height, depth - thickness * 2.0),
				Vector3(side * (width * 0.5 - thickness * 0.5), height * 0.5, 0.0),
				wall_mat, true)
	var side_len := (width - door) * 0.5
	for side in [-1.0, 1.0]:
		_bunker_box(root, Vector3(side_len, height, thickness),
				Vector3(side * (door * 0.5 + side_len * 0.5), height * 0.5, front_z),
				wall_mat, true)
	_bunker_box(root, Vector3(door, height - 2.4, thickness),
			Vector3(0.0, 2.4 + (height - 2.4) * 0.5, front_z), wall_mat, true)
	_bunker_box(root, Vector3(width + 0.6, 0.4, depth + 0.6),
			Vector3(0.0, height + 0.2, 0.0), trim_mat, true)
	for side in [-1.0, 1.0]:
		_bunker_visual(root, Vector3(0.18, 2.4, 0.55),
				Vector3(side * door * 0.5, 1.2, front_z), trim_mat, "jamb")
	_bunker_visual(root, Vector3(door, 0.16, 0.55),
			Vector3(0.0, 2.5, front_z), glow_mat, "door_light")
	_bunker_visual(root, Vector3(width - 2.0, 0.12, 0.4),
			Vector3(0.0, height - 0.25, 0.0), glow_mat, "ceil_light")
	_bunker_box(root, Vector3(1.3, 1.3, 1.3),
			Vector3(-width * 0.24, 0.95, depth * 0.18), trim_mat, true)
	_bunker_box(root, Vector3(1.1, 1.1, 1.1),
			Vector3(width * 0.26, 0.85, depth * 0.26), trim_mat, true)
	var lamp := OmniLight3D.new()
	lamp.name = "BunkerLamp"
	lamp.position = Vector3(0.0, height - 0.5, 0.0)
	lamp.light_color = Color(0.6, 0.85, 1.0)
	lamp.light_energy = 1.5
	lamp.omni_range = 12.0
	lamp.shadow_enabled = false
	root.add_child(lamp)

func _bunker_box(parent: Node3D, size: Vector3, position: Vector3, material: Material,
		collide: bool) -> void:
	if collide:
		MeshUtil.add_box_body(parent, size, position, material,
				Layers.WORLD, Layers.WORLD, 0.0, "part")
	else:
		MeshUtil.add_visual_box(parent, size, position, material, 0.0, "part")

func _bunker_visual(parent: Node3D, size: Vector3, position: Vector3, material: Material,
		name_hint: String) -> void:
	MeshUtil.add_visual_box(parent, size, position, material, 0.0, name_hint)

func _build_industrial() -> void:
	var centre := Vector3(INDUSTRIAL.x, 0.0, INDUSTRIAL.y)
	var buildings := [
		["building-a", Vector2(-26.0, -26.0), 0.0],
		["building-l", Vector2(26.0, -22.0), 12.0],
		["building-q", Vector2(28.0, 26.0), -8.0],
		["building-n", Vector2(-30.0, 24.0), -14.0],
		["building-f", Vector2(2.0, -40.0), 4.0],
		["chimney-medium", Vector2(-38.0, -6.0), 0.0],
		["chimney-large", Vector2(40.0, 6.0), 0.0],
		["water-tower", Vector2(14.0, 44.0), 0.0],
		["windmill", Vector2(-44.0, 40.0), 20.0],
		["detail-tank-large", Vector2(-14.0, 12.0), 15.0],
		["detail-tank-large", Vector2(16.0, -10.0), -25.0],
		["solar-panel-landscape-group", Vector2(-34.0, -40.0), 0.0],
		["solar-panel-landscape-group", Vector2(36.0, 40.0), 90.0],
	]
	for entry in buildings:
		var model := String(entry[0])
		var offset: Vector2 = entry[1]
		var scale := BUILDING_SCALE
		var clear := 10.0
		if model.begins_with("chimney") or model.begins_with("water") \
				or model.begins_with("windmill") or model.begins_with("detail") \
				or model.begins_with("solar"):
			scale = PROP_SCALE
			clear = 6.0
		_kit_place(KIT + "ind/" + model + ".glb",
				Vector3(centre.x + offset.x, _ground_at(centre.x + offset.x,
						centre.z + offset.y), centre.z + offset.y),
				float(entry[2]), scale, true)
		_mark_structure(centre.x + offset.x, centre.z + offset.y, clear)

	var container_colours := [
		Color(0.5, 0.2, 0.14), Color(0.16, 0.32, 0.44), Color(0.3, 0.4, 0.24),
	]
	var container_size := Vector3(6.0, 2.6, 2.4)
	for variant in 3:
		var material := MeshUtil.make_material(container_colours[variant], 0.3, 0.8)
		Quality.decorate_material(material, &"steel", 1.4)
		var transforms: Array[Transform3D] = []
		for row in 4:
			var px := centre.x - 20.0 + float(variant) * 7.5
			var pz := centre.z - 60.0 + float(row) * 6.8
			var y := _ground_at(px, pz) + container_size.y * 0.5 + 0.05
			transforms.append(Transform3D(Basis(Vector3.UP, deg_to_rad(
					float((row * 17 + variant * 31) % 25) - 12.0)),
					Vector3(px, y, pz)))
			_mark_structure(px, pz, 3.6)
		var multi := MultiMesh.new()
		multi.transform_format = MultiMesh.TRANSFORM_3D
		var box := BoxMesh.new()
		box.size = container_size
		box.material = material
		multi.mesh = box
		multi.instance_count = transforms.size()
		for index in transforms.size():
			multi.set_instance_transform(index, transforms[index])
		var instance := MultiMeshInstance3D.new()
		instance.name = "containers_%d" % variant
		instance.multimesh = multi
		add_child(instance)
		for index in transforms.size():
			var body := StaticBody3D.new()
			body.name = "container_%d_%d" % [variant, index]
			body.collision_layer = Layers.WORLD
			body.collision_mask = Layers.WORLD
			body.transform = transforms[index]
			var shape := CollisionShape3D.new()
			var box_shape := BoxShape3D.new()
			box_shape.size = container_size
			shape.shape = box_shape
			body.add_child(shape)
			add_child(body)

	var prop_spots := [
		[SCIFI + "ammo_box.glb", Vector2(-8.0, -34.0), 1.5, 30.0],
		[SCIFI + "ammo_box.glb", Vector2(6.0, -36.0), 1.5, 140.0],
		[SCIFI + "cage_box.glb", Vector2(34.0, -34.0), 2.3, 0.0],
		[SCIFI + "cage_box_large.glb", Vector2(-36.0, -34.0), 3.0, 20.0],
		[SCIFI + "liquid_cell.glb", Vector2(44.0, -18.0), 2.3, 90.0],
		[SCIFI + "cage_cylindric.glb", Vector2(44.0, -10.0), 2.3, 70.0],
		[SCIFI + "pillar.glb", Vector2(-46.0, 4.0), 3.6, 0.0],
		[SCIFI + "pillar.glb", Vector2(-46.0, 14.0), 3.6, 0.0],
		[SCIFI + "pillar.glb", Vector2(46.0, 24.0), 3.6, 0.0],
		[SCIFI + "cage_cylindric.glb", Vector2(22.0, 46.0), 2.4, 45.0],
	]
	for entry in prop_spots:
		var offset: Vector2 = entry[1]
		var px := centre.x + offset.x
		var pz := centre.z + offset.y
		AssetLibrary.place(self, String(entry[0]),
				Vector3(px, _ground_at(px, pz) + 0.04, pz),
				float(entry[2]), float(entry[3]), null, true)
		_mark_structure(px, pz, float(entry[2]) * 0.7 + 1.0)

	var kit_props := [
		["roads/construction-fence.glb", Vector2(-16.0, -48.0), 0.0, 1.0],
		["roads/construction-fence.glb", Vector2(-6.0, -48.0), 0.0, 1.0],
		["roads/construction-fence.glb", Vector2(4.0, -48.0), 0.0, 1.0],
		["roads/construction-cone.glb", Vector2(-2.0, -44.0), 0.0, 1.0],
		["roads/construction-cone.glb", Vector2(1.5, -43.0), 0.0, 1.0],
		["roads/construction-cone.glb", Vector2(5.0, -44.5), 0.0, 1.0],
		["roads/construction-barrier.glb", Vector2(9.0, -44.0), 10.0, 1.0],
		["roads/dumpster.glb", Vector2(-44.0, -22.0), 75.0, 1.0],
		["roads/dumpster.glb", Vector2(30.0, 34.0), -40.0, 1.0],
		["roads/electricity-pole.glb", Vector2(-48.0, -44.0), 0.0, 1.0],
		["roads/electricity-pole.glb", Vector2(48.0, 48.0), 0.0, 1.0],
	]
	for entry in kit_props:
		var offset: Vector2 = entry[1]
		var px := centre.x + offset.x
		var pz := centre.z + offset.y
		_kit_place(KIT + String(entry[0]),
				Vector3(px, _ground_at(px, pz), pz), float(entry[2]),
				float(entry[3]), entry[0] != "roads/construction-cone.glb")
		_mark_structure(px, pz, 3.0)

func _build_ruins_district() -> void:
	var centre := Vector3(RUINS_CENTRE.x, 0.0, RUINS_CENTRE.y)
	var pieces := [
		["CathedralRuins_01.glb", Vector2(0.0, 0.0), 36.0, 25.0, true],
		["TempleRuin_01.glb", Vector2(-24.0, 18.0), 17.0, 70.0, true],
		["TempleRuin_02.glb", Vector2(24.0, 20.0), 15.0, -40.0, true],
		["FoundationRuin_01.glb", Vector2(-4.0, -30.0), 15.0, 15.0, true],
		["RuinArch_01.glb", Vector2(-30.0, -14.0), 11.0, 55.0, true],
		["RuinArch_01.glb", Vector2(30.0, -18.0), 11.0, -75.0, true],
		["RuinWallSegment_01.glb", Vector2(14.0, -34.0), 13.0, 30.0, true],
		["RuinWallSegment_02.glb", Vector2(-16.0, -36.0), 11.0, -20.0, true],
		["RomanRail_01.glb", Vector2(6.0, 34.0), 9.0, 0.0, true],
		["RomanTypeCol_01.glb", Vector2(-38.0, 6.0), 9.5, 0.0, true],
		["RomanTypeCol_01.glb", Vector2(38.0, 8.0), 9.5, 0.0, true],
		["RomanTypeCol_01.glb", Vector2(-40.0, 30.0), 9.5, 0.0, true],
		["RomanTypeCol_01.glb", Vector2(40.0, 34.0), 9.5, 0.0, true],
		["RuinPillar_01.glb", Vector2(-12.0, 40.0), 7.5, 10.0, true],
		["RuinPillar_01.glb", Vector2(12.0, 42.0), 7.5, -10.0, true],
		["RuinPillar_01.glb", Vector2(-44.0, -22.0), 7.5, 40.0, true],
		["RuinPillar_01.glb", Vector2(44.0, -26.0), 7.5, -30.0, true],
		["PillarSegment_01.glb", Vector2(-22.0, 44.0), 5.0, 0.0, false],
		["PillarSegment_01.glb", Vector2(22.0, 46.0), 5.0, 90.0, false],
		["PillarSegment_01.glb", Vector2(0.0, 48.0), 5.0, 30.0, false],
		["SpeakingStones_01.glb", Vector2(-48.0, 40.0), 4.5, 0.0, true],
		["SpeakingStones_01.glb", Vector2(48.0, 42.0), 4.5, 120.0, true],
		["SpeakingStones_01.glb", Vector2(-50.0, -40.0), 4.5, 220.0, true],
	]
	for entry in pieces:
		var offset: Vector2 = entry[1]
		var px := centre.x + offset.x
		var pz := centre.z + offset.y
		AssetLibrary.place(self, RUINS + String(entry[0]),
				Vector3(px, _ground_at(px, pz) + 0.02, pz),
				float(entry[2]), float(entry[3]), null, bool(entry[4]))
		_mark_structure(px, pz, float(entry[2]) * 0.55 + 1.0)

	var dungeon_spots := [
		[DUNGEON + "struct_block_normal.obj", Vector2(-6.0, -46.0), 2.6, 0.0],
		[DUNGEON + "struct_block_normal.obj", Vector2(8.0, -48.0), 2.6, 45.0],
		[DUNGEON + "struct_block_tapered.obj", Vector2(-34.0, 46.0), 3.2, 20.0],
		[DUNGEON + "prop_floor_crate.obj", Vector2(-8.0, 20.0), 1.2, 30.0],
		[DUNGEON + "prop_floor_crate.obj", Vector2(16.0, 14.0), 1.2, -50.0],
		[DUNGEON + "prop_floor_barrel.obj", Vector2(18.0, -6.0), 1.1, 0.0],
		[DUNGEON + "prop_floor_brazier.obj", Vector2(-18.0, -4.0), 1.6, 0.0],
		[DUNGEON + "prop_wall_torch.obj", Vector2(-28.0, 28.0), 3.0, 140.0],
		[DUNGEON + "prop_wall_torch.obj", Vector2(30.0, 4.0), 3.0, -60.0],
	]
	for entry in dungeon_spots:
		var offset: Vector2 = entry[1]
		var px := centre.x + offset.x
		var pz := centre.z + offset.y
		AssetLibrary.place(self, String(entry[0]),
				Vector3(px, _ground_at(px, pz) + 0.03, pz),
				float(entry[2]), float(entry[3]), _stone_material if String(entry[0]).contains("struct") else null, true)
		_mark_structure(px, pz, float(entry[2]) * 0.6 + 1.0)

func _lake_point(angle_degrees: float, radius: float) -> Vector3:
	var angle := deg_to_rad(angle_degrees)
	var x := LAKE_CENTRE.x + cos(angle) * radius
	var z := LAKE_CENTRE.y + sin(angle) * radius
	return Vector3(x, _ground_at(x, z), z)

func _build_lake_shore() -> void:
	var dock_specs := [
		[BEACH + "Prop_Docks_Straight.obj", 160.0, 46.0, 9.0, 250.0],
		[BEACH + "Prop_Docks_Straight.obj", 340.0, 46.0, 9.0, 70.0],
		[BEACH + "Prop_Docks_Corner.obj", 255.0, 44.0, 8.0, 345.0],
		[BEACH + "Prop_Docks_Steps.obj", 60.0, 46.0, 6.0, 150.0],
	]
	for entry in dock_specs:
		var point := _lake_point(float(entry[1]), float(entry[2]))
		AssetLibrary.place(self, String(entry[0]), point + Vector3(0.0, 0.02, 0.0),
				float(entry[3]), float(entry[4]), _wood_material, true)

	for index in 8:
		var angle := 40.0 + float(index) * 42.0
		var point := _lake_point(angle, 58.0 + float(index % 3) * 3.0)
		AssetLibrary.place(self, BEACH + "Prop_Tree_Palm_%d.obj" % (index % 3 + 1),
				point, 7.5, randf_range(0.0, 360.0), null, true)

	var beach_props := [
		[BEACH + "Prop_Shell_1.obj", 30.0, 52.0, 0.7],
		[BEACH + "Prop_Shell_2.obj", 96.0, 53.0, 0.6],
		[BEACH + "Prop_Starfish_1.obj", 140.0, 52.0, 0.5],
		[BEACH + "Prop_Starfish_2.obj", 250.0, 54.0, 0.5],
		[BEACH + "Prop_Treasure_Chest.obj", 15.0, 56.0, 1.4],
		[BEACH + "Prop_Shell_1.obj", 310.0, 54.0, 0.7],
	]
	for entry in beach_props:
		var point := _lake_point(float(entry[1]), float(entry[2]))
		AssetLibrary.place(self, String(entry[0]), point + Vector3(0.0, 0.03, 0.0),
				float(entry[3]), randf_range(0.0, 360.0),
				_sand_material if String(entry[0]).contains("Starfish") else null, false)

	for index in 6:
		var point := _lake_point(20.0 + float(index) * 58.0, 50.0 + float(index % 2) * 8.0)
		var variant := index % AssetLibrary.ROCK_TEXTURES.size()
		var material := AssetLibrary.textured_material(
				AssetLibrary.ROCK_TEXTURES[variant], AssetLibrary.ROCK_NORMALS[variant], 0.95)
		AssetLibrary.place(self,
				"res://assets/models/rocks/0%d/rock_0%d.obj" % [variant + 1, variant + 1],
				point + Vector3(0.0, 0.1, 0.0), randf_range(1.6, 3.2),
				randf_range(0.0, 360.0), material, true)

func _build_city() -> void:
	var centre := Vector3(CITY.x, 0.0, CITY.y)
	var base_y := _ground_at(centre.x, centre.z)
	_kit_spot(DOWNTOWN_KIT + "Street_4WayIntersection.gltf",
			Vector3(centre.x, base_y + 0.17, centre.z), 0.0, 1.0, true, 13.0)
	for lane in 4:
		var angle := 90.0 * float(lane)
		var dir := Vector2(0.0, -1.0)
		if lane == 1:
			dir = Vector2(1.0, 0.0)
		elif lane == 2:
			dir = Vector2(0.0, 1.0)
		elif lane == 3:
			dir = Vector2(-1.0, 0.0)
		for segment in [1, 2]:
			var px := centre.x + dir.x * 21.35 * float(segment)
			var pz := centre.z + dir.y * 21.35 * float(segment)
			_kit_place(DOWNTOWN_KIT + "Street_4Lane.gltf",
					Vector3(px, base_y + 0.17, pz), angle, 1.0, true)
			for along in [-6.0, 0.0, 6.0]:
				_mark_structure(px + dir.x * along, pz + dir.y * along, 4.5)
	for patch in [
		Vector2(-39.0, -39.0), Vector2(39.0, -39.0),
		Vector2(-39.0, 39.0), Vector2(39.0, 39.0),
	]:
		_kit_spot(DOWNTOWN_KIT + "Street_Asphalt_6x6.gltf",
				Vector3(centre.x + patch.x, base_y + 0.17, centre.z + patch.y),
				0.0, 1.0, true, 4.5)

	var building_spots := [
		["Building_Large_2", Vector2(-40.0, -36.0), 0.0],
		["Building_Large_2", Vector2(42.0, 40.0), 90.0],
		["Building_Medium_2_001", Vector2(-38.0, 34.0), 180.0],
		["Building_Medium_2_001", Vector2(36.0, -38.0), 0.0],
		["Building_Medium_2_001", Vector2(-8.0, -52.0), 180.0],
		["Building_Small_1", Vector2(20.0, 54.0), 0.0],
		["Building_Small_1", Vector2(56.0, -6.0), -90.0],
		["Building_Small_1", Vector2(-56.0, 4.0), 90.0],
	]
	for entry in building_spots:
		var offset: Vector2 = entry[1]
		var px := centre.x + offset.x
		var pz := centre.z + offset.y
		var clear := 11.0
		if String(entry[0]).contains("Large"):
			clear = 14.0
		elif String(entry[0]).contains("Small"):
			clear = 9.0
		_kit_spot(DOWNTOWN_KIT + String(entry[0]) + ".gltf",
				Vector3(px, _ground_at(px, pz), pz), float(entry[2]), 1.0, true, clear)

	for entry in [
		["Prop_Planter_Single.gltf", Vector2(-14.0, 14.0)],
		["Prop_Planter_Single.gltf", Vector2(14.0, -14.0)],
		["Prop_Planter_Single.gltf", Vector2(-14.0, -14.0)],
		["Prop_Planter_Single.gltf", Vector2(14.0, 14.0)],
		["Prop_Planter_Single.gltf", Vector2(-30.0, 0.0)],
		["Prop_Planter_Single.gltf", Vector2(30.0, 0.0)],
	]:
		var offset: Vector2 = entry[1]
		var px := centre.x + offset.x
		var pz := centre.z + offset.y
		_kit_spot(DOWNTOWN_KIT + String(entry[0]),
				Vector3(px, _ground_at(px, pz), pz), 0.0, 1.0, true, 3.0)

	var bollard_ring: Array[Vector3] = []
	for index in 8:
		var angle := TAU * float(index) / 8.0
		bollard_ring.append(Vector3(centre.x + cos(angle) * 26.0, 0.0,
				centre.z + sin(angle) * 26.0))
	for point in bollard_ring:
		_kit_spot(DOWNTOWN_KIT + "Prop_Bollard.gltf",
				Vector3(point.x, _ground_at(point.x, point.z), point.z),
				0.0, 1.0, false, 2.0)
	for index in 3:
		var px := centre.x + float(index) * 9.0 - 9.0
		var pz := centre.z + 46.0
		_kit_spot(DOWNTOWN_KIT + "Prop_ManholeCover.gltf",
				Vector3(px, _ground_at(px, pz) + 0.19, pz), 0.0, 1.0, false, 2.5)

	for index in 4:
		var angle := TAU * float(index) / 4.0 + 0.78
		var px := centre.x + cos(angle) * 48.0
		var pz := centre.z + sin(angle) * 48.0
		AssetLibrary.place(self, VILLAGE + "Prop_Lamp_Street.obj",
				Vector3(px, _ground_at(px, pz) + 0.04, pz), 4.0,
				rad_to_deg(angle) + 180.0, null, true)
		_mark_structure(px, pz, 3.0)

	var plaza_columns: Array[Vector2] = [
		Vector2(-24.0, -24.0), Vector2(24.0, -24.0),
		Vector2(-24.0, 24.0), Vector2(24.0, 24.0),
	]
	for index in plaza_columns.size():
		var offset := plaza_columns[index]
		var px := centre.x + offset.x
		var pz := centre.z + offset.y
		AssetLibrary.place(self,
				RUINS + "RomanTypeCol_01.glb",
				Vector3(px, _ground_at(px, pz) + 0.02, pz), 8.0,
				float(index) * 40.0, null, true)
		_mark_structure(px, pz, 5.0)

	var city_bushes: Array = []
	for index in 10:
		var angle := TAU * float(index) / 10.0
		var px := centre.x + cos(angle) * 34.0
		var pz := centre.z + sin(angle) * 34.0
		city_bushes.append([Vector3(px, _ground_at(px, pz), pz),
				rad_to_deg(angle)])
	var bush_material := AssetLibrary.textured_material(
			AssetLibrary.BUSH_TEXTURES[3], "", 0.9, 0.0, Color.WHITE, true)
	AssetLibrary.multimesh(self,
			"res://assets/models/nature/04/bush_04.obj", city_bushes, 1.7,
			bush_material, false)

func _build_wilderness() -> void:
	var rng := RandomNumberGenerator.new()
	rng.seed = 20261004

	for index in 22:
		var angle := rng.randf_range(0.0, TAU)
		var distance := rng.randf_range(55.0, 175.0)
		var px := cos(angle) * distance
		var pz := sin(angle) * distance
		if Vector2(px, pz).distance_to(LAKE_CENTRE) < 48.0:
			continue
		if Vector2(px, pz).distance_to(MAGMA_CENTRE) < 38.0:
			continue
		if _in_district(px, pz):
			continue
		var variant := index % AssetLibrary.ROCK_TEXTURES.size()
		var material := AssetLibrary.textured_material(
				AssetLibrary.ROCK_TEXTURES[variant], AssetLibrary.ROCK_NORMALS[variant], 0.95)
		var size := rng.randf_range(1.8, 4.6)
		AssetLibrary.place(self,
				"res://assets/models/rocks/0%d/rock_0%d.obj" % [variant + 1, variant + 1],
				Vector3(px, _ground_min(px, pz, size * 0.5) - 0.08, pz), size,
				rng.randf_range(0.0, 360.0), material, true)

	for variant in 5:
		var points: Array = []
		for _spread in 12:
			var angle := rng.randf_range(0.0, TAU)
			var distance := rng.randf_range(50.0, 180.0)
			var px := cos(angle) * distance
			var pz := sin(angle) * distance
			if Vector2(px, pz).distance_to(LAKE_CENTRE) < 46.0:
				continue
			if Vector2(px, pz).distance_to(MAGMA_CENTRE) < 38.0:
				continue
			if _in_structure(px, pz):
				continue
			points.append([Vector3(px, _ground_at(px, pz), pz),
					rng.randf_range(0.0, 360.0)])
		if points.is_empty():
			continue
		var bush_material := AssetLibrary.textured_material(
				AssetLibrary.BUSH_TEXTURES[variant], "", 0.9, 0.0,
				Color.WHITE, true)
		AssetLibrary.multimesh(self,
				"res://assets/models/nature/0%d/bush_0%d.obj" % [variant + 1, variant + 1],
				points, rng.randf_range(1.6, 2.6), bush_material, false)

	var grass_points: Array[Transform3D] = []
	for _patch in 46:
		var angle := rng.randf_range(0.0, TAU)
		var distance := rng.randf_range(40.0, 178.0)
		var px := cos(angle) * distance
		var pz := sin(angle) * distance
		if _in_structure(px, pz):
			continue
		_append_cover(grass_points, px, pz, rng)
	_add_cover(grass_points, "WildGrassCover", _grass_material)

	var cliff_spots: Array[Vector2] = [
		Vector2(72.0, -134.0), Vector2(-44.0, -160.0),
		Vector2(146.0, -44.0), Vector2(-156.0, 138.0),
		Vector2(24.0, -158.0), Vector2(-126.0, -96.0),
	]
	for index in cliff_spots.size():
		var offset := cliff_spots[index]
		var model := "Cliff_Base_Hill_Gentle" if index % 2 == 0 else "Cliff_Base_Hill_Sharp"
		var px := offset.x
		var pz := offset.y
		AssetLibrary.place(self,
				"res://assets/models/terrain/Modular Terrain Cliff/%s.obj" % model,
				Vector3(px, _ground_min(px, pz, 5.5) - 0.5, pz), 11.0,
				rng.randf_range(0.0, 360.0), _rock_material, true)

	for index in 9:
		var angle := TAU * float(index) / 9.0 + 0.35
		var distance := rng.randf_range(90.0, 168.0)
		var px := cos(angle) * distance
		var pz := sin(angle) * distance
		if _in_district(px, pz):
			continue
		_add_dead_tree(Vector3(px, _ground_at(px, pz), pz),
				rng.randf_range(4.5, 8.0), index)

	for index in 4:
		var angle := TAU * float(index) / 4.0 + 1.2
		var px := cos(angle) * 130.0
		var pz := sin(angle) * 130.0
		if _in_district(px, pz):
			continue
		AssetLibrary.place(self,
				"res://assets/models/dungeon/Dungeon Set 2/struct_block_curved.obj",
				Vector3(px, _ground_at(px, pz) + 0.1, pz), 3.4,
				rng.randf_range(0.0, 360.0), _stone_material, true)

	var village_props := [
		[VILLAGE + "Prop_Barrel_1.obj", 0.95],
		[VILLAGE + "Prop_Crate_1.obj", 1.1],
		[VILLAGE + "Prop_Broom.obj", 1.2],
	]
	for index in 6:
		var angle := rng.randf_range(0.0, TAU)
		var distance := rng.randf_range(60.0, 170.0)
		var px := cos(angle) * distance
		var pz := sin(angle) * distance
		if _in_district(px, pz) or Vector2(px, pz).distance_to(LAKE_CENTRE) < 46.0:
			continue
		if Vector2(px, pz).distance_to(MAGMA_CENTRE) < 38.0:
			continue
		var entry: Array = village_props[index % village_props.size()]
		AssetLibrary.place(self, String(entry[0]),
				Vector3(px, _ground_at(px, pz) + 0.03, pz), float(entry[1]),
				rng.randf_range(0.0, 360.0), null, false)

func _build_rim() -> void:
	var rng := RandomNumberGenerator.new()
	rng.seed = 777
	for index in 14:
		var angle := TAU * float(index) / 14.0 + 0.11
		var distance := 198.0 + rng.randf_range(-8.0, 8.0)
		var px := cos(angle) * distance
		var pz := sin(angle) * distance
		var variant := index % AssetLibrary.ROCK_TEXTURES.size()
		var material := AssetLibrary.textured_material(
				AssetLibrary.ROCK_TEXTURES[variant], AssetLibrary.ROCK_NORMALS[variant], 0.95)
		AssetLibrary.place(self,
				"res://assets/models/rocks/0%d/rock_0%d.obj" % [variant + 1, variant + 1],
				Vector3(px, _ground_min(px, pz, 4.0) - 0.3, pz),
				rng.randf_range(4.5, 8.0), rng.randf_range(0.0, 360.0),
				material, true)

func _in_district(x: float, z: float) -> bool:
	var point := Vector2(x, z)
	return point.distance_to(HUB) < 46.0 \
			or point.distance_to(INDUSTRIAL) < 60.0 \
			or point.distance_to(RUINS_CENTRE) < 52.0 \
			or point.distance_to(CITY) < 66.0 \
			or _in_tunnel_span(x, z)

# Scatter band must never drop boulders/trees into the trench or on a bunker.
func _in_tunnel_span(x: float, z: float) -> bool:
	return absf(x) < TUNNEL_SKIRT + 6.0 \
			and z > TUNNEL_START.y - 12.0 and z < TUNNEL_END.y + 12.0

func _mark_structure(x: float, z: float, radius: float) -> void:
	_structure_spots.append(Vector3(x, z, radius))

func _in_structure(x: float, z: float) -> bool:
	if _in_tunnel_span(x, z):
		return true
	for spot in _structure_spots:
		var dx := x - spot.x
		var dz := z - spot.y
		if dx * dx + dz * dz < spot.z * spot.z:
			return true
	return false

func _edge_blocked(x: float, z: float) -> bool:
	if _in_structure(x, z):
		return true
	var point := Vector2(x, z)
	return point.distance_to(LAKE_CENTRE) < 46.0 \
			or point.distance_to(MAGMA_CENTRE) < 38.0

func _kit_spot(path: String, position: Vector3, yaw_degrees: float,
		scale: float, collide: bool, clear_radius: float,
		cast_shadow: bool = true) -> void:
	_kit_place(path, position, yaw_degrees, scale, collide, cast_shadow)
	_mark_structure(position.x, position.z, clear_radius)

func _build_district_cover() -> void:
	var rng := RandomNumberGenerator.new()
	rng.seed = 20261005
	var centres: Array[Vector2] = [HUB, INDUSTRIAL, RUINS_CENTRE, CITY]
	var radii: Array[float] = [44.0, 58.0, 48.0, 62.0]
	var grass_points: Array[Transform3D] = []
	var bush_points: Array = []
	for district_index in centres.size():
		var centre: Vector2 = centres[district_index]
		var radius := radii[district_index]
		for _attempt in 16:
			var angle := rng.randf_range(0.0, TAU)
			var distance := rng.randf_range(5.0, radius * 0.95)
			var px := centre.x + cos(angle) * distance
			var pz := centre.y + sin(angle) * distance
			if _edge_blocked(px, pz):
				continue
			_append_cover(grass_points, px, pz, rng)
		for _bush_attempt in 3:
			var bush_angle := rng.randf_range(0.0, TAU)
			var bush_distance := rng.randf_range(9.0, radius * 0.88)
			var bx := centre.x + cos(bush_angle) * bush_distance
			var bz := centre.y + sin(bush_angle) * bush_distance
			if _edge_blocked(bx, bz):
				continue
			bush_points.append([Vector3(bx, _ground_at(bx, bz), bz),
					rng.randf_range(0.0, 360.0), rng.randf_range(0.8, 1.3)])
	_add_cover(grass_points, "DistrictGrassCover", _grass_material)
	if not bush_points.is_empty():
		var bush_material := AssetLibrary.textured_material(
				AssetLibrary.BUSH_TEXTURES[1], "", 0.9, 0.0, Color.WHITE, true)
		AssetLibrary.multimesh(self,
				"res://assets/models/nature/02/bush_02.obj", bush_points,
				2.0, bush_material, false)

func _build_district_edges() -> void:
	var rng := RandomNumberGenerator.new()
	rng.seed = 20261006
	var centres: Array[Vector2] = [HUB, INDUSTRIAL, RUINS_CENTRE, CITY]
	var radii: Array[float] = [44.0, 58.0, 48.0, 62.0]
	var rock_points: Array = []
	var tuft_points: Array[Transform3D] = []
	var kerb_transforms: Array[Transform3D] = []
	var post_transforms: Array[Transform3D] = []
	for district_index in centres.size():
		var centre: Vector2 = centres[district_index]
		var radius := radii[district_index]
		for index in 18:
			var rock_angle := TAU * float(index) / 18.0 + rng.randf_range(-0.1, 0.1)
			var rock_ring := radius * rng.randf_range(0.74, 1.07)
			var rx := centre.x + cos(rock_angle) * rock_ring
			var rz := centre.y + sin(rock_angle) * rock_ring
			if _edge_blocked(rx, rz):
				continue
			var rock_size := rng.randf_range(1.3, 2.6)
			rock_points.append([Vector3(rx,
					_ground_min(rx, rz, rock_size * 0.5) - 0.06, rz),
					rng.randf_range(0.0, 360.0), rock_size / 2.4])
		for index in 34:
			var kerb_angle := TAU * float(index) / 34.0 + rng.randf_range(-0.05, 0.05)
			var kerb_ring := radius * rng.randf_range(0.72, 1.04)
			var kx := centre.x + cos(kerb_angle) * kerb_ring
			var kz := centre.y + sin(kerb_angle) * kerb_ring
			if _edge_blocked(kx, kz):
				continue
			kerb_transforms.append(Transform3D(Basis.from_euler(Vector3(
					rng.randf_range(-0.07, 0.07), kerb_angle + PI * 0.5,
					rng.randf_range(-0.07, 0.07))),
					Vector3(kx, _ground_at(kx, kz) + 0.14, kz)))
		for index in 26:
			var post_angle := TAU * float(index) / 26.0 + rng.randf_range(-0.06, 0.06)
			var post_ring := radius * rng.randf_range(0.76, 1.06)
			var fx := centre.x + cos(post_angle) * post_ring
			var fz := centre.y + sin(post_angle) * post_ring
			if _edge_blocked(fx, fz):
				continue
			post_transforms.append(Transform3D(Basis.from_euler(Vector3(
					rng.randf_range(-0.14, 0.14), rng.randf_range(0.0, TAU),
					rng.randf_range(-0.14, 0.14))),
					Vector3(fx, _ground_at(fx, fz) + 0.58, fz)))
		for index in 30:
			var tuft_angle := TAU * float(index) / 30.0 + rng.randf_range(-0.06, 0.06)
			var tuft_ring := radius * rng.randf_range(0.7, 1.05)
			var tx := centre.x + cos(tuft_angle) * tuft_ring
			var tz := centre.y + sin(tuft_angle) * tuft_ring
			if _edge_blocked(tx, tz):
				continue
			_append_cover(tuft_points, tx, tz, rng)
	if not rock_points.is_empty():
		AssetLibrary.multimesh(self, "res://assets/models/rocks/01/rock_01.obj",
				rock_points, 2.4, _rock_material, false)
	_add_cover(tuft_points, "DistrictEdgeTuft", _grass_material)
	var kerb_mesh := BoxMesh.new()
	kerb_mesh.size = Vector3(1.9, 0.42, 0.6)
	kerb_mesh.material = _stone_material
	var post_mesh := BoxMesh.new()
	post_mesh.size = Vector3(0.16, 1.3, 0.16)
	post_mesh.material = _rust_material
	_add_edge_multimesh(kerb_mesh, kerb_transforms, "DistrictEdgeKerb")
	_add_edge_multimesh(post_mesh, post_transforms, "DistrictEdgePost")

# Each district flattens a wide disc, so the band where that disc blends back
# into natural terrain reads as a bare green plateau next to its detailed
# core. Ring the seam with rubble and drop district-flavoured debris through
# the OUTER band only (0.66r-1.06r): the flat cores keep their spawn and
# action clearance, and every piece here is visual-only — no StaticBody3D —
# so colliders, play surfaces and the smoke staging rays are untouched.
func _build_district_plateaus() -> void:
	var rng := RandomNumberGenerator.new()
	rng.seed = 20261008
	var centres: Array[Vector2] = [HUB, INDUSTRIAL, RUINS_CENTRE, CITY]
	var radii: Array[float] = [44.0, 58.0, 48.0, 62.0]
	var chunk_sizes: Array[Vector3] = [
		Vector3(1.7, 0.26, 1.3), Vector3(1.9, 0.18, 1.2),
		Vector3(1.4, 0.8, 1.1), Vector3(1.6, 0.3, 1.3),
	]
	var chunk_materials: Array[StandardMaterial3D] = [
		_cobble_material, _rust_material, _stone_material, _asphalt_material,
	]
	var debris: Array = [
		[[VILLAGE + "Prop_Crate_1.obj", 1.1],
			[VILLAGE + "Prop_Barrel_1.obj", 0.95],
			[DUNGEON + "prop_floor_barrel.obj", 1.0]],
		[[SCIFI + "ammo_box.glb", 1.5],
			[KIT + "roads/construction-cone.glb", 0.8],
			[KIT + "roads/construction-barrier.glb", 1.5]],
		[[DUNGEON + "struct_block_normal.obj", 2.4],
			[RUINS + "PillarSegment_01.glb", 3.0],
			[DUNGEON + "struct_block_tapered.obj", 2.2]],
		[[DOWNTOWN_KIT + "Prop_Bollard.gltf", 1.1],
			[DOWNTOWN_KIT + "Prop_ManholeCover.gltf", 1.1],
			[KIT + "roads/construction-barrier.glb", 1.5]],
	]
	var seam_cover: Array[Transform3D] = []
	var rock_points: Array = []
	for district_index in centres.size():
		var centre: Vector2 = centres[district_index]
		var radius := radii[district_index]
		var options: Array = debris[district_index]
		var chunk_size: Vector3 = chunk_sizes[district_index]
		var chunks: Array[Transform3D] = []
		var debris_slot := 0
		for index in 40:
			var angle := TAU * float(index) / 40.0 + rng.randf_range(-0.07, 0.07)
			var ring := radius * rng.randf_range(0.66, 1.0)
			var px := centre.x + cos(angle) * ring
			var pz := centre.y + sin(angle) * ring
			if _edge_blocked(px, pz):
				continue
			if index % 2 == 0:
				var rock_size := rng.randf_range(0.9, 2.0)
				rock_points.append([Vector3(px,
						_ground_min(px, pz, rock_size * 0.5) - 0.1, pz),
						rng.randf_range(0.0, 360.0), rock_size / 2.4])
			if index % 3 == 0:
				_append_cover(seam_cover, px, pz, rng)
			if index % 5 == 0:
				chunks.append(Transform3D(Basis.from_euler(Vector3(
						rng.randf_range(-0.1, 0.1), rng.randf_range(0.0, TAU),
						rng.randf_range(-0.1, 0.1))),
						Vector3(px + rng.randf_range(-1.4, 1.4),
								_ground_at(px, pz) + chunk_size.y * 0.5 - 0.08,
								pz + rng.randf_range(-1.4, 1.4))))
			if index % 10 == 0:
				var entry: Array = options[debris_slot % options.size()]
				debris_slot += 1
				AssetLibrary.place(self, String(entry[0]),
						Vector3(px, _ground_at(px, pz) + 0.03, pz),
						float(entry[1]), rng.randf_range(0.0, 360.0), null, false)
		var chunk_mesh := BoxMesh.new()
		chunk_mesh.size = chunk_size
		chunk_mesh.material = chunk_materials[district_index]
		_add_edge_multimesh(chunk_mesh, chunks, "DistrictSeamRubble%d" % district_index)
	if not rock_points.is_empty():
		AssetLibrary.multimesh(self, "res://assets/models/rocks/03/rock_03.obj",
				rock_points, 2.4, _rock_material, false)
	_add_cover(seam_cover, "DistrictSeamCover", _cover_material)

# Flat ground-cover patch: a 1 x 1 plane stretched to a random rectangle and
# seated on the surface. Unlike a Grass_Flat box it has no thickness, so a
# slope underneath can never turn it into a slab with visible side walls.
func _append_cover(transforms: Array[Transform3D], x: float, z: float,
		rng: RandomNumberGenerator) -> void:
	var width := rng.randf_range(COVER_WIDTH_MIN, COVER_WIDTH_MAX)
	var depth := rng.randf_range(COVER_WIDTH_MIN * 0.6, COVER_WIDTH_MAX * 0.7)
	var basis := Basis.from_scale(Vector3(width, 1.0, depth)) * Basis(
			Vector3.UP, rng.randf_range(0.0, TAU))
	transforms.append(Transform3D(basis,
			Vector3(x, _ground_at(x, z) + COVER_LIFT, z)))

func _add_cover(transforms: Array[Transform3D], node_name: String,
		material: Material) -> void:
	if transforms.is_empty():
		return
	var plane := PlaneMesh.new()
	plane.size = Vector2.ONE
	plane.material = material
	_add_edge_multimesh(plane, transforms, node_name)

func _add_edge_multimesh(mesh: Mesh, transforms: Array[Transform3D],
		node_name: String) -> void:
	if transforms.is_empty():
		return
	var multi := MultiMesh.new()
	multi.transform_format = MultiMesh.TRANSFORM_3D
	multi.mesh = mesh
	multi.instance_count = transforms.size()
	for index in transforms.size():
		multi.set_instance_transform(index, transforms[index])
	var instance := MultiMeshInstance3D.new()
	instance.name = node_name
	instance.multimesh = multi
	instance.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	add_child(instance)

func _add_dead_tree(base: Vector3, height: float, index: int) -> void:
	var trunk := MeshUtil.make_cone(0.2, 0.09, height, _wood_material, 7, "trunk")
	trunk.position = base + Vector3(0.0, height * 0.5, 0.0)
	trunk.rotation_degrees.z = randf_range(-4.0, 4.0)
	add_child(trunk)
	var tree_body := StaticBody3D.new()
	tree_body.name = "TreeBody_%02d" % index
	tree_body.collision_layer = Layers.WORLD
	tree_body.collision_mask = Layers.WORLD
	tree_body.position = base + Vector3(0.0, height * 0.5, 0.0)
	var tree_shape := CollisionShape3D.new()
	var tree_box := BoxShape3D.new()
	tree_box.size = Vector3(0.4, height, 0.4)
	tree_shape.shape = tree_box
	tree_body.add_child(tree_shape)
	add_child(tree_body)
	var top := base + Vector3(0.0, height * 0.8, 0.0)
	for branch in 3:
		var angle := TAU * float(branch) / 3.0 + float(index)
		var direction := Vector3(cos(angle), randf_range(0.4, 0.9), sin(angle)).normalized()
		var length := randf_range(1.6, 2.8)
		MeshUtil.add_visual_cylinder(self, 0.05, length, top + direction * length * 0.5,
				_wood_material, direction, "branch_%d_%d" % [index, branch])

func _define_spawns() -> void:
	var player_point := Vector2(HUB.x, HUB.y + 26.0)
	player_spawn = Vector3(player_point.x, _ground_at(player_point.x, player_point.y) + 2.6,
			player_point.y)
	_mark_structure(player_point.x, player_point.y, 7.0)
	var points := [
		Vector2(-26.0, -6.0), Vector2(-64.0, 104.0), Vector2(-4.0, 132.0),
		Vector2(74.0, -56.0), Vector2(112.0, -88.0), Vector2(96.0, -40.0),
		Vector2(-74.0, -44.0), Vector2(-112.0, -74.0), Vector2(-96.0, -26.0),
		Vector2(58.0, 26.0), Vector2(96.0, 104.0), Vector2(66.0, 122.0),
		Vector2(-66.0, 84.0), Vector2(-116.0, 42.0),
		Vector2(40.0, -124.0),
	]
	for point in points:
		enemy_spawns.append(Vector3(point.x, _ground_at(point.x, point.y) + 2.6, point.y))
		_mark_structure(point.x, point.y, 6.0)
	_add_spawn_marker(player_spawn, Color(0.3, 0.9, 1.0), "player_spawn")
	for index in enemy_spawns.size():
		_add_spawn_marker(enemy_spawns[index], Color(1.0, 0.35, 0.25),
				"enemy_spawn_%d" % index)

func _add_spawn_marker(position: Vector3, color: Color, name_hint: String) -> void:
	var marker := Marker3D.new()
	marker.name = name_hint
	marker.position = position
	add_child(marker)
	var beacon := MeshUtil.make_cylinder(0.9, 0.08,
			MeshUtil.make_material(color, 0.0, 0.5, color, 2.4),
			MeshUtil.SEGMENTS_MED, "beacon")
	beacon.position = Vector3(0.0, -2.54, 0.0)
	marker.add_child(beacon)
