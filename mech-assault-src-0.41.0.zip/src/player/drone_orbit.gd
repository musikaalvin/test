extends Node3D

# Companion drone: ONE shaped drone that flies in formation beside the robot,
# repositions to rear-guard when a threat gets behind the host, and fires its
# own scaled-down built-in weapon at nearby enemies with line of sight.

const FORMATION_SIDE := 2.6
const FORMATION_FORWARD := 0.4
const FORMATION_HEIGHT := 2.3
const BOB_AMPLITUDE := 0.14
const BOB_SPEED := 2.4
const FOLLOW_SPEED := 9.0
const THREAT_RANGE := 42.0
const RETARGET_INTERVAL := 0.2
const BODY_SCALE := 1.35
const REAR_GUARD_DISTANCE := 3.0
const BEHIND_DOT := -0.15
# Dynamic reposition: back off when a threat crowds the slot, and slide around
# world geometry instead of clipping through walls.
const STANDOFF_DISTANCE := 14.0
const AVOID_PUSH := 2.6
# Emergency repair: WR-style trigger burst — drone restores a percentage of
# max HP in one hit when the host drops to/below the critical threshold,
# then rests on a cooldown (Starter/Glider-style).
const HEAL_TRIGGER := 0.30
const HEAL_COOLDOWN := 18.0
# Repair channel: the drone ties a beam to the hull for a beat after each
# emergency burst and pulses its own shell + accent glow while it works.
const ACCENT_ENERGY := 2.4
const BEAM_HOLD := 1.5
const POD_PULSE_TIME := 0.45
const POD_PULSE_BUMP := 0.22
const GLOW_PULSE_TIME := 0.6
const GLOW_PULSE_BOOST := 1.8

var weapon: WeaponData = null
var target: EnemyRobot = null
var shots_fired: int = 0
var rear_guard_weight: float = 0.0

var _body: Node3D
var _muzzle: Marker3D
var _bob: float = 0.0
var _cooldown: float = 0.0
var _retarget: float = 0.0
var _target_los: bool = false
var _heal_left: float = 0.0
var _beam_hold: float = 0.0
var _pod_pulse: float = 0.0
var _glow_pulse: float = 0.0
var _accent_material: StandardMaterial3D = null

func _ready() -> void:
	var kind := _drone_kind()
	weapon = WeaponData.drone_for(kind)
	_body = Node3D.new()
	_body.name = "Body"
	_body.scale = Vector3(BODY_SCALE, BODY_SCALE, BODY_SCALE)
	add_child(_body)
	_build_body(_body, kind)
	_build_barrel(_body, kind)
	_muzzle = Marker3D.new()
	_muzzle.name = "Muzzle"
	_muzzle.position = Vector3(0.0, 0.0, -0.46)
	_body.add_child(_muzzle)

func _build_body(body: Node3D, kind: String) -> void:
	var tint := _drone_color()
	var shell := MeshUtil.make_material(Color(0.14, 0.16, 0.18), 0.9, 0.35)
	# Built per instance, so pulsing its emission while a repair channels only
	# touches this drone - never a rig material.
	var accent := MeshUtil.make_material(tint, 0.4, 0.3, tint, ACCENT_ENERGY)
	_accent_material = accent
	var eye_mat := MeshUtil.make_material(tint, 0.2, 0.2, tint, 3.4)
	match kind:
		"bulwark":
			_add_box(body, "Core", Vector3(0.34, 0.17, 0.34), Vector3.ZERO, shell)
			_add_box(body, "Shield", Vector3(0.44, 0.26, 0.08),
					Vector3(0.0, 0.0, -0.2), accent)
			_add_box(body, "SkirtR", Vector3(0.1, 0.14, 0.3),
					Vector3(0.21, -0.02, 0.02), shell)
			_add_box(body, "SkirtL", Vector3(0.1, 0.14, 0.3),
					Vector3(-0.21, -0.02, 0.02), shell)
			_add_box(body, "Spine", Vector3(0.14, 0.1, 0.26),
					Vector3(0.0, 0.11, 0.1), accent)
			_add_eye(body, eye_mat, Vector3(0.0, 0.03, -0.25))
		"patch":
			_add_box(body, "Core", Vector3(0.2, 0.12, 0.42), Vector3.ZERO, shell)
			_add_box(body, "PodR", Vector3(0.1, 0.14, 0.18),
					Vector3(0.15, 0.0, 0.04), accent)
			_add_box(body, "PodL", Vector3(0.1, 0.14, 0.18),
					Vector3(-0.15, 0.0, 0.04), accent)
			_add_box(body, "WingR", Vector3(0.16, 0.04, 0.12),
					Vector3(0.16, 0.06, -0.1), shell, Vector3(0.0, 0.0, -0.35))
			_add_box(body, "WingL", Vector3(0.16, 0.04, 0.12),
					Vector3(-0.16, 0.06, -0.1), shell, Vector3(0.0, 0.0, 0.35))
			_add_box(body, "Antenna", Vector3(0.03, 0.2, 0.03),
					Vector3(0.0, 0.16, 0.16), accent)
			_add_eye(body, eye_mat, Vector3(0.0, 0.0, -0.23))
		"kestrel":
			_add_box(body, "Core", Vector3(0.22, 0.1, 0.46), Vector3.ZERO, shell)
			_add_box(body, "WingR", Vector3(0.3, 0.05, 0.14),
					Vector3(0.2, 0.0, -0.04), accent, Vector3(0.0, 0.45, 0.25))
			_add_box(body, "WingL", Vector3(0.3, 0.05, 0.14),
					Vector3(-0.2, 0.0, -0.04), accent, Vector3(0.0, -0.45, -0.25))
			_add_box(body, "Tail", Vector3(0.05, 0.18, 0.14),
					Vector3(0.0, 0.1, 0.2), shell, Vector3(-0.3, 0.0, 0.0))
			_add_box(body, "Spike", Vector3(0.06, 0.06, 0.22),
					Vector3(0.0, 0.0, -0.32), accent)
			_add_eye(body, eye_mat, Vector3(0.0, 0.04, -0.2))
		_:
			_add_box(body, "Core", Vector3(0.3, 0.1, 0.44), Vector3.ZERO, shell)
			_add_box(body, "WingR", Vector3(0.26, 0.05, 0.16),
					Vector3(0.17, 0.02, 0.04), accent, Vector3(0.0, -0.5, -0.18))
			_add_box(body, "WingL", Vector3(0.26, 0.05, 0.16),
					Vector3(-0.17, 0.02, 0.04), accent, Vector3(0.0, 0.5, 0.18))
			_add_box(body, "Fin", Vector3(0.05, 0.2, 0.14),
					Vector3(0.0, 0.12, 0.17), accent, Vector3(-0.35, 0.0, 0.0))
			_add_box(body, "Nose", Vector3(0.14, 0.07, 0.16),
					Vector3(0.0, 0.0, -0.28), shell)
			_add_eye(body, eye_mat, Vector3(0.0, 0.03, -0.24))

func _build_barrel(body: Node3D, kind: String) -> void:
	var tint := _drone_color()
	var gunmetal := MeshUtil.make_material(Color(0.2, 0.22, 0.24), 0.9, 0.4)
	var glow := MeshUtil.make_material(tint, 0.2, 0.2, tint, 3.0)
	match kind:
		"bulwark":
			for side: float in [-1.0, 1.0]:
				MeshUtil.add_visual_cylinder(body, 0.05, 0.36,
						Vector3(0.09 * side, 0.02, -0.36), gunmetal,
						Vector3(0.0, 0.0, -1.0), "tube")
				_add_tip(body, glow, Vector3(0.09 * side, 0.02, -0.52), 0.045)
		"patch":
			MeshUtil.add_visual_cylinder(body, 0.09, 0.3,
					Vector3(0.0, 0.0, -0.36), gunmetal,
					Vector3(0.0, 0.0, -1.0), "nozzle")
			_add_tip(body, glow, Vector3(0.0, 0.0, -0.5), 0.07)
		"kestrel":
			for index: int in 3:
				var angle := TAU * float(index) / 3.0
				MeshUtil.add_visual_cylinder(body, 0.032, 0.34,
						Vector3(cos(angle) * 0.05, sin(angle) * 0.05, -0.36),
						gunmetal, Vector3(0.0, 0.0, -1.0), "barrel")
			_add_tip(body, glow, Vector3(0.0, 0.0, -0.52), 0.05)
		_:
			MeshUtil.add_visual_cylinder(body, 0.04, 0.38,
					Vector3(0.0, -0.02, -0.4), gunmetal,
					Vector3(0.0, 0.0, -1.0), "prong")
			_add_tip(body, glow, Vector3(0.0, -0.02, -0.58), 0.055)

func _add_tip(parent: Node3D, material: StandardMaterial3D, pos: Vector3,
		radius: float) -> void:
	var node := MeshInstance3D.new()
	node.name = "Tip"
	var mesh := SphereMesh.new()
	mesh.radius = radius
	mesh.height = radius * 2.0
	node.mesh = mesh
	node.material_override = material
	node.position = pos
	parent.add_child(node)

func _add_box(parent: Node3D, mesh_name: String, size: Vector3, pos: Vector3,
		material: StandardMaterial3D, rot: Vector3 = Vector3.ZERO) -> void:
	var node := MeshInstance3D.new()
	node.name = mesh_name
	var mesh := BoxMesh.new()
	mesh.size = size
	node.mesh = mesh
	node.material_override = material
	node.position = pos
	node.rotation = rot
	parent.add_child(node)

func _add_eye(parent: Node3D, material: StandardMaterial3D, pos: Vector3) -> void:
	var node := MeshInstance3D.new()
	node.name = "Eye"
	var mesh := SphereMesh.new()
	mesh.radius = 0.05
	mesh.height = 0.1
	node.mesh = mesh
	node.material_override = material
	node.position = pos
	parent.add_child(node)

func _physics_process(delta: float) -> void:
	var host := get_parent() as Node3D
	if host == null or not is_finite(global_position.x):
		return
	_bob += delta * BOB_SPEED
	_cooldown -= delta
	_retarget -= delta
	_heal_left -= delta
	var player := host as PlayerRobot
	_tick_emergency_repair(player)
	_tick_beam_hold(player, delta)
	_tick_pod_pulse(delta)
	_tick_glow_pulse(delta)
	var host_alive := player == null or (player.health != null and not player.health.dead)
	var facing := _host_forward(host)
	var side := host.global_transform.basis.x
	side.y = 0.0
	if side.length_squared() < 0.001:
		side = Vector3.RIGHT
	side = side.normalized()
	var desired := host.global_position + side * FORMATION_SIDE \
			+ facing * FORMATION_FORWARD + Vector3.UP * FORMATION_HEIGHT
	rear_guard_weight = 0.0
	var threat := _nearest_threat(host.global_position)
	if threat != null:
		var to_threat := threat.global_position - host.global_position
		to_threat.y = 0.0
		if to_threat.length() > 0.5:
			var dot := facing.dot(to_threat.normalized())
			if dot < BEHIND_DOT:
				rear_guard_weight = clampf((-dot - BEHIND_DOT) / (1.0 + BEHIND_DOT),
						0.0, 1.0)
				var rear := host.global_position \
						+ to_threat.normalized() * REAR_GUARD_DISTANCE \
						+ Vector3.UP * FORMATION_HEIGHT
				desired = desired.lerp(rear, rear_guard_weight)
	if rear_guard_weight < 0.5:
		desired = _standoff(desired, threat)
	desired.y += sin(_bob) * BOB_AMPLITUDE
	desired = _avoid_obstacle(global_position, desired, host)
	global_position = global_position.move_toward(desired, FOLLOW_SPEED * delta)
	if _retarget <= 0.0:
		_retarget = RETARGET_INTERVAL
		_refresh_target(host)
	var face := facing
	if target != null and not target_is_dead():
		face = target.eye_position() - global_position
	face.y = 0.0
	if face.length_squared() > 0.0004:
		var yaw := atan2(-face.x, -face.z)
		rotation.y = lerp_angle(rotation.y, yaw, minf(10.0 * delta, 1.0))
	if host_alive and target != null and not target_is_dead() and _target_los \
			and _cooldown <= 0.0 and weapon != null:
		_fire_at_target(host)

func target_is_dead() -> bool:
	if target != null and not is_instance_valid(target):
		target = null
		return true
	return target == null or (target.health != null and target.health.dead)

func _tick_emergency_repair(player: PlayerRobot) -> void:
	if player == null or player.health == null or player.health.dead:
		return
	if _heal_left > 0.0:
		return
	var health := player.health
	if health.current >= health.max_health * HEAL_TRIGGER:
		return
	var pct := heal_percent()
	if pct <= 0.0 or health.current >= health.max_health:
		return
	health.heal(health.max_health * pct)
	_heal_left = HEAL_COOLDOWN
	Events.player_health_changed.emit(health.current, health.max_health)
	_note_repair_beam(player)

func heal_percent() -> float:
	return float(GameState.drone_def(_drone_kind()).get("heal", 0.0))

# Channel visuals for the emergency burst: the hull's HealFxController draws
# the beam itself (it knows the capsule anchor), the drone just keeps it fed
# for BEAM_HOLD and lights its own shell while the channel lasts.
func _note_repair_beam(player: PlayerRobot) -> void:
	var fx := player.heal_fx
	if fx == null:
		return
	fx.set_beam_source(self)
	fx.set_beam_active(true)
	_beam_hold = BEAM_HOLD
	_pod_pulse = POD_PULSE_TIME
	_glow_pulse = GLOW_PULSE_TIME

func _tick_beam_hold(player: PlayerRobot, delta: float) -> void:
	if _beam_hold <= 0.0:
		return
	_beam_hold -= delta
	if _beam_hold > 0.0:
		return
	_beam_hold = 0.0
	if player != null and player.heal_fx != null:
		player.heal_fx.set_beam_active(false)

func _tick_pod_pulse(delta: float) -> void:
	if _pod_pulse <= 0.0:
		return
	_pod_pulse -= delta
	var lift := clampf(1.0 - _pod_pulse / POD_PULSE_TIME, 0.0, 1.0)
	var bump := sin(lift * PI)
	if _body != null:
		_body.scale = Vector3.ONE * (BODY_SCALE * (1.0 + POD_PULSE_BUMP * bump))
	if _pod_pulse > 0.0:
		return
	_pod_pulse = 0.0
	if _body != null:
		_body.scale = Vector3.ONE * BODY_SCALE

func _tick_glow_pulse(delta: float) -> void:
	if _glow_pulse <= 0.0:
		return
	_glow_pulse -= delta
	var lift := clampf(1.0 - _glow_pulse / GLOW_PULSE_TIME, 0.0, 1.0)
	var bump := sin(lift * PI)
	if _accent_material != null:
		_accent_material.emission_energy_multiplier = ACCENT_ENERGY \
				* (1.0 + GLOW_PULSE_BOOST * bump)
	if _glow_pulse > 0.0:
		return
	_glow_pulse = 0.0
	if _accent_material != null:
		_accent_material.emission_energy_multiplier = ACCENT_ENERGY

func _refresh_target(host: Node3D) -> void:
	target = null
	_target_los = false
	if weapon == null:
		return
	var fire_range := WeaponData.drone_fire_range(_drone_kind())
	var muzzle := _muzzle.global_position
	var best := fire_range
	var exclude := _host_exclude(host)
	for node in get_tree().get_nodes_in_group("enemy"):
		var enemy := node as EnemyRobot
		if enemy == null or enemy.state == EnemyRobot.State.DEAD:
			continue
		if enemy.health != null and enemy.health.dead:
			continue
		var distance := muzzle.distance_to(enemy.eye_position())
		if distance >= best:
			continue
		if not _line_of_sight(muzzle, enemy, exclude):
			continue
		best = distance
		target = enemy
	_target_los = target != null

func _fire_at_target(host: Node3D) -> void:
	var origin := _muzzle.global_position
	var aim := target.eye_position() - origin
	if aim.length_squared() < 0.04:
		return
	if not Projectiles.fire(origin, aim.normalized(), weapon, _host_exclude(host)):
		return
	shots_fired += 1
	_cooldown = 60.0 / maxf(weapon.shots_per_minute, 1.0)
	# mount_index < 0 = drone shot: audio plays, host haptics ignore it
	Events.weapon_fired.emit(-1, weapon.kind, StringName(weapon.family), int(weapon.size))

func _line_of_sight(from: Vector3, enemy: EnemyRobot,
		exclude: Array[RID]) -> bool:
	var world := get_world_3d()
	if world == null:
		return false
	var query := PhysicsRayQueryParameters3D.new()
	query.from = from
	query.to = enemy.eye_position()
	query.collision_mask = Layers.WORLD | Layers.ENEMY
	query.collide_with_areas = false
	query.collide_with_bodies = true
	query.exclude = exclude
	var result := world.direct_space_state.intersect_ray(query)
	if result.is_empty():
		return true
	return result.get("collider") == enemy

## Keep a firing stand-off: when a threat crowds the formation slot, slide the
## slot away so the drone stays at weapon range instead of flying into melee.
func _standoff(desired: Vector3, threat: EnemyRobot) -> Vector3:
	if threat == null or not is_instance_valid(threat):
		return desired
	var away := desired - threat.global_position
	away.y = 0.0
	var distance := away.length()
	if distance >= STANDOFF_DISTANCE:
		return desired
	if distance < 0.5:
		away = Vector3(0.0, 0.0, 1.0)
	else:
		away = away / distance
	var pushed := threat.global_position + away * STANDOFF_DISTANCE
	pushed.y = desired.y
	return pushed

## Slide around world geometry: if the path to the slot crosses a wall, push the
## slot out along the surface so the drone never flies through scenery.
func _avoid_obstacle(from: Vector3, to: Vector3, host: Node3D) -> Vector3:
	var world := get_world_3d()
	if world == null:
		return to
	var travel := to - from
	if travel.length_squared() < 0.09:
		return to
	var query := PhysicsRayQueryParameters3D.new()
	query.from = from
	query.to = to
	query.collision_mask = Layers.WORLD
	query.exclude = _host_exclude(host)
	query.collide_with_areas = false
	query.collide_with_bodies = true
	var hit := world.direct_space_state.intersect_ray(query)
	if hit.is_empty():
		return to
	var normal := hit.get("normal") as Vector3
	var push := Vector3(normal.x, 0.0, normal.z)
	if push.length_squared() < 0.01:
		push = Vector3.RIGHT
	push = push.normalized() * AVOID_PUSH
	return to + push + Vector3.UP * 0.7

func _nearest_threat(origin: Vector3) -> EnemyRobot:
	var best: EnemyRobot = null
	var best_distance := THREAT_RANGE
	for node in get_tree().get_nodes_in_group("enemy"):
		var enemy := node as EnemyRobot
		if enemy == null or enemy.state == EnemyRobot.State.DEAD:
			continue
		if enemy.health != null and enemy.health.dead:
			continue
		var distance := enemy.global_position.distance_to(origin)
		if distance < best_distance:
			best_distance = distance
			best = enemy
	return best

func _host_forward(host: Node3D) -> Vector3:
	var forward := -host.global_transform.basis.z
	forward.y = 0.0
	if forward.length_squared() < 0.001:
		return Vector3.FORWARD
	return forward.normalized()

func _host_exclude(host: Node3D) -> Array[RID]:
	var exclude: Array[RID] = []
	if host is CollisionObject3D:
		exclude.append((host as CollisionObject3D).get_rid())
	return exclude

func _drone_kind() -> String:
	return GameState.drone_for_robot(GameState.selected_robot)

func _drone_color() -> Color:
	match _drone_kind():
		"bulwark": return Color(1.0, 0.72, 0.28)
		"patch": return Color(0.36, 0.95, 0.55)
		"kestrel": return Color(1.0, 0.38, 0.34)
	return Color(0.25, 0.9, 1.0)
