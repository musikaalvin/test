class_name TitanRig
extends VortexRig

# Bulk factor shared with tools/build_princeps.py (BULK = 1.25): the GLB is
# authored at 1.0 and multiplied by the same number, so rig bones, weapon
# sockets and mesh stay in sync. TITAN_SCALE scales the whole rig vs. robots.
const BULK := 1.25
const TITAN_SCALE := 1.5 * BULK
const PRINCEPS_GLB := "res://assets/mech/princeps.glb"
const CITADEL_GLB := "res://assets/mech/citadel.glb"
const RAVAGER_GLB := "res://assets/mech/ravager.glb"

func glb_path() -> String:
	match GameState.selected_robot:
		GameState.ROBOT_CITADEL:
			return CITADEL_GLB
		GameState.ROBOT_RAVAGER:
			return RAVAGER_GLB
	return PRINCEPS_GLB

func _ready() -> void:
	move_pitch_gain = 0.02
	turn_roll_gain = 0.04
	strafe_roll_gain = 0.025
	bob_freq_base = 1.5
	bob_freq_speed = 6.0
	fire_pitch_kick = -0.09
	fire_bob_kick = -0.07
	fire_roll_kick = 0.015
	fire_kick_decay = 3.0
	reload_pitch = -0.1
	reload_crouch = -0.09
	reload_brace_hardpoint = 0.16
	_make_materials()
	_build_chassis()
	_build_carapace_detail()
	_build_head()
	_build_legs()
	_build_hardpoints()
	_build_thrusters()
	_build_titan_crown()
	_head_base = _head_base * TITAN_SCALE
	head_sensor.position = _head_base
	_attach_heromech()

func _build_thrusters() -> void:
	for side in [-1.0, 1.0]:
		var flame := CPUParticles3D.new()
		flame.name = "ThrusterFlame"
		flame.amount = 22
		flame.lifetime = 0.3
		flame.preprocess = 0.3
		flame.direction = Vector3(0.0, -1.0, 0.4)
		flame.spread = 14.0
		flame.gravity = Vector3.ZERO
		flame.initial_velocity_min = 6.5
		flame.initial_velocity_max = 12.0
		flame.scale_amount_min = 0.15
		flame.scale_amount_max = 0.39
		flame.color = Color(1.0, 0.62, 0.25, 0.9)
		var cone := BoxMesh.new()
		cone.size = Vector3.ONE
		var flame_material := MeshUtil.make_material(Color(1.0, 0.7, 0.35), 0.0, 0.9,
				Color(1.0, 0.55, 0.2), 2.6)
		flame_material.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
		flame_material.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
		flame_material.blend_mode = BaseMaterial3D.BLEND_MODE_ADD
		flame_material.vertex_color_use_as_albedo = true
		cone.material = flame_material
		flame.mesh = cone
		flame.emitting = false
		flame.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
		flame.position = Vector3(side * 0.66, 0.78, 1.14) * BULK
		chassis.add_child(flame)
		_thruster_flames.append(flame)

func _build_legs() -> void:
	var hip_pos: Array[Vector3] = [
		Vector3(0.78 * BULK, -0.15 * BULK, 0.0),
		Vector3(-0.78 * BULK, -0.15 * BULK, 0.0),
	]
	var hip_out: Array[Vector3] = [
		Vector3.RIGHT, Vector3.LEFT,
	]
	var hip_phase: Array[float] = [0.0, 0.5]
	var hip_name: Array[String] = ["Leg_R", "Leg_L"]
	for index in hip_pos.size():
		var leg := LegUnit.new()
		leg.name = hip_name[index]
		leg.phase_offset = hip_phase[index]
		leg.outward = hip_out[index]
		leg.thigh_length = 1.875 * BULK
		leg.shin_length = 2.175 * BULK
		leg.coxa_length = 0.48 * BULK
		leg.hip_radius = 0.3 * BULK
		leg.thigh_radius = 0.24 * BULK
		leg.shin_radius = 0.18 * BULK
		leg.foot_size = Vector3(0.69, 0.21, 0.9) * BULK
		leg.rest_spread = 0.5
		leg.pole_style = 1
		leg.stride_length = 2.1 * BULK
		leg.step_height = 0.825 * BULK
		leg.reference_speed = 5.6 * BULK
		leg.configure(_primary, _joint, _accent, _secondary, _trim, _sensor)
		leg.apply_scale(visual_scale)
		add_child(leg)
		leg.position = hip_pos[index]
		_leg_bases.append(hip_pos[index])
		leg_units.append(leg)

func _build_hardpoints() -> void:
	var socket_pos: Array[Vector3] = [
		Vector3(1.08, 2.16, -0.3) * BULK, Vector3(-1.08, 2.16, -0.3) * BULK,
		Vector3(1.65, 0.15, 0.3) * BULK, Vector3(-1.65, 0.15, 0.3) * BULK,
	]
	var socket_side: Array[float] = [1.0, -1.0, 1.0, -1.0]
	_create_hardpoints(socket_pos, socket_side)

func _build_titan_crown() -> void:
	for index in 3:
		var height := 0.55 + float(index) * 0.22
		MeshUtil.bevel_at(chassis, Vector3(0.36, height, 0.34),
				Vector3(0.0, 1.7 + float(index) * 0.26, 0.3 + float(index) * 0.16),
				Vector3(-12.0, 0.0, 0.0), _primary, "titan_spine_%d" % index)
		MeshUtil.bevel_at(chassis, Vector3(0.2, height * 0.5, 0.16),
				Vector3(0.0, 1.72 + float(index) * 0.26, 0.16 + float(index) * 0.16),
				Vector3(-12.0, 0.0, 0.0), _accent, "titan_spine_trim_%d" % index)
	for side in [-1.0, 1.0]:
		MeshUtil.cyl_at(chassis, 0.12, 1.35, Vector3(side * 0.72, 2.05, 0.34),
				Vector3(-16.0, 0.0, side * -9.0), _trim, "titan_pylon")
		MeshUtil.sph_at(chassis, 0.17, Vector3(side * 0.55, 2.72, 0.16),
				_sensor, "titan_pylon_tip")
		MeshUtil.bevel_at(chassis, Vector3(0.5, 0.42, 0.62),
				Vector3(side * 1.3, 1.62, 0.3), Vector3.ZERO, _secondary,
				"titan_shoulder_block")
	MeshUtil.bevel_at(head_sensor, Vector3(1.1, 0.1, 0.12),
			Vector3(0.0, 0.36, -0.02), Vector3.ZERO, _sensor, "titan_crown_bar")
	MeshUtil.bevel_at(head_sensor, Vector3(1.3, 0.14, 0.4),
			Vector3(0.0, 0.3, 0.16), Vector3(-8.0, 0.0, 0.0), _accent, "titan_crown")
