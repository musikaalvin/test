class_name MechRig
extends Node3D

var leg_units: Array[LegUnit] = []
var mounts: Array[WeaponMount] = []
var hardpoints: Array[Node3D] = []
var muzzle_points: Array[Marker3D] = []

func hardpoint_count() -> int:
	return mounts.size()

func muzzle_world_position(index: int) -> Vector3:
	if index < 0 or index >= muzzle_points.size():
		return global_position
	return muzzle_points[index].global_position

func reset_feet(_ground_points: Array[Vector3]) -> void:
	pass

func update_animation(_delta: float, _velocity: Vector3, _turn_rate: float, _grounded: bool,
		_aim_yaw: float, _head_yaw: float) -> void:
	pass

func set_stealth(_active: bool) -> void:
	pass
