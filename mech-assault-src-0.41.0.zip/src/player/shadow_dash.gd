class_name ShadowDash
extends AbilityBase

# Ground-fan tessellation for the stealth-break burst.
const FAN_RINGS := 5
const FAN_SEGS := 14

# Omen-Fang-style Sandcloak: long fast dash + stealth; while dashing the
# scorpion skims across water and magma instead of sinking.
@export var dash_distance: float = 30.0
@export var dash_duration: float = 1.5
@export var stealth_duration: float = 6.5
@export var recharge_time: float = 6.0
@export var jam_duration: float = 3.0
@export var fracture_duration: float = 6.0
@export var rust_duration: float = 5.0
@export var rust_dps: float = 3.0
@export var cone_angle_degrees: float = 75.0
@export var effect_range: float = 15.0
@export var effect_strength: float = 1.0

var dash_active: bool = false
var stealth_active: bool = false

var _player: PlayerRobot
var _rig: RobotRig
var _dash_left: float = 0.0
var _stealth_left: float = 0.0
var _recharges: Array[float] = []
var _motes: CPUParticles3D
var _trail: CPUParticles3D
var _charge_clock: float = 0.0

func setup(player: PlayerRobot, rig: RobotRig) -> void:
	_player = player
	_rig = rig

func _ready() -> void:
	recharge_time *= float(GameState.combat_stats().get("cooldown", 1.0))
	max_charges = 3
	dash_speed = 26.0
	charges = max_charges
	Events.ability_requested.connect(activate)
	_build_motes()
	_build_trail()
	_emit_charges()
	_set_phase("READY")

func _physics_process(delta: float) -> void:
	var charges_before := charges
	for index in range(_recharges.size() - 1, -1, -1):
		_recharges[index] -= delta
		if _recharges[index] <= 0.0:
			_recharges.remove_at(index)
			charges = mini(charges + 1, max_charges)
	if charges != charges_before:
		_emit_charges()
	if not _recharges.is_empty():
		_charge_clock += delta
		if _charge_clock >= 0.15:
			_charge_clock = 0.0
			_emit_charges()
	if _dash_left > 0.0:
		_dash_left -= delta
		if _dash_left <= 0.0:
			dash_active = false
			if _trail != null:
				_trail.emitting = false
			_update_phase()
	if stealth_active:
		_stealth_left -= delta
		_charge_clock += delta
		if _charge_clock >= 0.25:
			_charge_clock = 0.0
			_emit_charges()
		if _stealth_left <= 0.0:
			end_stealth("duration")

func is_dash_active() -> bool:
	return dash_active

func is_stealth_active() -> bool:
	return stealth_active

func tick_vertical(_delta: float) -> bool:
	if not dash_active or _player == null:
		return false
	var zone := HazardZones.zone_at(_player.global_position)
	if zone.is_empty():
		return false
	# Glide on the liquid surface for the whole dash
	var level := float(zone["level"])
	if _player.global_position.y < level + 0.35:
		_player.global_position.y = level + 0.35
		_player.velocity.y = maxf(_player.velocity.y, 0.0)
	else:
		_player.velocity.y = maxf(_player.velocity.y, -0.5)
	return true

func recharge_ratio() -> float:
	if _recharges.is_empty():
		return 1.0
	var fastest := INF
	for time_left in _recharges:
		fastest = minf(fastest, time_left)
	return clampf(1.0 - fastest / maxf(recharge_time, 0.01), 0.0, 1.0)

func activate() -> void:
	if stealth_active:
		end_stealth("manual")
		return
	if dash_active or charges <= 0 or _player == null or not _player._is_alive():
		return
	charges -= 1
	_recharges.append(recharge_time)
	_emit_charges()
	dash_active = true
	_dash_left = dash_duration
	stealth_active = true
	_stealth_left = stealth_duration
	if _trail != null:
		_trail.emitting = true
	_apply_dash_impulse()
	_set_visual_stealth(true)
	_spawn_activation_fx()
	Events.camera_shake_requested.emit(0.55, 0.28)
	_set_phase("DASHING")

func notify_fired() -> void:
	if stealth_active:
		end_stealth("fired")

func force_end() -> void:
	if stealth_active:
		end_stealth("forced")

func end_stealth(_reason: String) -> void:
	if not stealth_active:
		return
	stealth_active = false
	_stealth_left = 0.0
	_set_visual_stealth(false)
	_disrupt()
	_update_phase()

func _apply_dash_impulse() -> void:
	if _player == null:
		return
	var forward := -_player.global_basis.z
	forward.y = 0.0
	if forward.length_squared() < 0.001:
		forward = Vector3.FORWARD
	var step := forward.normalized() * (dash_distance / maxf(dash_duration, 0.05)) * 0.35
	_player.velocity += step

func _set_visual_stealth(active: bool) -> void:
	if _rig != null:
		_rig.set_stealth(active)
	if _motes != null:
		_motes.emitting = active

func _update_phase() -> void:
	if dash_active:
		_set_phase("DASHING")
	elif stealth_active:
		_set_phase("STEALTH")
	elif charges < max_charges:
		_set_phase("RECHARGING")
	else:
		_set_phase("READY")

func _set_phase(value: String) -> void:
	if phase_name != value:
		phase_name = value
		Events.ability_phase_changed.emit(value)

func _emit_charges() -> void:
	Events.ability_charges_changed.emit(charges, max_charges, recharge_ratio())

func _build_motes() -> void:
	_motes = CPUParticles3D.new()
	_motes.name = "StealthMotes"
	_motes.amount = 24
	_motes.lifetime = 0.7
	_motes.local_coords = false
	_motes.direction = Vector3.UP
	_motes.spread = 180.0
	_motes.gravity = Vector3(0.0, 1.2, 0.0)
	_motes.initial_velocity_min = 0.4
	_motes.initial_velocity_max = 1.4
	_motes.scale_amount_min = 0.05
	_motes.scale_amount_max = 0.14
	_motes.color = Color(0.4, 0.95, 1.0, 0.7)
	var box := BoxMesh.new()
	box.size = Vector3.ONE
	var material := MeshUtil.make_material(Color(0.4, 0.95, 1.0), 0.0, 0.3,
			Color(0.35, 0.9, 1.0), 2.4)
	material.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
	material.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
	material.vertex_color_use_as_albedo = true
	box.material = material
	_motes.mesh = box
	_motes.emitting = false
	add_child(_motes)

# Speed streaks left behind the hull for the whole dash.
func _build_trail() -> void:
	_trail = CPUParticles3D.new()
	_trail.name = "DashTrail"
	_trail.amount = 70
	_trail.lifetime = 0.55
	_trail.local_coords = false
	_trail.direction = Vector3(0.0, 0.3, 1.0)
	_trail.spread = 26.0
	_trail.gravity = Vector3.ZERO
	_trail.initial_velocity_min = 3.0
	_trail.initial_velocity_max = 8.0
	_trail.scale_amount_min = 0.5
	_trail.scale_amount_max = 1.7
	_trail.color = Color(0.35, 0.9, 1.0, 0.8)
	var streak := BoxMesh.new()
	streak.size = Vector3(0.5, 0.34, 0.34)
	var material := MeshUtil.make_material(Color(0.3, 0.85, 1.0), 0.0, 0.4,
			Color(0.35, 0.9, 1.0), 2.2)
	material.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
	material.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
	material.blend_mode = BaseMaterial3D.BLEND_MODE_ADD
	material.vertex_color_use_as_albedo = true
	streak.material = material
	_trail.mesh = streak
	_trail.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	_trail.emission_shape = CPUParticles3D.EMISSION_SHAPE_BOX
	_trail.emission_box_extents = Vector3(0.9, 1.0, 0.5)
	_trail.position = Vector3(0.0, 1.4, 0.2)
	_trail.emitting = false
	add_child(_trail)

func _spawn_activation_fx() -> void:
	if _player == null:
		return
	var flash := OmniLight3D.new()
	flash.name = "DashFlash"
	flash.light_color = Color(0.45, 0.9, 1.0)
	flash.omni_range = 7.0
	flash.light_energy = 3.0
	flash.position = Vector3(0.0, 0.4, 0.0)
	_player.add_child(flash)
	var tween := create_tween()
	tween.tween_property(flash, "light_energy", 0.0, 0.3)
	tween.tween_callback(flash.queue_free)
	_spawn_dust()

func _spawn_dust() -> void:
	var dust := CPUParticles3D.new()
	dust.name = "DashDust"
	dust.one_shot = true
	dust.amount = 16
	dust.lifetime = 0.6
	dust.explosiveness = 1.0
	dust.direction = Vector3.UP
	dust.spread = 80.0
	dust.gravity = Vector3(0.0, -6.0, 0.0)
	dust.initial_velocity_min = 1.5
	dust.initial_velocity_max = 4.0
	dust.scale_amount_min = 0.15
	dust.scale_amount_max = 0.4
	dust.color = Color(0.55, 0.55, 0.5, 0.55)
	var ball := SphereMesh.new()
	ball.radius = 0.25
	ball.height = 0.5
	var material := MeshUtil.make_material(Color(0.5, 0.5, 0.47), 0.0, 1.0)
	material.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
	material.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
	material.vertex_color_use_as_albedo = true
	ball.material = material
	dust.mesh = ball
	dust.position = _player.global_position + Vector3(0.0, 0.15, 0.0)
	get_parent().add_child(dust)
	dust.global_position = _player.global_position + Vector3(0.0, 0.15, 0.0)
	dust.emitting = true
	var timer := get_tree().create_timer(1.0)
	timer.timeout.connect(dust.queue_free)

func _disrupt() -> void:
	Events.ability_phase_changed.emit("DISRUPTION PULSE")
	if _player == null:
		return
	var origin := _player.global_position
	var forward := _player.forward_direction()
	var half_angle := deg_to_rad(cone_angle_degrees * 0.5)
	for target in get_tree().get_nodes_in_group("enemy"):
		var enemy := target as Node3D
		if enemy == null or not enemy.has_method("apply_system_jam"):
			continue
		var offset: Vector3 = enemy.global_position - origin
		offset.y *= 0.35
		var distance := offset.length()
		if distance > effect_range or distance < 0.05:
			continue
		if forward.angle_to(offset.normalized()) > half_angle:
			continue
		enemy.call("apply_system_jam", jam_duration)
		enemy.call("apply_armor_fracture", fracture_duration, effect_strength)
		if enemy.has_method("apply_corrosion"):
			enemy.call("apply_corrosion", rust_duration, rust_dps)
		_spawn_enemy_burst(enemy)
	_spawn_pulse_visual(origin, forward)

# The burst always lives in world space so it never rides the hull transform.
func _fx_world() -> Node:
	if _player != null and _player.get_parent() != null:
		return _player.get_parent()
	return self

# Flat ground fan (local -Z is the fan direction) built as a rings x segs
# grid: vertex colour ramps inner -> outer, winding gives +Y normals.
func _make_cone_fan(radius: float, half_angle: float, inner_frac: float,
		col_inner: Color, col_outer: Color) -> ArrayMesh:
	var inner_radius := radius * clampf(inner_frac, 0.0, 0.95)
	var span := maxf(radius - inner_radius, 0.01)
	var surface := SurfaceTool.new()
	surface.begin(Mesh.PRIMITIVE_TRIANGLES)
	for ring in FAN_RINGS + 1:
		var t := float(ring) / float(FAN_RINGS)
		var r := inner_radius + span * t
		var col := col_inner.lerp(col_outer, t)
		for seg in FAN_SEGS + 1:
			var u := float(seg) / float(FAN_SEGS)
			var angle := -half_angle + 2.0 * half_angle * u
			surface.set_normal(Vector3.UP)
			surface.set_color(col)
			surface.set_uv(Vector2(t, u))
			surface.add_vertex(Vector3(sin(angle) * r, 0.0, -cos(angle) * r))
	for ring in FAN_RINGS:
		for seg in FAN_SEGS:
			var v00 := ring * (FAN_SEGS + 1) + seg
			var v01 := v00 + 1
			var v10 := (ring + 1) * (FAN_SEGS + 1) + seg
			var v11 := v10 + 1
			surface.add_index(v00)
			surface.add_index(v01)
			surface.add_index(v10)
			surface.add_index(v01)
			surface.add_index(v11)
			surface.add_index(v10)
	return surface.commit()

func _fan_material(emission: Color, emission_energy: float) -> StandardMaterial3D:
	var material := MeshUtil.make_material(Color.WHITE, 0.0, 0.4,
			emission, emission_energy)
	material.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
	material.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
	material.blend_mode = BaseMaterial3D.BLEND_MODE_ADD
	material.cull_mode = BaseMaterial3D.CULL_DISABLED
	material.vertex_color_use_as_albedo = true
	return material

# One-shot world-space particle burst (sparks, rust wash, victim pops).
func _burst_particles(name_hint: String, amount: int, life: float,
		direction: Vector3, spread_deg: float, speed_min: float, speed_max: float,
		gravity: Vector3, color: Color, size: float, additive: bool) -> CPUParticles3D:
	var burst := CPUParticles3D.new()
	burst.name = name_hint
	burst.one_shot = true
	burst.amount = maxi(1, amount)
	burst.lifetime = life
	burst.explosiveness = 1.0
	burst.local_coords = false
	burst.direction = direction.normalized()
	burst.spread = spread_deg
	burst.gravity = gravity
	burst.initial_velocity_min = speed_min
	burst.initial_velocity_max = speed_max
	burst.color = color
	burst.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	var box := BoxMesh.new()
	box.size = Vector3(size, size, size)
	var material := MeshUtil.make_material(color, 0.0, 0.4, color,
			2.6 if additive else 0.0)
	material.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
	material.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
	if additive:
		material.blend_mode = BaseMaterial3D.BLEND_MODE_ADD
	material.vertex_color_use_as_albedo = true
	box.material = material
	burst.mesh = box
	return burst

func _place_burst(world: Node, burst: CPUParticles3D, at: Vector3,
		free_after: float) -> void:
	world.add_child(burst)
	burst.global_position = at
	burst.emitting = true
	var timer := get_tree().create_timer(free_after)
	timer.timeout.connect(burst.queue_free)

func _free_nodes(nodes: Array[MeshInstance3D]) -> void:
	for node in nodes:
		if is_instance_valid(node):
			node.queue_free()

# Jagged 3-segment bolt sharing one transient material, faded out over life.
func _spawn_bolt(world: Node, a: Vector3, b: Vector3, col: Color, thickness: float,
		life: float) -> void:
	var fractions: Array[float] = [0.34, 0.67]
	var points: Array[Vector3] = [a]
	for fraction in fractions:
		var mid := a.lerp(b, fraction)
		mid += Vector3(randf_range(-0.9, 0.9), randf_range(-0.9, 0.9),
				randf_range(-0.9, 0.9))
		points.append(mid)
	points.append(b)
	var material := MeshUtil.make_material(col, 0.0, 0.3, col, 3.0)
	material.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
	material.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
	material.blend_mode = BaseMaterial3D.BLEND_MODE_ADD
	var segments: Array[MeshInstance3D] = []
	for index in points.size() - 1:
		var start_p: Vector3 = points[index]
		var end_p: Vector3 = points[index + 1]
		var delta := end_p - start_p
		var seg_length := delta.length()
		if seg_length < 0.001:
			continue
		var segment := MeshInstance3D.new()
		var box := BoxMesh.new()
		# Long axis is local Y to match MeshUtil.segment_basis (+Y along dir).
		box.size = Vector3(thickness, seg_length, thickness)
		box.material = material
		segment.mesh = box
		segment.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
		world.add_child(segment)
		segment.global_transform = Transform3D(
				MeshUtil.segment_basis(delta / seg_length),
				(start_p + end_p) * 0.5)
		segments.append(segment)
	if segments.is_empty():
		return
	var tween := create_tween()
	tween.tween_property(material, "albedo_color:a", 0.0, life)
	tween.tween_callback(_free_nodes.bind(segments))

# EMP systems pop + rust settles on every victim inside the cone.
func _spawn_enemy_burst(enemy: Node3D) -> void:
	if enemy == null or not is_instance_valid(enemy):
		return
	var world := _fx_world()
	var at := enemy.global_position + Vector3.UP * 1.3
	var pop := _burst_particles("EnemyEmpPop", 16, 0.35, Vector3.UP, 180.0,
			2.5, 6.0, Vector3(0.0, -3.0, 0.0), Color(0.7, 0.95, 1.0, 1.0), 0.09, true)
	_place_burst(world, pop, at, 0.7)
	var rust := _burst_particles("EnemyRustSettle", 10, 0.7, Vector3.UP, 70.0,
			1.0, 2.6, Vector3(0.0, -5.0, 0.0), Color(0.78, 0.34, 0.08, 0.7), 0.16, false)
	_place_burst(world, rust, at, 1.2)

# Fang-style stealth break: rust wedge wash, leading wavefront, spark and
# rust bursts, arc bolts and an EMP flash - all layered on the ground cone.
func _spawn_pulse_visual(origin: Vector3, forward: Vector3) -> void:
	AudioEngine.play(&"zap", 1.0, 0.1, 0.8)
	Events.camera_shake_requested.emit(0.3, 0.22)
	var world := _fx_world()
	var dir := forward
	dir.y = 0.0
	if dir.length_squared() < 0.0001:
		dir = Vector3.FORWARD
	dir = dir.normalized()
	var half_angle := deg_to_rad(cone_angle_degrees * 0.5)
	var yaw := atan2(-dir.x, -dir.z)
	var fan_origin := origin + Vector3(0.0, 0.12, 0.0)

	# 1) main ground wedge: rust core washing out to electric cyan-white.
	var wedge := MeshInstance3D.new()
	wedge.name = "DisruptionPulse"
	wedge.mesh = _make_cone_fan(effect_range, half_angle, 0.06,
			Color(0.9, 0.38, 0.08, 0.55), Color(0.55, 0.92, 1.0, 0.9))
	var wedge_mat := _fan_material(Color(0.55, 0.85, 1.0), 1.4)
	wedge.material_override = wedge_mat
	wedge.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	world.add_child(wedge)
	wedge.global_position = fan_origin
	wedge.global_basis = Basis(Vector3.UP, yaw)
	wedge.scale = Vector3.ONE * 0.16
	var wedge_tw := create_tween()
	wedge_tw.set_parallel(true)
	wedge_tw.tween_property(wedge, "scale", Vector3.ONE, 0.42) \
			.set_trans(Tween.TRANS_CUBIC).set_ease(Tween.EASE_OUT)
	wedge_tw.tween_property(wedge_mat, "albedo_color:a", 0.0, 0.5)
	wedge_tw.chain().tween_callback(wedge.queue_free)

	# 2) leading wavefront band, brighter, starting a beat later.
	var wave := MeshInstance3D.new()
	wave.name = "PulseWavefront"
	wave.mesh = _make_cone_fan(effect_range, half_angle, 0.82,
			Color(0.7, 0.95, 1.0, 0.7), Color(1.0, 1.0, 1.0, 0.95))
	var wave_mat := _fan_material(Color(0.8, 0.96, 1.0), 3.0)
	wave.material_override = wave_mat
	wave.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	world.add_child(wave)
	wave.global_position = fan_origin + Vector3(0.0, 0.04, 0.0)
	wave.global_basis = Basis(Vector3.UP, yaw)
	wave.scale = Vector3.ONE * 0.3
	var wave_tw := create_tween()
	wave_tw.set_parallel(true)
	wave_tw.tween_property(wave, "scale", Vector3.ONE * 1.16, 0.36) \
			.set_trans(Tween.TRANS_CUBIC).set_ease(Tween.EASE_OUT).set_delay(0.06)
	wave_tw.tween_property(wave_mat, "albedo_color:a", 0.0, 0.44).set_delay(0.06)
	wave_tw.chain().tween_callback(wave.queue_free)

	# 3) spark burst thrown forward inside the cone.
	var sparks := _burst_particles("PulseSparks", 46, 0.3, dir,
			cone_angle_degrees * 0.5, 12.0, 22.0, Vector3.ZERO,
			Color(0.75, 0.95, 1.0, 1.0), 0.1, true)
	_place_burst(world, sparks, origin + Vector3.UP * 0.5, 0.8)

	# 4) corroding dust falling inside the cone.
	var rust := _burst_particles("PulseRustWash", 34, 0.85, dir,
			cone_angle_degrees * 0.5, 3.5, 8.0, Vector3(0.0, -6.0, 0.0),
			Color(0.78, 0.34, 0.08, 0.7), 0.16, false)
	_place_burst(world, rust, origin + Vector3.UP * 0.4, 1.3)

	# 5) arc bolts leaping to points down-range inside the cone.
	var side := dir.cross(Vector3.UP)
	if side.length_squared() < 0.0001:
		side = Vector3.RIGHT
	side = side.normalized()
	for index in 4:
		var reach := randf_range(5.0, 12.0)
		var start := origin + dir * randf_range(0.4, 1.4) \
				+ Vector3.UP * randf_range(0.3, 1.2)
		var end := origin + dir * reach + side * randf_range(-4.0, 4.0) \
				+ Vector3.UP * randf_range(0.3, 1.8)
		_spawn_bolt(world, start, end, Color(0.7, 0.92, 1.0), 0.14, 0.35)

	# 6) EMP flash.
	var flash := OmniLight3D.new()
	flash.name = "PulseFlash"
	flash.light_color = Color(0.55, 0.8, 1.0)
	flash.omni_range = 11.0
	flash.light_energy = 4.0
	flash.shadow_enabled = false
	world.add_child(flash)
	flash.global_position = origin + Vector3.UP * 0.8
	var flash_tw := create_tween()
	flash_tw.tween_property(flash, "light_energy", 0.0, 0.28)
	flash_tw.tween_callback(flash.queue_free)

