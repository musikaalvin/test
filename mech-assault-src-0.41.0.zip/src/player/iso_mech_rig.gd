class_name IsoMechRig
extends RobotRig

const MECH_SCENE := "res://assets/mech_kit/Mech/SK_ISO_Mech.fbx"
const ANIM_DIR := "res://assets/mech_kit/Mech/Animations/"
const TEX_DIR := "res://assets/mech_kit/Mech/Textures/"
const MECH_TEX_ALBEDO := TEX_DIR + "T_Mech_Base_Color.png"
const MECH_TEX_METALLIC := TEX_DIR + "T_Mech_Metallic.png"
const MECH_TEX_ROUGH := TEX_DIR + "T_Mech_Roughness.png"
const MECH_TEX_NORMAL := TEX_DIR + "T_Mech_Normal.png"
const MECH_TEX_EMISSION := TEX_DIR + "T_Mech_Emissive.png"
const MECH_SCALE := 0.36
const MECH_Y := -2.1
const MECH_YAW_DEGREES := 180.0
const WALK_REFERENCE_SPEED := 3.4
const STRAFE_REFERENCE_SPEED := 2.6
const DEATH_BLEND := 0.3

const CLIP_KEYS := {
	&"idle": "A_ISO_Mech_Idle_01",
	&"walk_f": "A_ISO_Mech_WalkForward_01",
	&"walk_b": "A_ISO_Mech_WalkBackward_01",
	&"walk_l": "A_ISO_Mech_Walk_L_01",
	&"walk_r": "A_ISO_Mech_Walk_R_01",
	&"land": "A_ISO_Mech_Landing_01",
	&"death": "A_ISO_Mech_Death_01",
}
const LOOP_KEYS: Array[StringName] = [
	&"idle", &"walk_f", &"walk_b", &"walk_l", &"walk_r",
]

var _anim: AnimationPlayer = null
var _current_state: StringName = &""
var _was_airborne := false
var _fade_materials: Array[StandardMaterial3D] = []
var _fade_emission: Array[float] = []
var _tex_ok := 0
var _tex_total := 0
var _tex_albedo: Texture2D = null
var _tex_metallic: Texture2D = null
var _tex_rough: Texture2D = null
var _tex_normal: Texture2D = null
var _tex_emission: Texture2D = null
var _tex_loaded := false

func _ready() -> void:
	_make_materials()
	_build_mech()
	_build_animations()
	_build_hardpoints()

func _build_mech() -> void:
	var scene := load(MECH_SCENE) as PackedScene
	if scene == null:
		push_warning("IsoMechRig: missing mech scene %s" % MECH_SCENE)
		return
	var mech := scene.instantiate() as Node3D
	if mech == null:
		return
	mech.name = "Group"
	mech.position = Vector3(0.0, MECH_Y, 0.0)
	mech.rotation_degrees = Vector3(0.0, MECH_YAW_DEGREES, 0.0)
	mech.scale = Vector3.ONE * MECH_SCALE
	add_child(mech)
	chassis = mech
	_load_mech_textures()
	for node in mech.find_children("*", "MeshInstance3D", true, false):
		var mesh_instance := node as MeshInstance3D
		if mesh_instance == null or mesh_instance.mesh == null:
			continue
		if String(mesh_instance.name).ends_with("LOD1"):
			mesh_instance.visible = false
		for surface in mesh_instance.mesh.get_surface_count():
			var material := mesh_instance.get_active_material(surface)
			var copy: StandardMaterial3D
			if material is StandardMaterial3D:
				copy = (material as StandardMaterial3D).duplicate() as StandardMaterial3D
			if copy == null:
				copy = StandardMaterial3D.new()
			mesh_instance.set_surface_override_material(surface, copy)
			_apply_mech_textures(copy)
			_fade_materials.append(copy)
			_fade_emission.append(copy.emission_energy_multiplier if copy.emission_enabled else -1.0)

func _load_mech_textures() -> void:
	if _tex_loaded:
		return
	_tex_loaded = true
	_tex_albedo = load(MECH_TEX_ALBEDO) as Texture2D
	_tex_metallic = load(MECH_TEX_METALLIC) as Texture2D
	_tex_rough = load(MECH_TEX_ROUGH) as Texture2D
	_tex_normal = load(MECH_TEX_NORMAL) as Texture2D
	_tex_emission = load(MECH_TEX_EMISSION) as Texture2D

func _apply_mech_textures(material: StandardMaterial3D) -> void:
	_tex_total += 1
	material.transparency = BaseMaterial3D.TRANSPARENCY_DISABLED
	material.vertex_color_use_as_albedo = false
	if _tex_albedo != null:
		material.albedo_texture = _tex_albedo
		material.albedo_color = Color.WHITE
		_tex_ok += 1
	else:
		push_error("IsoMechRig: albedo texture missing: %s" % MECH_TEX_ALBEDO)
		material.albedo_texture = null
		material.albedo_color = Color(0.78, 0.22, 0.16)
	if _tex_metallic != null and _tex_rough != null:
		material.metallic = 0.6 if _tex_albedo != null else 0.25
		material.metallic_texture = _tex_metallic
		material.roughness = 0.9
		material.roughness_texture = _tex_rough
	else:
		material.metallic = 0.35
		material.metallic_texture = null
		material.roughness = 0.85
		material.roughness_texture = null
	if _tex_normal != null:
		material.normal_enabled = true
		material.normal_texture = _tex_normal
	else:
		material.normal_enabled = false
		material.normal_texture = null
	if _tex_emission != null and _tex_albedo != null:
		material.emission_enabled = true
		material.emission = Color.WHITE
		material.emission_texture = _tex_emission
		material.emission_energy_multiplier = 1.0
	else:
		material.emission_enabled = false
		material.emission = Color.BLACK
		material.emission_texture = null
		material.emission_energy_multiplier = 1.0

func texture_report() -> String:
	return "TEX %d/%d" % [_tex_ok, _tex_total]

func _build_animations() -> void:
	_anim = AnimationPlayer.new()
	_anim.name = "RigAnimator"
	add_child(_anim)
	var library := AnimationLibrary.new()
	for key in CLIP_KEYS:
		var clip_file := String(CLIP_KEYS[key])
		var scene := load(ANIM_DIR + clip_file + ".fbx") as PackedScene
		if scene == null:
			push_warning("IsoMechRig: missing clip %s" % clip_file)
			continue
		var inst := scene.instantiate() as Node3D
		if inst == null:
			continue
		var clip: Animation = null
		for node in inst.find_children("*", "AnimationPlayer", true, false):
			var source := node as AnimationPlayer
			var names := source.get_animation_library("").get_animation_list()
			if not names.is_empty():
				clip = source.get_animation_library("").get_animation(names[0])
				break
		inst.free()
		if clip == null:
			push_warning("IsoMechRig: empty clip %s" % clip_file)
			continue
		if LOOP_KEYS.has(key):
			clip.loop_mode = Animation.LOOP_LINEAR
			for track in range(clip.get_track_count() - 1, -1, -1):
				if clip.track_get_type(track) == Animation.TYPE_POSITION_3D \
						and String(clip.track_get_path(track)).ends_with(":Root_M"):
					clip.remove_track(track)
		clip.resource_name = String(key)
		library.add_animation(key, clip)
	_anim.add_animation_library("", library)
	_anim.animation_finished.connect(_on_animation_finished)

func _build_hardpoints() -> void:
	var socket_pos: Array[Vector3] = [
		Vector3(0.95, -0.3, -0.2), Vector3(-0.95, -0.3, -0.2),
		Vector3(1.3, -1.05, 0.4), Vector3(-1.3, -1.05, 0.4),
	]
	var socket_side: Array[float] = [1.0, -1.0, 1.0, -1.0]
	_create_hardpoints(socket_pos, socket_side)

func set_stealth(active: bool) -> void:
	for index in _fade_materials.size():
		var material := _fade_materials[index]
		var original_energy := _fade_emission[index]
		if active:
			if material.transparency == BaseMaterial3D.TRANSPARENCY_DISABLED:
				material.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
			var color := material.albedo_color
			color.a = 0.32
			material.albedo_color = color
			if material.emission_enabled and original_energy >= 0.0:
				material.emission_energy_multiplier = maxf(original_energy * 2.5, 3.2)
		else:
			var faded := material.albedo_color
			faded.a = 1.0
			material.albedo_color = faded
			material.transparency = BaseMaterial3D.TRANSPARENCY_DISABLED
			if material.emission_enabled and original_energy >= 0.0:
				material.emission_energy_multiplier = original_energy

func play_death() -> void:
	if _anim == null:
		return
	_current_state = &"death"
	_anim.play(&"death", DEATH_BLEND, 1.0, false)

func update_animation(_delta: float, velocity: Vector3, _turn_rate: float, grounded: bool,
		aim_yaw: float, _head_yaw: float) -> void:
	if _anim == null:
		return
	if _current_state == &"death":
		return
	var planar := Vector3(velocity.x, 0.0, velocity.z)
	var speed := planar.length()
	var local := global_basis.inverse() * planar
	var state: StringName = &"idle"
	if speed > 0.4:
		if absf(local.z) >= absf(local.x):
			state = &"walk_f" if local.z < 0.0 else &"walk_b"
		else:
			state = &"walk_l" if local.x < 0.0 else &"walk_r"
	if not grounded:
		_was_airborne = true
	elif _was_airborne:
		_was_airborne = false
		if speed <= 0.4:
			_current_state = &"land"
			_anim.play(&"land", 0.1, 2.0, false)
			return
	if _current_state == &"land" and speed <= 0.4:
		return
	if state != _current_state:
		var blend := 0.15
		if _current_state == &"land":
			blend = 0.2
		_anim.play(state, blend, 1.0, false)
		_current_state = state
	var ratio := 1.0
	if state == &"walk_f" or state == &"walk_b":
		ratio = clampf(speed / WALK_REFERENCE_SPEED, 0.6, 1.9)
	elif state == &"walk_l" or state == &"walk_r":
		ratio = clampf(speed / STRAFE_REFERENCE_SPEED, 0.6, 1.7)
	_anim.speed_scale = ratio
	var converge := clampf(aim_yaw * 0.45, -0.35, 0.35)
	for index in hardpoints.size():
		var side: float = 1.0 if index % 2 == 0 else -1.0
		hardpoints[index].rotation = Vector3(
				0.0, deg_to_rad(_socket_yaw_deg[index]) + converge * side, 0.0)

func _on_animation_finished(anim_name: StringName) -> void:
	if anim_name == &"land":
		_current_state = &""
