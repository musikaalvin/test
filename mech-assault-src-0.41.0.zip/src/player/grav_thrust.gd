class_name GravThrustAbility
extends AbilityBase

# Princeps-style GRAV THRUST (War Robots tuning): TWO charges on a 9 s
# cooldown. Activation locks a live line-of-sight target (locked enemy first,
# else nearest in front, 90 m on our scale of WR's 400 m aim), waits 0.5 s,
# then hurls THAT target away from the titan with a Slowdown of 50% for 5 s
# and a short systems jam. Whiffs (target died or ducked behind cover before
# the cast lands) simply fizzle.

const ROBOT: StringName = &"PRAETOR"

@export var recharge_time: float = 9.0
@export var cast_range: float = 90.0
@export var cast_delay: float = 0.5
@export var push_strength: float = 16.0
@export var slow_duration: float = 5.0
@export var jam_duration: float = 0.8

var _player: PlayerRobot
var _rig: RobotRig
var _recharge_left: float = -1.0
var _pending_target: EnemyRobot = null
var _pending_left: float = 0.0

func setup(player: PlayerRobot, rig: RobotRig) -> void:
	_player = player
	_rig = rig

func _ready() -> void:
	recharge_time *= float(GameState.combat_stats().get("cooldown", 1.0))
	max_charges = 2
	charges = 2
	dash_speed = 0.0
	Events.secondary_ability_requested.connect(activate)
	_emit_charges()
	_set_phase("READY")

func _physics_process(delta: float) -> void:
	if charges < max_charges:
		if _recharge_left < 0.0:
			_recharge_left = recharge_time
		_recharge_left -= delta
		if _recharge_left <= 0.0:
			charges = mini(charges + 1, max_charges)
			_recharge_left = recharge_time if charges < max_charges else -1.0
			if charges >= max_charges:
				_set_phase("READY")
		_emit_charges()
	if _pending_target != null and _pending_left > 0.0:
		_pending_left -= delta
		if _pending_left <= 0.0:
			var target := _pending_target
			_pending_target = null
			if is_instance_valid(target) and _player != null and _has_los(target):
				_execute(target)
			_settle_phase()

func activate() -> void:
	if GameState.selected_robot != ROBOT:
		return
	if charges <= 0 or _player == null or not _player._is_alive():
		return
	charges -= 1
	if _recharge_left < 0.0:
		_recharge_left = recharge_time
	_pending_target = _pick_target()
	_pending_left = cast_delay
	if _rig != null:
		_rig.kick_ability(6.0, 0.0, 0.45)
	Events.camera_shake_requested.emit(0.55, 0.35)
	Haptics.pulse(70, 0.85)
	_set_phase("THRUST")
	_emit_charges()

func _enemy_gone(enemy: EnemyRobot) -> bool:
	if enemy == null or not is_instance_valid(enemy):
		return true
	if enemy.state == EnemyRobot.State.DEAD:
		return true
	return enemy.health == null or enemy.health.dead

func _pick_target() -> EnemyRobot:
	if _player == null:
		return null
	var locked := _player.locked_enemy
	if not _enemy_gone(locked) \
			and locked.global_position.distance_to(_player.global_position) <= cast_range \
			and _has_los(locked):
		return locked
	var best: EnemyRobot = null
	var best_distance := cast_range
	for node in get_tree().get_nodes_in_group("enemy"):
		var enemy := node as EnemyRobot
		if _enemy_gone(enemy):
			continue
		var distance := enemy.global_position.distance_to(_player.global_position)
		if distance < best_distance and _has_los(enemy):
			best_distance = distance
			best = enemy
	return best

func _has_los(target: EnemyRobot) -> bool:
	if _player == null or target == null:
		return false
	var from := _player.global_position + Vector3.UP * 1.6
	var to := target.global_position + Vector3.UP * 1.0
	var query := PhysicsRayQueryParameters3D.create(from, to, Layers.WORLD)
	var hit := _player.get_world_3d().direct_space_state.intersect_ray(query)
	if hit.is_empty():
		return true
	var hit_position: Vector3 = hit.get("position", to)
	return hit_position.distance_to(from) >= from.distance_to(to) - 0.5

func _execute(target: EnemyRobot) -> void:
	if _player == null or target == null or not is_instance_valid(target):
		return
	var offset := target.global_position - _player.global_position
	if offset.length() > cast_range * 1.6:
		return
	var push := offset.normalized() * push_strength + Vector3.UP * 5.0
	if target.has_method("apply_grav_pulse"):
		target.call("apply_grav_pulse", push)
	elif target is CharacterBody3D:
		(target as CharacterBody3D).velocity += push
	if target.has_method("apply_slow"):
		target.call("apply_slow", slow_duration, 0.5)
	if target.has_method("apply_system_jam"):
		target.call("apply_system_jam", jam_duration)

func _settle_phase() -> void:
	if charges > 0:
		_set_phase("READY")
	else:
		_set_phase("RECHARGING")

func is_dash_active() -> bool:
	return false

func is_stealth_active() -> bool:
	return false

func recharge_ratio() -> float:
	if charges >= max_charges:
		return 1.0
	if _recharge_left <= 0.0:
		return 1.0
	return clampf(1.0 - _recharge_left / maxf(recharge_time, 0.01), 0.0, 1.0)

func notify_fired() -> void:
	pass

func force_end() -> void:
	_pending_target = null
	_pending_left = 0.0
	_settle_phase()

func _set_phase(value: String) -> void:
	if phase_name != value:
		phase_name = value
		Events.secondary_ability_phase_changed.emit(value)

func _emit_charges() -> void:
	Events.secondary_ability_charges_changed.emit(charges, max_charges, recharge_ratio())
