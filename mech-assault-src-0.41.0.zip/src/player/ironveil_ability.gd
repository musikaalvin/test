class_name IronveilAbility
extends AbilityBase

# CITADEL secondary: raise a frontal barrier for a few seconds - 90% of every
# hit is cut away and 35% of the raw damage is welded back into the hull,
# capped so one window can never repair more than 40% of max health.
const ROBOT: StringName = &"CITADEL"

@export var recharge_time: float = 13.0
@export var duration: float = 9.0
@export var shield_reduction: float = 0.1
@export var repair_fraction: float = 0.35
@export var repair_budget_fraction: float = 0.4

var barrier_active: bool = false

var _player: PlayerRobot
var _rig: RobotRig
var _recharge_left: float = -1.0
var _active_left: float = 0.0
var _pending_repair: float = 0.0
var _repair_budget: float = 0.0
var _plate: MeshInstance3D
var _pulse: Tween

func setup(player: PlayerRobot, rig: RobotRig) -> void:
	_player = player
	_rig = rig
	if player.health != null and not player.health.damaged.is_connected(_on_damaged):
		player.health.damaged.connect(_on_damaged)

func _ready() -> void:
	recharge_time *= float(GameState.combat_stats().get("cooldown", 1.0))
	max_charges = 1
	charges = 1
	dash_speed = 0.0
	Events.secondary_ability_requested.connect(activate)
	_emit_charges()
	_set_phase("READY")

func _physics_process(delta: float) -> void:
	if charges < max_charges:
		if _recharge_left < 0.0:
			_recharge_left = recharge_time
		_recharge_left -= delta
		if _recharge_left <= 0.0:
			charges = mini(charges + 1, max_charges)
			_recharge_left = recharge_time if charges < max_charges else -1.0
			_set_phase("READY")
		_emit_charges()
	if barrier_active:
		_active_left -= delta
		if _active_left <= 0.0:
			_end_barrier()
	# Repairs land one frame after the hit so heal() never runs before the
	# incoming damage has been subtracted from the hull.
	if _pending_repair > 0.0 and _player != null and _player.health != null:
		var repair := _pending_repair
		_pending_repair = 0.0
		if not _player.health.dead:
			_player.health.heal(repair)
			Events.player_health_changed.emit(
					_player.health.current, _player.health.max_health)

func activate() -> void:
	if GameState.selected_robot != ROBOT:
		return
	if barrier_active or charges <= 0 or _player == null or not _player._is_alive():
		return
	if _player.health == null:
		return
	charges = 0
	_recharge_left = recharge_time
	barrier_active = true
	_active_left = duration
	_repair_budget = repair_budget_fraction * _player.health.max_health
	_player.health.shield_mult = shield_reduction
	_show_plate(true)
	if _rig != null:
		_rig.kick_ability(3.5, 0.0, 0.6)
	Events.camera_shake_requested.emit(0.3, 0.2)
	Haptics.pulse(60, 0.6)
	_set_phase("BARRIER")
	_emit_charges()

func _on_damaged(amount: float, _applied: float, _current: float,
		_point: Vector3) -> void:
	if not barrier_active or amount <= 0.001:
		return
	if _repair_budget <= 0.0:
		return
	var repair := minf(amount * repair_fraction, _repair_budget)
	_repair_budget -= repair
	_pending_repair += repair

func _end_barrier() -> void:
	barrier_active = false
	_active_left = 0.0
	_pending_repair = 0.0
	if _player != null and _player.health != null:
		_player.health.shield_mult = 1.0
	_show_plate(false)
	if charges > 0:
		_set_phase("READY")
	else:
		_set_phase("RECHARGING")

func is_dash_active() -> bool:
	return false

func is_stealth_active() -> bool:
	return false

func recharge_ratio() -> float:
	if charges >= max_charges:
		return 1.0
	if _recharge_left <= 0.0:
		return 1.0
	return clampf(1.0 - _recharge_left / maxf(recharge_time, 0.01), 0.0, 1.0)

func notify_fired() -> void:
	pass

func force_end() -> void:
	if barrier_active:
		_end_barrier()

func _show_plate(active: bool) -> void:
	if active:
		_ensure_plate()
		if _plate == null:
			return
		_plate.visible = true
		_plate.scale = Vector3(0.5, 1.0, 1.0)
		if _pulse != null and _pulse.is_valid():
			_pulse.kill()
		_pulse = create_tween()
		_pulse.set_loops()
		_pulse.tween_property(_plate, "scale", Vector3.ONE, 0.22) \
				.set_trans(Tween.TRANS_BACK).set_ease(Tween.EASE_OUT)
		_pulse.tween_property(_plate, "transparency", 0.35, 0.5)
		_pulse.tween_property(_plate, "transparency", 0.1, 0.5)
	elif _plate != null:
		if _pulse != null and _pulse.is_valid():
			_pulse.kill()
		_pulse = create_tween()
		_pulse.tween_property(_plate, "transparency", 1.0, 0.25)
		_pulse.tween_callback(_hide_plate)

func _hide_plate() -> void:
	if _plate != null:
		_plate.visible = false

func _ensure_plate() -> void:
	if _plate != null or _player == null:
		return
	_plate = MeshInstance3D.new()
	_plate.name = "IronveilPlate"
	var wall := BoxMesh.new()
	wall.size = Vector3(7.5, 5.0, 0.12)
	var material := StandardMaterial3D.new()
	material.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
	material.albedo_color = Color(1.0, 0.78, 0.32, 0.16)
	material.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
	material.blend_mode = BaseMaterial3D.BLEND_MODE_ADD
	material.cull_mode = BaseMaterial3D.CULL_DISABLED
	material.emission_enabled = true
	material.emission = Color(1.0, 0.72, 0.28)
	material.emission_energy_multiplier = 2.2
	wall.material = material
	_plate.mesh = wall
	_plate.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	_plate.position = Vector3(0.0, 2.0, -3.2)
	_plate.visible = false
	_player.add_child(_plate)

func _set_phase(value: String) -> void:
	if phase_name != value:
		phase_name = value
		Events.secondary_ability_phase_changed.emit(value)

func _emit_charges() -> void:
	Events.secondary_ability_charges_changed.emit(charges, max_charges, recharge_ratio())
