class_name VortexRig
extends RobotRig

const VORTEX_GLB := "res://assets/mech/vortex.glb"

func glb_path() -> String:
	return VORTEX_GLB

func _ready() -> void:
	move_pitch_gain = 0.016
	turn_roll_gain = 0.065
	strafe_roll_gain = 0.042
	bob_freq_base = 2.6
	bob_freq_speed = 10.0
	fire_pitch_kick = -0.035
	fire_bob_kick = -0.025
	fire_roll_kick = 0.035
	fire_kick_decay = 6.0
	reload_pitch = -0.06
	reload_crouch = -0.05
	reload_brace_hardpoint = 0.1
	_make_materials()
	_build_chassis()
	_build_carapace_detail()
	_build_head()
	_build_legs()
	_build_hardpoints()
	_build_thrusters()
	_attach_heromech()

func _build_carapace_detail() -> void:
	var dome := MeshUtil.sph_at(chassis, 0.8, Vector3(0.0, 1.0, -0.05), _primary, "carapace_dome")
	dome.scale = Vector3(1.06, 0.6, 0.9)
	MeshUtil.cyl_at(chassis, 0.2, 0.08, Vector3(0.0, 0.74, -0.72),
			Vector3(-90.0, 0.0, 0.0), _recess, "core_bezel")
	var core := MeshUtil.make_cylinder(0.13, 0.12, _sensor, 6, "chest_core")
	chassis.add_child(core)
	core.position = Vector3(0.0, 0.74, -0.77)
	core.rotation_degrees = Vector3(-90.0, 0.0, 0.0)
	for side in [-1.0, 1.0]:
		var cap := MeshUtil.sph_at(chassis, 0.27, Vector3(side * 1.0, 1.2, 0.0),
				_primary, "shoulder_cap")
		cap.scale = Vector3(1.0, 0.75, 1.0)
		MeshUtil.cyl_at(chassis, 0.07, 0.07, Vector3(side * 1.0, 1.42, 0.0),
				Vector3.ZERO, _sensor, "shoulder_hex")
		MeshUtil.cone_at(chassis, 0.05, 0.005, 0.26,
				Vector3(side * 1.16, 1.32, 0.1),
				Vector3(-40.0, 0.0, side * -50.0), _accent, "shoulder_spike")

var _thruster_flames: Array[CPUParticles3D] = []

func _build_thrusters() -> void:
	for side in [-1.0, 1.0]:
		MeshUtil.bevel_at(chassis, Vector3(0.3, 0.36, 0.44),
				Vector3(side * 0.44, 0.98, 0.62), Vector3(14.0, 0.0, 0.0),
				_recess, "thruster_pod")
		MeshUtil.cyl_at(chassis, 0.15, 0.42, Vector3(side * 0.44, 0.74, 0.7),
				Vector3(-20.0, 0.0, 0.0), _joint, "thruster_nozzle")
		var flame := CPUParticles3D.new()
		flame.name = "ThrusterFlame"
		flame.amount = 22
		flame.lifetime = 0.3
		flame.preprocess = 0.3
		flame.direction = Vector3(0.0, -1.0, 0.4)
		flame.spread = 14.0
		flame.gravity = Vector3.ZERO
		flame.initial_velocity_min = 5.5
		flame.initial_velocity_max = 10.0
		flame.scale_amount_min = 0.1
		flame.scale_amount_max = 0.26
		flame.color = Color(1.0, 0.62, 0.25, 0.9)
		var cone := BoxMesh.new()
		cone.size = Vector3.ONE
		var flame_material := MeshUtil.make_material(Color(1.0, 0.7, 0.35), 0.0, 0.9,
				Color(1.0, 0.55, 0.2), 2.6)
		flame_material.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
		flame_material.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
		flame_material.blend_mode = BaseMaterial3D.BLEND_MODE_ADD
		flame_material.vertex_color_use_as_albedo = true
		cone.material = flame_material
		flame.mesh = cone
		flame.emitting = false
		flame.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
		flame.position = Vector3(side * 0.44, 0.52, 0.76)
		chassis.add_child(flame)
		_thruster_flames.append(flame)

func set_thrusters(active: bool) -> void:
	for flame in _thruster_flames:
		flame.emitting = active

func _build_chassis() -> void:
	chassis = Node3D.new()
	chassis.name = "Chassis"
	add_child(chassis)

	MeshUtil.bevel_at(chassis, Vector3(1.15, 0.62, 0.9), Vector3(0.0, -0.05, 0.06),
			Vector3.ZERO, _primary, "pelvis")
	MeshUtil.bevel_at(chassis, Vector3(0.9, 0.5, 0.7), Vector3(0.0, 0.4, 0.05),
			Vector3.ZERO, _secondary, "abdomen")
	MeshUtil.bevel_at(chassis, Vector3(1.6, 0.95, 1.3), Vector3(0.0, 0.92, -0.05),
			Vector3.ZERO, _primary, "chest")
	MeshUtil.bevel_at(chassis, Vector3(1.78, 0.26, 1.12), Vector3(0.0, 1.34, -0.05),
			Vector3(-5.0, 0.0, 0.0), _secondary, "upper_deck")
	MeshUtil.bevel_at(chassis, Vector3(1.2, 0.5, 0.44), Vector3(0.0, 1.06, -0.66),
			Vector3(-24.0, 0.0, 0.0), _accent, "glacis")
	MeshUtil.bevel_at(chassis, Vector3(1.3, 0.34, 0.5), Vector3(0.0, 0.5, -0.6),
			Vector3(-14.0, 0.0, 0.0), _secondary, "chest_chin")
	MeshUtil.bevel_at(chassis, Vector3(0.6, 0.3, 0.4), Vector3(0.0, 1.4, 0.42),
			Vector3.ZERO, _accent, "dorsal_pack")
	MeshUtil.bevel_at(chassis, Vector3(0.8, 0.5, 0.2), Vector3(0.0, 1.0, 0.66),
			Vector3.ZERO, _primary, "backplate")
	for vent_index in 3:
		MeshUtil.bevel_at(chassis, Vector3(0.5, 0.06, 0.08),
				Vector3(0.0, 0.78 + float(vent_index) * 0.16, 0.78),
				Vector3.ZERO, _recess, "back_vent_%d" % vent_index)

	for side in [-1.0, 1.0]:
		MeshUtil.bevel_at(chassis, Vector3(0.2, 0.9, 1.15), Vector3(side * 0.88, 0.88, -0.05),
				Vector3(0.0, 0.0, side * -6.0), _secondary, "chest_side")
		MeshUtil.bevel_at(chassis, Vector3(0.14, 0.5, 0.8), Vector3(side * 0.96, 0.6, -0.1),
				Vector3(0.0, 0.0, side * -6.0), _accent, "chest_accent")
		MeshUtil.bevel_at(chassis, Vector3(0.5, 0.44, 0.6), Vector3(side * 0.94, 1.12, -0.02),
				Vector3.ZERO, _joint, "shoulder_yoke")
		MeshUtil.sph_at(chassis, 0.24, Vector3(side * 1.02, 1.06, 0.0), _joint, "shoulder_ball")
		MeshUtil.bevel_at(chassis, Vector3(0.3, 0.68, 0.34), Vector3(side * 1.04, 0.6, 0.04),
				Vector3(0.0, 0.0, side * -7.0), _secondary, "upper_arm")
		MeshUtil.sph_at(chassis, 0.15, Vector3(side * 1.06, 0.28, 0.05), _joint, "elbow")
		MeshUtil.bevel_at(chassis, Vector3(0.34, 0.56, 0.42), Vector3(side * 1.08, 0.02, 0.12),
				Vector3(6.0, 0.0, side * 4.0), _primary, "forearm")
		MeshUtil.bevel_at(chassis, Vector3(0.36, 0.3, 0.46), Vector3(side * 1.08, -0.22, 0.18),
				Vector3.ZERO, _joint, "fist")
		MeshUtil.bevel_at(chassis, Vector3(0.5, 0.6, 0.66), Vector3(side * 0.62, 0.1, 0.52),
				Vector3.ZERO, _secondary, "rear_flank")
		MeshUtil.cyl_at(chassis, 0.13, 0.7, Vector3(side * 0.4, 1.06, 0.72),
				Vector3(28.0, 0.0, 0.0), _trim, "exhaust")
		MeshUtil.cyl_at(chassis, 0.15, 0.12, Vector3(side * 0.4, 1.34, 0.86),
				Vector3(28.0, 0.0, 0.0), _recess, "exhaust_tip")

	MeshUtil.bevel_at(chassis, Vector3(1.0, 0.36, 1.1), Vector3(0.0, -0.36, 0.06),
			Vector3.ZERO, _secondary, "belly")
	MeshUtil.bevel_at(chassis, Vector3(0.5, 0.3, 0.9), Vector3(0.0, -0.44, -0.1),
			Vector3.ZERO, _primary, "core_block")
	MeshUtil.sph_at(chassis, 0.2, Vector3(0.0, -0.4, -0.44), _sensor, "core_glow")

func _build_head() -> void:
	head_sensor = Node3D.new()
	head_sensor.name = "HeadSensor"
	add_child(head_sensor)
	_head_base = Vector3(0.0, 1.6, -0.52)
	head_sensor.position = _head_base

	MeshUtil.bevel_at(head_sensor, Vector3(0.78, 0.42, 0.62), Vector3.ZERO,
			Vector3.ZERO, _primary, "head_shell")
	MeshUtil.bevel_at(head_sensor, Vector3(0.9, 0.14, 0.5), Vector3(0.0, 0.18, -0.12),
			Vector3(-14.0, 0.0, 0.0), _accent, "head_brow")
	MeshUtil.bevel_at(head_sensor, Vector3(0.6, 0.2, 0.16), Vector3(0.0, -0.02, -0.3),
			Vector3.ZERO, _recess, "visor_recess")
	MeshUtil.bevel_at(head_sensor, Vector3(0.46, 0.07, 0.06), Vector3(0.0, 0.03, -0.36),
			Vector3.ZERO, _sensor, "optic_bar")
	MeshUtil.sph_at(head_sensor, 0.06, Vector3(0.17, 0.03, -0.36), _sensor, "eye_r")
	MeshUtil.sph_at(head_sensor, 0.06, Vector3(-0.17, 0.03, -0.36), _sensor, "eye_l")
	MeshUtil.bevel_at(head_sensor, Vector3(0.56, 0.16, 0.4), Vector3(0.0, -0.24, -0.1),
			Vector3(12.0, 0.0, 0.0), _secondary, "chin")
	for side in [-1.0, 1.0]:
		MeshUtil.bevel_at(head_sensor, Vector3(0.16, 0.3, 0.44), Vector3(side * 0.42, -0.02, -0.04),
				Vector3(0.0, 0.0, side * -10.0), _secondary, "head_cheek")
	MeshUtil.sph_at(head_sensor, 0.1, Vector3(0.0, 0.24, 0.06), _joint, "dome")
	MeshUtil.cyl_at(head_sensor, 0.026, 0.44, Vector3(-0.26, 0.42, 0.08),
			Vector3(8.0, 0.0, 8.0), _trim, "antenna")
	MeshUtil.sph_at(head_sensor, 0.045, Vector3(-0.29, 0.63, 0.05), _sensor, "antenna_tip")

func _build_legs() -> void:
	var hip_pos: Array[Vector3] = [
		Vector3(0.52, -0.1, 0.0), Vector3(-0.52, -0.1, 0.0),
	]
	var hip_out: Array[Vector3] = [
		Vector3.RIGHT, Vector3.LEFT,
	]
	var hip_phase: Array[float] = [0.0, 0.5]
	var hip_name: Array[String] = ["Leg_R", "Leg_L"]
	for index in hip_pos.size():
		var leg := LegUnit.new()
		leg.name = hip_name[index]
		leg.phase_offset = hip_phase[index]
		leg.outward = hip_out[index]
		leg.thigh_length = 1.25
		leg.shin_length = 1.45
		leg.coxa_length = 0.32
		leg.hip_radius = 0.2
		leg.thigh_radius = 0.16
		leg.shin_radius = 0.12
		leg.foot_size = Vector3(0.46, 0.14, 0.6)
		leg.rest_spread = 0.5
		leg.pole_style = 1
		leg.stride_length = 1.4
		leg.step_height = 0.55
		leg.reference_speed = 5.2
		leg.configure(_primary, _joint, _accent, _secondary, _trim, _sensor)
		leg.apply_scale(visual_scale)
		add_child(leg)
		leg.position = hip_pos[index]
		_leg_bases.append(hip_pos[index])
		leg_units.append(leg)

func _build_hardpoints() -> void:
	var socket_pos: Array[Vector3] = [
		Vector3(0.72, 1.44, -0.2), Vector3(-0.72, 1.44, -0.2),
		Vector3(1.1, 0.1, 0.2), Vector3(-1.1, 0.1, 0.2),
	]
	var socket_side: Array[float] = [1.0, -1.0, 1.0, -1.0]
	_create_hardpoints(socket_pos, socket_side)
