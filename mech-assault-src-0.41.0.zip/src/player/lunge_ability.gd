class_name LungeAbility
extends AbilityBase

# RAVAGER secondary: a ram dash (2 charges). Tuned to War Robots' Hook
# (numbers only, original name/visuals): ~1 s dash, conversion window opens
# AND refreshes on activation, ALL incoming damage converts while it lasts,
# the converted flow is halved by the defence core and then drains over 4 s
# (8 x 0.5 s ticks) as repairable (non-grey) damage - WR's DoT conversion
# deals no grey damage, so repair sources heal it straight back.
const ROBOT: StringName = &"RAVAGER"

@export var recharge_time: float = 20.0
@export var dash_duration: float = 1.0
@export var dash_kick: float = 0.4
@export var convert_window: float = 2.5
@export var drain_ticks: int = 8
@export var drain_interval: float = 0.5
@export var convert_ratio: float = 1.0
@export var dot_reduction: float = 0.5

var dash_active: bool = false

var _player: PlayerRobot
var _rig: RobotRig
var _recharge_left: float = -1.0
var _dash_left: float = 0.0
var _convert_left: float = 0.0
var _banked: float = 0.0
var _drain_left: float = 0.0
var _drain_ticks_left: int = 0

func setup(player: PlayerRobot, rig: RobotRig) -> void:
	_player = player
	_rig = rig

func _ready() -> void:
	recharge_time *= float(GameState.combat_stats().get("cooldown", 1.0))
	max_charges = 2
	charges = 2
	dash_speed = 30.0
	Events.secondary_ability_requested.connect(activate)
	_emit_charges()
	_set_phase("READY")

func _physics_process(delta: float) -> void:
	if charges < max_charges:
		if _recharge_left < 0.0:
			_recharge_left = recharge_time
		_recharge_left -= delta
		if _recharge_left <= 0.0:
			charges = mini(charges + 1, max_charges)
			_recharge_left = recharge_time if charges < max_charges else -1.0
			_update_phase()
		_emit_charges()
	if dash_active:
		_dash_left -= delta
		if _dash_left <= 0.0:
			dash_active = false
			_update_phase()
	if _convert_left > 0.0:
		_convert_left -= delta
		if _convert_left <= 0.0:
			_convert_left = 0.0
			_begin_drain()
			_update_phase()
	if _drain_ticks_left > 0:
		_drain_left -= delta
		if _drain_left <= 0.0:
			_drain_left = drain_interval
			_drain_tick()
			if _drain_ticks_left <= 0:
				_update_phase()

func activate() -> void:
	if GameState.selected_robot != ROBOT:
		return
	if dash_active or charges <= 0 or _player == null or not _player._is_alive():
		return
	charges -= 1
	if _recharge_left < 0.0:
		_recharge_left = recharge_time
	dash_active = true
	_dash_left = dash_duration
	# WR Hook refreshes (never extends) the conversion on re-activation.
	_convert_left = convert_window
	_apply_lunge_kick()
	_spawn_lunge_fx()
	if _rig != null:
		_rig.kick_ability(8.0, 0.0, 0.4)
	Events.camera_shake_requested.emit(0.5, 0.3)
	Haptics.pulse(70, 0.8)
	_update_phase()
	_emit_charges()

func conversion_active() -> bool:
	return _convert_left > 0.0

func split_damage(amount: float) -> float:
	var converted := amount * convert_ratio
	_banked += converted * (1.0 - dot_reduction)
	return amount - converted

func is_dash_active() -> bool:
	return dash_active

func is_stealth_active() -> bool:
	return false

func tick_vertical(_delta: float) -> bool:
	return false

func recharge_ratio() -> float:
	if charges >= max_charges:
		return 1.0
	if _recharge_left <= 0.0:
		return 1.0
	return clampf(1.0 - _recharge_left / maxf(recharge_time, 0.01), 0.0, 1.0)

func notify_fired() -> void:
	pass

func force_end() -> void:
	if dash_active:
		dash_active = false
		_dash_left = 0.0
		_convert_left = convert_window
		_update_phase()

func _begin_drain() -> void:
	if _banked <= 0.0 or _drain_ticks_left > 0:
		return
	_drain_ticks_left = drain_ticks
	_drain_left = drain_interval

func _drain_tick() -> void:
	if _player == null or _player.health == null or _player.health.dead:
		_drain_ticks_left = 0
		_banked = 0.0
		return
	if _banked <= 0.0:
		_drain_ticks_left = 0
		return
	var share := _banked / float(_drain_ticks_left)
	_drain_ticks_left -= 1
	_banked = maxf(_banked - share, 0.0)
	var point := _player.global_position + Vector3.UP * 1.2
	var applied := _player.health.apply_damage(share, point, 0.0)
	if applied > 0.0:
		GameState.player_damage_taken += applied
		Events.player_health_changed.emit(
				_player.health.current, _player.health.max_health)

func _apply_lunge_kick() -> void:
	if _player == null:
		return
	var forward := -_player.global_basis.z
	forward.y = 0.0
	if forward.length_squared() < 0.001:
		forward = Vector3.FORWARD
	_player.velocity += forward.normalized() * dash_speed * dash_kick

func _spawn_lunge_fx() -> void:
	if _player == null:
		return
	var flash := OmniLight3D.new()
	flash.name = "LungeFlash"
	flash.light_color = Color(1.0, 0.35, 0.2)
	flash.omni_range = 7.0
	flash.light_energy = 3.0
	flash.position = Vector3(0.0, 0.6, -1.0)
	_player.add_child(flash)
	var tween := create_tween()
	tween.tween_property(flash, "light_energy", 0.0, 0.3)
	tween.tween_callback(flash.queue_free)

func _update_phase() -> void:
	if dash_active:
		_set_phase("DASHING")
	elif _convert_left > 0.0 or _drain_ticks_left > 0:
		_set_phase("DRAIN")
	elif charges < max_charges:
		_set_phase("RECHARGING")
	else:
		_set_phase("READY")

func _set_phase(value: String) -> void:
	if phase_name != value:
		phase_name = value
		Events.secondary_ability_phase_changed.emit(value)

func _emit_charges() -> void:
	Events.secondary_ability_charges_changed.emit(charges, max_charges, recharge_ratio())
