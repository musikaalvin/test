class_name FollowCamera
extends Node3D

const MIN_PITCH := -0.62
const MAX_PITCH := 0.42
const FOLLOW_SMOOTHNESS := 11.0
const AIM_SMOOTHNESS := 14.0
const BASE_FOV := 72.0
const SPEED_FOV_KICK := 8.0
const RECENTER_DELAY := 1.1
const RECENTER_SPEED := 1.9
const DEFAULT_PITCH := -0.16
# GameSession rewrites `height_offset` at runtime (1.15 x chassis scale, or the
# titan's 1.85 x BULK), so the framing lift lives here instead: it is added on
# top of whatever offset the session set, which raises every chassis in frame
# and keeps the tail clear of the top-centre HUD timer.
const FOCUS_LIFT := 0.5

@export var target_path: NodePath
@export var distance: float = 11.0
@export var height_offset: float = 1.15
@export var shoulder_offset: float = 0.0

var target: Node3D
var yaw: float = 0.0
var pitch: float = -0.16
var shake_strength: float = 0.0
var shake_time_left: float = 0.0

var _shake_seed: float = 0.0
var _idle_look: float = 0.0

@onready var _spring: SpringArm3D = $SpringArm3D
@onready var _camera: Camera3D = $SpringArm3D/Camera3D

func _ready() -> void:
	target = get_node_or_null(target_path) as Node3D
	_spring.collision_mask = Layers.WORLD
	_spring.spring_length = distance
	_spring.margin = 0.4
	_camera.fov = BASE_FOV
	_camera.current = true
	Events.camera_shake_requested.connect(_on_shake_requested)
	if target != null:
		yaw = target.global_rotation.y
		global_position = _target_position()

func _process(delta: float) -> void:
	var look := InputRouter.consume_look()
	if look.length_squared() > 0.0:
		_idle_look = 0.0
		yaw = wrapf(yaw - look.x, -PI, PI)
		pitch = clampf(pitch - look.y, MIN_PITCH, MAX_PITCH)
	else:
		_update_recenter(delta)
	_update(delta)

func _update_recenter(delta: float) -> void:
	if target == null:
		return
	_idle_look += delta
	if _idle_look < RECENTER_DELAY:
		return
	var moving := false
	if target is PlayerRobot:
		moving = (target as PlayerRobot).planar_speed > 1.5
	if not moving:
		return
	var weight := clampf(RECENTER_SPEED * delta, 0.0, 1.0)
	yaw = lerp_angle(yaw, target.global_rotation.y, weight)
	pitch = lerpf(pitch, DEFAULT_PITCH, weight * 0.7)

func _physics_process(delta: float) -> void:
	_update(delta)

func _update(delta: float) -> void:
	if target == null:
		return
	rotation.y = lerp_angle(rotation.y, yaw, clampf(delta * AIM_SMOOTHNESS, 0.0, 1.0))
	_spring.rotation.x = lerp_angle(_spring.rotation.x, pitch, clampf(delta * AIM_SMOOTHNESS, 0.0, 1.0))
	global_position = global_position.lerp(_target_position(), clampf(delta * FOLLOW_SMOOTHNESS, 0.0, 1.0))
	var speed_ratio := 0.0
	if target is PlayerRobot:
		speed_ratio = (target as PlayerRobot).speed_ratio
	_camera.fov = lerpf(_camera.fov, BASE_FOV + speed_ratio * SPEED_FOV_KICK, clampf(delta * 4.0, 0.0, 1.0))
	_apply_shake(delta)
	if target is PlayerRobot:
		(target as PlayerRobot).aim_yaw = rotation.y

func _target_position() -> Vector3:
	var focus := target.global_position + Vector3.UP * (height_offset + FOCUS_LIFT)
	var right := Vector3.RIGHT.rotated(Vector3.UP, rotation.y)
	return focus + right * shoulder_offset

func _apply_shake(delta: float) -> void:
	if shake_time_left <= 0.0:
		_camera.h_offset = 0.0
		_camera.v_offset = 0.0
		return
	shake_time_left = maxf(shake_time_left - delta, 0.0)
	_shake_seed += delta * 34.0
	var fade := shake_time_left / maxf(shake_strength, 0.001)
	_camera.h_offset = sin(_shake_seed * 1.7) * shake_strength * fade * 0.12
	_camera.v_offset = cos(_shake_seed * 2.3) * shake_strength * fade * 0.12

func _on_shake_requested(strength: float, duration: float) -> void:
	shake_strength = maxf(strength, shake_strength)
	shake_time_left = maxf(duration, shake_time_left)

func add_yaw(amount: float) -> void:
	yaw = wrapf(yaw + amount, -PI, PI)