class_name PlayerRobot
extends CharacterBody3D

const DRONE_ORBIT := preload("res://src/player/drone_orbit.gd")
const WALK_SPEED := 3.4
const RUN_SPEED := 7.0
const REVERSE_SPEED := 2.3
const STRAFE_SPEED := 2.9
const ACCELERATION := 10.0
const DECELERATION := 13.0
const AIR_ACCELERATION := 2.2
const FLY_LIFT_GAP := 0.75
const TURN_SPEED := 2.7
const GRAVITY_FALL_MULTIPLIER := 1.35
const GROUND_CLEARANCE := 0.1
const PROBE_UP := 1.6
const PROBE_DOWN := 6.0
const LANDING_RESET_TIME := 0.3
const RIG_HEIGHT_RAISE := 0.45
const CLIMB_SPEED := 3.4
const CLIMB_RANGE := 1.5
# Component (weapon) damage: hull hits below the gate also shake guns apart,
# weighted onto the side that got struck.
const COMPONENT_GATE_RATIO := 0.55
const COMPONENT_DESTROY_RATIO := 0.55
const COMPONENT_STRESS_MULT := 3.0

@export var aim_yaw: float = 0.0
@export var head_yaw: float = 0.0
@export var run_threshold: float = 0.72
@export var input_enabled: bool = true

var rig: RobotRig
var weapons: WeaponSystem
var health: Health
var ability: AbilityBase
var ability2: AbilityBase
var heal_fx: HealFxController = null
var _regen_rate: float = 0.0
var _regen_tick: float = 0.0
var speed_ratio: float = 0.0
var planar_speed: float = 0.0
var turn_rate: float = 0.0
var is_running: bool = false
var respawn_point: Vector3 = Vector3.ZERO
var locked_enemy: EnemyRobot = null
var _hazard_acc: float = 0.0
var _hazard_name: String = ""

var _yaw_step: float = 0.0
var _probe_from := PhysicsRayQueryParameters3D.new()
var _probe_result := {}
var _ground_position: Vector3 = Vector3.ZERO
var _ground_found: bool = false
var _airborne_time: float = 0.0
var _feet_initialised: bool = false
var _move_scale: float = 1.0
var _climbing: bool = false
var _mantle_left: float = 0.0
var _wall_normal: Vector3 = Vector3.ZERO
# Climb pose state, driven only by _tick_wall_climb: the rig and legs read it
# every animation frame. The active flag is off outside a climb (or mantle), but
# the last normal is kept so the rig can ease the pose out instead of snapping.
var _wall_climb_active: bool = false
var _wall_climb_normal: Vector3 = Vector3.ZERO
var _wall_contact: Vector3 = Vector3.ZERO
var _climb_ray := PhysicsRayQueryParameters3D.new()
var _rescue_ray := PhysicsRayQueryParameters3D.new()
var _flyer: bool = false
var _hover_rest: float = 0.0
# Per-mount accumulation of component stress; index matches weapons.mounts.
var _mount_stress: Array[float] = []
var _damage_reaction: DamageReactionController = null

@onready var _rig_root: Node3D = $Visuals

func _ready() -> void:
	collision_layer = Layers.PLAYER
	collision_mask = Layers.WORLD | Layers.ENEMY
	add_to_group("player")
	_flyer = bool(GameState.robot_def().get("flyer", false))
	floor_max_angle = deg_to_rad(52.0)
	floor_snap_length = 0.0 if _flyer else 1.1
	floor_stop_on_slope = true
	slide_on_ceiling = true
	rig = _rig_root.get_node_or_null("RobotRig") as RobotRig
	var is_titan := bool(GameState.robot_def().get("is_titan", false))
	# Per-robot chassis scale (hangar + battle): must be set BEFORE the rig is
	# added, because _ready bakes it into the IK lengths and hull sockets.
	var visual_scale := float(GameState.robot_def().get("scale", 1.0))
	if GameState.selected_robot == &"VORTEX":
		if rig != null:
			rig.free()
		rig = VortexRig.new()
		rig.name = "RobotRig"
		rig.visual_scale = visual_scale
		_rig_root.add_child(rig)
	elif GameState.selected_robot == &"RAMPART":
		if rig != null:
			rig.free()
		rig = ZephyrRig.new()
		rig.name = "RobotRig"
		rig.visual_scale = visual_scale
		_rig_root.add_child(rig)
	elif is_titan:
		if rig != null:
			rig.free()
		rig = TitanRig.new()
		rig.name = "RobotRig"
		rig.visual_scale = visual_scale
		_rig_root.add_child(rig)
	if rig != null:
		rig.position.y = RIG_HEIGHT_RAISE * (
				TitanRig.TITAN_SCALE if is_titan else visual_scale)
	Events.weapon_fired.connect(_on_player_weapon_fired)
	var shape_node := get_node_or_null("BodyCollision") as CollisionShape3D
	if shape_node != null:
		var capsule := shape_node.shape as CapsuleShape3D
		if capsule != null:
			if is_titan:
				capsule.radius = 1.85 * TitanRig.BULK
				capsule.height = 4.5 * TitanRig.BULK
			elif not is_equal_approx(visual_scale, 1.0):
				# Scene capsule (1.25 x 3.0) scales with the chassis so the
				# hitbox tracks the bigger/smaller body.
				capsule.radius = 1.25 * visual_scale
				capsule.height = 3.0 * visual_scale
	var drone_id := GameState.drone_for_robot(GameState.selected_robot)
	if not drone_id.is_empty() and GameState.owns_drone(drone_id):
		var orbit := DRONE_ORBIT.new() as Node3D
		orbit.name = "DroneOrbit"
		orbit.position = Vector3(2.6, 2.3, -0.4) * visual_scale
		add_child(orbit)
	var stats: Dictionary = GameState.combat_stats()
	_move_scale = float(GameState.robot_def().get("speed_scale", 1.0)) \
			* float(stats.get("speed", 1.0))
	_regen_rate = float(stats.get("regen", 0.0))
	_probe_from.collision_mask = Layers.WORLD
	_probe_from.collide_with_areas = false
	_probe_from.collide_with_bodies = true
	_probe_from.exclude = [get_rid()]
	_climb_ray.collision_mask = Layers.WORLD
	_climb_ray.collide_with_areas = false
	_climb_ray.collide_with_bodies = true
	_climb_ray.exclude = [get_rid()]
	_rescue_ray.collision_mask = Layers.WORLD
	_rescue_ray.collide_with_areas = false
	_rescue_ray.collide_with_bodies = true
	_rescue_ray.exclude = [get_rid()]
	if rig != null:
		weapons = WeaponSystem.new()
		weapons.name = "WeaponSystem"
		add_child(weapons)
		weapons.bind(rig)
		weapons.builtin_requires_field = bool(GameState.robot_def().get("builtin_gated", false))
		_setup_builtin_weapon()
	health = Health.new()
	health.name = "Health"
	health.max_health = float(GameState.robot_def().get("armor", 200.0)) \
			* GameState.body_mult(GameState.selected_robot) \
			* float(stats.get("hp", 1.0))
	add_child(health)
	health.defense = float(stats.get("defense", 1.0))
	health.died.connect(_on_health_died)
	# Critical-hull presentation (smoke + flames at the capsule's upper half);
	# lives on the player so it tracks the body transform for free.
	_damage_reaction = DamageReactionController.new()
	_damage_reaction.name = "DamageReaction"
	add_child(_damage_reaction)
	_damage_reaction.setup(self, health)
	# Repair presentation (expanding ring, sparkles, flash, cross and the drone
	# repair beam) tracks the hull transform from the same place, and seeds its
	# HP baseline before the emit below so the initial value reads as no change.
	heal_fx = HealFxController.new()
	heal_fx.name = "HealFx"
	add_child(heal_fx)
	heal_fx.setup(self, health)
	Events.player_health_changed.emit(health.current, health.max_health)
	Events.enemy_targeted.connect(_on_enemy_targeted)
	Events.enemy_target_cleared.connect(_on_enemy_target_cleared)
	match GameState.selected_robot:
		GameState.ROBOT_VORTEX:
			ability = JetJump.new()
			ability.name = "JetJump"
		GameState.ROBOT_RAMPART:
			ability = SiroccoAbility.new()
			ability.name = "SiroccoAbility"
		GameState.ROBOT_PRAETOR:
			ability = NullfieldAbility.new()
			ability.name = "NullfieldAbility"
			ability2 = GravThrustAbility.new()
			ability2.name = "GravThrustAbility"
		GameState.ROBOT_CITADEL:
			ability = ChallengeAbility.new()
			ability.name = "ChallengeAbility"
			ability2 = IronveilAbility.new()
			ability2.name = "IronveilAbility"
		GameState.ROBOT_RAVAGER:
			ability = ShroudAbility.new()
			ability.name = "ShroudAbility"
			ability2 = LungeAbility.new()
			ability2.name = "LungeAbility"
		_:
			ability = ShadowDash.new()
			ability.name = "ShadowDash"
	add_child(ability)
	ability.setup(self, rig)
	if ability2 != null:
		add_child(ability2)
		ability2.setup(self, rig)

func _physics_process(delta: float) -> void:
	if _regen_rate > 0.0 and health != null and not health.dead \
			and health.current < health.max_health:
		_regen_tick += delta
		if _regen_tick >= 0.25:
			_regen_tick = 0.0
			health.heal(health.max_health * _regen_rate * 0.25)
			Events.player_health_changed.emit(health.current, health.max_health)
	if health != null and health.dead:
		_update_death(delta)
		return
	_read_input(delta)
	if ability2 != null and ability2.tick_vertical(delta):
		pass
	if ability != null and ability.tick_vertical(delta):
		# an active ability outranks the climb: drop the pose so the legs
		# return to ground while the dash/jump carries the hull
		_set_climb_state(false)
	elif _tick_wall_climb(delta):
		pass
	else:
		_apply_gravity(delta)
	move_and_slide()
	if not _climbing:
		_rescue_from_underground()
	_tick_hazards(delta)
	if global_position.y < -8.0:
		global_position = respawn_point
		velocity = Vector3.ZERO
		_feet_initialised = false
	_update_animation(delta)

# Capsule: radius 1.25, height 3.0, shape offset y = -0.15 => feet 1.65 below origin.
const FEET_DEPTH := 1.65

func _rescue_from_underground() -> void:
	# The valley terrain collides from both sides; if the robot ever ends up
	# below the surface it can stand on the backface forever (no void trigger),
	# which is exactly the "half in both worlds" bug. Probe the column just
	# above the feet: a surface hit there means we are buried -> snap on top.
	_rescue_ray.from = global_position + Vector3(0.0, -1.2, 0.0)
	_rescue_ray.to = global_position + Vector3(0.0, 0.1, 0.0)
	var hit := get_world_3d().direct_space_state.intersect_ray(_rescue_ray)
	if hit.is_empty():
		return
	var surface_y := (hit["position"] as Vector3).y
	global_position.y = surface_y + FEET_DEPTH + 0.06
	velocity.y = maxf(velocity.y, 0.0)
	_feet_initialised = false

func receive_damage(amount: float, point: Vector3,
		hull_fraction: float = Health.HULL_FRACTION) -> void:
	if health == null or health.dead:
		return
	# LUNGE conversion window: every point of raw damage converts (WR Hook) —
	# halved by the defence core, nothing lands at once, and the bank drains
	# over the next seconds as repairable (non-grey) damage.
	var lunge := ability2 as LungeAbility
	if lunge != null and lunge.conversion_active():
		amount = lunge.split_damage(amount)
		hull_fraction = 0.0
	var applied := health.apply_damage(amount, point, hull_fraction)
	if applied > 0.0:
		GameState.player_damage_taken += applied
		Events.player_health_changed.emit(health.current, health.max_health)
		Events.damage_applied.emit(self, applied, point, Vector3.UP)
		Events.camera_shake_requested.emit(0.35, 0.12)
		if not health.dead:
			take_component_damage(applied, point)

# --- component damage (guns shaken off the hull) ---------------------------
# War Robots-style: once the hull sits below the gate, incoming damage is also
# fed into per-mount stress on the side that was struck, and a mount that
# blows its budget comes off with an explosion, debris and a camera shake.
# The last working gun is always spared so a stripped robot can still shoot.

func take_component_damage(amount: float, point: Vector3) -> void:
	if weapons == null or rig == null or amount <= 0.0:
		return
	if health == null or health.dead or health.ratio() > COMPONENT_GATE_RATIO:
		return
	var threshold := health.max_health * COMPONENT_DESTROY_RATIO
	if threshold <= 0.0:
		return
	var weights := _component_weights(point)
	var stressed := -1
	var worst := 0.0
	for index in weights.size():
		if index >= _mount_stress.size():
			_mount_stress.append(0.0)
		if weights[index] <= 0.0:
			continue
		_mount_stress[index] = _mount_stress[index] + amount * weights[index] \
				* COMPONENT_STRESS_MULT
		if _mount_stress[index] >= threshold and _mount_stress[index] > worst:
			worst = _mount_stress[index]
			stressed = index
	if stressed < 0:
		return
	if weapons.functional_weapon_count() <= 1:
		return
	_mount_stress[stressed] = 0.0
	_destroy_mount(stressed)

# Splits the hit across the guns it could plausibly have hit: a flank strike
# only burdens that column, a front/rear strike spreads over every loaded
# mount, and a hit with no meaningful direction (volcano from above) does the
# same. Empty loadout slots and already-blown guns take no stress at all.
func _component_weights(point: Vector3) -> Array[float]:
	var weights: Array[float] = [0.0, 0.0, 0.0, 0.0]
	if weapons == null:
		return weights
	var local := global_transform.basis.inverse() * (point - global_position)
	var planar := Vector2(local.x, local.z)
	var flank := absf(planar.x) >= absf(planar.y) and planar.length() > 0.05
	var hit_side := signf(planar.x)
	var eligible: Array[int] = []
	for index in weights.size():
		if index >= weapons.mounts.size():
			continue
		var mount := weapons.mounts[index]
		if mount == null or mount.data == null or mount.destroyed:
			continue
		if flank and mount.side() * hit_side < 0.0:
			continue
		eligible.append(index)
	if eligible.is_empty():
		for index in weights.size():
			if index >= weapons.mounts.size():
				continue
			var fallback := weapons.mounts[index]
			if fallback != null and fallback.data != null and not fallback.destroyed:
				eligible.append(index)
	if eligible.is_empty():
		return weights
	var share := 1.0 / float(eligible.size())
	for index in eligible:
		weights[index] = share
	return weights

# Detaches one gun: FX at its muzzle, visual subtree hidden, heat/trigger dead
# from here on. Never frees the mount (rig + muzzle arrays keep pointing at it).
func _destroy_mount(index: int) -> void:
	if weapons == null or index < 0 or index >= weapons.mounts.size():
		return
	var mount := weapons.mounts[index]
	if mount == null or mount.destroyed or mount.data == null:
		return
	var point := mount.global_position
	if rig != null and index < rig.muzzle_points.size():
		var marker := rig.muzzle_points[index]
		if marker != null:
			point = marker.global_position
	mount.mark_destroyed()
	var fx := _combat_fx()
	if fx != null:
		fx.spawn_weapon_burst(point, 0.55)
		if rig != null and rig._trim != null:
			fx.spawn_debris(point, Vector3(0.3, 0.26, 0.58), rig._trim)
	Events.camera_shake_requested.emit(0.55, 0.3)

func _combat_fx() -> CombatFx:
	if not is_inside_tree():
		return null
	return get_tree().get_first_node_in_group("combat_fx") as CombatFx

func _on_enemy_targeted(enemy: Node, _ratio: float) -> void:
	locked_enemy = enemy as EnemyRobot

func _on_enemy_target_cleared() -> void:
	locked_enemy = null

func _setup_builtin_weapon() -> void:
	if rig == null or weapons == null:
		return
	if String(GameState.robot_def().get("builtin", "")).is_empty():
		return
	var weapon := WeaponData.builtin_for_robot(GameState.selected_robot)
	if weapon == null:
		return
	GameState.apply_combat_stats(weapon)
	var socket := Node3D.new()
	socket.name = "BuiltinSocket"
	var side := 1.0
	match GameState.selected_robot:
		GameState.ROBOT_SCARAB:
			if rig._stinger == null:
				return
			rig._stinger.add_child(socket)
			socket.position = Vector3(0.0, 0.04, 0.5)
			socket.rotation_degrees.y = -90.0
			side = -1.0
		GameState.ROBOT_VORTEX:
			rig.add_child(socket)
			socket.position = Vector3(0.0, 1.66, 0.15)
			socket.rotation_degrees.y = 90.0
		GameState.ROBOT_RAMPART:
			rig.add_child(socket)
			socket.position = Vector3(0.0, 0.6, -1.05)
			socket.rotation_degrees.y = 90.0
		_:
			rig.add_child(socket)
			socket.position = Vector3(0.0, 2.12, -0.15)
			socket.rotation_degrees.y = 90.0
	var mount := WeaponMount.new()
	mount.name = "BuiltinWeapon"
	socket.add_child(mount)
	var materials := {
		"gold": rig._accent, "dark": rig._primary, "joint": rig._joint,
		"trim": rig._trim, "sensor": rig._sensor,
	}
	mount.setup(4, weapon, side, materials)
	weapons.builtin = mount

func _on_health_died() -> void:
	input_enabled = false
	if weapons != null:
		weapons.enabled = false
	if ability != null:
		ability.force_end()
	if ability2 != null:
		ability2.force_end()
	if rig != null and rig.has_method("play_death"):
		rig.call("play_death")
	velocity = Vector3.ZERO
	GameState.notify_player_died()

func notify_weapon_fired() -> void:
	if ability != null:
		ability.notify_fired()

func _on_player_weapon_fired(mount_index: int, _kind: int,
		_family: StringName, _size: int) -> void:
	# The drone companion reports mount_index -1; only real chassis guns kick
	# the hull recoil.
	if mount_index < 0 or rig == null:
		return
	rig.kick_fire()

func is_stealthed() -> bool:
	return ability != null and ability.is_stealth_active()

# True while the hull sits in the critical band and is smoking/burning (the
# HUD's CRITICAL chip and the damage-reaction controller track the same state).
func is_critical() -> bool:
	return _damage_reaction != null and _damage_reaction.is_critical()

func _is_alive() -> bool:
	return health == null or not health.dead

func _update_death(delta: float) -> void:
	rotation.x = lerpf(rotation.x, -0.5, clampf(delta * 2.0, 0.0, 1.0))
	velocity.x = move_toward(velocity.x, 0.0, 40.0 * delta)
	velocity.z = move_toward(velocity.z, 0.0, 40.0 * delta)

func _dash_active() -> bool:
	if ability != null and ability.is_dash_active():
		return true
	return ability2 != null and ability2.is_dash_active()

func _dash_speed() -> float:
	if ability != null and ability.is_dash_active():
		return ability.dash_speed
	if ability2 != null and ability2.is_dash_active():
		return ability2.dash_speed
	return 0.0

func _read_input(delta: float) -> void:
	var wish := InputRouter.move_vector if input_enabled else Vector2.ZERO
	var camera_basis := Basis(Vector3.UP, aim_yaw)
	var forward_speed := WALK_SPEED * _move_scale
	is_running = wish.length() > run_threshold
	var dashing := _dash_active()
	if dashing and wish.length_squared() < 0.01:
		wish = Vector2(0.0, 1.0)
		is_running = true
	if dashing:
		forward_speed = _dash_speed()
		is_running = true
	elif is_running:
		forward_speed = RUN_SPEED * _move_scale
	elif wish.y < -0.05:
		forward_speed = REVERSE_SPEED * _move_scale

	var target := (camera_basis * Vector3.FORWARD) * (wish.y * forward_speed) \
			+ (camera_basis * Vector3.RIGHT) * (wish.x * STRAFE_SPEED * _move_scale)
	target.y = 0.0

	var rate := ACCELERATION if target.length_squared() > 0.0001 else DECELERATION
	if dashing:
		rate = 60.0
	if not is_on_floor() and not _flyer:
		rate = AIR_ACCELERATION
	var planar := Vector3(velocity.x, 0.0, velocity.z).move_toward(target, rate * delta)
	if not (_climbing or _mantle_left > 0.0):
		velocity.x = planar.x
		velocity.z = planar.z
		planar_speed = planar.length()
		speed_ratio = clampf(planar_speed / (RUN_SPEED * _move_scale), 0.0, 1.2)

	var previous_yaw := rotation.y
	rotation.y = previous_yaw + clampf(angle_difference(previous_yaw, aim_yaw), -TURN_SPEED * delta, TURN_SPEED * delta)
	turn_rate = wrapf(rotation.y - previous_yaw, -PI, PI) / maxf(delta, 0.0001)

	var body_forward := Basis(Vector3.UP, rotation.y) * Vector3.FORWARD
	var camera_forward := Basis(Vector3.UP, aim_yaw) * Vector3.FORWARD
	head_yaw = clampf(_signed_angle_y(body_forward, camera_forward), -0.65, 0.65)

func _apply_gravity(delta: float) -> void:
	if not is_on_floor():
		var gravity: float = ProjectSettings.get_setting("physics/3d/default_gravity", 22.0)
		var multiplier := GRAVITY_FALL_MULTIPLIER if velocity.y < 0.0 else 1.0
		velocity.y -= gravity * multiplier * delta
	elif velocity.y < 0.0:
		velocity.y = 0.0

func _tick_hover(delta: float) -> void:
	var query := PhysicsRayQueryParameters3D.create(
			global_position, global_position + Vector3.DOWN * 24.0, Layers.WORLD)
	query.exclude = [get_rid()]
	var hit := get_world_3d().direct_space_state.intersect_ray(query)
	if hit.is_empty():
		velocity.y -= 22.0 * delta
		return
	var floor_y := (hit["position"] as Vector3).y
	if is_on_floor() and _hover_rest <= 0.0:
		_hover_rest = maxf(global_position.y - floor_y, 0.4)
	var rest := _hover_rest if _hover_rest > 0.0 else 0.9
	var target := floor_y + rest + FLY_LIFT_GAP
	var zone := HazardZones.zone_at(global_position)
	if not zone.is_empty():
		target = maxf(target, float(zone["level"]) + 1.4)
	velocity.y = clampf((target - global_position.y) * 5.0, -9.0, 5.0)

func _tick_hazards(delta: float) -> void:
	var zone := HazardZones.zone_at(global_position)
	if zone.is_empty():
		_hazard_acc = 0.0
		if not _hazard_name.is_empty():
			_hazard_name = ""
			Events.hazard_changed.emit(_hazard_name)
		return
	var level := float(zone["level"])
	var floating := _dash_active()
	if floating:
		# Omen-Fang dash skims across water and magma instead of sinking
		if global_position.y < level + 0.35:
			global_position.y = level + 0.35
			velocity.y = maxf(velocity.y, 0.0)
		_hazard_acc = 0.0
	else:
		var depth := level - global_position.y
		if depth > 0.5:
			velocity.x = move_toward(velocity.x, 0.0, 5.0 * delta)
			velocity.z = move_toward(velocity.z, 0.0, 5.0 * delta)
		if depth > 0.9:
			velocity.y = maxf(velocity.y, 4.0)
		if health != null and not health.dead:
			var dps := float(zone["dps"])
			# RAVAGER's hull eats a quarter less hazard burn.
			dps *= float(GameState.robot_def().get("dot_taken", 1.0))
			_hazard_acc += dps * health.max_health * delta
			if _hazard_acc >= 1.0:
				var tick := _hazard_acc
				_hazard_acc = 0.0
				health.apply_damage(tick, global_position)
				Events.player_health_changed.emit(health.current, health.max_health)
				Events.damage_applied.emit(self, tick, global_position, Vector3.UP)
	var label := String(zone["kind"]).to_upper()
	if label != _hazard_name:
		_hazard_name = label
		Events.hazard_changed.emit(label)

func _can_climb() -> bool:
	return input_enabled and _is_alive() \
			and bool(GameState.robot_def().get("wall_climb", false))

func _tick_wall_climb(delta: float) -> bool:
	if not _can_climb():
		_climbing = false
		_mantle_left = 0.0
		_set_climb_state(false)
		return false

	var wish := InputRouter.move_vector if input_enabled else Vector2.ZERO
	var camera_basis := Basis(Vector3.UP, aim_yaw)
	var dir := (camera_basis * Vector3.FORWARD) * wish.y \
			+ (camera_basis * Vector3.RIGHT) * wish.x
	dir.y = 0.0
	var wish_dir := dir.normalized() if dir.length() > 0.05 else Vector3.ZERO

	if _mantle_left > 0.0:
		# cresting the lip: the rig eases the climb pose out over 0.4 s
		_mantle_left -= delta
		_set_climb_state(false)
		var crest_forward := -global_basis.z
		crest_forward.y = 0.0
		crest_forward = crest_forward.normalized() * 2.5
		velocity = crest_forward + Vector3.UP * 6.5
		planar_speed = 3.0
		speed_ratio = 0.4
		return true

	var probe_dir := wish_dir
	if probe_dir.length_squared() < 0.001:
		probe_dir = -_wall_normal if _wall_normal.length_squared() > 0.001 \
				else -global_basis.z
	probe_dir.y = 0.0
	probe_dir = probe_dir.normalized()
	var from := global_position + Vector3.UP * 0.9
	_climb_ray.from = from
	_climb_ray.to = from + probe_dir * CLIMB_RANGE
	var hit: Dictionary = get_world_3d().direct_space_state.intersect_ray(_climb_ray)
	if hit.is_empty():
		if _climbing:
			_climbing = false
			_mantle_left = 0.5
			_set_climb_state(false)
			Events.camera_shake_requested.emit(0.2, 0.15)
			return true
		return false
	var normal: Vector3 = hit["normal"]
	normal.y = 0.0
	if normal.length_squared() < 0.0001:
		if _climbing:
			_climbing = false
			_set_climb_state(false)
		return false
	normal = normal.normalized()
	if absf((hit["normal"] as Vector3).y) >= 0.45:
		if _climbing:
			_climbing = false
			_set_climb_state(false)
		return false

	var into := wish_dir.dot(-normal) if wish_dir.length_squared() > 0.001 else 0.0
	if _climbing and into < -0.15:
		_climbing = false
		_set_climb_state(false)
		velocity = wish_dir * 5.0 + Vector3.UP * 1.5
		return false
	if not _climbing:
		if into < 0.35:
			return false
		_climbing = true

	_wall_normal = normal
	aim_yaw = atan2(normal.x, normal.z)
	var right := Vector3.UP.cross(normal)
	var up := wish.y * CLIMB_SPEED
	var side := wish.x * CLIMB_SPEED * 0.75
	velocity = -normal * 1.6 + Vector3.UP * up + right * side
	planar_speed = 1.0 + absf(wish.y) * CLIMB_SPEED * 0.6 + absf(wish.x) * 2.4
	speed_ratio = clampf(planar_speed / (RUN_SPEED * _move_scale), 0.0, 1.2)
	var contact: Vector3 = hit["position"]
	_set_climb_state(true, normal, contact)
	return true

# Publishes the climb pose to the rig and legs. Clearing keeps the last normal
# so the rig can ease the pose out over its blend time instead of snapping.
func _set_climb_state(active: bool, normal: Vector3 = Vector3.ZERO,
		contact: Vector3 = Vector3.ZERO) -> void:
	_wall_climb_active = active
	if active:
		if normal.length_squared() > 0.0001:
			_wall_climb_normal = normal
		_wall_contact = contact

func _update_animation(delta: float) -> void:
	if rig == null:
		return
	if not _feet_initialised:
		_feet_initialised = true
		rig.reset_feet(_probe_feet())
	var grounded := is_on_floor()
	var forward := -global_basis.z
	var up := global_basis.y
	var climb_pose := _wall_climb_active and rig.leg_units.size() == 4

	for leg in rig.leg_units:
		var hip_world := leg.global_position
		var rest := _rest_foot(hip_world, leg)
		if grounded and _probe_ground(hip_world + Vector3.UP * PROBE_UP) \
				and absf(rest.y - (_ground_position.y + GROUND_CLEARANCE)) < 1.7:
			rest.y = _ground_position.y + GROUND_CLEARANCE
		leg.set_climb_mode(climb_pose, _wall_climb_normal, _wall_contact, rest)
		var leg_velocity := velocity if grounded else Vector3.ZERO
		leg.update_gait(hip_world, rest, leg_velocity, forward, up, delta, turn_rate,
				global_position)

	if not grounded:
		_airborne_time += delta
	elif _airborne_time > LANDING_RESET_TIME:
		rig.reset_feet(_probe_feet())
		_airborne_time = 0.0

	rig.set_wall_climb(climb_pose, _wall_climb_normal)
	rig.update_animation(delta, velocity, turn_rate, grounded, aim_yaw, head_yaw)
	if weapons != null and health != null and not health.dead:
		rig.set_reloading(weapons.reload_ratio() > 0.0)

func _rest_foot(hip_world: Vector3, leg: LegUnit) -> Vector3:
	var reach := leg.thigh_length + leg.shin_length
	var forward := -global_basis.z
	var lateral := global_basis * leg.outward
	lateral = lateral - forward * lateral.dot(forward)
	if lateral.length_squared() < 0.0001:
		lateral = global_basis.x
	lateral = lateral.normalized()
	return hip_world + lateral * (leg.coxa_length + reach * 0.55) * leg.rest_spread \
			+ Vector3.DOWN * reach * 0.92

func _probe_feet() -> Array[Vector3]:
	var points: Array[Vector3] = []
	for leg in rig.leg_units:
		var hip := leg.global_position
		var rest := _rest_foot(hip, leg)
		if _probe_ground(hip + Vector3.UP * PROBE_UP):
			points.append(Vector3(rest.x, _ground_position.y + GROUND_CLEARANCE, rest.z))
		else:
			points.append(hip + Vector3.DOWN * 1.6)
	return points

func _probe_ground(from: Vector3) -> bool:
	_probe_from.from = from
	_probe_from.to = from + Vector3.DOWN * PROBE_DOWN
	_probe_result = get_world_3d().direct_space_state.intersect_ray(_probe_from)
	_ground_found = not _probe_result.is_empty()
	if _ground_found:
		_ground_position = _probe_result["position"]
	return _ground_found

func _signed_angle_y(from: Vector3, to: Vector3) -> float:
	return atan2(from.cross(to).y, from.dot(to))

func eye_position() -> Vector3:
	return global_position + global_basis.y * 0.4

func forward_direction() -> Vector3:
	return -global_basis.z

func set_aim_yaw(yaw: float) -> void:
	aim_yaw = yaw