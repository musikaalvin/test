class_name ZephyrRig
extends RobotRig

const ZEPHYR_GLB := "res://assets/mech/zephyr.glb"
const WING_ROOTS: Array[Vector3] = [
	Vector3(0.78, 1.12, -0.28), Vector3(-0.78, 1.12, -0.28),
	Vector3(0.72, 1.10, 0.52), Vector3(-0.72, 1.10, 0.52),
]

var wings: Array[Node3D] = []
var _thruster_flames: Array[CPUParticles3D] = []
var _wing_phase: float = 0.0

func glb_path() -> String:
	return ZEPHYR_GLB

func _glb_target(part_name: String) -> Node3D:
	if part_name.begins_with("wing") and part_name.length() > 5:
		var digit := part_name.substr(4, 1)
		if digit.is_valid_int():
			var wing_index := digit.to_int()
			if wing_index >= 0 and wing_index < wings.size():
				return wings[wing_index]
	return super._glb_target(part_name)

func _ready() -> void:
	move_pitch_gain = 0.008
	turn_roll_gain = 0.085
	strafe_roll_gain = 0.05
	bob_freq_base = 3.0
	bob_freq_speed = 12.0
	hover_bob_amp = 0.05
	fire_pitch_kick = -0.02
	fire_bob_kick = -0.015
	fire_roll_kick = 0.05
	fire_kick_decay = 8.0
	reload_pitch = -0.03
	reload_crouch = -0.02
	reload_brace_hardpoint = 0.06
	_make_materials()
	_build_chassis()
	_build_head()
	_build_hardpoints()
	_build_thrusters()
	_attach_heromech()

func _build_chassis() -> void:
	chassis = Node3D.new()
	chassis.name = "Chassis"
	add_child(chassis)
	for index in WING_ROOTS.size():
		var wing := Node3D.new()
		wing.name = "Wing_%d" % index
		wing.position = WING_ROOTS[index]
		add_child(wing)
		wings.append(wing)

func _build_head() -> void:
	head_sensor = Node3D.new()
	head_sensor.name = "HeadSensor"
	add_child(head_sensor)
	_head_base = Vector3(0.0, 1.0, -1.12)
	head_sensor.position = _head_base

func _build_hardpoints() -> void:
	var socket_pos: Array[Vector3] = [
		Vector3(0.9, 1.3, -0.35), Vector3(-0.9, 1.3, -0.35),
		Vector3(0.0, 1.9, -0.5),
	]
	var socket_side: Array[float] = [1.0, -1.0, 1.0]
	_create_hardpoints(socket_pos, socket_side)

func _build_thrusters() -> void:
	for x in [0.34, -0.34]:
		for z in [0.42, -0.45]:
			var flame := CPUParticles3D.new()
			flame.name = "LiftFlame"
			flame.amount = 20
			flame.lifetime = 0.3
			flame.preprocess = 0.3
			flame.direction = Vector3(0.0, -1.0, 0.0)
			flame.spread = 10.0
			flame.gravity = Vector3.ZERO
			flame.initial_velocity_min = 5.0
			flame.initial_velocity_max = 9.0
			flame.scale_amount_min = 0.08
			flame.scale_amount_max = 0.2
			flame.color = Color(0.4, 0.9, 1.0, 0.9)
			var puff := BoxMesh.new()
			puff.size = Vector3.ONE
			var flame_material := MeshUtil.make_material(Color(0.5, 0.92, 1.0), 0.0, 0.9,
					Color(0.35, 0.85, 1.0), 2.4)
			flame_material.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
			flame_material.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
			flame_material.blend_mode = BaseMaterial3D.BLEND_MODE_ADD
			flame_material.vertex_color_use_as_albedo = true
			puff.material = flame_material
			flame.mesh = puff
			flame.emitting = false
			flame.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
			flame.position = Vector3(x, 0.3, z)
			chassis.add_child(flame)
			_thruster_flames.append(flame)

func set_thrusters(active: bool) -> void:
	for flame in _thruster_flames:
		flame.emitting = active

func update_animation(delta: float, velocity: Vector3, turn_rate: float, grounded: bool,
		aim_yaw: float, head_yaw: float) -> void:
	super.update_animation(delta, velocity, turn_rate, grounded, aim_yaw, head_yaw)
	_wing_phase += delta * (16.0 + velocity.length() * 2.4 + _fire_kick * 6.0)
	for index in wings.size():
		var root := WING_ROOTS[index]
		var side := 1.0 if root.x >= 0.0 else -1.0
		var lift := 5.0 + _fire_kick * 1.5 if grounded else 8.5 + _fire_kick * 2.0
		var flap := sin(_wing_phase + float(index % 2) * 1.9 + float(index / 2) * 0.4)
		var wing := wings[index] as Node3D
		wing.rotation_degrees.z = flap * lift * side
