class_name AegisShield
extends AbilityBase

const ROBOT: StringName = &"RAMPART"

@export var duration: float = 4.0
@export var recharge_time: float = 9.0
@export var shield_reduction: float = 0.15

var shield_active: bool = false

var _player: PlayerRobot
var _rig: RobotRig
var _active_left: float = 0.0
var _recharge_left: float = -1.0
var _bubble: MeshInstance3D
var _pulse: Tween

func setup(player: PlayerRobot, rig: RobotRig) -> void:
	_player = player
	_rig = rig

func _ready() -> void:
	recharge_time *= float(GameState.combat_stats().get("cooldown", 1.0))
	max_charges = 1
	charges = 1
	dash_speed = 0.0
	Events.ability_requested.connect(activate)
	_emit_charges()
	_set_phase("READY")

func _physics_process(delta: float) -> void:
	if _recharge_left > 0.0:
		_recharge_left -= delta
		if _recharge_left <= 0.0:
			charges = 1
			_recharge_left = -1.0
			_set_phase("READY")
		_emit_charges()
	if shield_active:
		_active_left -= delta
		if _active_left <= 0.0:
			_end_shield()

func activate() -> void:
	if GameState.selected_robot != ROBOT:
		return
	if shield_active:
		_end_shield()
		return
	if charges <= 0 or _player == null or not _player._is_alive():
		return
	charges = 0
	_recharge_left = recharge_time
	shield_active = true
	_active_left = duration
	if _player.health != null:
		_player.health.shield_mult = shield_reduction
	_show_bubble(true)
	Events.camera_shake_requested.emit(0.3, 0.2)
	_set_phase("SHIELD")
	_emit_charges()

func is_dash_active() -> bool:
	return false

func is_stealth_active() -> bool:
	return false

func recharge_ratio() -> float:
	if _recharge_left <= 0.0:
		return 1.0
	return clampf(1.0 - _recharge_left / maxf(recharge_time, 0.01), 0.0, 1.0)

func notify_fired() -> void:
	pass

func force_end() -> void:
	if shield_active:
		_end_shield()

func _end_shield() -> void:
	shield_active = false
	_active_left = 0.0
	if _player != null and _player.health != null:
		_player.health.shield_mult = 1.0
	_show_bubble(false)
	if _recharge_left > 0.0:
		_set_phase("RECHARGING")
	else:
		_set_phase("READY")

func _show_bubble(active: bool) -> void:
	if active:
		_ensure_bubble()
		if _bubble == null:
			return
		_bubble.visible = true
		_bubble.scale = Vector3.ONE * 0.35
		if _pulse != null and _pulse.is_valid():
			_pulse.kill()
		_pulse = create_tween()
		_pulse.set_loops()
		_pulse.tween_property(_bubble, "scale", Vector3.ONE * 1.0, 0.18) \
				.set_trans(Tween.TRANS_BACK).set_ease(Tween.EASE_OUT)
		_pulse.parallel().tween_property(_bubble, "transparency", 0.0, 0.18)
		_pulse.tween_property(_bubble, "transparency", 0.24, 0.5)
		_pulse.tween_property(_bubble, "transparency", 0.08, 0.5)
	elif _bubble != null:
		if _pulse != null and _pulse.is_valid():
			_pulse.kill()
		_pulse = create_tween()
		_pulse.tween_property(_bubble, "scale", Vector3.ONE * 1.25, 0.25)
		_pulse.parallel().tween_property(_bubble, "transparency", 1.0, 0.25)
		_pulse.tween_callback(_hide_bubble)

func _hide_bubble() -> void:
	if _bubble != null:
		_bubble.visible = false

func _ensure_bubble() -> void:
	if _bubble != null or _player == null:
		return
	_bubble = MeshInstance3D.new()
	_bubble.name = "AegisBubble"
	var sphere := SphereMesh.new()
	sphere.radius = 2.7
	sphere.height = 5.4
	sphere.radial_segments = 24
	sphere.rings = 12
	var material := StandardMaterial3D.new()
	material.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
	material.albedo_color = Color(0.35, 0.85, 1.0, 0.12)
	material.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
	material.blend_mode = BaseMaterial3D.BLEND_MODE_ADD
	material.cull_mode = BaseMaterial3D.CULL_DISABLED
	material.emission_enabled = true
	material.emission = Color(0.3, 0.8, 1.0)
	material.emission_energy_multiplier = 1.6
	sphere.material = material
	_bubble.mesh = sphere
	_bubble.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	_bubble.position = Vector3(0.0, 1.9, 0.0)
	_bubble.visible = false
	_player.add_child(_bubble)

func _set_phase(value: String) -> void:
	if phase_name != value:
		phase_name = value
		Events.ability_phase_changed.emit(value)

func _emit_charges() -> void:
	Events.ability_charges_changed.emit(charges, max_charges, recharge_ratio())
