class_name ChallengeAbility
extends AbilityBase

# CITADEL primary: paint one hostile with a challenge mark - it drops all
# caution and hunts you relentlessly (stealth and broken LOS no longer make
# it fall back to SEARCH) while every hit it takes is amplified. Firing on
# nothing leaves the charge loaded.
const ROBOT: StringName = &"CITADEL"

@export var recharge_time: float = 13.0
@export var scan_range: float = 400.0
@export var mark_duration: float = 9.0
@export var mark_mult: float = 1.2
@export var taunt_duration: float = 9.0

var _player: PlayerRobot
var _rig: RobotRig
var _recharge_left: float = -1.0
var _flash_left: float = 0.0

func setup(player: PlayerRobot, rig: RobotRig) -> void:
	_player = player
	_rig = rig

func _ready() -> void:
	recharge_time *= float(GameState.combat_stats().get("cooldown", 1.0))
	max_charges = 1
	charges = 1
	dash_speed = 0.0
	Events.ability_requested.connect(activate)
	_emit_charges()
	_set_phase("READY")

func _physics_process(delta: float) -> void:
	if _flash_left > 0.0:
		_flash_left -= delta
		if _flash_left <= 0.0 and charges < max_charges:
			_set_phase("RECHARGING")
	if charges < max_charges:
		if _recharge_left < 0.0:
			_recharge_left = recharge_time
		_recharge_left -= delta
		if _recharge_left <= 0.0:
			charges = mini(charges + 1, max_charges)
			_recharge_left = recharge_time if charges < max_charges else -1.0
			_set_phase("READY")
		_emit_charges()

func activate() -> void:
	if GameState.selected_robot != ROBOT:
		return
	if charges <= 0 or _player == null or not _player._is_alive():
		return
	var mark := _pick_target()
	if mark == null:
		return
	charges = 0
	_recharge_left = recharge_time
	mark.apply_death_mark(mark_duration, mark_mult)
	mark.apply_taunt(taunt_duration, _player)
	_spawn_challenge_fx(mark)
	if _rig != null:
		_rig.kick_ability(-5.0, 0.0, 0.5)
	Events.camera_shake_requested.emit(0.4, 0.25)
	Haptics.pulse(80, 0.7)
	_flash_left = 1.5
	_set_phase("CHALLENGE")
	_emit_charges()

func _pick_target() -> EnemyRobot:
	if _player == null:
		return null
	var locked := _player.locked_enemy
	if _enemy_in_range(locked):
		return locked
	var best: EnemyRobot = null
	var best_distance := scan_range
	for entry in get_tree().get_nodes_in_group("enemy"):
		var enemy := entry as EnemyRobot
		if enemy == null or not _enemy_in_range(enemy):
			continue
		var distance := enemy.global_position.distance_to(_player.global_position)
		if distance < best_distance:
			best_distance = distance
			best = enemy
	return best

func _enemy_in_range(enemy: EnemyRobot) -> bool:
	if enemy == null or not is_instance_valid(enemy):
		return false
	if enemy.state == EnemyRobot.State.DEAD:
		return false
	if enemy.health == null or enemy.health.dead:
		return false
	if _player == null:
		return false
	return enemy.global_position.distance_to(_player.global_position) <= scan_range

func _spawn_challenge_fx(marked: EnemyRobot) -> void:
	if not is_instance_valid(marked):
		return
	var flash := OmniLight3D.new()
	flash.name = "ChallengeFlash"
	flash.light_color = Color(1.0, 0.62, 0.2)
	flash.omni_range = 8.0
	flash.light_energy = 3.5
	flash.position = marked.global_position + Vector3.UP * 1.6
	marked.get_parent().add_child(flash)
	var tween := create_tween()
	tween.tween_property(flash, "light_energy", 0.0, 0.4)
	tween.tween_callback(flash.queue_free)

func is_dash_active() -> bool:
	return false

func is_stealth_active() -> bool:
	return false

func recharge_ratio() -> float:
	if charges >= max_charges:
		return 1.0
	if _recharge_left <= 0.0:
		return 1.0
	return clampf(1.0 - _recharge_left / maxf(recharge_time, 0.01), 0.0, 1.0)

func notify_fired() -> void:
	pass

func force_end() -> void:
	pass

func _set_phase(value: String) -> void:
	if phase_name != value:
		phase_name = value
		Events.ability_phase_changed.emit(value)

func _emit_charges() -> void:
	Events.ability_charges_changed.emit(charges, max_charges, recharge_ratio())
