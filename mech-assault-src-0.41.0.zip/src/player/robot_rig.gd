class_name RobotRig
extends Node3D

const HULL_LENGTH := 3.1
const HULL_WIDTH := 2.3
const HERO_GLB := "res://assets/mech/hero_mech.glb"

# Scorpion wall-climb pose. Inert unless PlayerRobot arms it every frame, so
# the hangar preview (update_animation with zero motion) never climbs.
const CLIMB_LEAN_DEG := 32.0
const CLIMB_ROLL_DEG := 12.0
const CLIMB_HEAD_UP_DEG := 26.0
const CLIMB_TAIL_LIFT_DEG := 30.0
const CLIMB_BLEND_TIME := 0.4
const CLIMB_DIAGONAL_PHASES: Array[float] = [0.0, 0.5, 0.5, 0.0]

@export var tail_sway_scale: float = 1.0
@export var bob_scale: float = 1.0
@export var idle_bob_height: float = 0.05
@export var walk_bob_height: float = 0.075

# Per-chassis motion personality (transform-only, read every animation frame).
# SCARAB defaults live here; each rig override tunes its own stance in _ready().
var move_pitch_gain: float = 0.012
var turn_roll_gain: float = 0.05
var strafe_roll_gain: float = 0.03
var bob_freq_base: float = 2.2
var bob_freq_speed: float = 9.0
var hover_bob_amp: float = 0.0
var fire_pitch_kick: float = -0.05
var fire_bob_kick: float = -0.03
var fire_roll_kick: float = 0.02
var fire_kick_decay: float = 4.5
var reload_pitch: float = -0.05
var reload_crouch: float = -0.04
var reload_brace_hardpoint: float = 0.08

# Per-part follow polish (transform-only): the sensor head and the tail trail
# the hull on their own rates, so pitch/bob/roll read as separate parts instead
# of one welded block. accel_pitch_gain drives the brake/accelerate weight shift.
var head_follow_pitch: float = 0.55
var head_counter_roll: float = -0.4
var head_lag_rate: float = 8.5
var tail_lag_rate: float = 4.2
var accel_pitch_gain: float = 0.004
var accel_pitch_rate: float = 7.0

var climb_active: bool = false

# Ability activation telegraph (additive, transform-only). kick_ability() arms
# a hull slam in degrees; update_animation decays it next to _fire_kick and
# eases it out over its own duration. Both defaults stay 0.0 so every existing
# pose - fire kick, reload brace, climb lean - is bit-identical when idle.
var ability_jolt_pitch: float = 0.0
var ability_jolt_roll: float = 0.0
var _ability_jolt_left: float = 0.0
var _ability_jolt_total: float = 0.5

# Fire recoil + magazine-reload pose state.
var _fire_kick: float = 0.0
var _reload_pose: float = 0.0
var _reload_target: float = 0.0
var _accel_pitch: float = 0.0
var _prev_speed: float = 0.0
var _head_pitch: float = 0.0
var _head_roll: float = 0.0
var _tail_pitch: float = 0.0
var _tail_roll: float = 0.0
var _climb_normal: Vector3 = Vector3.ZERO
var _climb_blend: float = 0.0
var _climb_head_up: float = 0.0

var chassis: Node3D
var head_sensor: Node3D
var tail: Node3D
var leg_units: Array[LegUnit] = []
var hardpoints: Array[Node3D] = []
var mounts: Array[WeaponMount] = []
var mount_pivots: Array[Node3D] = []
var muzzle_points: Array[Marker3D] = []

# Uniform visual scale for this chassis. Set it BEFORE the rig enters the
# tree: _build_legs bakes it into the IK length constants (LegUnit.apply_scale)
# while the node scale carries the hull, tail and weapon sockets, so the legs
# and the body stay matched. After _ready it is too late to change.
var visual_scale: float = 1.0:
	set(value):
		visual_scale = value
		scale = Vector3(value, value, value)

var _tail_segments: Array[Node3D] = []
var _tail_rest_x: Array[float] = []
var _tail_phase: float = 0.0
var _bob_phase: float = 0.0
var _pitch: float = 0.0
var _roll: float = 0.0
var _stinger: Node3D = null

var _chassis_base: Vector3 = Vector3.ZERO
var _head_base: Vector3 = Vector3.ZERO
var _tail_base: Vector3 = Vector3.ZERO
var _leg_bases: Array[Vector3] = []
var _socket_bases: Array[Vector3] = []
var _socket_yaw_deg: Array[float] = []

var _primary: StandardMaterial3D
var _secondary: StandardMaterial3D
var _accent: StandardMaterial3D
var _joint: StandardMaterial3D
var _trim: StandardMaterial3D
var _sensor: StandardMaterial3D
var _recess: StandardMaterial3D

func _ready() -> void:
	_make_materials()
	_build_chassis()
	_build_carapace_detail()
	_build_head()
	_build_tail()
	_build_legs()
	_build_hardpoints()
	_attach_heromech()

func glb_path() -> String:
	return HERO_GLB

func _make_materials() -> void:
	var palette := GameState.palette_colors(GameState.palette_for(GameState.selected_robot))
	_primary = MeshUtil.make_material(palette[0], 0.15, 0.55)
	_secondary = MeshUtil.make_material(palette[1], 0.2, 0.62)
	_accent = MeshUtil.make_material(palette[2], 0.25, 0.45)
	_joint = MeshUtil.make_material(Color(0.06, 0.062, 0.07), 0.0, 0.85)
	_trim = MeshUtil.make_material(Color(0.42, 0.45, 0.5), 0.95, 0.35)
	_sensor = MeshUtil.make_material(Color(0.1, 0.85, 1.0), 0.2, 0.15, Color(0.15, 0.9, 1.0), 3.6)
	_recess = MeshUtil.make_material(Color(0.05, 0.055, 0.07), 0.5, 0.8)
	PanelTextures.apply(_primary, &"armor", 1.4)
	PanelTextures.apply(_secondary, &"armor", 1.4)
	PanelTextures.apply(_accent, &"armor", 1.8)
	PanelTextures.apply(_trim, &"steel", 1.6)
	PanelTextures.apply(_joint, &"rubber", 3.0)

func _build_chassis() -> void:
	chassis = Node3D.new()
	chassis.name = "Chassis"
	add_child(chassis)

	var hull := MeshUtil.make_cylinder(1.0, 2.3, _primary, 6, "core_hull")
	chassis.add_child(hull)
	hull.position = Vector3(0.0, 0.05, 0.0)
	hull.rotation_degrees = Vector3(90.0, 0.0, 0.0)
	hull.scale = Vector3(1.16, 1.0, 0.56)

	MeshUtil.bevel_at(chassis, Vector3(1.9, 0.16, 1.0), Vector3(0.0, 0.44, -0.85),
			Vector3(-22.0, 0.0, 0.0), _secondary, "FrontArmor")
	MeshUtil.bevel_at(chassis, Vector3(1.5, 0.5, 0.6), Vector3(0.0, 0.16, -1.18),
			Vector3(-8.0, 0.0, 0.0), _primary, "nose_block")
	MeshUtil.bevel_at(chassis, Vector3(1.1, 0.22, 0.3), Vector3(0.0, 0.4, -1.42),
			Vector3(-14.0, 0.0, 0.0), _accent, "brow_trim")
	MeshUtil.bevel_at(chassis, Vector3(1.55, 0.18, 1.5), Vector3(0.0, 0.6, 0.0),
			Vector3(-4.0, 0.0, 0.0), _secondary, "UpperArmor")
	MeshUtil.bevel_at(chassis, Vector3(1.2, 0.1, 1.2), Vector3(0.0, 0.68, -0.1),
			Vector3(-4.0, 0.0, 0.0), _primary, "upper_deck_inset")
	MeshUtil.bevel_at(chassis, Vector3(0.5, 0.24, 0.5), Vector3(0.0, 0.74, 0.42),
			Vector3(-6.0, 0.0, 0.0), _accent, "dorsal_0")
	MeshUtil.bevel_at(chassis, Vector3(0.46, 0.2, 0.44), Vector3(0.0, 0.7, 0.85),
			Vector3(-8.0, 0.0, 0.0), _primary, "dorsal_1")
	MeshUtil.bevel_at(chassis, Vector3(0.4, 0.18, 0.4), Vector3(0.0, 0.63, 1.2),
			Vector3(-10.0, 0.0, 0.0), _accent, "dorsal_2")

	for side in [-1.0, 1.0]:
		MeshUtil.bevel_at(chassis, Vector3(0.16, 0.86, 2.05), Vector3(side * 1.1, 0.0, -0.05),
				Vector3(0.0, 0.0, side * -9.0), _primary,
				"SideArmor_R" if side > 0.0 else "SideArmor_L")
		MeshUtil.bevel_at(chassis, Vector3(0.1, 0.5, 1.15), Vector3(side * 1.2, -0.04, -0.1),
				Vector3(0.0, 0.0, side * -9.0), _accent, "side_accent")
		MeshUtil.bevel_at(chassis, Vector3(0.06, 0.3, 0.7), Vector3(side * 1.26, 0.1, 0.75),
				Vector3(0.0, 0.0, side * -9.0), _recess, "side_vent")
		MeshUtil.bevel_at(chassis, Vector3(0.3, 0.1, 1.9), Vector3(side * 1.0, 0.62, -0.05),
				Vector3(0.0, 0.0, side * -36.0), _secondary, "chamfer")
		MeshUtil.bevel_at(chassis, Vector3(0.5, 0.66, 0.9), Vector3(side * 1.26, -0.2, -1.0),
				Vector3(0.0, 0.0, side * -6.0), _secondary, "sponson_f")
		MeshUtil.bevel_at(chassis, Vector3(0.5, 0.66, 0.9), Vector3(side * 1.28, -0.2, 1.02),
				Vector3(0.0, 0.0, side * -6.0), _secondary, "sponson_r")
		MeshUtil.bevel_at(chassis, Vector3(0.44, 0.34, 0.5), Vector3(side * 1.06, 0.3, -0.72),
				Vector3.ZERO, _joint, "pedestal_f")
		MeshUtil.bevel_at(chassis, Vector3(0.44, 0.34, 0.5), Vector3(side * 1.14, 0.34, 0.62),
				Vector3.ZERO, _joint, "pedestal_r")
		MeshUtil.bevel_at(chassis, Vector3(0.5, 0.42, 0.66), Vector3(side * 0.86, 0.16, -1.05),
				Vector3(0.0, side * -12.0, side * -8.0), _primary, "cheek")
		MeshUtil.bevel_at(chassis, Vector3(0.4, 0.4, 0.72), Vector3(side * 0.6, -0.1, -1.4),
				Vector3(6.0, side * -14.0, side * 10.0), _accent, "mandible")
		MeshUtil.cyl_at(chassis, 0.15, 0.8, Vector3(side * 0.55, 0.5, 1.2),
				Vector3(35.0, 0.0, 0.0), _trim, "exhaust")
		MeshUtil.cyl_at(chassis, 0.17, 0.14, Vector3(side * 0.55, 0.82, 1.44),
				Vector3(35.0, 0.0, 0.0), _recess, "exhaust_tip")

	MeshUtil.bevel_at(chassis, Vector3(1.7, 0.8, 0.8), Vector3(0.0, 0.1, 1.1),
			Vector3.ZERO, _primary, "RearArmor")
	MeshUtil.bevel_at(chassis, Vector3(1.4, 0.5, 0.16), Vector3(0.0, 0.06, 1.5),
			Vector3.ZERO, _secondary, "engine_rear")
	for vent_index in 4:
		MeshUtil.bevel_at(chassis, Vector3(1.1, 0.07, 0.08),
				Vector3(0.0, -0.1 + float(vent_index) * 0.16, 1.58),
				Vector3.ZERO, _recess, "vent_%d" % vent_index)
	MeshUtil.cyl_at(chassis, 0.34, 2.0, Vector3(0.0, -0.5, 0.1),
			Vector3(90.0, 0.0, 0.0), _joint, "belly_keel")
	MeshUtil.bevel_at(chassis, Vector3(0.9, 0.2, 1.4), Vector3(0.0, -0.44, 0.1),
			Vector3.ZERO, _primary, "MechanicalCore")

func _build_carapace_detail() -> void:
	var dome := MeshUtil.sph_at(chassis, 0.95, Vector3(0.0, 0.5, 0.05), _primary, "carapace_dome")
	dome.scale = Vector3(1.24, 0.52, 1.55)
	MeshUtil.cyl_at(chassis, 0.26, 0.1, Vector3(0.0, 0.05, -1.47),
			Vector3(-90.0, 0.0, 0.0), _recess, "core_bezel")
	var core := MeshUtil.make_cylinder(0.16, 0.14, _sensor, 6, "chest_core")
	chassis.add_child(core)
	core.position = Vector3(0.0, 0.05, -1.53)
	core.rotation_degrees = Vector3(-90.0, 0.0, 0.0)
	MeshUtil.cyl_at(chassis, 0.42, 0.3, Vector3(0.0, 0.55, 1.36),
			Vector3(90.0, 0.0, 0.0), _joint, "tail_collar")
	for side in [-1.0, 1.0]:
		var hip_dome := MeshUtil.sph_at(chassis, 0.36, Vector3(side * 1.3, 0.16, 0.1),
				_primary, "hip_dome")
		hip_dome.scale = Vector3(0.7, 0.85, 1.15)
		MeshUtil.cyl_at(chassis, 0.09, 0.08, Vector3(side * 1.56, 0.18, -0.05),
				Vector3(0.0, 0.0, side * -90.0), _sensor, "hip_hex")
		for stroke in 2:
			MeshUtil.bevel_at(chassis, Vector3(0.05, 0.05, 0.3),
					Vector3(side * 1.5, -0.14, -1.02 + float(stroke) * 0.17),
					Vector3(30.0 if stroke == 0 else -30.0, 0.0, 0.0),
					_accent, "sponson_chevron")
		MeshUtil.cyl_at(chassis, 0.1, 0.06, Vector3(side * 0.55, 0.87, 1.47),
				Vector3(35.0, 0.0, 0.0), _sensor, "exhaust_glow")
		MeshUtil.cone_at(chassis, 0.07, 0.006, 0.44,
				Vector3(side * 0.48, -0.3, -1.48),
				Vector3(-150.0, 0.0, side * 8.0), _trim, "fang_tusk")

func _build_head() -> void:
	head_sensor = Node3D.new()
	head_sensor.name = "HeadSensor"
	add_child(head_sensor)
	_head_base = Vector3(0.0, 0.3, -1.5)
	head_sensor.position = _head_base

	MeshUtil.bevel_at(head_sensor, Vector3(0.92, 0.46, 0.64), Vector3.ZERO,
			Vector3.ZERO, _primary, "head_shell")
	MeshUtil.bevel_at(head_sensor, Vector3(1.02, 0.16, 0.52), Vector3(0.0, 0.2, -0.14),
			Vector3(-16.0, 0.0, 0.0), _accent, "head_brow")
	MeshUtil.bevel_at(head_sensor, Vector3(0.7, 0.24, 0.16), Vector3(0.0, -0.01, -0.32),
			Vector3.ZERO, _recess, "visor_recess")
	MeshUtil.bevel_at(head_sensor, Vector3(0.5, 0.08, 0.06), Vector3(0.0, 0.03, -0.38),
			Vector3.ZERO, _sensor, "optic_bar")
	MeshUtil.sph_at(head_sensor, 0.07, Vector3(0.2, 0.03, -0.38), _sensor, "eye_r")
	MeshUtil.sph_at(head_sensor, 0.07, Vector3(-0.2, 0.03, -0.38), _sensor, "eye_l")
	MeshUtil.bevel_at(head_sensor, Vector3(0.62, 0.18, 0.44), Vector3(0.0, -0.26, -0.12),
			Vector3(14.0, 0.0, 0.0), _secondary, "chin")
	for side in [-1.0, 1.0]:
		MeshUtil.bevel_at(head_sensor, Vector3(0.2, 0.34, 0.5), Vector3(side * 0.47, -0.02, -0.06),
				Vector3(0.0, 0.0, side * -12.0), _secondary, "head_cheek")
		MeshUtil.cyl_at(head_sensor, 0.1, 0.3, Vector3(side * 0.5, 0.14, 0.06),
				Vector3(0.0, 0.0, -90.0), _trim, "head_pod")
	MeshUtil.sph_at(head_sensor, 0.12, Vector3(0.0, 0.26, 0.08), _joint, "dome")
	MeshUtil.cyl_at(head_sensor, 0.03, 0.5, Vector3(0.3, 0.46, 0.1),
			Vector3(8.0, 0.0, -10.0), _trim, "antenna")
	MeshUtil.sph_at(head_sensor, 0.05, Vector3(0.34, 0.7, 0.06), _sensor, "antenna_tip")
	for side in [-1.0, 1.0]:
		MeshUtil.cone_at(head_sensor, 0.06, 0.005, 0.32,
				Vector3(side * 0.38, 0.2, 0.05),
				Vector3(58.0, 0.0, side * -32.0), _accent, "head_horn")
		MeshUtil.sph_at(head_sensor, 0.05, Vector3(side * 0.3, -0.1, -0.3), _sensor, "head_glow")

func _build_tail() -> void:
	tail = Node3D.new()
	tail.name = "Tail"
	add_child(tail)
	_tail_base = Vector3(0.0, 0.52, 1.42)
	tail.position = _tail_base

	var lengths: Array[float] = [0.78, 0.68, 0.58, 0.5]
	var radii: Array[float] = [0.34, 0.28, 0.22, 0.17]
	var rest_x: Array[float] = [-18.0, -24.0, -26.0, -26.0]
	var parent: Node3D = tail
	for index in lengths.size():
		var joint := Node3D.new()
		joint.name = "TailJoint%d" % index
		joint.position = Vector3.ZERO if index == 0 else Vector3(0.0, 0.0, lengths[index - 1])
		joint.rotation_degrees.x = rest_x[index]
		parent.add_child(joint)
		_tail_segments.append(joint)
		_tail_rest_x.append(rest_x[index])
		MeshUtil.cyl_at(joint, radii[index], lengths[index] * 0.94,
				Vector3(0.0, 0.0, lengths[index] * 0.5), Vector3(90.0, 0.0, 0.0),
				_primary if index % 2 == 0 else _secondary, "tail_shell_%d" % index)
		MeshUtil.sph_at(joint, radii[index] * 1.1, Vector3.ZERO, _joint, "tail_joint_%d" % index)
		MeshUtil.bevel_at(joint, Vector3(radii[index] * 1.9, 0.18, lengths[index] * 0.75),
				Vector3(0.0, radii[index] * 0.95, lengths[index] * 0.5), Vector3.ZERO,
				_accent if index % 2 == 0 else _primary, "tail_armor_%d" % index)
		MeshUtil.bevel_at(joint, Vector3(radii[index] * 1.55, 0.14, lengths[index] * 0.6),
				Vector3(0.0, -radii[index] * 0.9, lengths[index] * 0.5), Vector3.ZERO,
				_secondary, "tail_under_%d" % index)
		for side in [-1.0, 1.0]:
			MeshUtil.bevel_at(joint, Vector3(0.07, radii[index] * 1.1, lengths[index] * 0.55),
					Vector3(side * radii[index] * 1.0, 0.0, lengths[index] * 0.5),
					Vector3.ZERO, _trim, "tail_rib")
		parent = joint

	var stinger_mount := Node3D.new()
	stinger_mount.name = "Stinger"
	stinger_mount.position = Vector3(0.0, 0.0, lengths[-1])
	stinger_mount.rotation_degrees.x = 30.0
	_tail_segments[-1].add_child(stinger_mount)
	_stinger = stinger_mount
	MeshUtil.sph_at(stinger_mount, 0.2, Vector3(0.0, 0.0, 0.08), _joint, "stinger_bulb")
	MeshUtil.bevel_at(stinger_mount, Vector3(0.3, 0.2, 0.3), Vector3(0.0, 0.1, 0.1),
			Vector3.ZERO, _accent, "stinger_collar")
	MeshUtil.cone_at(stinger_mount, 0.2, 0.02, 1.0, Vector3(0.0, 0.0, 0.62),
			Vector3(90.0, 0.0, 0.0), _trim, "stinger_spine")
	MeshUtil.sph_at(stinger_mount, 0.06, Vector3(0.0, 0.0, 1.12), _sensor, "stinger_tip")

func _build_legs() -> void:
	var hip_pos: Array[Vector3] = [
		Vector3(1.22, -0.3, -1.05), Vector3(-1.22, -0.3, -1.05),
		Vector3(1.26, -0.3, 1.02), Vector3(-1.26, -0.3, 1.02),
	]
	var hip_out: Array[Vector3] = [
		Vector3(0.88, 0.0, -0.3), Vector3(-0.88, 0.0, -0.3),
		Vector3(0.9, 0.0, 0.32), Vector3(-0.9, 0.0, 0.32),
	]
	var hip_phase: Array[float] = [0.0, 0.5, 0.25, 0.75]
	var hip_name: Array[String] = ["Leg_FR", "Leg_FL", "Leg_RR", "Leg_RL"]
	for index in hip_pos.size():
		var leg := LegUnit.new()
		leg.name = hip_name[index]
		leg.phase_offset = hip_phase[index]
		leg.outward = hip_out[index]
		# climb gait pairs the diagonals: FR+RL together, FL+RR together
		if index < CLIMB_DIAGONAL_PHASES.size():
			leg.climb_phase = CLIMB_DIAGONAL_PHASES[index]
		leg.configure(_primary, _joint, _accent, _secondary, _trim, _sensor)
		leg.apply_scale(visual_scale)
		add_child(leg)
		leg.position = hip_pos[index]
		_leg_bases.append(hip_pos[index])
		leg_units.append(leg)

func _build_hardpoints() -> void:
	# Rear pair sits on the upper hull: at the old y (0.54) it was perfectly
	# coaxial with the front pair, so head-on views showed 2 guns instead of 4.
	var socket_pos: Array[Vector3] = [
		Vector3(1.06, 0.5, -0.72), Vector3(-1.06, 0.5, -0.72),
		Vector3(1.14, 1.2, 0.62), Vector3(-1.14, 1.2, 0.62),
	]
	var socket_side: Array[float] = [1.0, -1.0, 1.0, -1.0]
	_create_hardpoints(socket_pos, socket_side)

func _create_hardpoints(socket_pos: Array[Vector3], socket_side: Array[float]) -> void:
	for index in socket_pos.size():
		var side: float = socket_side[index]
		var socket := Node3D.new()
		socket.name = "WeaponHardpoint_%02d" % (index + 1)
		socket.position = socket_pos[index]
		socket.rotation_degrees.y = side * 90.0
		add_child(socket)
		var mount := WeaponMount.new()
		mount.name = "Weapon_%02d" % (index + 1)
		var materials := {
			"gold": _accent, "dark": _primary, "joint": _joint, "trim": _trim,
			"sensor": _sensor,
		}
		socket.add_child(mount)
		var item_id := GameState.equipped_item(GameState.selected_robot, index)
		var weapon: WeaponData = WeaponData.for_item(item_id) if not item_id.is_empty() else null
		if weapon != null:
			GameState.apply_weapon_upgrades(weapon, GameState.selected_robot, index)
		mount.setup(index, weapon, side, materials)
		mounts.append(mount)
		hardpoints.append(socket)
		mount_pivots.append(socket)
		muzzle_points.append(mount.muzzle)
		_socket_bases.append(socket_pos[index])
		_socket_yaw_deg.append(side * 90.0)

func _attach_heromech() -> void:
	var packed := load(glb_path()) as PackedScene
	if packed == null:
		return
	var legacy: Array[Node] = find_children("*", "MeshInstance3D", true, false)
	var shell := packed.instantiate() as Node3D
	if shell == null:
		return
	add_child(shell)
	var materials := {
		"m_primary": _primary, "m_secondary": _secondary, "m_accent": _accent,
		"m_joint": _joint, "m_trim": _trim, "m_recess": _recess, "m_sensor": _sensor,
	}
	var attached := 0
	for child in shell.get_children():
		var part_name := String(child.name)
		if part_name.begins_with("gun"):
			continue
		var target := _glb_target(part_name)
		if target == null:
			continue
		child.reparent(target, false)
		attached += 1
		if child is MeshInstance3D:
			_apply_glb_materials(child as MeshInstance3D, materials)
		else:
			for sub in child.find_children("*", "MeshInstance3D", true, false):
				if sub is MeshInstance3D:
					_apply_glb_materials(sub as MeshInstance3D, materials)
	if attached == 0:
		shell.queue_free()
		return
	for node in legacy:
		if node.name == "muzzle_flash" or _is_mount_owned(node):
			continue
		node.queue_free()
	shell.queue_free()

func _is_mount_owned(node: Node) -> bool:
	var current: Node = node.get_parent()
	while current != null and current != self:
		if current is WeaponMount:
			return true
		current = current.get_parent()
	return false

func _glb_target(part_name: String) -> Node3D:
	if part_name.begins_with("chassis__"):
		return chassis
	if part_name.begins_with("head__"):
		return head_sensor
	if part_name.begins_with("stinger__"):
		return _stinger
	if part_name.begins_with("tail") and part_name.length() > 5:
		var digit := part_name.substr(4, 1)
		if digit.is_valid_int():
			var tail_index := digit.to_int()
			if tail_index >= 0 and tail_index < _tail_segments.size():
				return _tail_segments[tail_index]
	if part_name.begins_with("gun") and part_name.length() > 4:
		var digit := part_name.substr(3, 1)
		if digit.is_valid_int():
			var gun_index := digit.to_int()
			if gun_index >= 0 and gun_index < mounts.size():
				return mounts[gun_index]
	if part_name.begins_with("l") and part_name.length() > 4:
		var leg_digit := part_name.substr(1, 1)
		var role := part_name.substr(2, 1)
		if leg_digit.is_valid_int():
			var leg_index := leg_digit.to_int()
			if leg_index >= 0 and leg_index < leg_units.size():
				var leg := leg_units[leg_index]
				match role:
					"c":
						return leg.get_node_or_null("CoxaBone") as Node3D
					"u":
						return leg.get_node_or_null("UpperBone") as Node3D
					"l":
						return leg.get_node_or_null("LowerBone") as Node3D
					"f":
						return leg.get_node_or_null("Foot") as Node3D
	return null

func _apply_glb_materials(mesh: MeshInstance3D, materials: Dictionary) -> void:
	for surface in mesh.get_surface_override_material_count():
		var source := mesh.get_active_material(surface)
		if source == null:
			continue
		var mapped: Variant = materials.get(source.resource_name)
		if mapped is StandardMaterial3D:
			mesh.set_surface_override_material(surface, mapped as StandardMaterial3D)

func set_stealth(active: bool) -> void:
	var mats: Array[StandardMaterial3D] = [
		_primary, _secondary, _accent, _joint, _trim, _recess, _sensor,
	]
	if active:
		for mat in mats:
			if mat.transparency == BaseMaterial3D.TRANSPARENCY_DISABLED:
				mat.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
			var color := mat.albedo_color
			color.a = 0.32
			mat.albedo_color = color
			if mat.emission_enabled:
				mat.emission_energy_multiplier = maxf(mat.emission_energy_multiplier, 3.2)
	else:
		for mat in mats:
			var color := mat.albedo_color
			color.a = 1.0
			mat.albedo_color = color
			mat.transparency = BaseMaterial3D.TRANSPARENCY_DISABLED
		_primary.emission_energy_multiplier = 0.0
		_sensor.emission_energy_multiplier = 3.2

func muzzle_world_position(index: int) -> Vector3:
	if index < 0 or index >= muzzle_points.size():
		return global_position
	return muzzle_points[index].global_position

func hardpoint_count() -> int:
	return mounts.size()

func reset_feet(ground_points: Array[Vector3]) -> void:
	for index in leg_units.size():
		if index < ground_points.size():
			leg_units[index].reset_gait(ground_points[index])
		else:
			leg_units[index].reset_gait(leg_units[index].global_position)

func kick_fire(amount: float = 1.0) -> void:
	_fire_kick = minf(_fire_kick + amount, 3.0)

# Ability telegraph: snap the hull into a pose (pitch/roll in DEGREES) that
# eases back out over `duration` seconds. Clamped so a bad call can never
# throw the hull past a readable slam.
func kick_ability(pitch_deg: float, roll_deg: float = 0.0,
		duration: float = 0.5) -> void:
	ability_jolt_pitch = clampf(pitch_deg, -45.0, 45.0)
	ability_jolt_roll = clampf(roll_deg, -30.0, 30.0)
	_ability_jolt_total = maxf(duration, 0.05)
	_ability_jolt_left = _ability_jolt_total

func set_reloading(active: bool) -> void:
	_reload_target = 1.0 if active else 0.0

# Arms the scorpion climb pose. The rig keeps the last normal while it eases
# out, so a mantle (active false) blends over CLIMB_BLEND_TIME with no snap.
func set_wall_climb(active: bool, normal: Vector3 = Vector3.ZERO) -> void:
	climb_active = active
	if active and normal.length_squared() > 0.0001:
		_climb_normal = normal.normalized()

func update_animation(delta: float, velocity: Vector3, turn_rate: float, grounded: bool,
		aim_yaw: float, head_yaw: float) -> void:
	var planar := Vector3(velocity.x, 0.0, velocity.z)
	var speed := planar.length()
	var speed_ratio := clampf(speed / 7.0, 0.0, 1.4)
	var target_pitch := clampf(velocity.dot(global_basis.z) * move_pitch_gain, -0.09, 0.09)
	var strafe := planar.dot(global_basis.x)
	var target_roll := clampf(turn_rate * turn_roll_gain - strafe * strafe_roll_gain,
			-0.14, 0.14)
	# Weight transfer: the hull dips winding up and lifts braking (velocity vs facing).
	var accel := (speed - _prev_speed) / maxf(delta, 0.0001)
	_prev_speed = speed
	_accel_pitch = lerpf(_accel_pitch,
			clampf(-accel * accel_pitch_gain, -0.035, 0.035),
			clampf(delta * accel_pitch_rate, 0.0, 1.0))
	_fire_kick = maxf(_fire_kick - fire_kick_decay * delta, 0.0)
	_ability_jolt_left = maxf(_ability_jolt_left - delta, 0.0)
	_reload_pose = lerpf(_reload_pose, _reload_target,
			clampf(delta * 5.0, 0.0, 1.0))
	var kick := _fire_kick
	target_pitch += kick * fire_pitch_kick + _reload_pose * reload_pitch + _accel_pitch
	target_roll += kick * fire_roll_kick
	# Ability telegraph: an additive slam whose ease runs 1 -> 0 over the jolt
	# duration with TRANS_CUBIC / EASE_OUT. Zero when no ability is playing.
	var jolt_ease := 0.0
	if _ability_jolt_left > 0.0:
		var jolt_progress := clampf(
				1.0 - _ability_jolt_left / maxf(_ability_jolt_total, 0.01), 0.0, 1.0)
		jolt_ease = pow(1.0 - jolt_progress, 3.0)
	target_pitch += deg_to_rad(ability_jolt_pitch * jolt_ease)
	target_roll += deg_to_rad(ability_jolt_roll * jolt_ease)
	_pitch = lerpf(_pitch, target_pitch if grounded else 0.0, clampf(delta * 6.0, 0.0, 1.0))
	_roll = lerpf(_roll, target_roll if grounded else 0.0, clampf(delta * 6.0, 0.0, 1.0))

	# --- scorpion climb pose (0 unless armed; hangs in the air on mantle) ---
	_climb_blend = move_toward(_climb_blend, 1.0 if climb_active else 0.0,
			delta / maxf(CLIMB_BLEND_TIME, 0.01))
	var climb_pitch := 0.0
	var climb_roll := 0.0
	_climb_head_up = 0.0
	if _climb_blend > 0.0 and _climb_normal.length_squared() > 0.0001:
		# wall normal expressed in rig space: z = square-on to the wall, x = lean
		var rig_normal := (global_basis.inverse() * _climb_normal).normalized()
		var face := clampf(rig_normal.z, 0.0, 1.0)
		climb_pitch = -deg_to_rad(CLIMB_LEAN_DEG) * face * _climb_blend
		climb_roll = deg_to_rad(CLIMB_ROLL_DEG) * clampf(rig_normal.x, -1.0, 1.0) \
				* _climb_blend
		_climb_head_up = deg_to_rad(CLIMB_HEAD_UP_DEG) * face * _climb_blend
	var hull_pitch := _pitch + climb_pitch
	var hull_roll := _roll + climb_roll

	_bob_phase += delta * (bob_freq_base + speed_ratio * bob_freq_speed)
	var bob_amplitude := (walk_bob_height * speed_ratio + idle_bob_height) * bob_scale
	var bob := sin(_bob_phase) * bob_amplitude * (0.25 + speed_ratio)
	if not grounded:
		bob = sin(_bob_phase) * hover_bob_amp * (0.35 + speed_ratio)
	bob += kick * fire_bob_kick + _reload_pose * reload_crouch
	var offset := Vector3(0.0, bob, 0.0)
	var lean := Vector3(hull_pitch, 0.0, hull_roll)

	chassis.position = _chassis_base + offset
	chassis.rotation = lean
	# Sensor head trails the hull on its own rate and counter-rolls like a gimbal.
	var head_ease := clampf(delta * head_lag_rate, 0.0, 1.0)
	_head_pitch = lerpf(_head_pitch, hull_pitch * head_follow_pitch, head_ease)
	_head_roll = lerpf(_head_roll, hull_roll * head_counter_roll, head_ease)
	head_sensor.position = _head_base + offset
	head_sensor.rotation = Vector3(_head_pitch + _climb_head_up,
			clampf(head_yaw, -0.65, 0.65), _head_roll)
	if tail != null:
		# Tail whips behind the hull on a slower rate, plus the climb lift.
		var tail_ease := clampf(delta * tail_lag_rate, 0.0, 1.0)
		_tail_pitch = lerpf(_tail_pitch, hull_pitch, tail_ease)
		_tail_roll = lerpf(_tail_roll, hull_roll, tail_ease)
		tail.position = _tail_base + offset
		tail.rotation = Vector3(_tail_pitch, 0.0, _tail_roll)
	for index in leg_units.size():
		leg_units[index].position = _leg_bases[index] + offset

	var converge := clampf(aim_yaw * 0.45, -0.35, 0.35)
	for index in hardpoints.size():
		var side: float = 1.0 if index % 2 == 0 else -1.0
		hardpoints[index].position = _socket_bases[index] + offset
		hardpoints[index].rotation = Vector3(
				hull_pitch - 0.06 - speed_ratio * 0.03 + _reload_pose * reload_brace_hardpoint,
				deg_to_rad(_socket_yaw_deg[index]) + converge * side,
				hull_roll)

	_update_tail(delta, speed_ratio, turn_rate, aim_yaw)

func _update_tail(delta: float, speed_ratio: float, turn_rate: float, aim_yaw: float) -> void:
	if _tail_segments.is_empty():
		return
	_tail_phase += delta * (1.1 + speed_ratio * 2.4)
	for index in _tail_segments.size():
		var weight := 1.0 - float(index) / float(maxi(_tail_segments.size(), 1))
		var lag := float(index) * 0.55
		var sway := sin(_tail_phase - lag) * 0.09 * weight * tail_sway_scale
		var turn_bias := clampf(-turn_rate * 0.16, -0.4, 0.4) * weight * tail_sway_scale
		var aim_bias := clampf(aim_yaw * 0.1, -0.2, 0.2) * weight
		var lift := -speed_ratio * 6.0 * weight
		# climb: the tail rides up as a counterweight while the hull leans in
		lift += -CLIMB_TAIL_LIFT_DEG * weight * _climb_blend
		_tail_segments[index].rotation_degrees = Vector3(
				_tail_rest_x[index] + lift,
				rad_to_deg(sway + turn_bias + aim_bias),
				0.0)
