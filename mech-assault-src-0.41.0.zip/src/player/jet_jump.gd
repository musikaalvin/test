class_name JetJump
extends AbilityBase

const ROBOT: StringName = &"VORTEX"

@export var rise_time: float = 0.95
@export var rise_accel: float = 46.0
@export var rise_speed: float = 13.0
@export var glide_time: float = 1.65
@export var recharge_time: float = 7.0

var thrusting: bool = false

var _player: PlayerRobot
var _rig: RobotRig
var _rise_left: float = 0.0
var _glide_left: float = 0.0
var _recharge_left: float = -1.0

func setup(player: PlayerRobot, rig: RobotRig) -> void:
	_player = player
	_rig = rig

func _ready() -> void:
	recharge_time *= float(GameState.combat_stats().get("cooldown", 1.0))
	max_charges = 1
	charges = 1
	dash_speed = 9.0
	Events.ability_requested.connect(activate)
	_emit_charges()
	_set_phase("READY")

func _physics_process(delta: float) -> void:
	if _recharge_left > 0.0:
		_recharge_left -= delta
		if _recharge_left <= 0.0:
			charges = 1
			_recharge_left = -1.0
			_set_phase("READY")
		_emit_charges()
	if thrusting:
		if _rise_left > 0.0:
			_rise_left -= delta
		else:
			_glide_left -= delta
			if _glide_left <= 0.0:
				_finish()

func activate() -> void:
	if GameState.selected_robot != ROBOT:
		return
	if thrusting or charges <= 0 or _player == null or not _player._is_alive():
		return
	charges = 0
	_recharge_left = recharge_time
	thrusting = true
	_rise_left = rise_time
	_glide_left = glide_time
	_player.velocity.y = maxf(_player.velocity.y, 4.0)
	_set_thrusters(true)
	_spawn_launch_fx()
	Events.camera_shake_requested.emit(0.4, 0.3)
	_set_phase("JETPACK")
	_emit_charges()

func tick_vertical(delta: float) -> bool:
	if not thrusting or _player == null:
		return false
	if _rise_left > 0.0:
		_player.velocity.y = minf(_player.velocity.y + rise_accel * delta, rise_speed)
	else:
		_player.velocity.y = move_toward(_player.velocity.y, 1.4, 9.0 * delta)
	return true

func is_dash_active() -> bool:
	return thrusting

func is_stealth_active() -> bool:
	return false

func recharge_ratio() -> float:
	if _recharge_left <= 0.0:
		return 1.0
	return clampf(1.0 - _recharge_left / maxf(recharge_time, 0.01), 0.0, 1.0)

func notify_fired() -> void:
	pass

func force_end() -> void:
	if thrusting:
		_finish()

func _finish() -> void:
	thrusting = false
	_rise_left = 0.0
	_glide_left = 0.0
	_set_thrusters(false)
	if _recharge_left > 0.0:
		_set_phase("RECHARGING")
	else:
		_set_phase("READY")

func _set_thrusters(active: bool) -> void:
	if _rig != null and _rig.has_method("set_thrusters"):
		_rig.call("set_thrusters", active)

func _set_phase(value: String) -> void:
	if phase_name != value:
		phase_name = value
		Events.ability_phase_changed.emit(value)

func _emit_charges() -> void:
	Events.ability_charges_changed.emit(charges, max_charges, recharge_ratio())

func _spawn_launch_fx() -> void:
	if _player == null:
		return
	var flash := OmniLight3D.new()
	flash.name = "JetFlash"
	flash.light_color = Color(1.0, 0.7, 0.35)
	flash.omni_range = 8.0
	flash.light_energy = 3.5
	flash.position = Vector3(0.0, 0.8, 0.4)
	_player.add_child(flash)
	var tween := create_tween()
	tween.tween_property(flash, "light_energy", 0.0, 0.35)
	tween.tween_callback(flash.queue_free)
	var dust := CPUParticles3D.new()
	dust.name = "JetDust"
	dust.one_shot = true
	dust.amount = 18
	dust.lifetime = 0.7
	dust.explosiveness = 1.0
	dust.direction = Vector3.UP
	dust.spread = 35.0
	dust.gravity = Vector3.ZERO
	dust.initial_velocity_min = 4.0
	dust.initial_velocity_max = 9.0
	dust.scale_amount_min = 0.08
	dust.scale_amount_max = 0.2
	dust.color = Color(0.85, 0.7, 0.5, 0.8)
	var box := BoxMesh.new()
	box.size = Vector3.ONE
	var material := MeshUtil.make_material(Color(0.9, 0.75, 0.55), 0.0, 0.9)
	material.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
	material.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
	material.vertex_color_use_as_albedo = true
	box.material = material
	dust.mesh = box
	dust.position = Vector3(0.0, 0.1, 0.0)
	_player.add_child(dust)
	dust.emitting = true
	var cleanup := create_tween()
	cleanup.tween_interval(1.2)
	cleanup.tween_callback(dust.queue_free)
