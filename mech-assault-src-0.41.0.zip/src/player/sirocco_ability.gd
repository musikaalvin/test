class_name SiroccoAbility
extends AbilityBase

# ZEPHYR Gale Veil: takeoff flight for a fixed field window; damage taken while
# the field is up consumes an invisibility charge for a short stealth pop, and
# the built-in rotary gun only fires while the field is active.

@export var field_duration: float = 13.0
@export var recharge_time: float = 14.0
@export var flight_altitude: float = 6.5
@export var stealth_duration: float = 1.5
@export var max_invis_charges: int = 3

var field_active: bool = false
var stealth_active: bool = false

var _player: PlayerRobot
var _rig: RobotRig
var _field_left: float = 0.0
var _stealth_left: float = 0.0
var _ground_ref: float = 0.0
var _invis_charges: int = 0
var _recharges: Array[float] = []
var _charge_clock: float = 0.0

func setup(player: PlayerRobot, rig: RobotRig) -> void:
	_player = player
	_rig = rig
	if player.health != null and not player.health.damaged.is_connected(_on_damaged):
		player.health.damaged.connect(_on_damaged)

func _ready() -> void:
	recharge_time *= float(GameState.combat_stats().get("cooldown", 1.0))
	max_charges = 2
	charges = max_charges
	Events.ability_requested.connect(activate)
	_emit_charges()
	_set_phase("READY")

func _physics_process(delta: float) -> void:
	var charges_before := charges
	for index in range(_recharges.size() - 1, -1, -1):
		_recharges[index] -= delta
		if _recharges[index] <= 0.0:
			_recharges.remove_at(index)
			charges = mini(charges + 1, max_charges)
	if charges != charges_before:
		_emit_charges()
	if not _recharges.is_empty():
		_charge_clock += delta
		if _charge_clock >= 0.15:
			_charge_clock = 0.0
			_emit_charges()
	if field_active:
		_field_left -= delta
		if _field_left <= 0.0:
			_end_field()
	if stealth_active:
		_stealth_left -= delta
		if _stealth_left <= 0.0:
			_end_stealth()

func is_field_active() -> bool:
	return field_active

func is_dash_active() -> bool:
	return false

func is_stealth_active() -> bool:
	return stealth_active

func tick_vertical(_delta: float) -> bool:
	if not field_active or _player == null:
		return false
	var target := _ground_ref + flight_altitude
	var zone := HazardZones.zone_at(_player.global_position)
	if not zone.is_empty():
		target = maxf(target, float(zone["level"]) + 1.6)
	# Never punch through an interior roof: probe for overhead structure and
	# hold the hover a body-height under it (bunkers, gantries, overhangs).
	var ceiling := _probe_ceiling()
	if ceiling < INF:
		target = minf(target, ceiling - 1.3)
	var error_height := target - _player.global_position.y
	_player.velocity.y = clampf(error_height * 4.5, -7.0, 8.0)
	return true

func recharge_ratio() -> float:
	if _recharges.is_empty():
		return 1.0
	var fastest := INF
	for time_left in _recharges:
		fastest = minf(fastest, time_left)
	return clampf(1.0 - fastest / maxf(recharge_time, 0.01), 0.0, 1.0)

func activate() -> void:
	if field_active or charges <= 0 or _player == null or not _player._is_alive():
		return
	charges -= 1
	_recharges.append(recharge_time)
	_emit_charges()
	field_active = true
	_field_left = field_duration
	_invis_charges = max_invis_charges
	_ground_ref = _probe_ground()
	if _rig != null and _rig.has_method("set_thrusters"):
		_rig.call("set_thrusters", true)
	_set_phase("FLIGHT")
	_spawn_activation_fx()
	if _rig != null:
		_rig.kick_ability(-4.0, 0.0, 0.5)
	Events.camera_shake_requested.emit(0.4, 0.25)

func notify_fired() -> void:
	pass

func force_end() -> void:
	if stealth_active:
		_end_stealth()
	if field_active:
		_end_field()

func _on_damaged(_amount: float, _applied: float, _current: float, _point: Vector3) -> void:
	if not field_active or stealth_active or _invis_charges <= 0:
		return
	_invis_charges -= 1
	stealth_active = true
	_stealth_left = stealth_duration
	if _rig != null:
		_rig.set_stealth(true)
	_set_phase("STEALTH")

func _end_field() -> void:
	field_active = false
	_field_left = 0.0
	if _rig != null and _rig.has_method("set_thrusters"):
		_rig.call("set_thrusters", false)
	_update_phase()

func _end_stealth() -> void:
	stealth_active = false
	_stealth_left = 0.0
	if _rig != null:
		_rig.set_stealth(false)
	_update_phase()

func _update_phase() -> void:
	if stealth_active:
		_set_phase("STEALTH")
	elif field_active:
		_set_phase("FLIGHT")
	elif charges < max_charges:
		_set_phase("RECHARGING")
	else:
		_set_phase("READY")

func _probe_ground() -> float:
	var query := PhysicsRayQueryParameters3D.create(
			_player.global_position, _player.global_position + Vector3.DOWN * 60.0,
			Layers.WORLD)
	query.exclude = [_player.get_rid()]
	var hit := _player.get_world_3d().direct_space_state.intersect_ray(query)
	if hit.is_empty():
		return _player.global_position.y
	return (hit["position"] as Vector3).y

# World Y of the lowest collider overhead, or INF when the sky is clear.
func _probe_ceiling() -> float:
	var query := PhysicsRayQueryParameters3D.create(
			_player.global_position + Vector3.UP * 0.6,
			_player.global_position + Vector3.UP * 40.0, Layers.WORLD)
	query.exclude = [_player.get_rid()]
	var hit := _player.get_world_3d().direct_space_state.intersect_ray(query)
	if hit.is_empty():
		return INF
	return (hit["position"] as Vector3).y

func _set_phase(value: String) -> void:
	if phase_name != value:
		phase_name = value
		Events.ability_phase_changed.emit(value)

func _emit_charges() -> void:
	Events.ability_charges_changed.emit(charges, max_charges, recharge_ratio())

func _spawn_activation_fx() -> void:
	if _player == null:
		return
	var flash := OmniLight3D.new()
	flash.name = "GaleFlash"
	flash.light_color = Color(0.45, 0.9, 1.0)
	flash.omni_range = 8.0
	flash.light_energy = 3.0
	flash.position = Vector3(0.0, 0.5, 0.0)
	_player.add_child(flash)
	var tween := create_tween()
	tween.tween_property(flash, "light_energy", 0.0, 0.35)
	tween.tween_callback(flash.queue_free)
