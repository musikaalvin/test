class_name LegUnit
extends Node3D

const UP := Vector3.UP
# Wall-climb stroke (scorpion gait). Climb mode overrides the ground gait only
# while PlayerRobot arms it; every value is deterministic (no wall-clock time).
const CLIMB_RETURN_TIME := 0.35
const CLIMB_WALL_GAP := 1.3
# Thigh+shin reach measured from the hip. _solve clamps at thigh+shin-0.02 and
# still parks the foot on the requested target, so any target past this budget
# visibly tears the shin away from the foot.
const CLIMB_REACH_BUDGET := 2.3

@export var foot_drop: float = 0.0
@export var rest_spread: float = 1.0
@export var pole_style: int = 0
@export var thigh_length: float = 1.15
@export var shin_length: float = 1.35
@export var coxa_length: float = 0.28
@export var hip_radius: float = 0.17
@export var thigh_radius: float = 0.13
@export var shin_radius: float = 0.095
@export var foot_size: Vector3 = Vector3(0.34, 0.12, 0.42)
@export var phase_offset: float = 0.0
@export var stride_length: float = 1.05
@export var step_height: float = 0.55
@export var duty_factor: float = 0.42
@export var base_frequency: float = 0.85
@export var run_frequency: float = 2.1
@export var reference_speed: float = 7.0
@export var outward: Vector3 = Vector3.RIGHT
@export var bend_up_bias: float = 1.0

@export var climb_phase: float = -1.0
@export var climb_reach: float = 1.3
@export var climb_frequency: float = 1.05
@export var climb_swing_ratio: float = 0.42
@export var climb_lift_off: float = 0.3
@export var climb_press: float = 0.08
@export var climb_max_hold: float = 1.8
@export var climb_min_hold: float = -1.6

# Bakes a uniform chassis scale into every length the IK and gait use, so a
# bigger (or smaller) robot keeps hull, sockets, feet and stride matched.
# MUST run before _ready: the leg visuals are built from these constants.
func apply_scale(scale_factor: float) -> void:
	if is_equal_approx(scale_factor, 1.0):
		return
	foot_drop *= scale_factor
	thigh_length *= scale_factor
	shin_length *= scale_factor
	coxa_length *= scale_factor
	hip_radius *= scale_factor
	thigh_radius *= scale_factor
	shin_radius *= scale_factor
	foot_size *= scale_factor
	stride_length *= scale_factor
	step_height *= scale_factor
	climb_reach *= scale_factor
	climb_lift_off *= scale_factor
	climb_max_hold *= scale_factor
	climb_min_hold *= scale_factor

var _phase: float = 0.0
var _planted: Vector3 = Vector3.ZERO
var _step_from: Vector3 = Vector3.ZERO
var _step_to: Vector3 = Vector3.ZERO
var _stepping: bool = false
var _climb_return_left: float = 0.0
var _foot_world: Vector3 = Vector3.ZERO
var _foot_forward: Vector3 = Vector3.ZERO
var _initialised: bool = false

# Climb-mode state (owned by set_climb_mode / _update_climb).
var _climbing: bool = false
var _climb_time: float = 0.0
var _climb_hold: Vector3 = Vector3.ZERO
var _climb_normal: Vector3 = Vector3.ZERO
var _climb_contact: Vector3 = Vector3.ZERO
var _climb_planted: bool = false

var _coxa_bone: Node3D
var _upper_bone: Node3D
var _lower_bone: Node3D
var _knee_node: Node3D
var _ankle_node: Node3D
var _foot_node: Node3D
var _leg_body: AnimatableBody3D
var _foot_shape: CollisionShape3D
var _shin_shape: CollisionShape3D

var _armor_material: StandardMaterial3D
var _joint_material: StandardMaterial3D
var _accent_material: StandardMaterial3D
var _secondary_material: StandardMaterial3D
var _trim_material: StandardMaterial3D
var _sensor_material: StandardMaterial3D

func configure(armor_material: StandardMaterial3D, joint_material: StandardMaterial3D,
		accent_material: StandardMaterial3D = null, secondary_material: StandardMaterial3D = null,
		trim_material: StandardMaterial3D = null,
		sensor_material: StandardMaterial3D = null) -> void:
	_armor_material = armor_material
	_joint_material = joint_material
	_accent_material = accent_material if accent_material != null else armor_material
	_secondary_material = secondary_material if secondary_material != null else armor_material
	_trim_material = trim_material if trim_material != null else joint_material
	_sensor_material = sensor_material if sensor_material != null else trim_material

func _ready() -> void:
	_build()
	_initialised = true

func _build() -> void:
	_coxa_bone = Node3D.new()
	_coxa_bone.name = "CoxaBone"
	add_child(_coxa_bone)
	MeshUtil.sph_at(_coxa_bone, hip_radius * 1.3, Vector3.ZERO, _joint_material, "hip_ball")
	MeshUtil.cyl_at(_coxa_bone, hip_radius * 0.85, coxa_length, Vector3(0.0, coxa_length * 0.5, 0.0),
			Vector3.ZERO, _trim_material, "coxa_strut")
	MeshUtil.bevel_at(_coxa_bone, Vector3(0.16, coxa_length * 0.9, 0.3),
			Vector3(0.0, coxa_length * 0.5, 0.0), Vector3.ZERO, _armor_material, "coxa_armor")

	_upper_bone = Node3D.new()
	_upper_bone.name = "UpperBone"
	add_child(_upper_bone)
	MeshUtil.cyl_at(_upper_bone, thigh_radius * 0.6, thigh_length * 0.96,
			Vector3(0.0, thigh_length * 0.5, 0.0), Vector3.ZERO, _joint_material, "thigh_core")
	MeshUtil.bevel_at(_upper_bone, Vector3(0.3, thigh_length * 0.7, 0.24),
			Vector3(0.0, thigh_length * 0.45, 0.0), Vector3.ZERO, _armor_material, "thigh_armor")
	MeshUtil.bevel_at(_upper_bone, Vector3(0.34, thigh_length * 0.26, 0.1),
			Vector3(0.0, thigh_length * 0.52, 0.14), Vector3.ZERO, _accent_material, "thigh_plate")
	MeshUtil.cyl_at(_upper_bone, 0.045, thigh_length * 0.55,
			Vector3(0.19, thigh_length * 0.4, 0.0), Vector3.ZERO, _trim_material, "thigh_piston")
	MeshUtil.cyl_at(_upper_bone, 0.028, thigh_length * 0.34,
			Vector3(0.19, thigh_length * 0.76, 0.0), Vector3.ZERO, _joint_material, "thigh_rod")
	MeshUtil.bevel_at(_upper_bone, Vector3(0.05, thigh_length * 0.8, 0.16),
			Vector3(-0.17, thigh_length * 0.5, 0.0), Vector3.ZERO, _secondary_material, "thigh_fin")
	var horn_side := -signf(outward.x) if absf(outward.x) > 0.05 else 1.0
	MeshUtil.cone_at(_upper_bone, 0.08, 0.006, 0.46,
			Vector3(horn_side * 0.17, thigh_length * 0.88, 0.0),
			Vector3(0.0, 0.0, horn_side * -58.0), _accent_material, "thigh_horn")
	MeshUtil.cone_at(_upper_bone, 0.05, 0.005, 0.26,
			Vector3(horn_side * 0.15, thigh_length * 0.6, -0.13),
			Vector3(-32.0, 0.0, horn_side * -44.0), _secondary_material, "thigh_spur")
	_knee_node = Node3D.new()
	_knee_node.name = "Knee"
	_knee_node.position = Vector3(0.0, thigh_length, 0.0)
	_upper_bone.add_child(_knee_node)
	MeshUtil.sph_at(_knee_node, thigh_radius * 1.5, Vector3.ZERO, _joint_material, "knee_ball")
	MeshUtil.cyl_at(_knee_node, thigh_radius * 0.9, 0.12, Vector3(0.0, 0.0, 0.0),
			Vector3(90.0, 0.0, 0.0), _accent_material, "knee_cap")

	_lower_bone = Node3D.new()
	_lower_bone.name = "LowerBone"
	add_child(_lower_bone)
	MeshUtil.cyl_at(_lower_bone, shin_radius * 0.6, shin_length * 0.95,
			Vector3(0.0, shin_length * 0.5, 0.0), Vector3.ZERO, _joint_material, "shin_core")
	MeshUtil.bevel_at(_lower_bone, Vector3(0.2, shin_length * 0.55, 0.16),
			Vector3(0.0, shin_length * 0.45, 0.0), Vector3.ZERO, _secondary_material, "shin_armor")
	MeshUtil.cyl_at(_lower_bone, 0.038, shin_length * 0.5,
			Vector3(0.14, shin_length * 0.45, 0.06), Vector3.ZERO, _trim_material, "shin_piston")
	MeshUtil.bevel_at(_lower_bone, Vector3(0.14, shin_length * 0.3, 0.1),
			Vector3(-0.1, shin_length * 0.7, 0.0), Vector3.ZERO, _accent_material, "shin_plate")
	MeshUtil.cone_at(_lower_bone, 0.05, 0.005, 0.3,
			Vector3(horn_side * 0.1, shin_length * 0.82, 0.0),
			Vector3(0.0, 0.0, horn_side * -66.0), _secondary_material, "shin_spur")
	MeshUtil.cyl_at(_lower_bone, 0.02, shin_length * 0.45,
			Vector3(-0.13, shin_length * 0.38, -0.04), Vector3.ZERO, _joint_material, "shin_hose")
	_ankle_node = Node3D.new()
	_ankle_node.name = "Ankle"
	_ankle_node.position = Vector3(0.0, shin_length, 0.0)
	_lower_bone.add_child(_ankle_node)
	MeshUtil.sph_at(_ankle_node, shin_radius * 1.3, Vector3.ZERO, _joint_material, "ankle_ball")

	_foot_node = Node3D.new()
	_foot_node.name = "Foot"
	add_child(_foot_node)
	MeshUtil.bevel_at(_foot_node, Vector3(0.14, 0.18, 0.16), Vector3(0.0, 0.08, 0.0),
			Vector3.ZERO, _joint_material, "foot_strut")
	MeshUtil.bevel_at(_foot_node, foot_size, Vector3(0.0, -0.03, 0.0),
			Vector3.ZERO, _armor_material, "foot_pad")
	MeshUtil.bevel_at(_foot_node, Vector3(0.26, 0.06, 0.34), Vector3(0.0, 0.02, 0.02),
			Vector3.ZERO, _accent_material, "foot_plate")
	for side in [-1.0, 1.0]:
		MeshUtil.bevel_at(_foot_node, Vector3(0.05, 0.17, 0.4),
				Vector3(side * 0.155, 0.045, 0.0), Vector3.ZERO, _joint_material, "foot_rail")
	MeshUtil.bevel_at(_foot_node, Vector3(0.1, 0.02, 0.2), Vector3(0.0, 0.055, 0.01),
			Vector3.ZERO, _sensor_material, "foot_glow")
	var claw_x: Array[float] = [-0.11, 0.0, 0.11]
	for index in claw_x.size():
		var lateral_yaw := -12.0 * (signf(claw_x[index]) if claw_x[index] != 0.0 else 0.0)
		MeshUtil.cone_at(_foot_node, 0.06, 0.008, 0.26,
				Vector3(claw_x[index], 0.0, -0.24),
				Vector3(-85.0, lateral_yaw, 0.0), _trim_material, "claw_%d" % index)
	MeshUtil.cone_at(_foot_node, 0.055, 0.008, 0.22, Vector3(0.0, -0.01, 0.24),
			Vector3(95.0, 0.0, 0.0), _trim_material, "heel_spur")

	_leg_body = AnimatableBody3D.new()
	_leg_body.name = "LegBody"
	_leg_body.collision_layer = Layers.LEG
	_leg_body.collision_mask = Layers.LEG_MASK
	_leg_body.sync_to_physics = true
	add_child(_leg_body)
	_foot_shape = CollisionShape3D.new()
	_foot_shape.name = "FootShape"
	var foot_box := BoxShape3D.new()
	foot_box.size = foot_size * Vector3(1.0, 1.5, 1.0)
	_foot_shape.shape = foot_box
	_foot_shape.position = Vector3(0.0, -foot_size.y * 0.3, 0.0)
	_leg_body.add_child(_foot_shape)
	_shin_shape = CollisionShape3D.new()
	_shin_shape.name = "ShinShape"
	var shin_capsule := CapsuleShape3D.new()
	shin_capsule.radius = shin_radius * 1.5
	shin_capsule.height = shin_length * 1.04
	_shin_shape.shape = shin_capsule
	_leg_body.add_child(_shin_shape)

func reset_gait(foot_world: Vector3) -> void:
	_phase = phase_offset
	_planted = foot_world
	_foot_world = foot_world
	_foot_forward = Vector3.ZERO
	_stepping = false
	_climb_return_left = 0.0

# Arms (or releases) the wall-climb stroke. While armed the ground gait is
# bypassed entirely; on release the foot eases back onto the ground rest so
# nothing snaps or detaches.
func set_climb_mode(active: bool, wall_normal: Vector3, wall_contact: Vector3,
		rest_foot: Vector3) -> void:
	if active:
		if not _climbing:
			_climbing = true
			_climb_time = 0.0
			_climb_hold = _foot_world
			_climb_planted = true
			_stepping = false
			_climb_return_left = 0.0
			_foot_forward = Vector3.ZERO
		_climb_normal = wall_normal
		_climb_contact = wall_contact
		return
	if not _climbing:
		return
	_climbing = false
	_phase = phase_offset
	_step_from = _foot_world
	_step_to = rest_foot if rest_foot.length_squared() > 0.0001 else _foot_world
	_stepping = false
	_climb_return_left = CLIMB_RETURN_TIME
	_foot_forward = Vector3.ZERO

func update_gait(hip_world: Vector3, rest_foot: Vector3, velocity: Vector3, body_forward: Vector3,
		body_up: Vector3, delta: float, turn_rate: float = 0.0,
		body_center: Vector3 = Vector3.ZERO) -> void:
	if not _initialised:
		return
	if _climbing:
		_update_climb(hip_world, rest_foot, body_forward, body_up, delta)
		_solve(hip_world, body_forward, body_up)
		return
	if _climb_return_left > 0.0:
		_update_climb_return(rest_foot, body_forward, delta)
		_solve(hip_world, body_forward, body_up)
		return
	var planar_speed := Vector3(velocity.x, 0.0, velocity.z).length()
	var turn_speed := absf(turn_rate) * 1.3
	var move_speed := maxf(planar_speed, turn_speed)
	var speed_ratio := clampf(move_speed / maxf(reference_speed, 0.01), 0.0, 1.4)
	var frequency := lerpf(base_frequency, run_frequency, clampf(speed_ratio, 0.0, 1.0))
	var previous_phase := _phase
	_phase = fmod(_phase + frequency * delta + phase_offset, 1.0)
	var wrapped := _phase < previous_phase
	var should_step := move_speed > 0.35
	if wrapped and should_step:
		_begin_step(rest_foot, velocity, body_up, turn_rate, body_center)
	if _foot_forward == Vector3.ZERO:
		_foot_forward = body_forward
	if _stepping:
		var t := clampf(_phase / maxf(duty_factor, 0.05), 0.0, 1.0)
		var eased := t * t * (3.0 - 2.0 * t)
		var lift := step_height * (0.35 + 0.65 * speed_ratio) * sin(PI * t)
		_foot_world = _step_from.lerp(_step_to, eased) + UP * lift
		_foot_forward = (_foot_forward + (body_forward - _foot_forward) \
				* minf(9.0 * delta, 1.0)).normalized()
		if t >= 1.0:
			_stepping = false
			_planted = _step_to
	else:
		_foot_world = _planted
		if not should_step:
			_foot_world += UP * (0.012 * sin(Time.get_ticks_msec() * 0.0016 + phase_offset * TAU))
	_solve(hip_world, body_forward, body_up)

# Post-climb: one eased arc from the wall foot down onto the ground rest,
# tracking the (moving) rest so the landing point stays fresh.
func _update_climb_return(rest_foot: Vector3, body_forward: Vector3, delta: float) -> void:
	_climb_return_left = maxf(_climb_return_left - delta, 0.0)
	_step_to = rest_foot if rest_foot.length_squared() > 0.0001 else _step_to
	var k := 1.0 - _climb_return_left / CLIMB_RETURN_TIME
	var eased := k * k * (3.0 - 2.0 * k)
	_foot_world = _step_from.lerp(_step_to, eased) + UP * (sin(PI * k) * step_height * 0.6)
	if _foot_forward == Vector3.ZERO:
		_foot_forward = body_forward
	else:
		_foot_forward = (_foot_forward + (body_forward - _foot_forward) \
				* minf(9.0 * delta, 1.0)).normalized()
	if _climb_return_left <= 0.0:
		_planted = _step_to
		_foot_world = _step_to
		_stepping = false

# Alternating diagonal climb stroke: reach high up the wall plane, plant the
# claws, then hold the foot world-fixed so the rising hull pulls itself past it.
func _update_climb(hip_world: Vector3, rest_foot: Vector3, body_forward: Vector3,
		body_up: Vector3, delta: float) -> void:
	var normal := _climb_normal
	if normal.length_squared() < 0.0001:
		normal = -body_forward
	if normal.length_squared() < 0.0001:
		normal = UP
	normal = normal.normalized()
	var wall_up := body_up - normal * body_up.dot(normal)
	if wall_up.length_squared() < 0.0001:
		wall_up = UP
	wall_up = wall_up.normalized()
	var wall_right := wall_up.cross(normal)
	var contact := _climb_contact
	if contact.length_squared() < 0.0001:
		# no probe point: assume the hull sits its own gap off the plane
		contact = hip_world - normal * CLIMB_WALL_GAP
	var hip_on_wall := hip_world - normal * (hip_world - contact).dot(normal)
	var gap := absf((hip_world - contact).dot(normal))
	# foot keeps the leg's natural spread, but only inside the wall plane
	var side := rest_foot - hip_world
	side = side - normal * side.dot(normal)
	side = side - wall_up * side.dot(wall_up)
	if side.length_squared() < 0.0001:
		side = wall_right * 0.4
	# Rear hips sit ~2.3 m off the plane, so the in-plane offset is scaled into
	# whatever reach the leg has left at that gap (front legs keep the full
	# stroke, rear legs only just touch the wall instead of overextending).
	var plane_budget := sqrt(maxf(CLIMB_REACH_BUDGET * CLIMB_REACH_BUDGET - gap * gap, 0.0))
	var offset := side + wall_up * climb_reach
	var offset_len := offset.length()
	if offset_len > plane_budget:
		offset = offset * (plane_budget / maxf(offset_len, 0.01))
	_climb_time += delta
	var cycle := fmod(_climb_time * climb_frequency + _climb_phase_offset(), 1.0)
	var high := hip_on_wall + offset
	var target: Vector3
	if cycle < climb_swing_ratio:
		var swing := clampf(cycle / maxf(climb_swing_ratio, 0.01), 0.0, 1.0)
		var eased := swing * swing * (3.0 - 2.0 * swing)
		# lift-off only as far as the reach still allows (0 for stretched legs)
		var reach_now := sqrt(gap * gap + offset.length_squared())
		var lift := minf(climb_lift_off, maxf(CLIMB_REACH_BUDGET - reach_now, 0.0))
		target = _climb_hold.lerp(high, eased) + normal * (lift * sin(PI * swing))
		_climb_planted = false
	else:
		if not _climb_planted:
			_climb_hold = high - normal * climb_press
			_climb_planted = true
		var above := (_climb_hold - hip_on_wall).dot(wall_up)
		if above > climb_max_hold:
			_climb_hold -= wall_up * (above - climb_max_hold)
		elif above < climb_min_hold:
			_climb_hold -= wall_up * (above - climb_min_hold)
		# last line of defence: never let a plant drift outside the leg's reach
		var to_hold := _climb_hold - hip_world
		var hold_len := to_hold.length()
		if hold_len > CLIMB_REACH_BUDGET:
			_climb_hold = hip_world + to_hold * (CLIMB_REACH_BUDGET / maxf(hold_len, 0.01))
		target = _climb_hold
	_foot_world = target
	if _foot_forward == Vector3.ZERO:
		_foot_forward = body_forward
	else:
		_foot_forward = (_foot_forward + (body_forward - _foot_forward) \
				* minf(9.0 * delta, 1.0)).normalized()

func _climb_phase_offset() -> float:
	if climb_phase >= 0.0:
		return climb_phase
	return fmod(phase_offset * 2.0, 1.0)

func _begin_step(rest_foot: Vector3, velocity: Vector3, body_up: Vector3, turn_rate: float,
		body_center: Vector3) -> void:
	var swing := Vector3(velocity.x, 0.0, velocity.z)
	if absf(turn_rate) > 0.01:
		swing += turn_rate * body_up.cross(rest_foot - body_center)
	if swing.length_squared() > 0.01:
		_step_to = rest_foot + swing.normalized() * stride_length * 0.5
	else:
		_step_to = rest_foot
	_step_from = _foot_world
	_stepping = true
	_climb_return_left = 0.0

func _solve(hip_world: Vector3, body_forward: Vector3, body_up: Vector3) -> void:
	var body_right := body_forward.cross(body_up)
	var lateral := body_right * outward.x + body_up * outward.y - body_forward * outward.z
	lateral = lateral - body_forward * lateral.dot(body_forward)
	if lateral.length_squared() < 0.0001:
		lateral = body_right
	lateral = lateral.normalized()

	var coxa_end := hip_world + lateral * coxa_length
	_coxa_bone.global_position = hip_world
	_coxa_bone.global_basis = MeshUtil.segment_basis(lateral)

	var pole: Vector3
	if pole_style == 1:
		pole = (body_forward + body_up * 0.15).normalized()
	else:
		pole = (body_up * bend_up_bias + lateral * 0.4).normalized()
	var delta := _foot_world - coxa_end
	var distance := clampf(delta.length(), 0.05, thigh_length + shin_length - 0.02)
	var direction := delta.normalized() if delta.length_squared() > 0.000001 else Vector3.DOWN

	var along := (thigh_length * thigh_length - shin_length * shin_length + distance * distance) / (2.0 * distance)
	var height := sqrt(maxf(thigh_length * thigh_length - along * along, 0.0))

	var perpendicular := pole - direction * pole.dot(direction)
	if perpendicular.length_squared() < 0.0001:
		perpendicular = direction.cross(body_forward)
		if perpendicular.length_squared() < 0.0001:
			perpendicular = Vector3.RIGHT
	perpendicular = perpendicular.normalized()

	var knee := coxa_end + direction * along + perpendicular * height
	var shin_end := coxa_end + direction * distance

	var upper_dir := knee - coxa_end
	if upper_dir.length_squared() < 0.000001:
		upper_dir = direction
	var lower_dir := shin_end - knee
	if lower_dir.length_squared() < 0.000001:
		lower_dir = direction

	_upper_bone.global_position = coxa_end
	_upper_bone.global_basis = MeshUtil.segment_basis(upper_dir)
	_lower_bone.global_position = knee
	_lower_bone.global_basis = MeshUtil.segment_basis(lower_dir)

	_foot_node.global_position = _foot_world + Vector3.DOWN * foot_drop
	_foot_node.global_basis = MeshUtil.look_rotation_basis(
			_foot_forward if _foot_forward != Vector3.ZERO else body_forward, body_up)

	_leg_body.global_position = _foot_world
	var shin_vector := knee - _foot_world
	if shin_vector.length_squared() > 0.000001:
		_shin_shape.global_position = _foot_world + shin_vector * 0.5
		_shin_shape.global_basis = MeshUtil.segment_basis(shin_vector)

func foot_position() -> Vector3:
	return _foot_world
