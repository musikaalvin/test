class_name ShroudAbility
extends AbilityBase

# RAVAGER primary: an 8 second shroud field - a 100 m aura that slows every
# hostile caught inside and stacks a fresh damage mark on each of them on a
# half-second pulse. Tuned to War Robots' Dark Light (numbers only, original
# name/visuals): 8 s duration, 0.5 s per stack, 13 s cooldown, radius scaled
# 175-200 m -> 100 m for our 460 m map (same ratio as grav cast 90 m).
# 16 pulses x 0.125 = x3.0 mark at full duration = "stacks to the cap by the
# time the field expires", the WR relationship.
const ROBOT: StringName = &"RAVAGER"
# Titan capsule: radius 1.85*BULK, height 4.5*BULK, centred at y -0.15, so
# the feet sit ~2.96 below the origin - the field hugs the ground there.
const FEET_Y := -2.9
# Dark Light now reads as a projected zone of darkness (Mauler-style): a dark
# ground disc + a fading skirt of shadow around the rim + slow rising motes.
# The old floating black-hole ball above the back is gone (director note).
const CURTAIN_H := 7.0

# --- Dark zone shaders (all unshaded + transient, never rig-shared) ---
const CURTAIN_SHADER: String = """
shader_type spatial;
render_mode cull_disabled, unshaded, depth_draw_never;

uniform vec3 edge_color : source_color = vec3(0.30, 0.10, 0.55);
uniform vec3 core_color : source_color = vec3(0.02, 0.01, 0.05);
uniform float curtain_h : hint_range(1.0, 20.0) = 7.0;

varying vec3 v_local;

void vertex() {
	v_local = VERTEX;
}

void fragment() {
	float h = clamp(v_local.y / curtain_h, 0.0, 1.0);
	float fade = pow(1.0 - h, 1.6);
	float fres = 1.0 - abs(dot(normalize(NORMAL), normalize(VIEW)));
	float ripple = 0.5 + 0.5 * sin(atan(v_local.z, v_local.x) * 6.0 + TIME * 1.3);
	vec3 col = mix(core_color, edge_color, fres * 0.75);
	float alpha = mix(0.10, 0.52, fres) * fade * (0.72 + 0.36 * ripple);
	ALBEDO = col;
	EMISSION = edge_color * (fres * fade * (0.5 + ripple * 0.35));
	ALPHA = clamp(alpha, 0.0, 1.0);
}
"""

const GROUND_SHADER: String = """
shader_type spatial;
render_mode cull_disabled, unshaded, depth_draw_never;

uniform vec3 edge_color : source_color = vec3(0.34, 0.12, 0.6);
uniform vec3 core_color : source_color = vec3(0.03, 0.01, 0.07);
uniform float rim_boost : hint_range(0.0, 3.0) = 0.0;
uniform float pulse_speed : hint_range(0.0, 6.0) = 1.1;
uniform float max_radius : hint_range(1.0, 200.0) = 50.0;

varying vec3 v_local;

void vertex() {
	v_local = VERTEX;
}

void fragment() {
	float rn = clamp(length(v_local.xz) / max_radius, 0.0, 1.0);
	float edge = smoothstep(0.68, 1.0, rn);
	float ripple = 0.5 + 0.5 * sin(rn * 44.0 - TIME * pulse_speed * 6.28318);
	vec3 col = mix(core_color, edge_color, edge);
	float alpha = mix(0.24, 0.5, edge) * (0.7 + 0.35 * ripple);
	alpha += edge * rim_boost * 0.5;
	ALBEDO = col;
	EMISSION = edge_color * (edge * (0.85 + rim_boost * 2.4) + ripple * 0.1);
	ALPHA = clamp(alpha, 0.0, 1.0);
}
"""

@export var recharge_time: float = 13.0
@export var duration: float = 8.0
@export var field_radius: float = 100.0
@export var pulse_interval: float = 0.5
@export var slow_duration: float = 1.2
@export var slow_factor: float = 0.65
@export var mark_duration: float = 3.0
@export var mark_step: float = 0.125
@export var mark_cap: float = 3.0

var field_active: bool = false

var _player: PlayerRobot
var _rig: RobotRig
var _recharge_left: float = -1.0
var _active_left: float = 0.0
var _pulse_left: float = 0.0
var _disc: MeshInstance3D
var _motes: CPUParticles3D
var _curtain: MeshInstance3D
var _ground_mat: ShaderMaterial
var _rim_tw: Tween

func setup(player: PlayerRobot, rig: RobotRig) -> void:
	_player = player
	_rig = rig

func _ready() -> void:
	recharge_time *= float(GameState.combat_stats().get("cooldown", 1.0))
	max_charges = 1
	charges = 1
	dash_speed = 0.0
	Events.ability_requested.connect(activate)
	_build_field()
	_emit_charges()
	_set_phase("READY")

func _physics_process(delta: float) -> void:
	if charges < max_charges:
		if _recharge_left < 0.0:
			_recharge_left = recharge_time
		_recharge_left -= delta
		if _recharge_left <= 0.0:
			charges = mini(charges + 1, max_charges)
			_recharge_left = recharge_time if charges < max_charges else -1.0
			_set_phase("READY")
		_emit_charges()
	if field_active:
		_active_left -= delta
		_pulse_left -= delta
		if _pulse_left <= 0.0:
			_pulse_left = pulse_interval
			_pulse_field()
		if _active_left <= 0.0:
			_end_field()

func activate() -> void:
	if GameState.selected_robot != ROBOT:
		return
	if field_active or charges <= 0 or _player == null or not _player._is_alive():
		return
	charges = 0
	_recharge_left = recharge_time
	field_active = true
	_active_left = duration
	_pulse_left = 0.0
	_set_field_visible(true)
	AudioEngine.play(&"sonic", -1.0, 0.08, 0.75)
	if _rig != null:
		_rig.kick_ability(-3.5, 0.0, 0.5)
	Events.camera_shake_requested.emit(0.35, 0.25)
	Haptics.pulse(75, 0.7)
	_set_phase("SHROUD")
	_emit_charges()

func _pulse_field() -> void:
	if _player == null:
		return
	var origin := _player.global_position
	for entry in get_tree().get_nodes_in_group("enemy"):
		var enemy := entry as EnemyRobot
		if enemy == null or not is_instance_valid(enemy):
			continue
		if enemy.state == EnemyRobot.State.DEAD:
			continue
		if enemy.health == null or enemy.health.dead:
			continue
		var offset := enemy.global_position - origin
		offset.y = 0.0
		if offset.length() > field_radius:
			continue
		enemy.apply_slow(slow_duration, slow_factor)
		var stacked := minf(maxf(enemy.death_mark_mult, 1.0) + mark_step, mark_cap)
		enemy.apply_death_mark(mark_duration, stacked)
	_flash_ground_rim()

func _end_field() -> void:
	field_active = false
	_active_left = 0.0
	_set_field_visible(false)
	if charges > 0:
		_set_phase("READY")
	else:
		_set_phase("RECHARGING")

func is_dash_active() -> bool:
	return false

func is_stealth_active() -> bool:
	return false

func recharge_ratio() -> float:
	if charges >= max_charges:
		return 1.0
	if _recharge_left <= 0.0:
		return 1.0
	return clampf(1.0 - _recharge_left / maxf(recharge_time, 0.01), 0.0, 1.0)

func notify_fired() -> void:
	pass

func force_end() -> void:
	if field_active:
		_end_field()

func _set_field_visible(active: bool) -> void:
	# setup() runs after _ready(), so the field is built the first time the
	# shroud is actually switched on.
	if active and _disc == null:
		_build_field()
	if _disc != null:
		_disc.visible = active
	if _motes != null:
		_motes.emitting = active
	if _curtain != null:
		_curtain.visible = active
	if _rim_tw != null and _rim_tw.is_valid():
		_rim_tw.kill()
	if active:
		_rim_tw = create_tween()
		_rim_tw.tween_method(_set_rim_boost, 1.6, 0.0, 0.7)
	else:
		_set_rim_boost(0.0)

func _set_rim_boost(value: float) -> void:
	if _ground_mat != null:
		_ground_mat.set_shader_parameter("rim_boost", value)

# Every pulse rings the field edge brighter for a beat.
func _flash_ground_rim() -> void:
	if _ground_mat == null:
		return
	if _rim_tw != null and _rim_tw.is_valid():
		_rim_tw.kill()
	_rim_tw = create_tween()
	_rim_tw.tween_method(_set_rim_boost, 1.4, 0.0, 0.45)

func _make_shader(code: String) -> ShaderMaterial:
	var shader := Shader.new()
	shader.code = code
	var material := ShaderMaterial.new()
	material.shader = shader
	return material

# Open-tube skirt around the field rim (CylinderMesh would cap it with lids).
func _curtain_mesh(radius: float, height: float) -> ArrayMesh:
	var st := SurfaceTool.new()
	st.begin(Mesh.PRIMITIVE_TRIANGLES)
	var segments := 48
	for index in segments:
		var a0 := TAU * float(index) / float(segments)
		var a1 := TAU * float(index + 1) / float(segments)
		var mid := Vector3(cos((a0 + a1) * 0.5), 0.0, sin((a0 + a1) * 0.5))
		var b0 := Vector3(cos(a0) * radius, 0.0, sin(a0) * radius)
		var b1 := Vector3(cos(a1) * radius, 0.0, sin(a1) * radius)
		var t0 := b0 + Vector3(0.0, height, 0.0)
		var t1 := b1 + Vector3(0.0, height, 0.0)
		# outward winding seen from outside
		for vertex: Vector3 in [b0, t0, t1, b0, t1, b1]:
			st.set_normal(mid)
			st.add_vertex(vertex)
	return st.commit()

func _build_field() -> void:
	if _player == null:
		return
	_disc = MeshInstance3D.new()
	_disc.name = "ShroudDisc"
	var disc_mesh := CylinderMesh.new()
	disc_mesh.top_radius = field_radius
	disc_mesh.bottom_radius = field_radius
	disc_mesh.height = 0.14
	disc_mesh.radial_segments = 40
	disc_mesh.rings = 1
	_ground_mat = _make_shader(GROUND_SHADER)
	_ground_mat.set_shader_parameter("max_radius", field_radius)
	disc_mesh.material = _ground_mat
	_disc.mesh = disc_mesh
	_disc.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	_disc.position = Vector3(0.0, FEET_Y, 0.0)
	_disc.visible = false
	_player.add_child(_disc)

	_motes = CPUParticles3D.new()
	_motes.name = "ShroudMotes"
	_motes.amount = 140
	_motes.lifetime = 1.6
	_motes.local_coords = true
	# Dim shadow-violet embers drifting up out of the dark ground.
	_motes.direction = Vector3.UP
	_motes.spread = 35.0
	_motes.gravity = Vector3(0.0, 0.7, 0.0)
	_motes.initial_velocity_min = 0.4
	_motes.initial_velocity_max = 1.3
	_motes.scale_amount_min = 0.07
	_motes.scale_amount_max = 0.18
	_motes.color = Color(0.34, 0.12, 0.6, 0.4)
	var mote_mesh := BoxMesh.new()
	mote_mesh.size = Vector3.ONE
	var mote_material := MeshUtil.make_material(
			Color(0.3, 0.1, 0.55), 0.0, 0.5, Color(0.26, 0.08, 0.5), 0.9)
	mote_material.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
	mote_material.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
	mote_material.blend_mode = BaseMaterial3D.BLEND_MODE_ADD
	mote_material.vertex_color_use_as_albedo = true
	mote_mesh.material = mote_material
	_motes.mesh = mote_mesh
	_motes.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	_motes.emission_shape = CPUParticles3D.EMISSION_SHAPE_BOX
	_motes.emission_box_extents = Vector3(field_radius - 4.0, 1.0, field_radius - 4.0)
	_motes.position = Vector3(0.0, FEET_Y + 0.2, 0.0)
	_motes.emitting = false
	_player.add_child(_motes)

	# The shadow skirt: an open tube ringing the zone, fading out with height.
	_curtain = MeshInstance3D.new()
	_curtain.name = "ShroudCurtain"
	var curtain_mesh := _curtain_mesh(field_radius, CURTAIN_H)
	var curtain_mat := _make_shader(CURTAIN_SHADER)
	curtain_mat.set_shader_parameter("curtain_h", CURTAIN_H)
	curtain_mesh.surface_set_material(0, curtain_mat)
	_curtain.mesh = curtain_mesh
	_curtain.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	_curtain.position = Vector3(0.0, FEET_Y + 0.05, 0.0)
	_curtain.visible = false
	_player.add_child(_curtain)

func _set_phase(value: String) -> void:
	if phase_name != value:
		phase_name = value
		Events.ability_phase_changed.emit(value)

func _emit_charges() -> void:
	Events.ability_charges_changed.emit(charges, max_charges, recharge_ratio())
