class_name NullfieldAbility
extends AbilityBase

# Princeps-style NULL FIELD (War Robots 12.2 tuning): ONE stored charge, SIX
# stasis-barrier hits inside a 10 s field, 12 s cooldown. Every triggering hit
# is fully soaked (works at any hull level) and re-arms the 1 s Quantum Lock
# that keeps blocking health changes after the field itself drops — healing
# still passes. The soak is a temporary shield pool, so `damaged` keeps firing
# and every hit consumes one of the six charges.

const ROBOT: StringName = &"PRAETOR"

@export var recharge_time: float = 12.0
@export var barrier_duration: float = 10.0
@export var barrier_hits: int = 6
@export var lock_duration: float = 1.0

var barrier_active: bool = false

var _player: PlayerRobot
var _rig: RobotRig
var _recharge_left: float = -1.0
var _barrier_left: float = 0.0
var _hits_left: int = 0
var _lock_left: float = 0.0
var _pool_on: bool = false
var _saved_shield: float = 0.0
var _saved_shield_max: float = 0.0
var _saved_shield_regen: float = 0.0
var _saved_shield_kind: int = Health.Zone.PHYSICAL
var _bubble: MeshInstance3D
var _pulse: Tween

func setup(player: PlayerRobot, rig: RobotRig) -> void:
	_player = player
	_rig = rig
	if player.health != null and not player.health.damaged.is_connected(_on_damaged):
		player.health.damaged.connect(_on_damaged)

func _ready() -> void:
	recharge_time *= float(GameState.combat_stats().get("cooldown", 1.0))
	max_charges = 1
	charges = 1
	dash_speed = 0.0
	Events.ability_requested.connect(activate)
	_emit_charges()
	_set_phase("READY")

func _physics_process(delta: float) -> void:
	if charges < max_charges:
		if _recharge_left < 0.0:
			_recharge_left = recharge_time
		_recharge_left -= delta
		if _recharge_left <= 0.0:
			charges = mini(charges + 1, max_charges)
			_recharge_left = recharge_time if charges < max_charges else -1.0
			if charges >= max_charges:
				_set_phase("READY")
		_emit_charges()
	if barrier_active:
		_barrier_left -= delta
		if _barrier_left <= 0.0:
			_end_barrier()
	if _lock_left > 0.0:
		_lock_left -= delta
		if _lock_left <= 0.0:
			_lock_left = 0.0
			_refresh_pool()

func activate() -> void:
	if GameState.selected_robot != ROBOT:
		return
	if barrier_active or charges <= 0 or _player == null or not _player._is_alive():
		return
	charges -= 1
	if _recharge_left < 0.0:
		_recharge_left = recharge_time
	barrier_active = true
	_barrier_left = barrier_duration
	_hits_left = barrier_hits
	_lock_left = lock_duration
	_refresh_pool()
	_show_bubble(true)
	if _rig != null:
		_rig.kick_ability(-3.0, 0.0, 0.5)
	Events.camera_shake_requested.emit(0.35, 0.25)
	_set_phase("BARRIER")
	_emit_charges()

func _on_damaged(amount: float, _applied: float, _current: float, _point: Vector3) -> void:
	if not barrier_active or _player == null:
		return
	if amount <= 0.001:
		return
	_lock_left = lock_duration	# every trigger re-arms Quantum Lock
	_hits_left -= 1
	if _hits_left <= 0:
		_end_barrier()
	_refresh_pool()

# The soak: while the field (or its 1 s lock tail) runs, the hull hides behind
# a temporary shield pool. Hits are absorbed at ANY health level and the pool
# keeps `damaged` firing so the six charges actually count down.
func _refresh_pool() -> void:
	if _player == null or _player.health == null:
		return
	var health := _player.health
	var want := barrier_active or _lock_left > 0.0
	if want and not _pool_on:
		_pool_on = true
		_saved_shield = health.shield
		_saved_shield_max = health.shield_max
		_saved_shield_regen = health.shield_regen
		_saved_shield_kind = health.shield_kind
		health.configure_shield(Health.Zone.PHYSICAL,
				maxf(health.max_health * 1000.0, 1.0), 0.0)
	elif not want and _pool_on:
		_pool_on = false
		health.shield = _saved_shield
		health.shield_max = _saved_shield_max
		health.shield_regen = _saved_shield_regen
		health.shield_kind = _saved_shield_kind

func _end_barrier() -> void:
	barrier_active = false
	_barrier_left = 0.0
	_show_bubble(false)
	_refresh_pool()
	if charges > 0:
		_set_phase("READY")
	else:
		_set_phase("RECHARGING")

func is_dash_active() -> bool:
	return false

func is_stealth_active() -> bool:
	return false

func recharge_ratio() -> float:
	if charges >= max_charges:
		return 1.0
	if _recharge_left <= 0.0:
		return 1.0
	return clampf(1.0 - _recharge_left / maxf(recharge_time, 0.01), 0.0, 1.0)

func notify_fired() -> void:
	pass

func force_end() -> void:
	_lock_left = 0.0
	if barrier_active:
		_end_barrier()
	else:
		_refresh_pool()

func _show_bubble(active: bool) -> void:
	if active:
		_ensure_bubble()
		if _bubble == null:
			return
		_bubble.visible = true
		_bubble.scale = Vector3.ONE * 0.4
		if _pulse != null and _pulse.is_valid():
			_pulse.kill()
		_pulse = create_tween()
		_pulse.set_loops()
		_pulse.tween_property(_bubble, "scale", Vector3.ONE * 1.0, 0.2) \
				.set_trans(Tween.TRANS_BACK).set_ease(Tween.EASE_OUT)
		_pulse.parallel().tween_property(_bubble, "transparency", 0.0, 0.2)
		_pulse.tween_property(_bubble, "transparency", 0.22, 0.5)
		_pulse.tween_property(_bubble, "transparency", 0.07, 0.5)
	elif _bubble != null:
		if _pulse != null and _pulse.is_valid():
			_pulse.kill()
		_pulse = create_tween()
		_pulse.tween_property(_bubble, "scale", Vector3.ONE * 1.3, 0.25)
		_pulse.parallel().tween_property(_bubble, "transparency", 1.0, 0.25)
		_pulse.tween_callback(_hide_bubble)

func _hide_bubble() -> void:
	if _bubble != null:
		_bubble.visible = false

func _ensure_bubble() -> void:
	if _bubble != null or _player == null:
		return
	_bubble = MeshInstance3D.new()
	_bubble.name = "NullfieldBubble"
	var sphere := SphereMesh.new()
	sphere.radius = 3.4
	sphere.height = 6.8
	sphere.radial_segments = 24
	sphere.rings = 12
	var material := StandardMaterial3D.new()
	material.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
	material.albedo_color = Color(0.55, 0.95, 1.0, 0.1)
	material.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
	material.blend_mode = BaseMaterial3D.BLEND_MODE_ADD
	material.cull_mode = BaseMaterial3D.CULL_DISABLED
	material.emission_enabled = true
	material.emission = Color(0.5, 0.9, 1.0)
	material.emission_energy_multiplier = 2.0
	sphere.material = material
	_bubble.mesh = sphere
	_bubble.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	_bubble.position = Vector3(0.0, 2.4, 0.0)
	_bubble.visible = false
	_player.add_child(_bubble)

func _set_phase(value: String) -> void:
	if phase_name != value:
		phase_name = value
		Events.ability_phase_changed.emit(value)

func _emit_charges() -> void:
	Events.ability_charges_changed.emit(charges, max_charges, recharge_ratio())
