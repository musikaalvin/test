class_name AbilityBase
extends Node

var charges: int = 0
var max_charges: int = 1
var phase_name: String = "READY"
var dash_speed: float = 0.0

func setup(_player: PlayerRobot, _rig: RobotRig) -> void:
	pass

func activate() -> void:
	pass

func tick_vertical(_delta: float) -> bool:
	return false

func is_dash_active() -> bool:
	return false

func is_stealth_active() -> bool:
	return false

func is_field_active() -> bool:
	return false

func recharge_ratio() -> float:
	return 1.0

func notify_fired() -> void:
	pass

func force_end() -> void:
	pass
