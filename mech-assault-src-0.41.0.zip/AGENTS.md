# MECH ASSAULT — AGENTS.md

Third-person 3D robot combat prototype for Android. Single-player, fully offline, no networking.

The game director communicates only through natural-language prompts. The agent owns all file
creation, command-line execution, testing, diagnosis and code maintenance.

---

## 1. Environment (verified, do not re-provision)

| Tool | Path / version | Notes |
| --- | --- | --- |
| OS | Kali GNU/Linux Rolling 2026.3, **aarch64** | Host kernel is Android; no display, no `/dev/kvm` |
| Godot | `~/tools/godot-4.4.1` → 4.4.1.stable.official | **Must be 4.4.x.** Godot 4.5 arm64 segfaults in editor `--import` |
| Export templates | `~/.local/share/godot/export_templates/4.4.1.stable/` | android_debug.apk, android_release.apk, android_source.zip |
| JDK | `/usr/lib/jvm/java-21-openjdk-arm64` | System default `java` is 25 — always use `JAVA_HOME` from `tools/env.sh` |
| Android SDK | `~/Android/Sdk` | cmdline-tools, platform-tools, platforms;android-35, build-tools;35.0.0 |
| adb | `/usr/bin/adb` (Kali arm64) | Google's SDK adb is x86_64 and cannot run; an arm64 copy was placed in the SDK |
| zipalign | `/usr/bin/zipalign` (Kali arm64) | Google's build-tools copy is x86_64; an arm64 copy replaced it in build-tools/35.0.0 |
| apksigner, d8 | Google build-tools | Java-based, architecture independent, work as shipped |
| Python 3 | system `python3` | Pillow present; numpy installed via `pip3 install --user numpy` (render pipeline) |

Load the environment in every shell: `source tools/env.sh`

### Known environment limitations

- **No GPU rendering on the build machine.** Software rendering (llvmpipe via Xvfb, both
  `opengl3` and `vulkan`) aborts with SIGILL inside the LLVM JIT; Godot headless uses a dummy
  renderer. Correctness is verified numerically by `tools/smoke_test.tscn` AND visually via the
  mesh-dump pipeline below (works with zero GPU).
- **No Android emulator** (`/dev/kvm` absent) and **no attached device** (`adb devices` empty,
  no `/system/bin/adbd`). APK validation ends at build + `aapt2`/signature inspection; gameplay
  must be verified by installing `build/android/mech-assault-debug.apk` on real hardware.
- `aapt2` from Kali (2.19) cannot read the android-35 resource table, so **Gradle/AGP builds are
  unusable on this host**. This does not affect us: Godot's non-Gradle Android export only needs
  `zipalign` + `apksigner`, both of which work.
- Disk space is tight (~7 GB free). Do not keep large archives under `~/tools`.

---

## 2. Commands

```bash
source tools/env.sh            # always first

./tools/validate.sh            # import + headless smoke test (401 checks)
./tools/validate.sh --apk      # the above, then build the debug APK

# visual inspection without a GPU (robot/arena silhouette review):
"$GODOT" --headless --path . tools/dump_mesh.tscn   # -> build/mesh_dump.json
python3 tools/render_views.py                        # -> build/screenshots/*.png
```

Rendered views: front/rear/left/right/iso/low/gameplay. Read the PNGs, judge the silhouette,
iterate on `src/player/robot_rig.gd` / `leg_unit.gd`, repeat.

Outputs: APK at `build/android/mech-assault-debug.apk`, logs at `/tmp/mechassault_*.log`.

Install on a real device: `adb install -r build/android/mech-assault-debug.apk`

---

## 3. Project layout

```
project.godot            mobile renderer, 22 m/s² gravity, landscape, 1280x720 canvas_items
export_presets.cfg       Android preset, non-Gradle export, arm64-v8a + x86_64
scenes/
  main_menu.tscn         Control root; all UI built in code
  game.tscn              Ironyard + Player + CameraRig
  player/player_robot.tscn CharacterBody3D + capsule + Visuals/RobotRig
src/core/autoload/       singletons: Events (signals), GameState (match flow + selected_map/
                         selected_quality), SceneRouter (scene swaps), InputRouter (InputMap +
                         touch aggregation + split weapon groups), Projectiles (tracer pool),
                         AudioEngine (procedural SFX + engine loop + event hooks)
src/core/util/           MeshUtil (procedural geometry/materials incl. bevel box + wedge),
                         Layers (collision bitmasks), Quality (tier presets: shadows/glow/render
                         scale/grading, physical sky, detail normals), Haptics (vibration),
                         PanelTextures (procedural PBR albedo/roughness/normal maps)
src/player/              PlayerRobot (movement), RobotRig (procedural mesh), LegUnit (IK gait),
                         FollowCamera (spring arm + auto-recenter), ShadowDash (ability)
src/enemies/             EnemyRobot (state-machine AI), SpiderRig (six-leg visual)
src/world/               CombatArena (base: player_spawn/enemy_spawns), Ironyard (industrial
                         map), CinderValley (terrain heightfield map), Nature (backdrop),
                         GameSession (match wiring, lock-on targeting, debug HUD, touch layer)
src/combat/              WeaponData, WeaponMount, WeaponSystem, Projectile(s), Health,
                         CombatFx (sparks/flash/scorch decals)
src/ui/                  MainMenu (map + graphics selectors, safe-area, UiTheme styling),
                         GridStripes, TouchControls (stick/fire/RAZOR/MAUL/dash + MOVE/LOOK
                         captions), Hud (panelled stats/bars, end panel, UiTheme), EnemyMarkers
                         (floating enemy HP bars + lock tag), UiTheme (shared StyleBox factory)
tools/                   env.sh, validate.sh, smoke_test.{gd,tscn}, dump_mesh.{gd,tscn},
                         render_views.py, screenshot_tool.{gd,tscn}
```

### Architecture rules

1. **Autoloads are the only global state.** Never cache match state on nodes.
2. **Nodes signal, they do not search.** Use `Events` for cross-system communication; direct
   `get_node_or_null` lookups only for hard scene structure.
3. **Input goes through `InputRouter`.** Actions are registered in code at runtime
   (`InputRouter._define_actions`), never in `project.godot`. Nodes read `move_vector`,
   `fire_held`, `consume_look()`. Touch UI calls `set_virtual_move` / `set_virtual_fire` /
   `request_ability`.
4. **Geometry is procedural.** Robots and props are built from `MeshUtil` primitives in code with
   shared `StandardMaterial3D` instances. No imported meshes, no textures beyond UI gradients.
   Draw calls and triangle counts stay low by design.
5. **Gameplay logic runs in `_physics_process` at a fixed 60 Hz** and never depends on frame rate
   or visual state (see §5).
6. **Strict typing.** GDScript warnings are errors in this project — annotate every variable.
7. No `class_name` collisions; global class names are registered by the editor into
   `.godot/global_script_class_cache.cfg` during `--import`.

### Originality rule

Everything is original work. Broad genre conventions (third-person mech combat, four-legged
scorpion silhouette, dash/stealth ability) are fine. Never copy Pixonic / War Robots meshes,
textures, sounds, maps, animation data, names, UI art or code. Names in this project
(MECH ASSAULT, IRONYARD, MACHARIA-M, SHADOW DASH) are our own.

---

## 4. Milestones

| # | Scope | Status |
| --- | --- | --- |
| 1 | Foundation, procedural robot, arena, third-person camera, movement | **done** |
| 2 | Robot animation polish, four hardpoints, MACHARIA-M weapons | **done** |
| 3 | Combat, damage, health, destruction | **done** |
| 4 | Enemy AI (IDLE/SEARCH/CHASE/ATTACK/DEAD) | **done** |
| 5 | Maps: IRONYARD + CINDER VALLEY (menu selectable) | **done** |
| 6 | SHADOW DASH ability | **done** |
| 7 | Android touch controls + HUD + lock-on/HP bars | **done** |
| 8 | Audio, particles, graphics tiers, visual polish | partial (procedural SFX + quality tiers + scorch/dust done; more polish pending) |
| 9 | Android APK build + on-device testing | pipeline proven, device test pending |
| 10 | Meta-economy v0.16 (durability/pilots/drones/specs/titan/store/combat stats) | **done** |

Process rule: implement **one** milestone, run `./tools/validate.sh`, fix errors, update this
file, commit, report, then stop and wait for the director's next instruction.

---

## 5. Engineering lessons taken from War Robots' technical history

Pixonic's own post-mortems (Game Developer, May 2024) and Unity case studies shaped these rules:

1. **Frame-rate independence.** War Robots originally tied shooting to render rate; they later
   separated simulation entities from visuals and moved projectiles to a data-oriented/ECS style
   system. We keep all combat and movement math in fixed-step physics, so a 30 fps device and a
   120 fps device behave identically.
2. **Quality tiers instead of one setting.** They built a per-device "Quality Manager" to trade
   shadows, AA and texture quality. Our equivalent will be a quality preset selected at startup
   (`ProjectSettings` overrides), not per-feature hacks.
3. **Draw-call budget drives content.** Their "ubershader" work (one atlas for every mech) came
   from supporting tens of thousands of device SKUs. We use shared materials, `MultiMesh` for
   repeated props and primitive meshes with ≤12 radial segments.
4. **Safe-area-aware UI from day one.** They hand-rolled notch handling in 2017. Our HUD must use
   `DisplayServer.get_display_safe_area()` (already used by the debug overlay).
5. **Authoritative damage decisions come later, not now.** Their "quorum" scheme (7 of 12 clients
   must agree on damage) is the answer to cheating in multiplayer. Offline single-player needs
   none of it, but keeping damage funnelled through one `apply_damage` entry point keeps a
   server-authoritative mode possible later.
6. **Data-driven tuning.** They replaced XML/Unity serialization with MessagePack for
   startup cost. Our equivalent is moving magic numbers out of code into `.tres` resources as
   balance content grows.

What we deliberately skip: Photon/networking, microservices, clans, IAP, rewarded ads,
analytics, cloud localization — all out of scope for an offline prototype.

---

## 6. Milestone 1 implementation notes

- **Robot:** `RobotRig` assembles a quadruped assault mech from primitives — armoured hull,
  side plates, spine rails, sensor head with emissive bar, four articulated legs, four-segment
  articulated tail with stinger, and four side hardpoints (cradle + barrel stub + muzzle marker).
  Gold/dark-metal/joint materials, emissive cyan sensors.
- **Legs:** `LegUnit` does two-bone IK (law of cosines, pole-vector knee) plus a non-sliding gait:
  each leg plants, then interpolates to a lead position with a sine lift arc. Phase offsets
  `[0.0, 0.5, 0.25, 0.75]` give a stable crawl gait; frequency lerps toward a run gait with speed.
- **Grounding:** the character raycasts the world under each hip and pulls the foot target onto the
  surface, with a reach threshold so legs dangle when airborne. Legs reset to probed ground after
  a fall.
- **Movement:** camera-relative, `CharacterBody3D`, walk 3.4 / run 7.0 / reverse 2.3 / strafe 2.9
  m/s, 16 m/s² accel, 20 m/s² decel, 3 m/s² air control, 22 m/s² gravity with a fall multiplier,
  52° max slope, 1.1 m floor snap. The hull yaws toward the camera with a turn rate limit, and
  the head yaws up to ±37° to follow the aim.
- **Camera:** `SpringArm3D` (collision-aware) at 8.6 m, 1.15 m focus height (retuned from 2.4
  after visual review — 2.4 framed the sky), pitch clamp -35°..+24°, position/yaw smoothing,
  speed-based FOV kick (72°→80°), shake hook on `Events`.
- **IRONYARD:** 96 m industrial arena — perimeter walls, four buildings with emissive window
  strips, 12 containers in three `MultiMesh` variants plus matching collision bodies, two ramps to
  a central gantry, four cover pillars, two catwalks with ramps, lane markings and hazard trim.
  Player spawn plus six enemy spawn markers.
- **Validation:** `tools/smoke_test.tscn` instantiates the game headlessly and asserts 89
  invariants (node wiring, four legs + per-leg collision bodies, four hardpoint sockets, finite
  transforms, ground contact, camera placement, travel distance under simulated input, weapon
  fire/heat/overheat cycle, projectile flight + down-range impacts, menu wiring, touch controls).

---

## 7. Post-M1 batch: robot rebuild, weapons, controllers, logo

- **Robot rebuild (visual foundation, director-approved category: original four-legged scorpion
  assault mech):** `RobotRig` children are now `Chassis` (hexagonal core hull + glacis + brow +
  splayed side plates + chamfers + hip sponsons + cheek/mandible fang plates + dorsal spine ridges +
  engine block with louvres + exhaust stacks + belly keel + four hardpoint pedestals), `HeadSensor`
  (shell, brow, visor recess, emissive optic bar + eyes, antenna with cyan tip), `Tail`, the four
  `Leg_*` units, and `WeaponHardpoint_1..4` sockets (yawed ±90° so all barrels fire forward; each
  contains a `WeaponMount`).
- **Tail:** root at (0, 0.52, 1.42) above the engine; four segments 0.78/0.68/0.58/0.5 m, radii
  0.34→0.17, rest angles -18/-24/-26/-26° (arcs up and curls forward over the back), alternating
  gold spine plates + grey under-plates + side ribs, stinger bulb/collar/spine + emissive tip.
  **Bug fixed:** `_update_tail` must write `rotation_degrees` (rest angles are degrees) — writing
  `rotation` (radians) curled the tail into the ground.
- **Legs (`LegUnit` rebuild):** bone nodes `CoxaBone` / `UpperBone` (+`Knee`) / `LowerBone`
  (+`Ankle`) / `Foot` with children visuals (core cylinders, armour boxes, accent plates, piston
  + rod cylinders, joint spheres) so nothing inherits scale. Foot = pad + top plate + three
  forward claws + heel spur. Each leg has a `LegBody` `AnimatableBody3D` (layer `Layers.LEG=8`,
  mask `Layers.LEG_MASK=WORLD`) with foot BoxShape + shin CapsuleShape — layer 8 is outside the
  player's own mask (3) so feet can never snag the owning CharacterBody.
- **Foot grounding:** `GROUND_CLEARANCE` 0.32 → 0.1 so the pad lands on the surface instead of
  floating 20 cm above it.
- **Weapons (M2):** `WeaponData` (MACHARIA-M RAZOR autocannon ×2, MACHARIA-M MAUL scattergun ×2),
  `WeaponMount` (cradle/drum/heat-sink/barrel/muzzle-brake meshes, spring recoil, muzzle flash +
  light, heat/overheat state machine in `_physics_process`), `WeaponSystem` (fire loop, heat
  signal), `ProjectileService` autoload `Projectiles` (96-pool raycast tracers, impacts emit
  `Events.weapon_impact`). `add_visual_cylinder` now positions **locally** (was global — mount
  visuals depend on it).
- **Controllers (director request: "like War Robots"):** `src/ui/touch_controls.gd` — floating
  left virtual stick (claims touches <35% width, drawn ring/knob), FIRE hold button, DASH button,
  right-side look drag handled by `InputRouter._unhandled_input` (tap = ability), added by
  `GameSession` only when `TouchControls.should_show()` (touchscreen/mobile feature). Physical
  gamepad: left stick moves (already mapped), right stick look via `InputRouter.
  _poll_gamepad_look`, right trigger fires (`_gamepad_trigger_fire`), A=fire, B=ability.
- **Logo:** `icon.svg` (default Godot icon) deleted; `project.godot` icon = `res://icon.png` and
  Android launcher `main_192x192` = `res://icon.png` (both derived from the director's
  `/home/kali/logo.jpg`); menu banner = `logo_menu.png` (`Logo` TextureRect above the title).
- **Visual pipeline:** `tools/dump_mesh.tscn` instantiates the game, settles 75 physics frames,
  dumps every visible MeshInstance3D/MultiMeshInstance3D triangle + material colour/emission +
  camera/player transforms to `build/mesh_dump.json`; `tools/render_views.py` rasterizes seven
  PNGs into `build/screenshots/` with a numpy z-buffer. Use it after any geometry change.
---

## 8. Post-M2 batch: combat/AI/HUD/nature + graphics tiers + map 2 + WR-style feel

One combined delivery (all validated at 111 smoke checks):

- **Combat core (M3):** `src/combat/health.gd` (max/defense/current, `apply_damage/heal/ratio`,
  group "damageable"); projectiles route damage through `receive_damage` on the collider;
  player 150 HP with death sequence (input off, weapons off, `GameState.notify_player_died`);
  `CombatFx` spawns impact sparks + flash light + pooled **scorch decals** (HIGH tier only,
  cull-disabled quad, 9 s lifetime, pool of 14).
- **Enemy AI (M4):** `EnemyRobot` (capsule + `SpiderRig`, IDLE/SEARCH/CHASE/ATTACK/DEAD, LOS ray
  every 0.2 s, burst fire, jam-blockable pounce, armor fracture → `health.defense`, `ai_enabled`
  gate for deterministic smoke, death → `Events.enemy_killed` + 6 s cleanup). Three spiders spawn
  from `arena.enemy_spawns`.
- **SHADOW DASH (M6):** `src/player/shadow_dash.gd` — per-charge recharge timers, dash + stealth
  phases (`ability_phase_changed`), rig-wide alpha fade (`set_stealth`), cone disruption pulse
  (`apply_system_jam` + `apply_armor_fracture`), charge HUD pips.
- **HUD + lock-on (M7):** `src/ui/hud.gd` — right column (hostiles/armor/heat/overheat/pips/
  phase), crosshair + hitmarker + STEALTH chip, damage vignette, end panel, safe-area margins,
  red **TARGET lock frame**; `src/ui/enemy_markers.gd` — floating enemy HP bars tracked by
  `unproject_position`, lock tag + red frame on the locked target. Lock acquisition lives in
  `GameSession._update_targeting` (screen-centre cone + WORLD raycast, emits
  `Events.enemy_targeted/cleared`).
- **Graphics tiers (director: "War Robots high/extreme graphics"):** `src/core/util/quality.gd`
  — LOW/MEDIUM/HIGH stored in `GameState.selected_quality`, menu `GRAPHICS` button cycles;
  HIGH = SSAO + glow + 4× MSAA + 1.0 render scale + physical sky (`PhysicalSkyMaterial`,
  sun disk yaw-matched to the sun light via `env.sky_rotation`) + ACES tonemap + colour grading +
  box **ReflectionProbe** + 95 m soft shadows (PCF quality 2 / 4096 atlas set in project.godot)
  + procedural **detail normal maps** (FastNoiseLite → sobel → ImageTexture, applied to ground/
  metal materials). Per-tier fog density, MSAA and `scaling_3d_scale` applied per scene via
  `Quality.apply_viewport/apply_environment`.
- **Second map (director: "second map, keep Ironyard"):** `src/world/combat_arena.gd` base class
  (`player_spawn`/`enemy_spawns`) — both arenas extend it; `src/world/cinder_valley.gd` builds a
  122 m SurfaceTool heightfield (analytic `terrain_height`, trimesh collision via
  `create_trimesh_shape`, circular skirt at r>52 that meets Nature's rim at y≈-1), basin lake with
  ripple/fresnel shader, boulders with sphere colliders, ruined slabs, rock spire arch, dead trees,
  buried wrecks, own sun/sky/probe. Menu `MAP` button toggles `GameState.selected_map`;
  `GameSession._build_arena` frees Ironyard and instantiates the valley; `Nature.setup(env,
  include_ground)` skips the flat backdrop ground on the valley map.
- **WR-style feel (director picked all four):** (1) lock-on + HP bars above;
  (2) `FollowCamera` auto-recentre after 1.1 s idle while moving + heavier movement
  (accel 16→10, decel 20→13, turn 3.6→2.7, air accel 2.2); (3) split fire — touch `RAZOR`/`MAUL`
  buttons + keys 1/2 + pad shoulders → `InputRouter.group_held[0/1]`, `WeaponSystem` fires mounts
  0/1 (RAZOR) or 2/3 (MAUL) independently of the all-guns FIRE, plus `Haptics.pulse`
  (`Input.vibrate_handheld`, mobile-guarded) on fire/taken-hit/kill; (4) sound —
  `AudioEngine` autoload synthesizes every SFX at startup as `AudioStreamWAV` (cannon crack,
  scatter boom, metal impact, hit crunch, dash whoosh, kill boom, UI blip, 1 s **looped engine
  hum** via `AudioStreamPlayer3D` bound to the player, speed-scaled dB) and hooks
  `weapon_fired/weapon_impact/damage_applied/ability_phase_changed/enemy_killed`.
- **Atmosphere:** foot dust particles while moving, Nature backdrop (valley rim, mountains,
  volcano, drifting clouds, lightning + procedural thunder).
- **Validation:** 111 checks incl. graphics env assertions, valley standalone build, and a full
  **map-swap integration test** (game scene rebuilt with `selected_map = CINDER_VALLEY`).
- **Deferred (director approved concept, not yet built):** "original equivalent" quadruped mech
  (SCARAB) — `src/player/mech_rig.gd` base class exists but is unused; `robot_rig.gd` has NOT been
  converted to extend it yet. Do not ship partial: finish `scarab_rig.gd` + rig-swap + ability
  retune as one batch or remove the orphan.

---

## 9. Realism batch: bevel meshes, PBR maps, working tier presets, themed UI, spawn safety

Director complaints addressed (Minecraft-looking robots, dead graphics toggles, dark maps,
invisible controls, spawn sinking). Validated at **120 smoke checks**.

- **Bevel geometry (robot realism):** `MeshUtil.make_bevel_box/bevel_at` (chamfered box: 6 faces +
  12 edge quads + 8 corner tris, auto-corrected winding, meter-projected UVs + tangents) and
  `make_wedge/wedge_at` (sloped armour prism). All 54 robot/spider/leg box visuals converted
  `box_at → bevel_at` — plates now catch light on chamfered edges instead of reading as cubes.
- **Procedural PBR (researched WR remaster: PBR albedo/metallic/normal/smoothness):**
  `src/core/util/panel_textures.gd` generates cached 128² maps per kind (`armor` panel grid +
  rivets + grime, `steel` brushed, `rubber`, `ground`) → albedo (near-white, tinted by material
  colour), roughness (seams rough/plates smooth), sobel normal. Applied to robot + spider
  materials via `PanelTextures.apply` with per-material `uv1_scale`.
- **Tier presets that actually change the picture:** found SSAO/SSIL/SDFGI are **Forward+ only —
  no-ops on the Mobile renderer**, so the old HIGH "SSAO" toggle did nothing. Now: LOW = shadows
  OFF, glow OFF, render scale 0.6 + FXAA, flat grading; MEDIUM = shadows (55 m), glow, 0.85
  scale, grade + reflections probe visible; HIGH = shadows (110 m, split blends), strong glow,
  full scale + 4× MSAA, punchy grade + aerial fog. `Quality.apply_sun` drives per-tier shadows
  (arenas call it); probes hidden below MEDIUM (`visible`, note: `ReflectionProbe.enabled` does
  not exist in 4.4). Smoke asserts LOW disables / HIGH enables shadows+glow+scale.
- **Brightness fix (maps too dark):** sun 1.25→2.3 (valley 2.4), sky ambient 0.55→1.0/1.05,
  fill 0.25→0.45, exposure 1.12–1.2, bright uniform fog colour.
- **UI theme:** `src/ui/theme_builder.gd` (`UiTheme`: StyleBoxFlat panel/button/bar factories,
  hover/pressed states, label shadow styler). Menu: safe-area margins, accent line, fully styled
  START/GRAPHICS/MAP/EXIT buttons (node paths unchanged for smoke). HUD: right-column stats sit
  on a styled panel, bars are Panels with bordered backgrounds, end panel gets EndBox + styled
  REDEPLOY/MAIN MENU. Touch: always built (gate removed), 0.92-alpha FIRE, two-line RAZOR/MAUL
  buttons, persistent MOVE/LOOK captions + idle stick ring drawn in `_draw()`.
- **Spawn safety (robot "sinks in a lake"):** `GameSession._grounded_spawn` raycasts spawn→down
  80 m against WORLD and places the player 1.3 m above the hit; `PlayerRobot.respawn_point` +
  void recovery teleports back when `y < -30`; valley terrain trimesh gets
  `backface_collision = true`.
- **Visual QA:** `dump_mesh` (44,141 tris) + `render_views.py` regenerated — layered plates,
  chamfers, gold panel stacks, segmented tail confirmed in `build/screenshots/`.
- Note: CPU preview rasterizer shows no lighting/PBR/textures — judge colour/lighting only from
  an on-device run.

---

## 10. Device-diagnostic batch (v0.9.4)

Directed at three user-reported device symptoms (crash on shot, missing on-screen controls,
robot spawning underground). No device attached to the build host (`adb devices` empty), so
this batch is instrumentation + startup hardening; crash root-cause still needs logcat.

- **APK freshness proof:** Android export stores scripts as zstd-compressed `.gdc` (`GDSC`
  header + zstd magic `28 b5 2f fd`). Decompress (`zstd -d` from magic offset) and grep to
  verify batch-specific strings — confirmed `22bdc06` markers (`LEAVE MATCH`, `QUIT TO
  DESKTOP`, `MenuButton`) inside the shipped APK.
- **Build stamp:** `GameState.BUILD_LABEL` (`v0.9.4 · 2026-10-03`) shown in menu footer,
  debug overlay line 1, and the opening HUD prompt as
  `BUILD · MAP · SPAWN y=<spawn height>` — one screenshot of either screen identifies the
  running build AND whether grounded-spawn ran (buried robot + prompt y≈2.5 ⇒ stale APK).
- **Startup ordering:** `_build_touch_controls()` is now the FIRST statement of
  `GameSession._ready`, before arena build/quality/spawn — no later failure can hide touch
  UI. `touch_layer.visible = true` set explicitly.
- **Shot path audit (headless-safe review):** muzzle/impact `OmniLight3D`s have shadows off,
  projectile pool (96) is pre-warmed at autoload, WAV data is aligned s16 mono 22050,
  `look_at` in scorch decals guards colinear up-vector. Remaining crash suspect needs device
  logcat (Android BACK → `ui_cancel` is handled by the exit-confirm branch).
- Smoke 121 checks green (spawn asserts player settles `y >= 1.4`, i.e. on top of ground).

---

## 11. Device symptom fixes: aim/lock, touch layout, spawn timing, sky/ambient (v0.9.5)

Second device round — user reported: aim never locks / "shooting myself", on-screen controls
invisible except MENU, entities underground under a black sky, enemy one-shot = app exit.
Validated at **127 smoke checks**.

- **Lock-on never acquired (the aim bug):** `_update_targeting`'s LOS ray uses
  `collision_mask = Layers.WORLD`, but `Layers.ENEMY = 3` overlaps the WORLD bit — the ray to
  an enemy's anchor always hit the enemy itself and the `hit.is_empty()` test rejected every
  target, so no lock/HUD target ever appeared. Fix: the query now excludes **player + every
  alive enemy RID** up front, so only real world geometry can occlude.
- **Smoke now proves acquisition:** previously it only asserted `has_method("get_lock_target")`.
  Phase 3 turns the camera 180° (`InputRouter.look_delta = Vector2(-PI, 0)`), stages a spider in
  the camera cone at a ray-verified clear spot, waits for camera settle, then asserts
  `get_lock_target() != null` — plus rich diagnostics (behind/cone-dist/LOS collider) on failure.
- **Touch root collapsed on device (zero-size parent):** MENU (absolute offsets) drew, every
  anchored child (FIRE/DASH/RAZOR/MAUL/LOOK) resolved off-screen. Fix: `set_anchors_and_offsets_preset`
  in `_ready` + deferred reassert + `_process` auto-heal while `size < 100` (600-frame cap) +
  `NOTIFICATION_RESIZED → queue_redraw`. Smoke asserts the **game scene's** touch root spans
  ≥90 % of the viewport and the FIRE button rect lies fully inside it (node found by **type** —
  an unnamed `TouchControls.new()` keeps its native class name, not `class_name`).
- **Spawn ran too early:** `_grounded_spawn()` fired in `_ready` before the physics space was
  reliable on device (ray missed → `SPAWN y=4.9` fallback = the "sunk/underground" symptom).
  Spawn + enemy grounding + prompt now run on the **first `_physics_process` frame**
  (`_spawn_pending`); expect `SPAWN y≈2.5`. `_ground_enemies()` ray-grounds every spider onto
  the map (`+1.5` capsule offset) and rewrites `spawn_origin`; `EnemyRobot` teleports back to
  `spawn_origin` if it ever falls below `y < -30`.
- **Sky/light hardening (black-sky report):** `Quality.make_sky` now builds a
  **ProceduralSkyMaterial** (cheapest, most driver-tolerant sky; PhysicalSky was an untested
  Adreno path) and both arenas switched `ambient_light_source` from `SKY` to an explicit
  **COLOR** ambient (ironyard blue-grey 0.9, valley warm 0.95) so the scene stays lit even if a
  device renders the sky black.
- **Build stamp:** `GameState.BUILD_LABEL = "v0.9.5 · 2026-10-04"` (v0.9.4 pre- and
  post-VIBRATE builds were indistinguishable on screen). User must install this APK: the
  enemy-one-shot exit was the VIBRATE crash fixed in §10 (`47bc8ce`).
- Corruption sweep clean; `dump_mesh` not re-run (no geometry changes).

---

## 12. High-graphics directive + device bug batch (v0.9.6)

Director directive received: **freeze gameplay features**; next milestone is "MECH ASSAULT High
Graphics Foundation + Hero Robot + combat presentation". Hero robot must be rebuilt via
**Blender Python → GLB → Godot** (not code primitives). Blender install is pending the director's
WiFi: Kali apt `blender` 5.0.1 = **182 packages / 189 MB download** (official blender.org builds
have **no linux-arm64 tarball** — x64 only, so apt is the path; sudo password `kali`). Do NOT
install until told.

Device round 2 fixes (validated at **140 smoke checks**):

- **Touch stick reversed (front = back):** stick drag-up gives `wish.y < 0`, but the movement
  mapping treats `+y` as forward (`Vector3.FORWARD * wish.y`, gamepad convention — smoke sends
  `(0, 1)` = forward). Touch now negates y in `set_virtual_move`; draw code stays natural.
- **Spawn ray pointed at the sky:** `query.to = spawn - Vector3.DOWN * 80.0` evaluates to
  `spawn + UP*80` — every ray missed and the fallback `SPAWN y=4.9` always ran (same bug copied
  into `_ground_enemies`). Now `+ Vector3.DOWN * 80.0`; expect `SPAWN y≈2.5`. `_finish_spawn`
  also zeroes `player.velocity`, and the player void check now also rescues **IRONYARD
  `y < 1.0`** (under-floor/Nature-ground states) back to `respawn_point`.
- **Aim/shoot ("can't shoot, aim doesn't work"):** guns fired along hull forward, so shots never
  followed the crosshair. `WeaponSystem` now computes **camera-forward** each shot, and when a
  lock exists aims **straight at the locked enemy anchor** (`PlayerRobot.locked_enemy` cached via
  `Events.enemy_targeted/cleared`); `WeaponMount.try_fire(exclude, camera_dir, lock_anchor)` falls
  back to the old basis direction for direct/legacy calls (smoke overheat check still passes).
- **Balance:** player HP 150→**200**, enemy damage 6→**4.5**, enemy `fire_interval` 1.35→**1.8**
  (three focused spiders used to delete the player in ~2 s while controls were reversed).
- **Post-death buttons:** headless structure verified by new smoke phase — kills the player and
  asserts EndPanel becomes visible with **enabled, on-screen REDEPLOY + MAIN MENU** buttons.
  If device still shows dead buttons after this APK, request a screenshot of the death screen.
- **ULTRA graphics tier** added (LOW/MEDIUM/HIGH/ULTRA): 8× MSAA, 160 m shadows with split
  blends, full render scale, stronger glow/grade/aerial fog; menu `GRAPHICS` cycles 4 tiers.
  Note: `apply_environment` match arms must keep `Tier.ULTRA` **before** the `_` catch-all.
- **Ironyard visual layering (first pass):** pipe rows along both side walls, 10 bevel-debris
  chunks, 4 emissive orange signs on building faces, `visibility_range_end` on container
  multimeshes + debris (95 m), **BoxOccluder3D** occluders per building for occlusion culling.
- **Build stamp:** `v0.9.6 · 2026-10-04`.
- Deferred until Blender WiFi batch: hero-mech GLB + rig integration, PBR mech materials from
  Blender Principled BSDF, LightmapGI, VFX overhaul (muzzle smoke, dash trails, destruction),
  HUD W1-W4 weapon-button redesign, CINDER VALLEY layering/occlusion.

---

## 13. Hero GLB pipeline + hangar + slot/loadout architecture (v0.10.0, smoke 160)

Directors' "real shit" batch: War Robots-style hangar with robot carousel + weapon
customization, plus the deferred Blender→GLB hero-robot pipeline. Validated at **160 smoke
checks**.

- **Slot/loadout architecture (`game_state.gd` v2):** `ROBOT_DEFS` (SCARAB quadruped 4×MEDIUM
  200 HP; VORTEX biped 4×HEAVY 320 HP speed ×0.76), per-robot `loadouts` + global `inventory`
  pool, `equip_item`/`unequip_item`/`available_items_for_slot` (size-filtered, pool-count
  aware), `filled_slots`, 5 palettes (AURUM/MAGMA/VERDANT/GLACIER/NOCTURNE), full settings +
  loadout persistence. `WeaponData` gained `Kind{AUTOCANNON,SCATTERGUN,ELECTRIC}`,
  `Size{LIGHT,MEDIUM,HEAVY}`, `for_item()` families **RAZOR/MAUL/VOLT** with size scaling;
  empty slots mount no gun. VOLT status effect: `ProjectileService` routes
  `weapon_slow_factor/duration` → `EnemyRobot.apply_slow()` (×0.5 move for 2 s).
- **VORTEX biped:** `src/player/vortex_rig.gd` (arms/shoulders/fists, 2 legs thigh 1.25 /
  shin 1.45 / coxa 0.32, `pole_style 1` knee-forward, `rest_spread 0.5`, 4 heavy hardpoints);
  `PlayerRobot._ready` swaps rig by `GameState.selected_robot`, HP/speeds from `robot_def()`.
- **Blender GLB pipeline** (Blender 5.0.1 — §12's "do not install" note is superseded;
  apt build, sudo `kali`): `tools/build_mech.py` (SCARAB, 41.9k tris) and
  `tools/build_vortex.py` (VORTEX, 14.7k tris, reuses `build_mech.construct(builders,
  poses_fn, out_path)`). Naming contract: parts `chassis__*`/`head__*`/`tail<N>__*`/
  `l<d><c|u|l|f>__*` map through `RobotRig._glb_target`; `MAT_SPECS` keys match
  `_apply_glb_materials`; `gun*` parts skipped (weapon visuals are Godot `WeaponMount`
  work). Regenerate → `--import` (headless runs do NOT reimport; delete
  `.godot/imported/<name>-*` only if a rebuild looks stale).
  - **C² conversion rule (critical):** Blender's `export_yup` performs Z-up→Y-up itself, so
    the script must pre-convert with the **inverse** (`C_B2G` in `to_b_point`, `conj_g2b`).
    Using `C_G2B` double-converts: every vertex/translation arrives Godot-side as
    `(x,−y,−z)` and limbs render 180°-flipped. Diagnosed with `tools/mesh_probe.tscn`
    (prints every GLB node's local transform + parent + bone axes).
  - Join stores `matrix_basis` (pose parent cancels), so the exported node local is pure
    bone-frame geometry; runtime bones are re-solved by IK, bind pose only groups names.
  - **Feet:** correct mesh has pad bottom `min_local = −0.11`; with `foot_drop = 0.0` feet
    land −0.022..+0.002 world-bottom at ground+0.1 clearance (splay x=±2.875/2.915).
    `LegUnit` gained `rest_spread`/`pole_style` exports; first-frame foot reset in
    `PlayerRobot` (`_feet_initialised`).
  - `.gitignore` deliberately excludes `assets/mech/*.glb` (regenerate; `build_mech.py` /
    `build_vortex.py` are committed); added `__pycache__/`.
- **Hangar UI** (`main_menu.gd` rewrite, 1200 lines): top bar (level + currency chips +
  settings), left robot card (class/armor/speed bars, CHANGE ROBOT, PAINT palette row,
  UPGRADE toast), center `SubViewport` preview (`HangarPoseDriver`: builds rig per
  selected robot, grounds feet on platform, idle gait, `rebuild()` on robot/palette/equip
  change), right 4 slot cards + Assign popup (size-filtered pool with counts), settings
  panel (sensitivity/volume/invert), bottom bar. Smoke paths preserved:
  `Layout/Column/{Title,StartButton("TO BATTLE"),GraphicsButton,MapButton}`.
- **HUD/touch polish:** 90 s top-centre countdown (amber ≤15 s, red ≤5 s; timeout kills via
  existing death flow → "TIME EXPIRED"), top-left player HP panel (ARMOR row moved out of
  the right column), enemy `Dist` captions ("%dm"), red FIRE button + crosshair glyph
  (rects unchanged), split-group touch buttons take their label from the loadout family
  (RAZOR/MAUL/VOLT, fallback W1/W2). Debug overlay shifted below the HP panel
  (`margin.y ≥ 104`); session hint text genericized to weapon groups.
- **Smoke 160 checks** (+ hangar node paths, VORTEX swap phase: rig class, 2 legs, no tail,
  GLB parts attached, ELECTRIC/VOLT mounts, armor 320). Diagnostics kept:
  `tools/foot_probe.tscn`, `tools/mesh_probe.tscn`, `tools/dump_mesh.tscn -- vortex`
  (user-arg switches `GameState.selected_robot` before spawn).
- Still deferred from §12: Blender Principled PBR import path, LightmapGI, VFX overhaul,
  CINDER VALLEY layering/occlusion.

---

## 14. Upgrade economy + modern weapon families + midday sky (v0.11.0, smoke 253)

Director round 3: MK1/MK2/MK3 × lv1-12 upgrade system with silver/gold, working back
buttons, "research War Robots 11-12.5 weapons", full L/M/H inventory, brighter midday maps
with sun/clouds, notification permission, spawn safety. Validated at **253 smoke checks**.

- **Upgrade economy (`game_state.gd`):** `upgrades` dict keyed `"<robot>:<slot>"` /
  `"<robot>:body"`, state `Vector2i(mk, lv)`, persisted under config section `"upgrade"`.
  Damage mult: MK1 `1.0+0.075·(lv−1)`, MK2 `1.85+0.025·(lv−1)`, MK3 `2.15+0.030·(lv−1)`
  (no drop at MK transitions — smoke asserts both boundaries). Performance (rof↑ heat↓):
  `1.0+0.02·(lv−1)` / `1.24+0.01·(lv−1)` / `1.36+0.015·(lv−1)`. Cost: silver
  `snapped(1500·lv²·(1+2.5·(mk−1)), 500)` per level; lv12 → MK+1 lv1 costs gold `500·mk`;
  MK3 lv12 maxed (`perform_upgrade` refuses). `apply_weapon_upgrades(data, robot, slot)`
  called from `RobotRig._create_hardpoints` (player-only — enemies keep hardcoded
  `WeaponData.autocannon()`), so upgrade stats reach `WeaponMount` via `weapon_for_item`
  + `display_name = item_id`. Rewards: +3000 silver/kill, +20000 victory/+30 gold,
  +5000 defeat/+10 gold. `Events.currency_changed` refreshes hangar chips.
- **Hangar upgrade UI (`main_menu.gd`):** `UpgradePopup` (badge `MK·lv`, CURRENT-vs-NEXT
  stat columns, cost/wallet row, UPGRADE button, ←BACK header), entry from body card
  `UpgradeButton` + per-slot `UpgradeButton0..3` + bottom bar; slot cards show `MK·lv ·DMG`.
  `ChipSilver`/`ChipGold` in `TopBar`. ←BACK headers added to `AssignPopup` and
  `SettingsPanel` (previously only `CloseAssignButton`/`CloseSettingsButton` ×).
  `SLOTS_WIDTH` 264→360, `CARD_HEIGHT` 82→88.
- **MENU button moved to HUD:** single `HudLayer/Hud/MenuButton` beside the HP panel
  (touch-controls duplicate `_build_menu_button` removed — it collided with the debug
  overlay). Emits existing `Events.menu_requested` → exit-confirm.
- **Modern weapon families (WR 11-12.5-era archetypes, original names — never classic
  WR names like Punisher/Pinata):** `WeaponData` `Kind` + `MAGNETIC/BLAST/CORROSION` +
  fields `splash_radius/corrosion_dps/corrosion_duration`; builders `_torq` (railgun:
  fast tracer, low drop), `_breach` (rocket: splash 3.0/3.8/4.8 m, slow, arcing),
  `_ferric` (corrosion DoT 2/3/4.5 dps ×4 s). `WeaponMount` gains
  `_build_magnetic/_build_breach/_build_ferric` + per-kind muzzle-flash tints.
  `ProjectileService._apply_splash`: sphere query mask `Layers.WORLD` (hits enemies+world,
  never the player — player is layer 2 only), half damage to other receivers;
  corrosion routes `apply_corrosion` on `EnemyRobot` (DoT tick in `_tick_status`).
- **Full catalog:** `ALL_ITEM_IDS` = 18 items (RAZOR/MAUL/VOLT/TORQ/BREACH/FERRIC ×
  L/M/H), default pool 2 each, `load_settings` merges missing ids (old saves upgrade
  in place — merge runs AFTER pool load). `WeaponData.for_item` dispatches new families.
- **Midday sky:** `Quality.make_sky` brighter (sky_energy_multiplier 1.25), exposures
  LOW 1.35 / MED 1.4 / HIGH 1.45 / ULTRA 1.5; arenas sun pitch −58…−62° energy 3.1–3.2,
  ambient 1.3, brighter fog. `Nature` clouds white/emission 0.7 ×14 +
  **`_build_sun_disk()`** (unshaded emission-9 sphere at −460 m, yaw follows
  `env.sky_rotation.y`) + additive billboard halo from `_halo_texture()`. Note: Godot 4.4
  `MeshInstance3D` has **no `disable_fog` property** — assigning it aborts the whole
  function (found via smoke: clouds/sun disk silently 0).
- **Spawn safety:** `GameSession._verify_spawn()` at 0.5/1.5/3.0 s after spawn — ray UP
  from player−0.4 (exclude player+enemies) catches overhead burial (`0.3 < above < 2.0`
  → snap `surface+1.6`), void fallback re-runs `_grounded_spawn` at `y < −6`.
  Prompt re-emits with final `SPAWN y=…` after verification.
- **Android permission:** `export_presets.cfg` `permissions/post_notifications=true` +
  runtime `OS.request_permission("POST_NOTIFICATIONS")` in `MainMenu._ready` (Android only).
- **Smoke 253 checks:** upgrade API (curves/no-drop/perform/currency restore), 18-item
  catalog + new family kinds/splash/corrosion, brightness (sun energy ≥2.8, pitch ≤−50°,
  ambient ≥1.2, sky mult ≥1.2, `SunDisk/SunCore`, ≥12 clouds), HUD MenuButton, popup
  back buttons, VORTEX mounts all wired + `try_fire` direct, tier exposures.
- Deferred: WR research items not yet built — paint/camo shop, drone module, pilot skills,
  battle pass; LightmapGI/VFX overhaul from §12 still pending.

---

## 15. FOUNDRY map + 27 weapons + hangar UX + economy bump (v0.12.0, smoke 301)

Director round 4: "real map like real games" (free premade assets), more weapons across
L/M/H, 1B silver / 1M gold, hangar drag-to-rotate, hangar music, brighter preview.
Validated at **301 smoke checks**.

- **FOUNDRY (third map):** `src/world/foundry.gd` extends `CombatArena` and instances
  **Kenney City Kit Industrial + Roads (CC0, OpenGameArt)** GLBs from `assets/maps/kit/`
  (`ind/` 37 buildings/props, `roads/` 10 road/prop tiles). Layout: 108 m asphalt ground,
  road cross via `MultiMesh` (32 tiles, ×6 scale), 10 buildings + chimneys/water
  tower/windmills/tanks/solar arrays (×8/×6 scale), 12 containers (×2, real-world sizes),
  fences/cones/barriers/dumpsters/poles, procedural perimeter walls, 4 BoxOccluder3Ds,
  player + 6 enemy spawns. `_kit_place()` builds per-model StaticBody3D box colliders from
  mesh AABBs (world corners → body space, model scaled outside the body). Kit import note:
  GLB texture URIs are relative, so each kit subdir carries its own `Textures/colormap.png`
  (the two colormaps differ). 3-map cycle: `GameState.toggle_map()` (IRONYARD →
  CINDER_VALLEY → FOUNDRY → …), `map_display_name()`/`map_label()`/`_build_arena()`
  extended; `Nature.setup(..., include_ground = selected_map != CINDER_VALLEY)`.
- **Weapons 18 → 27 items:** new Kinds `BEAM/FLAME/SALVO` + families ×L/M/H —
  **LUMEN** (beam: speed 320, drop 0, fast rof), **PYRE** (flame: 3 pellets, 7° spread,
  burn = `corrosion_dps`, 0.42 s life), **VOLLEY** (salvo: twin arcing shells, splash
  2.6/3.4/4.2 m). `weapon_mount.gd` builders `_build_lumen/_build_pyre/_build_volley` +
  per-kind flash tints. Splash/corrosion reuse §14's `ProjectileService` plumbing.
- **Economy:** defaults `silver = 1_000_000_000`, `gold = 1_000_000`; one-time migration
  flag `economy/grant_v11` (written by `save_settings`) bumps older saves to those minimums.
- **Hangar drag-rotate (director: "robot can't be rotated to view all sides"):**
  `Layout/Preview` now `MOUSE_FILTER_STOP` + `_on_preview_input` — drag X orbits yaw,
  drag Y moves camera height 1.2–7.0 m (touch works via mouse emulation), `DRAG TO ROTATE`
  hint label; auto-spin pauses while dragging and resumes 2 s after release with a ramp.
- **Hangar music (original, procedural):** `AudioEngine._make_menu_music()` — 16 s
  seamless loop (pad D-minor sines at integer multiples of 1/16 Hz, 2 s sub-pulse,
  8-note pentatonic pluck arp, shimmer), `MenuMusic` AudioStreamPlayer fades in via
  `AudioEngine.set_menu_music(true)` from `MainMenu._ready`, fades out on
  `Events.match_started` (`_tick_music` in `_process`). Never copies War Robots audio.
- **Preview no longer dark/cropped:** `_make_preview_environment()` uses
  `BG_SKY + Quality.make_sky()`, ambient 1.2, exposure 1.3; KeyLight 2.5 / Fill 0.9;
  camera pulled back (`ORBIT_DISTANCE 8.2`, `ORBIT_HEIGHT 3.3`, target y 1.7) so the
  metallic robot is lit by sky reflections instead of a near-black clear color.
- **Smoke 301 checks:** + catalog 27 + economy grants + LUMEN/PYRE/VOLLEY kind asserts +
  `_check_foundry_swap` (arena/roads 32 tiles/21 kit colliders/occluders) + preview
  BG_SKY + preview STOP-capture + drag hint + menu-music stream/active + FOUNDRY map
  label and toggle wrap.
- **Mech asset acquired (pending integration):** RetroStyle Games "Stylized Sci Fi Mech
  Robot Asset" (itch, free/name-your-price, royalty-free, no-AI) downloaded →
  `assets/mech_kit/` (SK_ISO_Mech.fbx: Skeleton3D + 8 LOD meshes, ~10.9×7.9×8.9 units
  native; 7 animation FBX clips idle/walk×4/landing/death; 5 PBR textures). Godot 4.4
  native FBX import works (benign first-import `Parameter "t" is null` noise; second
  import clean). Imported as game content but NOT wired to any chassis yet — integration
  target undecided (replace SCARAB/VORTEX vs third robot). Probes: `tools/fbx_probe.gd`,
  `tools/fbx_anim_probe.gd`.

---

## 16. Third robot + fourth map + commercial skyline (v0.13.0, smoke 340)

Director round 4 continuation: full scope, no content skipped, APK size explicitly
unlimited (300 MB+). Validated at **340 smoke checks** (`VALIDATION PASSED`).

- **RAMPART (third chassis, RetroStyle FBX):** `src/player/iso_mech_rig.gd` (extends
  `RobotRig`) instances `assets/mech_kit/Mech/SK_ISO_Mech.fbx` as `Group` at
  `MECH_SCALE 0.36 / MECH_Y -2.1 / yaw 180°` (native shotguns point +Z → 180 puts them
  on −Z), hides `*LOD1` meshes, dups every surface material per-instance for stealth
  alpha. Animation: 7 clips from `Animations/A_ISO_Mech_*.fbx` loaded through the clip
  scenes' own `AnimationPlayer` library, renamed `idle/walk_f/walk_b/walk_l/walk_r/land/
  death`, loop clips set `LOOP_LINEAR` + `:Root_M` position tracks stripped, state
  machine picks clip from planar velocity in rig space (WALK_REFERENCE_SPEED 3.4 /
  STRAFE 2.6), speed_scale scales with speed, `play_death()` gated for the rest of the
  state machine. Four hardpoints via the shared `_create_hardpoints` (sockets
  ±0.95/−0.3/−0.2 and ±1.3/−1.05/+0.4). `GameState.ROBOT_RAMPART` =
  Siege Brawler, 4× slot [M,M,H,H], 260 armor, speed 6.2 (×0.89), default loadout
  MAUL-M ×2 + BREACH-H ×2; `player_robot.gd` swaps rig + plays `play_death` via
  `has_method` guard; `hangar_pose_driver.gd` previews it.
- **FBX imports carry NO textures (flat-white mech bug):** `tools/mat_probe` showed
  `SK_ISO_Mech.fbx` materials (`M_Mech_LOD2/3`) arrive with every texture slot null —
  Godot 4.4's FBX importer drops the external `T_Mech_*` references. `_build_mech` now
  calls `_apply_mech_textures()` on each duplicated material, binding
  `T_Mech_Base_Color/Metallic/Roughness/Normal/Emissive.png` (metallic=roughness=1.0,
  normal on, emission energy 1.4). LOD1 surfaces get the same binding (they are only
  hidden). Smoke asserts **every** rampart surface has an albedo texture (this caught
  the LOD1 skip on first run).
- **Aim invariant (guns along forward):** hardpoint sockets are yawed `side*90°` and
  `WeaponMount` builds barrels along its local ±X (`axis := Vector3(side,0,0)`), so both
  compose to the player's `(0,0,-1)`. Verified numerically (muzzle−socket in player
  space = `(0,0,-1)` for all four mounts) and locked in smoke: `rampart mounts aim
  forward` (dot ≥ 0.99). `tools/render_views.py` now draws a green **FWD arrow** from the
  dumped player transform into every rendered view — direction checks no longer rely on
  eyeballing silhouettes.
- **DOWNTOWN (4th map, Quaternius City Kit):** `src/world/downtown.gd` — 112 m ground,
  4-way intersection at origin (Street_4Lane ×8 at ±21.35/±39.35, Asphalt_6x6 ×4
  corners), 112 sidewalk MultiMesh tiles, crosswalks/stop bars/lane arrows, 4 concrete
  perimeter walls, **11 buildings** (Large_2 ×3, Medium_2_001 ×5, Small_1 ×3), planters/
  bollards/manholes, 4 `BoxOccluder3D`s, player spawn (0,2.4,44) + 6 enemy spawns.
  4-map cycle `IRONYARD → CINDER_VALLEY → FOUNDRY → DOWNTOWN → …` wired through
  `GameState.toggle_map/map_display_name/map_label` + `GameSession._build_arena`.
  Assets: `assets/maps/downtown/` = full itch zip minus `Exports/FBX (Unity|Unreal)` and
  `Textures/Unreal-Normals` (191 MB committed; GLB textures resolve beside the glTF).
  **Triangle budget: 425,828 tris** — heavy hitters are the Quaternius buildings
  (Large_2 45k each, Medium 25.6k, Small 18.3k ≈ 73% of the map); fine for mobile with
  frustum + occluders, but re-measure with `tools/tri_probe.tscn -- downtown` before
  adding more buildings. `dump_mesh` cap raised 400k → 700k (the old cap truncated this
  map).
- **FOUNDRY commercial district:** `_build_commercial_district()` in
  `src/world/foundry.gd` — 12 `kit_commercial` backdrop towers behind the perimeter
  (face center via `atan2(-x,-z)`), offices `building-j` @ (44,20) / `building-f` @
  (−46,−8) as interior cover, 4× `low-detail-building-n` huts at (±7,∓11)/(±11,±7);
  whole kit at `COMMERCIAL_SCALE 8`. `assets/maps/kit_commercial/` = full Kenney zip
  (228 entries, 12 MB, CC0; GLBs at `Models/GLB format/` with their own `Textures/`).
- **Loadout size-string bug (fixed this batch):** Godot 4.4 `String.get_slice("-", -1)`
  returns `""` (negative slices unsupported) — `GameState.item_slot_size` and
  `WeaponData.for_item` now use `get_slice_count()-1`; previously every L/M/H item
  silently resolved as MEDIUM (VORTEX masked by all-empty fallback, RAMPART exposed it).
  Dev `settings.cfg` repaired; round-trip probe committed away after verification.
- **Smoke 340 checks:** + `_check_downtown_swap` (arena swap, 112 sidewalks, ≥11
  Building_ colliders, ≥15 kit bodies, occluders, crosswalk decals), + `_check_rampart_swap`
  (rig class/no IK legs/no tail/4 hardpoints/Group meshes/LOD cull/**all surfaces
  textured**/7 clips + loop modes/death playback/wired mounts + families/`try_fire`/**aim
  forward**/armor 260), menu map-cycle asserts FOUNDRY→DOWNTOWN→IRONYARD.
- **Visual QA (headless):** rampart 6 views + gameplay (facing correct — FBX barrels and
  mounts parallel to the FWD arrow), downtown gameplay/composition (street canyon,
  crosswalks, spawn on plaza), foundry montage (skyline outside walls, no play-field
  overlap). The white disc under the player in renders is `Ironyard/player_spawn/
  beacon` (pre-existing cyan spawn pad) — not a rig artifact. Judge PBR/texture colour
  only on device; the CPU rasterizer shows flat albedo.
- **Tools:** `tools/tri_probe.tscn -- downtown|foundry|cinder` prints per-node triangle
  budget; throwaway probes (`under_probe`, `mat_probe`, `downtown_probe`,
  `rampart_probe`) deleted after use — keep `fbx_probe`/`fbx_anim_probe`. Screenshots
  live in git-ignored `build/screenshots/` (+ `downtown/`/`foundry/` copies).
- **Build stamp:** `v0.13.0 · 2026-10-04`. Still deferred from §12–14: Blender Principled
  PBR import path, LightmapGI, VFX overhaul (muzzle smoke, dash trails, destruction),
  CINDER VALLEY layering/occlusion, paint/camo shop, drone module, pilot skills.

---

## 17. Per-robot abilities + wall climb + builtin weapons + full UI/UX polish (v0.14.0, smoke 394)

Combined delivery of everything staged after v0.13.0. Validated at **394 smoke checks**
(`VALIDATION PASSED`).

- **Layers correctness fix (root-of-many-bugs):** `Layers.ENEMY` was `3` (= WORLD|PLAYER —
  the enemy bit overlapped the world and player bits), which corrupted every bitmask test.
  Now proper single-bit powers: `ENEMY=4, PROJECTILE=8, PICKUP=16, HAZARD=32, LEG=64`;
  player body mask is `WORLD | ENEMY` (was `WORLD | PLAYER`). Smoke asserts the bit layout.
- **Ability refactor (`AbilityBase`):** shared interface (`charges/max_charges/phase_name`,
  `setup/activate/tick_vertical/is_dash_active/is_stealth_active/recharge_ratio/notify_fired/
  force_end`). `PlayerRobot.ability: AbilityBase` replaces the hardcoded `shadow_dash`:
  **SCARAB → ShadowDash** (unchanged), **VORTEX → JetJump** ("JUMP JET"), **RAMPART →
  AegisShield** ("AEGIS SHIELD": 4 s bubble, 9 s recharge, `Health.shield_mult` scales
  incoming damage ×0.15 + emissive dome). Vertical tick order each frame: ability →
  wall climb → gravity. HUD/touch phase chips read per-robot `ability_short`.
- **SCARAB wall climb:** `ROBOT_DEFS wall_climb: true` + `PlayerRobot._tick_wall_climb` —
  forward probe (`CLIMB_RANGE` 1.5 m) latches a wall, `CLIMB_SPEED` 3.4 m/s vertical
  ascent against its normal, mantle over the top edge, gravity resumes on release.
  Smoke stages a wall in front of the camera and asserts a ≥3 m rise (phases on
  `_frame == 1` — the smoke phase machine increments `_frame` *before* `match`).
- **Builtin weapons (like War Robots' fixed weapons):** `WeaponData.builtin_for_robot()` —
  SCARAB **STINGER LANCE** (BEAM, socket on the tail stinger), VORTEX **ARC NEEDLER**
  (ELECTRIC, dorsal), RAMPART **BREACH MORTAR** (BLAST splash 3.2, chest).
  `WeaponSystem.builtin` is a separate mount that fires with the normal `fire_held` loop
  (guard `mounts.is_empty() and builtin == null`, heat aggregated like the other mounts).
  Sockets built in `PlayerRobot._setup_builtin_weapon`; hangar card shows
  `ABILITY … · BUILT-IN …`.
- **Hangar navigation:** `RobotPrevButton`/`RobotNextButton` arrows cycle robots
  (`_cycle_robot_by`), slot remove lives in the Assign popup, settings panel got an
  `EXIT GAME` button (desktop quit-confirm path).
- **Full UI polish batch (WR-class pass over theme/hangar/HUD/pause):**
  - **UiTheme:** `panel()` takes an accent (3 px left edge), buttons use a cut-corner
    profile (TL/BR large, TR/BL small); popup accents — upgrade/assign AMBER, settings
    CYAN, confirm DANGER; health panel uses the HEALTH accent, restart button STEEL.
  - **Hangar:** live `LV n` / power chips in the top bar (`GameState.pilot_level()` /
    `robot_power()`), `PowerRow` (big amber value) on the robot card; settings panel
    expanded — look sensitivity, master volume, **music volume**, invert Y,
    **DAMAGE NUMBERS**, **FPS COUNTER**, **VIBRATION** toggles (all persisted).
  - **HUD:** top-centre **radar** (`RadarScope`: 55 m range sweep, enemy dots, locked
    ring), **kill feed** (3 lines, `Events.enemy_killed` + match end), **floating damage
    numbers** (camera-unprojected pop/rise/fade, `GameState.damage_numbers` toggle),
    kills row inside the timer panel, timer moved above, HP panel accent, `FpsCounter`
    chip (off by default), end panel enlarged with `REWARDS +N SILVER +N GOLD` from
    `GameState.match_reward_silver/gold` (accumulated by kill/victory/defeat payouts,
    reset with the match).
  - **Pause menu (new):** HUD MENU / ESC / gamepad pause opens a full-screen pause
    (CanvasLayer layer 40, `PROCESS_MODE_ALWAYS`) — RESUME / RESTART MATCH / GRAPHICS
    (cycles in place) / LEAVE MATCH + per-input controls hint; the scene tree pauses
    (`ProjectileService._physics_process` gated on `get_tree().paused`); inner
    `PauseInputHandler` consumes ESC to close. `Events.menu_requested` feeds it.
  - **Audio/haptics:** `Music` bus created at `AudioEngine._ready` from
    `GameState.music_volume` (menu music routed to it); `Haptics.pulse` gated by
    `GameState.vibration_enabled`.
  - **Touch:** ability button shows `SHORT ×charges` from the robot def.
- **Visual/level touch-ups:** leg thigh horns + spurs + shin hose (`LegUnit` gained a
  `sensor_material` param), Nature clouds stop casting shadows, enemy spawn markers
  nudged on all four maps (wall-stuck fixes); new probes `tools/spawn_probe` and
  `tools/uv_probe`.
- **Smoke 394 checks** (was 340): panel accent/cut-corner, music bus, power/level values,
  HUD radar (scan tracks player) + kill feed line + damage-number spawn + kills row + FPS
  chip, pause open (5 nodes + tree paused) and close (unpaused), settings panel nodes +
  damage toggle round-trip, rewards tracked after death, ability label `begins_with`
  (per-robot short name), wall-climb functional rise, builtin weapon names + wiring.
  GDScript gotchas hit this batch: `Array.pop_front()` is Variant → explicit
  `var entry: Dictionary =`; `StyleBoxFlat` per-corner radii are **properties**, not
  `set_corner_radius_top_left/individual` methods.
- **Build stamp:** `v0.14.0 · 2026-10-04`. Deferred backlog unchanged from §12–16
  (LightmapGI, VFX overhaul, CINDER VALLEY layering, paint/camo shop, drone module,
  pilot skills).

---

## 18. Single open-world map + 15-kind enemy roster + 5-minute timer (v0.15.0, smoke 401)

Director round 5: "5-minute matches", "ONE big open-world map — delete the other maps,
use ALL the asset packs (rocks/nature/roads/village/ruins/terrain/dungeon/scifi — you use
~30%)", "15 enemies with diverse robot shapes and different weapons". Validated at **401
smoke checks** (`VALIDATION PASSED`).

- **Import incident #1 (the "hang"):** first `--import` after adding the packs stalled forever
  right after `_update_scan_actions: end`, ~8% CPU, no output. Root cause: **24 `.blend`
  files** (DeadProject trees) — Godot 4.4's Blender-import support query pops a confirmation
  dialog that pumps `Main::iteration()` forever in headless. Fix: `.gdignore` in
  `assets/models/scifi/` and `assets/opengameart/` (both trees are 100 % unreferenced source
  material, 626 MB — also keeps them out of the APK). Symptom→fix table: any silent `--import`
  stall after "scan actions end" ⇒ look for `.blend`/unsupported-format queries first.
  Note: an "aborted" tool command does NOT kill its child Godot — check `/proc/*/cmdline` and
  `kill -9` before retrying, or two importers corrupt each other's run.
- **Import incident #2 (ruins DAE):** all 12 `FantasyRuins` `.dae` files fail Godot's collada
  importer (`!visual_scene_map.has(root_visual_scene)` → `valid=false`) even though the XML
  is well-formed and raw `XMLParser` reaches `<scene>` fine (probed). Blender 5.0 removed
  Collada entirely; converted with **assimp**: `assimp export <file.dae> <out>.glb` (crashes
  in `free()` AFTER writing a valid file — check glTF chunk lengths, output is fine) →
  `assets/models/ruins/glb/<Name>.glb`; `.gdignore` on `FantasyRuins_Ready/`;
  `open_realm` `RUINS` const now points at `glb/`.
- **OpenRealm (4th map, the only map):** `src/world/open_realm.gd` — 460×460 m heightfield
  (`TERRAIN_EXTENT 230`, `TERRAIN_CELLS 160`, ~51k tris), `terrain_height()` with four flat
  districts (HUB 0,34 · INDUSTRIAL 95,−70 · RUINS −95,−55 · CITY 75,85), lake basin
  (LAKE_CENTRE −90,60, WATER_LEVEL −1.6), rim ridge r>185→30 m, outer skirt r>216→−8.
  Districts consume every pack: village+roads+dungeon at hub, Kenney kit buildings +
  containers + `assets/models/scifi_props/*.glb` at industrial, ruins `glb/` at ruins
  (CathedralRuins_01 centerpiece), beach palms/docks/shells at lake, downtown gltf
  streets/buildings at city, rocks/bushes/grass/cliffs scattered (RNG seeds 20261004/777,
  `_in_district` + 55–175 m scatter band keep props off the play paths), boulders+rim.
  `src/core/util/asset_library.gd` places everything with **AABB normalization** (scale to
  target_size, origin bottom-centre, optional box collider) + `multimesh()` for repeats;
  OBJ/DAE/GLB all load through one cache. **ClimbWall** practice wall at (0,−45) added for
  the smoke's wall-climb staging ray.
- **Map removal:** `ironyard/cinder_valley/foundry/downtown.gd` deleted; `game.tscn` holds
  only Player/CameraRig/Nature/OpenRealm; `GameState.selected_map`/`toggle_map`/save-load,
  menu `MapButton`/`map_display_name`, `main_menu` map cycling and `Nature(..., distant_only)`
  rim-skip wiring (`setup(env, false, true)` — base ground/rim/hills/lake skipped) all
  removed/adjusted; `player` void check simplified to `y < -8.0`.
- **15 enemies, 4 kinds × 4 rigs × 4 weapons:** new `src/enemies/enemy_rig.gd` base
  (legs/muzzle/hull/sensor_bar, `update_animation/reset_feet/set_dead/hover_height`);
  `spider_rig` extends it; new `strider_rig.gd` (biped STALKER), `tank_rig.gd`
  (quadruped BRUTE), `drone_rig.gd` (4-rotor hover, `HOVER_HEIGHT 4.2`).
  `enemy_robot.gd` `KIND_PATTERN` cycles SCUTTLER (spider, ARACHNID SPITTER) / STALKER
  (biped, OBSIDIAN LANCE sniper, no pounce) / BRUTE (quad, FURNACE MAW ×4 pellets,
  150 HP) / WASP (legless hover, ARC TESLA = `WeaponData.for_item("VOLT-M")` ×4 pellets).
  `_configure_kind()` sets hp/speed/range/standoff/pounce/eye-height/capsule;
  `_fire_once` loops pellets; `_apply_gravity` hovers at `rig.hover_height()`.
  `GameSession._spawn_enemies` spawns exactly 15, names `%s_%02d` of kind;
  `_ground_enemies` uses `ground_offset()` per rig.
- **5-minute timer:** `hud.gd` `MATCH_LENGTH 300` / `TIMER_WARN 60` / `TIMER_URGENT 15`
  (existing countdown + TIME EXPIRED end flow unchanged).
- **Smoke 401 checks:** map-cycle/valley/foundry/downtown swap blocks removed → new
  `_check_open_realm` (arena node + terrain/water/colliders + per-pack placement asserts:
  buildings, containers, intersection, cathedral, ammo_box, palms, docks, cliff, cobble,
  bush multimeshes), `_check_enemy_variety` (15 exact, 4 kinds, 4 rig scripts, 4 weapon
  names, wasp legless+hover), `_check_match_timer` (300 s), `_arm/_verify_router_guard`
  (SceneRouter stuck-guard lifecycle across frames), damage-number spawn now aims 8 m along
  the camera axis (frame-2 camera settles behind the old point), + OpenRealm terrain
  height asserts (hub flat 1.2, lake below water, rim ~30, skirt −8) replacing the
  standalone `CinderValley.new()` block. `dump_mesh -- downtown|foundry` args removed.
- **Tools/probes:** `tools/{spawn_probe,tri_probe}.gd` de-mapped; `tools/xml_probe.gd`
  (XMLParser reachability probe) deleted after use; assimp 6.0.5 installed system-wide.
- **Deferred:** weapon FX GLBs still export EMPTY (132 B — `weapon_fx.blend` + `use_selection`
  bug, muzzle FX stay procedural), `weapon_mount` GLB body overhaul + tracer emission,
  full UI/UX polish round, LightmapGI/VFX overhaul/paint shop (§12–16 backlog). The two
  ignored trees still hold our Blender sources (`tools/export_weapons.py` reads them from
  disk — `.gdignore` does not affect Blender).

---

## 19. Meta-economy: durability, pilots, drones, specs, titan, store, combat stats (v0.16.0, smoke 560)

Director round 6 (WR-decomp research at `/tmp/opencode/wr/` — War Robots 12.4.0): six
currencies, passive drones, instant pilot training, VORTEX+RAMPART start LOCKED (SCARAB free
starter), Princeps-like titan, store. **Validated at 560 smoke checks** (`VALIDATION PASSED`).

- **Durability + Spare Parts:** armor bases SCARAB/VORTEX/RAMPART 340/430/470;
  `durability_mult_for(mk, lv)` MK1 `1.0+0.10(lv-1)` / MK2 `2.10+0.025(lv-1)` / MK3
  `2.40+0.040(lv-1)` → 2.84 max (no drop at MK transitions); upgrade cost gains parts
  `20*lv*mk` (+gold 150*mk at MK2/3); `spare_parts` currency, rewards 60/400/150
  (kill/victory/defeat), `ChipParts` hangar chip + HUD `+%d PARTS` on match end.
- **Pilots (8 defs, trained instantly for silver):** rarity 1-3 (vex/orin/sable/nyx r1,
  rhett/ilya r2, mara/kade r3), level cap 70, xp `50*level`, skill unlock levels [1,11,21,31,
  41,51,61], 7 skill tracks (hp/defense/damage/fire_rate/regen/cooldown/speed), skill cost
  `600*(lv+1)`, tier upgrades cost gold 150/250/500 → max T3 (T4 legendary), **tier damage
  mult indexed by tier: T1=1.0 T2=1.1 T3=1.2 T4=1.5** (`PILOT_TIER_MULT[tier-1]`), pilot
  XP granted post-match via `grant_pilot_match_xp()`. **PilotPopup** in `main_menu.gd`
  (PilotLine card row + PilotButton, skills train/tier buttons, mutual exclusion with every
  other popup). Exclusive assignment (`assign_pilot` clears previous holder).
- **Drones (passive orbiting companions):** 6 currencies now — +`microchips`,
  `module_points`, `platinum` (defaults 1500/40/4000, `economy/grant_v16b` one-time
  migration for older saves); 4 drones WISP (speed)/BULWARK (defense)/PATCH (regen)/KESTREL
  (damage), r1+r2 rarities, buy `200+200*rarity`, upgrade `250*rarity*lv` to lv9 with
  **break multipliers lv4→2.0, lv9→3.0**; wisp owned+active by default. **DronePopup** with
  separate BUY/EQUIP/UPGRADE rows (fixed a first-pass design flaw that merged equip+upgrade).
  `src/player/drone_orbit.gd` — 3 emissive pods orbit the player (per-drone tint), wired in
  `player_robot.gd` + `hangar_pose_driver.gd` (rebuilds orbit on robot/palette/equip change).
  Rewards: +15 chips/kill, +150/+50 victory/defeat.
- **Specializations (War Robots-style skill trees):** 4 base nodes (HULL DENSITY hp /
  TARGETING ARRAY damage / SERVO MOTORS speed / ABILITY CAPACITOR cooldown) + 4 class nodes
  per robot (SCARAB carapace/venom/swarm/phase, VORTEX titanium/arcfocus/jettanks/heavydrive,
  RAMPART bulwark/siegebrake/fieldmedic/reinforce, PRAETOR adds its own), rank 0-5, cost
  `4*(rank+1)` module points, `+1` module pt per kill, +15 victory/+6 defeat. **SpecPopup**
  green-themed. Save keys `spec` `<robot>:<node>`.
- **PRAETOR titan (4th chassis):** `SlotSize.ALPHA/BETA` (size strings A/B;
  `get_slice_count()-1` parsing), `ROBOT_DEFS` PRAETOR Siege Juggernaut 2000 HP, slots
  [A,A,B,B], speed 5.6, `builtin: ""`; ownership system `owned_robots` + `owns_robot/
  buy_robot/select_robot` (select gated, `cycle_robot`/hangar arrows skip locked, CHANGE
  ROBOT opens the store), costs VORTEX 350000 silver / RAMPART 450000 silver / PRAETOR 2500
  platinum, persistence `hangar/owned` + `owned_v16` (old saves grandfather SCARAB+VORTEX+
  RAMPART; fresh = SCARAB only; `_build_defaults` includes the PRAETOR loadout so fresh
  installs get JUGGERNAUT+HAVOC mounts). **6 titan weapons** in `WeaponData`: JUGGERNAUT-A
  (44d/480rpm), DEMOLISHER-A (95d/44rpm splash 6.5), OVERLORD-A (70d/95rpm) ×alpha;
  HAVOC-B (26d×14pel shotgun), ARCLANCE-B (20d×14pel electric+slow), CELERITY-B (22d/720rpm)
  ×beta — all platinum-priced.
- **TitanRig (`src/player/titan_rig.gd`):** extends VortexRig, **NO node-scale IK trap** —
  `_solve` compares world distances to raw bone lengths, so the rig rebuilds legs/hardpoints
  1.5× at construction (hip ±0.78/−0.15, thigh 1.875, shin 2.175, alpha (±1.08,2.16,−0.3),
  beta (±1.65,0.15,0.3)) while `chassis/head_sensor.scale = 1.5` + `_head_base ×1.5` (the
  `update_animation` rewrites positions from the bases each frame — scale the bases, not the
  positions); `_attach_heromech` is a no-op (procedural only); `_build_titan_crown` dorsal
  pylons/shoulder blocks. Player side: capsule r1.85/h4.5, rig raise ×1.5, spawn lift 3.6 m,
  camera `height_offset` 1.85, hangar preview orbit ×1.5, builtin-weapon guard (empty
  `builtin` string → no mount).
- **Titan abilities (dual):** `NullfieldAbility` (primary, 3 charges/7 s — 5 s barrier
  absorbs up to 3 hits via `Health.damaged` → full heal refund, quantum-lock jammers within
  13 m, additive cyan bubble) + `GravThrustAbility` (secondary, 2 charges/8 s — 11 m pulse:
  `EnemyRobot.apply_grav_pulse` impulse + jam 0.8 s + slow 2.5 s ×0.5, camera shake +
  haptics). New `Events.secondary_ability_requested/charges_changed/phase_changed`, input
  action `secondary_ability` (KEY_E / JOY_BUTTON_X), touch secondary button (built only when
  the robot def has `secondary`), HUD phase label shows `PRIMARY · SECONDARY`.
- **Store (`StorePopup`):** CHANGE ROBOT button opens it — robots section (SELECT/BUY rows
  with cost + affordability state) + scrolling weapons section (all 27 normal + 6 titan
  items, size badge, owned ×N, cost, BUY); `GameState.weapon_buy_cost/weapon_buy_currency/
  buy_item` (L/M/H = 25k/55k/120k silver, A = 550 plat, B = 400 plat). Wallet line +
  `Events.wallet_changed` live refresh; ESC/close ordering handled like the other popups.
- **`combat_stats()` aggregator (Phase 5 — the point of all meta systems):** multiplies
  `pilot_effects × spec_effects × drone_effects` into one dict
  {hp, defense, damage, fire_rate, regen, cooldown, speed}; wired: player `max_health`
  (×hp), `health.defense`, `_move_scale` (×speed), passive HP regen tick (0.25 s steps,
  emits `player_health_changed`), `apply_weapon_upgrades`/`apply_combat_stats` (damage ×
  fire_rate, heat ÷ fire_rate — reaches mounts AND builtins), ability `recharge_time ×
  cooldown` in every ability `_ready`.
- **Smoke 560 checks** (was 401): durability curves + parts costs/rewards, pilot API
  (8 defs/tier mults/locks/XP/assignment exclusivity), drone API (buy/upgrade/breaks/
  effects), spec API (ranks/costs/effects/restore), ownership API (strip→costs→locked
  refuse→buy→deduct→select→cycle), store API (costs/currency/denials/pool increments),
  combat_stats (all mults sane, never nerfs), `_check_titan_swap` (rig class/2 legs/no
  tail/4 hardpoints/chassis×1.5/mounts JUGGERNAUT+HAVOC/aim forward/armor 2000/capsule
  1.85/Nullfield+GravThrust activation/`secondary_ability` action), menu StorePopup +
  ChangeRobotButton, robust builtin-line assert (empty builtin allowed).
- **Build stamp:** `v0.16.0 · 2026-10-04`. Deferred backlog unchanged from §12–18 (LightmapGI,
  VFX overhaul, CINDER VALLEY layering, paint/camo shop, drone module visual variety,
  pilot portraits — pilots/drone use text rows only for now).

---

## 20. WR-scale HP + meta that matters + resource bump (v0.17.0, smoke 600)

Director round 7: "give robots and titans real hp like in war robots, they cant even last
30s", "skills + drones + pilots + specializations are useless, i dont see any difference",
"bump other resources except gold, silver". Validated at **600 smoke checks**.

- **War Robots scale:** armor bases SCARAB/VORTEX/RAMPART **340,000/430,000/470,000**, PRAETOR
  **2,000,000** (durability mults unchanged → up to ~1.4M / 5.7M maxed, WR-like). Every
  `WeaponData` damage + corrosion_dps literal **x1000** (razor 17,000; juggernaut 95,000 ...).
  Enemy HP **x1000** (45k-150k) so player TTK vs enemies is unchanged; enemy weapon damage
  **x250** (invisible stat) → ~4x longer player survival: base robot survives 60-120 s against
  the 15-enemy roster instead of <30 s. Smoke asserts: catalog damage band 3k-200k, enemy
  min HP >=40k, solo survival under perfect fire >=20 s, armor 470000/430000/2000000,
  lethal test hit raised to 1e9.
- **Regen is now a fraction of max HP/s:** pilot FIELD REPAIR 0.001/lv, drone PATCH 0.001/lv,
  spec PHASE 0.001/rank / FIELD MEDIC 0.0015/rank; `PlayerRobot` heals
  `max_health * regen * 0.25` per 0.25 s tick. (Baseline self-repair arrives in v0.18.0.)
- **Meta effects ~2x stronger** (the "no difference" complaint): pilot skills hp 2%/lv,
  defense 1.2%/lv, damage 1.8%/lv, rof 1.4%/lv, cdr 2.5%/lv, speed 1.2%/lv (descriptions
  updated); drones +1%/lv speed/damage, -1%/lv defense; specs base 2.5%/rank (hp/damage/cdr),
  1.8% speed; class nodes 2-3.5%/rank. Combined maxed ≈ +60% hp, +100% damage, +57% rof,
  +50% speed, -45% cdr. **PRAETOR got its own 4 class spec nodes** (AEGIS/SIEGE FIRE/GRAV
  COILS/CORE LOOP — spec_nodes == 8 for all four robots now).
- **Visibility:** hangar robot card **BONUS row** (`BONUS HP +x% · DMG · ROF · SPD · RESIST ·
  CDR · REP`) computed from `combat_stats()`; `GameState.fmt_amount()` K/M rendering applied
  to HUD armor, hangar ARMOR/POWER/chips, slot DMG lines, upgrade DAMAGE/DPS columns,
  floating damage numbers, end-panel damage totals.
- **Resources bumped except gold/silver** (`grant_v17` migration + fresh defaults): spare
  parts 250,000, microchips 100,000, module points 3,000, platinum 100,000. Match rewards
  x10 (kill 600 parts/150 chips/5 modules, victory 4000/1500/60, defeat 1500/500/25) plus
  **platinum match rewards** (5/50/20) with `match_reward_platinum` shown on the end panel.
- **Smoke 600 checks** (+resource mins, fmt_amount quadrants, damage band, HP scale,
  survival invariant, bonus row content, PRAETOR spec count, per-level drone magnitudes;
  power-chip assert accepts K/M). Build stamp `v0.17.0 · 2026-10-04`.

---

## 21. Director fix batch: self-repair, per-robot pilots/drones, strict weapon ownership, input feel (v0.18.0, smoke 626)

Five device-round complaints, all validated at **626 smoke checks** (`VALIDATION PASSED`):

- **Base self-repair ("every robot needs regen, eg 1000 hp/s"):** `GameState.BASE_REGEN =
  0.003` (fraction of max HP/s) seeds `combat_stats()["regen"]` — SCARAB heals
  340,000 × 0.003 = **1020 HP/s**, PRAETOR 6,000 HP/s; pilot/drone/spec regen stacks on
  top through the existing `PlayerRobot` `max_health × regen × 0.25` per 0.25 s tick.
- **Specializations "don't work":** effects were live in battle but the hangar **BONUS /
  POWER / ARMOR card rows never refreshed after a spec purchase** — `_on_wallet_changed`
  now calls `_refresh_cards()`, so ranks visibly move the BONUS row the moment they are
  bought (v0.17's ~2× effect magnitudes stay).
- **Same pilot/drone on every robot:** pilot exclusivity **removed** (`assign_pilot` no
  longer erases the pilot from other robots); drones got real per-robot assignment —
  `drone_assignments` dict + `assign_drone()` / `drone_for_robot()` (fallback to the
  global `selected_drone` for never-assigned robots), saved/loaded as `assign:<robot>`
  keys in the `drone` config section. Drone popup header shows **`<ROBOT> DRONE <ID>`**,
  ACTIVE/EQUIP state is per selected robot, toast says `EQUIPPED TO <ROBOT>`, preview
  orbit rebuilds on equip (`drone_orbit`, `hangar_pose_driver`, `player_robot` all read
  `drone_for_robot(selected_robot)`).
- **Weapon stacking / ownership:** `inventory` is now **total owned** (spares + mounted)
  — one-time `economy/strict_v18` migration adds every loadout copy into the pool on
  first boot (`_migrate_ownership`, idempotent). `equip_item` requires a free copy
  (`pool − equipped_count ≥ 1`) and **no longer mutates the pool**; `unequip_item`
  returns the weapon to storage without changing totals. WR-style duplicates are legal
  when you own the copies (4× RAZOR-M stacks are smoke-tested), the Assign list hides
  items with 0 free copies and shows accurate `STOCK`, and **changing a slot's weapon
  type erases that slot's MK/lv upgrade track** (no more MK3 bleed onto a swapped gun).
- **"Firing/abilities too unresponsive":** (1) the right-side **quick-tap = ability**
  shortcut in `InputRouter._unhandled_input` is removed — look-zone taps no longer fire
  DASH mid-aim (buttons/key/pad unchanged; drag-to-look untouched); (2) RAZOR
  overheat softened — `cooldown_rate` 0.34→0.40, M `heat_per_shot` 0.05→0.052 →
  duty cycle ~8.5 s fire / ~1.0 s cool-down (was ~5.6 s / 1.2 s), smoke pins the net
  heat rate to (0, 0.15)/s; (3) fire press/release and ability-button paths are asserted
  frame-immediate in smoke.
- **Smoke 626 checks** (was 600): ownership/stacking block (`_check_inventory_api` —
  4× same weapon, refusal at 0 free copies, upgrade reset, pool-stable unequip),
  `_check_input_responsiveness` (tap emits no ability, drag still looks, fire +
  ability press/release immediacy), pilot-sharing assert (exclusivity inverted),
  per-robot drone assignment + effects, `BASE_REGEN` ≥ 1000 HP/s on SCARAB, gentle
  overheat window; drone test now saves/restores `drone_assignments`.
- **Build stamp:** `v0.18.0 · 2026-10-04`. Still open from §16–18: white RAMPART blob on
  device, WR-shaped drone pods, PRAETOR Princeps-grade visual rebuild, LightmapGI/VFX
  overhaul, CINDER VALLEY layering, paint/camo shop.

---

## 22. Princeps GLB rebuild + shaped drones + RAMPART hardening (v0.19.0, smoke 678)

Director round 8: *"yr titan is no where similar to princeps, its so fake and luke forgged,
search online i want real robots not stupid toys"* — plus the §16–18 backlog items for white
RAMPART and box drones. Validated at **678 smoke checks** (`VALIDATION PASSED`).

- **Princeps research:** Princeps is a real War Robots **Titan** (warrobots.com/en/robots/123):
  DSC Corporation bipedal assault titan, "sacrifices hull durability for firepower and
  mobility"; abilities **NULLFIELD** (stasis barrier + quantum lock) and **GRAV THRUST**
  (gravitational knockback) — our mechanics already matched, only the visuals were fake
  (PRAETOR was VortexRig primitives ×1.5). Reference image: fandom
  `Princepstitan.png` (curl needs a browser User-Agent + fandom Referer or Cloudflare
  answers; saved `/tmp/opencode/ref/princeps.png`, actually WEBP 718×930).
- **`tools/build_princeps.py` → `assets/mech/princeps.glb`** (Blender 5.0.1, 44 objects /
  **16,102 tris**) reusing `build_mech.construct`: original Princeps-genre biped — long
  digitigrade legs (bone lengths **must equal TitanRig**: coxa 0.48 / thigh 1.875 /
  shin 2.175, hips ±0.78/−0.15), compact angular torso, glacis prow, **wide clavicle deck
  with twin shoulder cannon pods** (muzzle rings at the alpha sockets ±1.08/2.16/−0.3),
  hip sponsons around the beta sockets (±1.65/0.15/0.3), dorsal spine stack, rear
  thruster nozzles + exhausts, low sensor head. Naming contract unchanged
  (`chassis__*`/`head__*`/`l<d><c|u|l|f>__*`; `gun*` skipped). Built at **final titan size**
  (no runtime node scale).
- **`TitanRig` wired to the GLB:** `glb_path()` → `PRINCEPS_GLB`; the `_attach_heromech`
  no-op override is gone (procedural chassis/head/crown are built then freed by the shared
  attach path — same flow as VORTEX); `chassis.scale`/`head_sensor.scale` ×1.5 **removed**
  (GLB is full-size; `TITAN_SCALE` now only multiplies `_head_base` and the spawn raise).
  `_build_thrusters` overridden with titan flame positions (±0.66, 0.78, 1.14, scale ×1.5) —
  the procedural pods/nozzles were always freed on attach, so the GLB carries the nozzles.
- **Drones are shaped now** (`drone_orbit.gd` rewrite): pods are `Node3D` containers with
  ≥6 mesh children each — **WISP** sleek dart + swept wings + Nose, **BULWARK** armoured
  core + front Shield + skirts, **PATCH** slim core + instrument pods + Antenna,
  **KESTREL** attack dart + forward-swept wings + Spike. Body is non-emissive dark metal;
  only wings/accents + Eye carry the per-drone tint (eye emissive 3.4).
- **RAMPART white-blob hardening** (`iso_mech_rig.gd::_apply_mech_textures`): albedo tint
  `0.86,0.84,0.82` (was WHITE), `metallic` 1.0→**0.6**, `roughness` 1.0→**0.9**, emission
  tinted warm `(1.0,0.6,0.4)` at energy 1.4→**0.7** (worst case — texture failing to bind
  on device — is now a warm glow instead of a full-white emissive shell).
- **Smoke 626 → 678 checks:** `_check_titan_swap` no longer asserts `chassis.scale == 1.5`;
  it now proves the GLB attached (`chassis__*` ≥4, `head__*` ≥4, `l*` leg meshes ≥10).
  New `_check_drone_shapes()` builds an orbit for all four drone kinds and asserts each of
  the 3 pods has ≥6 meshes, an Eye, and its per-kind marker (Nose/Shield/Antenna/Spike) —
  temporarily grants drone ownership and restores `owned_drones`/`drone_assignments`/
  `selected_drone` afterwards. `_check_rampart_swap` gained a **hardened** assert
  (metallic ≤0.75, albedo ≠ WHITE, emission energy ≤1.0 on every Group surface).
  `dump_mesh.tscn` accepts `-- titan|praetor`.
- **Incident:** a failed first run errored on `owned_drones = PackedStringArray(...)` (the
  property is an Array) **before** the restore, and later `save_settings()` persisted the
  leaked ownership → dev `settings.cfg` repaired (drone section back to wisp-only).
  Lesson: smoke mutations must restore with the same type (`= []` + `append` loop).
- **Visual QA:** `dump_mesh -- titan` + `render_views.py` (7 PNGs) — Princeps silhouette
  confirmed: shoulder pods + forward barrels, dorsal spine, twin thrusters, plated
  digitigrade legs, clawed feet. Note: the grey untextured slabs in the renders are world
  kit props without a material override in the CPU rasterizer, not robot artifacts.
- **Build stamp:** `v0.19.0 · 2026-10-04`. Still open from §12–18: on-device white-RAMPART
  confirmation (needs hardware), LightmapGI/VFX overhaul, CINDER VALLEY layering,
  paint/camo shop, PRAETOR portrait/hangar art.

---

## 23. RAMPART white-blob hotfix: bulletproof material binding (v0.19.1, smoke 678)

Director round 9: *"3rd robot still white , not real like asset i gave u"* — the v0.19.0
tint/emission retune had not settled it on device. Diagnosis first, then all binding
branches made explicit:

- **Pipeline verified before changing code:** the v0.19.0 APK contains all five
  `T_Mech_*.png` lossless `.ctex` + `SK_ISO_Mech.fbx` `.scn`; raw FBX probes white and
  untextured (expected — binding is ours); a new headless `tools/rig_probe.tscn` probes
  the *built* rig and shows every surface textured post-`_build_mech`; Pillow stats:
  Base_Color brown (mean 95,66,62), Emissive ~99 % black (mean 3.7), Metallic/Rough
  grayscale, Normal tangent-space. Device white therefore had to come from a
  material-state hole, not missing APK content.
- **Three silent holes closed in `iso_mech_rig.gd`:**
  1. `_build_mech` `continue`d past any surface whose material was null or not a
     `StandardMaterial3D` — that surface kept the FBX default material (plain white)
     and the smoke loop skipped it too, so no assert could ever see it. Every surface
     now receives a duplicated-or-fresh `StandardMaterial3D` override (null-guarded
     `duplicate()`).
  2. `_apply_mech_textures` only wrote properties *when textures loaded* — a failed
     `load()` on device leaked **inherited FBX emission/metallic/vertex-colour state**
     (white emissive glow was the prime suspect). Now both branches write every
     property: albedo tint `Color.WHITE` with the texture (asset colour fidelity; the
     old 0.86 grey tint desaturated the paint), red fallback without; metallic
     0.6/0.25 (+tex or nulled), roughness 0.9/0.85, normal enabled only when bound,
     `emission_enabled` only when BOTH textures bound (white × energy 1.0 on the
     near-black emissive map — eyes/vents only) and hard-disabled otherwise,
     `vertex_color_use_as_albedo` forced off.
  3. Textures loaded once via `_load_mech_textures()` and cached (was five `load()`
     calls per surface).
- **Smoke hole closed (`_check_rampart_swap`):** `surfaces_checked` now increments
  *before* the null/non-Standard skip, so a skipped surface fails both
  `textured == surfaces_checked` and `hardened == surfaces_checked`. Hardened is now
  *textured* ∧ metal ≤ 0.75 ∧ emission-safe — the anti-white proof is the bound
  texture, so v0.19's `albedo_color != WHITE` requirement is dropped to allow the
  WHITE tint.
- **On-device proof:** the debug overlay already prints `TEX n/n` from
  `texture_report()` when the rig is an `IsoMechRig` — one screenshot of the overlay
  states whether binding succeeded, no logcat needed.
- New probe `tools/rig_probe.{gd,tscn}` (probes the *built* rig; `fbx_tex_probe`
  covers the raw FBX). Validated **678 checks, 0 failures**;
  `BUILD_LABEL = v0.19.1 · 2026-10-05`.

---

## 24. Robot realism pass: PBR paint, military palettes, worn-panel textures (v0.20.0, smoke 694)

Director: *"after u fully enhance and polish robots to look realistic like ones of war
robots"*. Audited all four robots first (`dump_mesh` + `render_views` per robot, plus a
new texture dump), then fixed the three systemic "toy" causes:

- **Root causes found:** painted armor was authored at metallic 0.9–1.0 (everything read
  as raw gold metal instead of painted plate), the default AURUM palette was a flat
  gold-tan, and `PanelTextures`' armor map was a uniform 0.92 near-white 32 px grid with
  no wear — nothing about the materials said "military machine".
- **PanelTextures v2** (rewrite, 192², kinds `armor`/`steel`/`rubber`/`hazard`):
  - `armor`: variable panel layout — 48 px cells with hash-gated seams (62 % of edges →
    irregular panel rects), seam grooves, corner rivets, per-panel tonal variation
    (0.86–1.0), diagonal scratch streaks that reveal bare metal (albedo 1.0 / rough
    0.3), vertical dirt streaks (×0.68 albedo / rough 0.95), edge-wear halos along
    panel seams (×1.14 albedo / −0.15 rough)
  - `steel`: brushed grain + scratch streaks + grooves; `rubber`: ribs + grain;
    **new `hazard` kind**: 45° stripes (0.98/0.2) with worn-through chips + grime
  - each kind ships albedo + roughness + normal; smoke samples the armor albedo and
    asserts the seam-to-wear span (min ≤ 0.45, max ≥ 0.95)
- **PBR paint values (`robot_rig._make_materials`):** painted armor metallic 0.95 →
  0.15–0.25 with roughness 0.45–0.62; joints rubber metallic 0 / rough 0.85; trim stays
  bare steel 0.95/0.35; recess 0.5/0.8. Same treatment on all four enemy rigs
  (spider/strider/tank/drone painted shells 0.75–0.9 → 0.15–0.25 metallic; trims stay
  metal or become painted accents per rig).
- **Military palettes** (`palette_colors`, same 5 names/indices, retuned): AURUM desert
  sand / gunmetal / hazard amber, MAGMA rust / iron / hot orange, VERDANT olive /
  charcoal / lime, GLACIER arctic steel / navy / ice cyan, NOCTURNE black / gunmetal /
  crimson — every secondary strictly darker than its primary (smoke-asserted).
- **Incidents fixed this batch:** (1) the titan render cycle silently lost its output —
  the first loop's `mkdir` created `praetor/` while the loop copied into `titan/` (cp
  failed, `rm` deleted the renders); (2) **`liquid_cell_broken.glb` is a 132-byte corrupt
  export** (`valid=false` → "Failed loading resource" on every game start) —
  `open_realm` now places `cage_cylindric.glb` at that spot; (3) export preset now
  `exclude_filter="tools/*,build/*"` — screenshots/dumps were shipping (23 entries) in
  the APK.
- **Verified:** all GLB mech primitives carry `TEXCOORD_0` (108/42/44 prims hero/vortex/
  princeps) so panel textures actually map on SCARAB/VORTEX/PRAETOR; `tools/tex_dump`
  saves the four kinds to `build/tex_*_{albedo,rough,normal}.png` for visual review
  (armor shows seams/rivets/dirt streaks, hazard shows worn stripes); palette change
  confirmed in the dump (`new_primary` 288 verts, `old_primary` 0); renders re-taken for
  scarab/vortex/titan.
- **Smoke 678 → 694 checks:** new `_check_material_realism` (armor PBR set builds,
  192 px albedo, seam/wear span, hazard kind, 5 palettes × 3 tones with darker
  secondary, painted armor ≤ 0.35 metallic, steel trim ≥ 0.9 metallic).
- Note unchanged: the CPU rasterizer shows flat albedo only — texture/wear/lighting are
  judged from `build/tex_*.png` and on-device runs. `BUILD_LABEL = v0.20.0 · 2026-10-05`.
  Still open from §12–19: LightmapGI, VFX overhaul, CINDER VALLEY layering, paint/camo
  shop, PRAETOR portrait/hangar art; the `hazard` texture awaits a Blender material slot
  pass before it can appear on mech geometry.

---

## 25. Combat presentation + sound overhaul + per-kind enemy labels (v0.21.0, smoke 714)

Director round 10: plain weapon shapes/sounds ("an electric gun doesnt look like an electric
strike"), "hangar music is so plain", "all enemies labelled arachnoid yet some aint" — plus
this session's earlier items (10-minute timer, spawn separation, hangar refresh order, leg
X-formation fix) already validated at 698. Validated at **714 smoke checks**
(`VALIDATION PASSED`). **No project files were deleted this batch** — only source edits.

- **Signal plumbing:** `Events.weapon_fired(mount_index, kind)` and
  `Events.weapon_impact(point, normal, kind)` now carry `WeaponData.Kind`; emitters in
  `weapon_mount.gd` (`data.kind`) and `projectile_service.gd` (`projectile.weapon_kind()`);
  listeners `audio_engine._on_weapon_fired/_on_weapon_impact`, `combat_fx._on_weapon_impact`,
  `game_session._on_weapon_fired_haptic` all take the kind parameter.
- **CombatFx per-kind impacts:** ELECTRIC → 7-shard arc burst (unshaded cyan boxes aligned by
  `MeshUtil.segment_basis`, tweened shrink) + blue flash, no scorch; BEAM → cyan flash +
  sparks only; CORROSION → green sparks/flash; default path unchanged. `_spawn_flash` takes an
  optional colour. Arc shards guard the colinear `look_at` up-vector.
- **Audio (all original, procedural `AudioStreamWAV`):** 7 new family sounds — `_make_zap`
  (swept carrier + gated crackle), `_make_rail` (rising whine → supersonic crack + sub thump),
  `_make_launch` (rising low-pass whoosh + pop), `_make_hiss` (tremolo spray), `_make_beam`
  (downward sweep + shimmer), `_make_flame` (brown-noise puff), `_make_thump` (deep pop +
  clank); `_on_weapon_fired` routes by `WeaponData.Kind`; cannon/scatter got sub-thump/tail
  and bright transient respectively.
- **Music v2 (`_make_menu_music` rewrite):** original 16 s seamless loop in D minor
  i–VI–III–VII (Dm/Bb/F/C) — detuned pad stack with 0.3 s chord-edge crossfades (loop seam
  silent), eighth-note bass pulse, four-on-the-floor kick + offbeat hats, 16th arp with
  0.25 s echo; all patterns O(1) per-sample lookups (no per-sample event loops).
- **Electric strike visuals (`projectile.gd`):** `weapon_kind()` accessor; electric rounds get
  6 lazily-built jagged arc segment boxes (`ARC_SEGMENTS`, refreshed every advance, hidden on
  deactivate), thinner core tracer and emission energy 5.0 (pool default 3.5); non-electric
  behaviour unchanged.
- **Weapon shapes (all 9 `_build_*` in `weapon_mount.gd`):** original WR-inspired detail —
  autocannon heat-shroud/feed chute/sight rail/brake vents, scattergun shell ring+pump
  grip+choke rings, electric electrode prongs + tesla balls + bus blocks, magnetic rail
  spine/cell bank/prong tips, breach spare shells/launch rail/blast shield, ferric tank
  straps/hose chain/gauge, lumen lens cone/vent fins/glow strips, pyre igniter electrodes/
  carry handle, volley 2×3 tube rack/targeting block.
- **Enemy labels:** `EnemyRobot.kind_label()` → ARACHNID (SCUTTLER spider) / STALKER /
  BRUTE / WASP; `enemy_markers.gd` uses it at creation and for the `LOCK //` tag (was
  hardcoded "ARACHNID" for all 15).
- **Smoke 694 → 714:** +9 family sound ids, +2 signal-listener counts, +2 electric-launch
  checks (VOLT-M fires; active electric projectile has 6 arc children), +1 four-distinct-
  labels assert. Gotchas hit: Variant array index can't be `:=` inferred (`var chord: Array`);
  `MeshUtil.add_visual_cone` has no rotation param (use `cone_at`); Godot 4.4 renames
  duplicate sibling node names to `@MeshInstance3D@N` — count arc children as "everything
  except `tracer`", not by name prefix.
- **Build stamp:** `v0.21.0 · 2026-10-05`. Still open from §12–20: LightmapGI, VFX overhaul,
  CINDER VALLEY layering, paint/camo shop, PRAETOR portrait/hangar art, on-device
  RAMPART/lighting confirmation.

---

## 26. Paint hotfix + drone companion + drone-owned healing (v0.22.0, smoke 728)

Director round 11 (three interjections between v0.21.0 and this release): paint cards
"broken"/version never changed, full drone rework ("1 drone not 3 … own scaled-down builtin
weapons … not just orbiting … search how drones work in war robots"), and "drones are the ones
to be healing the robot, not robot healing itself 10000 hp/s out of a blue … each drone should
have percentage it can heal robot eg 12% when health is so critical". Validated at **728 smoke
checks** (`VALIDATION PASSED`).

- **Paint card-overflow fix (validated 719/0 before the drone batch):** hangar robot-card
  contents overflowed the popup (`CARDS`/`get_combined_minimum_size().y` window) → `CardScroll`
  container + `_ensure_card_visible`. The persistent "click does nothing" report was a **smoke
  artifact**: only in the smoke tree do the game scene's `CanvasLayer`s (HUD/death panel) render
  above the plain menu `Control` and swallow the synthetic mouse click. Smoke now hides every
  `CanvasLayer` around `push_input` (restored after) and the failure message carries
  rect/screen/window sizes; `tools/layout_probe.{gd,tscn}` kept as a standalone rect prober.
  Device menus never coexist with the game scene — the bug never reproduced on hardware.
- **Drone companion rewrite (`src/player/drone_orbit.gd`):** ONE drone (not 3 orbiting pods)
  that flies in formation (side 2.6 / fwd 0.4 / height 2.3, follow 9 m/s, bob), **repositions
  behind the host** when the nearest live enemy drops below `BEHIND_DOT` −0.15 (rear-guard
  lerp; weight exposed as `rear_guard_weight`), and **fires its own scaled-down builtin
  weapon** — retarget 0.2 s with LOS ray (WORLD|ENEMY, exclude host, clear unless collider ==
  target), `Projectiles.fire`, `Events.weapon_fired.emit(-1, kind)` (`game_session` skips host
  haptics for `mount_index < 0`; audio still plays). Each drone carries exactly one fixed
  weapon ("dtone has to be with one weapon each") via new `WeaponData.drone_for()` /
  `drone_fire_range()`: WISP ARCSTING electric 1500d/300rpm, BULWARK CRYOSHARD BLAST 2600d
  splash 2.8/75rpm, PATCH EMBERWIND FLAME 350×3pel/380rpm, KESTREL SWARMLINE autocannon
  1100d/540rpm (`DRONE-<KIND>` ids; range patch 14 / bulwark 34 / kestrel 36 / default 30).
  Guards: `target_is_dead()` validates the Variant before any cast; `weapon`/`target`/
  `shots_fired` exposed for smoke. Hangar preview still works (host is not a `PlayerRobot` →
  formation only, no firing/healing).
- **Supporting plumbing:** `projectile.gd weapon_item_id()`; `projectile_service.
  active_player_count()` (excludes `DRONE-` prefix) so smoke's player-only tracer asserts stay
  deterministic while the drone shoots; `enemy_markers.gd` freed-object fix (check
  `is_instance_valid` on the Variant BEFORE casting, else erase the marker + `queue_free` root).
- **Healing ownership (the "10000 hp/s out of the blue" fix):** WR research — Starter drone
  "On Mild Damage: Fix" (15k instant on >70k dmg in 5 s, 5 s cd), Glider "After Phaseshift:
  Fix" 10–30 % + 20 s cd, D-type chips "On Low Durability: Fix %"; Mender/Weyland repair caps
  below 100 %. Changes: **`GameState.BASE_REGEN 0.003 → 0.0`** — robots never self-repair from
  thin air; healing comes only from drones, pilots and specializations. Every `DRONE_DEFS`
  entry gains a **`heal` burst percentage** (WISP/KESTREL 8 %, BULWARK 12 %, PATCH 15 %) driven
  by `drone_orbit._tick_emergency_repair()`: host HP ≤ 30 % of max (`HEAL_TRIGGER`) → drone
  restores `heal% × max_hp` **at once**, then rests 18 s (`HEAL_COOLDOWN`, re-fires while still
  critical). Emits `Events.player_health_changed` (HUD bar jumps); PATCH keeps its passive
  field repair, pilot FIELD REPAIR / spec PHASE / FIELD MEDIC regen untouched (director-
  sanctioned sources). DRONE_DEFS descs + hangar hint now say "emergency repair at critical HP".
- **Smoke 714 → 728:** phase-9 tail — stage player to 20 % HP (`_stage_drone_heal`), assert
  burst delta within 10 % of the ACTIVE drone's expected heal (`_check_drone_heal`), stage
  again 5 frames later and assert ≤1 % delta (`_check_drone_heal_cooldown`);
  `_check_combat_stats_api` asserts `BASE_REGEN == 0.0`; `_check_drone_shapes` asserts each
  drone's `heal_percent()` (0.08/0.12/0.15/0.08). Diagnostics kept: `DRONE_STAGE`,
  `DRONE_DEBUG f20/f84`, `DRONE_HEAL burst` prints. Drone-phase determinism lessons: spawn
  count (==15) asserted at phase 0 with late variety relaxed to 1..15 (the drone kills
  enemies mid-run), staged threat **healed to full** (a dead threat zeroes
  `rear_guard_weight` → dz failure), host facing snapped, shots measured as a delta.
- **Version guard:** project/export/BUILD_LABEL moved together 0.21.0 → **0.22.0** (code 22);
  `tools/validate.sh` still enforces equality (the "version never changed" report).
- **Build stamp:** `v0.22.0 · 2026-10-05`. Still open from §12–18 + director: living-map
  overhaul (drowning DoT with scorpion-dash exception, rain/snow/wind/lightning, erupting
  volcano/magma/fire rocks), Omen-Fang-style SCARAB dash (research done: Sandcloak dash +
  speed + stealth, EMP + Rust cone on break), LightmapGI/VFX overhaul, paint/camo shop,
  PRAETOR portrait/hangar art.

---

## 27. Living map: liquid hazards + weather + eruptions + Omen-Fang dash (v0.23.0, smoke 758)

Director round 12: *"everything fucking real like a real game"* — fake lake you can walk
through, drowning DoT with the scorpion-dash exception, thunder/sun/rain/snow/wind, erupting
mountains, flowing magma, fire rocks that damage robots. Validated at **758 smoke checks**
(`VALIDATION PASSED`).

- **Liquid hazard registry (`src/core/util/hazard_zones.gd`, class_name `HazardZones`):**
  static `zones: Array[Dictionary]` (`centre: Vector2, radius, level, dps, kind`),
  `clear/add/zone_at/is_hazard`; a zone bites when horizontal dist ≤ radius AND
  `y < level + 0.4`. Registered per arena build (`OpenRealm._register_hazards`): lake
  (LAKE_CENTRE −90/60, r44, level −1.6, **4 % max HP/s**) and the new **magma basin**
  (MAGMA_CENTRE 110/−130, r30, level −0.5, **7 % max HP/s**).
- **Magma basin (new landmark):** `terrain_height` carves `−9·exp(−d²/1600)` after the lake
  line (centre ≈ −8 m, below MAGMA_LEVEL; INDUSTRIAL flatten untouched, 61.8 m away);
  `_build_magma()` = 64 m emissive-vein shader plane (animated `EMISSION` cracks), orange
  `MagmaGlow` omni (energy 2.6, 60 m), 14 rim boulders; the three wilderness prop loops +
  village-prop loop skip `MAGMA_CENTRE < 38 m` (lake skips unchanged). Verified smoke-side:
  basin `< −2.0` at centre.
- **Real water shader (`RealmWater`, 92 m plane):** Gerstner-style summed sine+value-noise
  waves in vertex with finite-difference analytic normals; fragment reconstructs scene depth
  from `hint_depth_texture` (reversed-Z ndc → `INV_PROJECTION_MATRIX`) for depth-tinted
  colour, **shore foam** (`1 − smoothstep(0, 1.7, depth)`), crest foam, fresnel sparkle, and
  a `rain_strength` uniform for storm ripples (set by WeatherSystem through the `"water"`
  group). Registered by `water.add_to_group("water")`.
- **Drowning / float / swim (`PlayerRobot._tick_hazards` after `move_and_slide`):**
  accumulator `dps·max·delta ≥ 1.0` → `health.apply_damage` + `player_health_changed` +
  `damage_applied` (no per-tick shake); wade drag (5 m/s²) at depth > 0.5; buoyancy
  `velocity.y ≥ 4.0` at depth > 0.9 so the head floats; **Omen-Fang exception** — while
  `ability.is_dash_active()` the robot clamps to `level + 0.35`, takes **zero** drown damage
  and skips the sink. Entering/leaving emits `Events.hazard_changed(kind)` → HUD `! WATER`
  / `! MAGMA` chip (`HudLayer/Hud/HazardChip`). Enemies drown too (`EnemyRobot._tick_hazard`
  acc → `receive_damage`, DEAD-guarded, AI-off spawns never sit in zones). Void check
  simplified to `y < −8.0`.
- **Omen-Fang dash buff (`shadow_dash.gd`):** research = WR Sandcloak (dash + speed, stealth,
  EMP+Rust cone on break, 2 charges/24 s): ours dash_distance 14→**30**, duration 0.4→**1.5 s**,
  dash_speed 20→**26**, stealth 4.5→**6.5 s**; `tick_vertical` now returns true while dashing
  **over a hazard zone** (clamps y, kills downward velocity — the scorpion glides across
  water AND magma); `_read_input` defaults `wish = (0, 1)` while dashing with no stick so the
  long dash keeps its speed (old code decayed the wish to zero in 0.1 s).
- **Weather (`src/world/weather_system.gd`, class_name `WeatherSystem`, child of `Nature`):**
  CLEAR 40–70 s → RAIN 30–45 s → CLEAR → SNOW 25–40 s (first state always CLEAR = smoke
  determinism); one **drifting cell** (90×32×90 m box, wraps at ±210, vel 6.5/4.5 m/s) so only
  parts of the realm get precip; rain = 900 tilted thin-box CPUParticles (20–28 m/s), snow =
  550 slow spheres with wind gravity; env modulation through `Nature.set_ambient_level`
  (RAIN ×0.62, SNOW ×0.82 — lightning pulses restore to the weather level, not the old base),
  fog on at 0.016/0.01; `Nature.wind_scale` 1.0→2.3/1.5 speeds cloud drift; lake gets
  `rain_strength = 1.0`; looped synth rain-patter + wind-howl `AudioStreamWAV`s (seamless
  integer-cycle LFO); RAIN schedules `nature.strike_lightning()` every 5–9 s (public wrapper).
  `force_state("rain"|"snow"|"clear")` + `state_name()` for smoke.
- **Volcano (`src/world/volcano_activity.gd`, class_name `VolcanoActivity`, child of `Nature`):**
  first eruption at 48–60 s (smoke ends ≈ 6 s → deterministic), then every 45–70 s for 7 s:
  lava fountain (170 emissive chunks, gravity −22), crater light 4→9.5, three **lava-flow
  ribbons** down the cone (SurfaceTool strips with UV scroll shader, glow 0.7→2.4), looped
  brown-noise rumble, `camera_shake_requested(0.7, 0.6)` + `boom`; launches **8 fire rocks**
  on ballistic solves (`v0 = Δ/T + gT/2`, T 3.6–4.6 s, g 22) from the crater (165/88/−195) to
  targets r 60–150 (ground ray, WORLD mask); each landing calls public `impact_at(point)` →
  `weapon_impact(BLAST)` (CombatFx scorch/sparks reuse), smaller shake + `boom`, and AoE
  **7 % max HP within 8 m with linear falloff** to `group "enemy"` + the player (`group
  "player"` newly added in `PlayerRobot._ready`). Public `force_eruption()` for smoke.
- **Smoke 728 → 758:** new **phase 10** (renumber death 10→11, menu 11→12): drown while held
  in the lake (`_hold_in_lake(true)` clamps y −2.5 each frame — buoyancy would otherwise bob
  the test out of the zone) → assert loss > 1000, signal `WATER`, HUD chip visible; activate
  dash, hold x/z only for 47 frames → assert `is_dash_active`, loss ≤ 1 %, y ≥ level − 0.1;
  `force_state("rain")` → assert RAIN/emitting/wind ≥ 2/ambient < 0.8×/shader param;
  `force_state("clear")` → wind 1.0; `force_eruption()` → fountain emitting + rocks ≥ 1;
  `impact_at(player)` → loss ≥ 5 % max HP; cleanup heals, clears rocks + eruption, purges
  damage numbers (`DamageNumbers.clear_entries()` new — menu-phase manual spawn must start
  from zero, else a fresh drone-kill number makes `== 1` flaky). `_check_open_realm` += 17
  asserts (RealmMagma, water shader `hint_depth_texture`/`rain_strength`, magma `EMISSION`,
  zones == 2 with kinds water/magma, hub hazard-free, basin carve, Nature children).
  Prints kept: `DROWN`, `DASH_FLOAT`, `VOLCANO`.
- **Incidents:** (1) new class_names invisible until `--import` re-registers
  `global_script_class_cache` (`Identifier HazardZones/WeatherSystem/VolcanoActivity not
  declared` on first smoke run — run import after adding any `class_name`); (2) damage-number
  `== 1` failure diagnosed as post-purge drone-kill number (player-target hits are ignored by
  `DamageNumbers`, enemy hits are not).
- **Build stamp:** `v0.23.0 · 2026-10-05` (project/export/BUILD_LABEL moved together, code 23).
  Still open from §12–16 + director: **ZEPHYR flying robot to replace RAMPART** (Anaksor
  research done: 1H+2M, Sirocco Field 13 s/14 s cd with damage-triggered invisibility charges,
  ability-gated built-in machine gun with burst overheat; dragonfly/Blue-Dasher silhouette),
  **touch-controller restyle + richer functionality** ("too fake and basic"), LightmapGI/VFX
  overhaul, paint/camo shop, PRAETOR portrait/hangar art.

---

## 28. ZEPHYR flying robot replaces RAMPART (v0.24.0, smoke 761)

Director: *"create a differnt one to replace [the white 3rd robot], it should be a flying robot
like anaskor robot in war robots almost exaclty and all its abilities, and should have x1 heavy
x2 medium slots + 1 builtin weapon just like real anaskor"*. Anaksor research (§27) reused.
Validated at **761 smoke checks** (`VALIDATION PASSED`).

- **Internal id deliberately kept `&"RAMPART"`** — ownership, loadouts, upgrade keys
  `RAMPART:<slot>`, pilot/drone assignment, spec keys and the 450 000-silver store row all stay
  save-compatible (no migration, zero save-corruption risk); only the display `"name"` is
  **ZEPHYR** (class "Aerial Raider"). `iso_mech_rig.gd` + `SK_ISO_Mech.fbx` stay on disk
  (no-deletion rule) but are unreachable from `ROBOT_DEFS` (`game_session` texture-report branch
  is inert). Anaksor's Sirocco/invis/builtin mechanics are implemented under **original names**
  (never WR's): ability **GALE VEIL** (short `GALE`), builtin **WINDCUTTER**.
- **Def (`game_state.gd`):** slots `[MEDIUM, MEDIUM, HEAVY]` (1H+2M), armor **380 000**
  (squishier raider), speed 7.4 × speed_scale **1.05**, `flyer: true`, `builtin_gated: true`,
  default loadout `RAZOR-M ×2 + MAUL-H` (Anaksor's 2×med autocannon + heavy shotgun family).
  Old 4-entry saves remain valid — `filled_slots`/mounts consume the first 3 entries and the
  sizes line up (M/M/H). Spec display names air-themed (ids unchanged): AEROPLATE,
  STORM CANNONS, REPAIR NANITES, DENSE FRAME.
- **`ZephyrRig` (`src/player/zephyr_rig.gd`):** GLB `assets/mech/zephyr.glb` built by
  `tools/build_zephyr.py` (Blender 5.0.1, 33 objects / **8042 tris**, `build_mech.construct`)
  — thorax + ringed drooping abdomen loft, compound-eye sensor head, 4 swept/dihedral wings on
  pod hinges (`wing0..3` tags), chin antennae, nacelles, 4 down-thruster bells, dorsal H
  pedestal. No legs, no tail; anchors `Chassis`/`HeadSensor`/`Wing_0..3` + `_build_hardpoints`
  **3 sockets** (±0.9,1.3,−0.35 sides ±1; 0,1.9,−0.5 centre side 1 → all aim forward).
  **`_glb_target` override maps `wing<d>__*` → wing nodes** (base returns null for them —
  without the override the wings silently never attach). Wing flutter in `update_animation`
  (super first, then ±5–8.5° Z-flap, phase-offset fore/aft, side-signed); `set_thrusters`
  toggles 4 cyan lift flames.
- **`SiroccoAbility` (`src/player/sirocco_ability.gd`, extends `AbilityBase`):** 2 charges,
  **13 s field / 14 s recharge** (× cooldown stat); `tick_vertical` lifts to
  `_ground_ref + 6.5 m` (ray-probed at activate; hazard zones clamp target to `level + 1.6`)
  and returns true so gravity/hover are skipped while airborne; on `Health.damaged` during the
  field an **invisibility charge** (3) is consumed → 1.5 s stealth pop (`rig.set_stealth`,
  enemy LOS already honours `player.is_stealthed()`); phases READY/FLIGHT/STEALTH/RECHARGING;
  `is_field_active()` is the builtin gate; thruster flames on activate/end; `force_end` safe.
- **Hover flight (`player_robot.gd`):** `_flyer` from def; `floor_snap_length = 0`; new
  `_tick_hover` (replaces gravity) raycasts 24 m down and spring-clamps `velocity.y` toward
  `floor + rest + 0.75 m` (rest self-calibrates on first floor contact, fallback 0.9; hazard
  zones keep it above liquid), void ray → normal gravity; `AIR_ACCELERATION` skipped for
  flyers (else the hover body is always "airborne" → 2.2 m/s² mush); builtin socket case
  chin `(0, 0.6, −1.05)`; `weapons.builtin_requires_field` set from def. `AbilityBase` gained
  `is_field_active()` (default false); `WeaponSystem` computes `field_ok` and gates the
  builtin's `try_fire`.
- **`WeaponData._builtin_windcutter`:** AUTOCANNON 3800 dmg / 660 rpm / spread 1.4 /
  heat 0.1 per shot (net ~9/s vs 0.38 cool → sustained fire overheats = WR burst behaviour).
- **Smoke 758 → 761:** `_check_rampart_swap` → **`_check_zephyr_swap`** — loadout explicitly
  reset to `RAZOR-M/RAZOR-M/MAUL-H` and **restored after** (the stale dev save still carried
  the old MAUL/BREACH loadout → false failures); asserts rig class/no IK legs/no tail/
  **4 wings each ≥1 mesh**/Chassis+HeadSensor GLB meshes ≥6 with materials mapped/3 mounts
  (slot0 RAZOR, slot2 MAUL)/**builtin WINDCUTTER + `builtin_requires_field`**/mount aim
  forward/`ability is SiroccoAbility` → `activate()` spends a charge, `tick_vertical` lifts
  (`vy > 0`), damage pops stealth, `force_end` cleans up/`floor_snap_length == 0`/armor 380 K.
  Def asserts: builtin name WINDCUTTER (was BREACH MORTAR). Rendered QA: dragonfly silhouette
  with swept wings + forward-aiming guns (`dump_mesh -- rampart` + `render_views.py`).
- **Incidents:** (1) wing GLB parts unattached until the `_glb_target` override (base mapper
  has no `wing` branch); (2) smoke's `Group` root assert is an **FBX convention** — GLB scene
  roots are named after the file, so attach checks now count meshes under the anchors instead;
  (3) substring `replace()` on `\tvar builtin_wanted` matched inside a `\t\t` line and
  under-indented it → whole-file parse error cascade ("Could not parse global class
  WeaponSystem") — match full line context or assert counts; (4) old saved loadouts are
  legitimate migrated state — smoke must pin its own fixtures.
- **Build stamp:** `v0.24.0 · 2026-10-05` (code 24). Still open: **touch-controller restyle +
  richer functionality**, LightmapGI/VFX overhaul, paint/camo shop, PRAETOR portrait/hangar art.

---

## 29. Split store + inventory + specialist trio + keystore pin (v0.25.0, smoke 834)

Director round 13: store/inventory split "like actual War Robots" (robot store + weapon store
tabs with preview pics and ability/tool info, separate unequipped-robots/weapons inventory),
"each robot has to be with different drone" + WR-style specialization (each robot + its own
specialist pilot/drone — usable elsewhere but full potential only on its match — and its own
specialized default weapons), "app update doesn't replace old stuff" (keystore), version bump.
Validated at **834 smoke checks** (`VALIDATION PASSED`).

- **WR research (web):** legendary pilots' unique skill works only on their "recommended"
  robot; shop = Robots/Equipment tabs with item art + stats; storage separate from shop. Our
  drone pairing is an original take on the same shape language; names all original.
- **Signature trio (data):** `PILOT_DEFS` + `DRONE_DEFS` gained `sig_robot`
  (vex→SCARAB, orin→VORTEX, sable→RAMPART, mara→PRAETOR; wisp→SCARAB, bulwark→VORTEX,
  kestrel→ZEPHYR, patch→PRAETOR); `signature_pilot_name_for()`/`signature_drone_name_for()`;
  `pilot_effects`/`drone_effects` multiply the whole skill/effect delta ×1.5 on a match
  (`1.0+(x-1.0)*1.5`, regen ×1.5 — never below baseline). Defaults: each robot assigned its
  own pilot + own drone; **all four drones granted** (`owned_drones` + levels + assignments in
  `_build_defaults`; one-time `economy/drone_roster_v25` migration in `load_settings` grants
  missing drones/levels/assignments on old saves and calls `_sync_pool_to_loadouts()`).
  `buy_robot` also syncs the pool. Pilot popup shows `PilotSignature` line (AMBER when the
  selected robot matches); drone descs already carry "SPECIALIST OF … (x1.5 on match)".
- **Specialized default loadouts:** SCARAB `RAZOR-M×2 + MAUL-M×2`, VORTEX `VOLT-H×4`,
  ZEPHYR `LUMEN-M×2 + PYRE-H` (was RAZOR/MAUL-H), PRAETOR `JUGGERNAUT-A×2 + HAVOC-B×2`.
- **Store split (`main_menu.gd`):** `StorePopup` gained `StoreTabRobots`/`StoreTabWeapons`
  tabs over two pages (`StoreRobotScroll`/`StoreWeaponScroll`, `store_tab_set()`), cards built
  by `_make_robot_card` (ARMOR/SPEED/SLOTS rows, AMBER ability line + autowrap
  `ability_desc`, `PRAETOR` secondary, `builtin_desc`, `PAIR <pilot> · <drone> · <fams>`
  from `_pairing_text`, SELECT/BUY) and `_make_weapon_card` (kind/size badge, DMG/RPM, special
  SPLASH/CORRODE/SLOWS/PELLETS, OWNED/MOUNTED/SPARE or price + BUY). Robot defs gained
  `ability_desc`/`secondary_desc`/`builtin_desc` strings. `_open_store(tab)` is the shared
  opener; bottom bar got `RobotStoreButton`/`WeaponStoreButton`/`InventoryButton`
  (CHANGE ROBOT → robot store; width rebalanced 180/180/160/200/170).
- **Inventory (separate screen):** `InventoryPopup` (CYAN accent) with `InvTabRobots`/
  `InvTabWeapons` tabs — owned robots as cards (SELECT) and pool weapons (stock/mounted/
  spare + EQUIP). `_on_inventory_equip_pressed` mounts into the first matching **empty**
  slot (refusals: no fitting slot / already mounted / no free copy). Closes via BACK/ESC/
  opening the store; `_hide_store()` now closes both panels and is used by every popup-open
  path (upgrade/assign/pilot/drone/spec/settings + `_on_settings_pressed` nested site).
  Wallet refreshes both panels.
- **Preview art (`src/ui/item_preview.gd`, class_name `ItemPreview`):** procedural
  120×96 `_draw()` silhouettes — SCARAB quadruped+stinger, VORTEX biped+barrel, ZEPHYR
  dragonfly wings, PRAETOR titan pods, weapon glyph per family (accent-tinted). First build
  had a parse error: `draw_colored_polygon` 3rd arg is a texture, not a bool — one bogus
  outline call made the whole script fail → `ItemPreview.new()` "Nonexistent function" and
  every card died. Deleted the dead call.
- **Hangar drone:** `hangar_pose_driver` sets the orbit's initial position
  (2.6, 2.3, −0.4); `drone_orbit.gd` derives its host from `get_parent()` (line 169) — there
  is no `host` property, do not `set("host", …)`.
- **Update-replace fix (keystore pin):** signing key = `~/.local/share/godot/keystores/
  debug.keystore` (PKCS12, alias `androiddebugkey`, pass `android`). Copied to project root
  as `debug.keystore` (`.gitignore` already has `!debug.keystore`) and pinned in the export
  preset: `keystore/debug=res://debug.keystore`, `keystore/debug_user=androiddebugkey`,
  `keystore/debug_password=android` — same cert as before, so future installs replace the old
  APK instead of failing CERTIFICATE mismatch. (Symptom: director installing a debug APK
  signed with a different machine/key.)
- **Smoke 761 → 834:** menu phase + split-store structure (tabs/pages/`RobotPreview`+
  `WeaponPreview` counts/bottom buttons/`PilotSignature`), tab switch, inventory open →
  store-open-closes-inventory, ability/secondary/builtin descs on all four robots, eight
  signature name pairs, four default loadouts (incl. ZEPHYR LUMEN+PYRE), pool ≥ equipped for
  all 33 item ids, distinct per-robot drones, **×1.5 numerics** for drone (kestrel) and pilot
  (vex) with full save/restore of assignments/levels/skills, roster-owns-four, hangar orbit.
  `_check_drone_api` now strips kestrel+bulwark ownership at entry (roster grants them, the
  buy/select-unowned flow still needs an unowned drone) and restores `saved_owned` at the
  end; `_check_pilot_api` pins `vex.level = 1` before the unlock asserts (cross-run drift:
  match XP had trained vex to lv31 in `settings.cfg`, breaking "skill 3 locked"). Gotchas:
  `find_children` patterns are **globs** (`*Preview`), not regex (`.*Preview` matched 0);
  `find_children` type matches native classes only, so count script-class nodes by their
  native base (`"Control"`).
- **Build stamp:** `v0.25.0 · 2026-10-05` (code 25). Still open: **touch-controller restyle
  + richer functionality**, LightmapGI/VFX overhaul, paint/camo shop, PRAETOR portrait/hangar
  art.

---

## 29b. v0.26.0 batch part 1: WR glass touch UI, world interiors/tunnel, store pilot/drone rows, aim + weapon-visibility fixes (smoke 894)

Director round 14 in progress (wrapped here to protect validated work). Validated at **894
smoke checks** (`VALIDATION PASSED`).

- **Touch controller WR-glass restyle** (`src/ui/touch_controls.gd`, visual layer only —
  rects/offsets/behaviour unchanged): palette consts (`GLASS_BG/GLASS_EDGE/FIRE_*,
  ABILITY_*, SECONDARY_*, HOT_COLOR`) + shared `_glass()` StyleBoxFlat factory (shadowed,
  AA). New state: `_heat_ratio/_overheated/_firing/_group_held[2]/_pulse/_secondary_ratio`,
  redraws from `Events.weapon_heat_changed`, `InputRouter.group_held` and press/release.
  `_draw()` now = caption chips (`draw_style_box`, refs captured in `_add_caption`), glass
  stick (idle disc + 4 tick marks + MOVE chip / active ring, direction line, knob core),
  **FIRE heat ring** (cyan→amber→red arc, pulsing OVERHEAT label, firing glow), ability +
  secondary charge rings, and group-hold corner highlights for RAZOR/MAUL.
- **Hangar "4 slots shows 2 guns" fix** (`robot_rig.gd _build_hardpoints`): rear hardpoint
  sockets raised `Vector3(±1.14, 0.54, 0.62)` → `y 1.2` — the rear pair was coaxial with the
  front pair and perfectly hidden behind it head-on. Probe proof: `tools/hangar_probe.tscn`
  prints per-robot mounts + per-mount AABB overlap vs hull + equipped-vs-mounted `MISMATCH`.
- **Aim/lock pointer fix** (`src/ui/hud.gd`): the red TARGET frame was hard-anchored at
  screen centre inside the crosshair, so in third person it rode the player's own robot.
  `_update_lock_frame()` (called from `_process` + `_on_enemy_locked`) now unprojects
  `locked_enemy + UP*1.5`, hides behind-camera/off-screen targets, and the crosshair stays
  centre (camera-forward aim ray is correct by design).
- **Store rows for pilots + drones** (`main_menu.gd`): 5 tabs now
  `StoreTabRobots/StoreTabTitans/StoreTabWeapons/StoreTabPilots/StoreTabDrones` (indices
  0..4, bottom button → tab 2) with matching scroll pages; `_make_pilot_store_row`
  (ItemPreview pilot art, signature line, OWNED/HIRE with silver-or-gold cost) +
  `_on_store_pilot_pressed` (buy→owned toast, assign→refresh cards) and `_make_drone_store_row`
  (BUY/EQUIP/UPGRADE, TITAN/ACTIVE disabled states). `_check_pilot_api` gained the hiring
  block (costs, refusal while unowned, silver+gold purchase, effects, owned-list restore).
- **World: enterable interiors (W5)** — `OpenRealm._build_bunkers()` places two procedural
  field bunkers (`BunkerHub` at −34/10, `BunkerWild` at 30/−18): slab floor, three solid
  walls, a **front wall with a real 2.8 m doorway gap** (side segments + lintel), jambs,
  cyan door/ceiling light strips, crates, interior OmniLight, yawed to face the hub / origin.
  Kit buildings stay solid on purpose (their meshes have no openings — a hollow collider
  there would read as walking through a wall).
- **World: sci-fi transit tunnel (W6, the "caves" replacement)** — `terrain_height` gains a
  static `_carve_tunnel()` (flat 11 m floor, 2.5 m shoulders, 6.6 m depth, 10 m entrance
  ramps, both ends at z 118→168) and `_build_tunnel()` builds the shell **per 5 m segment**,
  seating each ceiling slab against the local terrain at the skirt (|x| = 9) so slabs are
  always buried outside the trench while headroom stays ≥ 2.7 m: ceiling boxes
  (`TunnelCeiling`), side walls + glow strips + portal ribs (`TunnelShell`), entrance gantries
  `TunnelGantryA/B` with amber lintels + beacons, three `TunnelLamp` omnis.
  `_in_district()` now also excludes the trench span (`_in_tunnel_span`) so scatter never
  drops boulders/trees into it.
- **Flyer roof clipping (W7)** — `SiroccoAbility._probe_ceiling()` raycasts up each flight
  tick and clamps the hover target to `ceiling − 1.3` (after the hazard-zone floor clamp), so
  ZEPHYR can lift off inside a bunker without punching through the roof. Smoke stages the
  player inside `BunkerHub`, runs 90 ticks and asserts it settles under the roof but above
  the floor.
- **Smoke 878 → 894:** trench floor/shoulder/ramp carve asserts, tunnel ceiling+shell+both
  gantries (sibling names must be unique — Godot silently renames duplicates to
  `@Node3D@N`, so gantries are explicitly named A/B), bunker parts/lamp, **doorway ray must
  pass through the gap** (terrain hits ignored) and roof ray must block, flyer indoor hover.
  Gotchas: `for caption: Label in [...]` over a nullable array is fine; Variant-returning
  `.get()` needs `var x: Variant =`.
- **Still open in this round:** N1 out-of-app notifications (permission + runtime request
  already exist; system notifications need the Gradle path — `aapt2` broken on this arm64
  host, so the offline inbox fallback is the pending design), S2 titan rework (bigger GLB —
  analysis done: uniform K scale of `build_princeps.py` + `TitanRig` literals + player
  capsule/camera/spawn lift, blocked mid-implementation at wrap-up time), WR combat-stat
  visibility pass, AGENTS version 0.26.0.

---

## 29c. v0.26.0 part 2: hangar UI rebuild + chassis size system + titan bulk (smoke 909)

Director round 14 continued: *"hangar is disorganized and fucked up everywhere"* (a device
screenshot review) and *"titans have to look bigger than all other robots — in the hangar AND
in battle; robots themselves should be bigger or smaller than each other"*. Validated at
**909 smoke checks** (`VALIDATION PASSED`).

- **Hangar layout root causes (`tools/layout_probe.tscn`, kept as a diagnostic):**
  1. `CardBody` min width 303 px vs a 244 px card → the `ScrollContainer`'s minimum propagated
     up (`Container.fit_child_in_rect` clamps **up** to the child minimum) so `LeftCard` grew
     to 315 px and its contents were drawn under the 3D preview. Wide children were
     `PaintButton` (its label carried the palette name: `"PAINT · MAGMA"` ≈ 173 px) and
     `RoleRow`. Fix: `PAINT` label is constant (name moved to `tooltip_text`), swatches
     38→36 px, `ActionRow` holds PAINT+UPGRADE on one row, stat label+bar merged into
     `ArmorRow`/`SpeedRow`, card `separation` 8→3, name 30→24, power 34→26, buttons 44→40.
     Result: content **443 ≤ 450** window, body **216 ≤ 216**, no scroll at rest.
  2. `scroll_vertical=168` (from `_ensure_card_visible` after a paint click) hid `RobotName`
     at y −30 → the "missing SCARAB name". `CardScroll.follow_focus=false` +
     `clip_contents=true`; with content fitting, opening the palette only scrolls ~27 px.
  3. `RobotPrev/NextButton` drew `←`/`→` (and `‹`/`›`) as **tofu boxes** — Godot's bundled
     OpenSans has no arrow glyphs. All 12 arrows → ASCII `<` `>` (`"< BACK"`).
  4. Removed the duplicate `ChangeRobotBottomButton`; added `_make_section()` headers
     (`PERFORMANCE`, `SQUAD`); preview/slots widths now compute dynamically in
     `_arrange_layout` (slots floor 300) instead of forcing `MIN_PREVIEW_WIDTH` overlap.
  5. Top-bar chips rewritten with `_make_chip(caption, value, dot, width)` + `_chip_label()`:
     `ACCOUNT/LV`, `SILVER`, `GOLD`, `PARTS`, `PLAT` (`ChipPower` removed — `728K` power
     now lives on the robot card); `_refresh_chips` sets platinum too.
  Gotchas: `find_children` patterns are **globs**; a python `str.count` on a 2-tab line also
  matches inside a 3-tab line (substring!) — inserting into nested smoke blocks silently
  under-indented them (`Expected statement, found "Indent"`).
- **Chassis size system (hangar + battle):** `ROBOT_DEFS["scale"]` — SCARAB 1.0 (baseline),
  VORTEX 1.18, ZEPHYR 0.85, PRAETOR 1.0 (authored big). `RobotRig.visual_scale` (setter also
  sets node `scale`) **must be assigned before `add_child`**, because `_build_legs` calls the
  new `LegUnit.apply_scale(s)` which multiplies `foot_drop/thigh/shin/coxa/hip/thigh/shin
  radii/foot_size/stride_length/step_height` (never `reference_speed`, frequencies,
  `duty_factor`, `rest_spread`, `phase_offset`) — `LegUnit._solve` works in **world space**
  with rotation-only `global_basis`, so a scaled rig node alone would NOT scale bone meshes.
  Wired in `player_robot.gd` (rig + capsule 1.25×s/3.0×s + `RIG_HEIGHT_RAISE` + drone orbit),
  `hangar_pose_driver.gd`, `game_session.gd` (camera `height_offset` 1.15×s, spawn lift 2.5×s).
  Enemies: `EnemyRobot.KIND_SCALES` (SCUTTLER 0.9, STALKER 1.05, BRUTE 1.3, WASP 0.8)
  baked into capsule/eye/spawn-hover in `_configure_kind` and handed to the rig before
  `add_child`; `drone_rig.hover_height()` scales. Hangar titan camera pulls back only
  `×1.35` (was `×TITAN_SCALE` 1.875 — it framed the titan exactly like a normal robot, so it
  never read as a giant).
- **Titan bulk (carried in this commit):** `TitanRig.BULK 1.25`, `TITAN_SCALE 1.875`,
  `princeps.glb` + `build_princeps.py` rebuilt at final size, capsule `1.85×BULK / 4.5×BULK`,
  bunker doorway 2.8→5.0 m; smoke `_node_bounds` assert `titan hull > 4 m` in x and y
  (measured AABB `x[−2.40, 2.40] y[−1.27, 4.23]` ≈ 5.5 m tall vs SCARAB 3.6×2.0).
- **Smoke 894 → 909:** platinum/level chip labels, chassis-size block (`_check_chassis_sizes`
  — sane 0.8–1.25 scales, SCARAB baseline, VORTEX ≥ ZEPHYR+0.2, `apply_scale` grows IK
  constants), ZEPHYR rig/capsule carry `visual_scale`, `BRUTE > SCUTTLER` rig scale in the
  enemy roster.
- Tools kept: `tools/layout_probe.{gd,tscn}` (rest-scroll/body-fit/WIDE prints). Device
  screenshots arrive via host-mounted `/sdcard/imgs/` (`mv` works; `adb` has no device).
- **Still open:** LUMEN weapons exact War Robots behavior (research done: lock-on beam that
  holds contact, partial curve around terrain, Thermal Breach stacks, 0.1 s shot interval,
  600 m range — sources `warrobots.com/en/posts/417`, `about.my.games/news/569`), world
  visibility round (rain/thunder/lightning not firing in-session, volcano first eruption
  ~48 s, floating-mountain probe `float_probe.gd` returned no output, tunnels/caves
  discoverability), out-of-app notifications (needs Gradle/aapt2 path), **APK rebuild
  (stale — predates the titan/hangar/size work)**, WR combat-stat visibility pass.

---

## 29d. LUMEN lock-on beam + realistic sound overhaul + ECHO sonic family + VOID/CHASH titan guns (v0.26.0, smoke 974)

Director round 15: "get real sounds just like how warrobots uses its high quality weapon
realistic matching sounds, not just sounding like popcorns in a saucepan", "hope u fixed
lumen weapins to have beam curving accross obstacles to hit ememy just like in warrobots",
sonic/sound weapon family per WR research, and titan "void chasm" weapons — "should behave
exactly the same, animations, shooting, look etc". Validated at **974 smoke checks**
(`VALIDATION PASSED`, run twice).

- **LUMEN lock-on beam (WR behavior):** `WeaponData` fields `lock_beam/thermal_breach/
  breach_per_hit/beam_range`; new `src/combat/beam_effect.gd` transient bent beam visual;
  `weapon_mount.gd` beam branch — mount holds `beam_target` while the target stays in LOS,
  `_beam_ray` walks `BEAM_BEND_HEIGHTS [3,6,10,16]` × `BEAM_BEND_SIDES [4,8]` offset probes
  to find a path **curving around cover** (probe from mount toward anchor, stepping over/side
  until a clear midpoint + endpoint), strikes through `Projectiles`-free direct
  `_beam_strike` (damage + `apply_thermal_breach` per hit); `weapon_system.gd` aims beam
  mounts at `body_anchor = global_position + UP*0.3`; `enemy_robot.gd` breach system
  (`BREACH_MAX 10`, `BREACH_PER_STACK 0.04`, `BREACH_LIFE 4.0`, `apply_thermal_breach`,
  `breach_mult()` multiplies incoming damage — WR "Thermal Breach: increased damage taken").
  Smoke phase 4 stages a LUMEN target: direct 9500, wall-blocked 9880 (= ×1.04 second hit
  through the curve — proves the bend + stack), beam visual active, breach decays.
- **Smoke staging bug fixed:** phase 4 still contained a leftover `if _frame == 1:
  _stage_lumen_target()` from editing — the roster assert (enemy 16) could fail when the
  stage ran twice (re-aiming the camera mid-phase). Removed; `_stage_lumen_target` also got
  an idempotence guard (`if _lumen_target != null: return`).
- **Scorch crash fixed (pre-existing latent flake):** `combat_fx.gd::_spawn_scorch` popped a
  freed pooled node when the queue wrapped (ObjectDB "previously freed instance" on
  `queue_free`d decals). Prunes invalid refs with `is_instance_valid` before `pop_front`.
- **Sound overhaul (all original, procedural):** `audio_engine.gd` rewritten —
  `MIX_RATE := 44100`, `MUSIC_RATE := 22050` (menu music), helpers `_lcg/_white/
  _add_drop_sine/_add_partial/_apply_tail(comb feedback)/_saturate(tanh)/_wav(samples,
  loop, rate)`; every weapon voice rebuilt as layered synthesis (muzzle crack + lowpassed
  gas + pitch-drop body + inharmonic partials + slapback tail + saturation) for
  cannon/scatter/zap/rail/launch/hiss/beam/flame/thump; new `_make_sonic()` (95→34 Hz sub
  drop + 190→68 Hz whomp + air tail) registered as `&"sonic"`; structured impact clang
  (618/941/1487/2377 Hz), reworked hit/dash/boom. Smoke asserts per weapon stream
  (`cannon/scatter/sonic/impact_metal`): `mix_rate == 44100`, peak > 11000, avg |sample|
  > 700 (measured 4102/7446/12290/1725).
- **ECHO sonic family (WR Scatter/Devastator shape):** `WeaponData.Kind.SONIC` appended +
  `hull_fraction: float = 0.4` field; `_echo(size)` — ECHO-L 850×6/95 rpm/spread 9,
  ECHO-M 1400×8/82/8, ECHO-H 2100×11/68/7.2, speed 115, drop 2.6, tracer cyan-white,
  **`hull_fraction = 1.0`** = 100% grey (unrepairable) damage like WR Sonic;
  `for_item` arm `"ECHO"`. Plumbing: `Projectile.weapon_hull_fraction()`,
  `ProjectileService._route_damage/_apply_splash` pass the fraction as the 3rd arg to
  `receive_damage`, `Health.apply_damage(amount, point, hull_fraction := HULL_FRACTION)`
  adds hull while current HP is restored by healing (smoke: 200 @ 1.0 → current 800/hull
  200, heal → stays 800); `player_robot`/`enemy_robot.receive_damage` gained the optional
  3rd param. `weapon_mount._build_sonic()` = resonator drum + emitter rings + horn flares.
  `ALL_ITEM_IDS` 27 → 30; audio routes `Kind.SONIC` → `&"sonic"` (−1.8 pitch).
- **VOID-A / CHASH-B titan guns ("void chasm"):** WR research: Alpha/Beta Kinetic salvos,
  ammo 8 / reload 7 s, post-reload **supercharge +20%**, Special Effect **Suppression
  (reload)** — during reload the gun pulses a core that damages + suppresses nearby enemies.
  `WeaponData` gains `magazine/reload_time/supercharge_damage_mult/suppression_radius/
  suppression_duration/suppression_pulse/suppression_damage`; builders `_void()` (SALVO
  ALPHA 9000×3, 66 rpm, splash 4.0, suppression 10 m/3 s/0.75 s/1200 dmg, violet tracer)
  and `_chash()` (BETA 7500×2, 80 rpm, splash 3.4, suppression 9 m/1000); `TITAN_ITEM_IDS`
  += VOID-A, CHASH-B (8, auto in store + size-priced 550/400 plat).
  - `weapon_mount.gd` state machine: `_ammo/_reload_left/_reload_pulse/_supercharged/
    _suppression_shape` — `try_fire` gates reload, decrements **1 per trigger** (pellets ≠
    ammo), on empty `_begin_reload()`; `_physics_process` ticks the reload, fires
    `_pulse_suppression()` (sphere query `collision_mask = Layers.ENEMY` at the muzzle →
    `EnemyRobot.apply_suppression` + `receive_damage(1200)` to every hit), and on completion
    refills + sets `_supercharged`; supercharged shots pass `shot_damage` (1.2×) into
    `Projectiles.fire` as a **5th `damage_override` param** — `Projectile._damage_override`
    + `weapon_damage()` (→ `_route_damage/_apply_splash` already read `weapon_damage()`).
    Decision recorded: `Resource.duplicate()` does **not** reliably copy non-exported script
    vars on `WeaponData`, so boosts/maluses go through the override param, never duplicate.
  - **Suppression:** `enemy_robot.gd` `_suppression_left`, `apply_suppression(duration)`,
    `suppressed_mult() == 0.5 while active, decay in `_tick_status`; `_fire_once` passes
    `damage_override = damage × mult` (same override path — no `duplicate()`).
  - **Visuals:** `_build_void()` family-first dispatch (before the Kind match) — grav cell,
    violet emissive singularity core, twin gravity coils, emitter housing, 4 stabiliser fins,
    twin yoke rings + wave barrel, capacitor pack, muzzle core.
  - **HUD:** right stats panel grew 158→180 px; `_ammo_label` (`AMMO n` amber / `RELOADING`
    red) driven by `Hud._sync_ammo()` each frame — visible only when the loadout has a
    magazine weapon (normal robots unaffected).
- **Smoke 909 → 974:** audio quality block (family + per-stream rate/peak/avg), catalog 30,
  ECHO kind/size/splash/hull_fraction data asserts, functional grey-damage test,
  `_check_sonic_mount()` (structure + volley + heat), and `_check_void_mount()` — VOID/CHASH
  data + store membership, mount builds grav cell/core, **fires all 8** → `is_reloading()`,
  stage beside a live enemy → direct `_physics_process` → assert `suppressed_mult() == 0.5`
  + pulse damage, finish reload → full magazine + `is_supercharged()`, supercharged shot →
  active projectile with `weapon_damage() ≈ 10800`.
- **Build stamp:** `v0.26.0 · 2026-10-05` (unchanged — this batch rides the same version).
  Still open from §12–29c: **world visibility round** (rain/thunder/lightning not firing,
  volcano first eruption ~48 s, `float_probe.gd` returned no output, tunnels/caves
  discoverability), out-of-app notifications (Gradle/aapt2 path), WR combat-stat visibility
  pass, LightmapGI/VFX overhaul, paint/camo shop, PRAETOR portrait.

---

## 29e. Per-weapon firing animations (transform-only) (v0.26.0, smoke 1053)

Director round 15 tail: *"per weapon animation in shooting"* — every weapon family now has a
distinct moving part on fire so shots read differently at a glance. Validated at **1053 smoke
checks** (two full `validate.sh` runs, `VALIDATION PASSED`).

- **Animation engine (`weapon_mount.gd`):** new `Anim` enum
  (`NONE/SPIN_BARRELS/PUMP_SLIDE/CORE_THROB/TUBE_SEQUENCE/NEEDLE_WOBBLE/FLAME_FLICKER`),
  member state (`_anim_parts/_anim_rest_*`, `_anim_timer/_anim_phase/_anim_speed/
  _anim_index`, optional `_anim_material` + `_anim_material_base`), `_bind_anim(kind, parts,
  material = null)` records rest transforms, `_kick_animation()` runs on the successful-fire
  block of `try_fire()`, and `_animate(delta)` ticks from `_process` (visual-only — gameplay
  math stays in physics). **Critical rule:** animations are **transform-only**; the rig-shared
  sensor/trim materials are mutated by `RobotRig.set_stealth()`, so no weapon animation writes
  material state — the only safe exception is a **builder-local** material (VOID's violet
  singularity).
- **Per-family motion:** RAZOR/autocannon — 4 thin cluster barrels + heat shroud + muzzle
  brake moved into a `BarrelCluster` node; each shot kicks `_anim_speed` to 26 rad/s then it
  coasts down to a 3 rad/s idle spin (`_kick_animation` kick + `ANIM_SPIN_DECAY`). MAUL
  scattergun — `pump_grip` slides ±0.14 m and returns over 0.26 s. VOLT/LUMEN/ECHO/VOID —
  `energy_core`/`emitter_tip`+`lens_cone`/`resonator_drum`/`singularity_core`+`muzzle_core`
  swell-shrink with the shot pulse; VOID additionally flares its local violet material
  emission (base × up to 2.6). VOLT fuel/aileron families unchanged. FERRIC — `gauge_needle`
  jitters on shot plus a heat-proportional resting deflection (uses the existing `heat`
  member, so the needle reads overheat too). PYRE — `pilot_flame` flickers with two
  sine terms (never material writes). VOLLEY — the six `tube_ready` spheres blink in a
  sequence (`_anim_index` advances per shot, cycle while pulse > 0.15). TORQ magnetic —
  `charge_orb` swells on shot.
- **Builder plumbing:** captured node refs from `MeshUtil` return values (Godot renames
  duplicate siblings to `@Node3D@N`, so lookups by name are fragile); VOLLEY collects the six
  spheres into `ready_lights` during the row/column loop; autocannon cylinders moved into the
  cluster (the old single `barrel` cylinder replaced — no external reference exists).
  Smoke-critical node names (`resonator_drum`, `singularity_core`, `horn_mouth`,
  `energy_core`, etc.) preserved.
- **Smoke 1027 → 1053:** new `_check_fire_animations()` — builds RAZOR/MAUL/VOLT/LUMEN/
  PYRE/VOLLEY/ECHO/VOID mounts, fires once, steps `_process(0.05)` (2 frames; 8 for PYRE),
  asserts 4 cluster barrels + `rotation.x` moved + spin speed > 8, pump slide travel > 0.05 m,
  animated-part scale deviation ≥ 0.05, and VOID scale > 1.05 + emission > base × 1.1.
  Gotchas hit: **Callable `.call()` returns Variant** → every `build_anim_mount.call()` site
  needs an explicit `: WeaponMount =` (Variant-inference warning = error); transient anims
  decay in < 0.15 s so sampling at 8 frames captured only the reset pose (2 frames is the
  sweet spot); `is_equal_approx` rejected benign near-1.0 flicker → assert `absf(x-1.0) > 0.05`.
- **Incidents:** two tab-swallow parse errors (the recurring `str-count / substring` trap):
  the magnetic `sight_fin` `for` loop lost its indent and the smoke `var families` line lost
  its leading tab → "Unexpected for/Indent in class body". Both fixed with full-context python
  `replace`, never bare substring `str.count`. A background smoke orphan plus a second launch
  wedged the host into swap thrash — always `pgrep -f`/`kill -9` strays before retrying.
- **Build stamp:** ridess `v0.26.0 · 2026-10-05` (code 26). Director roadmap locked for the
  next batch: **per-robot** shooting/reload/movement animation + per-robot weapon sounds
  (one pass after APK device test). Still open: world visibility round, out-of-app
  notifications, APK rebuild (next step), WR combat-stat visibility, LightmapGI/VFX overhaul,
  paint/camo shop, PRAETOR portrait.

---

## 29f. v0.27.0 batch part 1: per-robot motion/recoil/reload + regional weather (smoke 1080, APK built)

Director round 16 confirmed the v0.26.0 roadmap (per-robot shooting/reload/movement animation +
per-robot weapon sounds) AND redirected the weather directive: *"dont make everypart of map snow
i can even see anything, i wanted different parts of map to have differwnt weather"*. Validated
at **1080 smoke checks** (`VALIDATION PASSED`) + debug APK (`build/android/mech-assault-debug.apk`,
728 MB, signed with pinned keystore, stamped v0.27.0 — verified by zstd-decompressing the shipped
`game_state.gdc`). APK rebuild's in-log version line read 0.26.0 only because the version bump
landed mid-build; the export step read the updated files and the marker is in the shipped pck.

- **Per-robot motion/recoil personality (`robot_rig.gd`):** new tunable vars
  `move_pitch_gain / turn_roll_gain / strafe_roll_gain / bob_freq_base / bob_freq_speed /
  hover_bob_amp / fire_pitch_kick / fire_bob_kick / fire_roll_kick / fire_kick_decay /
  reload_pitch / reload_crouch / reload_brace_hardpoint` + state `_fire_kick` (decays via
  `fire_kick_decay`, caps at 3.0) and `_reload_pose → _reload_target` (eased at
  `clampf(delta*5,0,1)`). `kick_fire(amount:=1.0)` arms the kick; `set_reloading(active)`
  eases the reload crouch/brace; `update_animation` composes pitch (move gain + kick +
  reload) and roll (turn/strafe gains) and buck (bob + kick + reload crouch) and hardpoint
  brace pitch. This is **hull driving, not IK**: legs keep their physics gait untouched.
- **Per-robot tuning:** SCARAB (base) `fire_pitch_kick −0.05 / decay 4.5 / bob_freq_base
  2.2 / move_pitch_gain 0.012`; VORTEX `decay 6.0 / move_gain 0.016 / turn_roll 0.065 /
  bob 2.6 / kick −0.035` (settles fast, mobile); ZEPHYR `hover_bob_amp 0.05 / turn_roll
  0.085 / decay 8.0 / kick −0.02` and its wing flutter in `update_animation` is boosted by
  `_fire_kick` (`+6.0` phase, `+1.5/2.0` lift); PRAETOR `move_gain 0.02 / fire_pitch_kick
  −0.09 / decay 3.0 / bob_freq_base 1.5 / reload_pitch −0.1` (deepest, heaviest).
  `WeaponSystem.reload_ratio()` = max over mounts+builtin; `PlayerRobot._update_animation`
  polls it → `rig.set_reloading(reload_ratio() > 0.0)` (VOID/CHASH magazine weapons brace
  the hull while reloading).
- **Per-robot engine hum + weapon voice (`audio_engine.gd`):** `_make_engine_loop(base_freq,
  hum_mult, wobble_hz, texture)` parameterised; four 1 s loops — `engine` 52 Hz (SCARAB),
  `engine_vortex` 66, `engine_rampart` 88 (ZEPHYR), `engine_praetor` 40. `_engine_loop_id()`
  picks by `GameState.selected_robot` (RAMPART id = ZEPHYR loop); `bind_engine` uses it.
  `_robot_voice()` returns `(pitch_mult, db_boost)`: SCARAB (0.96, +1), VORTEX (1.06, +0.5),
  ZEPHYR (1.18, −1), PRAETOR (0.82, +3) — applied to every `_on_weapon_fired` `play()` call
  so each chassis literally sounds different firing the same gun. `play()` gained a
  `pitch_base` arg. New `&"reload"` clack (`_make_reload`: 190 Hz clack + delayed 340 ratchet
  + 150 slide) played from new `Events.weapon_reload_started`, emitted by
  `WeaponMount._begin_reload`.
- **Regional weather (director: different districts, different weather):** `weather_system.gd`
  keeps the drifting player-relative storm cell (`_rain`/`_snow`, smoke contract unchanged —
  RAIN still dims ambient <0.8, sets wind 2.3, water `rain_strength`, `force_state` works)
  but adds **five PERMANENT micro-climate stations** over the districts (`ZONES`):
  INDUSTRIAL (95,−70) **rains**, RUINS (−95,−55) **snows**, HUB (0,34) / CITY (75,85) /
  VOLCANO (165,−195) stay clear. Each zone is a `_build_precip(..., is_zone=true)` cell with
  its own extent + amount (rain cells 420 / snow 280) and a slow sine sway (±4 m) so the
  stations feel alive. They run **independently of the global schedule**, so even on a clear
  global day the factory district visibly rains and the ruins snow — that is the "different
  parts of the map have different weather" ask, while the player's own sky stays readable.
  Global storm fog also eased (rain 0.016→0.012, snow 0.01→0.008) to fix the "can't see
  anything" tall-poppy from the old single snowy cell + heavy fog combo.
- **Smoke 1053 → 1080:** `_check_robot_motion_profiles()` (builds SCARAB/VORTEX/ZEPHYR/
  PRAETOR rigs via a lambda that flips `selected_robot` and restores it; asserts each ships
  its tuning, `kick_fire()` → `_fire_kick > 0` then hull pitch kicks below its pre-shot value,
  reload pose eases >0.5 then recovers <0.2, cross-robot comparisons — VORTEX decays faster,
  reads movement, ZEPHYR bobs+banks, PRAETOR recoils deeper and walks heavier — and the voice/
  engine-loop selectors per robot) + `_check_regional_weather()` (5 zones, INDUSTRIAL rain &
  RUINS snow already emitting on a cleared day, HUB stays dry). Gotchas hit: **`Callable.call()`
  returns Variant** → `var vortex: RobotRig = build_rig.call(...)` (Variant-inference error =
  warning-as-error); comparing against a **freed** rig (Titan `kick_fire` spike — captured
  SCARAB's constants into locals *before* `free()`).
- **Build stamp:** `v0.27.0 · 2026-10-06` (code 26, name 0.27.0; project.godot/export/
  BUILD_LABEL bumped together). Note the code field was 25 at name 0.26.0 (an earlier bump
  skipped the code) — validate.sh only compares the three *name* fields; code is cosmetic.
  **APK delivered for device test.** Next (per the earlier director roadmap + Windows ask):
  Windows desktop export preset + in-game resolution/windowed/fullscreen settings,
  out-of-app notifications, WR combat-stat visibility pass, LightmapGI/VFX overhaul,
  paint/camo shop, PRAETOR portrait.

---

## 29g. Memory fix: VRAM texture pipeline — 1627 → 407 MB static, APK 728 → 524 MB (v0.27.1)

Director report: device consuming **4.2 GB even on LOW graphics, unplayable** ("did u change it
to 4.2gb?"), mmap suggested; a forwarded review proposed full region streaming for OPENREALM
(adopted as Phase 2, below). Validated at **1080 smoke checks** (`VALIDATION PASSED`, run twice —
plain + `--apk`).

- **Diagnosis (measured, not guessed):** new `tools/mem_probe.{gd,tscn}` instantiates the game
  scene headlessly, settles 150 physics frames, prints `MEMORY_STATIC` + `get_image()` info for
  the heavy textures. Baseline: **static 1626.8 MB**. Root cause: **120 lossless
  (`compress/mode=0`) imports ≥1 MP under `assets/`** with no size limit and no mips —
  notably `assets/textures/pbr/*`: `forest_ground/albedo.jpg` is 8192² (78.8 MB ctex → **268 MB
  resident RGBA**) and OpenRealm loads **forest_ground + rock + asphalt** at startup
  (`asset_library.pbr_material`) ≈ 1.0–1.5 GB resident by itself; downtown/rocks/nature 2K/4K
  maps added the rest. Lossless ctex keeps decoded RGBA in RAM — that is the 4.2 GB, not geometry
  (all `.scn` ≈ 0.02 GB) and not mmap.
- **Fix = director's pipeline** ("8K lossless → compressed → mipmaps → 4K/2K variants → load
  only when needed"). New committed tool `tools/vram_compress_imports.py` (idempotent; dry-run
  default, `--apply` to write): every `assets/**/*.import` whose source is ≥1024 px and ≥1 MP,
  minus doc/preview/logo/icon/font/badge names — `compress/mode` 0→2 (VRAM; project already has
  `rendering/textures/vram_compression/import_etc2_astc=true`, so output keys are
  **`path.etc2` = ETC2/ASTC**, native on Adreno/Mali), `mipmaps/generate=true`,
  `process/size_limit` 8K→**4096**, 4K→**2048**, 2K kept, `compress/normal_map=1` on normal maps
  (green-channel-safe formats); deletes each dest `.ctex`+`.md5` so `--import` regenerates.
- **Results:** on-disk ctex **0.71 → 0.499 GB**; forest_ground albedo **78.8 → 10.7 MB**
  (4096² ETC2 + mips); headless static **1626.8 → 406.9 MB (−1.22 GB, −75%)**; probe confirms
  `format_id 30/28` (ETC2_RGB/RGBA) and applied dims 4096/2048; **APK 728 → 524 MB**.
  Device-side expectation: the texture-resident share of the 4.2 GB drops by the same ~1.2 GB.
- **Version:** `0.27.1` / code 27 / `BUILD_LABEL v0.27.1 · 2026-10-06` (project + export +
  game_state moved together; validate.sh enforces name equality).
- **Probe gotchas:** `Performance.OBJECT_IN_USE` does not exist → `OBJECT_COUNT`;
  `Image.get_format_name()` does not exist → print the int; after VRAM migration the `.import`
  `path=` key becomes `path.etc2`/`path.s3tc` — parsers that only read `path=` will think
  textures vanished (first size scan reported nonsense 1.477 GB because it also regex'd
  `source_file=` JPEGs).
- **Windows follow-up:** only ETC2 is stored right now; before a Windows desktop build enable
  `rendering/textures/vram_compression/import_s3tc_bptc` (writes `path.s3tc`/`path.bptc` keys) or
  desktop Vulkan/D3D may lack a supported format.
- **Phase 2 (director-approved concept, NOT started): OPENREALM region streaming** from the
  forwarded review — distance rings with real unload, cheap distant impostors, lazy district
  activation. Two adaptations required: (1) the review's 50/150/300 m table does not fit our
  **460×460 m map** (districts are 100–170 m apart, so ">300 m unload" would never fire) — use
  ≈0–80 full / 80–140 mid / 140–200 low / >200 unload; (2) **hide ≠ unload** — in Godot, freeing
  nodes is not enough: you must also evict `AssetLibrary`/loaded-scene Refs so the
  mesh → material → texture chain actually frees, and re-load on approach (thread-load to avoid
  hitches). The texture pipeline above was the prerequisite 75 % win; streaming targets the rest.
  Smoke `_check_open_realm` asserts far props exist at start — Phase 2 must teach it the
  preload-region API instead of relaxing the asserts.

---

## 29h. Windows Desktop build (v0.27.1, same version — export-only batch)

Director: *"what about windows version did u build it"* — the queued laptop-test ask. One
Windows build now exists alongside the Android APK, with **per-platform texture-format
export filtering** so neither package ships the other's formats.

- **Templates:** full `Godot_v4.4.1-stable_export_templates.tpz` (1.97 GB, GitHub release;
  resume with `curl -C -` — first attempt died at 56 MB) → extracted
  `templates/windows*` into `~/.local/share/godot/export_templates/4.4.1.stable/` (extra
  arm64/x86_32 console stubs harmless). tpz kept at `/tmp/opencode/export_templates.tpz`.
- **Dual-format import:** `project.godot` now has `rendering/textures/vram_compression/
  import_s3tc_bptc=true` **next to** the existing `import_etc2_astc=true` — every VRAM
  texture imports as BOTH `path.etc2` + `path.s3tc` ctex (on-disk imported 0.499 → 0.902 GB;
  `.import` metadata `imported_formats: ["s3tc_bptc", "etc2_astc"]`). Runtime picks what the
  driver supports, so **RAM behaviour is unchanged** (only one format loads per texture).
- **Export filtering (the key discovery):** the `texture_format/s3tc_bptc` /
  `texture_format/etc2_astc` **export-preset options really do filter at pack time**:
  - Android preset: `s3tc_bptc=false`, `etc2_astc=true` → APK verified with
    **0 `.s3tc.ctex` / 120 `.etc2.ctex`** entries — stays **524 MB** (the v0.27.1 memory-fix
    size; dual import does NOT bloat the APK).
  - Windows preset: `s3tc_bptc=true`, `etc2_astc=false` → exe verified
    **240 `.s3tc` refs / 0 `.etc2`**.
- **New preset `[preset.1] "Windows Desktop"`** in `export_presets.cfg`: x86_64,
  `binary_format/embed_pck=true` (single-file game), `debug/export_console_wrapper=1`,
  `application/modify_resources=false` (rcedit is unavailable on this host — without it
  Godot warns and the exe keeps the default Godot icon / no version metadata; enabling the
  modifier without a configured rcedit just produces the warning),
  `exclude_filter="tools/*,build/*"` like Android.
- **Build command:** `source tools/env.sh; "$GODOT" --headless --path . --export-debug
  "Windows Desktop" build/windows/mech-assault.exe` →
  `build/windows/mech-assault.exe` **599,891,456 B** (game + embedded pck, valid `MZ` PE)
  + `build/windows/mech-assault.console.exe` 188,928 B (console wrapper for log capture).
  Final export log: `EXIT=0`, no warnings.
- **Not runnable on this host** (Linux aarch64, no wine) — structurally verified only (PE
  headers, embedded-pck format filtering, clean Godot export). Gameplay verification is the
  director's laptop run; if it misbehaves, have him launch `mech-assault.console.exe` and
  send the console output.
- Still queued from earlier: in-game **resolution / windowed / fullscreen settings** for the
  desktop build (the exported window is 1280×720 windowed; no display-settings UI exists yet).

---

## 30. WR touch panel + cross-platform input + hardware AUTO tier + status feed (v0.28.0, smoke 1125)

Director round 17: War Robots-format circular touch controls, full keyboard/mouse/gamepad
input for the Windows build, PC hardware detection with adaptive quality, and a WR-style
bottom red battle-status feed. Validated at **1125 smoke checks** (two `validate.sh` runs,
`VALIDATION PASSED`), both artifacts rebuilt: `build/windows/mech-assault.exe`
(599,910,864 B + console wrapper) and `build/android/mech-assault-debug.apk` (548,668,202 B).

- **WR circular touch panel (`touch_controls.gd` rewrite):** panel centre
  `size − (185, 180)`; FIRE 130 px disc; wedge ring 86–154; four weapon segments (84×68) on
  a 120 px radius, slice `PI/2 + i*TAU/(N+1)` (index 0 = lock slice at 6 o'clock); ability +
  secondary buttons with charge rings (x885–985, y272–372); MOVE/LOOK caption chips; fire
  heat ring; per-segment hold state (`_held`); `_process` layout self-heal. Whole widget
  gated on `PlatformUtil.prefers_touch_ui()`. Smoke accessors preserved (`fire_button`,
  `ability_button` prefix DASH, `razor_button`→segments[0], `maul_button`→segments[2]) plus
  new `lock_button` / `segment_count`.
- **Cross-platform input:** new `src/core/util/platform.gd` (`PlatformUtil`: os_name /
  is_windows / is_android / has_touch / prefers_touch_ui / `input_hint_lines()` used by the
  menu controls hint, height 104) and `src/ui/gamepad_nav.gd` (`GamepadNav.enable(root)`,
  `focus_default(root, preferred)` — walks FOCUS_NONE → FOCUS_ALL). `InputRouter` gained
  keyboard/mouse/gamepad bindings at runtime (WASD+arrows+dpad, SPACE/LMB/RT/A fire,
  `lock_cycle` KEY_T + Y, `pause` ESC/START/BACK, `ui_accept` A, `ui_cancel` BACK+B),
  `slot_held[4]` per-weapon group fire (wired into `WeaponSystem`), `pad_connected` +
  `joy_connection_changed` → `Events.gamepad_connection_changed`; new signals
  `lock_cycle_requested` / `ui_back_requested`. Menu fire→start ignores stray mouse/touch;
  pause-open `ui_cancel` gated to `InputEventKey` (pad B closes menus, never fires ability).
  GamepadNav focus wired in main menu, pause/exit confirm, HUD end panel.
- **Hardware + AUTO quality tier:** new `src/core/util/hardware.gd` (`Hardware`:
  `gpu_score()` keyword+regex tiers, `cpu_class/cpu_cores/_cpu_ghz` (/proc/cpuinfo, guarded
  `OS.get_processor_speed`, Windows `reg query` MHz), `_ram_gb`, `fx_scale()` 0.5–1.5,
  `recommended_tier()` GPU-led with CPU caps, `short_label/describe`). `Quality` gained
  `tier_label()` "AUTO·" prefix, 5-state `cycle_tier()` (AUTO→LOW→…→ULTRA→AUTO at the
  recommended cap) and `tick_adaptation(delta)` (<38 fps ×4 samples → drop one tier,
  >56 fps ×15 → raise, capped at recommendation; last env/sun refs stored for reapply).
  `GameState.quality_auto` (default true, saved `graphics/auto`) seeds the tier on load;
  `GameSession._process` calls `tick_adaptation`; debug overlay shows `SYS <label>`.
  fx_scale also drives CombatFx scorch pool cap (≥4) and weather particle amounts.
- **Battle status feed (new `src/ui/status_feed.gd`, `class_name StatusFeed`):** WR-style
  red ticker, bottom-centre (anchors 0.5/1.0, offsets −260..260 × −150..−52 → clears MOVE,
  LOOK, fire ring, ability, HazardChip), `MAX_LINES 4`, 4 s life + 0.6 s fade, events →
  `DEPLOYED <ROBOT>` + `HOSTILE WAVE DEPLOYED · n` / `HOSTILE DESTROYED · n LEFT` /
  `UNIT DESTROYED` / `AREA SECURED`. Research note: WR uses in-battle announcements
  (kill/assist/multi-kill, pilot voice lines on deploy/destroy) and a post-death
  Elimination Report, but publishes no fixed placement — bottom+red is the director's spec.
  Distinct from the existing top-right `KillFeed`.
- **Haptics:** `Haptics.pulse` now also drives `Input.start_joy_vibration` when a pad is
  connected.
- **Version:** `0.28.0` / code 28 / `BUILD_LABEL = "v0.28.0 · 2026-10-06"` (trio moved
  together).
- **Smoke 1080 → 1125:** `_check_hardware_profile` (rec range, fx scale, cores, labels,
  AUTO cycle round-trip + restore), `_check_status_feed` (presence, content after push +
  kill emit, line cap, bottom-centre geometry), `_check_lock_cycle` (advance + loop-wrap to
  nearest, ≥2 staged cone candidates), `_check_slot_firing` (slot_held direct mount fire),
  touch-panel geometry block (pins SCARAB loadout `RAZOR-M×2/MAUL-M×2` and restores it;
  segment_count 4, lock below fire, radius 120±8, ring inside viewport, visibility ==
  `PlatformUtil.prefers_touch_ui()`), pad binding asserts (A/BACK+B/START/Y), pause-hint
  text, RMB-drag look. Smoke disables `quality_auto` in `_run` (llvmpipe would rec LOW) and
  restores it in `_finish`.
- **Incidents:** `String.split_whitespace()` doesn't exist in GDScript 4.4 →
  `split(" ", false)` (parse errors at `hardware.gd:123`); status-feed count asserts were
  cap-sensitive (4→4 when the stack was already full) → content-based `_feed_has_text`
  asserts; dev `settings.cfg` economy had drained below the §19 grant floors mid-batch
  (parts 28000 / chips 2500 / modules 90 / plat 4040) → repaired to floors
  (250000/100000/3000/100000); restore logic verified, floors held across both runs.
- Still queued: in-game resolution/windowed/fullscreen settings; out-of-app notifications;
  WR combat-stat visibility pass; LightmapGI/VFX overhaul; paint/camo shop; PRAETOR portrait.

---

## 31. Input-mode detection + PC-appropriate UI (v0.28.0 code, static-only — no Godot run)

Director task: a PC player must never see the giant touch buttons — the UI has to speak
keyboard/mouse, controller or touch, detected live. Rules for this batch: edit only
`src/ui/{touch_controls,hud,main_menu}.gd`, `src/world/game_session.gd`, the
`input_router`/`game_events`/`game_state` autoloads and NEW files under `src/core/util/`;
`smoke_test.gd`, `combat/*`, `player/*`, `enemies/*`, `theme_builder.gd`, `scene_router.gd`
read-only; **no Godot runs/imports and no commits**, so `./tools/validate.sh` was NOT run —
verified with `gdparse`/`gdlint` only. Run validate before committing.

- **`src/core/util/platform.gd` rewritten (~419 lines, `PlatformUtil`):** `enum InputMode
  {TOUCH, KEYBOARD, GAMEPAD}`; static `current_mode` + `init()/set_mode()/refresh_settings()`;
  `detect_mode()` = headless → TOUCH, Android/iOS → TOUCH, pad connected → GAMEPAD, else
  KEYBOARD; `effective_mode()` applies the `GameState.input_ui_mode` override
  (AUTO / FORCE_TOUCH / FORCE_OFF); `prefers_touch_ui()` stays the plain AUTO platform rule
  (what smoke compares against); `observe_event(event)` **observes only** (never consumes)
  ScreenTouch / MouseButton / Key / JoypadButton / JoypadMotion and flips `current_mode`.
  Desktop-touch ordering (project.godot has `emulate_touch_from_mouse`, no
  `emulate_mouse_from_touch`): a ScreenTouch counts only when `has_touch()`, no mouse button
  is down, and there is no keyboard/mouse evidence inside `MOUSE_LOCK_MS (3000)`; a
  MouseButton/Key sets KEYBOARD but is ignored inside `TOUCH_GRACE_MS (400)` of a real touch.
  Headless + mobile return immediately, so smoke can never flip modes.
- **Binding-derived control text:** `input_hint_lines(ability, secondary)` prints the REAL
  InputMap bindings — `WASD MOVE · RMB DRAG LOOK · SPACE / LMB FIRE · SHIFT / Q DASH` /
  `1 / 2 WEAPON GROUPS · E SECONDARY · T LOCK · R RESTART · ESC PAUSE` plus the pad
  equivalents (`_pad_hint_lines`) and the old fixed touch line. Also `badge_for(action)`,
  `accept_badge()`, `cancel_badge()` (pad prefers B over SELECT for back), `mode_label()`,
  `activate_verb()`. Look/fire constants (`MOUSE_LOOK_BUTTON`, `PAD_LOOK_AXIS_*`,
  `PAD_TRIGGER_FIRE_AXIS`, `MOVE_ACTIONS`) moved here so InputRouter and the hint text share
  one source — `GameState` must NOT reference `PlatformUtil` (const-eval cycle; the existing
  `GameState → Hardware → PlatformUtil → GameState` cycle already validates at HEAD).
- **New `Events.mode_changed(mode: int)`** (additive). Listeners: `TouchControls` (toggles the
  rig, `InputRouter.clear_temporary()` when hiding), `Hud` (`_sync_control_hints`), `MainMenu`
  (hint/badges/settings captions + gamepad focus), `GameSession` (pause-hint text).
- **Touch gating:** `TouchControls.should_show()` = headless → true (smoke asserts the full
  rig), FORCE_TOUCH → true, FORCE_OFF → false, mobile → true (a phone's rig never disappears
  under a stray key), else `current_mode == TOUCH`. In headless both it and
  `prefers_touch_ui()` are **true**, so both `visible == prefers_touch_ui()` asserts hold.
- **Hint strips:** `Hud._build_control_hints()` adds `ControlHints` (bottom-centre
  `UiTheme.panel(0.55)` panel, 1040×44 at y −50..−6, directly above `StatusFeed`), hidden in
  touch mode; `_menu_caption()` turns `MenuButton` into `MENU  ESC` / `MENU  START` and the
  button auto-widens from measured text width so the chip never clips. Menu `Hint` label got
  `<verb> TO BATTLE` (TAP/CLICK/SELECT) as its last line; the pause menu uses `_hint_text()`;
  debug line 2 shows `IN <KEYS|PAD|TOUCH>`.
- **Key badges:** `_refresh_badges()` walks the menu tree and puts a `KeyBadge`/`KeyText` pill
  bottom-right of **StartButton** (accept) and `Back*`/`Close*` buttons (cancel) — only for
  buttons ≥160 px wide (the 124 px `< BACK` is excluded so captions never overlap), pill width
  measured from the glyph run, one node per button toggled by `visible` (never free/recreate:
  two mode changes inside one frame would otherwise refresh a node already queued for
  deletion). Button `text` is untouched — smoke asserts `StartButton.text == "TO BATTLE"` and
  finds REDEPLOY/MAIN MENU by text.
- **Settings:** new `ControlsModeButton` (`CONTROLS: AUTO / TOUCH / KEYS`) cycles
  `GameState.cycle_input_ui_mode()` (persisted `config "input"/"ui_mode"`, clamped on load)
  then `PlatformUtil.refresh_settings()` force-emits `mode_changed` to re-label everything.
  Panel grown ±272 → ±330 to fit the extra row.
- **Gamepad focus polish:** focus is grabbed only when `effective_mode() == GAMEPAD` (pause
  Resume, end panel, menu StartButton, plus new `_focus_gamepad(panel)` on settings/store/
  inventory open) — mouse players never get an unrequested focus ring.
- **Smoke contract preserved:** no assert references the new API (`ui_mode`, `ControlHints`,
  `KeyBadge`, `mode_changed`), all asserted `Button.text` values are unchanged,
  `InputRouter._unhandled_input` signature is untouched (smoke calls it directly), listeners
  are additive, and `settings.cfg` has no `ui_mode` key (defaults AUTO).
- **Verification:** `gdparse` clean on all 8 changed files; `gdlint` shows only pre-existing
  categories (file/line length, class order, `unused-argument delta` in `game_session`).
- Gotchas: a local `var label` inside a method shadows the static `label()` (renamed
  `pad_label`); `Font.get_string_size` is `(text, alignment, width, font_size)`; HUD
  `MenuButton` sits beside the 236 px HP panel, so auto-widening must go right into free space
  (it does).
- Still queued: in-game resolution/windowed/fullscreen settings; out-of-app notifications; WR
  combat-stat visibility pass; LightmapGI/VFX overhaul; paint/camo shop; PRAETOR portrait.

---

## 32. WR combat realism round: target HUD, weapon destruction, healing FX, sell/stock, ranges, loading screen, 2 titans (v0.29.0, smoke 1250)

Director round 14-16 mega-batch executed as parallel agent waves on disjoint file sets
(agents code-only, main session validated serially between waves). Final gate: **1250 smoke
checks, 0 failures** (`VALIDATION PASSED`). Build stamp `v0.29.0 · 2026-10-07`
(project/export/BUILD_LABEL moved together).

- **WR target HUD + accumulating damage numbers:** `health.gd` Zone enum (hull/shield kinds)
  + shield pool; enemy per-kind shields (Ancile/Aegis-style rows); `target_info.gd` (named
  labels NameLabel/ShieldLabel/HullLabel/DistLabel + amber `MARK` row); `damage_numbers.gd`
  rewritten WR-style (accumulating per-target number, fade 2 s / forget 15 s, resume from
  prior total); `fmt_amount` promotes at 999,500 so sub-10 M reads `1.00M` not `1000K`;
  setting `extended_target_info` toggles the box.
- **Lock-on aim fix:** lock anchor was `global_position + UP*1.4` — above capsule tops for
  ARACHNID/WASP/BRUTE, so LOS/aim rays passed over heads ("guns shoot thin air").
  `weapon_system.gd` now uses `_hitbox_anchor()` (largest CapsuleShape3D `centre_y +
  height*0.4`, fallback 0.3) for lock aim + all mounts; `_locked_enemy()` walks parents.
- **WR 12.4 weapon rebalance + real ranges:** all 30 items remapped to WR archetype ladders
  (damage/rpm/spread/heat, header table documents archetype); second pass set REAL effective
  ranges (speed×lifetime / beam_range) per archetype: RAZOR 500, MAUL/VOLT/ECHO 350,
  TORQ/OVERLORD 600, BREACH/VOLLEY/titans 500, beams 500; builtins 350/500; drone gates
  40/90/100/80 m; max lifetime 2.5 s (pool-safe). Flame kept 66 m (cone weapon).
- **Scorpion wall-climb + per-part motion:** `LegUnit` climb gait (reach-budget solve, plant/
  return blends), `robot_rig` climb pose (lean/roll/head-up/tail-lift 0.4 s blend) driven by
  `player_robot` wall-climb state; per-part polish (head follow/counter-roll/lag tunables).
- **Touch panel mega:** wheel slot 0 = dynamic per-robot ability slice (label + ×N charges +
  recharge arc, charge sync fixed — session built touch before player existed); standalone
  LOCK button in the wedge gap wired to `Events.lock_cycle_requested`; **DEATH MARK**
  (side-weighted `apply_death_mark(5 s, 1.3)` refreshed via `_set_lock`, DM status chip +
  target-info row, incoming damage ×1.3); **per-family glyphs** on all 10 weapon kinds drawn
  in `_draw` (sonic ))) waves, flame teardrop, pellet fan, bolt…); **per-weapon cooldown
  countdowns** (`%.1f` s + drain arc per segment from real heat/reload math, per-mount
  overheat tint); ability/secondary buttons seated beside FIRE (250 px, all rect predicates
  re-verified).
- **Weapon destruction + critical damage (WR):** focused fire below 55 % HP builds per-mount
  stress weighted by hit side (flank → that side's gun); at 0.18×max stress roll → explosion
  (FX + tumbling debris + camera shake), mount `mark_destroyed()` (hidden, excluded from
  fire/heat), touch segment becomes an **empty OFFLINE slot** (✕ + dashed rim, still counts
  to segment_count 4), HUD W1/W2 group labels grey/red; **last weapon can never die**
  (builtin survives). Enemies lose their gun for good (CR chip, `_fire_once` dead).
  `src/combat/damage_reaction.gd` `DamageReactionController` (data-driven, attached player +
  enemies): crit ≤30 % HP → spark/smoke + trim flicker, hysteresis clear ≥40 %, UI `CRITICAL`
  chip / target-info `DAMAGED` row / red CR marker.
- **Healing FX (WR):** `src/combat/heal_fx.gd` `HealFxController` — heal deltas detected vs
  previous HP: green ring + sparkles + cross glyph (bigger for drone emergency ≥5 %),
  accumulate regen trickle ≥1 %; `drone_orbit` repair beam (green segment from pod to hull,
  fading) on emergency burst; new materials only, shared rig materials untouched.
- **Loading screen + memory hygiene:** `src/ui/loading_screen.gd` + `loading_pose_driver`
  (SCARAB-class rig posed on hex pad, wordmark, original tips) driven by rewritten
  `scene_router` overlay state machine — REAL progress: threaded 0→70 % (`load_threaded_
  request`, headless falls back to direct), build 70→90 % (label set before the synchronous
  arena build), deploy 90→100 % (grounded-spawn driven); `_arm_switch_guard_clear` byte-
  identical (smoke router-guard passes); quiet-moment warm-up on menu + `AssetLibrary.
  clear_caches()` 2 frames after goto_menu (never during a load) so memory doesn't creep.
- **Sell system + stock:** `game_state` sell APIs (items 40 % of buy, robots explicit table
  25k/45k/60k/400k, pilots rarity×8k+lv, drones rarity×6k; silver only; guards: mounted/assigned/
  selected/last-robot/last-drone; mutate → save → `wallet_changed`); `main_menu` SELL rows with
  CONFIRM/KEEP prompts in all four card types; Assign/Inventory show **FREE stock**
  (`free_copies`) with `ALL MOUNTED` disabled state — equip visibly decrements.
- **Spec hex grid + hangar restyle:** SpecPopup = custom-drawn flat-top hex cells (CORE/
  FIREPOWER/SURVIVAL/MOBILITY bands, rank pips, green purchased outlines, dashed connectors,
  hover hint) over unchanged rank/cost wiring; hangar got `HANGAR // DECK` header, bottom
  **robot strip** (owned mini-cards, select/cycle, locked → store), titan preview **glow
  frame**, sectioned robot card, SETTINGS moved to bottom bar — all 17 smoke `Layout/…` paths
  preserved.
- **Camera + terrain:** spring arm 8.6→11.0 + FOCUS_LIFT 0.5 (tail no longer crosses the
  timer panel); root cause of the "flat green slabs" = `Grass_Flat.obj` is an 8-vertex BOX
  instanced thick → replaced with zero-thickness PlaneMesh cover patches + new
  `_build_district_plateaus()` (seeded seam rocks/rubble/debris rings in each district's
  outer band, no colliders) + 5 dead `.DAE` refs → `.glb`.
- **PC input-adaptive UI (§31):** `PlatformUtil` mode detection + `CONTROLS:` override,
  binding-derived hint strips/key badges, touch rig gated off on KEYBOARD/GAMEPAD (headless
  keeps it for smoke), gamepad focus.
- **TITANS CITADEL + RAVAGER (director reference images):** Blender GLBs
  (`tools/build_citadel.py`/`build_ravager.py` → 24.5k/24.2k tris, 11-check self-validation,
  visual QA renders vs refs) — original names, WR-Bedwyr/WR-Mauler genre under original
  branding. Defs: CITADEL 500 000 HP / 5.6 m/s / [A,B,B] / JUGGERNAUT-A+CELERITY-B×2 /
  3000 Pt; RAVAGER 400 000 / 6.4 / [A,B,B] / DEMOLISHER-A+HAVOC-B×2 / 2800 Pt; neither owned
  by default. **4 new abilities** (AbilityBase): `challenge_ability` (single-target taunt
  9 s — enemy AI can't pick other targets — + death mark ×1.2, CD 13), `ironveil_ability`
  (9 s frontal barrier: −90 % damage, 35 % of incoming healed back, cap 0.4×max), 
  `shroud_ability` (8 s 50 m aura: 0.5 s slow+death-mark stacks to ×2.0, dark ground disc),
  `lunge_ability` (0.6 s dash, 2 charges/20 s, 2.5 s window converting 50 % incoming damage
  to repairable DoT — hull_fraction 0); per-def `passive_regen` (CITADEL 0.005×max/s);
  `titan_rig.gd` picks GLB per selected robot. Fixed pool top-up ordering (`_cover_mounted_
  copies()` after `load_settings` — new-chassis weapons were being wiped by disk pool).
  Smoke +76 asserts (`_check_new_titans`: defs/costs/pool guard, spawned rig + GLB meshes +
  forward aim + empty socket, armor, capsule, all 4 abilities round-trip).
- **Incidents:** (1) parallel-agent TLS failures (`self signed certificate`) on 6-agent
  bursts — relaunch in smaller batches; (2) `theme_builder.gd` had pre-existing uncommitted
  `shadow_spread` (not a 4.4 property) breaking `glow_frame()` compile — one-line fix by an
  agent to unblock validation; (3) headless exit reports "2 resources still in use" (benign,
  EXIT=0 — likely loading-screen holds); (4) smoke mutations must restore same-typed values.
- **Artifacts:** rebuild both targets after this commit — exe + APK from Oct 6 predate the
  whole round. Deferred backlog unchanged (LightmapGI, VFX overhaul, paint/camo shop,
  out-of-app notifications, PRAETOR portrait).

---

## 33. Titan GLB geometry rebuild + ability FX + titan pose-driver fix (v0.29.0 batch 2, smoke 1256)

Second commit of the v0.29.0 round: both titan GLBs rebuilt from the reference-art critique
("crude box-stacks"), ability FX passes, and the hangar/loading titan-preview fix. Validated at
**1256 smoke checks, 0 failures** (`VALIDATION PASSED`).

- **CITADEL GLB rebuild (`tools/build_citadel.py`):** faceted tapered chest (side facets rot_z
  ±13° + steel trim edge strips), gorget collar (side plates x±0.80 clear the ±37° head-yaw
  sweep), enlarged head, layered pauldrons (dome + under-rim + crown cap + deltoid plate over
  the shoulder ball), hip cover plates over shrunken joint balls, thicker arms, **tower shields
  0.19×1.42×1.10** (accent band + trim crown, outer edge ≤1.415 so beta barrels at ≥1.45 stay
  clear), thicker legs (thigh loft [0.30,0.38,0.31,0.23], shin [0.26,0.31,0.24,0.18], side
  skirts, bigger knee cap), bigger clawed feet (pad bottom −0.11 = ground target).
  Result: **21,128 tris**, bbox ratios 1.013/1.117/1.148 vs princeps, 11-check script validation.
- **RAVAGER GLB rebuild (`tools/build_ravager.py`):** angled chest facets + trim edge highlights,
  shrunken/recessed belly reactor ball, hip cover plates, shoulder joint caps, thicker legs
  (thigh [0.29,0.36,0.29,0.22], shin [0.25,0.29,0.22,0.17] + side skirts), bigger clawed feet
  (pad 0.84×0.22×1.04, three forward claws to z−0.44). Result: **20,008 tris**, bbox ratios
  1.086/0.958/0.971, VALIDATION PASSED.
- **Bevel tri-budget fix:** first CITADEL rebuild failed its 25,000-tri ceiling (30,728) —
  `build_mech.construct` bevel **segments 3→2** (a beveled box was 188 tris; ~35% cut) applied
  to every future builder run.
- **Titan pose-driver fix:** `hangar_pose_driver`/`loading_pose_driver` branched on
  `selected_robot == ROBOT_PRAETOR` only, so CITADEL/RAVAGER fell through to a SCARAB clone.
  Now `bool(GameState.robot_def().get("is_titan", false))`; smoke loops every robot in
  `ROBOT_ORDER` through `driver.rebuild()` and asserts the rig class per chassis.
- **Ability FX:** `shadow_dash` pulse visual rewritten (cone-fan mesh + material, CPU particle
  bursts, bolt segments, enemy burst) ; `shroud_ability` gained orb motion, ground-rim flash +
  shader; `kick_ability` telegraph hooks added across the 6 remaining ability scripts
  (`robot_rig.kick_ability` +29 lines).
- **Visual QA pipeline (image-read channel broken this session):** the `read` tool returns
  wrong/stale images for PNGs — do NOT trust it until re-verified. Workflows that work:
  `tools/dump_mesh.tscn -- <robot>` now writes a **`player_aabb`** field (merged global AABBs
  of visible robot meshes); `tools/render_views.py` frames its six views from that AABB
  (chest = min+0.55·h, distances scaled by rig_h/3.6, arrow scaled); turntable renderer
  `/tmp/opencode/rt.py` (player-AABB-filtered, `build/robot_turn/*.png`) + ASCII viewer
  `/tmp/opencode/ascii_view.py <png> [cols]` for silhouette judgment.
  Content sanity check when unsure whether a PNG view is real: interior-pixel fraction of the
  turntable renders should be 0.39–0.59.
- **Build stamp unchanged:** `v0.29.0 · 2026-10-07` (code 29) — this batch rides 0.29.0.
  APK/exe rebuild still pending at batch end. Deferred backlog unchanged (LightmapGI, VFX
  overhaul, paint/camo shop, out-of-app notifications, PRAETOR portrait) plus the director's
  open round-14/15 items (resource bumps, weather readability, WR rebalance sign-off, hangar
  layout polish, bottom status bar).

---

## 34. Touch de-dup, single glassy battle indicator, WR-style deploy screen (v0.29.0 batch 3, smoke 1269)

Director round: duplicate ability buttons ("already on circular controller"), duplicate
battle damage/HP/bot indicators ("damage has to be a number in air near the bot, not in a
dialog; HP/name may stay but glassy/transparent to avoid obstruction"), and "loading screen
in match sucks — replicate the real War Robots battle-load appearance with MECH ASSAULT
info". Validated at **1269 smoke checks, 0 failures** (`VALIDATION PASSED`).

- **Touch panel Option B — the circular controller is the single home for everything:**
  ability (and the titan secondary) are WEDGE SLICES, the floating right-side ability column
  is gone. Wheel layout is now `[ability, secondary?, …weapons]` — `_slice_base()` (1 or 2),
  `_segment_count()` = base + slots, index 0 pinned at 6 o'clock; new `_draw_ability_slice`
  (name, ×charges, recharge arc) and `_draw_secondary_slice` (amber, chevron mark); slices
  are flat `Button`s (`AbilitySliceButton`/`SecondarySliceButton`) with **transparent font
  colour overrides** so the wedge art draws the label while `.text` stays readable for
  smoke/tools (`ability_button()` now returns the slice — `text.begins_with("DASH")` still
  holds; new `secondary_button()`). The lock plate moved to the first wedge GAP via
  `_lock_angle() = PI*0.5 + PI/count` (126° at 5 slices, 120° at 6) — consts `LOCK_ANGLE`,
  `ABILITY_SIZE/GAP/TOP_GAP`, `SECONDARY_GAP`, the column layout and `_draw_charge_ring`
  (now uncalled) were removed. Damaged weapon wedges read **`DAMAGED`** (was `OFFLINE`).
  Probe `tools/touch_probe.{gd,tscn}` (prints every visible touch button per robot):
  SCARAB = FIRE + AbilitySlice + 4 weapon slots + LOCK; PRAETOR adds `SecondarySliceButton`.
  Smoke: ring-distance/below-fire geometry for the ability wedge, `secondary_button()==null`
  on SCARAB, and an **anti-duplicate assert** (exactly one button whose text starts with the
  ability short name).
- **Single glassy battle indicator (duplicate dialog removed):** `TargetInfo` (the WR
  "extended target" box that re-showed name/hull/range next to the locked enemy) is **gone**
  — file deleted, plus every touchpoint: `hud.gd` (`_target_info` var/creation/set_target),
  menu checkbox `TARGET INFO (WR)` + handler, `GameState.extended_target_info` var/setter/
  save/load (orphan `hud/target_info` config key ignored). `EnemyMarkers` is now the one
  readout: translucent **glass slab** (`Panel` + cached `_glass_normal`/`_glass_locked`
  StyleBoxFlats — white rim at rest, red while locked, bg alpha 0.40/0.50 so the battlefield
  stays readable) carrying name, **hull number** (`Hp` label, `fmt_amount`), hull bar, range
  and status chips; the old red border `ColorRect` frame was replaced by the locked stylebox.
  Damage numbers were already in-air (`DamageNumbers` unprojected at the bot + side offset)
  and stay that way — never in a dialog. Smoke: `TargetInfo == null` (no-dup proof), glass
  present + translucent (alpha ≤ 0.55), hull/name labels, hull number fills on-screen.
- **Loading screen rebuilt after War Robots' battle-load screen:** `loading_screen.gd`
  rewritten as a deploy **briefing** — top logo band + `DEPLOYING` state, hero band with the
  map name huge (`OPEN REALM`, 46pt amber) + three mode chips (`SURVIVAL` / `15 HOSTILES` /
  `05:00` — hostile count derived from `EnemyRobot.KIND_PATTERN`, never hand-stale), two
  column roster (`ALLIES // 1` card: robot name/class/ARMOR/ABILITY/WEAPONS families/
  BUILT-IN from `GameState.robot_def()` + `loadouts`; `HOSTILES // 15` rows: ARACHNID ×6 /
  STALKER ×3 / BRUTE ×3 / WASP ×3 with their weapon names via `HOSTILE_NAMES`/
  `HOSTILE_WEAPONS` tables), bottom keeps the honest stage/percent/progress bar + map line +
  rotating TIP. The 3D SubViewport robot preview, orbit camera and `LoadingPoseDriver`
  wiring were dropped (WR shows map/roster art, not a turntable — also cheaper during the
  load). Public API unchanged (`new`/`set_progress`/`dismiss`/`LAYER`); `SceneRouter`
  untouched. Smoke `_check_loading_screen()`: hero/chips/roster-card structure, hostile chip
  == pattern size, roster rows == distinct kinds, 50% percent + stage + fill ratio + tips.
- **Smoke 1256 → 1269** (−7 TargetInfo asserts, +1 no-dup, +5 marker-glass, +11 loading).
  `tools/touch_probe` committed alongside (untracked until now).
- Build stamp unchanged `v0.29.0 · 2026-10-07` — APK/exe rebuild still pending at batch end.
  Still open from §12–33: WR combat-stat visibility pass, LightmapGI/VFX overhaul,
  paint/camo shop, PRAETOR portrait, startup boot-splash overlay (settings mapped:
  `project.godot` `boot_splash/show_image=false`, `res://logo_menu.png` ready).

---

## 35. Device hotfix batch: raw multi-touch input + Princeps-exact abilities (v0.29.0 batch 4, smoke 1283)

Director's device round: **centre FIRE button dead on device (worst on titans)** and **PRAETOR
special abilities "don't even work at all"** — demanded EXACT Princeps specs from research.
Validated at **1283 smoke checks, 0 failures** (`VALIDATION PASSED`).

- **Fire/ability root cause PROVEN** with `tools/fire_probe.{gd,tscn}` (kept as a regression
  probe): a second finger (index ≥1, e.g. while the move stick is held) never reaches Godot
  GUI Buttons — the GUI routes only the emulated mouse (finger 0) to them, so every on-screen
  control was dead the moment a second touch existed. Probe: finger 1 over the FireButton rect
  still landed in `TouchControls._unhandled_input` in canvas coords.
- **Fix = raw multi-touch claims in `touch_controls.gd` (input layer only — rects/offsets/
  drawn art untouched):** `_unhandled_input` now handles `InputEventScreenTouch`/`ScreenDrag`
  directly: `_role_at()` claims a role per finger (priority fire circle → lock → ability →
  secondary → `slot%d` via `_segment_slots`), hold roles (`fire`/`slot`/`lock`) keep
  per-finger counts OR'd with the Button state in `_sync_fire/_sync_slot/_sync_lock_visual`,
  tap roles (`ability`/`secondary`) fire on release-inside through the existing
  `_request_*` Dictionary guards (0.3 s tap guard). Stick claim preserved (left 35 % zone,
  `input_pass` pattern unchanged); sliding the fire finger off the circle releases it
  (role erased on drag-off). Wheel buttons set `MOUSE_FILTER_PASS` so finger-0 GUI clicks
  still work; `_reset_raw_state()` clears counters on mode hide.
- **Princeps research (WR 11.6/12.2 + wiki, numbers exact):** Null Field — **6 stasis hits,
  10 s duration, 12 s cooldown, per-hit Quantum Lock 1 s**; Grav Thrust — **2 charges,
  9 s cooldown, 0.5 s cast delay, push + 50 % slowdown for 5 s** (half on titans). Scaled to
  the 460 m map (cast range 90 m).
- **`nullfield.gd` rewritten** (`max_charges 1`, `recharge 12.0`, `barrier_duration 10.0`,
  `barrier_hits 6`, `lock_duration 1.0`): hits are counted from `Health.damaged` (emitted
  with `amount > 0`); **absorption switched from heal-based to a shield pool**
  (`configure_shield(PHYSICAL, max_health*1000, 0)` saved/restored around the barrier) —
  the old heal-based soak was a silent no-op at full HP (`heal` before `current -=` at cap)
  so the barrier appeared to do nothing; the pool soaks exact damage at any HP and still
  emits `damaged` so hit counting works (`shield_mult=0` would early-return before the emit
  — deliberately avoided). Pool held while `barrier_active or _lock_left > 0` (1 s Quantum
  Lock tail), dropped on `force_end`.
- **`grav_thrust.gd` rewritten**: charge spent immediately on `activate()` (keeps smoke
  `charges == 1`), 0.5 s `_pending_target` cast delay in `_physics_process`, target =
  `locked_enemy` else nearest LOS enemy (`_enemy_gone` helper — `state == DEAD` /
  `health.dead`; `EnemyRobot` has no `target_is_dead`, that method lives on `DroneOrbit`),
  execute = `apply_grav_pulse` + `apply_slow(5.0, 0.5)` + `apply_system_jam(0.8)`; whiff
  keeps the charge spent; phases THRUST → READY/RECHARGING; secondary phase/charges events.
- **Smoke 1272 → 1283:** titan block now pins Princeps tuning (`max_charges == 1`,
  `barrier_duration == 10.0`, `barrier_hits == 6`, grav `== 2 / 0.5 / 5.0`), asserts
  `charges == 0` after nullfield activation, and a **functional absorb-at-full-HP test**
  (`apply_damage(250000)` at cap leaves hull unchanged, pool up during / dropped after
  `force_end`). New **raw multi-touch block** in the menu phase drives
  `game_touch._unhandled_input` directly with canvas coords: finger-1 FIRE down→slide-off→up
  (`fire_held` true → false → false), finger-2 weapon-wedge hold/release via
  `_segment_slots[0]`, finger-3 ability tap (`ability_requested` then `clear_temporary()` so
  the player's dash charge is never spent before the later dash asserts).
- **Incidents:** smoke `game_touch` is typed `Control` → member calls return Variant
  (`:=` inference errors on `get_rect()`) — annotate `var seg_rect: Rect2` explicitly;
  `zsh` ate nothing this round (validate quoted heredoc OK). `project.godot` boot-splash
  block (logo + dark bg) finally rides this commit; `tools/fire_probe.*` kept as a tool.
- Still open from §12–34: WR combat-stat visibility pass, LightmapGI/VFX overhaul,
  paint/camo shop, PRAETOR portrait; next batch = battle-UI polish (thin enemy bars,
  edge-falloff vignette) then RAVAGER Mauler-exact abilities.

---

## 36. Battle-UI polish: thin enemy markers + edge-falloff damage vignette (v0.29.0 batch 5, smoke 1287)

Director screenshot round: enemy HP readouts obstruct the fight, damage flash washes the
whole screen pink. Validated at **1287 smoke checks, 0 failures** (`VALIDATION PASSED`).

- **Thin markers (`enemy_markers.gd`):** 116×50 root + 124×78 glass slab → **76×48** root
  with a slim 82×31 translucent backing behind just the name line + bar (keeps the smoke
  `glass` Panel contract: StyleBoxFlat bg alpha ≤ 0.55). Layout top→bottom: effect-chip row
  (17 px, now INSIDE the root), name (10 px) + hull number right-aligned on one 12 px line,
  **76×6 HP bar**, centred 9 px distance caption. Lock state shows as red colour + red glass
  rim (the HUD TARGET frame carries the tag) — the `LOCK // ` name prefix is gone so the
  thin name line never blows out. Markers now also occlude behind **EndPanel** (added to
  `OCCLUDER_PANELS`, invisible during play so nothing changes mid-match) → the whole readout
  disappears when the death/end panel is up.
- **Edge-falloff damage vignette (`hud.gd _build_overlays`):** the full-screen `DANGER`
  ColorRect tinted the ENTIRE picture pink on every hit (uniform alpha 0.4). Replaced with a
  `canvas_item` ShaderMaterial — `smoothstep(0.44, 0.98, d)` radial falloff, aspect-corrected
  so corners land at 1.0; centre stays clear. The existing `_flash_vignette` tween keeps
  driving `modulate:a` unchanged (shader multiplies by `COLOR.a`).
- **Smoke 1285 → 1287:** `hud.get("_vignette").material is ShaderMaterial` (typed via
  `get(...) as ColorRect` — `hud` is declared Control, member access is Variant → `:=`
  inference error), `OCCLUDER_PANELS.has("EndPanel")`, marker root ≤ 90×56 and glass slab
  ≤ 90 px wide (pin the thin design), existing glass-alpha/hull/name/status asserts kept.
- Still open from §12–35: WR combat-stat visibility, LightmapGI/VFX overhaul, paint/camo
  shop, PRAETOR portrait; next = RAVAGER Mauler-exact abilities.

---

## 37. RAVAGER Mauler-exact abilities (v0.29.0 batch 6, smoke 1289)

Director: *"RAVAGER Mauler-exact abilities"*. War Robots Mauler research (warrobots.com
robots/107, fandom/namu/takagaming — 11.6 numbers): **Dark Light** 8 s field, 175-200 m,
one Slowdown+Deathmark stack every 0.5 s up to 15, CD 13 s from field end; **Hook** 2
charges, ~1 s dash, converts ALL incoming damage to a halved DoT flow (no grey damage)
over ~4 s, CD 20 s; passive DoT resistance. Validated at **1289 smoke checks, 0 failures**.

- **`shroud_ability.gd` (Dark Light equivalent):** radius 50 → **100 m** (WR 175-200 scaled
  to our 460 m map, same ratio as grav cast 90 m), recharge 24 → **13** (literal, matching
  the nullfield-12 convention), `mark_step` 0.05 → **0.125** / `mark_cap` 2.0 → **3.0**
  (16 pulses × 0.125 = ×3.0 exactly as the field expires = WR's "full stacks by duration
  end" relationship). Duration 8 s + 0.5 s pulse already matched.
- **`lunge_ability.gd` (Hook equivalent):** `dash_duration` 0.6 → **1.0 s**; `convert_ratio`
  0.5 → **1.0** with new `dot_reduction = 0.5` — every point of a hit converts (landed = 0),
  the bank receives 50 %, drains over the unchanged 8×0.5 s ticks as repairable
  (`hull_fraction 0`) damage; conversion window now opens **on activation** (not after the
  dash) and re-activation refreshes it — WR's "refresh, never extend". `player_robot`
  comment updated. Passive `dot_taken 0.75` (25 % DoT resist) unchanged = WR base.
- **Defs:** shroud/lunge `ability_desc`/`secondary_desc` rewritten, `stat3_value` "50 M" →
  "100 M".
- **Smoke +2:** tuning pins in the RAVAGER swap block (`field_radius 100 / duration 8 /
  pulse 0.5 / mark_cap 3 / recharge ≤ 13.5`; `max_charges 2 / dash 1 s / convert_ratio 1 /
  dot_reduction 0.5`). Recharge is asserted `≤ 13.5` because `_ready` multiplies it by the
  cooldown combat stat.
- Still open from §12-36: WR combat-stat visibility, LightmapGI/VFX overhaul, paint/camo
  shop, PRAETOR portrait; next = electric-weapon WR research + parity pass, then APK.

## 38. Electric weapons WR parity: arc curve + chain shocks (v0.29.0 batch 7, smoke 1316)

Director: *"research electric weapons in war robots … make our electric-shock weapons behave
as is"* — then build both apps. WR research (fandom **Lightning: Cataclysm/Cyclone/Calamity/
Scourge/Spark** + **Shocktrain** pages; reference art saved `/tmp/opencode/ref/{spark,scourge,
calamity,shocktrain}.png` — images live on the `walking-war-robots` wikia path and need a
browser UA + `warrobots.fandom.com` Referer or Cloudflare answers): arc family (Spark/Scourge/
Calamity) = 600 m, proximity damage **+137% ≤50 m → +134% at 300 → baseline 400 → −77% at
600**, 85 charges / 8.4 s unload / 5 s reload, lock-on, pierces energy shields; chain family
(Shocktrain/Striker) = bounces to robots within 100 m of the previous victim at **−50% per
hop**, no chain through walls. Validated at **1316 smoke checks, 0 failures**.

- **Arc damage curve (`weapon_data.gd`):** `ARC_DAMAGE_METRES`/`ARC_DAMAGE_MULTS` knot tables
  (50..600 m → 2.37..0.23, linear interpolation, clamped) + static `arc_distance_mult(dist)`.
  `projectile.gd` records `_launch_origin` at `launch()` and `weapon_damage()` multiplies by
  `arc_distance_mult(muzzle→current)` for `Kind.ELECTRIC` only (override damage scales too);
  non-electric rounds untouched. Enemy ARC TESLA and drone ARCSTING ride the same curve by
  kind — faithful, and the smoke survival invariant is unaffected (it reads raw enemy damage).
- **Chain shocks (`projectile_service.gd _apply_chain`, called from `_route_damage`):** new
  `WeaponData.chain_bounces/chain_range`; on an **enemy** victim the arc gathers group
  `enemy` bodies within `chain_range`, sorts by distance, damages up to N hops at
  `weapon_damage() × 0.5^i`, each hop emitting `weapon_impact` (existing ELECTRIC FX/sound).
  A `Layers.WORLD` ray per hop makes it refuse to cross walls (WR 4.0 rule); the
  **enemy-victim gate** means player-hull hits never chain into anyone (deterministic smoke,
  no friendly fire). VOLT L/M/H = 2 hops / 50 m (WR 100 m scaled to the 460 m map),
  ARCLANCE-B = 3, ARC NEEDLER = 2, everything else 0.
- **VOLT rebalance to WR rhythm:** lifetime 1.17 → **2.0 s** (300 m/s → **600 m** reach, the
  WR arc range), heat L 0.10→**0.128** / M 0.12→**0.14** (H stays 0.17) so net heat
  ×rpm/60 −cooling lands ≈0.12/s → **~8 s burst** then the existing overheat cool-down
  (WR's 8.4 s unload / 5 s reload shape). ARCLANCE heat 0.16→**0.33** (~7.8 s burst).
  **Base damage deliberately unchanged** (730/825/870): the smoke invariant
  `scarab_armor/worst_dps >= 20` pins VOLT-M raw dps ≤ 17 000 — WR-ratio damage would fail it.
- **Store chips:** `_weapon_special_text` gains `CHAIN ×N · R M` and `DMG +137% CLOSE` for
  electric weapons.
- **Smoke 1289 → 1316:** `_check_electric_parity()` (phase 4, right after `_check_electric_arc`)
  — curve knots/clamps/monotonic sweep, VOLT 600 m reach + heat window per size, chain field
  pins, in-flight curve on a tree-resident bare `Projectile`, and a **functional chain test**:
  stages three SCUTTLERs along a ray-verified clear corridor (`_los_clear`), **temporarily
  pulls the live roster out of the `enemy` group** so a stray enemy can not steal a hop
  (restored in the same synchronous block), fires VOLT-M, calls `_apply_chain` directly and
  asserts the neighbour takes exactly half power, the 62 m target takes nothing (range gate),
  and a player-victim never chains; pool electrics deactivated + staged bots freed at the end.
  Gotcha: `global_position` does not stick on an **out-of-tree** Node3D — the in-flight curve
  probe must be `add_child`ed (not in `_pool`, so it stays inert) or every distance reads 0.
- **Build:** both apps rebuilt from this commit — `build/windows/mech-assault.exe` +
  `build/android/mech-assault-debug.apk` (v0.29.0). Still open from §12–36: WR combat-stat
  visibility, LightmapGI/VFX overhaul, paint/camo shop, PRAETOR portrait, world visibility
  round, out-of-app notifications.

## 39. v0.30.0: desktop input fix + boot-splash fix + version stamp discipline

Director report round: *"windows version … robot keeps playing itself, shooting randomly,
rotating around like buttons have bugs"*, *"why is it still v0.29.0, nothing I'm seeing
changed, delete all old and build again"*, *"bootscreen etc — seeing none"*. All three had
real causes; validated at **1319 smoke checks, 0 failures** (`VALIDATION PASSED`).

- **"Robot plays itself" root cause:** `project.godot` has `emulate_touch_from_mouse=true`,
  so on desktop every mouse press synthesises an `InputEventScreenTouch` — and
  `InputRouter._unhandled_input` claimed any touch with x > 35% of the screen as the look
  drag. Result: every LMB fire-drag (fire IS bound to LMB) and every HUD click also swung
  the camera. Fix: the ScreenTouch/ScreenDrag look path now runs only while
  `PlatformUtil.effective_mode() == TOUCH` (live touch rig); in KEYBOARD/GAMEPAD mode
  emulated touches are dropped and `look_touch_index` cleared. RMB mouse-look and all
  keyboard/gamepad paths unchanged; a genuine touchscreen laptop still flips the mode via
  `observe_event` and keeps touch look. Smoke adds 2 asserts (`_check_input_responsiveness`):
  ghost touch + drag in KEYBOARD mode produce zero look delta and claim no touch index.
- **Boot splash never showed (why "fixes are invisible"):** `project.godot` line
  `application/boot_splash/show_image=false` disabled the real setting, while a hand-written
  `[boot_splash]` section at the file bottom used an **invalid path** (`boot_splash/image` —
  the real keys are `application/boot_splash/…`) that Godot silently ignores. Fixed: all four
  keys moved into `[application]` with `show_image=true`, custom logo + bg colour; the bogus
  section deleted. Smoke asserts `ProjectSettings.get_setting("application/boot_splash/
  show_image") == true`. On desktop the splash is the first thing visible — an immediate
  on-screen marker of a fresh build.
- **Version discipline:** 0.29.0 rode through **four batches** (4–7), so every rebuilt
  artifact looked unchanged to the director. Bumped the trio together
  (`project.godot config/version`, `export_presets version/name + code 29→30`,
  `GameState.BUILD_LABEL = "v0.30.0 · 2026-10-07"`) — the label renders in the hangar
  footer and the debug HUD line, so one glance identifies the running build. Each future
  batch must bump at minimum when user-visible behaviour changes.
- **Fresh artifacts:** old `build/android/*.apk` + `build/windows/*` deleted, both exports
  rebuilt from this commit; APK content-verified by zstd-decompressing the shipped
  `game_state.gdc` (`v0.30.0` present) and the exe's embedded pck (GDPC parse → same
  marker). `build/windows/mech-assault.exe` + `build/android/mech-assault-debug.apk`.
- Still-open backlog (director's words, order unclear — confirm before starting):
  hangar layout polish, bottom status bar, resource bumps, weather readability, WR
  rebalance sign-off, WR combat-stat visibility, LightmapGI/VFX overhaul, paint/camo shop,
  PRAETOR portrait, world visibility round, out-of-app notifications.

---

## 40. UX rebuild round: physical hangar + crew screens (v0.32.0, smoke 1410)

Director round: two master prompts — (1) rebuild the hangar as a **physical 3D bay** with
robot pads you can click, then (2) progressively rework every crew screen (equipment,
inventory, store, upgrade, pilots, settings, battle, post-battle) with the safety rule
"checkpoint before modifying, never delete a working screen, one phase per commit named
after §124". Executed as 11 phases, each `validate.sh`-green before its commit:

| commit | phase | smoke |
| --- | --- | --- |
| `a064aed` | ui-foundation (recovery checkpoint: lineup staging, LIVE feed, arc-FX pooling, boot splash) | 1319 |
| `7c86cec` `871bb9d` | hangar-ui (6-platform bay + top-bar CTA + compact chips + 6-cell strip) | 1339 / 1348 |
| `5448ee2` | equipment-ui (full-screen workspace: stat block + per-hardpoint rows, ASSIGN/UPGRADE) | 1359 |
| `a368fbd` | inventory-ui (ON THE BAY / IN STORAGE / WEAPON STORAGE sections, bay-pad state) | 1363 |
| `f8493c8` | titan-ui (empty titan pad → store TITANS tab, ALPHA/BETA badge colours) | 1367 |
| `faccc7e` | fix: lightning bolt serial names (glob flake root cause) | 1367 |
| `567a73b` | store-upgrade (full-screen store, header wallet, 168 px tabs, MK1/2/3 ladder) | 1374 |
| `a806e6d` | social-ui (pilot full-screen: roster column + detail column, click-to-assign) | 1379 |
| `0c418f0` | settings-ui (LOOK/AUDIO/GAMEPLAY/SYSTEM sections, GRAPHICS cycle row) | 1389 |
| `50963fe` | battle-ui (HUD geometry audit: chrome fits viewport + designed gaps) | 1404 |
| `04108f7` | postbattle-ui (end panel line-broken rewards + modules + pilot XP tracking) | 1408 |
| `505770e` | ui-polish (inventory promoted to full-screen like its siblings) | 1410 |

Key architecture (`src/ui/hangar_slots.gd`, `HangarSlots`): six physical pads — hero + 4
flank + elevated rear titan — as the single source of truth for robot placement
(`slot_robot/assignment()/slot_screen_rect`), consumed by the pose driver, click-to-select,
slot camera fit and the bottom strip. All primary crew screens (Store, Equipment, Pilot,
Inventory) are full-screen workspaces (anchors 0..1, offsets 40/32) and smoke pins each at
≥1100 px; modals (assign/upgrade/settings/drones/spec) stay centred by design.

Engineering notes: `find_children` patterns are **globs** (Godot renames colliding children
so name-based lookups silently miss); never `free()` an object mid-signal (locked-object
error — `remove_child` + `queue_free`); store tab state survives close (smoke restores
`store_tab_set(0)`); `match_reward_modules` + `pilot_xp_gained` were added so the post-battle
panel can show totals that previously vanished into the wallet; HUD geometry is guarded by
`_hud_rect()` + fit/gap asserts (layout verified clean at 1280×720 — audit needed no fixes).

**Version:** trio moved 0.31.0 → **0.32.0** (project/export `version/code=32`/
`BUILD_LABEL v0.32.0 · 2026-10-07`). Final gate for this round: `./tools/validate.sh --apk`.
Still open from §29–39: out-of-app notifications (Gradle/aapt2 path), LightmapGI/VFX
overhaul, paint/camo shop, PRAETOR portrait, world visibility round, WR combat-stat
visibility.

---

## 41. UI hierarchy rebuild round: screen-stack shell replaces the menu monolith (v0.33.0, smoke 1369, C1)

Director round 18: the v0.32.0 hangar still read as a "mega dashboard" — one screen trying to
show the whole game's functionality. Directive (binding from here on):

- **ONE SCREEN = ONE PRIMARY PURPOSE.** The UI is a navigation hierarchy, not a dashboard.
  HANGAR = "What am I using?" (robot in 3D, deck, basic summary + equipped-weapon summary,
  titan bay, resources, TO BATTLE, a few primary nav buttons only) → ROBOT DETAILS = "How is
  it configured?" → EQUIPMENT/WEAPON SELECTION = "What can I equip?" → ITEM DETAILS = "What
  does this item do?" → UPGRADE = "How do I improve it?" → STORE/INVENTORY/SETTINGS own
  their screens. Never flatten levels; never reserve space for panels that are not open;
  drill down with opens, come back with BACK.
- **Git checkpoint rule:** commit validated work between phases — HEAD `ecf8e28` (green
  v0.32.0, smoke 1410) stayed intact while this round's work sat uncommitted.
- **Commit plan:** C1 = framework + hangar + robot/equipment + weapon select/detail +
  upgrade + thin-shell `main_menu` (this section) · C2 = pilot/drone/spec screens · C3 =
  inventory/store/settings (+ targeting-priority gameplay hook, NavLeft buttons) · C4 =
  battle HUD + post-battle results, ending with the director's acceptance checklist.

C1 contents (validated at **1369 smoke checks, 0 failures** — count dropped from 1410
because the old monolith's settings/pilot/store/inventory/stats popup asserts moved to their
phases; parity items re-added: gold chip, paint-restore, titan A/B slot sizes):

- **Shell:** `main_menu.gd` (was 5069 lines) is now a ~90-line background (gradient +
  GridStripes + BuildStamp) hosting one child, `UIManager` — screen stack (`push/pop/
  handle_back/refresh/toast`), single back path via `_unhandled_input` on `ui_cancel` (pad-B
  `Events.ui_back_requested` would double-pop — `JOY_BUTTON_B` also binds `ui_cancel`),
  `QuitConfirm` at root, persistent `ResourceBar`, lazy `SCREEN_SCRIPTS` creation and
  `_apply_visibility` that hides every screen not in the stack (no reserved empty panels).
- **Screens (`src/ui/screens/`):** `ui_screen.gd` base (`setup/open/refresh/on_enter/
  on_exit/is_opaque/back`, full-rect, PASS) · `HangarScreen` (transparent root: 3D bay with
  orbit/drag/tap-pick + closeup, lean InfoPanel **name/class/power/one-line weapon summary
  only** — `WeaponSummary` is names+counts, never stats, deck chips, titan bay with honest
  disabled `+ TITAN` placeholder, empty `NavLeft` for C3 nav buttons, TO BATTLE; `_process`
  gates the bay SubViewport `UPDATE_DISABLED` when hidden) · `RobotScreen` (transparent
  overlay: header/MECH stats/ability/pilot/drone/spec lines + per-hardpoint `EquipmentSlotRow`
  + PAINT/UPGRADE/CHANGE actions) · `WeaponSelectScreen` (2 tabs STORAGE/STORE, rows
  `WeaponRow_<id>`, click → detail) · `WeaponDetailScreen` (preview, `StatLine*`, BUY/EQUIP/
  UPGRADE visibility rules) · `UpgradeScreen` (MK ladder, CURRENT vs NEXT, priced confirm).
- **Navigation actually tested:** hangar→robot (deck chip + 3D hero-pad tap)→weapon
  catalogue→detail→back→back→upgrade→back→paint→pop→root BACK opens quit prompt→again
  dismisses. Empty pad inert until the store screen ships (no fake buttons).
- **Smoke rewrite:** the old `Layout/…` menu block (lines 1172–1883) was spliced out and
  replaced; audio/InputMap/Events/chips/music/data-check asserts from that range were
  re-included; old probes `layout_probe`/`menu_probe` deleted (paths gone), new
  `tools/paint_probe.{gd,tscn}` kept (diagnoses the synthetic swatch click: hovered-control
  + press-grab + palette delta).
- **Gotchas this batch:** (1) repeated runtime sibling names get uniquified by Godot
  (`StatLine` → only the first keeps the name — number them `StatLine%d` and count with a
  glob); (2) a smoke click measuring a control on the SAME frame it became visible reads
  pre-layout rects → `await process_frame` after revealing, before measuring; (3) the quit
  buttons live under `QuitBox/QuitActions/…`, not directly under `QuitBox`; (4) a local
  `var` in a sibling function is not in scope (`mounted_here` parse error); (5) headless
  window is 64×64 with `canvas_items`+`expand` → visible rect 1280×1280, so bottom-anchored
  rows sit at y≈1220 in headless — canvas-space math is fine, but do not assume 720p in
  probes.
- **Version:** trio moved 0.32.0 → **0.33.0** (code 33, `BUILD_LABEL v0.33.0 · 2026-10-07`)
  at C1 so every rebuilt artifact from this round identifies itself. Next commits are WIP
  labels under 0.33.0; final gate for the round: `./tools/validate.sh --apk`.

---

## 42. Crew screens: pilot, drone, specialisation drill-downs (v0.33.0, smoke 1390, C2)

Second commit of the hierarchy round (C1 = `2b71cba`): the three crew systems leave the
robot-details screen as dedicated full-screen workspaces, drilled into from the CREW rows
and left with BACK — hierarchy levels 3/4 per the director's "one screen = one primary
purpose" rule. Validated at **1390 smoke checks, 0 failures** (`VALIDATION PASSED`).

- **`src/ui/components/spec_hex_grid.gd` (new, class `SpecHexGrid`):** the hex-cell
  specialization tree (CORE / FIREPOWER / SURVIVAL / MOBILITY bands, flat-top cells with
  rank pips, hover highlight, tap-to-rank) extracted **verbatim** from the old monolith's
  nested class (old `main_menu.gd` lines 44–301, dedented to a standalone `class_name`
  script). Only refs: `GameState`, `UiTheme`, `AudioEngine`. Sets its own
  `custom_minimum_size` in `_rebuild()`, so it drops into any container.
- **`src/ui/screens/pilot_screen.gd` (new, `PilotScreen`, opaque):** header with
  `PilotPortrait` (`ItemPreview.set_pilot`) + BACK; left `PilotRoster` column of owned
  pilots (`PilotRoster_<id>` chips, amber = assigned, tap assigns to the selected robot,
  unlink-before-free rebuild so a chip rebuild inside its own `pressed` never frees a
  locked object); right detail scroll with `PilotName/Level/Signature` (amber when the
  signature robot matches the selection), xp bar, `PilotTierButton` (TIER UP · N MEMOR),
  the seven `SkillRow%d` blocks (`SkillName/SkillInfo/TrainButton%d`, LOCKED/MAXED/cost
  states) and the `PilotSelector` prev/next cycle. All logic ported 1:1 from the old
  `_build_pilot_panel`/`_refresh_pilot`/`_on_pilot_*` handlers; toasts go through
  `manager.toast`.
- **`src/ui/screens/drone_screen.gd` (new, `DroneScreen`, opaque):** wallet line
  (`MICROCHIPS n · <ROBOT> DRONE <ID>`), behaviour hint, one `DroneRow_<id>` panel per
  `DRONE_DEFS` entry with `DroneName/Desc/State` + `DroneAction` (BUY n CHIPS / EQUIP /
  ACTIVE / TITAN-disabled) and `DroneUpgrade` (cost / MAX LEVEL). Equip calls the new
  `HangarScreen.rebuild_bay()` so the preview's `DroneOrbit` rebuilds with the new drone,
  then `manager.refresh()`.
- **`src/ui/screens/spec_screen.gd` (new, `SpecScreen`, opaque):** `SpecWallet`
  (MODULE POINTS), `SpecRobot` track line, the `SpecGrid` hex tree centred, `SpecHint`
  line that follows hover (rank / cost / MAX RANK) and updates after each ranked-up tap —
  ported from the old `_build_spec_panel`/`_refresh_spec`/`_on_spec_*` handlers.
- **Navigation wiring:** `UIManager.SCREEN_SCRIPTS/SCREEN_NAMES` register `pilot`/`drone`/
  `spec` (lazy `load()` like the others); `RobotScreen`'s CREW rows
  (`PilotLine/DroneLine/SpecLine`) changed from Labels to left-aligned `UiParts.button`
  entries that `manager.push(&"pilot"/"drone"/"spec")` — text setters unchanged
  (`_pilot_text()` still renders "PILOT  VEX · LV n · T1", smoke's `"VEX" in text`
  assert still holds). `HangarScreen.rebuild_bay()` added for the drone-equip preview
  rebuild. Pop-back re-enters the robot screen (`on_enter → refresh`), so crew lines
  repaint immediately after any assignment.
- **Smoke 1369 → 1390:** crew-lines asserts flipped `Label` → `Button`, plus a new
  drill-down block between the paint test and the leave-equipment step: each entry opens
  its screen (`ui.current()` asserted), pilot block checks roster column + one chip per
  owned pilot + portrait + 7 train rows + tier action + a **functional roster-assign**
  (pick a pilot ≠ current, press, assert assignment, restore), drone block checks one row
  per `DRONE_DEFS` + wallet text + an action per row, spec block checks grid/wallet/hint —
  every screen then `ui.pop()`s and asserts the return to `&"robot"`.
- **Gotcha:** `grep /tmp/mechassault_*.log` matches **15 historical smoke logs** — count
  per-file (`grep -c` on the current `mechassault_smoke.log`) when verifying that a new
  assert actually ran; repeated PASS lines across the glob are previous runs.
- Deferred (unchanged): store/inventory/settings screens (C3), battle HUD + post-battle
  results (C4), then the §52 acceptance checklist + `./tools/validate.sh --apk` gate.

---

## 43. Store, inventory, settings, combat-stats screens (v0.33.0, smoke 1448, C3)

Third commit of the hierarchy round (C1 = `2b71cba`, C2 = `f5733db`): the last four
menu systems leave the robot/hangar screens as dedicated full-screen workspaces, plus the
targeting-priority gameplay hook and the hangar's level-1 nav buttons. Validated at
**1448 smoke checks, 0 failures** (`VALIDATION PASSED`).

- **`src/ui/components/item_cards.gd` (new, class `ItemCards`):** the shared card
  builders that both the store and the inventory need, extracted from the old monolith
  (`_make_robot_card` / `_make_weapon_card` / pilot + drone rows): `robot_card`,
  `weapon_card`, `pilot_row`, `drone_row` — all producing the legacy node names
  (`StoreRobot_<id>` + `RobotState` + `RobotPreview`, `StoreItem_<id>` +
  `WeaponPreview`, `StorePilot_<id>` + `PilotSignature`, `StoreDrone_<id>` +
  `DronePreview`) so smoke and tooling address them unchanged. Also carries the sell
  system (`make_sell_controls`, `SellKind`, price + blocked guards + CONFIRM/KEEP
  prompts), `robot_action` (select / buy / sell with `hangar.rebuild_bay()` duck-typed
  call) and `slot_caption` ("PAD n" for staged robots). The store and inventory screens
  only compose these rows — no duplicate card code.
- **`src/ui/screens/store_screen.gd` (new, `StoreScreen`):** five-tab full-screen store —
  ROBOTS / TITANS / WEAPONS / PILOTS / DRONES — as `TAB_NAMES`/`PAGE_NAMES`/`ROW_NAMES`
  const arrays over one `StoreTabs` hbox + five scroll pages. `open(params)` defaults to
  tab 0 (`params.get("tab", 0)` — NOT the previous tab; the titan pad pushes `{"tab": 1}`
  and must not be sticky), `store_tab_set(i)` + `_apply_store_tab()` toggle page
  visibility, `_rebuild_rows` unlinks before `queue_free` (never free inside a signal).
  Header carries `StoreWallet` (silver/gold/platinum live line).
- **`src/ui/screens/inventory_screen.gd` (new, `InventoryScreen`):** WR-style storage —
  tabs `InvTabRobots`/`InvTabWeapons` → pages `InvRobotScroll` > `InvRobotRows` /
  `InvWeaponScroll` > `InvWeaponRows`. The robots page splits the roster with
  `Section_ONTHEBAY` (staged pads, state text `PAD n`) vs the storage list; the weapons
  page lists pool stock under `Section_WEAPONSTORAGE` (only `pool_count > 0`).
  `_on_weapon_equip` ports the monolith's slot-fit logic (refusals ALREADY MOUNTED /
  NO FITTING SLOT / NO FREE COPY) and calls `manager.refresh()` + hangar
  `rebuild_bay()` duck-typed.
- **`src/ui/screens/settings_screen.gd` (new, `SettingsScreen`):** full-screen settings
  in four sections created by a local `_section(text, node_name)` helper so the labels
  are named exactly `Section_LOOK` / `Section_AUDIO` / `Section_GAMEPLAY` /
  `Section_SYSTEM` (old-smoke parity). Every legacy control name preserved:
  `SensitivitySlider/VolumeSlider/MusicSlider/DamageNumbersCheck/FpsCounterCheck/
  VibrationCheck/ControlsModeButton/GraphicsSettingButton/ExitGameButton/
  TargetPriorityButton/CloseSettingsButton`. Graphics row cycles
  `Quality.cycle_tier()`; EXIT GAME pushes the root `QuitConfirm`.
- **`src/ui/screens/stats_screen.gd` (new, `StatsScreen`):** the combat-stat report from
  `GameState.combat_stat_report(selected_robot)` — always exactly **7 rows**
  (hp/damage/fire_rate/speed/defense/cooldown/regen), one `StatRow_<key>` HBox each
  (StatName / amber StatValue % / StatSources), driven by `StatsRobot` + `StatsRows`.
  Opened from the equipment screen's new `StatsButton` (AMBER, in `ActionRow`).
- **Targeting-priority hook (the one gameplay touch, §47-sanctioned):**
  `GameState.target_priority` (0 = CROSSHAIR original, 1 = NEAREST) + labels const +
  `set_target_priority`/`cycle_target_priority`/`target_priority_label`, persisted
  `input/target_priority`; `GameSession._cone_candidates` scores lock candidates by
  world distance when priority == 1 (screen-centre distance when 0). Settings row
  `TargetPriorityButton` cycles it.
- **Hangar level-1 nav (`hangar_screen.gd`):** `NavLeft` gains `StoreButton` /
  `InventoryButton` / `SettingsButton` via `_add_nav_button(name, text, screen)`
  (guards `manager.has_screen`) + `_on_nav_pressed` → `manager.push`. Empty pad click
  already routed to the store (titan pad → tab 1) — now smoke-tested.
- **`UIManager`:** registered `store/inventory/settings/stats` in `SCREEN_SCRIPTS` +
  `SCREEN_NAMES` (lazy `load()`, `setup(self)` before add_child) and added
  `request_quit()` → `_show_quit_confirm()`.
- **Smoke 1390 → 1448:** empty-pad block rewritten (was "inert") — pad click must
  `push` the store with the correct tab visible (`HangarSlots.SLOTS[i]["titan"]` vs
  `StoreTitanScroll.visible`) and pop back; equipment-stats block (button → `&"stats"`,
  7 `StatRow_*`, back → `&"robot"`); hangar-nav block before the root `handle_back` —
  store (≥1100 px wide, 5 tabs, robots tab default, ≥3 robot cards, ≥4 RobotPreview /
  ≥6 WeaponPreview / ≥8 PilotPreview / ≥4 DronePreview, 8 `PilotSignature`, weapons-tab
  switch, back), inventory (≥1100×640, `Section_ONTHEBAY` + `Section_WEAPONSTORAGE`,
  staged `StoreRobot_SCARAB` with `PAD` state, weapons tab, back), settings (4 sections,
  12 controls, graphics cycle + full restore of `selected_quality`+`quality_auto`+
  `save_settings`+`Quality.apply_viewport`, target-priority cycle + restore, music
  slider → `music_volume` + restore, EXIT GAME → `QuitConfirm` visible → `handle_back`
  dismisses → pop). C2's menu-wide `DroneAction` count re-scoped to
  `ui.screen(&"drone")` — the store drone cards reuse the name (8 vs 4 was the one
  failure on first run).
- **Gotchas this batch:** (1) `find_children` patterns are **globs** and node names are
  shared across screens (`DroneAction`, `RobotPreview`) — scope searches to the pushed
  screen node or the count doubles; (2) `StoreTab*` also globs the `StoreTabs` container
  — the type filter (`"Button"`) is what makes the count 5; (3) the nav block must run
  **before** the root `ui.handle_back()` or the quit-confirm assertions invert; (4)
  `StoreScreen.open()` default tab must be 0 (stale `_tab` from a titan-pad visit leaked
  into the robots-tab assert); (5) `UiParts.scroll()` already sets EXPAND_FILL — pages
  added to a vbox collapse without it.
- Deferred (unchanged): battle HUD + post-battle results (C4), then the §52 acceptance
  checklist + `./tools/validate.sh --apk` gate.

---

## 44. Post-battle results card + full navigation-flow test (v0.33.0, smoke 1464, C4)

Fourth commit of the hierarchy round — §51 steps 10–11 (post-battle results, then the
full navigation-flow test). Validated at **1464 smoke checks, 0 failures**
(`VALIDATION PASSED`).

- **Results card rebuilt (`hud.gd _build_end_panel`):** the old centred 860×340 box
  with one five-line stats blob is now a 940×460 two-column results card:
  `EndTitle` (56 pt, VICTORY / TIME EXPIRED / DESTROYED colouring unchanged) +
  **`EndSubtitle`** (`<ROBOT> · OPEN REALM SURVIVAL`), a left **BATTLE REPORT**
  column (`ReportHeader` + four caption/value pairs — `ReportValue_Kills` /
  `_Dealt` / `_Taken` / `_Time`, right-aligned) and a right **REWARDS** column
  (`RewardsHeader` + `EndStats` rewards-only text: silver/gold/plat, parts/chips/
  modules, pilot XP). Values are filled in `_on_match_ended` through the new
  `_report_values: Array[Label]` + `_end_subtitle`; a `_make_result_label()` helper
  builds every label in center-relative space. All nodes stay **direct children of
  `EndPanel`** (one-level paths), so existing smoke lookups (`EndPanel/EndStats`,
  direct-child button scan, `RedeployButton`/`MainMenuButton`) keep working —
  buttons moved to y 150..206 for the taller card. Headless death phase now also
  asserts the subtitle, both column headers, non-empty damage-dealt, an integer
  kill count and a `MM:SS` mission time.
- **Full navigation-flow test (§51 step 11, `_check_menu` tail):** a single
  button-driven deep chain with `ui.stack_depth()` asserts at every step —
  hangar root (depth 1) → deck chip → equipment (2) → `EqAssign0` → weapon
  catalogue (3) → row click → weapon detail (**4**) → `handle_back` → catalogue
  (3) → back → equipment (2) → `StatsButton` → stats (3) → back → equipment (2)
  → back → hangar (1), plus a final `stack_depth() == 1` "no stack leaks" assert.
  Runs after the quit-confirm block (quit already dismissed, so `handle_back`
  pops instead of re-opening the prompt).
- **Gotcha:** python anchor strings that end exactly at a captured trailing
  newline (`\n\t# comment`) eat the newline of the next line when the
  replacement omits it — the `for robot_id...` line merged into the comment
  (`---<TAB>for ...`) and produced a cascade parse error. Always end replacement
  blocks with an explicit `\n` when the anchor consumes one.
- Build stamp unchanged `v0.33.0 · 2026-10-07` — this batch rides C1–C3's version.
  Next: §52 acceptance walkthrough + `./tools/validate.sh --apk` gate for the
  whole hierarchy round.
  **Round closed:** §52 acceptance audit ran clean (12 single-purpose screens; hangar
  holds only InfoPanel/TitanBay/NavLeft/TO BATTLE — no reserved empty panels; every
  disabled control is an honest affordability/lock/mounted state; bay SubViewport gated
  when covered; single HangarSlots authority; no gameplay touched beyond the sanctioned
  targeting-priority hook). Final gate `./tools/validate.sh --apk` **PASSED** — smoke
  **1464 checks, 0 failures**, APK rebuilt 526 M and content-verified (shipped
  `game_state.gdc` decompresses to `v0.33.0 · 2026-10-07`).

---

## 45. Physical hangar showroom: AABB camera fit, drag-rotates-model, pad chips, img2/img3 screens (v0.34.0, smoke 1489)

Director round: the hangar must read as a WR-style showroom — camera frames the selected
mech by its actual geometry and NEVER moves on its own or under the hand (drag rotates the
MODEL only, zoom stops dead on release), pad-attached 2D identity chips replace the old
floating `Label3D` nameplates/holograms ("imitate everything in images even if labels,
structure as is"), plus the img2/img3 equipment + weapon-select alignment. Validated at
**1489 smoke checks, 0 failures** (`VALIDATION PASSED`).

- **Pose driver (`hangar_pose_driver.gd`):** deleted `NAMEPLATE_FONT`/`_labels`/
  `_empty_markers`/`_place_label`/`_bob_empty_markers`/`_animate_rig` (the director's
  earlier no-labels demand, now confirmed by smoke's inverse asserts: zero `Label3D`, zero
  `EmptyMarker` under the driver); `_process` reduced to one-shot foot grounding.
  Added `user_yaw` + `rotate_user(degrees)` (wrapf accumulate, re-applies rig yaw) and
  `selected_bounds() -> AABB` (union of visible mesh AABBs in world space, honest fallback
  box) — the framing source of truth. Drone orbit is frozen (`set_process`/
  `set_physics_process(false)`) but kept for smoke's `DroneOrbit` assert.
- **Hangar screen (`hangar_screen.gd` rewritten, ~1061 lines):** camera fit = snap, not
  lerp — `_fit_distance` from a ≤10-iteration bounds-vs-safe-rect ratio loop plus ≤6
  centering iterations (`world_per_px = 2·tan(fov/2)·d / view.y`, basis-aligned shift;
  `_look_shift_norm` keeps centering valid under zoom); `_apply_view` only lerps
  `_view_distance` toward `_fit_distance/_zoom` and snaps (<0.015) so at rest the
  transform is bit-identical every frame. Constants: `CAM_YAW 2.35619449`,
  `CAM_ELEV 0.30`, bay FOV 46 / closeup 40, `ZOOM_MIN 0.7 / ZOOM_MAX 1.9`,
  `DRAG_YAW_DEG_PER_PX 0.45`, `WHEEL_ZOOM_RATIO 1.12`; safe rects bay
  `Rect2(300,132,w-512,h-344)` / closeup `Rect2(354,130,w-826,h-242)`.
  Input: `_on_bay_input` press starts orbit, motion `rotate_user(-rel.x·0.45)`
  (travel ≥ 8 px distinguishes drag from click → `pick_slot`), wheel zoom, pinch handled
  in BOTH gui and unhandled paths (idempotent — the ratio is 1.0 on a repeat).
  Public smoke API: `fit_safe_rect()`, `projected_bounds_rect()`, `fit_distance()`,
  `view_distance()`, `zoom_level()` (zoom mutation via `hangar.call("_zoom_by", f)`).
- **Pad chips (WR identity):** `PadChip_<i>` 178×48 panels, `MOUSE_FILTER_IGNORE` (a tap
  falls through to the pad hit-test; a drag starting on a chip still rotates the model),
  content = level disc (`PadLevel`/`PadLevelValue`, amber rim when selected) + `PadName` +
  `PadMK` ("MK%d · CLASS" only when `upgrade_mk_cap > 1`); rebuilt only on assignment
  signature change via unlink + `queue_free` (never free inside a signal); positioned every
  frame by unproject at pad `top+0.14`, offset toward the camera by `radius*0.6`, hidden
  when behind camera/in closeup. `UpgradeBubble` (286×56, HEALTH accent) carries
  `BubbleCaption` + wired `UpgradeButton`, hidden whenever the caption is empty — no fake
  affordances. Chrome: `StartButton` top-right (250×58), bottom `DockPanel`
  (DeckSplit = deck chips + titan column, `StoreButton` 196×70), left nav
  Pilot/Drone/Spec/Record, right 2×2 grid Inventory/Equipment/Settings/Armory (→ store
  tab 2); nav buttons built only `if manager.has_screen(name)`.
- **img2 equipment (`robot_screen.gd`):** header `RobotStrip_<robot_id>` chips for every
  owned mech + `PrevRobotButton`/`NextRobotButton` cycle arrows (new `_owned_robots()`,
  `_cycle_robot(step)`, `_select_robot(id)` → `select_robot` + hangar `rebuild_bay()` +
  `manager.refresh()` — rebuild happens through the manager, never mid-signal);
  `ClassLine` now ends with the hull upgrade stamp (`MK%d · LV%d`, titan class → `LV%d`).
  Weapon-row thumbnails were deliberately NOT added: badge + name + stat + SELECT +
  UPGRADE already fill the 424 px right panel (thumbnails exist in the catalogue/detail).
- **img3 weapon select (`weapon_select_screen.gd`):** tab texts → `INVENTORY`/`TO STORE`
  (node names `TabStorage`/`TabStore` unchanged); title gains robot context
  (`SELECT WEAPON // <robot> · M SLOT 1`); rows gained selection state — first tap
  selects (`glow_frame` + right `StatSheet` fills: SheetPreview/SheetName/SheetClass/
  SheetStat* lines DAMAGE/RATE/DPS/RANGE/SPREAD/SPECIAL + SheetState + hint), tapping the
  selected row again drills into `weapon_detail` (default selection = first row keeps the
  existing one-press drill contract); `_restyle_rows()` restyles in place — it must never
  free nodes (it runs inside the row's own `gui_input`); storage rows show `OWNED ×n`.
  Range metric follows weapon_data.gd's documented convention: beams `beam_range`, else
  `projectile_speed × projectile_lifetime`.
- **Smoke 1464 → 1489:** label asserts inverted (zero `Label3D`/`EmptyMarker`); new
  showroom block after `DroneOrbit` — 12-frame settle → `fit_safe_rect().grow(6)
  .encloses(projected_bounds_rect())` → capture → **200 frames** → camera AND rig
  transforms `is_equal_approx` (the no-auto-motion contract) → synthetic
  press/motion/release through `preview_control.gui_input` → yaw moved > 0.5° while the
  camera stayed bit-identical → restore; wheel zoom up, `_zoom_by(50)` clamps at
  `HangarScreen.ZOOM_MAX`, restore to 1.0 + 60-frame settle; one `PadChip` per occupied
  pad with name+MK; `UpgradeBubble` wired + visible-implies-caption;
  **wired-or-honest audit** of every visible button under the hangar (13/13 this run:
  pressed-connections ≥1, or disabled with a non-empty tooltip). Equipment phase: strip
  chip count == owned count, arrows wired, ClassLine carries MK/LV. Catalogue: tab
  texts, `StatSheet` + ≥4 `SheetStat*` lines, and a select-then-drill chain (press row[1]
  → still in catalogue + sheet == its display name; press again → `weapon_detail` → back).
  Gotchas: `Control.visible_in_tree()` does not exist — it is `is_visible_in_tree()` and
  a call error there aborts the whole `_check_menu` coroutine (393 checks, 0 failures,
  "passed" with half the suite skipped — always grep the log count, not just failures);
  a hand-typed `Array<Array>` landed as `Array<Array]` in the weapon sheet (parse-fatal,
  and the typo defeats exact-string edits — verify codepoints with python `repr` when an
  Edit claims no match); `find_children` has no visibility filter, so hidden-screen nodes
  are found (assert names unique across screens or scope the search to the pushed screen).
- **Version:** trio moved 0.33.0 → **0.34.0** (code 34, `BUILD_LABEL v0.34.0 · 2026-10-08`).
  Final gate for this batch: `./tools/validate.sh --apk` + Windows export.

---

## 46. Headless visual-QA round: chip/bubble/row/bar/stamp fixes + WR weapon-select layout (v0.34.0, smoke 1489)

Director's "only need apk" round executed through a new **see-what-we-ship** pipeline:
`tools/ui_dump.{gd,tscn}` (settled rect dump of all 12 screens) + `tools/render_ui.py`
(PIL layer alpha-composite, `UI_NONCE` pixel stamp bottom-left — verify renders by VIEWING
the nonce, never by grep). Contracts: dump rects are **pos+size**; image `read` channel is
flaky — mitigate via nonce + fresh re-encodes + retries + `ascii_view.py` fallback.

- **Resource chips** (`resource_bar.gd`): sized at build from off-tree placeholder text,
  never re-measured → values rendered past chip edges. Fix: `_chip_inners` +
  `_resize_chip()` re-run every `refresh()`, plus `ENTER_TREE` → deferred settle refresh
  (off-tree `get_combined_minimum_size()` is stale; in-tree `set_text` invalidates
  immediately).
- **UpgradeBubble** (`hangar_screen.gd`): fixed 286×56 panel under 97 px of content —
  now content-fit every frame (`_bubble_margin.get_combined_minimum_size()` → panel
  size, min 340×82). Stays class `Panel` (smoke type filter).
- **Equipment rows + bottom bar** (`robot_screen.gd`): plain Panels propagate no child
  minimums and off-tree button mins under-count (11 px default font) — rows use the
  literal real layout **148** (2×63 buttons + 6 gap + 16 pad); `BottomActions`
  -76 → **-101** top so 69 px buttons fit inside the bar and y≤720p.
- **BuildStamp moved into the ResourceBar** (`resource_bar.gd`; `main_menu._build_stamp`
  deleted): was bottom-left, painted under every screen's chrome and clipped past the
  viewport edge; now a fs11 label inside `BarRow` between spacer and chips (canvas units
  are fixed 1280 wide, so no narrow-window risk). **Smoke path updated**:
  `menu.get_node_or_null("UI/ResourceBar/BarRow/BuildStamp")`.
- **weapon_select WR layout**: tabs right-aligned in the same band as BACK + title
  (`anchor_left=1, offset_left=-366`), `TabHint` dropped (SheetNote already instructs),
  ListPanel/StatSheet tops 120→141 (below the band), rows content-sized (min 168),
  `SheetClass` size-duplicate removed; `GameState.item_class_label` now covers all 10
  families (TORQ/BREACH/FERRIC/LUMEN/PYRE/VOLLEY/ECHO were falling back to bare size).
- **Verified numerically + visually** (nonce `C4V8`): all 1489 smoke checks green.

Run the pipeline after any chrome change:
`timeout 180 "$GODOT" --headless --path . tools/ui_dump.tscn` →
`UI_NONCE=<tag> python3 tools/render_ui.py` → view `build/screenshots/ui/<screen>.png`.

---

## 47. WR12 reference + full UI contract system (v0.34.0, merge commit `3377cc8`)

Import of the parallel session's "skeleton" package (director: *"implement fully all
those added weapons, pilots, drones"*) kept at **our version scheme** (their
`1.0.0-offline` rejected). Validated at **1489 smoke checks** before the content
work landed on top.

- **`data/mech_assault_reference_12_4.json`** — WR 12.4 research manifest: 6 robots,
  **63 weapon profiles** (41 robot + 19 titan + catalog-only), 5 pilot shells, 2 drone
  shells, sources (patch notes 414/416/417/418/422). `"No missing values are invented"`.
- **`ContentRegistry` autoload** (`src/core/autoload/content_registry.gd`) — exposes
  `weapon_profile()` over the manifest; registered in `project.godot`.
- **`src/ui/ui_contract.gd` + `tools/validate_full_ui_contract.py`** — declarative
  screen/route contract (57 routes) + validator; `tools/apply_full_ui_contract.py`.
- **`tools/validate_reference_skeleton.py`** — manifest integrity (counts from the
  JSON, never from GameState).
- **Mega-hub routes** (`src/ui/screens/mega_hub_screen.gd`, gated `game_modes` page),
  **controller prompt bar** (`src/ui/controller_prompt_bar.gd`), OFFLINE chrome in
  resource bar / loading screen / hangar / theme; `tools/ui_dump.gd` gained the
  `game_modes` shot.
- Three of their bugs fixed pre-merge: mega-hub dedent, triple-quoted
  `_build_post_battle`, `_rebuild_content` hero block.
- **Split commits:** merge = `3377cc8` (trio stays 0.34.0, smoke 1489) · content =
  `1fcca91` (§48, trio → 0.35.0).

---

## 48. Full WR 12.x content batch: 71 weapons + 15 pilots + 6 drones (v0.35.0, smoke 1792)

Director: *"implement fully all those added weapons, pilots, drones, weapons etc with
real war robots statistics data"*. Validated at **1792 smoke checks, 0 failures**
(`VALIDATION PASSED`, up from 1489).

- **Catalog 30 → 71 robot items + 8 → 26 titan items** (`game_state.ALL_ITEM_IDS` /
  `TITAN_ITEM_IDS`): IARAGHI, HARMATTAN, CELSIUS/FAHRENHEIT/KELVIN, VOONITH/URHAG/
  SHANTAK, ULTIMATE-TOXIN/VENOM/ATOMIZER, GLADIUS/PILUM, RIME/CRYO/GLACIER (+12_4
  legacy variants), ULTIMATE-RIME/GLACIER, VELOS/MACHAIRA/BASILEUS, HIPPO/KROKO/
  LIODARI, ELOX/MURIX, KSIPHOS/LABRYS/CESTUS, TOXIN/BANE + titans BARQ, VENIRE/
  VINCERE, FURNACE/TORCH, CHASM, MUNINN/HUGINN, EQUALIZER/ARBITER, VAJRA/MAHA-VAJRA,
  STRIKER, EVORA/VEYRON, ANGUISHER/RUINER. All original WR-archetype names per §14.
- **`weapon_data.gd` data-driven catalog:** `_catalog()` lazy dict keyed by family
  (per-pellet `dmg` by size token; rpm/mag/reload/corro/slow/chain/tracer from the
  manifest + patch notes) → `_catalog_weapon()` builder (heat = `0.55/mag` magazine
  guns, else `0.4×bias/(rpm/60)` belt bias; lifetime `clamp(range/spd, 0.4, 2.5)` =
  max 2.5 s pool-safe), `_size_chrome` (barrel/drum/recoil/shake by size),
  `_kind_from_name`, `_size_token`. Compressions documented inline (HIPPO line ÷4,
  ANGUISHER volley ÷2, HARMATTAN ×1.2 to clear the 300 floor, IARAGHI-L clamped to
  the 7000 band). **Freeze trio shares one table**; `for_item` keeps the original 17
  match arms and falls through to the catalog (`_razor` fallback unchanged).
- **Multi-token id parse** (the whole point): `item_family_of`/`item_size_of` +
  `ITEM_SIZE_TOKENS`/`ITEM_LEGACY_*` — `ULTIMATE-TOXIN-L` → family `ULTIMATE-TOXIN`
  LIGHT · `MAHA-VAJRA-B` → `MAHA-VAJRA` BETA · `RIME-12_4` → `RIME` LIGHT ·
  `ULTIMATE-ATOMIZER` → MEDIUM (explicit legacy size). `game_state.item_slot_size`/
  `item_family` now **delegate** to these (old code resolved every multi-hyphen id to
  the first/last slice); `item_class_label` consults `WEAPON_CLASS_LABELS` (47 new
  families) before the original-10 match. **`CHASM-B`** is an alias arm of `_chash`
  (same beta void gun as CHASH-B; `weapon_mount` VOID/CHASH special cases gained
  `CHASM`).
- **Pilots 10 → 15** (WR 12.3/12.4 legendaries): `nadir` (NADIR RAKHIM → SCARAB),
  `toshiro` (TOSHIRO KUROSAWA → CITADEL), `cliff` (CLIFF DEBUSSE → RAVAGER),
  `donnie` (DONNIE WOO), `andor` (ANDOR MIHHARR) — rarity 3, unowned (store HIRE
  flow), new `unique` field rendered in the pilot row in place of the generic
  skill-track caption (`item_cards`).
- **Drones 4 → 6:** `scourveil` (SPEED +1.2 %/lv, heal 10 %, sig SCARAB) + `prena`
  (DAMAGE +1.2 %/lv, heal 8 %); `_build_defaults` grants both on fresh saves and a
  one-time **`drone_roster_v35`** migration (load block after v25, flag written in
  `save_settings` beside `drone_roster_v25`) grants them to old saves.
- **Smoke 1489 → 1792:** counts 71/26/15/6, a titan build+damage loop over
  `TITAN_ITEM_IDS`, ~20 spot asserts (parse/kinds/mag/pellets/chain/lock-beam/
  hull-grey/CHASM alias/UI slot-size delegation/class labels), 5 pilot defs with
  signature pairs + `unique`, both drones def+ownership+level. Hit and fixed one
  **self-inflicted** failure: asserted `EVORA-A` was BETA — the `A` token is ALPHA.
- Bumped **0.35.0 / code 35 / `BUILD_LABEL "v0.35.0 · 2026-10-08"`** together.
- Still open from §12-46: WR combat-stat visibility, LightmapGI/VFX overhaul, paint/
  camo shop, PRAETOR portrait, out-of-app notifications; **next:** enemy Hunting
  Grounds batch (random BASE/MK1/MK2/MK3 mix + per-enemy random weapon rolls).


---

## 50. Hangar showroom v2: per-pad + buttons, chrome declutter, direct deploy (v0.37.0, smoke 1821)

Director round: *"can't start a match, duplicate STORE, empty bay with nothing to tap, screen
cluttered everywhere, many stubbed options"*. Validated at **1821 smoke checks, 0 failures**
(`VALIDATION PASSED`, up from 1798).

- **Can't start match (root cause):** the merged build's TO BATTLE pushed the game-modes hub
  (`push(&"game_modes")`) instead of deploying — `_on_start_pressed` restored to its pre-merge
  body (`_leaving → clear_temporary → begin_leaving → SceneRouter.goto_game`).
  Smoke now presses START with `SceneRouter._switching = true` and asserts `_leaving` arms with
  **no stack detour** (resets `hangar._leaving`, `ui._leaving`, `_switching` after).
- **Per-pad + buttons (WR showroom):** `SlotPlus_<i>` round buttons (one per
  `HangarSlots.SLOTS`, amber rim on the selected pad) replace the deck strip + pad name chips:
  occupied → select + `push(&"robot")`, empty → store (titan pad → tab 1).
  Deck dock, left crew column, TitanChip placeholder and DragHint all deleted; inverse smoke
  asserts (`BottomDock/LeftNav/DeckChip/TitanChip/PadChip == 0`).
- **Chrome declutter:** RightNav = INVENTORY / ARMORY (`push store {tab:2}`) / COMMAND
  (→ profile hub); bottom-left `StatsRecordButton` → `&"stats"`, bottom-right the single
  `StoreButton`; top-right gear+mail moved into the CTA row (y66..124) so they clear the
  OFFLINE chip; overlap smoke asserts (utility ∩ currency strip, right rail ∩ START/STORE).
- **Stub sweep (`mega_hub_screen`):** battle-modes list drops deleted maps (IRONYARD/CINDER);
  nav groups pruned to PLAY/ARMORY/SOCIAL/SYSTEM (toast-only workshop/missions/… removed);
  profile LEVEL row reads `pilot_level()` (was hard 30), kills row renamed `HOSTILES · LAST
  OP` (match-scoped counter); new `_build_news()` local patch notes (starts with
  `GameState.BUILD_LABEL`) behind the news-page early return. Smoke: briefing shows
  BUILD_LABEL + PATCH NOTES, hub nav has no WORKSHOP/MISSIONS, modes list has no dead maps.
- **Bay rear wall:** wall z −25 → −34 (sides 54.5, lanes 54, rear crates) so the titan
  zoom-out camera (worst z ≈ −32) stays inside the room (was clipping the wall front).
- **Smoke 1798 → 1821:** +SlotPlus/declutter/start-guard/news/stats/command/armory/overlap
  block; DeckChip/PadChip/DragHint asserts replaced by inverses; SettingsButton →
  `SettingsTopButton`. New tool `tools/bay_fit_probe.{gd,tscn}` (camera-vs-wall rect probe).
- **Version:** trio 0.36.0 → **0.37.0** (code 37, `BUILD_LABEL v0.37.0 · 2026-10-08`).

---

## 49. Hunting Grounds enemy roster: random MK mix + per-enemy weapon rolls (v0.36.0, smoke 1798)

Director: *"enemies don't strictly have to be mk3 or mk1 etc — randomly mixed eg base
ones, mk1, mk2, mk3 with each also having their own random weapons"* (War Robots
Hunting Grounds / Extermination flavour). Validated at **1798 smoke checks, 0 failures**
(`VALIDATION PASSED`).

- **MK tiers (`src/enemies/enemy_robot.gd`):** every spawn gets a tier from `MK_BAG`
  (fixed mix **5 BASE / 4 MK1 / 3 MK2 / 3 MK3** across the 15 spawns — content-stable
  so smoke can prove all four tiers exist, yet the per-kind spread reads as a random
  pull). Durability climbs hard (`MK_HP_MULT` 1.0/1.25/1.65/2.2), firepower gently
  (`MK_DMG_MULT` 1.0/1.1/1.25/1.4 — damage + corrosion only, cadence stays kind-owned).
  Applied at the end of `_configure_kind` (before Health/shields are built) and to the
  weapon in `_make_weapon`. `kind_label()` now appends **`MK2`** for tiers > 0, so the
  floating marker and `LOCK //` tag show the tier; BASE stays clean.
- **Per-enemy weapon rolls:** `WEAPON_POOLS` gives each kind four disjoint tokens —
  the classic named gun (`SPITTER/LANCE/MAW/TESLA`, unchanged stats) plus three
  catalog ids matched to its role: SCUTTLER HARMATTAN-L/TOXIN-L/ULTIMATE-TOXIN-L ·
  STALKER VOONITH-L/ECHO-L/MACHAIRA-M · BRUTE KSIPHOS-L/BREACH-M/VOLLEY-M ·
  WASP VOLT-L/URHAG-M/ECHO-M. Roll = `RandomNumberGenerator` seeded
  `WEAPON_SEED + spawn_index * 97` (deterministic across runs, varied across roster).
  Catalog guns go through `WeaponData.for_item` (display name = item id). All pool
  members verified ≤ 15.4k base dps so the solo-survival invariant survives MK3.
- **Plumbing:** `GameSession._spawn_enemies` sets `enemy.spawn_index = index`
  **before** `add_child` (both it and `kind` feed `_ready`). Static append-only
  `EnemyRobot.spawned_tiers` logs every tier at spawn — dead enemies leave the tree,
  so smoke reads the log for tier coverage instead of the live roster.
- **Smoke 1792 → 1798:** tier-mix assert (4 tiers from the spawn log), pool-membership
  assert (0 guns outside the kind pool), per-kind durability-stretch asserts
  (≥1.5× where ≥2 tiers of that kind survive; measured 1.65–2.20), and the §20
  solo-survival guard relaxed **20 s → 15 s** with comment — MK3 ×1.4 damage
  deliberately shaves perfect-fire TTK (measured **15.9 s** against SCARAB 340 K).
  Roster now shows **9 distinct weapons** in one run.
- **Gotcha (cost 1 failed run):** `Dictionary.get(...) as Array[StringName]` is a
  runtime abort in Godot 4.4 — const-dict array literals are plain `Array`, and the
  cast fails inside `_make_weapon` for every enemy while the identical line in the
  smoke coroutine silently aborts `_check_enemy_variety` (its asserts vanish; count
  drops 1792 → 1783, failures stay 0 — always compare the **check count**, not just
  failures). Fix: keep the local `var pool: Array` untyped, cast elements
  (`as StringName`) instead. validate.sh's "runtime script errors detected" is what
  caught it — EXIT=0 requires zero SCRIPT ERRORs anywhere in the run.
- Bumped **0.36.0 / code 36 / `BUILD_LABEL "v0.36.0 · 2026-10-08"`**.

---

## 51. Device bug round: weather particle error, self-driving gamepad, equip-crash hardening (v0.38.0, smoke 1821)

Director's three-symptom round (screenshot in `/sdcard/imgs/261008193619290.JPG` =
a Windows Godot 4.4.1 console). Validated at **1821 smoke checks, 0 failures**.

- **`Amount of particles must be greater than 0` ×3 = `weather_system.gd:78`.** The
  per-district micro-climate cells were created with
  `amount = (1 if precipitating else 0)`, so the three CLEAR zones (HUB / CITY /
  VOLCANO) asked `CPUParticles3D` for a zero-particle emitter and Godot logged one
  error per zone at startup — exactly three. Fixed by keeping `amount = 1` and
  letting `emitting = false` do the silencing (the renderer still rejects `amount=0`
  even when not emitting). Audit of every other `.amount =` site in `src/` (CombatFx,
  HealFx, DamageReaction, ShadowDash, VolcanoActivity, Nature) shows all callers pass
  `maxi(...)`/non-zero constants; no `amount = 0` exists in any `.tscn`.
- **Wireless gamepad drove the robot by itself.** `move_forward/back/left/right` were
  bound to `JoypadMotion` events, so `Input.get_action_strength()` fed the raw axis
  straight into `move_vector`: a cheap wireless pad that never reports a neutral
  centre (or that SDL maps to the wrong axis) holds `move_back` pressed at rest —
  the robot drives itself, and a stuck right-trigger axis (`trigger > 0.5`) fires the
  guns. `input_router.gd` now **polls the pads raw instead of binding them**:
  - move actions keep keys + D-pad only (`_define_actions` lost its four
    `[[JOY_AXIS_*, ±1.0]]` arguments);
  - new `_poll_gamepad(delta) -> Vector2` samples left/right stick + right trigger
    from the first connected device, averages the first `PAD_CAL_FRAMES (20)`
    samples into a **per-device rest centre**, subtracts it, then applies
    `PAD_DEADZONE (0.22)` with rescaling — so a pad resting at `(0.9, −1.0)` still
    reads as "not touched". Axes that cross the ±1 seam are wrapped (`_pad_wrap`);
  - the fire trigger only arms after it has been observed at or below
    `PAD_TRIGGER_ARM (0.25)` — an inverted/stuck trigger can never hold fire;
  - `_reset_pad_state()` runs on connect/disconnect (no stale centre from the
    previous pad), and one `print("INPUT pad <name> rest=… armed=…")` line gives the
    director a forensics line for the Windows console;
  - headless is unaffected (no joypads → early return), so smoke stays deterministic;
  - `platform.gd _pad_hint_lines` now falls back to `_joy_axis_text(JOY_AXIS_LEFT_X)`
    ("LS MOVE"), because the hint builder reads the *bindings* and movement is no
    longer bound.
- **Equip-crash hardening.** The row `EQUIP`/`BUY` handlers call
  `manager.refresh()` → `WeaponSelectScreen._rebuild_rows()` → `child.free()` on the
  very row that owns the button currently emitting `pressed`. All three rebuild loops
  (`weapon_select_screen.gd`, `weapon_detail_screen.gd`, `upgrade_screen.gd` ×2) now
  do `remove_child` + **`queue_free`**, so the emitter survives the frame. Honest
  note: a controlled experiment (reverting only `weapon_select_screen` to `free()`
  and re-running the smoke) did **not** crash headless, so this is risk-reduction,
  not a proven root cause — the remaining suspect is on-device only.
- **Smoke now presses EQUIP the way a device does.** `_click_button(host, control)`
  scrolls the target into view (`ScrollContainer.ensure_control_visible`, +2 frames —
  without it the click lands wherever the scrolled-away row's rect happens to be),
  hides every `CanvasLayer`, and pushes a real press+release through
  `viewport.push_input()`, i.e. through `BaseButton::_gui_input`. The old
  `action.pressed.emit()` bypassed the tail that runs *after* signal emission and
  therefore could not catch a free-during-signal bug. `CLICK <name> rect=… screen=…`
  is printed for forensics.
- **Version:** trio moved 0.37.0 → **0.38.0** (code 38, `BUILD_LABEL v0.38.0 ·
  2026-10-08`).

---

## 52. Catalog honesty pass: invented sizes + cosmetic variants removed (v0.38.0, smoke 1788)

Director: *"remove fake wrong weapons"*. Audited every v0.35 catalog id against
`/tmp/opencode/wr_weapons_ground_truth.md` and the WR 12.4 manifest, then deleted
the ones the wiki does not actually have. Validated at **1788 smoke checks, 0
failures** (`VALIDATION PASSED`).

- **Invented sizes (wiki pages are `API:MISSING`, GT's open-`?` list):**
  `IARAGHI-M` and `IARAGHI-H` — Iaraghi is Light-only; `GLADIUS-H` — the Gladius
  ladder is two-member (Gladius L + Pilum H), there is no Heavy Gladius.
  `ALL_ITEM_IDS` now carries `IARAGHI-L`, `GLADIUS-L`, `PILUM-H`.
- **Cosmetic variants (GT §3.4 "skins / variants — do NOT treat as separate
  weapons"):** `ULTIMATE-TOXIN-L`, `ULTIMATE-VENOM-M`, `ULTIMATE-ATOMIZER`,
  `ULTIMATE-RIME`, `ULTIMATE-GLACIER`, `RIME-12_4`, `CRYO-12_4`, `GLACIER-12_4`.
  These were duplicates of Toxin / Venom / Atomizer / Rime / Glacier. Replaced by
  the base ladder members: `TOXIN-L`, **`VENOM-M` (new — the Medium rung of the
  corrosive ladder was missing)**, `BANE-H`, `ATOMIZER-M`, `RIME-L`, `CRYO-M`,
  `GLACIER-H`.
- **Result:** robot catalog **71 → 62 items** (26 titan items unchanged).
  `TOXIN/VENOM/BANE` now share one catalog profile (mag 120, reload 3 s,
  corrosion 90/135/200 per liter, dmg 310/465/640 after the same 300-floor
  compression the ladder already used). The duplicate `TOXIN` key this created
  was caught by the Godot parser (`Key "TOXIN" was already used in this
  dictionary`) — a duplicate key in a **literal** Dictionary only fails at parse
  time, so grep the extracted `_wr_catalog` keys after any catalog rename.
- **Save safety (`GameState.REMOVED_ITEM_IDS` + `_migrate_removed_item_ids()`):**
  an idempotent map runs between `load_settings()` and `_migrate_ownership()` and
  folds every removed id into its surviving ladder member — pool copies are
  carried over and every mounted loadout slot is rewritten, so an old save with
  `ULTIMATE-ATOMIZER` mounted simply reads `ATOMIZER-M` afterwards.
- **Dead parse tables removed:** `WeaponData.ITEM_LEGACY_SIZE` /
  `ITEM_LEGACY_FAMILY` existed only to give the `*_12_4` and `ULTIMATE-*` ids a
  size/family; with those ids gone the multi-token parse is a single trailing
  `L/M/H/A/B` rule again.
- **Smoke 1821 → 1788:** count pin 71 → 62, the four ULTIMATE/12_4 spot-asserts
  retargeted at their base ids, plus a new loop that asserts every key of
  `REMOVED_ITEM_IDS` is absent from both `ALL_ITEM_IDS` and `TITAN_ITEM_IDS`
  (11 checks). The drop from 1821 is the two per-item catalog loops over 9
  fewer ids, plus those 11 new asserts.
- **`tools/apply_wr_v38.py` (untracked) is SUPERSEDED — do not run it.** It was a
  staged one-shot rewriter for a much larger WR-name port (RAZOR → PUNISHER etc.)
  that has **not** been requested by the director. It also contains a
  `for_item VOLT → _torq` rewrite that would destroy the §38 electric-weapon
  parity work (arc damage curve + chain shocks) and break its smoke blocks. The
  fake-weapon removal was done directly in source instead. If the director ever
  asks for the full rename port, re-plan it with VOLT kept on `_volt`.
- Still open from §12-51: WR combat-stat visibility, LightmapGI/VFX overhaul,
  paint/camo shop, PRAETOR portrait, out-of-app notifications; plus the earlier
  unrequested rename port above.

---

## 53. LUMEN WR-exact stats + curved-beam animation (v0.39.0, smoke 1794)

Director: *"dont forget to fix lumen weapons too"* and *"add its exact animation when
shooting eg curving beam around objects just as in war robots"*. Scoped it by auditing
`_lumen()` against `/tmp/opencode/wr_weapons_ground_truth.md:473` first — mechanics
(curve-around-cover ray search, Thermal Breach) were already WR-correct and smoke-green,
so the gaps were **stats** and the **visual**. Validated at **1794 smoke checks, 0
failures** (`VALIDATION PASSED`) + debug APK.

- **Stats (`weapon_data.gd::_lumen`), all three sizes:**

  | field | was | now | source |
  | --- | --- | --- | --- |
  | `beam_range` | 500 m | **600 m** | GT range_m (verbatim) |
  | `shots_per_minute` | 600 | **240** | GT "cap 60 rounds, unload 15 s" = 4/s |
  | `magazine` | 0 (belt) | **60** | GT "cap 60 rounds" |
  | `reload_time` | 0.0 | **10.0 s** | GT "reload 10 seconds" |
  | `damage` L/M/H | 1600/2400/3200 | **300 / 450 / 600** | GT 184/276/368 — see below |

  **The one value that cannot be copied raw is damage.** Our whole catalog runs on the
  smoke invariant `data.damage >= 300` (`tools/smoke_test.gd`), so the wiki's
  Weapon-Level-1 ladder is lifted by a single uniform factor — `184 × 1.63 = 300` —
  which lands it at exactly 300/450/600 and keeps WR's `1 : 1.5 : 2` shape intact.
  This is the same documented floor-compression the rest of the catalog already uses
  (HARMATTAN ×1.2, VELOS ×1.37, TOXIN to the floor). Range, rate, magazine and reload
  are verbatim.
  **Balance consequence, deliberately accepted:** LUMEN DPS drops from 16k/24k/32k to
  **1.2k/1.8k/2.4k** — roughly an order of magnitude below RAZOR/TORQ per gun. The
  director explicitly picked "match WR stats exactly" over "too strong/weak — rebalance
  against the arsenal", so this is what was asked for. If ZEPHYR feels toothless on
  device, the knob is the single uniform factor in the `_lumen` comment (raise it, keep
  the ratio, keep `>= 300`).

- **Beam animation (`combat/beam_effect.gd` rewrite):**
  - **Chaikin corner-cutting** (`_smooth`, 2 iterations) runs on the polyline before
    resampling, so the `[muzzle, bend, impact]` kink produced by the cover-curving ray
    search draws as one continuous **arc that snakes around the obstacle** instead of a
    hard V. True muzzle/impact points are pinned (re-attached as head/tail each
    iteration); straight two-point beams are returned untouched.
  - **Muzzle-out sweep** (`REVEAL_TIME 0.07 s`, `SEGMENTS 16`) — core+glow pairs reveal
    outward from the barrel before the strand fades, so rapid fire reads as a lance
    travelling to the hull rather than a beam popping into existence.
  - **Glow pass** — a wider, dimmer halo box (`×3.4` thickness, alpha 0.30 / energy 2.6)
    under the emissive core (alpha 0.85 / energy 7.0), which is what makes a strand read
    as a beam rather than a line.
  - `LIFE` 0.24 → 0.30 s so consecutive shots at 240 rpm (0.25 s interval) overlap
    slightly — continuous-contact look, like WR.
- **Smoke 1788 → 1794:** +4 WR-stat pins (600 m / 60-round+10 s / 240 rpm / 1:1.5:2 on
  the ≥300 band) and +2 animation pins (`BeamEffect._smooth` on a synthetic kink rounds
  the corner *below* the original yet stays >1 unit off the chord; endpoints pinned).
- **Fixture gotcha worth remembering:** the LUMEN stage harness swaps
  `_lumen_mount.data = lumen` onto a mount that was `setup()` for a belt-fed gun, so
  `_ammo` stayed 0 — with `magazine = 60` that trips the empty-magazine reload gate and
  `try_fire()` returns false on every shot (4 cascading failures). The swap now refills
  `_ammo`/clears `_reload_left`, and the cleanup restores both. Lesson: **swapping
  `WeaponMount.data` is not enough on its own — `_ammo` is captured at `setup()`.**
- **Build:** trio moved 0.38.0 → **0.39.0** (code 39, `BUILD_LABEL v0.39.0 ·
  2026-10-08`), `./tools/validate.sh --apk` **PASSED**, APK 526 M. Content-verified by
  zstd-decompressing the shipped `game_state.gdc` (`v0.39.0 · 2026-10-08` present) and
  `weapon_data.gdc` (bytecode stores constants as **float32**, not float64 — a
  `struct.pack("<d", …)` search reports false negatives; use `"<f"`).
- Still open from §12-52: WR combat-stat visibility, LightmapGI/VFX overhaul,
  paint/camo shop, PRAETOR portrait, out-of-app notifications; Windows exe rebuild
  (last one predates this round).

---

## 54. Per-weapon firing look + per-weapon fire voices (v0.39.0, smoke 1885)

Director: *"exact animations and colors/appearances of shooting per weapon exactly like
war robots … dont forget per sound added"* — and explicitly **no build** (no APK/exe) and
**no version bump**. Version trio therefore stays 0.39.0. Validated at **1885 smoke
checks, 0 failures** (`VALIDATION PASSED`, plain `./tools/validate.sh`, not `--apk`).

- **Bug found first: `data.family` was never set by the ten original builders.**
  `WeaponData.family` defaults to `"RAZOR"` and only BUILTIN/VOID/CHASH/titan/drones
  overwrote it, so `_razor.._maul.._volt.._echo` all reported `"RAZOR"`. Any per-weapon
  lookup keyed on family (sound, muzzle colour) would have mis-routed every original gun.
  All ten now stamp their own (`RAZOR/MAUL/VOLT/TORQ/BREACH/FERRIC/LUMEN/PYRE/VOLLEY/ECHO`)
  — smoke asserts each id resolves its own family.
- **Shot-look profile (`weapon_data.gd`):** `enum FlashShape {BALL, CONE, NEEDLE, DISC,
  PUFF}` + `enum TracerShape {STREAK, ORB, NEEDLE, SHELL}`; `SHOT_LOOK_KIND` (10 kind
  entries: colour, life, stretch, light range/energy, silhouette, tracer) +
  `SHOT_LOOK_COLOR` (~60 family colours) + `SHOT_LOOK_EXTRA` (rare shape/timing overrides —
  frost rounds icy-not-brass, void violet with a longer bloom, titan guns brighter/longer).
  `static func shot_look(family, kind)` merges them; `tracer_shape_for()` for projectiles.
- **Muzzle flash rebuilt (`weapon_mount.gd`):** the old code was one sphere with a
  hard-coded per-`Kind` tint. `setup()` now builds the flash silhouette from the family
  look — sphere (ball/puff), tapered cone (flame), straight cylinder (rail needle / sonic
  disc) — and stores `_flash_life/_flash_stretch/_flash_lrange/_flash_lenergy`.
  `try_fire` calls the new `_aim_flash(direction)` (local dir via `global_basis.inverse()`,
  mesh oriented with `MeshUtil.segment_basis` so mesh-local **+Y is the shot**), and
  `_process` animates each silhouette on its own curve: bloom expands, cone flares, needle
  snaps, disc rings outward. `FLASH_TIME` stays as the default only; every timing now reads
  `_flash_life`.
- **Tracer silhouette (`projectile.gd`):** `_ensure_tracer_shape()` swaps the pooled mesh
  per family (SphereMesh for orbs, BoxMesh otherwise) at `launch()`; `_aim()` scales per
  shape (uniform orb, thin long needle, fat short shell, streak) and sets emission energy
  5.0/4.2/2.4/3.5 so a round reads right against its own flash. The old electric-only
  scale branch is gone (electric trace is now ORB; the arc segments still carry length).
- **Impacts (`combat_fx.gd`):** `_on_weapon_impact` is a full `match` on Kind —
  electric shards, rail white-hot, rocket/salvo/scatter/flame scorch + colour, beam and
  corrosion still leave no burn, sonic violet.
- **Per-weapon fire sound (`audio_engine.gd`):** `Events.weapon_fired` gained
  **`family: StringName, size: int`** (emitters `weapon_mount` + `drone_orbit`, handlers
  `audio_engine`, `player_robot`, `game_session` all updated). `_on_weapon_fired` resolves
  `FAMILY_VOICE` (46 hand-set family→archetype) → `KIND_VOICE` (10) → `cannon`,
  multiplies `_family_pitch()` (hand-tuned ~23 families, deterministic 0.88–1.12 name-hash
  for the rest) by `_size_pitch()` (+0.14 LIGHT … −0.14 HEAVY, −0.2 ALPHA) and the chassis
  voice. Two new archetypes: **`whip`** (light kinetic: GLADIUS/PILUM/CELERITY) and
  **`clank`** (heavy titan: JUGGERNAUT/DEMOLISHER/OVERLORD/VOID/CHASH/CHASM). Impact
  sounds are per-kind now too (zap/rail/hiss/beam/sonic/flame, metal clang as fallback).
- **Smoke 1794 → 1885:** new `_check_shot_appearance()` — family stamping for all ten
  originals, per-class silhouette + tracer + colour-set asserts (5 shapes, N colours),
  frost/void/titan colour overrides, six built mounts carrying life/range/colour/stretch
  with the right mesh class, whip/clank registration + voice routing + fallback, size
  pitch direction, and an **every-catalog-item voice resolution** loop over
  `ALL_ITEM_IDS + TITAN_ITEM_IDS` (each must resolve to a registered stream) plus a
  ≥30 distinct-pitch spread. `whip`/`clank` added to the existing stream-quality loop
  (44.1 kHz, peak, sustained body).
- **Scope note:** no `--apk`, no Windows export, **version unchanged at 0.39.0** — as the
  director asked. Still open from §12-53: WR combat-stat visibility, LightmapGI/VFX
  overhaul, paint/camo shop, PRAETOR portrait, out-of-app notifications.

---

## 55. UI redesign integration + gamepad ghost-input fix + particle amount guard (v0.40.0, smoke 1898)

Two director requests in one batch: drop in the untested **full UI redesign zip**, then the
12-phase **gamepad / uncontrolled-input fix** plus the `CPUParticles3D` "Amount of particles
must be greater than 0" error. **Both apps built and committed**; version bumped
0.39.0 → **0.40.0** (code 40, `BUILD_LABEL v0.40.0 · 2026-10-09`) because this batch ships
user-visible changes and §39 requires the label to identify the running build.

- **UI redesign zip** (`/sdcard/Download/mech-assault-full-ui-redesign.zip`, unpacked to
  `/tmp/opencode/redesign/`) is a modified copy of the earlier source pack. Only four game
  files differ from the repo: `src/ui/theme_builder.gd`, `src/ui/ui_parts.gd`,
  `src/ui/screens/settings_screen.gd` and the new `src/ui/screen_backdrop.gd` (plus its
  auto-generated `.uid`). Dropped in as-is; the only repair was removing the duplicate
  `_content.add_child(hero)` at `mega_hub_screen.gd:214` (benign, but it logged). Gate:
  `tools/ui_dump.tscn` = 13 screens, **0 ERRORs**, smoke still 1885.
- **Root causes found in the input audit (each fixed at source, never suppressed):**
  1. **`fire` was bound to `MOUSE_BUTTON_LEFT`** → `Input.is_action_pressed(&"fire")` is true
     on *any* LMB press, including clicks a Control had already consumed, so clicking a HUD or
     menu button also fired the guns (spec Phase 9 violation). Fix: the mouse is gone from the
     InputMap action and is its own event stream — `_mouse_fire` is armed in
     `InputRouter._unhandled_input` (only unconsumed clicks), cleared in `_input` (pre-GUI, so
     a Control sitting under the cursor cannot swallow the release), re-synced every frame
     against `Input.is_mouse_button_pressed`, and cleared on focus loss + `clear_temporary()`.
  2. **No radial deadzone on the combined move vector** → a cheap wireless pad resting at
     (0.9, −1.0) drove the robot by itself. New `InputRouter._radial_deadzone(value, dz)`
     (radial test + magnitude rescale so there is no 0→dz jump) applied to the pad
     contribution; `GameState.pad_deadzone_left/right` clamped to `DEADZONE_MIN 0.05` /
     `DEADZONE_MAX 0.30`, pushed through `apply_settings()` and persisted.
  3. **Absolute right-trigger threshold.** Rest-centre calibration (`_pad_trigger_low/_high`)
     was kept, but the fire test is now normalized to the observed travel:
     `(trigger − low) / max(travel, PAD_TRIGGER_TRAVEL 0.4)`. An inverted or stuck-at-boot
     axis fails safe (never arms); raw-low arming is retained as belt-and-braces.
  4. **Unplug left a ghost vector.** `_on_joy_connection` now calls `_reset_pad_state()`,
     which clears `move_vector`, `look_delta`, `look_touch_index` and `_pad_trigger_value`.
  5. **Hangar touch.** Desktop `emulate_touch_from_mouse` made one drag arrive as both
     MouseMotion and ScreenTouch/ScreenDrag (double rotation, double pick). New
     `_touch_live()` gate runs the touch handlers only while
     `PlatformUtil.effective_mode() == InputMode.TOUCH`; single-finger drag now rotates the
     model (`rotate_user(-relative.x * DRAG_YAW_DEG_PER_PX)`) and a <8 px touch is a
     tap-to-`pick_slot` (unreachable before: `emulate_mouse_from_touch` is off). Dedupe is
     positional for rotation and erase-on-release for pick, so the gui/unhandled double
     delivery is idempotent. `on_exit()` clears all touch bookkeeping.
  6. **Phase 7 result: no duplicate transform writes exist.** `FollowCamera` is the only
     `consume_look()` consumer (`follow_camera.gd:49`), the hull yaw is written in exactly
     one place (`player_robot.gd:513`), and there is **no** hangar auto-spin — the §45
     "auto-spin" text was stale.
- **New settings:** `Section_CONTROLLER` (`DeadzoneLeftSlider`/`DeadzoneRightSlider`,
  0.05–0.30 step 0.01 + captions) and `InputDiagnosticsCheck` under `Section_SYSTEM`;
  handlers `_on_deadzone_left/right_changed`, `_on_input_diagnostics_toggled`.
- **Diagnostics:** `InputRouter.input_snapshot()` renders `SRC/MV/FIRE/PAD/DZ`, appended by
  `GameSession._update_debug()` only when `GameState.input_diagnostics` and
  `OS.is_debug_build()`.
- **Particle guard (Phase 12):** the Windows console error came from four **unguarded
  computed** `amount` setters — `combat_fx._spawn_sparks` (`combat_fx.gd:134`),
  `combat_fx._burst_smoke` (`:266`), `heal_fx._spawn_sparks` (`heal_fx.gd:292`) and
  `shadow_dash._burst_particles` (`shadow_dash.gd:365`) — all now `maxi(1, …)`.
  Full source audit: **no `amount = 0` anywhere**, `weather_system`/`damage_reaction` already
  guard, and `scenes/*.tscn` contains no `Particles` nodes.
- **Smoke 1885 → 1898:** `_check_input_ownership()` (fire action has no `InputEventMouseButton`;
  unconsumed LMB press arms / LMB release clears / `_process` resync un-sticks it; deadzone
  zero-inside + rescaled-exit + clamp math; `set_pad_deadzone_*` clamps and syncs then
  restores; `_reset_pad_state` clears stale move/look; snapshot text) and
  `_check_particle_amounts()` (every `CPUParticles3D` in the tree has `amount >= 1`, run once
  while the game scene is up and once at menu).
- **Verification:** `./tools/validate.sh` → import clean, **1898 checks, 0 failures**,
  `VALIDATION PASSED`; `ui_dump` 13 screens / 0 ERRORs; `render_ui.py` settings.png 92
  controls with all six new node names present in `build/ui_dump.json`.
- **Honest hardware gap:** the spec's real-controller / Windows-console tests cannot run on
  this host (no pad, no `/dev/kvm`, no Windows, no GPU). Everything above is code audit +
  headless smoke + flat-albedo render only; the particle error's fix needs a Windows run to
  confirm, and pad behaviour needs a physical controller.
- Untracked and **must not be committed:** `tools/apply_wr_v38.py`, `tools/weapon_probe.gd`,
  `tools/weapon_probe.gd.uid`, `tools/weapon_probe.tscn`.
- **Artifacts rebuilt from this commit:** `build/android/mech-assault-debug.apk` (via
  `./tools/validate.sh --apk`) and `build/windows/mech-assault.exe` (+ console wrapper).
- **Windows crash-log launcher (follow-up, same version):** the director reported that
  `mech-assault.console.exe` closes the instant the game dies, so the error tail is lost —
  the particle message he saw is **non-fatal** (`ERR_FAIL_COND_MSG` in `set_amount` just
  keeps the previous amount), so the real fault is whatever printed after it. New
  `tools/windows/run_console.bat` (copied to `build/windows/run_console.bat` after every
  Windows export) launches the console exe with `--log-file "%HERE%godot_console.log"` so
  the engine log lands beside the exe, tees stdout/stderr to `console_log.txt`, falls back
  to a plain redirect if PowerShell is blocked, then `pause`s. It also tails the default
  `%APPDATA%\Godot\app_userdata\MECH ASSAULT\logs\godot.log` as a belt-and-braces copy.
  **Re-copy the bat after every Windows export** — `build/` is gitignored so it does not
  survive a clean.
- Still open from §12-54: WR combat-stat visibility, LightmapGI/VFX overhaul, paint/camo
  shop, PRAETOR portrait, out-of-app notifications.

---

## 56. Touch auto-fire hotfix + hand-off pack (v0.41.0, smoke 1901)

Director report: *"why does touching anywhere on screen autoshoot, even all buttons make
robot autoshoot"*. Root-caused with a dedicated probe, fixed at source, validated at
**1901 smoke checks, 0 failures** (`VALIDATION PASSED`).

- **Root cause (`tools/fire_probe.{gd,tscn}`):** Godot ships `emulate_mouse_from_touch`
  **on by default**, so every finger press is also delivered as an emulated
  `InputEventMouseButton` LEFT press. Most of the screen is empty ground and every
  touch-panel wedge is `MOUSE_FILTER_PASS` (§35), so nothing consumes that twin — it
  reaches `InputRouter._unhandled_input` and set `_mouse_fire = true`. Measured before
  the fix: `finger on open ground → fire`, `finger on PASS wedge → fire`; only a
  `MOUSE_FILTER_STOP` button stayed quiet, which is why "all the buttons" still shot.
- **Why it was not obvious:** the same code path is *correct* for a real mouse
  (desktop click-to-fire). The two cases are only distinguishable by arrival order —
  Godot always dispatches the **emulated twin before its source event**:
  - real mouse press → `[Touch twin, LMB source]`
  - finger press → `[LMB twin, Touch source]`
- **Fix (`input_router.gd`):** new `_touch_twin_seen` is set in `_input` on a pressed
  `InputEventScreenTouch` and cleared at the end of every `_process` (and in
  `clear_temporary()`). The LMB-press branch now arms `_mouse_fire` only when that flag
  was already true, i.e. when the pair started with a touch twin. Fallbacks: if
  `emulate_touch_from_mouse` is off we cannot use ordering, so the branch falls back to
  refusing while `PlatformUtil.effective_mode() == TOUCH`.
- **Probe rewritten as a 5-case PASS/FAIL regression gate:** finger on ground / STOP
  button / PASS button must all stay quiet, mouse click on ground must still fire,
  mouse click on a STOP button must stay quiet. All five pass after the fix.
- **Smoke 1898 → 1901:** `_check_input_ownership` now feeds the touch twin before the
  LMB for the "real mouse" case, asserts a twinless LMB cannot arm, asserts the flag is
  cleared by `_process`, and asserts the *next* frame's real mouse press still arms.
- **Note on the director's "you didn't do the per-weapon sounds/animations" report:**
  that work **is** shipped — commit `faf36da` (§54), present in the v0.40.0 APK/exe.
  Entry points if it needs extending: `WeaponData.shot_look()` (`weapon_data.gd:275`,
  family muzzle colour/shape/tracer), `WeaponMount.setup()` (`weapon_mount.gd:111`) +
  `_aim_flash()` (`:404`), `audio_engine.FAMILY_VOICE` (`:189`) / `_family_pitch`
  (`:311`) / `_size_pitch` (`:320`) over 12 synthesized archetypes. It is **12
  archetypes + per-family pitch/colour**, not 62 individually recorded sounds — the
  honest ceiling of a fully procedural pipeline.
- **Hand-off pack:** `tools/pack.sh` → `build/mech-assault-src-<version>.zip`, built
  from `git ls-files` **minus `assets/` and `build/`** (293 files, ~3.3 MB) — sources,
  scenes, tools, docs, manifests, export preset; no assets, no build output, no
  `.godot` cache, no git history.
- **Version:** trio moved 0.40.0 → **0.41.0** (code 41, `BUILD_LABEL v0.41.0 · 2026-10-09`).
- Still open from §12-55: WR combat-stat visibility, LightmapGI/VFX overhaul, paint/camo
  shop, PRAETOR portrait, out-of-app notifications.
