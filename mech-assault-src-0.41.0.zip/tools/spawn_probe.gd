extends Node

const GAME_SCENE := "res://scenes/game.tscn"
const SETTLE_FRAMES := 150
const MOVE_FRAMES := 120
const REST_FRAMES := 60

var _combos: Array[Array] = []
var _combo_index: int = 0
var _game: Node3D = null
var _phase: int = 0
var _frame: int = 0

func _ready() -> void:
	var robots: Array[StringName] = [
		GameState.ROBOT_SCARAB, GameState.ROBOT_VORTEX, GameState.ROBOT_RAMPART,
	]
	for robot_id in robots:
		_combos.append([robot_id])
	_start_combo.call_deferred()

func _start_combo() -> void:
	if _combo_index >= _combos.size():
		print("PROBE DONE")
		get_tree().quit(0)
		return
	var combo := _combos[_combo_index]
	GameState.selected_robot = combo[0] as StringName
	_game = (load(GAME_SCENE) as PackedScene).instantiate() as Node3D
	add_child(_game)
	for child in _game.get_children():
		if child is EnemyRobot:
			(child as EnemyRobot).ai_enabled = false
	_phase = 0
	_frame = 0

func _physics_process(_delta: float) -> void:
	if _game == null:
		return
	_frame += 1
	match _phase:
		0:
			if _frame >= SETTLE_FRAMES:
				_measure("settled")
				InputRouter.set_virtual_move(Vector2(0.0, 1.0))
				_phase = 1
				_frame = 0
		1:
			if _frame >= MOVE_FRAMES:
				_measure("moving")
				InputRouter.set_virtual_move(Vector2.ZERO)
				_phase = 2
				_frame = 0
		2:
			if _frame >= REST_FRAMES:
				_measure("stopped")
				var combo := _combos[_combo_index]
				print("PROBE combo %s/%s done" % [
						String(combo[0] as StringName), String(combo[1] as StringName)])
				_game.free()
				_game = null
				_combo_index += 1
				_start_combo.call_deferred()

func _measure(tag: String) -> void:
	if _game == null:
		return
	var combo := _combos[_combo_index]
	var map_id := combo[0] as StringName
	var robot_id := combo[1] as StringName
	var player := _game.get_node_or_null("Player") as PlayerRobot
	if player == null:
		print("PROBE %s %s %s NO_PLAYER" % [String(map_id), String(robot_id), tag])
		return
	var ground := _ray_ground(player.global_position)
	var box: Variant = _visual_box(player.rig)
	var burrow := -999.0
	if box != null:
		burrow = (box as AABB).position.y - ground
	var enemy_text := ""
	for child in _game.get_children():
		if not (child is EnemyRobot):
			continue
		var enemy := child as EnemyRobot
		var e_ground := _ray_ground(enemy.global_position)
		var e_box: Variant = _visual_box(enemy)
		var e_burrow := -999.0
		if e_box != null:
			e_burrow = (e_box as AABB).position.y - e_ground
		if enemy_text != "":
			enemy_text += "; "
		enemy_text += "y=%.2f g=%.2f vmin=%.2f burrow=%.2f" % [
				enemy.global_position.y, e_ground,
				(e_box as AABB).position.y if e_box != null else -999.0, e_burrow]
	print("PROBE %s %s %s player_y=%.2f floor=%s ground=%.2f rig_y=%.2f vis_min=%s vis_max=%s burrow=%.2f | enemies: %s" % [
			String(map_id), String(robot_id), tag,
			player.global_position.y, str(player.is_on_floor()), ground,
			player.rig.global_position.y,
			"%.2f" % ((box as AABB).position.y if box != null else -999.0),
			"%.2f" % ((box as AABB).end.y if box != null else -999.0),
			burrow, enemy_text])

func _ray_ground(at: Vector3) -> float:
	if _game == null:
		return -999.0
	var query := PhysicsRayQueryParameters3D.new()
	query.from = at + Vector3.UP * 40.0
	query.to = at + Vector3.DOWN * 80.0
	query.collision_mask = Layers.WORLD
	query.collide_with_areas = false
	var hit: Dictionary = _game.get_world_3d().direct_space_state.intersect_ray(query)
	if hit.is_empty():
		return -999.0
	return (hit["position"] as Vector3).y

func _visual_box(root: Node) -> Variant:
	if root == null:
		return null
	var result: AABB = AABB()
	var found := false
	var nodes: Array[Node] = [root]
	while not nodes.is_empty():
		var node: Node = nodes.pop_back()
		if node is MeshInstance3D:
			var mesh_instance := node as MeshInstance3D
			if mesh_instance.visible and mesh_instance.mesh != null:
				var local: AABB = mesh_instance.mesh.get_aabb()
				var global_box := _transform_aabb(mesh_instance.global_transform, local)
				if found:
					result = result.merge(global_box)
				else:
					result = global_box
					found = true
		for child in node.get_children():
			nodes.append(child)
	if not found:
		return null
	return result

func _transform_aabb(xform: Transform3D, box: AABB) -> AABB:
	var corners: Array[Vector3] = []
	for ix in 2:
		for iy in 2:
			for iz in 2:
				var corner := box.position + Vector3(
						box.size.x * float(ix), box.size.y * float(iy),
						box.size.z * float(iz))
				corners.append(xform * corner)
	var out := AABB(corners[0], Vector3.ZERO)
	for index in range(1, corners.size()):
		out = out.expand(corners[index])
	return out
