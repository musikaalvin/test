extends Node

const OUTPUT_DIR := "res://build/screenshots"
const SHOT_COUNT := 4
const SHOT_INTERVAL := 45

var _game: Node3D
var _camera: Camera3D
var _frames: int = 0
var _shots: int = 0
var _angle_step: float = 0.0

func _ready() -> void:
	DirAccess.make_dir_recursive_absolute(ProjectSettings.globalize_path(OUTPUT_DIR))
	_run.call_deferred()

func _run() -> void:
	GameState.enter_menu()
	_game = (load("res://scenes/game.tscn") as PackedScene).instantiate() as Node3D
	add_child(_game)
	_camera = _game.get_node_or_null("CameraRig/SpringArm3D/Camera3D") as Camera3D
	if _camera == null:
		printerr("ScreenshotTool: no camera found")
		get_tree().quit(1)

func _process(_delta: float) -> void:
	_frames += 1
	if _camera != null and _frames % SHOT_INTERVAL == 0:
		_capture("shot_%02d" % _shots)
		_shots += 1
		_orbit()
	if _shots >= SHOT_COUNT:
		get_tree().quit(0)

func _orbit() -> void:
	var rig := _game.get_node_or_null("CameraRig") as FollowCamera
	if rig != null:
		rig.pitch = -0.22 + float(_shots) * 0.12
		rig.add_yaw(_angle_step)
		_angle_step += 0.9

func _capture(label: String) -> void:
	await RenderingServer.frame_post_draw
	var image := get_viewport().get_texture().get_image()
	if image == null:
		printerr("ScreenshotTool: viewport image unavailable")
		return
	var path := "%s/%s.png" % [OUTPUT_DIR, label]
	var error := image.save_png(path)
	if error == OK:
		print("screenshot saved: %s (%dx%d)" % [path, image.get_width(), image.get_height()])
	else:
		printerr("screenshot failed: %s (error %d)" % [path, error])