#!/usr/bin/env python3
"""One-pass texture import migration: lossless -> VRAM + mipmaps + 4K/2K caps.

Rules (director-approved pipeline):
  * sources under assets/ with max dim >= 1024 and >= 1 MP
  * compress/mode 0 (lossless) -> 2 (VRAM compressed, BC/ETC2)
  * mipmaps/generate -> true
  * process/size_limit: 8K sources -> 4096, 4K sources -> 2048, 2K kept
  * compress/normal_map = 1 for *normal* maps (green-channel safe formats)
  * documentation/preview/2D art names are skipped
Idempotent: already-VRAM files are only re-checked, not rewritten.
Dest .ctex/.md5 files are deleted so the next --import regenerates them.
"""
import glob
import os
import re
import sys

SKIP_NAME = re.compile(r"doc_\d|light_doc|preview|logo|icon|font|button|badge",
                       re.IGNORECASE)
NORMAL_NAME = re.compile(r"normal|_nrm|_nor\b|nor\.", re.IGNORECASE)
EXTS = (".png", ".jpg", ".jpeg", ".tga", ".bmp", ".webp")


def parse_import(path: str):
    sec, out = None, {}
    with open(path, encoding="utf-8") as fh:
        for line in fh:
            s = line.strip()
            if s.startswith("[") and s.endswith("]"):
                sec = s[1:-1]
                out.setdefault(sec, {})
                continue
            if sec and "=" in line and not line[0:1].isspace():
                k, v = line.split("=", 1)
                out[sec][k.strip()] = v.strip()
    return out


def rewrite_params(path: str, dims, forced: bool) -> bool:
    from PIL import Image
    w, h = dims
    src = path[:-7]
    mode = NORMAL_NAME.search(os.path.basename(src)) is not None
    limit = 0
    if max(w, h) >= 8192:
        limit = 4096
    elif max(w, h) >= 4096:
        limit = 2048
    if not forced:
        forced = True  # caller already decided this file qualifies
    with open(path, encoding="utf-8") as fh:
        lines = fh.readlines()
    changed = False
    in_params = False
    for i, line in enumerate(lines):
        s = line.strip()
        if s.startswith("[") and s.endswith("]"):
            in_params = s == "[params]"
            continue
        if not in_params or "=" not in line:
            continue
        k = line.split("=", 1)[0].strip()
        if k == "compress/mode" and not line.rstrip().endswith("=2"):
            lines[i] = "compress/mode=2\n"
            changed = True
        elif k == "mipmaps/generate" and "true" not in line:
            lines[i] = "mipmaps/generate=true\n"
            changed = True
        elif k == "process/size_limit" and limit > 0:
            val = int(line.split("=", 1)[1].strip() or "0")
            if val != limit:
                lines[i] = f"process/size_limit={limit}\n"
                changed = True
        elif k == "compress/normal_map" and mode and not line.rstrip().endswith("=1"):
            lines[i] = "compress/normal_map=1\n"
            changed = True
    if changed:
        with open(path, "w", encoding="utf-8") as fh:
            fh.writelines(lines)
    return changed


def delete_dests(imp: str) -> int:
    d = parse_import(imp)
    removed = 0
    paths = []
    rp = d.get("remap", {}).get("path", "").strip('"')
    if rp.startswith("res://"):
        paths.append(rp[6:])
    for k, v in d.get("deps", {}).items():
        if k.startswith("dest_files"):
            for m in re.finditer(r'"res://([^"]+)"', v):
                paths.append(m.group(1))
    for p in paths:
        for f in (p, p + ".md5"):
            if os.path.exists(f):
                os.remove(f)
                removed += 1
    return removed


def main() -> int:
    from PIL import Image
    dry = "--apply" not in sys.argv
    edited, skipped, removed = [], 0, 0
    for imp in sorted(glob.glob("assets/**/*.import", recursive=True)):
        src = imp[:-7]
        if SKIP_NAME.search(os.path.basename(src)):
            skipped += 1
            continue
        if os.path.splitext(src)[1].lower() not in EXTS:
            skipped += 1
            continue
        try:
            with Image.open(src) as im:
                dims = im.size
        except Exception:
            skipped += 1
            continue
        if max(dims) < 1024 or dims[0] * dims[1] < 1024 * 1024:
            skipped += 1
            continue
        if dry:
            print(f"WOULD EDIT {dims[0]}x{dims[1]}  {src}")
            edited.append(src)
            continue
        if rewrite_params(imp, dims, True):
            removed += delete_dests(imp)
            edited.append(src)
    tag = "DRY RUN" if dry else "APPLIED"
    print(f"{tag}: {len(edited)} imports edited, {skipped} skipped, "
          f"{removed} dest files deleted")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
