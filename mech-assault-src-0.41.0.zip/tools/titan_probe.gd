extends Node

func _ready() -> void:
	for rid: StringName in [&"PRAETOR", &"CITADEL", &"RAVAGER"]:
		GameState.selected_robot = rid
		var game := (load("res://scenes/game.tscn") as PackedScene).instantiate() as Node3D
		add_child(game)
		await get_tree().physics_frame
		await get_tree().physics_frame
		var player := game.get_node("Player") as Node3D
		var rig: Node3D = player.get_node_or_null("Visuals/RobotRig")
		if rig == null:
			rig = player.get_node_or_null("RobotRig")
		print("=== %s rig=%s class=%s" % [rid, str(rig), rig.get_class() if rig else "?"])
		if rig != null:
			var meshes: Array[String] = []
			var legacy: Array[String] = []
			for m in rig.find_children("*", "MeshInstance3D", true, false):
				var path: String = rig.get_path_to(m)
				if path.contains("__"):
					meshes.append(path.get_slice("/", 0) + "/" + String(m.name))
				else:
					legacy.append(path)
			print("  glb parts: %d  legacy: %d" % [meshes.size(), legacy.size()])
			print("  glb sample: %s" % str(meshes.slice(0, 6)))
			print("  legacy sample: %s" % str(legacy.slice(0, 6)))
			var shell := rig.get_node_or_null("Group")
			print("  shell node: %s" % str(shell))
		game.queue_free()
		await get_tree().physics_frame
	get_tree().quit(0)
