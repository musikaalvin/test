#!/usr/bin/env python3
"""Dependency-free sanity check for the reference/asset skeleton."""
from __future__ import annotations

import json
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parents[1]
CATALOG = ROOT / "data" / "mech_assault_reference_12_4.json"


def main() -> int:
    try:
        data = json.loads(CATALOG.read_text(encoding="utf-8"))
    except Exception as exc:
        print(f"REFERENCE SKELETON FAILED: JSON: {exc}")
        return 1

    required = ["robots", "weapons", "pilots", "drones", "asset_contract", "ui_assets"]
    missing = [key for key in required if not isinstance(data.get(key), dict)]
    if missing:
        print("REFERENCE SKELETON FAILED: missing sections: " + ", ".join(missing))
        return 1

    failures: list[str] = []
    for section_name in ("robots", "weapons", "pilots", "drones"):
        for item_id, profile in data[section_name].items():
            if not isinstance(profile, dict):
                failures.append(f"{section_name}/{item_id}: profile is not an object")
                continue
            hooks = profile.get("asset_hooks", {})
            if not isinstance(hooks, dict):
                failures.append(f"{section_name}/{item_id}: asset_hooks is not an object")
                continue
            if "model_scene" in data["asset_contract"].get("robot", []) and section_name == "robots":
                if "model_scene" not in hooks:
                    failures.append(f"robots/{item_id}: no model_scene hook")

    if failures:
        for failure in failures:
            print(" - " + failure)
        print(f"REFERENCE SKELETON FAILED: {len(failures)} issue(s)")
        return 1

    print(
        "REFERENCE SKELETON OK: "
        f"{len(data['robots'])} robots, {len(data['weapons'])} weapons, "
        f"{len(data['pilots'])} pilots, {len(data['drones'])} drones; "
        "asset paths are hook-based and optional."
    )
    return 0


if __name__ == "__main__":
    sys.exit(main())
