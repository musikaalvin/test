import os
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

import bpy
from mathutils import Matrix

import build_mech as bm

OUT_VORTEX = os.path.normpath(os.path.join(
	os.path.dirname(os.path.abspath(__file__)), "..", "assets", "mech", "vortex.glb"))

HIP_POS = [(0.52, -0.1, 0.0), (-0.52, -0.1, 0.0)]
HIP_OUT = [(1.0, 0.0, 0.0), (-1.0, 0.0, 0.0)]

THIGH = 1.25
SHIN = 1.45
COXA = 0.32


def part(t, m, verts, faces, local, bevel=0.0, smooth=False):
	return bm.part(t, m, verts, faces, local, bevel, smooth)


def box(t, m, size, origin, rot=None, bevel=0.02):
	return bm.box_part(t, m, size, origin, rot, bevel)


def cyl(t, m, radius, length, origin, rot=None, segments=16):
	return bm.cyl_part(t, m, radius, length, origin, rot, segments)


def sph(t, m, radius, origin, scale=None, rot=None):
	return bm.sph_part(t, m, radius, origin, scale, rot)


def cone(t, m, rb, rt, length, origin, rot=None):
	return bm.cone_part(t, m, rb, rt, length, origin, rot)


def loft(t, m, path, radii, origin=(0.0, 0.0, 0.0), rot=None, segments=16):
	return bm.loft_part(t, m, path, radii, origin, rot, segments)


def build_chassis():
	t = "chassis"
	box(t, "m_primary", (1.15, 0.62, 0.9), (0.0, -0.05, 0.06), None, 0.05)
	box(t, "m_secondary", (0.9, 0.5, 0.7), (0.0, 0.4, 0.05), None, 0.04)
	box(t, "m_primary", (1.6, 0.95, 1.3), (0.0, 0.92, -0.05), None, 0.07)
	box(t, "m_secondary", (1.78, 0.26, 1.12), (0.0, 1.34, -0.05),
		bm.rot_x(-5.0), 0.05)
	box(t, "m_accent", (1.2, 0.5, 0.44), (0.0, 1.06, -0.66),
		bm.rot_x(-24.0), 0.04)
	box(t, "m_secondary", (1.3, 0.34, 0.5), (0.0, 0.5, -0.6),
		bm.rot_x(-14.0), 0.04)
	box(t, "m_accent", (0.6, 0.3, 0.4), (0.0, 1.4, 0.42), None, 0.035)
	box(t, "m_primary", (0.8, 0.5, 0.2), (0.0, 1.0, 0.66), None, 0.04)
	for vent in range(3):
		box(t, "m_recess", (0.5, 0.06, 0.08),
			(0.0, 0.78 + vent * 0.16, 0.78), None, 0.008)
	for side in (1.0, -1.0):
		box(t, "m_secondary", (0.2, 0.9, 1.15), (side * 0.88, 0.88, -0.05),
			bm.rot_z(side * -6.0), 0.04)
		box(t, "m_accent", (0.14, 0.5, 0.8), (side * 0.96, 0.6, -0.1),
			bm.rot_z(side * -6.0), 0.03)
		box(t, "m_joint", (0.5, 0.44, 0.6), (side * 0.94, 1.12, -0.02),
			None, 0.04)
		sph(t, "m_joint", 1.0, (side * 1.02, 1.06, 0.0), scale=(0.24, 0.24, 0.24))
		box(t, "m_secondary", (0.3, 0.68, 0.34), (side * 1.04, 0.6, 0.04),
			bm.rot_z(side * -7.0), 0.035)
		sph(t, "m_joint", 1.0, (side * 1.06, 0.28, 0.05), scale=(0.15, 0.15, 0.15))
		box(t, "m_primary", (0.34, 0.56, 0.42), (side * 1.08, 0.02, 0.12),
			bm.euler_g(6.0, 0.0, side * 4.0), 0.035)
		box(t, "m_joint", (0.36, 0.3, 0.46), (side * 1.08, -0.22, 0.18),
			None, 0.04)
		box(t, "m_secondary", (0.5, 0.6, 0.66), (side * 0.62, 0.1, 0.52),
			None, 0.05)
		cyl(t, "m_trim", 0.13, 0.7, (side * 0.4, 1.06, 0.72), bm.rot_x(28.0), 12)
		cyl(t, "m_recess", 0.15, 0.12, (side * 0.4, 1.34, 0.86), bm.rot_x(28.0), 12)
		box(t, "m_sensor", (0.05, 0.06, 0.6), (side * 1.0, 0.9, -0.2), None, 0.006)
		cone(t, "m_accent", 0.13, 0.02, 0.42, (side * 0.72, -0.28, -0.62),
			bm.euler_g(-118.0, side * -10.0, 0.0))
	box(t, "m_secondary", (1.0, 0.36, 1.1), (0.0, -0.36, 0.06), None, 0.05)
	box(t, "m_primary", (0.5, 0.3, 0.9), (0.0, -0.44, -0.1), None, 0.04)
	sph(t, "m_sensor", 1.0, (0.0, -0.4, -0.44), scale=(0.2, 0.2, 0.2))


def build_head():
	t = "head"
	sph(t, "m_primary", 1.0, (0.0, 0.0, 0.0), scale=(0.45, 0.24, 0.36))
	sph(t, "m_accent", 1.0, (0.0, 0.18, -0.14), scale=(0.47, 0.08, 0.28),
		rot=bm.rot_x(-14.0))
	box(t, "m_recess", (0.62, 0.21, 0.15), (0.0, -0.02, -0.3), None, 0.015)
	box(t, "m_sensor", (0.5, 0.075, 0.06), (0.0, 0.03, -0.36), None, 0.006)
	sph(t, "m_sensor", 1.0, (0.17, 0.03, -0.36), scale=(0.055, 0.05, 0.045))
	sph(t, "m_sensor", 1.0, (-0.17, 0.03, -0.36), scale=(0.055, 0.05, 0.045))
	box(t, "m_secondary", (0.56, 0.16, 0.4), (0.0, -0.24, -0.1),
		bm.rot_x(12.0), 0.03)
	for side in (1.0, -1.0):
		box(t, "m_secondary", (0.16, 0.3, 0.44), (side * 0.42, -0.02, -0.04),
			bm.rot_z(side * -10.0), 0.025)
	sph(t, "m_joint", 1.0, (0.0, 0.24, 0.06), scale=(0.11, 0.1, 0.11))
	cyl(t, "m_trim", 0.026, 0.44, (-0.26, 0.42, 0.08), bm.euler_g(8.0, 8.0, 0.0), 8)
	sph(t, "m_sensor", 1.0, (-0.29, 0.63, 0.05), scale=(0.045, 0.045, 0.045))


def build_legs():
	for index in range(2):
		c = "l%dc" % index
		sph(c, "m_joint", 1.0, (0.0, 0.0, 0.0), scale=(0.21, 0.21, 0.21))
		loft(c, "m_trim", [(0.0, 0.0, 0.0), (0.0, 0.16, 0.0), (0.0, COXA, 0.0)],
			[0.17, 0.15, 0.125], segments=14)
		sph(c, "m_primary", 1.0, (0.0, 0.17, 0.0), scale=(0.17, 0.16, 0.21))
		u = "l%du" % index
		loft(u, "m_primary", [
			(0.0, 0.0, 0.0), (0.02, 0.42, 0.03), (0.01, 0.84, 0.01),
			(0.0, THIGH, 0.0),
		], [0.17, 0.21, 0.17, 0.12], segments=18)
		sph(u, "m_accent", 1.0, (0.01, 0.52, 0.05), scale=(0.14, 0.32, 0.1))
		cyl(u, "m_accent", 0.21, 0.08, (0.0, 0.36, 0.0), None, 18)
		for side in (1.0, -1.0):
			cyl(u, "m_trim", 0.045, 0.65, (side * 0.2, 0.44, 0.0), None, 10)
			cyl(u, "m_joint", 0.028, 0.4, (side * 0.2, 0.88, 0.0), None, 8)
		sph(u, "m_joint", 1.0, (0.0, THIGH, 0.0), scale=(0.2, 0.2, 0.2))
		cyl(u, "m_accent", 0.13, 0.1, (0.0, THIGH, 0.0), bm.rot_x(90.0), 14)
		l = "l%dl" % index
		loft(l, "m_primary", [
			(0.0, 0.0, 0.0), (0.0, 0.48, -0.02), (0.0, 0.96, -0.01),
			(0.0, SHIN, 0.0),
		], [0.145, 0.16, 0.125, 0.095], segments=16)
		sph(l, "m_secondary", 1.0, (0.0, 0.55, -0.075), scale=(0.095, 0.32, 0.085))
		cyl(l, "m_accent", 0.16, 0.07, (0.0, 0.45, 0.0), None, 16)
		for side in (1.0, -1.0):
			cyl(l, "m_trim", 0.038, 0.65, (side * 0.14, 0.55, 0.03), None, 10)
		sph(l, "m_joint", 1.0, (0.0, SHIN, 0.0), scale=(0.125, 0.125, 0.125))
		f = "l%df" % index
		sph(f, "m_joint", 1.0, (0.0, 0.09, 0.0), scale=(0.1, 0.11, 0.1))
		sph(f, "m_recess", 1.0, (0.0, -0.045, 0.0), scale=(0.2, 0.075, 0.26))
		sph(f, "m_joint", 1.0, (0.0, 0.0, 0.02), scale=(0.16, 0.045, 0.2))
		for cx in (-0.13, 0.0, 0.13):
			yaw = -12.0 if cx > 0.0 else (12.0 if cx < 0.0 else 0.0)
			cone(f, "m_joint", 0.06, 0.006, 0.3, (cx, -0.01, -0.27),
				bm.euler_g(-85.0, yaw, 0.0))
		cone(f, "m_joint", 0.055, 0.006, 0.24, (0.0, -0.02, 0.27), bm.rot_x(95.0))


def build_poses():
	empties = {}
	empties["chassis"] = Matrix.Identity(4)
	empties["head"] = bm.translate_g((0.0, 1.6, -0.52))
	for index in range(2):
		pose = bm.leg_pose(HIP_POS[index], HIP_OUT[index])
		empties["l%dc" % index] = pose["coxa"]
		empties["l%du" % index] = pose["upper"]
		empties["l%dl" % index] = pose["lower"]
		empties["l%df" % index] = pose["foot"]
	return empties


bm.construct(
	builders=[build_chassis, build_head, build_legs],
	poses_fn=build_poses,
	out_path=OUT_VORTEX)
