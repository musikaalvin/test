extends Node

func _ready() -> void:
	var game := (load("res://scenes/game.tscn") as PackedScene).instantiate()
	add_child(game)
	for _i in 30:
		await get_tree().physics_frame
	var counts: Dictionary = {}
	var total := 0
	for node in game.find_children("*", "MeshInstance3D", true, false):
		var mesh_node := node as MeshInstance3D
		if mesh_node == null or mesh_node.mesh == null or not mesh_node.visible:
			continue
		var tris := _mesh_tris(mesh_node.mesh)
		if tris <= 0:
			continue
		total += tris
		var key := String(mesh_node.name)
		var parent := mesh_node.get_parent()
		if parent != null:
			key = String(parent.name) + "/" + key
		counts[key] = int(counts.get(key, 0)) + tris
	for node in game.find_children("*", "MultiMeshInstance3D", true, false):
		var mm := node as MultiMeshInstance3D
		if mm == null or mm.multimesh == null or not mm.visible:
			continue
		var mesh := mm.multimesh.mesh
		if mesh == null:
			continue
		var count := _mesh_tris(mesh) * mm.multimesh.instance_count
		total += count
		counts["MM:" + String(mm.name)] = int(counts.get("MM:" + String(mm.name), 0)) + count
	var keys := counts.keys()
	keys.sort_custom(_tri_desc.bind(counts))
	print("PROBE total tris=", total)
	for key in keys.slice(0, 25):
		print("PROBE ", counts[key], "  ", key)
	get_tree().quit(0)

func _mesh_tris(mesh: Mesh) -> int:
	var tris := 0
	for surface in mesh.get_surface_count():
		var arrays := mesh.surface_get_arrays(surface)
		if arrays.size() <= Mesh.PRIMITIVE_TRIANGLES:
			continue
		var idx: Variant = arrays[Mesh.ARRAY_INDEX]
		var vtx: Variant = arrays[Mesh.ARRAY_VERTEX]
		if idx is PackedInt32Array:
			tris += int((idx as PackedInt32Array).size() / 3)
		elif idx is Array:
			tris += int((idx as Array).size() / 3)
		elif vtx is PackedVector3Array:
			tris += int((vtx as PackedVector3Array).size() / 3)
		elif vtx is Array:
			tris += int((vtx as Array).size() / 3)
	return tris

func _tri_desc(a: Variant, b: Variant, counts: Dictionary) -> bool:
	return int(counts[a]) > int(counts[b])
