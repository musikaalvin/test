import os
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

import bpy
from mathutils import Matrix

import build_mech as bm

OUT_ZEPHYR = os.path.normpath(os.path.join(
	os.path.dirname(os.path.abspath(__file__)), "..", "assets", "mech", "zephyr.glb"))

WING_ROOTS = [
	(0.78, 1.12, -0.28),
	(-0.78, 1.12, -0.28),
	(0.72, 1.10, 0.52),
	(-0.72, 1.10, 0.52),
]


def part(t, m, verts, faces, local, bevel=0.0, smooth=False):
	return bm.part(t, m, verts, faces, local, bevel, smooth)


def box(t, m, size, origin, rot=None, bevel=0.02):
	return bm.box_part(t, m, size, origin, rot, bevel)


def cyl(t, m, radius, length, origin, rot=None, segments=16):
	return bm.cyl_part(t, m, radius, length, origin, rot, segments)


def sph(t, m, radius, origin, scale=None, rot=None):
	return bm.sph_part(t, m, radius, origin, scale, rot)


def cone(t, m, rb, rt, length, origin, rot=None):
	return bm.cone_part(t, m, rb, rt, length, origin, rot)


def loft(t, m, path, radii, origin=(0.0, 0.0, 0.0), rot=None, segments=16):
	return bm.loft_part(t, m, path, radii, origin, rot, segments)


def build_chassis():
	t = "chassis"
	box(t, "m_primary", (1.0, 0.78, 1.55), (0.0, 1.0, -0.12), None, 0.06)
	box(t, "m_secondary", (0.84, 0.3, 1.25), (0.0, 1.42, -0.18), bm.rot_x(-3.0), 0.05)
	box(t, "m_accent", (0.62, 0.4, 0.62), (0.0, 0.97, -1.02), bm.rot_x(-6.0), 0.05)
	box(t, "m_primary", (0.5, 0.3, 0.55), (0.0, 0.66, -0.86), bm.rot_x(8.0), 0.04)
	box(t, "m_secondary", (0.72, 0.3, 1.3), (0.0, 0.6, 0.02), None, 0.05)
	box(t, "m_accent", (0.5, 0.3, 0.7), (0.0, 1.58, -0.5), None, 0.04)
	box(t, "m_accent", (0.07, 0.34, 0.85), (0.0, 1.66, 0.32), None, 0.03)
	loft(t, "m_primary", [
		(0.0, 0.98, 0.68), (0.0, 1.04, 1.35), (0.0, 0.98, 2.0), (0.0, 0.86, 2.6),
	], [0.3, 0.24, 0.17, 0.1], segments=14)
	for ring in range(3):
		radius = (0.27, 0.2, 0.14)[ring]
		z = (1.0, 1.6, 2.15)[ring]
		y = (1.0, 1.02, 0.92)[ring]
		cyl(t, "m_secondary", radius, 0.1, (0.0, y, z), bm.rot_x(90.0), 14)
	for side in (1.0, -1.0):
		box(t, "m_secondary", (0.4, 0.5, 1.0), (side * 0.7, 1.06, 0.08), None, 0.05)
		sph(t, "m_joint", 0.2, (side * 0.76, 1.12, -0.28))
		sph(t, "m_joint", 0.16, (side * 0.72, 1.10, 0.52))
		box(t, "m_primary", (0.3, 0.24, 0.6), (side * 0.9, 1.16, -0.35), None, 0.035)
		box(t, "m_trim", (0.1, 0.1, 0.34), (side * 1.02, 1.2, -0.35), None, 0.02)
		cyl(t, "m_trim", 0.17, 0.85, (side * 0.5, 0.78, 0.45), bm.rot_x(90.0), 14)
	for sx in (0.34, -0.34):
		for sz in (0.42, -0.45):
			cyl(t, "m_recess", 0.13, 0.22, (sx, 0.44, sz), None, 12)
			cyl(t, "m_sensor", 0.09, 0.03, (sx, 0.32, sz), None, 12)
	for vent in range(3):
		box(t, "m_recess", (0.44, 0.05, 0.07),
			(0.0, 0.8 + vent * 0.14, 0.72 + vent * 0.02), None, 0.02)
	box(t, "m_primary", (0.5, 0.26, 0.66), (0.0, 1.6, -0.5), None, 0.04)
	box(t, "m_trim", (0.14, 0.16, 0.4), (0.0, 1.76, -0.5), None, 0.02)
	for side in (1.0, -1.0):
		box(t, "m_recess", (0.16, 0.3, 0.1), (side * 0.5, 1.0, -0.62), None, 0.02)
		cone(t, "m_accent", 0.07, 0.008, 0.3, (side * 0.45, 1.5, -0.9),
			bm.euler_g(-70.0, side * -18.0, 0.0))


def build_head():
	t = "head"
	box(t, "m_primary", (0.56, 0.38, 0.52), (0.0, 0.0, 0.0), None, 0.05)
	box(t, "m_accent", (0.6, 0.12, 0.34), (0.0, 0.18, -0.1), bm.rot_x(-12.0), 0.03)
	box(t, "m_recess", (0.44, 0.14, 0.12), (0.0, -0.02, -0.26), None, 0.02)
	for side in (1.0, -1.0):
		sph(t, "m_sensor", 0.15, (side * 0.2, 0.04, -0.18), scale=(1.0, 1.0, 0.75))
		cyl(t, "m_joint", 0.17, 0.05, (side * 0.2, 0.04, -0.14), bm.rot_x(90.0), 14)
		cone(t, "m_trim", 0.03, 0.006, 0.34, (side * 0.15, -0.2, -0.14),
			bm.euler_g(-40.0, side * 10.0, 0.0))
	cyl(t, "m_trim", 0.024, 0.5, (-0.18, 0.4, 0.06), bm.euler_g(8.0, 0.0, 8.0), 8)
	sph(t, "m_sensor", 0.05, (-0.22, 0.63, 0.04))


def build_wings():
	for index, root in enumerate(WING_ROOTS):
		t = "wing%d" % index
		side = 1.0 if root[0] >= 0.0 else -1.0
		span = 1.6 if index < 2 else 1.3
		chord = 0.52 if index < 2 else 0.42
		sweep = 6.0 if index < 2 else 14.0
		dihedral = bm.euler_g(0.0, -side * sweep, side * 7.0)
		mid = (side * (0.05 + span * 0.5), 0.06, 0.0)
		box(t, "m_secondary", (span, 0.05, chord), mid, dihedral, 0.02)
		spar_mid = (side * (0.05 + span * 0.48), 0.1, 0.1)
		cyl(t, "m_trim", 0.035, span, spar_mid,
			bm.euler_g(0.0, -side * sweep, 90.0 + side * 7.0), 8)
		box(t, "m_primary", (span * 0.4, 0.07, chord * 0.5),
			(side * (0.05 + span * 0.3), 0.09, -chord * 0.2), dihedral, 0.02)
		tip = (side * (0.05 + span * 0.95), 0.06 + span * 0.12, -span * 0.08)
		sph(t, "m_sensor", 0.05, tip)
		box(t, "m_accent", (0.18, 0.04, chord * 0.7),
			(side * (0.05 + span * 0.82), 0.06 + span * 0.1, 0.0), dihedral, 0.015)


def build_poses():
	empties = {}
	empties["chassis"] = Matrix.Identity(4)
	empties["head"] = bm.translate_g((0.0, 1.0, -1.12))
	for index, root in enumerate(WING_ROOTS):
		empties["wing%d" % index] = bm.translate_g(root)
	return empties


bm.construct(
	builders=[build_chassis, build_head, build_wings],
	poses_fn=build_poses,
	out_path=OUT_ZEPHYR)
