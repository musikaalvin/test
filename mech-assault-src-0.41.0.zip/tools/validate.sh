#!/usr/bin/env bash
set -uo pipefail

cd "$(dirname "$0")/.."
source tools/env.sh

BUILD_APK=0
PRESET="Android"
for arg in "$@"; do
	case "$arg" in
		--apk) BUILD_APK=1 ;;
		--preset=*) PRESET="${arg#*=}" ;;
	esac
done

FAILED=0

step() { printf "\n\033[1;36m==> %s\033[0m\n" "$1"; }
ok() { printf "\033[1;32m    %s\033[0m\n" "$1"; }
fail() { printf "\033[1;31m    %s\033[0m\n" "$1"; FAILED=1; }

step "Godot: $("$GODOT" --version 2>/dev/null | tail -1)"
step "Java: $("$JAVA_HOME/bin/java" -version 2>&1 | head -1)"
step "Android SDK: $ANDROID_HOME"

step "Version consistency"
PROJ_VER=$(grep -oP 'config/version="\K[^"]+' project.godot)
EXPORT_VER=$(grep -oP 'version/name="\K[^"]+' export_presets.cfg)
EXPORT_CODE=$(grep -oP 'version/code=\K[0-9]+' export_presets.cfg)
BUILD_VER=$(grep -oP 'BUILD_LABEL := "v\K[0-9]+\.[0-9]+\.[0-9]+' src/core/autoload/game_state.gd)
if [ -n "$PROJ_VER" ] && [ "$PROJ_VER" = "$EXPORT_VER" ] && [ "$PROJ_VER" = "$BUILD_VER" ]; then
	ok "version $PROJ_VER (code $EXPORT_CODE) matches project/export/BUILD_LABEL"
else
	fail "version mismatch: project=$PROJ_VER export=$EXPORT_VER build=$BUILD_VER — bump all three each release"
fi

step "Importing project resources"
if timeout 300 "$GODOT" --headless --path . --import 2>&1 | tee /tmp/mechassault_import.log | grep -qiE "SCRIPT ERROR|Parse Error"; then
	fail "Import reported script errors (see /tmp/mechassault_import.log)"
	grep -iE "SCRIPT ERROR|Parse Error" -A3 /tmp/mechassault_import.log | head -40
else
	ok "import clean"
fi

step "Running headless smoke test"
if timeout 240 "$GODOT" --headless --path . tools/smoke_test.tscn 2>&1 | tee /tmp/mechassault_smoke.log | tail -30; then
	if grep -q "SMOKE TEST OK" /tmp/mechassault_smoke.log; then
		ok "smoke test passed"
	else
		fail "smoke test failed (see /tmp/mechassault_smoke.log)"
	fi
else
	fail "smoke test crashed (see /tmp/mechassault_smoke.log)"
fi

if grep -qiE "SCRIPT ERROR" /tmp/mechassault_smoke.log; then
	fail "runtime script errors detected"
	grep -iE "SCRIPT ERROR" -A4 /tmp/mechassault_smoke.log | head -40
fi

if [ "$BUILD_APK" = "1" ]; then
	step "Exporting APK (preset: $PRESET)"
	mkdir -p build/android
	if timeout 900 "$GODOT" --headless --path . --export-debug "$PRESET" build/android/mech-assault-debug.apk 2>&1 \
			| tee /tmp/mechassault_export.log | tail -20; then
		if [ -f build/android/mech-assault-debug.apk ]; then
			ok "APK built: $(du -h build/android/mech-assault-debug.apk | cut -f1)"
			if grep -qiE "SCRIPT ERROR" /tmp/mechassault_export.log; then
				fail "export log contains script errors"
			fi
		else
			fail "export produced no APK"
		fi
	else
		fail "export command failed"
		grep -iE "error|failed" -A3 /tmp/mechassault_export.log | head -30
	fi
fi

printf "\n"
if [ "$FAILED" = "0" ]; then
	printf "\033[1;32mVALIDATION PASSED\033[0m\n"
else
	printf "\033[1;31mVALIDATION FAILED\033[0m\n"
fi
exit $FAILED