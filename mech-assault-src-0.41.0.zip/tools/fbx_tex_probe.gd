extends Node

func _ready() -> void:
	var scene := load("res://assets/mech_kit/Mech/SK_ISO_Mech.fbx") as PackedScene
	if scene == null:
		print("PROBE: fbx load FAILED")
		get_tree().quit(1)
		return
	var inst := scene.instantiate() as Node3D
	add_child(inst)
	var meshes := inst.find_children("*", "MeshInstance3D", true, false)
	print("PROBE: meshes=", meshes.size())
	for m in meshes:
		var mi := m as MeshInstance3D
		if mi == null or mi.mesh == null:
			continue
		for s in mi.mesh.get_surface_count():
			var mat := mi.get_active_material(s)
			if mat == null:
				print("  ", mi.name, " surf", s, ": NULL material")
				continue
			var albedo_path := "-"
			var tint := Color(1,1,1)
			if mat is StandardMaterial3D:
				var std := mat as StandardMaterial3D
				if std.albedo_texture != null:
					albedo_path = str(std.albedo_texture.resource_path)
				tint = std.albedo_color
			print("  ", mi.name, " surf", s, ": ", mat.get_class(),
				" albedo_tex=", albedo_path, " tint=", tint)
	get_tree().quit(0)
