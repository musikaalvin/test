"""Build assets/mech/princeps.glb — PRAETOR "Princeps" bipedal assault titan.

Original design sharing broad genre conventions with military assault titans:
long digitigrade legs, compact angular torso, wide clavicle deck carrying twin
quad-barrel shoulder cannon pods, hip sponsons for side weapons, low sensor
head. Built at TITAN final size (no runtime scale); bone lengths must match
TitanRig (coxa 0.48 / thigh 1.875 / shin 2.175) and the head node sits at
(0, 2.4, -0.78).

Run: blender -b --python tools/build_princeps.py
"""
import os
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

import bpy
from mathutils import Matrix

import build_mech as bm

OUT_PRINCEPS = os.environ.get("MECH_GLB_OUT") or os.path.normpath(os.path.join(
	os.path.dirname(os.path.abspath(__file__)), "..", "assets", "mech", "princeps.glb"))

# Bulk factor: every dimension below is authored at 1.0 and multiplied here, so
# growing the titan is ONE number (must match TitanRig.BULK on the Godot side).
BULK = 1.25

HIP_POS = [(0.78 * BULK, -0.15 * BULK, 0.0), (-0.78 * BULK, -0.15 * BULK, 0.0)]
HIP_OUT = [(1.0, 0.0, 0.0), (-1.0, 0.0, 0.0)]

THIGH = 1.875 * BULK
SHIN = 2.175 * BULK
COXA = 0.48 * BULK
HEAD_POSE = (0.0, 2.4 * BULK, -0.78 * BULK)

# Weapon socket reference (TitanRig._build_hardpoints) — pods wrap these.
ALPHA_SOCKET = (1.08 * BULK, 2.16 * BULK, -0.3 * BULK)
BETA_SOCKET = (1.65 * BULK, 0.15 * BULK, 0.3 * BULK)


def _v3(value):
	return tuple(c * BULK for c in value)


def part(t, m, verts, faces, local, bevel=0.0, smooth=False):
	return bm.part(t, m, verts, faces, local, bevel * BULK, smooth)


def box(t, m, size, origin, rot=None, bevel=0.02):
	return bm.box_part(t, m, _v3(size), _v3(origin), rot, bevel * BULK)


def cyl(t, m, radius, length, origin, rot=None, segments=16):
	return bm.cyl_part(t, m, radius * BULK, length * BULK, _v3(origin), rot, segments)


def sph(t, m, radius, origin, scale=None, rot=None):
	return bm.sph_part(t, m, radius * BULK, _v3(origin), scale, rot)


def cone(t, m, rb, rt, length, origin, rot=None):
	return bm.cone_part(t, m, rb * BULK, rt * BULK, length * BULK, _v3(origin), rot)


def loft(t, m, path, radii, origin=(0.0, 0.0, 0.0), rot=None, segments=16):
	return bm.loft_part(t, m, [_v3(p) for p in path],
			[r * BULK for r in radii], _v3(origin), rot, segments)


def build_chassis():
	t = "chassis"
	# --- pelvis / waist -------------------------------------------------
	box(t, "m_primary", (1.55, 0.6, 1.15), (0.0, 0.1, 0.05), None, 0.06)
	box(t, "m_secondary", (1.78, 0.3, 1.3), (0.0, -0.16, 0.05), None, 0.05)
	box(t, "m_secondary", (0.95, 0.55, 0.85), (0.0, 0.62, 0.0), None, 0.04)
	box(t, "m_joint", (1.2, 0.22, 1.0), (0.0, 0.4, 0.0), None, 0.03)
	# --- chest ----------------------------------------------------------
	box(t, "m_primary", (2.0, 1.15, 1.45), (0.0, 1.4, -0.05), None, 0.07)
	box(t, "m_secondary", (1.7, 0.5, 1.2), (0.0, 1.9, -0.05), None, 0.05)
	# maroon-class prow (accent plate over the glacis)
	box(t, "m_accent", (1.35, 0.78, 0.5), (0.0, 1.45, -0.85), bm.rot_x(-24.0), 0.04)
	box(t, "m_secondary", (1.1, 0.42, 0.45), (0.0, 0.95, -0.78), bm.rot_x(-10.0), 0.04)
	box(t, "m_trim", (0.8, 0.1, 0.3), (0.0, 1.86, -0.78), bm.rot_x(-24.0), 0.02)
	# --- wide clavicle deck (carries the shoulder pods) -----------------
	box(t, "m_primary", (2.7, 0.3, 1.5), (0.0, 2.05, -0.05), None, 0.05)
	box(t, "m_secondary", (2.2, 0.16, 1.1), (0.0, 2.2, -0.02), None, 0.03)
	# --- rear pack + vents + exhausts -----------------------------------
	box(t, "m_secondary", (1.5, 1.0, 0.6), (0.0, 1.45, 0.9), None, 0.05)
	for vent in range(3):
		box(t, "m_recess", (0.9, 0.08, 0.1),
			(0.0, 1.15 + vent * 0.2, 1.22), None, 0.008)
	for side in (1.0, -1.0):
		cyl(t, "m_trim", 0.19, 1.0, (side * 0.45, 1.9, 1.15), bm.rot_x(28.0), 12)
		cyl(t, "m_recess", 0.22, 0.16, (side * 0.5, 2.32, 1.38), bm.rot_x(28.0), 12)
		cyl(t, "m_sensor", 0.05, 0.1, (side * 0.5, 2.36, 1.42), bm.rot_x(28.0), 8)
	# --- shoulder cannon pods (alpha sockets at ±1.08, 2.16, -0.3) ------
	for side in (1.0, -1.0):
		box(t, "m_secondary", (0.98, 0.66, 1.1),
			(side * 1.12, 2.22, -0.16), None, 0.05)
		box(t, "m_accent", (0.82, 0.14, 0.9),
			(side * 1.12, 2.58, -0.16), None, 0.03)
		box(t, "m_primary", (1.04, 0.4, 0.5),
			(side * 1.12, 2.2, -0.55), None, 0.04)
		cyl(t, "m_recess", 0.28, 0.3, (side * 1.08, 2.16, -0.78),
			bm.rot_x(90.0), 16)
		cyl(t, "m_trim", 0.32, 0.1, (side * 1.08, 2.16, -0.66),
			bm.rot_x(90.0), 16)
		box(t, "m_trim", (0.1, 0.52, 0.92),
			(side * 1.63, 2.2, -0.14), None, 0.02)
		box(t, "m_joint", (0.34, 0.26, 0.55),
			(side * 0.72, 2.1, 0.38), None, 0.03)
		# quad-barrel suggestion ribs on the pod face (barrels are WeaponMount)
		for dx, dy in ((-0.16, 0.14), (0.16, 0.14), (-0.16, -0.14), (0.16, -0.14)):
			cyl(t, "m_joint", 0.07, 0.16,
				(side * 1.08 + dx, 2.16 + dy, -0.74), bm.rot_x(90.0), 8)
	# --- hip sponsons (beta sockets at ±1.65, 0.15, 0.3) ----------------
	for side in (1.0, -1.0):
		sph(t, "m_joint", 0.34, (side * 0.95, -0.05, 0.05))
		box(t, "m_secondary", (0.72, 0.68, 1.18),
			(side * 1.5, 0.1, 0.25), None, 0.05)
		box(t, "m_primary", (0.6, 0.4, 0.6),
			(side * 1.5, 0.14, -0.28), None, 0.04)
		cyl(t, "m_recess", 0.24, 0.26, (side * 1.65, 0.15, -0.55),
			bm.rot_x(90.0), 14)
		box(t, "m_trim", (0.08, 0.44, 0.8),
			(side * 1.88, 0.1, 0.2), None, 0.02)
	# --- belly + core ---------------------------------------------------
	box(t, "m_secondary", (1.4, 0.4, 1.2), (0.0, -0.3, 0.05), None, 0.05)
	box(t, "m_primary", (0.7, 0.34, 0.9), (0.0, -0.4, -0.05), None, 0.04)
	sph(t, "m_sensor", 0.22, (0.0, -0.36, -0.5))
	# --- dorsal spine (replaces the old procedural crown) ----------------
	spine = [(0.0, 2.3, 0.5, 0.55, 0.24, 0.55),
			 (0.0, 2.45, 0.82, 0.46, 0.2, 0.46),
			 (0.0, 2.56, 1.1, 0.36, 0.16, 0.38)]
	for index, (sx, sy, sz, w, h, d) in enumerate(spine):
		box(t, "m_accent" if index % 2 == 0 else "m_primary",
			(w, h, d), (sx, sy, sz), bm.rot_x(-12.0), 0.03)
	for side in (1.0, -1.0):
		cyl(t, "m_trim", 0.07, 1.1, (side * 0.52, 2.6, 0.55),
			bm.euler_g(6.0, 0.0, side * -6.0), 8)
		sph(t, "m_sensor", 0.09, (side * 0.56, 3.14, 0.5))
	# --- rear thruster nozzles (flames come from TitanRig) --------------
	for side in (1.0, -1.0):
		cyl(t, "m_recess", 0.24, 0.55, (side * 0.66, 1.11, 1.05),
			bm.rot_x(-20.0), 12)
		cyl(t, "m_sensor", 0.16, 0.1, (side * 0.66, 1.02, 1.19),
			bm.rot_x(-20.0), 10)


def build_head():
	t = "head"
	box(t, "m_primary", (0.85, 0.4, 0.65), (0.0, 0.0, 0.0), None, 0.04)
	box(t, "m_accent", (0.95, 0.14, 0.5), (0.0, 0.2, -0.1), bm.rot_x(-14.0), 0.03)
	box(t, "m_recess", (0.66, 0.2, 0.16), (0.0, -0.02, -0.32), None, 0.015)
	box(t, "m_sensor", (0.5, 0.07, 0.06), (0.0, 0.03, -0.38), None, 0.006)
	sph(t, "m_sensor", 0.06, (0.18, 0.03, -0.38), scale=(1.0, 0.9, 0.9))
	sph(t, "m_sensor", 0.06, (-0.18, 0.03, -0.38), scale=(1.0, 0.9, 0.9))
	box(t, "m_secondary", (0.6, 0.16, 0.4), (0.0, -0.24, -0.08),
		bm.rot_x(12.0), 0.03)
	for side in (1.0, -1.0):
		box(t, "m_secondary", (0.17, 0.3, 0.46), (side * 0.45, -0.02, -0.02),
			bm.rot_z(side * -10.0), 0.025)
	sph(t, "m_joint", 0.11, (0.0, 0.24, 0.06))
	cyl(t, "m_trim", 0.03, 0.5, (-0.28, 0.45, 0.08), bm.euler_g(8.0, 8.0, 0.0), 8)
	sph(t, "m_sensor", 0.05, (-0.32, 0.69, 0.05))


def build_legs():
	for index in range(2):
		c = "l%dc" % index
		sph(c, "m_joint", 0.31, (0.0, 0.0, 0.0))
		loft(c, "m_trim", [(0.0, 0.0, 0.0), (0.0, 0.24, 0.0), (0.0, COXA, 0.0)],
			[0.25, 0.22, 0.185], segments=14)
		sph(c, "m_primary", 1.0, (0.0, 0.26, 0.0), scale=(0.255, 0.24, 0.315))
		u = "l%du" % index
		loft(u, "m_primary", [
			(0.0, 0.0, 0.0), (0.03, 0.63, 0.045), (0.015, 1.26, 0.015),
			(0.0, THIGH, 0.0),
		], [0.255, 0.315, 0.255, 0.18], segments=18)
		# heavy thigh armour plate (Princeps plating)
		box(u, "m_secondary", (0.52, 0.95, 0.22), (0.015, 0.78, -0.27),
			bm.rot_x(-4.0), 0.035)
		box(u, "m_accent", (0.4, 0.3, 0.14), (0.015, 1.2, -0.32),
			bm.rot_x(-6.0), 0.025)
		sph(u, "m_accent", 1.0, (0.015, 0.78, 0.075), scale=(0.21, 0.48, 0.15))
		cyl(u, "m_accent", 0.315, 0.12, (0.0, 0.54, 0.0), None, 18)
		for side in (1.0, -1.0):
			cyl(u, "m_trim", 0.068, 0.975, (side * 0.3, 0.66, 0.0), None, 10)
			cyl(u, "m_joint", 0.042, 0.6, (side * 0.3, 1.32, 0.0), None, 8)
		sph(u, "m_joint", 0.3, (0.0, THIGH, 0.0))
		cyl(u, "m_accent", 0.195, 0.15, (0.0, THIGH, 0.0), bm.rot_x(90.0), 14)
		l = "l%dl" % index
		loft(l, "m_primary", [
			(0.0, 0.0, 0.0), (0.0, 0.72, -0.03), (0.0, 1.44, -0.015),
			(0.0, SHIN, 0.0),
		], [0.218, 0.24, 0.188, 0.143], segments=16)
		box(l, "m_secondary", (0.42, 0.9, 0.2), (0.0, 0.8, -0.22), None, 0.03)
		sph(l, "m_secondary", 1.0, (0.0, 0.83, -0.11), scale=(0.14, 0.48, 0.13))
		cyl(l, "m_accent", 0.24, 0.1, (0.0, 0.68, 0.0), None, 16)
		for side in (1.0, -1.0):
			cyl(l, "m_trim", 0.057, 0.975, (side * 0.21, 0.83, 0.045), None, 10)
		sph(l, "m_joint", 0.19, (0.0, SHIN, 0.0))
		f = "l%df" % index
		sph(f, "m_joint", 0.15, (0.0, 0.135, 0.0))
		sph(f, "m_recess", 1.0, (0.0, -0.05, 0.0), scale=(0.3, 0.09, 0.39))
		sph(f, "m_joint", 1.0, (0.0, 0.0, 0.03), scale=(0.24, 0.07, 0.3))
		for cx in (-0.195, 0.0, 0.195):
			yaw = -18.0 if cx > 0.0 else (18.0 if cx < 0.0 else 0.0)
			cone(f, "m_joint", 0.09, 0.008, 0.45, (cx, -0.02, -0.405),
				bm.euler_g(-85.0, yaw, 0.0))
		cone(f, "m_joint", 0.08, 0.008, 0.36, (0.0, -0.03, 0.405), bm.rot_x(95.0))


def build_poses():
	empties = {}
	empties["chassis"] = Matrix.Identity(4)
	empties["head"] = bm.translate_g(HEAD_POSE)
	for index in range(2):
		pose = bm.leg_pose(HIP_POS[index], HIP_OUT[index])
		empties["l%dc" % index] = pose["coxa"]
		empties["l%du" % index] = pose["upper"]
		empties["l%dl" % index] = pose["lower"]
		empties["l%df" % index] = pose["foot"]
	return empties


bm.construct(
	builders=[build_chassis, build_head, build_legs],
	poses_fn=build_poses,
	out_path=OUT_PRINCEPS)
