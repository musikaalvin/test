extends SceneTree

const CLIPS := [
	"A_ISO_Mech_Idle_01", "A_ISO_Mech_WalkForward_01", "A_ISO_Mech_WalkBackward_01",
	"A_ISO_Mech_Walk_L_01", "A_ISO_Mech_Walk_R_01", "A_ISO_Mech_Landing_01",
	"A_ISO_Mech_Death_01",
]

func _init() -> void:
	for clip_name in CLIPS:
		var scene := load("res://assets/mech_kit/Mech/Animations/%s.fbx" % clip_name) as PackedScene
		if scene == null:
			print("ANIMPROBE ", clip_name, " LOAD FAILED")
			continue
		var inst := scene.instantiate() as Node3D
		print("ANIMPROBE ", clip_name, " root=", inst.name, " class=", inst.get_class())
		_dump(inst, 0, 3)
		for node in inst.find_children("*", "AnimationPlayer", true, false):
			var ap := node as AnimationPlayer
			print("ANIMPROBE   AP path=", inst.get_path_to(node), " libs=",
					ap.get_animation_library_list())
			var library := ap.get_animation_library("")
			for lib in library.get_animation_list():
				var anim: Animation = library.get_animation(StringName(lib))
				var loop := "none"
				if anim.loop_mode == Animation.LOOP_LINEAR:
					loop = "linear"
				print("ANIMPROBE   clip=", lib, " len=", anim.length,
						" tracks=", anim.get_track_count(), " loop=", loop)
				var shown := 0
				for t in anim.get_track_count():
					if shown >= 8:
						break
					print("ANIMPROBE     track ", t, " path=", anim.track_get_path(t),
							" type=", anim.track_get_type(t))
					shown += 1
		var meshes := inst.find_children("*", "MeshInstance3D", true, false)
		print("ANIMPROBE   meshinstances=", meshes.size())
		inst.free()
	quit(0)

func _dump(node: Node, depth: int, max_depth: int) -> void:
	var indent := ""
	for i in depth:
		indent += "  "
	print(indent, node.get_class(), " ", node.name)
	if depth >= max_depth:
		return
	for child in node.get_children():
		_dump(child, depth + 1, max_depth)
