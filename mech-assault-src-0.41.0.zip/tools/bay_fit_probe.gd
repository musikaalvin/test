extends Node

# Reproduces the hangar bay camera fit at the DEVICE canvas size
# (1560x720 — window/stretch/aspect=expand at 2730x1260) and prints where the
# camera ends up relative to the room geometry, plus the raw unprojected pad
# positions so they can be compared with the pad chips in the device
# screenshot (device px / 1.75 = canvas px).
#
# Run: "$GODOT" --headless --path . tools/bay_fit_probe.tscn

const DEVICE_VIEW := Vector2i(1560, 720)

var _menu: Control = null
var _screen: Control = null

func _ready() -> void:
	var scene := load("res://scenes/main_menu.tscn") as PackedScene
	if scene == null:
		print("PROBE: main_menu.tscn load FAILED")
		get_tree().quit(1)
		return
	_menu = scene.instantiate() as Control
	add_child(_menu)
	for frame in 12:
		await get_tree().process_frame
	var ui := _menu.get_node_or_null("UI")
	if ui == null:
		print("PROBE: UI node missing")
		get_tree().quit(1)
		return
	_screen = ui.call("screen", &"hangar")
	if _screen == null:
		print("PROBE: hangar screen missing")
		get_tree().quit(1)
		return

	var saved_robot: StringName = GameState.selected_robot
	for robot_id: StringName in [GameState.ROBOT_RAVAGER, GameState.ROBOT_SCARAB]:
		GameState.selected_robot = robot_id
		_screen.call("rebuild_bay") if _screen.has_method("rebuild_bay") else null
		for frame in 6:
			await get_tree().process_frame
		_probe_size("baseline-headless", Vector2i.ZERO)
		_probe_size("device-1560x720", DEVICE_VIEW)
	GameState.selected_robot = saved_robot
	print("PROBE: done")
	get_tree().quit(0)

func _probe_size(tag: String, force: Vector2i) -> void:
	var viewport: SubViewport = _screen.get("_bay_viewport")
	var camera: Camera3D = _screen.get("_camera")
	var driver: Node = _screen.get("_driver")
	if viewport == null or camera == null or driver == null:
		print("PROBE[%s]: bay parts missing vp=%s cam=%s drv=%s" % [
				tag, str(viewport != null), str(camera != null), str(driver != null)])
		return
	if force.x > 0:
		viewport.size = force
	_screen.set("_fit_dirty", true)
	_screen.call("_process", 0.016)
	_screen.call("_process", 0.016)

	var view := Vector2(viewport.size)
	var bounds: AABB = driver.call("selected_bounds")
	var assignment: Array = driver.get("_assignment")
	print("=== PROBE[%s] robot=%s ===" % [tag, String(GameState.selected_robot)])
	print("  view=%.0fx%.0f overlay=%.0fx%.0f update=%d" % [
			view.x, view.y,
			Vector2(_screen.get("_overlay").size).x,
			Vector2(_screen.get("_overlay").size).y,
			viewport.render_target_update_mode])
	print("  safe=%s bounds pos=%s size=%s center=%s" % [
			str(_screen.call("_safe_rect", view)), str(bounds.position),
			str(bounds.size), str(bounds.get_center())])
	print("  fit_d=%.2f view_d=%.2f zoom=%.2f" % [
			float(_screen.get("_fit_distance")), float(_screen.get("_view_distance")),
			float(_screen.get("_zoom"))])
	print("  camera pos=%s fwd=%s" % [
			str(camera.global_position), str(-camera.global_transform.basis.z)])

	# Analytic room geometry (hangar_pose_driver._build_room).
	var rear := AABB(Vector3(-37.0, 0.0, -25.4), Vector3(74.0, 11.0, 0.8))
	var side_l := AABB(Vector3(-35.4, 0.0, -29.0), Vector3(0.8, 9.0, 46.0))
	var side_r := AABB(Vector3(34.6, 0.0, -29.0), Vector3(0.8, 9.0, 46.0))
	var floor_box := AABB(Vector3(-37.0, -1.0, -37.0), Vector3(74.0, 1.0, 58.0))
	var p := camera.global_position
	print("  camera inside: rear_wall=%s side_l=%s side_r=%s floor=%s" % [
			str(rear.has_point(p)), str(side_l.has_point(p)),
			str(side_r.has_point(p)), str(floor_box.has_point(p))])
	print("  camera z=%.2f (wall front -24.60, room needs z > -24.60)" % p.z)

	# Raw unprojected pad anchor + the same world point the pins use.
	var slots: Array = HangarSlots.SLOTS
	for index in slots.size():
		var slot: Dictionary = slots[index]
		if index >= assignment.size() or String(assignment[index]).is_empty():
			continue
		var world := Vector3(float(slot["pos"].x), float(slot["top"]) + 0.14,
				float(slot["pos"].z))
		var toward := Vector3(p.x - world.x, 0.0, p.z - world.z)
		if toward.length_squared() > 0.04:
			world += toward.normalized() * (float(slot["radius"]) * 0.6)
		var behind := camera.is_position_behind(world)
		var point: Vector2 = Vector2.ZERO if behind else camera.unproject_position(world)
		print("  pad[%d] %s world=%s behind=%s unproject=(%.0f,%.0f)" % [
				index, String(assignment[index]), str(world), str(behind),
				point.x, point.y])

	# Where does the mech itself project?
	var center := bounds.get_center()
	print("  bounds center unproject=(%.0f,%.0f) behind=%s  safe=%s" % [
			camera.unproject_position(center).x, camera.unproject_position(center).y,
			str(camera.is_position_behind(center)), str(_screen.call("_safe_rect", view))])
	var corners: Array = []
	for i in 8:
		corners.append(Vector3(
				bounds.position.x + (bounds.size.x if (i & 1) != 0 else 0.0),
				bounds.position.y + (bounds.size.y if (i & 2) != 0 else 0.0),
				bounds.position.z + (bounds.size.z if (i & 4) != 0 else 0.0)))
	var rect: Rect2 = _screen.call("_project_rect", corners)
	print("  bounds projected rect=%s" % str(rect))

	# What the camera would see toward the rear wall strips (emissive bands).
	var strip_hits := 0
	for strip_y in [2.4, 6.2, 9.4]:
		var strip := Vector3(0.0, strip_y, -24.55)
		if not camera.is_position_behind(strip):
			strip_hits += 1
	print("  rear strips in front of camera: %d/3" % strip_hits)
