# Exports normalized weapon meshes from the DeadProject .blend files to GLB.
# Usage: blender -b <file.blend> --python tools/export_weapons.py -- <out_dir> <map_json>
# The map is a JSON object {object_name: output_basename}; every other mesh is skipped.
import bpy
import json
import sys
import os

from mathutils import Matrix

argv = sys.argv[sys.argv.index("--") + 1:]
out_dir = argv[0]
export_map = json.loads(argv[1])
mode = argv[2] if len(argv) > 2 else "norm"
os.makedirs(out_dir, exist_ok=True)


def normalize_and_export(obj, out_path):
    bpy.ops.object.select_all(action="DESELECT")
    obj.select_set(True)
    bpy.context.view_layer.objects.active = obj
    bpy.ops.object.transform_apply(location=True, rotation=True, scale=True)

    dims = list(obj.dimensions)
    if max(dims) <= 0.0:
        print("SKIP degenerate", obj.name)
        return

    if mode == "prop":
        # Keep Blender orientation (glTF exporter maps Z-up -> Y-up),
        # scale to unit max size, origin at bottom centre.
        factor = 1.0 / max(dims)
        obj.data.transform(Matrix.Diagonal((factor, factor, factor, 1.0)))
        obj.data.update()
        bpy.context.view_layer.objects.active = obj
        bb = [obj.matrix_world @ v.co for v in obj.data.vertices]
        min_z = min(v.z for v in bb)
        cx = (min(v.x for v in bb) + max(v.x for v in bb)) * 0.5
        cy = (min(v.y for v in bb) + max(v.y for v in bb)) * 0.5
        obj.data.transform(Matrix.Translation((-cx, -cy, -min_z)))
        obj.data.update()
    else:
        order = sorted(range(3), key=lambda i: -dims[i])  # long, mid, short
        # Target basis: X = longest (barrel), Z = mid (up), Y = short.
        rows = [
            [0.0, 0.0, 0.0],
            [0.0, 0.0, 0.0],
            [0.0, 0.0, 0.0],
        ]
        rows[0][order[0]] = 1.0
        rows[1][order[2]] = 1.0
        rows[2][order[1]] = 1.0
        m = Matrix(rows)
        if m.determinant() < 0.0:
            rows[1] = [-v for v in rows[1]]
            m = Matrix(rows)
        obj.data.transform(m.to_4x4())
        obj.data.update()
        bpy.context.view_layer.objects.active = obj
        bpy.ops.object.origin_set(type="ORIGIN_GEOMETRY", center="BOUNDS")

    bpy.ops.export_scene.gltf(
        filepath=out_path,
        export_format="GLB",
        use_selection=True,
        export_yup=True,
        export_apply=True,
        export_materials="EXPORT",
    )
    print("EXPORTED", obj.name, "->", out_path)


for obj_name, base in export_map.items():
    obj = bpy.data.objects.get(obj_name)
    if obj is None or obj.type != "MESH":
        print("MISSING", obj_name)
        continue
    normalize_and_export(obj, os.path.join(out_dir, base + ".glb"))
