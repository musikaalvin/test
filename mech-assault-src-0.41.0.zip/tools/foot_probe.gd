extends Node

const SETTLE_FRAMES := 75

var _game: Node3D
var _frames: int = 0

func _ready() -> void:
	for arg in OS.get_cmdline_user_args():
		if arg == "vortex":
			GameState.selected_robot = &"VORTEX"
	_game = (load("res://scenes/game.tscn") as PackedScene).instantiate() as Node3D
	add_child(_game)

func _physics_process(_delta: float) -> void:
	_frames += 1
	if _frames >= SETTLE_FRAMES:
		_probe()
		get_tree().quit(0)

func _probe() -> void:
	var player := _game.get_node_or_null("Player") as PlayerRobot
	if player == null or player.rig == null:
		printerr("foot_probe: no player rig")
		return
	var clearance: float = PlayerRobot.GROUND_CLEARANCE
	print("foot_probe: player.y=%.4f clearance=%.3f legs=%d on_floor=%s airborne=%.3f" % [
			player.global_position.y, clearance, player.rig.leg_units.size(),
			str(player.is_on_floor()), player._airborne_time])
	var probe := player._probe_feet()
	for point in probe:
		print("  probe_point y=%.4f" % point.y)
	for index in player.rig.leg_units.size():
		var leg := player.rig.leg_units[index]
		var foot := leg.get_node_or_null("Foot") as Node3D
		if foot == null:
			continue
		var min_local := 0.0
		var bottom_name := "-"
		var first := true
		for child in foot.get_children():
			if not (child is MeshInstance3D):
				continue
			var mesh := (child as MeshInstance3D).mesh
			if mesh == null:
				continue
			var aabb := mesh.get_aabb()
			var bottom := _aabb_min_y(aabb, (child as MeshInstance3D).transform)
			if first or bottom < min_local:
				min_local = bottom
				bottom_name = String(child.name)
				first = false
		var suggested := -clearance - min_local
		print("  leg[%d] foot_world=%s node=%s min_local=%.4f (%s) world_bottom=%.4f suggested_DROP=%.4f" % [
				index, str(leg.foot_position()), str(foot.global_position), min_local,
				bottom_name, foot.global_position.y + min_local, suggested])

func _aabb_min_y(aabb: AABB, xf: Transform3D) -> float:
	var min_y := INF
	for corner in 8:
		var p := Vector3(
				aabb.position.x if (corner & 1) == 0 else aabb.end.x,
				aabb.position.y if (corner & 2) == 0 else aabb.end.y,
				aabb.position.z if (corner & 4) == 0 else aabb.end.z)
		min_y = minf(min_y, (xf * p).y)
	return min_y
