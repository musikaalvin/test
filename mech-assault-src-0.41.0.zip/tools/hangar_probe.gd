extends Node

# Reports the hangar 3D preview's weapon mounts per robot: how many hardpoints
# the rig builds, which of them actually carry a weapon, and what the loadout
# says.  Run: "$GODOT" --headless --path . tools/hangar_probe.tscn

var _driver: Node3D = null

func _ready() -> void:
	var driver_script := load("res://src/ui/hangar_pose_driver.gd") as GDScript
	if driver_script == null:
		print("PROBE: hangar_pose_driver load FAILED")
		get_tree().quit(1)
		return
	for robot_id in GameState.ROBOT_DEFS.keys():
		await _probe_robot(driver_script, robot_id as StringName)
	print("PROBE: done")
	get_tree().quit(0)

func _probe_robot(driver_script: GDScript, robot_id: StringName) -> void:
	GameState.selected_robot = robot_id
	var loadout: Array = GameState.equipped_items(robot_id)
	var equipped: Array[String] = []
	for entry in loadout:
		equipped.append(String(entry))
	_driver = driver_script.new() as Node3D
	_driver.name = "HangarProbeDriver"
	add_child(_driver)
	for frame in 6:
		await get_tree().physics_frame
	var rig: RobotRig = _driver.get("rig") as RobotRig
	print("ROBOT %s  slots=%d filled=%d loadout=%s" % [
			String(robot_id), GameState.slot_count(robot_id),
			GameState.filled_slots(robot_id), str(equipped)])
	if rig == null:
		print("  RIG NULL")
	else:
		var script := rig.get_script() as Script
		print("  rig=%s script=%s legs=%d tail=%s wings=%d mounts=%d hardpoints=%d" % [
				rig.get_class(), script.resource_path if script != null else "none",
				rig.leg_units.size(), str(rig.get("tail") != null and rig.tail != null),
				(rig.get("wings") as Array).size() if rig.get("wings") != null else 0,
				rig.mounts.size(), rig.hardpoint_count()])
		var bodies := rig.find_children("*", "MeshInstance3D", true, false)
		print("  meshes=%d glb_parts=%d" % [bodies.size(),
				rig.find_children("chassis__*", "MeshInstance3D", true, false).size()])
		var hull := _aabb(rig.get_node_or_null("Chassis") as Node3D, rig)
		print("  hull AABB x[%.2f,%.2f] y[%.2f,%.2f] z[%.2f,%.2f]" % [
				hull.position.x, hull.end.x, hull.position.y, hull.end.y,
				hull.position.z, hull.end.z])
		for index in rig.mounts.size():
			var mount := rig.mounts[index]
			var box := _aabb(mount, rig)
			var inside := box.position.x < hull.end.x and box.end.x > hull.position.x \
					and box.position.y < hull.end.y and box.end.y > hull.position.y \
					and box.position.z < hull.end.z and box.end.z > hull.position.z
			print("   [%d] origin=%s  AABB x[%.2f,%.2f] y[%.2f,%.2f] z[%.2f,%.2f] overlap_hull=%s" % [
					index, str(mount.position), box.position.x, box.end.x,
					box.position.y, box.end.y, box.position.z, box.end.z, str(inside)])
		for index in rig.mounts.size():
			var mount := rig.mounts[index]
			var meshes := mount.find_children("*", "MeshInstance3D", true, false)
			var label := "EMPTY"
			if mount.data != null:
				label = String(mount.data.item_id) if "item_id" in mount.data \
						else String(mount.data.name)
			print("   [%d] %s  data=%s  visuals=%d  pos=%s" % [
					index, mount.name, label, meshes.size(),
					str(mount.global_position.round())])
	# did the hangar slot UI agree with what the rig mounted?
	var missing := 0
	for index in equipped.size():
		if not equipped[index].is_empty() and index < rig.mounts.size() \
				and rig.mounts[index].data == null:
			missing += 1
	print("  MISMATCH: %d equipped slot(s) with no weapon on the rig" % missing)
	_driver.queue_free()
	_driver = null
	await get_tree().process_frame

# World-space AABB of every MeshInstance3D under `node`, expressed in `space`.
func _aabb(node: Node, space: Node3D) -> AABB:
	var box := AABB()
	var first := true
	if node == null:
		return AABB(Vector3.ZERO, Vector3.ZERO)
	for mesh_node in node.find_children("*", "MeshInstance3D", true, false):
		var instance := mesh_node as MeshInstance3D
		if instance == null or instance.mesh == null or not instance.is_visible_in_tree():
			continue
		var local := instance.mesh.get_aabb()
		var xf := space.global_transform.affine_inverse() * instance.global_transform
		var corners := PackedVector3Array()
		for corner in [
				Vector3(0, 0, 0), Vector3(1, 0, 0), Vector3(0, 1, 0), Vector3(1, 1, 0),
				Vector3(0, 0, 1), Vector3(1, 0, 1), Vector3(0, 1, 1), Vector3(1, 1, 1)]:
			corners.append(xf * (local.position + local.size * corner))
		for corner in corners:
			if first:
				box = AABB(corner, Vector3.ZERO)
				first = false
			else:
				box = box.expand(corner)
	return box
