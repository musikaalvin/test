extends Node

const SETTLE_FRAMES := 75
const OUTPUT_PATH := "res://build/mesh_dump.json"
const MAX_TRIANGLES := 700000

var _game: Node
var _frames: int = 0
var _hangar: bool = false
var _hangar_focus: Node = null

func _ready() -> void:
	for arg in OS.get_cmdline_user_args():
		if arg == "vortex":
			GameState.selected_robot = &"VORTEX"
		elif arg == "rampart":
			GameState.selected_robot = &"RAMPART"
		elif arg == "titan" or arg == "praetor":
			GameState.selected_robot = &"PRAETOR"
		elif arg == "citadel":
			GameState.selected_robot = &"CITADEL"
		elif arg == "ravager":
			GameState.selected_robot = &"RAVAGER"
		elif arg == "hangar":
			_hangar = true
		elif arg == "allrobots":
			# QA only (in-memory, never saved): stage the full roster so the
			# multi-robot bay can be judged in renders.
			for robot_id in GameState.ROBOT_ORDER:
				if not GameState.owns_robot(robot_id):
					GameState.owned_robots.append(robot_id)
	DirAccess.make_dir_recursive_absolute(ProjectSettings.globalize_path("res://build"))
	if _hangar:
		# The real menu scene: the preview camera runs the actual orbit-fit,
		# so the rendered view matches what the player sees.
		_game = (load("res://scenes/main_menu.tscn") as PackedScene).instantiate()
		add_child(_game)
		_hangar_focus = _game.find_child("HangarPoseDriver", true, false)
		print("dump_mesh: hangar bay of %s" % String(GameState.selected_robot))
	else:
		_game = (load("res://scenes/game.tscn") as PackedScene).instantiate() as Node3D
		add_child(_game)

func _physics_process(_delta: float) -> void:
	_frames += 1
	if _frames >= SETTLE_FRAMES:
		_dump()
		get_tree().quit(0)

func _dump() -> void:
	var vertices: Array[float] = []
	var colors: Array[float] = []
	var emissives: Array[float] = []
	_collect(_game, vertices, colors, emissives)
	var camera: Camera3D = null
	var focus: Node3D = null
	if _hangar:
		camera = _game.find_child("Camera", true, false) as Camera3D
		focus = _hangar_focus as Node3D
	else:
		camera = _game.get_node_or_null("CameraRig/SpringArm3D/Camera3D") as Camera3D
		focus = _game.get_node_or_null("Player") as Node3D
	var focus_aabb: Array[float] = []
	if focus != null:
		var box := _subtree_aabb(focus)
		if box.size.x > 0.0:
			focus_aabb = [
				snappedf(box.position.x, 0.001), snappedf(box.position.y, 0.001),
				snappedf(box.position.z, 0.001), snappedf(box.end.x, 0.001),
				snappedf(box.end.y, 0.001), snappedf(box.end.z, 0.001),
			]
	var data := {
		"vertices": _rounded(vertices),
		"colors": _rounded(colors),
		"emissives": _rounded(emissives),
		"camera": _transform_values(camera.global_transform) if camera != null else [],
		"player": _transform_values(focus.global_transform) if focus != null else [],
		"player_aabb": focus_aabb,
	}
	var file := FileAccess.open(OUTPUT_PATH, FileAccess.WRITE)
	if file == null:
		printerr("dump_mesh: cannot open %s" % OUTPUT_PATH)
		return
	file.store_string(JSON.stringify(data))
	file.close()
	print("dump_mesh: %d triangles written to %s" % [vertices.size() / 9, OUTPUT_PATH])

func _rounded(values: Array[float]) -> Array[float]:
	var out: Array[float] = []
	out.resize(values.size())
	for index in values.size():
		out[index] = snappedf(values[index], 0.001)
	return out

func _transform_values(xf: Transform3D) -> Array[float]:
	var b := xf.basis
	var o := xf.origin
	return [
		o.x, o.y, o.z,
		b.x.x, b.x.y, b.x.z,
		b.y.x, b.y.y, b.y.z,
		b.z.x, b.z.y, b.z.z,
	]

func _subtree_aabb(node: Node) -> AABB:
	var box := AABB()
	var first := true
	# Hangar framing: skip the room shell (floor/walls) so the six views
	# frame the platform cluster + robots instead of the whole building.
	if node.name == "HangarRoom":
		return box
	if node is MeshInstance3D:
		var instance := node as MeshInstance3D
		if instance.is_visible_in_tree() and instance.mesh != null:
			box = instance.global_transform * instance.mesh.get_aabb()
			first = false
	for child in node.get_children():
		var sub := _subtree_aabb(child)
		if sub.size.x <= 0.0 and sub.size.y <= 0.0 and sub.size.z <= 0.0:
			continue
		if first:
			box = sub
			first = false
		else:
			box = box.merge(sub)
	return box

func _collect(node: Node, vertices: Array[float], colors: Array[float],
		emissives: Array[float]) -> void:
	if node is MultiMeshInstance3D:
		_collect_multimesh(node as MultiMeshInstance3D, vertices, colors, emissives)
	elif node is MeshInstance3D:
		var instance := node as MeshInstance3D
		if instance.is_visible_in_tree() and instance.mesh != null:
			_emit(instance.mesh, instance.global_transform, _color_of(instance, instance.mesh),
					vertices, colors, emissives)
	for child in node.get_children():
		_collect(child, vertices, colors, emissives)

func _collect_multimesh(instance: MultiMeshInstance3D, vertices: Array[float],
		colors: Array[float], emissives: Array[float]) -> void:
	if not instance.is_visible_in_tree() or instance.multimesh == null:
		return
	var multimesh := instance.multimesh
	if multimesh.mesh == null:
		return
	var base := _color_of(instance, multimesh.mesh)
	for index in multimesh.instance_count:
		var xf := instance.global_transform * multimesh.get_instance_transform(index)
		_emit(multimesh.mesh, xf, base, vertices, colors, emissives)

func _emit(mesh: Mesh, xf: Transform3D, color: Array, vertices: Array[float],
		colors: Array[float], emissives: Array[float]) -> void:
	if vertices.size() >= MAX_TRIANGLES * 9:
		return
	var faces := _faces_of(mesh)
	for index in range(0, faces.size() - 2, 3):
		for corner in 3:
			var world := xf * faces[index + corner]
			vertices.append(world.x)
			vertices.append(world.y)
			vertices.append(world.z)
			colors.append(color[0])
			colors.append(color[1])
			colors.append(color[2])
			emissives.append(color[3])
			emissives.append(color[4])
			emissives.append(color[5])

func _faces_of(mesh: Mesh) -> PackedVector3Array:
	var faces := mesh.get_faces()
	if faces.size() >= 3:
		return faces
	if not (mesh is PrimitiveMesh):
		return faces
	var arrays := (mesh as PrimitiveMesh).get_mesh_arrays()
	var points := arrays[Mesh.ARRAY_VERTEX] as PackedVector3Array
	var indices := arrays[Mesh.ARRAY_INDEX] as PackedInt32Array
	if points.is_empty():
		return faces
	if indices.is_empty():
		return points
	var out := PackedVector3Array()
	for index in range(0, indices.size() - 2, 3):
		out.append(points[indices[index]])
		out.append(points[indices[index + 1]])
		out.append(points[indices[index + 2]])
	return out

func _color_of(instance: GeometryInstance3D, mesh: Mesh) -> Array:
	var mat := instance.material_override
	if mat == null and mesh != null and mesh.get_surface_count() > 0:
		mat = mesh.surface_get_material(0)
	if mat is StandardMaterial3D:
		var standard := mat as StandardMaterial3D
		var emission := Color.BLACK
		if standard.emission_enabled:
			emission = standard.emission * standard.emission_energy_multiplier
		return [standard.albedo_color.r, standard.albedo_color.g, standard.albedo_color.b,
				emission.r, emission.g, emission.b]
	if mat is ShaderMaterial:
		return [0.6, 0.6, 0.6, 0.0, 0.0, 0.0]
	return [0.6, 0.6, 0.6, 0.0, 0.0, 0.0]
