"""RAVAGER — hunched assault titan mech for MECH ASSAULT (Godot 4.4.1).

Original design (never a copy of any War Robots asset): a dark, forward-hunched
brawler with a spiked shoulder cowl, one shoulder cannon pod, a round ball
shield on the right arm and purple emissive cores.

Runs the same Blender -> GLB pipeline as tools/build_princeps.py:

	blender --background --python tools/build_ravager.py

Contract (must match src/player/robot_rig.gd + src/player/titan_rig.gd):
  * part names   chassis__* / head__* / l0c,l0u,l0l,l0f / l1c,l1u,l1l,l1f
                 (never "gun*" — WeaponMount builds the weapons)
  * material keys m_primary m_secondary m_accent m_joint m_trim m_recess m_sensor
  * bones        thigh 1.875 / shin 2.175 / coxa 0.48  (* BULK = 1.25 game units)
  * hips         (+-0.78, -0.15, 0) * BULK, head node (0, 2.4, -0.78) * BULK,
                 alpha sockets (+-1.08, 2.16, -0.3) * BULK,
                 beta sockets  (+-1.65, 0.15, 0.3) * BULK
  * flame mouths (+-0.66, 0.78, 1.14) authored  (= TitanRig's flame emitters
                 (side*0.66, 0.78, 1.14) * BULK in game units)

Keeps the bone-accurate leg lengths of build_citadel.py (authored once, helpers
multiply by BULK exactly once) — see that module's docstring.

Runs its own validation after export: re-imports the GLB, checks object/triangle
counts, part-name contract, material keys, file size and bbox against
assets/mech/princeps.glb (+-15% per axis).
"""

import math
import os
import re
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

import bpy
from mathutils import Matrix, Vector

import build_mech as bm

HERE = os.path.dirname(os.path.abspath(__file__))
OUT_RAVAGER = os.path.abspath(os.path.join(HERE, "..", "assets", "mech", "ravager.glb"))
OUT_PRINCEPS = os.path.abspath(os.path.join(HERE, "..", "assets", "mech", "princeps.glb"))

# ---------------------------------------------------------------- contract --
BULK = 1.25
THIGH = 1.875
SHIN = 2.175
COXA = 0.48
HIP_POS = [
	(0.78 * BULK, -0.15 * BULK, 0.0),
	(-0.78 * BULK, -0.15 * BULK, 0.0),
]
HIP_OUT = [(1.0, 0.0, 0.0), (-1.0, 0.0, 0.0)]
HEAD_POSE = (0.0, 2.4 * BULK, -0.78 * BULK)
ALPHA_SOCKET = (1.08 * BULK, 2.16 * BULK, -0.3 * BULK)
BETA_SOCKET = (1.65 * BULK, 0.15 * BULK, 0.3 * BULK)
# TitanRig._build_thrusters: flame.position = Vector3(side*0.66, 0.78, 1.14)*BULK
# in chassis (game) units -> authored units are that tuple unchanged.
FLAME_MOUTH = (0.66, 0.78, 1.14)
FLAME_DIR = (0.0, -0.9285, 0.3714)  # normalised (0, -1, 0.4)

# Gunmetal black / graphite plates / purple accents, steel trim, purple
# emissive cores.  Painted armour keeps metallic low (0.2-0.25).
MAT_SPECS = {
	"m_primary": ((0.06, 0.06, 0.072, 1.0), 0.20, 0.55, None, 0.0),
	"m_secondary": ((0.14, 0.14, 0.16, 1.0), 0.25, 0.50, None, 0.0),
	"m_accent": ((0.36, 0.10, 0.50, 1.0), 0.20, 0.45, None, 0.0),
	"m_joint": ((0.07, 0.07, 0.085, 1.0), 0.60, 0.70, None, 0.0),
	"m_trim": ((0.45, 0.47, 0.52, 1.0), 0.95, 0.34, None, 0.0),
	"m_recess": ((0.03, 0.03, 0.04, 1.0), 0.40, 0.85, None, 0.0),
	"m_sensor": ((0.70, 0.25, 1.00, 1.0), 0.20, 0.15, (0.55, 0.15, 1.0), 4.0),
}

MAT_NAMES = (
	"m_primary", "m_secondary", "m_accent", "m_joint", "m_trim", "m_recess", "m_sensor",
)


# ----------------------------------------------------------------- helpers --
def _v3(value):
	return tuple(c * BULK for c in value)


def part(t, m, verts, faces, local, bevel=0.0, smooth=False):
	return bm.part(t, m, verts, faces, local, bevel * BULK, smooth)


def box(t, m, size, origin, rot=None, bevel=0.02):
	return bm.box_part(t, m, _v3(size), _v3(origin), rot, bevel * BULK)


def cyl(t, m, radius, length, origin, rot=None, segments=16):
	return bm.cyl_part(t, m, radius * BULK, length * BULK, _v3(origin), rot, segments)


def cone(t, m, rb, rt, length, origin, rot=None):
	return bm.cone_part(t, m, rb * BULK, rt * BULK, length * BULK, _v3(origin), rot)


def loft(t, m, path, radii, origin=(0.0, 0.0, 0.0), rot=None, segments=16):
	return bm.loft_part(t, m, [_v3(p) for p in path],
			[r * BULK for r in radii], _v3(origin), rot, segments)


def sph(t, m, radius, origin, scale=None, rot=None, seg=16, rings=10):
	"""Sphere with configurable tessellation (bm.sph_part is fixed at 24x14)."""
	r = radius * BULK
	if scale is None:
		verts, faces = bm.sphere_verts(r, seg, rings)
	else:
		verts, faces = bm.sphere_verts(1.0, seg, rings)
		sx, sy, sz = r * scale[0], r * scale[1], r * scale[2]
		verts = [(x * sx, y * sy, z * sz) for (x, y, z) in verts]
	local = bm.translate_g(_v3(origin))
	if rot is not None:
		local = local @ bm.mat4(rot)
	bm.part(t, m, verts, faces, local, 0.0, True)


def spike(t, m, base, rot3, rb, length):
	"""Cone whose base sits on `base` and whose axis follows `rot3` (a 3x3
	matrix from bm.euler_g / bm.rot_*).  cone_part centres the mesh on the
	origin, so shift it half a length along its own axis."""
	axis = rot3 @ Vector((0.0, 1.0, 0.0))
	centre = Vector(base) + axis * (length * 0.5)
	return cone(t, m, rb, 0.01, length, tuple(centre), rot3)


def nozzle(t, side):
	"""Exhaust tube whose mouth sits exactly on TitanRig's flame emitter and
	whose axis follows the flame direction (0, -1, 0.4) down-backward."""
	mouth = (side * FLAME_MOUTH[0], FLAME_MOUTH[1], FLAME_MOUTH[2])
	theta = math.degrees(math.atan2(FLAME_DIR[2], FLAME_DIR[1]))
	rot = bm.rot_x(theta)
	length = 0.62
	centre = (
		mouth[0] - FLAME_DIR[0] * length * 0.5,
		mouth[1] - FLAME_DIR[1] * length * 0.5,
		mouth[2] - FLAME_DIR[2] * length * 0.5,
	)
	cyl(t, "m_recess", 0.23, length, centre, rot, 12)
	lip = (
		mouth[0] + FLAME_DIR[0] * 0.045,
		mouth[1] + FLAME_DIR[1] * 0.045,
		mouth[2] + FLAME_DIR[2] * 0.045,
	)
	cyl(t, "m_sensor", 0.155, 0.09, lip, rot, 10)


# ------------------------------------------------------------- the machine --
def build_chassis():
	t = "chassis"

	# --- pelvis / waist ------------------------------------------------
	box(t, "m_primary", (1.50, 0.55, 1.15), (0.0, 0.08, 0.05), None, 0.06)
	box(t, "m_secondary", (1.72, 0.28, 1.28), (0.0, -0.18, 0.05), None, 0.05)
	box(t, "m_joint", (1.15, 0.24, 1.00), (0.0, 0.40, 0.0), None, 0.03)
	box(t, "m_secondary", (0.95, 0.50, 0.85), (0.0, 0.66, 0.0), None, 0.04)

	# --- belly + reactor core -----------------------------------------
	box(t, "m_secondary", (1.35, 0.40, 1.15), (0.0, -0.30, 0.05), None, 0.05)
	box(t, "m_primary", (0.70, 0.32, 0.90), (0.0, -0.40, -0.05), None, 0.04)
	sph(t, "m_sensor", 0.13, (0.0, -0.36, -0.44), None, None, 14, 9)

	# --- hunched chest (leans forward) ---------------------------------
	box(t, "m_primary", (2.05, 1.20, 1.42), (0.0, 1.32, 0.06), bm.rot_x(-10.0), 0.07)
	box(t, "m_secondary", (1.80, 0.42, 1.18), (0.0, 1.86, 0.06), bm.rot_x(-10.0), 0.05)
	# angled side facets + steel edge highlights (layered plate read)
	for side in (1.0, -1.0):
		box(t, "m_primary", (0.44, 1.06, 1.32),
			(side * 1.02, 1.34, 0.06),
			bm.rot_x(-10.0) @ bm.rot_z(side * -12.0), 0.05)
		box(t, "m_trim", (0.07, 0.84, 0.10),
			(side * 1.25, 1.38, -0.56),
			bm.rot_x(-10.0) @ bm.rot_z(side * -12.0), 0.012)
	box(t, "m_primary", (1.70, 0.46, 0.42), (0.0, 1.48, -0.74), bm.rot_x(-14.0), 0.04)
	box(t, "m_accent", (1.42, 0.12, 0.16), (0.0, 1.66, -0.88), bm.rot_x(-14.0), 0.015)
	box(t, "m_recess", (1.05, 0.20, 0.10), (0.0, 1.16, -0.79), bm.rot_x(-8.0), 0.01)
	box(t, "m_trim", (0.85, 0.08, 0.12), (0.0, 1.03, -0.81), bm.rot_x(-8.0), 0.01)
	box(t, "m_primary", (1.50, 0.44, 0.42), (0.0, 1.80, -0.76), bm.rot_x(-26.0), 0.04)
	box(t, "m_trim", (0.78, 0.08, 0.24), (0.0, 1.93, -0.88), bm.rot_x(-26.0), 0.015)

	# --- neck block reaching the fixed HeadSensor node -----------------
	box(t, "m_joint", (0.48, 0.28, 0.54), (0.0, 1.94, -0.56), bm.rot_x(-10.0), 0.03)

	# --- reactor eye (purple chest core) -------------------------------
	cyl(t, "m_recess", 0.30, 0.12, (0.0, 1.48, -1.01), bm.rot_x(90.0), 16)
	cyl(t, "m_trim", 0.35, 0.05, (0.0, 1.48, -1.075), bm.rot_x(90.0), 16)
	sph(t, "m_sensor", 0.21, (0.0, 1.48, -1.11), None, None, 14, 9)

	# --- cowl deck (hunched top plate, carries the spikes) -------------
	box(t, "m_primary", (2.75, 0.30, 1.30), (0.0, 2.10, 0.28), bm.rot_x(-9.0), 0.05)
	box(t, "m_secondary", (2.20, 0.14, 0.85), (0.0, 2.26, 0.38), bm.rot_x(-9.0), 0.03)

	# --- spikes: one on the cowl, two crowding the right pauldron ------
	spike(t, "m_secondary", (0.0, 2.26, 0.44), bm.euler_g(16.0, 0.0, 0.0), 0.17, 0.52)
	spike(t, "m_secondary", (-1.18, 2.55, 0.15), bm.euler_g(18.0, 0.0, 12.0), 0.18, 0.54)
	spike(t, "m_secondary", (-1.56, 2.48, 0.05), bm.euler_g(20.0, 0.0, 24.0), 0.15, 0.46)

	# --- left shoulder cannon pod (alpha socket) -----------------------
	box(t, "m_secondary", (0.98, 0.66, 1.08), (1.12, 2.20, -0.16), None, 0.05)
	box(t, "m_accent", (0.80, 0.14, 0.90), (1.12, 2.56, -0.16), None, 0.03)
	box(t, "m_primary", (1.00, 0.40, 0.50), (1.12, 2.18, -0.56), None, 0.04)
	cyl(t, "m_recess", 0.28, 0.30, (1.08, 2.16, -0.80), bm.rot_x(90.0), 16)
	cyl(t, "m_trim", 0.32, 0.10, (1.08, 2.16, -0.66), bm.rot_x(90.0), 16)
	box(t, "m_trim", (0.10, 0.50, 0.90), (1.64, 2.18, -0.14), None, 0.02)
	box(t, "m_joint", (0.34, 0.26, 0.50), (0.74, 2.08, 0.36), None, 0.03)
	for dx, dy in ((-0.16, 0.14), (0.16, 0.14), (-0.16, -0.14), (0.16, -0.14)):
		cyl(t, "m_joint", 0.07, 0.16,
			(1.08 + dx, 2.16 + dy, -0.76), bm.rot_x(90.0), 8)

	# --- right shoulder pauldron + mount pad (alpha socket) ------------
	box(t, "m_primary", (0.94, 0.62, 1.00), (-1.30, 2.10, 0.10), bm.rot_x(-8.0), 0.05)
	box(t, "m_accent", (0.80, 0.13, 0.86), (-1.30, 2.45, 0.12), bm.rot_x(-8.0), 0.03)
	box(t, "m_trim", (0.08, 0.50, 0.80), (-1.78, 2.04, 0.08), None, 0.02)
	box(t, "m_secondary", (0.66, 0.50, 0.66), (-1.12, 2.14, -0.12), None, 0.04)
	cyl(t, "m_recess", 0.27, 0.28, (-1.08, 2.16, -0.74), bm.rot_x(90.0), 16)
	cyl(t, "m_trim", 0.31, 0.10, (-1.08, 2.16, -0.62), bm.rot_x(90.0), 16)
	box(t, "m_sensor", (0.44, 0.07, 0.10), (-1.34, 2.42, -0.52), None, 0.008)

	# --- rounded shoulder masses (hunched brawler silhouette) ----------
	sph(t, "m_secondary", 0.42, (1.26, 1.75, 0.04), (1.08, 0.78, 1.0), None, 16, 10)
	sph(t, "m_primary", 0.42, (-1.26, 1.75, 0.04), (1.08, 0.78, 1.0), None, 16, 10)

	# --- hip sponsons (beta sockets) -----------------------------------
	for side in (1.0, -1.0):
		sph(t, "m_joint", 0.29, (side * 0.90, -0.05, 0.05), None, None, 16, 10)
		box(t, "m_primary", (0.40, 0.50, 0.66), (side * 1.00, -0.04, 0.03),
			None, 0.04)
		box(t, "m_secondary", (0.70, 0.60, 1.14), (side * 1.50, 0.10, 0.24), None, 0.05)
		box(t, "m_primary", (0.60, 0.40, 0.60), (side * 1.50, 0.14, -0.28), None, 0.04)
		cyl(t, "m_recess", 0.25, 0.28, (side * 1.65, 0.15, -0.56), bm.rot_x(90.0), 14)
		cyl(t, "m_trim", 0.29, 0.10, (side * 1.65, 0.15, -0.46), bm.rot_x(90.0), 14)
		box(t, "m_trim", (0.08, 0.44, 0.78), (side * 1.88, 0.10, 0.20), None, 0.02)

	# --- left arm (cannon side) ---------------------------------------
	sph(t, "m_joint", 0.25, (1.14, 1.26, -0.06), None, None, 16, 10)
	box(t, "m_secondary", (0.32, 0.36, 0.36), (1.23, 1.30, -0.04),
		bm.rot_z(-10.0), 0.03)
	box(t, "m_secondary", (0.34, 0.60, 0.40), (1.17, 0.90, -0.10), bm.rot_x(-8.0), 0.03)
	sph(t, "m_joint", 0.15, (1.19, 0.55, -0.18), None, None, 14, 9)
	box(t, "m_primary", (0.40, 0.54, 0.46), (1.20, 0.24, -0.22), bm.rot_x(-6.0), 0.03)
	box(t, "m_joint", (0.36, 0.24, 0.40), (1.22, -0.10, -0.22), None, 0.03)
	spike(t, "m_joint", (1.12, -0.22, -0.34), bm.euler_g(-100.0, 0.0, -14.0), 0.07, 0.30)
	spike(t, "m_joint", (1.32, -0.22, -0.34), bm.euler_g(-100.0, 0.0, 14.0), 0.07, 0.30)

	# --- right arm ending in the ball shield ---------------------------
	sph(t, "m_joint", 0.25, (-1.14, 1.26, -0.06), None, None, 16, 10)
	box(t, "m_secondary", (0.32, 0.36, 0.36), (-1.23, 1.30, -0.04),
		bm.rot_z(10.0), 0.03)
	box(t, "m_secondary", (0.34, 0.60, 0.40), (-1.17, 0.90, -0.10), bm.rot_x(-8.0), 0.03)
	sph(t, "m_joint", 0.15, (-1.19, 0.55, -0.18), None, None, 14, 9)
	box(t, "m_primary", (0.52, 0.38, 0.42), (-1.44, 0.72, -0.34), bm.rot_z(-12.0), 0.03)
	# ball shield: raised beside the chest, clears the beta gun body
	# (y <= 0.31 written) below and the alpha gun body (y >= 2.00) above
	bx, by, bz = -1.68, 0.92, -0.52
	sph(t, "m_secondary", 0.52, (bx, by, bz), None, None, 22, 16)
	cyl(t, "m_trim", 0.55, 0.14, (bx, by, bz), bm.rot_x(90.0), 20)
	cyl(t, "m_primary", 0.40, 0.06, (bx, by, bz - 0.44), bm.rot_x(90.0), 20)
	sph(t, "m_sensor", 0.17, (bx, by, bz - 0.47), None, None, 14, 9)
	spike(t, "m_joint", (bx, by, bz - 0.50), bm.euler_g(-90.0, 0.0, 0.0), 0.12, 0.38)
	spike(t, "m_joint", (bx, by + 0.20, bz - 0.41), bm.euler_g(-70.0, 0.0, 0.0), 0.10, 0.32)
	spike(t, "m_joint", (bx, by - 0.20, bz - 0.41), bm.euler_g(-110.0, 0.0, 0.0), 0.10, 0.32)

	# --- rear pack, vents, thruster nozzles ----------------------------
	box(t, "m_secondary", (1.50, 1.00, 0.62), (0.0, 1.42, 0.92), None, 0.05)
	box(t, "m_primary", (1.10, 0.50, 0.50), (0.0, 2.02, 0.88), bm.rot_x(-8.0), 0.04)
	box(t, "m_primary", (1.60, 0.44, 0.50), (0.0, 1.94, 0.72), bm.rot_x(16.0), 0.05)
	for vent in range(3):
		box(t, "m_recess", (1.00, 0.08, 0.10),
			(0.0, 1.10 + vent * 0.18, 1.24), None, 0.008)
	box(t, "m_sensor", (0.70, 0.26, 0.08), (0.0, 1.72, 1.24), None, 0.01)
	for side in (1.0, -1.0):
		nozzle(t, side)

	# --- belly skirt ---------------------------------------------------
	box(t, "m_accent", (1.20, 0.26, 0.30), (0.0, -0.44, -0.44), bm.rot_x(-14.0), 0.03)


def build_head():
	"""Head is authored relative to HeadSensor = (0, 2.4, -0.78) * BULK and
	sits low and forward in the hunch (shell offset ~(0, -0.15, -0.3))."""
	t = "head"
	box(t, "m_primary", (0.80, 0.40, 0.66), (0.0, -0.15, -0.30), None, 0.035)
	box(t, "m_accent", (0.90, 0.14, 0.50), (0.0, 0.04, -0.36), bm.rot_x(-12.0), 0.025)
	box(t, "m_recess", (0.60, 0.20, 0.14), (0.0, -0.17, -0.60), None, 0.012)
	box(t, "m_sensor", (0.48, 0.07, 0.06), (0.0, -0.13, -0.64), None, 0.006)
	sph(t, "m_sensor", 0.06, (0.17, -0.13, -0.64), (1.0, 0.9, 0.9), None, 12, 8)
	sph(t, "m_sensor", 0.06, (-0.17, -0.13, -0.64), (1.0, 0.9, 0.9), None, 12, 8)
	box(t, "m_secondary", (0.58, 0.16, 0.38), (0.0, -0.38, -0.34), bm.rot_x(12.0), 0.025)
	for side in (1.0, -1.0):
		box(t, "m_secondary", (0.16, 0.30, 0.44), (side * 0.44, -0.16, -0.30),
			bm.rot_z(side * -10.0), 0.022)
	box(t, "m_accent", (0.30, 0.30, 0.50), (0.0, 0.10, -0.16), None, 0.025)
	box(t, "m_trim", (0.09, 0.18, 0.58), (0.0, 0.30, -0.22), bm.rot_x(-14.0), 0.018)
	sph(t, "m_joint", 0.11, (0.0, 0.06, -0.10), None, None, 14, 9)
	cyl(t, "m_trim", 0.03, 0.46, (-0.26, 0.28, -0.14), bm.euler_g(8.0, 8.0, 0.0), 8)
	sph(t, "m_sensor", 0.05, (-0.30, 0.50, -0.17), None, None, 12, 8)


def build_legs():
	for index in range(2):
		c = "l%dc" % index
		u = "l%du" % index
		low = "l%dl" % index
		f = "l%df" % index

		# coxa
		sph(c, "m_joint", 0.33, (0.0, 0.0, 0.0), None, None, 16, 10)
		loft(c, "m_trim", [(0.0, 0.0, 0.0), (0.0, 0.12, 0.0), (0.0, COXA, 0.0)],
			[0.27, 0.24, 0.20], segments=14)
		box(c, "m_primary", (0.50, 0.36, 0.56), (0.0, 0.16, 0.0), None, 0.035)
		box(c, "m_trim", (0.52, 0.08, 0.17), (0.0, 0.32, -0.22), None, 0.015)

		# thigh — angular plates over a tapered core
		loft(u, "m_primary", [
			(0.0, 0.0, 0.0), (0.03, 0.55, 0.04), (0.01, 1.15, 0.01), (0.0, THIGH, 0.0),
		], [0.29, 0.36, 0.29, 0.22], segments=14)
		box(u, "m_secondary", (0.62, 0.92, 0.26), (0.02, 0.60, -0.30),
			bm.rot_x(-6.0), 0.03)
		box(u, "m_accent", (0.44, 0.32, 0.17), (0.02, 1.05, -0.35),
			bm.rot_x(-8.0), 0.02)
		box(u, "m_primary", (0.52, 0.50, 0.20), (0.02, 1.40, 0.30),
			bm.rot_x(7.0), 0.03)
		box(u, "m_trim", (0.34, 0.09, 0.09), (0.02, 0.80, -0.46),
			bm.rot_x(-6.0), 0.012)
		for side in (1.0, -1.0):
			box(u, "m_secondary", (0.12, 0.74, 0.42), (side * 0.33, 0.70, 0.0),
				None, 0.025)
			cyl(u, "m_trim", 0.06, 0.82, (side * 0.36, 0.60, 0.02), None, 10)
		cyl(u, "m_accent", 0.32, 0.10, (0.0, 0.45, 0.0), None, 16)
		sph(u, "m_joint", 0.31, (0.0, THIGH, 0.0), None, None, 16, 10)
		cyl(u, "m_accent", 0.21, 0.13, (0.0, THIGH, 0.0), bm.rot_x(90.0), 12)

		# shin
		loft(low, "m_primary", [
			(0.0, 0.0, 0.0), (0.0, 0.55, -0.04), (0.0, 1.15, -0.01), (0.0, SHIN, 0.0),
		], [0.25, 0.29, 0.22, 0.17], segments=14)
		box(low, "m_secondary", (0.56, 0.86, 0.24), (0.0, 0.60, -0.24), None, 0.03)
		box(low, "m_accent", (0.36, 0.26, 0.15), (0.0, 1.15, -0.28), None, 0.02)
		box(low, "m_primary", (0.46, 0.54, 0.18), (0.0, 0.70, 0.25), None, 0.03)
		box(low, "m_trim", (0.30, 0.08, 0.08), (0.0, 0.78, -0.43), None, 0.012)
		for side in (1.0, -1.0):
			box(low, "m_secondary", (0.11, 0.68, 0.34), (side * 0.25, 0.60, 0.0),
				None, 0.022)
			cyl(low, "m_trim", 0.05, 0.74, (side * 0.27, 0.58, 0.05), None, 10)
		sph(low, "m_joint", 0.19, (0.0, SHIN, 0.0), None, None, 14, 9)

		# foot: pad bottom lands 0.1125 game below the Foot node
		sph(f, "m_joint", 0.15, (0.0, 0.13, 0.0), None, None, 14, 9)
		box(f, "m_primary", (0.84, 0.22, 1.04), (0.0, 0.0, 0.02), None, 0.03)
		box(f, "m_trim", (0.52, 0.08, 0.52), (0.0, -0.06, -0.05), None, 0.015)
		box(f, "m_secondary", (0.64, 0.14, 0.28), (0.0, 0.10, -0.36),
			bm.rot_x(-6.0), 0.02)
		for cx in (-0.24, 0.0, 0.24):
			yaw = -16.0 if cx > 0.0 else (16.0 if cx < 0.0 else 0.0)
			spike(f, "m_joint", (cx, -0.03, -0.44),
				bm.euler_g(-95.0, yaw, 0.0), 0.105, 0.46)
		spike(f, "m_joint", (0.0, -0.04, 0.40), bm.euler_g(95.0, 0.0, 0.0), 0.09, 0.34)
		box(f, "m_sensor", (0.32, 0.05, 0.07), (0.0, 0.07, -0.32), None, 0.01)


def build_poses():
	"""Doc-only rest pose (build_mech.construct drops empties before export —
	the Godot side re-solves the IK).  Kept for parity with build_princeps."""
	empties = {"chassis": Matrix.Identity(4), "head": bm.translate_g(HEAD_POSE)}
	for index in range(2):
		pose = bm.leg_pose(HIP_POS[index], HIP_OUT[index])
		empties["l%dc" % index] = pose["coxa"]
		empties["l%du" % index] = pose["upper"]
		empties["l%dl" % index] = pose["lower"]
		empties["l%df" % index] = pose["foot"]
	return empties


# ------------------------------------------------------------- validation --
NAME_RE = re.compile(r"^(chassis|head|l[01][culf])__m_"
		+ "(primary|secondary|accent|joint|trim|recess|sensor)$")
REQUIRED = ["chassis", "head"] + [
	"l%d%s" % (i, role) for i in range(2) for role in "culf"]


def _measure(path):
	bpy.ops.wm.read_factory_settings(use_empty=True)
	bpy.ops.import_scene.gltf(filepath=path)
	lo = [1e9, 1e9, 1e9]
	hi = [-1e9, -1e9, -1e9]
	tris = 0
	names = []
	mats = set()
	for obj in bpy.data.objects:
		if obj.type != "MESH":
			continue
		names.append(obj.name)
		tris += sum(max(1, len(poly.vertices) - 2) for poly in obj.data.polygons)
		for slot in obj.material_slots:
			if slot.material is not None:
				mats.add(slot.material.name)
		mw = obj.matrix_world
		for vertex in obj.data.vertices:
			bco = mw @ vertex.co
			gco = (bco.x, bco.z, -bco.y)  # Blender Z-up -> glTF/Godot Y-up
			for axis in range(3):
				lo[axis] = min(lo[axis], gco[axis])
				hi[axis] = max(hi[axis], gco[axis])
	return {
		"objects": len(names), "tris": tris, "lo": lo, "hi": hi,
		"names": names, "mats": mats,
	}


def validate():
	failures = []
	size = os.path.getsize(OUT_RAVAGER)
	mine = _measure(OUT_RAVAGER)
	ref = _measure(OUT_PRINCEPS)

	print("\n=== RAVAGER build report ===")
	print("file            : %s (%d bytes)" % (OUT_RAVAGER, size))
	print("objects / tris  : %d / %d" % (mine["objects"], mine["tris"]))
	print("bbox (game axes): x[%6.3f,%6.3f] y[%6.3f,%6.3f] z[%6.3f,%6.3f]" % (
		mine["lo"][0], mine["hi"][0], mine["lo"][1], mine["hi"][1],
		mine["lo"][2], mine["hi"][2]))
	print("size            : (%.3f, %.3f, %.3f)" % (
		mine["hi"][0] - mine["lo"][0], mine["hi"][1] - mine["lo"][1],
		mine["hi"][2] - mine["lo"][2]))
	print("materials       : %s" % ", ".join(sorted(mine["mats"])))
	print("princeps ref    : %d objects / %d tris, size (%.3f, %.3f, %.3f)" % (
		ref["objects"], ref["tris"], ref["hi"][0] - ref["lo"][0],
		ref["hi"][1] - ref["lo"][1], ref["hi"][2] - ref["lo"][2]))

	if size <= 200 * 1024:
		failures.append("file is %d bytes (need > 204800)" % size)
	if not 15000 <= mine["tris"] <= 25000:
		failures.append("triangle count %d outside the 15000..25000 budget"
			% mine["tris"])
	bad = sorted(n for n in mine["names"] if not NAME_RE.match(n))
	if bad:
		failures.append("part names violate the contract: %s" % bad[:6])
	guns = [n for n in mine["names"] if n.startswith("gun")]
	if guns:
		failures.append("gun* parts present (weapons belong to WeaponMount): %s" % guns)
	targets = set(n.split("__", 1)[0] for n in mine["names"])
	for needed in REQUIRED:
		if needed not in targets:
			failures.append("missing part group %r" % needed)
	if mine["mats"] != set(MAT_NAMES):
		failures.append("material keys %s != %s" % (
			sorted(mine["mats"]), sorted(MAT_NAMES)))
	for axis, label in enumerate("xyz"):
		a = mine["hi"][axis] - mine["lo"][axis]
		b = ref["hi"][axis] - ref["lo"][axis]
		ratio = a / b if b else 0.0
		print("bbox %s vs princeps: %.3f / %.3f = %.3f" % (label, a, b, ratio))
		if not 0.85 <= ratio <= 1.15:
			failures.append("bbox axis %s is %.0f%% off princeps (need +-15%%)"
				% (label, (ratio - 1.0) * 100.0))

	if failures:
		print("\nVALIDATION FAILED:")
		for line in failures:
			print("  - " + line)
		raise SystemExit(1)
	print("\nVALIDATION PASSED (%d checks)" % (4 + len(MAT_NAMES)))


def main():
	bm.MAT_SPECS.clear()
	bm.MAT_SPECS.update(MAT_SPECS)
	bm.construct(
		builders=[build_chassis, build_head, build_legs],
		poses_fn=build_poses,
		out_path=OUT_RAVAGER)
	validate()


if __name__ == "__main__":
	main()
