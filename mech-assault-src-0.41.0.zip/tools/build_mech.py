import bpy
import bmesh
import math
import os
from mathutils import Vector, Matrix

OUT_PATH = os.path.normpath(os.path.join(
	os.path.dirname(os.path.abspath(__file__)), "..", "assets", "mech", "hero_mech.glb"))

HIP_POS = [
	(1.22, -0.3, -1.05), (-1.22, -0.3, -1.05),
	(1.26, -0.3, 1.02), (-1.26, -0.3, 1.02),
]
HIP_OUT = [
	(0.88, 0.0, -0.3), (-0.88, 0.0, -0.3),
	(0.9, 0.0, 0.32), (-0.9, 0.0, 0.32),
]
SOCK_POS = [
	(1.06, 0.5, -0.72), (-1.06, 0.5, -0.72),
	(1.14, 0.54, 0.62), (-1.14, 0.54, 0.62),
]
SOCK_SIDE = [1.0, -1.0, 1.0, -1.0]
TAIL_LEN = [0.78, 0.68, 0.58, 0.5]
TAIL_RAD = [0.34, 0.28, 0.22, 0.17]
TAIL_REST = [-18.0, -24.0, -26.0, -26.0]

MAT_SPECS = {
	"m_primary": ((0.56, 0.42, 0.14, 1.0), 0.95, 0.34, None, 0.0),
	"m_secondary": ((0.36, 0.26, 0.1, 1.0), 0.9, 0.44, None, 0.0),
	"m_accent": ((0.78, 0.6, 0.24, 1.0), 1.0, 0.28, None, 0.0),
	"m_joint": ((0.09, 0.095, 0.11, 1.0), 0.6, 0.7, None, 0.0),
	"m_trim": ((0.4, 0.43, 0.48, 1.0), 0.9, 0.4, None, 0.0),
	"m_recess": ((0.05, 0.055, 0.07, 1.0), 0.4, 0.85, None, 0.0),
	"m_sensor": ((0.1, 0.85, 1.0, 1.0), 0.2, 0.15, (0.15, 0.9, 1.0), 3.6),
}

C_G2B = Matrix((
	(1.0, 0.0, 0.0),
	(0.0, 0.0, 1.0),
	(0.0, -1.0, 0.0),
))
C_B2G = C_G2B.inverted()


def v_add(a, b):
	return (a[0] + b[0], a[1] + b[1], a[2] + b[2])


def v_sub(a, b):
	return (a[0] - b[0], a[1] - b[1], a[2] - b[2])


def v_mul(a, s):
	return (a[0] * s, a[1] * s, a[2] * s)


def v_dot(a, b):
	return a[0] * b[0] + a[1] * b[1] + a[2] * b[2]


def v_cross(a, b):
	return (
		a[1] * b[2] - a[2] * b[1],
		a[2] * b[0] - a[0] * b[2],
		a[0] * b[1] - a[1] * b[0],
	)


def v_norm(a):
	length = math.sqrt(v_dot(a, a))
	if length < 1e-8:
		return (0.0, 1.0, 0.0)
	return (a[0] / length, a[1] / length, a[2] / length)


def v_lerp(a, b, t):
	return (
		a[0] + (b[0] - a[0]) * t,
		a[1] + (b[1] - a[1]) * t,
		a[2] + (b[2] - a[2]) * t,
	)


def clampf(value, low, high):
	return max(low, min(high, value))


def rot_x(deg):
	r = math.radians(deg)
	c = math.cos(r)
	s = math.sin(r)
	return Matrix((
		(1.0, 0.0, 0.0),
		(0.0, c, -s),
		(0.0, s, c),
	))


def rot_y(deg):
	r = math.radians(deg)
	c = math.cos(r)
	s = math.sin(r)
	return Matrix((
		(c, 0.0, s),
		(0.0, 1.0, 0.0),
		(-s, 0.0, c),
	))


def rot_z(deg):
	r = math.radians(deg)
	c = math.cos(r)
	s = math.sin(r)
	return Matrix((
		(c, -s, 0.0),
		(s, c, 0.0),
		(0.0, 0.0, 1.0),
	))


def euler_g(x_deg, y_deg, z_deg):
	return rot_y(y_deg) @ rot_x(x_deg) @ rot_z(z_deg)


def basis_from_cols(x_axis, y_axis, z_axis):
	return Matrix((
		(x_axis[0], y_axis[0], z_axis[0]),
		(x_axis[1], y_axis[1], z_axis[1]),
		(x_axis[2], y_axis[2], z_axis[2]),
	))


def segment_basis_g(direction):
	y_axis = v_norm(direction)
	x_axis = v_cross((0.0, 0.0, -1.0), y_axis)
	if v_dot(x_axis, x_axis) < 1e-4:
		x_axis = v_cross((1.0, 0.0, 0.0), y_axis)
	x_axis = v_norm(x_axis)
	z_axis = v_norm(v_cross(x_axis, y_axis))
	return basis_from_cols(x_axis, y_axis, z_axis)


def mat4(rot3, origin=(0.0, 0.0, 0.0)):
	m = Matrix.Identity(4)
	for i in range(3):
		for j in range(3):
			m[i][j] = rot3[i][j]
		m[i][3] = origin[i]
	return m


def translate_g(origin):
	return mat4(Matrix.Identity(3), origin)


def conj_g2b(m4):
	rot3 = Matrix((
		(m4[0][0], m4[0][1], m4[0][2]),
		(m4[1][0], m4[1][1], m4[1][2]),
		(m4[2][0], m4[2][1], m4[2][2]),
	))
	origin = Vector((m4[0][3], m4[1][3], m4[2][3]))
	rot_b = C_B2G @ rot3 @ C_G2B
	origin_b = C_B2G @ origin
	out = Matrix.Identity(4)
	for i in range(3):
		for j in range(3):
			out[i][j] = rot_b[i][j]
		out[i][3] = origin_b[i]
	return out


def to_b_point(v_g):
	p = C_B2G @ Vector(v_g)
	return (p.x, p.y, p.z)


def leg_pose(hip, out):
	forward = (0.0, 0.0, -1.0)
	up = (0.0, 1.0, 0.0)
	lateral = v_sub(out, v_mul(forward, v_dot(out, forward)))
	lateral = v_norm(lateral)
	coxa_end = v_add(hip, v_mul(lateral, 0.28))
	foot = (hip[0] + lateral[0] * 1.15, -1.6, hip[2] + lateral[2] * 1.15)
	delta = v_sub(foot, coxa_end)
	dist = min(max(math.sqrt(v_dot(delta, delta)), 0.05), 2.48)
	direction = v_norm(delta)
	along = (1.15 * 1.15 - 1.35 * 1.35 + dist * dist) / (2.0 * dist)
	height = math.sqrt(max(1.15 * 1.15 - along * along, 0.0))
	pole = v_norm(v_add(up, v_mul(lateral, 0.4)))
	perp = v_sub(pole, v_mul(direction, v_dot(pole, direction)))
	if v_dot(perp, perp) < 1e-6:
		perp = v_cross(direction, forward)
	perp = v_norm(perp)
	knee = v_add(v_add(coxa_end, v_mul(direction, along)), v_mul(perp, height))
	shin_end = v_add(coxa_end, v_mul(direction, dist))
	upper_dir = v_norm(v_sub(knee, coxa_end))
	lower_dir = v_norm(v_sub(shin_end, knee))
	return {
		"coxa": mat4(segment_basis_g(lateral), hip),
		"upper": mat4(segment_basis_g(upper_dir), coxa_end),
		"lower": mat4(segment_basis_g(lower_dir), knee),
		"foot": translate_g((foot[0], foot[1] - 0.042, foot[2])),
	}


def build_poses():
	empties = {}
	empties["chassis"] = Matrix.Identity(4)
	empties["head"] = translate_g((0.0, 0.3, -1.5))
	tail_local = translate_g((0.0, 0.52, 1.42)) @ mat4(rot_x(TAIL_REST[0]))
	for index in range(4):
		key = "tail%d" % index
		empties[key] = tail_local
		next_local = translate_g((0.0, 0.0, TAIL_LEN[index]))
		if index + 1 < 4:
			next_local = next_local @ mat4(rot_x(TAIL_REST[index + 1]))
			tail_local = tail_local @ next_local
	empties["stinger"] = empties["tail3"] @ translate_g((0.0, 0.0, TAIL_LEN[3])) @ mat4(rot_x(30.0))
	for index in range(4):
		pose = leg_pose(HIP_POS[index], HIP_OUT[index])
		empties["l%dc" % index] = pose["coxa"]
		empties["l%du" % index] = pose["upper"]
		empties["l%dl" % index] = pose["lower"]
		empties["l%df" % index] = pose["foot"]
	for index in range(4):
		empties["gun%d" % index] = translate_g(SOCK_POS[index]) @ mat4(rot_y(SOCK_SIDE[index] * 90.0))
	return empties


def box_verts(size):
	hx = size[0] * 0.5
	hy = size[1] * 0.5
	hz = size[2] * 0.5
	verts = [
		(-hx, -hy, -hz), (hx, -hy, -hz), (hx, hy, -hz), (-hx, hy, -hz),
		(-hx, -hy, hz), (hx, -hy, hz), (hx, hy, hz), (-hx, hy, hz),
	]
	faces = [
		(0, 1, 2, 3), (5, 4, 7, 6), (4, 0, 3, 7),
		(1, 5, 6, 2), (4, 5, 1, 0), (3, 2, 6, 7),
	]
	return verts, faces


def cyl_verts(radius, length, segments=14, radius_top=None):
	if radius_top is None:
		radius_top = radius
	verts = []
	faces = []
	half = length * 0.5
	for i in range(segments):
		angle = (i / segments) * math.tau
		verts.append((math.cos(angle) * radius, -half, math.sin(angle) * radius))
	for i in range(segments):
		angle = (i / segments) * math.tau
		verts.append((math.cos(angle) * radius_top, half, math.sin(angle) * radius_top))
	verts.append((0.0, -half, 0.0))
	verts.append((0.0, half, 0.0))
	bottom_center = segments * 2
	top_center = segments * 2 + 1
	for i in range(segments):
		j = (i + 1) % segments
		faces.append((i, j, segments + j, segments + i))
		faces.append((bottom_center, j, i))
		faces.append((top_center, segments + i, segments + j))
	return verts, faces


def sphere_verts(radius, segments=20, rings=12):
	verts = []
	faces = []
	top = len(verts)
	verts.append((0.0, radius, 0.0))
	for r in range(1, rings):
		phi = (r / rings) * math.pi
		y = math.cos(phi) * radius
		ring_r = math.sin(phi) * radius
		for s in range(segments):
			theta = (s / segments) * math.tau
			verts.append((math.cos(theta) * ring_r, y, math.sin(theta) * ring_r))
	bottom = len(verts)
	verts.append((0.0, -radius, 0.0))
	for s in range(segments):
		ns = (s + 1) % segments
		faces.append((top, 1 + s, 1 + ns))
	for r in range(rings - 2):
		ring_a = 1 + r * segments
		ring_b = ring_a + segments
		for s in range(segments):
			ns = (s + 1) % segments
			faces.append((ring_a + s, ring_b + s, ring_b + ns, ring_a + ns))
	last_ring = 1 + (rings - 2) * segments
	for s in range(segments):
		ns = (s + 1) % segments
		faces.append((bottom, last_ring + ns, last_ring + s))
	return verts, faces


def loft_verts(path, radii, segments=16):
	verts = []
	faces = []
	ring_count = len(path)
	for i in range(ring_count):
		if i == 0:
			tangent = v_sub(path[1], path[0])
		elif i == ring_count - 1:
			tangent = v_sub(path[i], path[i - 1])
		else:
			tangent = v_sub(path[i + 1], path[i - 1])
		tangent = v_norm(tangent)
		ref = (0.0, 0.0, 1.0)
		if abs(v_dot(tangent, ref)) > 0.9:
			ref = (1.0, 0.0, 0.0)
		side = v_norm(v_cross(tangent, ref))
		up = v_norm(v_cross(side, tangent))
		radius = radii[i]
		for s in range(segments):
			angle = (s / segments) * math.tau
			offset = v_add(v_mul(side, math.cos(angle) * radius), v_mul(up, math.sin(angle) * radius))
			verts.append(v_add(path[i], offset))
	for i in range(ring_count - 1):
		for s in range(segments):
			ns = (s + 1) % segments
			faces.append((
				i * segments + s, i * segments + ns,
				(i + 1) * segments + ns, (i + 1) * segments + s,
			))
	bottom_center = len(verts)
	verts.append(path[0])
	top_center = len(verts)
	verts.append(path[ring_count - 1])
	for s in range(segments):
		ns = (s + 1) % segments
		faces.append((bottom_center, ns, s))
		base = (ring_count - 1) * segments
		faces.append((top_center, base + s, base + ns))
	return verts, faces


def pod_scale(scale, origin=(0.0, 0.0, 0.0), rot=None):
	verts, faces = sphere_verts(1.0, 24, 14)
	out = []
	for v in verts:
		p = (v[0] * scale[0], v[1] * scale[1], v[2] * scale[2])
		out.append((p[0] + origin[0], p[1] + origin[1], p[2] + origin[2]))
	return out, faces


def hull_verts():
	verts, faces = sphere_verts(1.0, 52, 30)
	out = []
	for v in verts:
		x = v[0] * 1.16
		y = v[1] * 0.6
		z = v[2] * 1.62
		floor = -0.3
		if y < floor:
			y = floor + (y - floor) * 0.16
		nose = clampf((-z - 0.45) / 1.1, 0.0, 1.0)
		x *= 1.0 - 0.55 * nose * nose
		y -= 0.12 * nose
		if y > 0.0:
			y += 0.1 * nose * y
		rear = clampf((z - 0.7) / 0.9, 0.0, 1.0)
		x *= 1.0 - 0.32 * rear * rear
		if y > 0.0:
			crown = 1.0 - abs(z) / 1.62
			y += 0.07 * crown
		out.append((x, y, z))
	return out, faces


PARTS = []


def part(target, mat_name, verts_g, faces_g, local_g, bevel=0.0, smooth=False):
	PARTS.append({
		"target": target,
		"mat": mat_name,
		"verts": verts_g,
		"faces": faces_g,
		"local": local_g,
		"bevel": bevel,
		"smooth": smooth,
	})


def box_part(target, mat_name, size, origin, rot=None, bevel=0.02):
	verts, faces = box_verts(size)
	local = translate_g(origin)
	if rot is not None:
		local = local @ mat4(rot)
	part(target, mat_name, verts, faces, local, bevel, False)


def cyl_part(target, mat_name, radius, length, origin, rot=None, segments=16,
		radius_top=None, bevel=0.0):
	verts, faces = cyl_verts(radius, length, segments, radius_top)
	local = translate_g(origin)
	if rot is not None:
		local = local @ mat4(rot)
	part(target, mat_name, verts, faces, local, bevel, False)


def sph_part(target, mat_name, radius, origin, scale=None, rot=None):
	if scale is None:
		verts, faces = sphere_verts(radius, 24, 14)
	else:
		verts, faces = pod_scale((radius * scale[0], radius * scale[1], radius * scale[2]))
	local = translate_g(origin)
	if rot is not None:
		local = local @ mat4(rot)
	part(target, mat_name, verts, faces, local, 0.0, True)


def loft_part(target, mat_name, path, radii, origin=(0.0, 0.0, 0.0), rot=None,
		segments=16):
	verts, faces = loft_verts(path, radii, segments)
	local = translate_g(origin)
	if rot is not None:
		local = local @ mat4(rot)
	part(target, mat_name, verts, faces, local, 0.0, True)


def cone_part(target, mat_name, radius_base, radius_tip, length, origin, rot=None):
	verts, faces = cyl_verts(radius_base, length, 12, radius_tip)
	local = translate_g(origin)
	if rot is not None:
		local = local @ mat4(rot)
	part(target, mat_name, verts, faces, local, 0.0, False)


def build_chassis():
	t = "chassis"
	verts, faces = hull_verts()
	part(t, "m_primary", verts, faces, translate_g((0.0, 0.05, 0.0)), 0.0, True)
	sph_part(t, "m_secondary", 1.0, (0.0, 0.52, 0.1), scale=(0.78, 0.16, 1.18), rot=rot_x(-3.0))
	sph_part(t, "m_accent", 1.0, (0.0, 0.46, -1.02), scale=(0.9, 0.1, 0.5), rot=rot_x(-16.0))
	sph_part(t, "m_accent", 1.0, (0.0, 0.66, 0.55), scale=(0.3, 0.14, 0.42), rot=rot_x(-6.0))
	sph_part(t, "m_secondary", 1.0, (0.0, 0.6, 0.98), scale=(0.26, 0.12, 0.36), rot=rot_x(-10.0))
	sph_part(t, "m_accent", 1.0, (0.0, 0.52, 1.32), scale=(0.2, 0.1, 0.28), rot=rot_x(-14.0))
	for vent in range(4):
		box_part(t, "m_recess", (1.0, 0.06, 0.07),
			(0.0, -0.08 + vent * 0.15, 1.52), None, 0.008)
	cyl_part(t, "m_joint", 0.3, 1.7, (0.0, -0.44, 0.15), rot_x(90.0), 14)
	sph_part(t, "m_primary", 1.0, (0.0, -0.34, 0.2), scale=(0.82, 0.16, 1.05))
	for side in (1.0, -1.0):
		sph_part(t, "m_primary", 1.0, (side * 1.1, 0.02, -0.05),
			scale=(0.14, 0.5, 1.15), rot=rot_z(side * -8.0))
		sph_part(t, "m_accent", 1.0, (side * 1.18, 0.28, -0.1),
			scale=(0.08, 0.2, 0.85), rot=rot_z(side * -14.0))
		sph_part(t, "m_recess", 1.0, (side * 1.22, 0.1, 0.72),
			scale=(0.05, 0.22, 0.45))
		sph_part(t, "m_secondary", 1.0, (side * 1.24, -0.18, -1.0),
			scale=(0.3, 0.34, 0.55), rot=rot_z(side * -6.0))
		sph_part(t, "m_secondary", 1.0, (side * 1.26, -0.18, 1.02),
			scale=(0.3, 0.34, 0.55), rot=rot_z(side * -6.0))
		sph_part(t, "m_primary", 1.0, (side * 1.34, 0.16, HIP_POS[0 if side > 0.0 else 1][2]),
			scale=(0.42, 0.4, 0.66), rot=rot_z(side * -10.0))
		sph_part(t, "m_primary", 1.0, (side * 1.36, 0.16, HIP_POS[2 if side > 0.0 else 3][2]),
			scale=(0.42, 0.4, 0.66), rot=rot_z(side * -10.0))
		box_part(t, "m_joint", (0.44, 0.34, 0.5), (side * 1.06, 0.3, -0.72), None, 0.025)
		box_part(t, "m_joint", (0.44, 0.34, 0.5), (side * 1.14, 0.34, 0.62), None, 0.025)
		sph_part(t, "m_primary", 1.0, (side * 0.9, 0.1, -1.1),
			scale=(0.34, 0.3, 0.5), rot=euler_g(0.0, side * -14.0, side * -8.0))
		cone_part(t, "m_accent", 0.16, 0.03, 0.55, (side * 0.55, -0.2, -1.55),
			euler_g(-118.0, side * -12.0, 0.0))
		cyl_part(t, "m_trim", 0.13, 0.7, (side * 0.55, 0.5, 1.24), rot_x(35.0), 12)
		cyl_part(t, "m_recess", 0.15, 0.12, (side * 0.55, 0.8, 1.46), rot_x(35.0), 12)
		box_part(t, "m_sensor", (0.05, 0.06, 0.8), (side * 1.24, 0.1, -0.15), None, 0.008)
		box_part(t, "m_sensor", (0.05, 0.06, 0.45), (side * 1.24, -0.12, 0.5), None, 0.008)
		sph_part(t, "m_secondary", 1.0, (side * 1.16, -0.3, 0.0),
			scale=(0.16, 0.28, 0.95))


def build_head():
	t = "head"
	sph_part(t, "m_primary", 1.0, (0.0, 0.0, 0.0), scale=(0.5, 0.27, 0.4))
	sph_part(t, "m_accent", 1.0, (0.0, 0.18, -0.16), scale=(0.54, 0.09, 0.3),
		rot=rot_x(-16.0))
	box_part(t, "m_recess", (0.72, 0.2, 0.14), (0.0, -0.02, -0.3), None, 0.015)
	box_part(t, "m_sensor", (0.54, 0.075, 0.06), (0.0, 0.03, -0.375), None, 0.006)
	sph_part(t, "m_sensor", 1.0, (0.21, 0.03, -0.37), scale=(0.06, 0.05, 0.045))
	sph_part(t, "m_sensor", 1.0, (-0.21, 0.03, -0.37), scale=(0.06, 0.05, 0.045))
	sph_part(t, "m_secondary", 1.0, (0.0, -0.24, -0.14), scale=(0.34, 0.1, 0.24),
		rot=rot_x(14.0))
	for side in (1.0, -1.0):
		sph_part(t, "m_secondary", 1.0, (side * 0.45, -0.02, -0.06),
			scale=(0.12, 0.19, 0.27), rot=rot_z(side * -12.0))
		cyl_part(t, "m_trim", 0.09, 0.26, (side * 0.5, 0.12, 0.04), rot_z(-90.0), 12)
		cone_part(t, "m_accent", 0.07, 0.015, 0.3, (side * 0.34, -0.24, -0.3),
			euler_g(-125.0, side * -8.0, 0.0))
	sph_part(t, "m_joint", 1.0, (0.0, 0.24, 0.06), scale=(0.13, 0.11, 0.13))
	cyl_part(t, "m_trim", 0.025, 0.46, (0.3, 0.44, 0.1), euler_g(8.0, -10.0, 0.0), 8)
	sph_part(t, "m_sensor", 1.0, (0.34, 0.67, 0.05), scale=(0.05, 0.05, 0.05))


def build_tail():
	for index in range(4):
		t = "tail%d" % index
		radius = TAIL_RAD[index]
		length = TAIL_LEN[index]
		path = [
			(0.0, 0.0, 0.0),
			(0.0, 0.0, length * 0.35),
			(0.0, 0.0, length * 0.7),
			(0.0, 0.0, length * 0.94),
		]
		radii = [radius * 1.04, radius * 1.2, radius * 1.0, radius * 0.86]
		loft_part(t, "m_primary" if index % 2 == 0 else "m_secondary",
			path, radii, segments=18)
		sph_part(t, "m_joint", 1.0, (0.0, 0.0, 0.0), scale=(
			radius * 1.15, radius * 1.15, radius * 1.15))
		sph_part(t, "m_accent" if index % 2 == 0 else "m_primary", 1.0,
			(0.0, radius * 0.72, length * 0.48),
			scale=(radius * 0.9, 0.1, length * 0.34), rot=rot_x(-4.0))
		sph_part(t, "m_secondary", 1.0, (0.0, -radius * 0.68, length * 0.46),
			scale=(radius * 0.7, 0.08, length * 0.3), rot=rot_x(4.0))
		for side in (1.0, -1.0):
			sph_part(t, "m_trim", 1.0, (side * radius * 0.95, 0.0, length * 0.45),
				scale=(0.05, radius * 0.5, length * 0.3))
	t = "stinger"
	sph_part(t, "m_joint", 1.0, (0.0, 0.0, 0.06), scale=(0.2, 0.2, 0.24))
	sph_part(t, "m_accent", 1.0, (0.0, 0.08, 0.1), scale=(0.17, 0.12, 0.17))
	cone_part(t, "m_trim", 0.14, 0.012, 0.95, (0.0, 0.0, 0.6), rot_x(90.0))
	sph_part(t, "m_sensor", 1.0, (0.0, 0.0, 1.08), scale=(0.05, 0.05, 0.05))


def build_legs():
	for index in range(4):
		c = "l%dc" % index
		sph_part(c, "m_joint", 1.0, (0.0, 0.0, 0.0), scale=(0.21, 0.21, 0.21))
		loft_part(c, "m_trim", [(0.0, 0.0, 0.0), (0.0, 0.14, 0.0), (0.0, 0.28, 0.0)],
			[0.15, 0.13, 0.115], segments=14)
		sph_part(c, "m_primary", 1.0, (0.0, 0.15, 0.0), scale=(0.16, 0.15, 0.2))
		u = "l%du" % index
		loft_part(u, "m_primary", [
			(0.0, 0.0, 0.0), (0.02, 0.4, 0.03), (0.01, 0.8, 0.01), (0.0, 1.15, 0.0),
		], [0.15, 0.19, 0.155, 0.115], segments=18)
		sph_part(u, "m_accent", 1.0, (0.01, 0.5, 0.05), scale=(0.13, 0.3, 0.1))
		cyl_part(u, "m_accent", 0.2, 0.08, (0.0, 0.34, 0.0), None, 18)
		for side in (1.0, -1.0):
			cyl_part(u, "m_trim", 0.045, 0.6, (side * 0.19, 0.42, 0.0), None, 10)
			cyl_part(u, "m_joint", 0.028, 0.36, (side * 0.19, 0.85, 0.0), None, 8)
		sph_part(u, "m_joint", 1.0, (0.0, 1.15, 0.0), scale=(0.19, 0.19, 0.19))
		cyl_part(u, "m_accent", 0.12, 0.1, (0.0, 1.15, 0.0), rot_x(90.0), 14)
		l = "l%dl" % index
		loft_part(l, "m_primary", [
			(0.0, 0.0, 0.0), (0.0, 0.45, -0.02), (0.0, 0.9, -0.01), (0.0, 1.35, 0.0),
		], [0.13, 0.15, 0.115, 0.09], segments=16)
		sph_part(l, "m_secondary", 1.0, (0.0, 0.5, -0.07), scale=(0.09, 0.3, 0.08))
		cyl_part(l, "m_accent", 0.15, 0.07, (0.0, 0.42, 0.0), None, 16)
		for side in (1.0, -1.0):
			cyl_part(l, "m_trim", 0.036, 0.6, (side * 0.13, 0.5, 0.03), None, 10)
		sph_part(l, "m_joint", 1.0, (0.0, 1.35, 0.0), scale=(0.12, 0.12, 0.12))
		f = "l%df" % index
		sph_part(f, "m_joint", 1.0, (0.0, 0.08, 0.0), scale=(0.09, 0.1, 0.09))
		sph_part(f, "m_recess", 1.0, (0.0, -0.04, 0.0), scale=(0.18, 0.07, 0.22))
		sph_part(f, "m_joint", 1.0, (0.0, 0.0, 0.02), scale=(0.14, 0.04, 0.18))
		claw_x = (-0.11, 0.0, 0.11)
		for cx in claw_x:
			yaw = -12.0 if cx > 0.0 else (12.0 if cx < 0.0 else 0.0)
			cone_part(f, "m_joint", 0.055, 0.006, 0.26, (cx, -0.01, -0.22),
				euler_g(-85.0, yaw, 0.0))
		cone_part(f, "m_joint", 0.05, 0.006, 0.2, (0.0, -0.02, 0.22), rot_x(95.0))


def build_guns():
	for index in range(4):
		t = "gun%d" % index
		side = SOCK_SIDE[index]
		razor = index < 2
		cyl_rot = rot_z(-90.0) if side > 0.0 else rot_z(90.0)
		box_part(t, "m_joint", (0.3, 0.3, 0.3), (side * 0.1, 0.0, 0.0), None, 0.03)
		box_part(t, "m_recess", (0.34, 0.26, 0.5), (side * 0.2, 0.04, 0.0), None, 0.03)
		if razor:
			box_part(t, "m_trim", (0.5, 0.3, 0.34), (side * 0.3, 0.02, 0.0), None, 0.045)
			box_part(t, "m_joint", (0.44, 0.07, 0.22), (side * 0.34, 0.19, 0.0), None, 0.015)
			box_part(t, "m_sensor", (0.3, 0.03, 0.05), (side * 0.34, 0.21, 0.12), None, 0.006)
			box_part(t, "m_sensor", (0.3, 0.03, 0.05), (side * 0.34, 0.21, -0.12), None, 0.006)
			cyl_part(t, "m_joint", 0.07, 0.95, (side * 0.99, 0.02, 0.0), cyl_rot, 14)
			cyl_part(t, "m_recess", 0.1, 0.5, (side * 0.75, 0.02, 0.0), cyl_rot, 16)
			cyl_part(t, "m_trim", 0.13, 0.16, (side * 1.32, 0.02, 0.0), cyl_rot, 14)
			cyl_part(t, "m_trim", 0.11, 0.06, (side * 1.4, 0.02, 0.0), cyl_rot, 14)
			cyl_part(t, "m_joint", 0.14, 0.34, (side * 0.16, -0.2, 0.0), cyl_rot, 16)
			box_part(t, "m_trim", (0.1, 0.2, 0.28), (side * 0.3, 0.19, 0.0), None, 0.02)
		else:
			box_part(t, "m_trim", (0.46, 0.34, 0.4), (side * 0.26, 0.02, 0.0), None, 0.05)
			box_part(t, "m_joint", (0.4, 0.08, 0.3), (side * 0.28, 0.2, 0.0), None, 0.015)
			box_part(t, "m_sensor", (0.26, 0.03, 0.05), (side * 0.28, 0.23, 0.14), None, 0.006)
			box_part(t, "m_sensor", (0.26, 0.03, 0.05), (side * 0.28, 0.23, -0.14), None, 0.006)
			for z_off in (-0.09, 0.09):
				cyl_part(t, "m_joint", 0.068, 0.66, (side * 0.79, 0.0, z_off), cyl_rot, 14)
				cyl_part(t, "m_trim", 0.08, 0.1, (side * 1.06, 0.0, z_off), cyl_rot, 14)
			cyl_part(t, "m_recess", 0.13, 0.4, (side * 0.6, 0.0, 0.0), cyl_rot, 16)
			cyl_part(t, "m_joint", 0.19, 0.36, (side * 0.16, -0.24, 0.0), cyl_rot, 16)
			for fin in range(3):
				box_part(t, "m_trim", (0.05, 0.22, 0.3),
					(side * (0.14 + fin * 0.1), 0.2, 0.0), None, 0.012)
		box_part(t, "m_trim", (0.16, 0.1, 0.16), (side * 0.5, -0.1, 0.0), None, 0.02)


def make_material(name):
	color, metallic, roughness, emission, strength = MAT_SPECS[name]
	material = bpy.data.materials.new(name)
	material.use_nodes = True
	bsdf = material.node_tree.nodes.get("Principled BSDF")
	bsdf.inputs["Base Color"].default_value = color
	bsdf.inputs["Metallic"].default_value = metallic
	bsdf.inputs["Roughness"].default_value = roughness
	if emission is not None:
		if "Emission Color" in bsdf.inputs:
			bsdf.inputs["Emission Color"].default_value = (
				emission[0], emission[1], emission[2], 1.0)
			bsdf.inputs["Emission Strength"].default_value = strength
		else:
			bsdf.inputs["Emission"].default_value = (
				emission[0], emission[1], emission[2], 1.0)
	return material


def add_box_uvs(mesh):
	uv_layer = mesh.uv_layers.new(name="UVMap")
	verts = mesh.vertices
	for poly in mesh.polygons:
		normal = poly.normal
		ax = abs(normal.x)
		ay = abs(normal.y)
		az = abs(normal.z)
		if ax >= ay and ax >= az:
			axis = 0
		elif ay >= az:
			axis = 1
		else:
			axis = 2
		for loop_index in poly.loop_indices:
			co = verts[mesh.loops[loop_index].vertex_index].co
			if axis == 0:
				u, v = co.y, co.z
			elif axis == 1:
				u, v = co.x, co.z
			else:
				u, v = co.x, co.y
			uv_layer.data[loop_index].uv = (u * 0.5, v * 0.5)


def build_mesh(spec):
	mesh = bpy.data.meshes.new(spec["target"])
	verts_b = [to_b_point(v) for v in spec["verts"]]
	mesh.from_pydata(verts_b, [], spec["faces"])
	mesh.validate()
	bm = bmesh.new()
	bm.from_mesh(mesh)
	bmesh.ops.recalc_face_normals(bm, faces=bm.faces)
	bm.to_mesh(mesh)
	bm.free()
	mesh.update()
	add_box_uvs(mesh)
	if spec["smooth"]:
		for poly in mesh.polygons:
			poly.use_smooth = True
	return mesh


def construct(builders=None, poses_fn=None, out_path=None):
	if out_path is None:
		out_path = OUT_PATH
	scene = bpy.context.scene
	for obj in list(bpy.data.objects):
		bpy.data.objects.remove(obj, do_unlink=True)
	materials = {}
	for name in MAT_SPECS:
		materials[name] = make_material(name)
	empties = (poses_fn if poses_fn is not None else build_poses)()
	for builder in (builders if builders is not None else
			[build_chassis, build_head, build_tail, build_legs, build_guns]):
		builder()
	empty_objs = {}
	for key, pose in empties.items():
		obj = bpy.data.objects.new("pose_" + key, None)
		obj.empty_display_size = 0.2
		obj.matrix_world = conj_g2b(pose)
		scene.collection.objects.link(obj)
		empty_objs[key] = obj
	for spec in PARTS:
		mesh = build_mesh(spec)
		mesh.materials.append(materials[spec["mat"]])
		obj = bpy.data.objects.new(spec["target"], mesh)
		obj.matrix_basis = conj_g2b(spec["local"])
		obj.parent = empty_objs[spec["target"]]
		scene.collection.objects.link(obj)
		if spec["bevel"] > 0.0:
			modifier = obj.modifiers.new("Bevel", "BEVEL")
			modifier.width = spec["bevel"]
			# 2 segments keeps the chamfer catching light while cutting ~35%
			# of the bevel's triangle cost (a beveled box was 188 tris at 3).
			modifier.segments = 2
			modifier.limit_method = "ANGLE"
			modifier.angle_limit = math.radians(40.0)
	for obj in bpy.data.objects:
		if obj.type != "MESH" or not obj.modifiers:
			continue
		for modifier in list(obj.modifiers):
			bpy.context.view_layer.objects.active = obj
			obj.select_set(True)
			bpy.ops.object.modifier_apply(modifier=modifier.name)
			obj.select_set(False)
	groups = {}
	for obj in bpy.data.objects:
		if obj.type != "MESH":
			continue
		material = obj.data.materials[0] if obj.data.materials else None
		key = (obj.parent.name if obj.parent else "", material.name if material else "")
		groups.setdefault(key, []).append(obj)
	joined = []
	for key, objects in groups.items():
		for obj in objects:
			obj.select_set(True)
		bpy.context.view_layer.objects.active = objects[0]
		bpy.ops.object.join()
		active = bpy.context.view_layer.objects.active
		bpy.ops.object.material_slot_remove_unused()
		target_key = key[0][len("pose_"):]
		active.name = "%s__%s" % (target_key, key[1])
		active.data.name = active.name
		basis = active.matrix_basis.copy()
		active.parent = None
		active.matrix_world = basis
		joined.append(active)
		for obj in bpy.data.objects:
			obj.select_set(False)
	for key in empty_objs:
		bpy.data.objects.remove(empty_objs[key], do_unlink=True)
	for obj in joined:
		obj.select_set(True)
	bpy.context.view_layer.objects.active = joined[0]
	os.makedirs(os.path.dirname(out_path), exist_ok=True)
	export_kwargs = {
		"filepath": out_path,
		"export_format": "GLB",
		"use_selection": True,
		"export_apply": True,
		"export_animations": False,
		"export_cameras": False,
		"export_lights": False,
		"export_yup": True,
	}
	rna_props = {prop.identifier for prop in
		bpy.ops.export_scene.gltf.get_rna_type().properties}
	filtered = {k: v for k, v in export_kwargs.items() if k in rna_props}
	bpy.ops.export_scene.gltf(**filtered)
	tris = 0
	for obj in joined:
		tris += len(obj.data.polygons)
	print("build_mech: %d objects, %d tris -> %s" % (len(joined), tris, out_path))


if __name__ == "__main__":
	construct()
