extends Node

func _ready() -> void:
	var scene := load("res://assets/mech_kit/Mech/SK_ISO_Mech.fbx") as PackedScene
	if scene == null:
		print("PROBE no scene")
		get_tree().quit(1)
		return
	var inst := scene.instantiate()
	add_child(inst)
	for node in inst.find_children("*", "MeshInstance3D", true, false):
		var mesh_node := node as MeshInstance3D
		if mesh_node == null or mesh_node.mesh == null:
			continue
		for surface in mesh_node.mesh.get_surface_count():
			var arrays := mesh_node.mesh.surface_get_arrays(surface)
			var verts: Variant = arrays[Mesh.ARRAY_VERTEX]
			var uvs: Variant = arrays[Mesh.ARRAY_TEX_UV]
			var uv_count := 0
			if uvs is PackedVector2Array:
				uv_count = (uvs as PackedVector2Array).size()
			var vert_count := 0
			if verts is PackedVector3Array:
				vert_count = (verts as PackedVector3Array).size()
			var uv_sample := Vector2(-1.0, -1.0)
			if uv_count > 0:
				uv_sample = (uvs as PackedVector2Array)[uv_count / 2]
			print("PROBE ", mesh_node.name, " surf", surface, " verts=", vert_count,
					" uvs=", uv_count, " mid_uv=", uv_sample)
	get_tree().quit(0)
