extends Node

func _ready() -> void:
	var rig_script := load("res://src/player/iso_mech_rig.gd") as GDScript
	if rig_script == null:
		print("PROBE: script load FAILED")
		get_tree().quit(1)
		return
	var rig: Node3D = rig_script.new() as Node3D
	add_child(rig)
	var meshes := rig.find_children("*", "MeshInstance3D", true, false)
	print("PROBE: meshes=", meshes.size())
	for m in meshes:
		var mi := m as MeshInstance3D
		if mi == null or mi.mesh == null:
			continue
		for s in mi.mesh.get_surface_count():
			var mat := mi.get_active_material(s)
			if mat == null:
				print("  ", mi.name, " surf", s, ": NULL MATERIAL (default white path)")
				continue
			if not (mat is StandardMaterial3D):
				print("  ", mi.name, " surf", s, ": NON-STANDARD ", mat.get_class())
				continue
			var std := mat as StandardMaterial3D
			var tex := "-"
			if std.albedo_texture != null:
				tex = str(std.albedo_texture.resource_path)
			print("  %s surf%d vis=%s tex=%s tint=%s emis=%s ecol=%s eenergy=%.2f metal=%.2f rough=%.2f" % [
				mi.name, s, str(mi.visible), tex, str(std.albedo_color),
				str(std.emission_enabled), str(std.emission),
				std.emission_energy_multiplier, std.metallic, std.roughness])
	print("PROBE report: ", (rig as IsoMechRig).texture_report() if rig is IsoMechRig else "n/a")
	get_tree().quit(0)
