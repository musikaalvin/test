extends Node
## Headless UI dump: walks the menu tree in every screen state and writes
## build/ui_dump.json so tools/render_ui.py can rasterize our screens
## for visual QA against the director's War Robots references (no GPU).

const OUT := "res://build/ui_dump.json"
const SETTLE := 4


func _ready() -> void:
	await _run()
	get_tree().quit(0)


func _run() -> void:
	var packed: PackedScene = load("res://scenes/main_menu.tscn")
	var menu: Control = packed.instantiate()
	add_child(menu)
	for i in SETTLE:
		await get_tree().process_frame
	var ui: UIManager = menu.get_node("UI") as UIManager
	var vp: Vector2 = menu.get_viewport_rect().size
	var doc: Dictionary = {
		"meta": {"viewport": [vp.x, vp.y]},
		"screens": {},
	}
	var shots: Array = [
		["hangar", {}],
		["robot", {}],
		["weapon_select", {"robot": GameState.selected_robot, "slot": 0}],
		["weapon_detail", {"item": "RAZOR-M", "robot": GameState.selected_robot, "slot": 0}],
		["upgrade", {"key": "SCARAB:0", "is_body": false}],
		["store", {}],
		["inventory", {}],
		["settings", {}],
		["pilot", {}],
		["drone", {}],
		["spec", {}],
		["stats", {}],
		["game_modes", {"page": "game_modes"}],
	]
	for shot_variant in shots:
		var shot: Array = shot_variant
		var id: String = shot[0]
		var params: Dictionary = shot[1]
		if id != "hangar":
			ui.push(StringName(id), params)
			for i in SETTLE:
				await get_tree().process_frame
		var entries: Array = []
		_walk(menu, menu, entries)
		doc["screens"][id] = entries
		print("dumped %s (%d controls)" % [id, entries.size()])
		if id != "hangar":
			ui.pop()
			for i in 2:
				await get_tree().process_frame
	var file := FileAccess.open(OUT, FileAccess.WRITE)
	file.store_string(JSON.stringify(doc, "  "))
	file.close()
	print("UI_DUMP_DONE -> %s" % OUT)


func _walk(root: Node, node: Node, out: Array) -> void:
	if node is Control:
		var control := node as Control
		if control.is_visible_in_tree():
			var entry := _entry(root, control)
			if not entry.is_empty():
				out.append(entry)
	for child in node.get_children():
		_walk(root, child, out)


func _entry(root: Node, control: Control) -> Dictionary:
	var e := {}
	e["name"] = String(control.name)
	e["path"] = String(root.get_path_to(control))
	e["cls"] = control.get_class()
	var r := control.get_global_rect()
	e["rect"] = [r.position.x, r.position.y, r.size.x, r.size.y]
	if control is SubViewportContainer:
		e["vp"] = true
		return e
	if control is ColorRect:
		e["color"] = _rgba((control as ColorRect).color)
	if control.modulate != Color.WHITE:
		e["mod"] = _rgba(control.modulate)
	if "text" in control:
		var text: String = String((control as Object).get("text"))
		if not text.is_empty():
			e["text"] = text
			e["fs"] = control.get_theme_font_size(&"font_size")
			e["fcol"] = _rgba(control.get_theme_color(&"font_color"))
			var align := 0
			if control is Button and (control as Button).alignment == HORIZONTAL_ALIGNMENT_CENTER:
				align = 1
			elif control is Label:
				align = (control as Label).horizontal_alignment
			e["align"] = align
	if control is ProgressBar:
		var bar := control as ProgressBar
		if bar.max_value > bar.min_value:
			e["ratio"] = (bar.value - bar.min_value) / (bar.max_value - bar.min_value)
		var fill := bar.get_theme_stylebox(&"fill")
		if fill is StyleBoxFlat:
			e["fill"] = _rgba((fill as StyleBoxFlat).bg_color)
	var sb_prop := _sb_prop(control)
	if sb_prop != "":
		var sb := control.get_theme_stylebox(StringName(sb_prop))
		if sb is StyleBoxFlat:
			var flat := sb as StyleBoxFlat
			e["sb"] = {
				"bg": _rgba(flat.bg_color),
				"border": _rgba(flat.border_color),
				"bw": [float(flat.border_width_left), float(flat.border_width_top),
						float(flat.border_width_right), float(flat.border_width_bottom)],
				"r": [float(flat.corner_radius_top_left), float(flat.corner_radius_top_right),
						float(flat.corner_radius_bottom_right), float(flat.corner_radius_bottom_left)],
			}
	if control is TextureRect:
		var tex := (control as TextureRect).texture
		if tex is GradientTexture2D:
			var grad: Gradient = (tex as GradientTexture2D).gradient
			e["gradient"] = {
				"colors": _colors(grad.colors),
				"offsets": Array(grad.offsets),
			}
	var script := control.get_script() as Script
	if script is GDScript:
		var source: String = (script as GDScript).source_code
		if source.find("func _draw(") != -1:
			e["custom"] = true
	return e


func _sb_prop(control: Control) -> String:
	if control is Button:
		return "normal"
	if control is ProgressBar:
		return "background"
	if control is PanelContainer or control is Panel:
		return "panel"
	if control is LineEdit:
		return "normal"
	if control is TabContainer:
		return "panel"
	return ""


func _rgba(c: Color) -> Array:
	return [c.r, c.g, c.b, c.a]


func _colors(list: PackedColorArray) -> Array:
	var out := []
	for c in list:
		out.append(_rgba(c))
	return out
