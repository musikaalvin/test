extends Node

# Diagnoses the synthetic paint-swatch click: which control actually sits
# under the event, whether the press is grabbed, and where the palette ends up.

func _ready() -> void:
	# Replicate smoke: the game scene sits under the menu with its layers.
	var game := (load("res://scenes/game.tscn") as PackedScene).instantiate() as Node3D
	add_child(game)
	var menu := (load("res://scenes/main_menu.tscn") as PackedScene).instantiate() as Control
	add_child(menu)
	await _frames(3)
	var ui := menu.get_node("UI") as UIManager
	ui.push(&"robot")
	await _frames(2)
	var robot := ui.screen(&"robot")
	var paint := menu.find_child("PaintButton", true, false) as Button
	paint.pressed.emit()
	await _frames(1)
	var target := (GameState.armor_palette + 1) % GameState.PALETTE_COUNT
	var swatch := menu.find_child("Swatch%d" % target, true, false) as Button
	print("PROBE swatch=", swatch.name, " rect=", swatch.get_global_rect(),
			" visible=", swatch.is_visible_in_tree())
	var vp := menu.get_viewport()
	var centre := swatch.get_global_rect().get_center()
	var screen_pos: Vector2 = vp.get_screen_transform() * centre
	print("PROBE screen_pos=", screen_pos, " vp.size=", vp.size)
	var hidden_layers: Array[CanvasLayer] = []
	for node in get_tree().root.find_children("*", "CanvasLayer", true, false):
		var canvas_layer := node as CanvasLayer
		if canvas_layer.visible:
			canvas_layer.visible = false
			hidden_layers.append(canvas_layer)
	print("PROBE hidden_layers=", hidden_layers.size())
	var motion := InputEventMouseMotion.new()
	motion.position = screen_pos
	motion.global_position = screen_pos
	vp.push_input(motion)
	var hovered := vp.gui_get_hovered_control()
	print("PROBE hovered=", hovered, " path=", hovered.get_path() if hovered != null else "-")
	var press := InputEventMouseButton.new()
	press.button_index = MOUSE_BUTTON_LEFT
	press.pressed = true
	press.position = screen_pos
	press.global_position = screen_pos
	vp.push_input(press)
	print("PROBE button_pressed=", swatch.button_pressed,
			" palette=", GameState.armor_palette)
	var release := InputEventMouseButton.new()
	release.button_index = MOUSE_BUTTON_LEFT
	release.pressed = false
	release.position = screen_pos
	release.global_position = screen_pos
	vp.push_input(release)
	await _frames(1)
	print("PROBE after palette=", GameState.armor_palette, " target=", target)
	get_tree().quit()

func _frames(count: int) -> void:
	for i in count:
		await get_tree().process_frame
