extends Node
# Prints every visible Button in the touch rig at 1280x720 for SCARAB + PRAETOR.

func _ready() -> void:
	await _probe(GameState.ROBOT_SCARAB)
	await _probe(GameState.ROBOT_PRAETOR)
	get_tree().quit(0)

func _probe(robot: StringName) -> void:
	var saved := GameState.selected_robot
	GameState.selected_robot = robot
	var tc := TouchControls.new()
	tc.name = "ProbeTouch"
	add_child(tc)
	tc.size = Vector2(1280.0, 720.0)
	tc.visible = true
	tc._layout_panel()
	await get_tree().process_frame
	await get_tree().process_frame
	print("=== %s ===" % String(robot))
	_dump(tc, tc)
	tc.queue_free()
	await get_tree().process_frame
	GameState.selected_robot = saved

func _dump(node: Node, root: Control) -> void:
	for child in node.get_children():
		if child is Button:
			var b := child as Button
			if b.visible:
				var r := b.get_global_rect()
				print("  %-28s text=%-10s rect=(%.0f,%.0f %.0fx%.0f)" % [
					b.name, b.text.replace("\n", "|"),
					r.position.x, r.position.y, r.size.x, r.size.y])
		_dump(child, root)
