extends Node
## Memory probe: loads the game scene headlessly, settles, prints memory
## monitors + the import format/size of the heavy PBR textures.

func _ready() -> void:
	print("MEM_PROBE start")
	var packed: PackedScene = load("res://scenes/game.tscn") as PackedScene
	var game: Node = packed.instantiate()
	add_child(game)
	for i in 150:
		await get_tree().physics_frame
	_report("game_loaded")
	_probe_texture("res://assets/textures/pbr/forest_ground/albedo.jpg")
	_probe_texture("res://assets/textures/pbr/forest_ground/normal.jpg")
	_probe_texture("res://assets/textures/pbr/asphalt/albedo.jpg")
	_probe_texture("res://assets/maps/downtown/Textures/T_Dirt_Normal.png")
	get_tree().quit(0)


func _report(tag: String) -> void:
	var mb := 1048576.0
	print("MEM_PROBE %s static_mb=%.1f" % [
		tag, Performance.get_monitor(Performance.MEMORY_STATIC) / mb])
	print("MEM_PROBE %s static_max_mb=%.1f" % [
		tag, Performance.get_monitor(Performance.MEMORY_STATIC_MAX) / mb])
	print("MEM_PROBE %s objects=%d" % [
		tag, int(Performance.get_monitor(Performance.OBJECT_COUNT))])
	print("MEM_PROBE %s texture_mb=%.1f" % [
		tag, Performance.get_monitor(Performance.RENDER_TEXTURE_MEM_USED) / mb])


func _probe_texture(path: String) -> void:
	var tex: Texture2D = load(path) as Texture2D
	if tex == null:
		print("MEM_PROBE tex %s FAILED_TO_LOAD" % path)
		return
	var img: Image = tex.get_image()
	if img == null:
		print("MEM_PROBE tex %s %dx%d format=<no cpu image>" % [
			path.get_file(), tex.get_width(), tex.get_height()])
		return
	var bytes: int = img.get_data().size()
	print("MEM_PROBE tex %s %dx%d format_id=%d cpu_mb=%.2f" % [
		path.get_file(), tex.get_width(), tex.get_height(),
		img.get_format(), bytes / 1048576.0])
