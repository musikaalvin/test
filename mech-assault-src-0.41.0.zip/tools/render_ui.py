#!/usr/bin/env python3
"""Rasterize build/ui_dump.json -> build/screenshots/ui/*.png.

Approximate 2D painting of the real menu layout (rects, stylebox colors,
fonts) so screen composition can be compared against reference screenshots
without a GPU.

Dump rects are [x, y, width, height] (position + size), NOT corners.
PIL's ImageDraw ignores fill alpha (even with mode="RGBA"), so entries
containing any translucent color are painted onto a transparent layer and
alpha-composited instead.
"""
import json
import os

from PIL import Image, ImageDraw, ImageFont

OUT_DIR = "build/screenshots/ui"
DUMP = "build/ui_dump.json"
FONT = "/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf"
FONT_B = "/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf"


def fcol(rgba):
    r, g, b, a = rgba
    return (int(r * 255), int(g * 255), int(b * 255), int(a * 255))


def scaled_alpha(rgba, mod):
    return [rgba[0], rgba[1], rgba[2], rgba[3] * mod[3]]


def mkdraw(img):
    d = ImageDraw.Draw(img, "RGBA")
    d._image = img
    return d


def draw_gradient(draw, rect, colors, offsets):
    x0, y0, x1, y1 = rect
    w, h = max(1, int(x1 - x0)), max(1, int(y1 - y0))
    strip = Image.new("RGBA", (1, h))
    px = strip.load()
    for y in range(h):
        t = y / max(1, h - 1)
        seg = 0
        for i in range(len(offsets) - 1):
            if offsets[i] <= t <= offsets[i + 1]:
                seg = i
                break
        else:
            seg = len(offsets) - 2 if len(offsets) > 1 else 0
        if len(offsets) > 1:
            span = max(1e-6, offsets[seg + 1] - offsets[seg])
            k = min(1.0, max(0.0, (t - offsets[seg]) / span))
        else:
            k = 0.0
        c0, c1 = colors[seg], colors[min(seg + 1, len(colors) - 1)]
        px[0, y] = tuple(int((c0[i] + (c1[i] - c0[i]) * k) * 255) for i in range(4))
    wide = strip.resize((w, h))
    draw._image.paste(wide, (int(x0), int(y0)), wide)


def needs_blend(e, mod):
    if "color" in e and scaled_alpha(e["color"], mod)[3] < 1.0:
        return True
    if "sb" in e:
        sb = e["sb"]
        if scaled_alpha(sb["bg"], mod)[3] < 1.0:
            return True
        if scaled_alpha(sb["border"], mod)[3] < 1.0:
            return True
    if "text" in e:
        if scaled_alpha(e.get("fcol", [1, 1, 1, 1]), mod)[3] < 1.0:
            return True
    return False


def draw_entry(draw, e, w, h):
    px_, py_, ew, eh = [int(v) for v in e["rect"]]
    x0, y0, x1, y1 = px_, py_, px_ + ew, py_ + eh
    if x1 <= x0 or y1 <= y0:
        return
    if x1 < 0 or y1 < 0 or x0 > w or y0 > h:
        return
    mod = e.get("mod", [1, 1, 1, 1])
    if "gradient" in e:
        g = e["gradient"]
        draw_gradient(draw, (x0, y0, x1, y1),
                      [c[:3] + [c[3] * mod[3]] for c in g["colors"]],
                      g["offsets"])
    if "color" in e:
        c = scaled_alpha(e["color"], mod)
        if c[3] > 0:
            draw.rectangle([x0, y0, x1 - 1, y1 - 1], fill=fcol(c))
    if "sb" in e:
        sb = e["sb"]
        bg = scaled_alpha(sb["bg"], mod)
        radius = int(min(sb["r"])) if sb["r"] else 0
        if radius >= 1:
            draw.rounded_rectangle([x0, y0, x1 - 1, y1 - 1],
                                   radius=radius, fill=fcol(bg))
        elif bg[3] > 0:
            draw.rectangle([x0, y0, x1 - 1, y1 - 1], fill=fcol(bg))
        bw = sb["bw"]
        if any(bw):
            border = scaled_alpha(sb["border"], mod)
            out = fcol(border)
            if bw[1] > 0:
                draw.rectangle([x0, y0, x1 - 1, y0 + int(bw[1]) - 1], fill=out)
            if bw[3] > 0:
                draw.rectangle([x0, y1 - int(bw[3]), x1 - 1, y1 - 1], fill=out)
            if bw[0] > 0:
                draw.rectangle([x0, y0, x0 + int(bw[0]) - 1, y1 - 1], fill=out)
            if bw[2] > 0:
                draw.rectangle([x1 - int(bw[2]), y0, x1 - 1, y1 - 1], fill=out)
    if "ratio" in e and "fill" in e:
        fw = int((x1 - x0) * float(e["ratio"]))
        if fw > 0:
            draw.rectangle([x0, y0, x0 + fw, y1 - 1],
                           fill=fcol(scaled_alpha(e["fill"], mod)))
    if "vp" in e:
        draw.rectangle([x0, y0, x1 - 1, y1 - 1], fill=(21, 49, 63, 255))
        try:
            font = ImageFont.truetype(FONT, 34)
        except OSError:
            font = ImageFont.load_default()
        draw.text((x0 + (x1 - x0) // 2 - 20, y0 + (y1 - y0) // 2 - 20),
                  "3D", font=font, fill=(70, 130, 160, 255))
    if "text" in e:
        fs = max(8, int(e.get("fs", 14)))
        try:
            font = ImageFont.truetype(FONT_B if fs >= 15 else FONT, fs)
        except OSError:
            font = ImageFont.load_default()
        col = fcol(scaled_alpha(e.get("fcol", [1, 1, 1, 1]), mod))
        lines = e["text"].split("\n")
        line_h = int(fs * 1.25)
        block_h = line_h * len(lines)
        for li, line in enumerate(lines):
            if not line:
                continue
            bbox = draw.textbbox((0, 0), line, font=font)
            tw = bbox[2] - bbox[0]
            align = e.get("align", 0)
            tx = x0 + 4
            if align == 1:
                tx = x0 + max(0, (x1 - x0 - tw) // 2)
            elif align == 2:
                tx = x1 - tw - 4
            if "sb" in e or e["cls"] == "Button":
                ty = y0 + max(0, (y1 - y0 - block_h) // 2)
            else:
                ty = y0 + li * line_h + 2
            draw.text((tx, ty), line, font=font, fill=col)
    elif "sb" not in e and "color" not in e and "vp" not in e \
            and "gradient" not in e and e.get("custom"):
        draw.rectangle([x0, y0, x1 - 1, y1 - 1], outline=(60, 90, 110, 160))
        try:
            font = ImageFont.truetype(FONT, 9)
        except OSError:
            font = ImageFont.load_default()
        draw.text((x0 + 3, y0 + 2), e["name"][:28], font=font,
                  fill=(90, 130, 155, 255))


def render(screen, entries, meta):
    max_x = max([e["rect"][0] + e["rect"][2] for e in entries] + [1280])
    max_y = max([e["rect"][1] + e["rect"][3] for e in entries] + [720])
    vw, vh = meta.get("viewport", [1280, 720])
    w, h = int(max(vw, max_x)), int(max(vh, max_y))
    img = Image.new("RGBA", (w, h), (10, 18, 26, 255))
    draw = mkdraw(img)

    for e in entries:
        mod = e.get("mod", [1, 1, 1, 1])
        if needs_blend(e, mod):
            layer = Image.new("RGBA", (w, h), (0, 0, 0, 0))
            ld = mkdraw(layer)
            draw_entry(ld, e, w, h)
            img = Image.alpha_composite(img, layer)
            draw = mkdraw(img)
        else:
            draw_entry(draw, e, w, h)
    return img


def main():
    os.makedirs(OUT_DIR, exist_ok=True)
    doc = json.load(open(DUMP))
    meta = doc.get("meta", {})
    nonce = os.environ.get("UI_NONCE", "0")
    for screen, entries in doc["screens"].items():
        img = render(screen, entries, meta)
        d = ImageDraw.Draw(img, "RGBA")
        try:
            f = ImageFont.truetype(FONT_B, 28)
        except OSError:
            f = ImageFont.load_default()
        d.text((12, img.height - 40), "NONCE %s %s" % (nonce, screen),
               font=f, fill=(255, 0, 255, 255))
        path = os.path.join(OUT_DIR, "%s.png" % screen)
        img.save(path)
        print("rendered %-16s %dx%d  %3d controls -> %s"
              % (screen, img.width, img.height, len(entries), path))


if __name__ == "__main__":
    main()
