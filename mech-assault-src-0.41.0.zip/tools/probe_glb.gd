extends SceneTree

func _initialize() -> void:
	var game: PackedScene = load("res://scenes/game.tscn")
	var root_node := game.instantiate()
	root.add_child(root_node)
	var rig: Node3D = root_node.get_node_or_null("Player/Visuals/RobotRig") as Node3D
	print("PROBE rig=", rig)
	if rig == null:
		quit(1)
		return
	print("PROBE script=", rig.get_script())
	print("PROBE children=", rig.get_child_count())
	for i in range(mini(rig.get_child_count(), 12)):
		var c := rig.get_child(i)
		print("PROBE child ", i, " ", c.name, " ", c.get_class())
	var packed := load("res://assets/mech/hero_mech.glb")
	print("PROBE glb=", packed)
	if packed != null:
		var shell: Node = (packed as PackedScene).instantiate()
		print("PROBE shell_children=", shell.get_child_count())
		for i in range(mini(shell.get_child_count(), 6)):
			print("PROBE glb_child ", shell.get_child(i).name, " ", shell.get_child(i).get_class())
		shell.free()
	var all := rig.find_children("*", "", true, false)
	print("PROBE find_all=", all.size())
	var meshes := rig.find_children("*", "MeshInstance3D", true, false)
	print("PROBE find_meshes=", meshes.size())
	quit(0)
