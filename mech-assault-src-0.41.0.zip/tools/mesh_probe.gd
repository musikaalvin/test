extends Node

const SETTLE_FRAMES := 75

var _game: Node3D
var _frames: int = 0

func _ready() -> void:
	for arg in OS.get_cmdline_user_args():
		if arg == "vortex":
			GameState.selected_robot = &"VORTEX"
	_game = (load("res://scenes/game.tscn") as PackedScene).instantiate() as Node3D
	add_child(_game)

func _physics_process(_delta: float) -> void:
	_frames += 1
	if _frames >= SETTLE_FRAMES:
		_probe()
		get_tree().quit(0)

func _probe() -> void:
	var player := _game.get_node_or_null("Player") as PlayerRobot
	if player == null or player.rig == null:
		printerr("mesh_probe: no rig")
		return
	print("mesh_probe: player=%s rig=%s" % [str(player.global_position), player.rig.get_class()])
	var chassis := player.rig.get_node_or_null("Chassis") as Node3D
	if chassis != null:
		print("  rig pos=%s rot=%s basis_y=%s" % [
				str(player.rig.position), str(player.rig.rotation_degrees),
				str(player.rig.global_basis.y)])
		print("  chassis pos=%s rot_deg=%s vel=%s" % [
				str(chassis.position), str(chassis.rotation_degrees), str(player.velocity)])
	for leg in player.rig.leg_units:
		for bone_name in ["CoxaBone", "UpperBone", "LowerBone", "Foot"]:
			var bone := leg.get_node_or_null(bone_name) as Node3D
			if bone != null:
				var b := bone.global_basis
				print("  bone %s/%s pos=%s yaxis=%s xaxis=%s" % [
						leg.name, bone_name, str(bone.global_position),
						str(b.y), str(b.x)])
	_walk(player.rig, player.rig, 0)

func _walk(node: Node, root: Node3D, depth: int) -> void:
	if node is MeshInstance3D and String(node.name).find("__") != -1:
		var mi := node as MeshInstance3D
		var aabb := mi.mesh.get_aabb() if mi.mesh != null else AABB()
		var center := mi.global_transform * aabb.get_center()
		print("  %s%s parent=%s lt=%s ly=%s lx=%s aabb_c=%s" % [
				"  ".repeat(depth), String(node.name),
				String(node.get_parent().name) if node.get_parent() != null else "-",
				str((node as Node3D).transform.origin),
				str((node as Node3D).basis.y if node is Node3D else Vector3.ZERO),
				str((node as Node3D).basis.x), str(center)])
	for child in node.get_children():
		_walk(child, root, depth + 1)
