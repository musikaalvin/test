export JAVA_HOME=/usr/lib/jvm/java-21-openjdk-arm64
export ANDROID_HOME="$HOME/Android/Sdk"
export ANDROID_SDK_ROOT="$ANDROID_HOME"
export GODOT="$HOME/tools/godot-4.4.1"
export PATH="$JAVA_HOME/bin:$ANDROID_HOME/platform-tools:$ANDROID_HOME/cmdline-tools/latest/bin:$PATH"
export GRADLE_USER_HOME="$HOME/.gradle"