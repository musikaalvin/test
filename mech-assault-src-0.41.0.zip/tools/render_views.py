#!/usr/bin/env python3
"""Software rasterizer: build/mesh_dump.json -> build/screenshots/*.png

Runs on the build host where Godot's GPU renderer is unavailable. Renders the
dumped triangle soup from several fixed viewpoints so the robot silhouette and
arena composition can be inspected as normal images.
"""
import json
import math
import os
import sys

import numpy as np
from PIL import Image, ImageDraw

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
DUMP = os.path.join(ROOT, "build", "mesh_dump.json")
OUT_DIR = os.path.join(ROOT, "build", "screenshots")
WIDTH, HEIGHT = 800, 450
FOV_DEG = 55.0
SUN = np.array([0.45, 1.0, 0.3], dtype=np.float32)
SUN = SUN / np.linalg.norm(SUN)


def load_dump():
    with open(DUMP) as handle:
        data = json.load(handle)
    verts = np.asarray(data["vertices"], dtype=np.float32).reshape(-1, 3, 3)
    cols = np.asarray(data["colors"], dtype=np.float32).reshape(-1, 3, 3)
    emis = np.asarray(data["emissives"], dtype=np.float32).reshape(-1, 3, 3)
    camera = np.asarray(data.get("camera", []), dtype=np.float32)
    player = np.asarray(data.get("player", []), dtype=np.float32)
    aabb = np.asarray(data.get("player_aabb", []), dtype=np.float32)
    return verts, cols, emis, camera, player, aabb


def transform_parts(t):
    origin = t[0:3]
    basis = t[3:12].reshape(3, 3)  # rows = x, y, z axis vectors
    return origin, basis


def look_at(eye, target, up=np.array([0.0, 1.0, 0.0], dtype=np.float32)):
    zaxis = eye - target
    zaxis = zaxis / np.linalg.norm(zaxis)
    xaxis = np.cross(up, zaxis)
    n = np.linalg.norm(xaxis)
    if n < 1e-6:
        xaxis = np.array([1.0, 0.0, 0.0], dtype=np.float32)
    else:
        xaxis = xaxis / n
    yaxis = np.cross(zaxis, xaxis)
    return np.stack([xaxis, yaxis, zaxis], axis=1)  # columns


def project(point, eye, target, fov=FOV_DEG):
    rot = look_at(np.asarray(eye, np.float32), np.asarray(target, np.float32))
    rel = np.asarray(point, np.float32) - np.asarray(eye, np.float32)
    depth = -float(rel @ rot[:, 2])
    if depth <= 0.08:
        return None
    fx = 1.0 / math.tan(math.radians(fov) * 0.5)
    aspect = WIDTH / HEIGHT
    xs = (float(rel @ rot[:, 0]) * fx) / (aspect * depth)
    ys = (float(rel @ rot[:, 1]) * fx) / depth
    return ((xs * 0.5 + 0.5) * WIDTH, (1.0 - (ys * 0.5 + 0.5)) * HEIGHT)


def render(verts, cols, emis, eye, target, path, fov=FOV_DEG, arrow=None):
    rot = look_at(eye, target)
    rel = verts - eye[None, None, :]          # (T,3,3)
    cam = rel @ rot                            # columns = cam basis
    depth = -cam[..., 2]                       # camera looks down -Z
    fx = 1.0 / math.tan(math.radians(fov) * 0.5)
    aspect = WIDTH / HEIGHT
    front = depth > 0.08

    safe = np.where(front, depth, 1.0)
    xs = (cam[..., 0] * fx) / (aspect * safe)
    ys = (cam[..., 1] * fx) / safe
    sx = (xs * 0.5 + 0.5) * WIDTH
    sy = (1.0 - (ys * 0.5 + 0.5)) * HEIGHT

    normals = np.cross(verts[:, 1] - verts[:, 0], verts[:, 2] - verts[:, 0])
    lengths = np.linalg.norm(normals, axis=1, keepdims=True)
    normals = np.divide(normals, np.where(lengths < 1e-9, 1.0, lengths))
    lam = np.abs(normals @ SUN)
    shade = (0.32 + 0.75 * lam)[:, None, None].astype(np.float32)
    lit = cols * shade + emis

    zbuf = np.full((HEIGHT, WIDTH), np.inf, dtype=np.float32)
    img = np.zeros((HEIGHT, WIDTH, 3), dtype=np.float32)

    order = np.argsort(-depth.mean(axis=1))    # far to near (painter aid)
    for tri in order:
        if not front[tri].all():
            continue
        x0, x1, x2 = sx[tri]
        y0, y1, y2 = sy[tri]
        minx = int(max(0, math.floor(min(x0, x1, x2))))
        maxx = int(min(WIDTH - 1, math.ceil(max(x0, x1, x2))))
        miny = int(max(0, math.floor(min(y0, y1, y2))))
        maxy = int(min(HEIGHT - 1, math.ceil(max(y0, y1, y2))))
        if minx > maxx or miny > maxy:
            continue
        area = (x1 - x0) * (y2 - y0) - (x2 - x0) * (y1 - y0)
        if abs(area) < 1e-6:
            continue
        gx, gy = np.meshgrid(
            np.arange(minx, maxx + 1, dtype=np.float32) + 0.5,
            np.arange(miny, maxy + 1, dtype=np.float32) + 0.5,
        )
        w0 = ((x1 - gx) * (y2 - gy) - (x2 - gx) * (y1 - gy)) / area
        w1 = ((x2 - gx) * (y0 - gy) - (x0 - gx) * (y2 - gy)) / area
        w2 = 1.0 - w0 - w1
        mask = (w0 >= 0) & (w1 >= 0) & (w2 >= 0)
        if not mask.any():
            continue
        # barycentric mapped back onto triangle vertices (w2 -> v0 etc.)
        d = w0 * depth[tri, 0] + w1 * depth[tri, 1] + w2 * depth[tri, 2]
        sub = zbuf[miny:maxy + 1, minx:maxx + 1]
        closer = mask & (d < sub)
        if not closer.any():
            continue
        sub[closer] = d[closer]
        region = img[miny:maxy + 1, minx:maxx + 1]
        region[closer] = lit[tri].mean(axis=0)

    # background: cool vertical gradient with a horizon glow
    t = np.linspace(0.0, 1.0, HEIGHT, dtype=np.float32)[:, None, None]
    top = np.array([0.05, 0.07, 0.10], dtype=np.float32)
    bottom = np.array([0.16, 0.13, 0.11], dtype=np.float32)
    bg = top * (1.0 - t) + bottom * t
    bg = np.repeat(bg, WIDTH, axis=1)
    lit_mask = np.isfinite(zbuf) & (zbuf < np.inf)
    out = np.where(lit_mask[..., None], np.clip(img, 0.0, 1.0), bg)
    image = Image.fromarray((out * 255.0).astype(np.uint8))
    if arrow is not None:
        base, tip = arrow
        p_base = project(base, eye, target, fov)
        p_tip = project(tip, eye, target, fov)
        if p_base is not None and p_tip is not None:
            draw = ImageDraw.Draw(image)
            draw.line([p_base, p_tip], fill=(40, 255, 90), width=3)
            draw.ellipse([p_base[0] - 5, p_base[1] - 5, p_base[0] + 5,
                          p_base[1] + 5], outline=(40, 255, 90), width=2)
            draw.text((p_tip[0] + 7, p_tip[1] - 8), "FWD", fill=(40, 255, 90))
    image.save(path)
    print("rendered %s" % os.path.basename(path))


def main():
    if not os.path.exists(DUMP):
        print("missing %s — run: godot --headless --path . tools/dump_mesh.tscn" % DUMP)
        return 1
    os.makedirs(OUT_DIR, exist_ok=True)
    verts, cols, emis, camera, player, aabb = load_dump()
    print("triangles: %d" % len(verts))
    arrow = None
    if player.size == 12:
        p_origin, p_basis = transform_parts(player)
        # Rows are the axis vectors: forward = -basis.z (row 2).
        forward = -p_basis[2, :]
        forward[1] = 0.0
        f_len = np.linalg.norm(forward)
        forward = forward / (f_len if f_len > 1e-6 else 1.0)
        right = np.array([forward[2], 0.0, -forward[0]], dtype=np.float32)
        # Scale-aware framing: use the robot's dumped AABB (fallback: a
        # naive near-origin scan) so 6 m titans are not cropped by the
        # robot-sized default camera, and world props never hijack it.
        if aabb.size == 6 and aabb[3] > aabb[0]:
            box_min, box_max = aabb[:3], aabb[3:]
        else:
            near = verts.reshape(-1, 3)
            near = near[(np.abs(near[:, 0] - p_origin[0]) < 3.5)
                        & (np.abs(near[:, 2] - p_origin[2]) < 3.5)]
            if len(near):
                box_min = near.min(axis=0)
                box_max = near.max(axis=0)
            else:
                box_min = p_origin + np.array([0.0, -1.0, 0.0], np.float32)
                box_max = p_origin + np.array([0.0, 2.6, 0.0], np.float32)
        rig_h = float(max(box_max[1] - box_min[1], 2.0))
        k = max(rig_h / 3.6, 1.0)
        centre = (box_min + box_max) * 0.5
        chest = np.array([centre[0], box_min[1] + rig_h * 0.55, centre[2]],
                         np.float32)
        arrow = (chest, chest + forward * 3.2 * k)
        views = {
            "view_front": (chest + forward * 7.0 * k + np.array([0, 1.6 * k, 0], np.float32), chest),
            "view_rear": (chest - forward * 7.0 * k + np.array([0, 1.6 * k, 0], np.float32), chest),
            "view_right": (chest + right * 6.5 * k + np.array([0, 1.5 * k, 0], np.float32), chest),
            "view_left": (chest - right * 6.5 * k + np.array([0, 1.5 * k, 0], np.float32), chest),
            "view_iso": (chest + forward * 4.5 * k + right * 4.5 * k + np.array([0, 3.6 * k, 0], np.float32), chest),
            "view_low": (chest + forward * 5.5 * k - right * 2.5 * k + np.array([0, 0.6 * k, 0], np.float32), chest),
        }
    else:
        views = {}
    if camera.size == 12:
        c_origin, c_basis = transform_parts(camera)
        views["view_gameplay"] = (c_origin, c_origin - c_basis[2, :] * 8.0)
    for name, (eye, target) in views.items():
        render(verts, cols, emis, np.asarray(eye, np.float32),
               np.asarray(target, np.float32), os.path.join(OUT_DIR, name + ".png"),
               arrow=arrow)
    return 0


if __name__ == "__main__":
    sys.exit(main())
