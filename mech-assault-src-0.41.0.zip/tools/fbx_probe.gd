extends SceneTree

func _init() -> void:
	var scene := (load("res://assets/mech_kit/Mech/SK_ISO_Mech.fbx") as PackedScene)
	if scene == null:
		print("PROBE: load failed")
		quit(1)
		return
	var inst := scene.instantiate() as Node3D
	print("PROBE root: ", inst.get_class(), " name=", inst.name)
	_dump(inst, 0)
	var box := AABB()
	var first := true
	for node in inst.find_children("*", "MeshInstance3D", true, false):
		var mi := node as MeshInstance3D
		if mi.mesh == null:
			continue
		print("PROBE mesh: ", mi.name, " surfaces=", mi.mesh.get_surface_count(),
				" aabb=", mi.get_aabb(), " mat=", mi.get_surface_override_material(0))
		var xf := inst.global_transform * mi.transform
		var aabb := mi.get_aabb()
		for c in 8:
			var p := Vector3(
				aabb.position.x + (aabb.size.x if c & 1 else 0.0),
				aabb.position.y + (aabb.size.y if c & 2 else 0.0),
				aabb.position.z + (aabb.size.z if c & 4 else 0.0))
			if first:
				box = AABB(xf * p, Vector3.ZERO)
				first = false
			else:
				box = box.expand(xf * p)
	print("PROBE combined aabb: pos=", box.position, " size=", box.size)
	for anim_node in inst.find_children("*", "AnimationPlayer", true, false):
		var ap := anim_node as AnimationPlayer
		print("PROBE animplayer: ", ap.name, " libs=", ap.get_animation_library("").get_animation_list())
	inst.free()
	quit(0)

func _dump(node: Node, depth: int) -> void:
	print("  ".repeat(depth), node.get_class(), " ", node.name)
	if depth >= 3:
		return
	for child in node.get_children():
		_dump(child, depth + 1)
