"""CITADEL — fortress-class titan mech for MECH ASSAULT (Godot 4.4.1).

Original design (never a copy of any War Robots asset): a bulky bipedal assault
titan with layered frontal barrier armour, twin shoulder cannon pods, forearm
tower shields and a dorsal command tower.

Runs the same Blender -> GLB pipeline as tools/build_princeps.py:

	blender --background --python tools/build_citadel.py

Contract (must match src/player/robot_rig.gd + src/player/titan_rig.gd):
  * part names   chassis__* / head__* / l0c,l0u,l0l,l0f / l1c,l1u,l1l,l1f
                 (never "gun*" — WeaponMount builds the weapons)
  * material keys m_primary m_secondary m_accent m_joint m_trim m_recess m_sensor
  * bones        thigh 1.875 / shin 2.175 / coxa 0.48  (* BULK = 1.25 game units)
  * hips         (+-0.78, -0.15, 0) * BULK, head node (0, 2.4, -0.78) * BULK,
                 alpha socket (+-1.08, 2.16, -0.3) * BULK,
                 beta socket  (+-1.65, 0.15, 0.3) * BULK

Deviation from the Princeps baseline (deliberate): build_princeps.py pre-multiplies
THIGH/SHIN/COXA by BULK and its helpers multiply every path point by BULK again, so
its leg segment meshes are 1.25x the bone length (knee ball 0.59 past the knee,
shin tube ~0.4 m through the floor at rest).  This script authors the segment
lengths once so the meshes end exactly at the bone ends.

Runs its own validation after export: re-imports the GLB, checks object/triangle
counts, part-name contract, material keys, file size and bbox against
assets/mech/princeps.glb (+-15% per axis).
"""

import math
import os
import re
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

import bpy
from mathutils import Matrix

import build_mech as bm

HERE = os.path.dirname(os.path.abspath(__file__))
OUT_CITADEL = os.path.abspath(os.path.join(HERE, "..", "assets", "mech", "citadel.glb"))
OUT_PRINCEPS = os.path.abspath(os.path.join(HERE, "..", "assets", "mech", "princeps.glb"))

# ---------------------------------------------------------------- contract --
BULK = 1.25
# Authored bone lengths.  The helpers below multiply by BULK exactly once, so the
# mesh reaches precisely the Godot-side bone length (see module docstring).
THIGH = 1.875
SHIN = 2.175
COXA = 0.48
HIP_POS = [
	(0.78 * BULK, -0.15 * BULK, 0.0),
	(-0.78 * BULK, -0.15 * BULK, 0.0),
]
HIP_OUT = [(1.0, 0.0, 0.0), (-1.0, 0.0, 0.0)]
HEAD_POSE = (0.0, 2.4 * BULK, -0.78 * BULK)
ALPHA_SOCKET = (1.08 * BULK, 2.16 * BULK, -0.3 * BULK)
BETA_SOCKET = (1.65 * BULK, 0.15 * BULK, 0.3 * BULK)
# TitanRig._build_thrusters: flame.position = Vector3(side*0.66, 0.78, 1.14)*BULK
# in chassis (game) units -> authored units are that tuple unchanged.
FLAME_MOUTH = (0.66, 0.78, 1.14)
FLAME_DIR = (0.0, -0.9285, 0.3714)  # normalised (0, -1, 0.4)

# Painted fortress armour: white plate / navy panels / hazard red accents, steel
# trim (metallic 0.95), dark joints, emissive cyan sensors.  Painted armour keeps
# metallic low (0.15-0.25) exactly like the Godot-side _make_materials values.
MAT_SPECS = {
	"m_primary": ((0.78, 0.79, 0.82, 1.0), 0.18, 0.45, None, 0.0),
	"m_secondary": ((0.11, 0.15, 0.30, 1.0), 0.20, 0.50, None, 0.0),
	"m_accent": ((0.62, 0.10, 0.12, 1.0), 0.20, 0.42, None, 0.0),
	"m_joint": ((0.09, 0.095, 0.11, 1.0), 0.60, 0.70, None, 0.0),
	"m_trim": ((0.50, 0.52, 0.56, 1.0), 0.95, 0.34, None, 0.0),
	"m_recess": ((0.05, 0.055, 0.07, 1.0), 0.40, 0.85, None, 0.0),
	"m_sensor": ((0.20, 0.85, 1.00, 1.0), 0.20, 0.15, (0.15, 0.9, 1.0), 3.6),
}

MAT_NAMES = (
	"m_primary", "m_secondary", "m_accent", "m_joint", "m_trim", "m_recess", "m_sensor",
)


# ----------------------------------------------------------------- helpers --
def _v3(value):
	return tuple(c * BULK for c in value)


def part(t, m, verts, faces, local, bevel=0.0, smooth=False):
	return bm.part(t, m, verts, faces, local, bevel * BULK, smooth)


def box(t, m, size, origin, rot=None, bevel=0.02):
	return bm.box_part(t, m, _v3(size), _v3(origin), rot, bevel * BULK)


def cyl(t, m, radius, length, origin, rot=None, segments=16):
	return bm.cyl_part(t, m, radius * BULK, length * BULK, _v3(origin), rot, segments)


def cone(t, m, rb, rt, length, origin, rot=None):
	return bm.cone_part(t, m, rb * BULK, rt * BULK, length * BULK, _v3(origin), rot)


def loft(t, m, path, radii, origin=(0.0, 0.0, 0.0), rot=None, segments=16):
	return bm.loft_part(t, m, [_v3(p) for p in path],
			[r * BULK for r in radii], _v3(origin), rot, segments)


def sph(t, m, radius, origin, scale=None, rot=None, seg=16, rings=10):
	"""Sphere with configurable tessellation (bm.sph_part is fixed at 24x14 = 624
	tris; a 16x10 joint is 288 tris and reads identically on a titan)."""
	r = radius * BULK
	if scale is None:
		verts, faces = bm.sphere_verts(r, seg, rings)
	else:
		verts, faces = bm.sphere_verts(1.0, seg, rings)
		sx, sy, sz = r * scale[0], r * scale[1], r * scale[2]
		verts = [(x * sx, y * sy, z * sz) for (x, y, z) in verts]
	local = bm.translate_g(_v3(origin))
	if rot is not None:
		local = local @ bm.mat4(rot)
	bm.part(t, m, verts, faces, local, 0.0, True)


# ------------------------------------------------------------- the machine --
def build_chassis():
	t = "chassis"

	# --- pelvis / waist ------------------------------------------------
	box(t, "m_primary", (1.62, 0.60, 1.20), (0.0, 0.08, 0.05), None, 0.06)
	box(t, "m_secondary", (1.86, 0.30, 1.34), (0.0, -0.18, 0.05), None, 0.05)
	box(t, "m_joint", (1.24, 0.24, 1.04), (0.0, 0.40, 0.0), None, 0.03)
	box(t, "m_secondary", (1.00, 0.56, 0.88), (0.0, 0.66, 0.0), None, 0.04)

	# --- chest core: tapered + faceted so the silhouette is a hull, not
	#     a slab (Bedwyr-genre knight: wide shoulders, narrow waist) -----
	box(t, "m_primary", (1.98, 1.24, 1.44), (0.0, 1.44, -0.02), None, 0.07)
	box(t, "m_secondary", (2.16, 0.44, 1.30), (0.0, 1.96, -0.02), None, 0.05)
	for side in (1.0, -1.0):
		box(t, "m_primary", (0.46, 1.12, 1.36), (side * 1.05, 1.46, 0.0),
			bm.rot_z(side * -13.0), 0.05)
		box(t, "m_trim", (0.07, 0.88, 0.11), (side * 1.29, 1.50, -0.67),
			bm.rot_z(side * -13.0), 0.012)

	# --- layered frontal barrier slabs (the fortress wall) -------------
	for i in range(5):
		box(t, "m_primary" if i % 2 == 0 else "m_secondary",
			(2.16 - i * 0.05, 0.30, 0.34), (0.0, 0.72 + i * 0.30, -0.86),
			bm.rot_x(-6.0 - i * 2.0), 0.025)
	box(t, "m_accent", (1.94, 0.14, 0.16), (0.0, 1.34, -1.02), None, 0.015)

	# --- navy crest plate + red centre boss ----------------------------
	box(t, "m_secondary", (1.16, 0.60, 0.12), (0.0, 1.56, -1.06), bm.rot_x(-8.0), 0.02)
	cyl(t, "m_trim", 0.32, 0.05, (0.0, 1.56, -1.15), bm.rot_x(90.0), 16)
	cyl(t, "m_accent", 0.27, 0.11, (0.0, 1.56, -1.20), bm.rot_x(90.0), 16)

	# --- glacis prow ---------------------------------------------------
	box(t, "m_accent", (1.72, 0.46, 0.52), (0.0, 2.02, -0.74), bm.rot_x(-26.0), 0.04)
	box(t, "m_trim", (1.24, 0.10, 0.30), (0.0, 2.16, -0.86), bm.rot_x(-26.0), 0.02)

	# --- wide clavicle deck (carries the shoulder pods) ---------------
	box(t, "m_primary", (3.00, 0.30, 1.50), (0.0, 2.05, -0.02), None, 0.05)
	box(t, "m_secondary", (2.40, 0.14, 0.90), (0.0, 2.20, 0.10), None, 0.03)

	# --- gorget: raised collar flanking the head so it sits in an
	#     armoured notch (clears the head's +-37 deg yaw sweep) ----------
	for side in (1.0, -1.0):
		box(t, "m_primary", (0.30, 0.58, 0.86), (side * 0.80, 2.42, -0.46),
			bm.rot_z(side * -8.0), 0.03)
		box(t, "m_accent", (0.15, 0.30, 0.52), (side * 0.90, 2.34, -0.78),
			bm.rot_z(side * -8.0), 0.02)
	box(t, "m_secondary", (0.90, 0.46, 0.44), (0.0, 2.44, -0.02), None, 0.04)

	# --- dorsal command tower -----------------------------------------
	box(t, "m_primary", (1.30, 0.70, 0.60), (0.0, 2.55, 0.20), None, 0.04)
	box(t, "m_accent", (1.00, 0.46, 0.50), (0.0, 2.98, 0.28), bm.rot_x(-8.0), 0.03)
	box(t, "m_sensor", (0.60, 0.10, 0.12), (0.0, 3.16, 0.52), bm.rot_x(-8.0), 0.01)
	cyl(t, "m_trim", 0.045, 0.40, (0.30, 3.36, 0.40), bm.euler_g(6.0, 0.0, -4.0), 8)
	sph(t, "m_sensor", 0.075, (0.34, 3.56, 0.37), None, None, 12, 8)

	# --- rear generator pack, vents, exhaust stacks --------------------
	box(t, "m_secondary", (1.60, 1.00, 0.70), (0.0, 1.50, 0.95), None, 0.05)
	box(t, "m_primary", (1.70, 0.16, 0.78), (0.0, 2.04, 0.92), None, 0.03)
	for vent in range(3):
		box(t, "m_recess", (1.30, 0.09, 0.10),
			(0.0, 1.10 + vent * 0.16, 1.30), None, 0.008)
	box(t, "m_sensor", (0.86, 0.30, 0.10), (0.0, 1.78, 1.32), None, 0.01)
	box(t, "m_secondary", (1.30, 0.70, 0.55), (0.0, 0.60, 0.72), None, 0.04)
	for side in (1.0, -1.0):
		cyl(t, "m_trim", 0.16, 0.90, (side * 0.52, 2.50, 1.10), bm.rot_x(24.0), 12)
		cyl(t, "m_recess", 0.19, 0.16, (side * 0.56, 2.90, 1.27), bm.rot_x(24.0), 12)
		# thruster nozzles sit exactly on TitanRig's flame emitters
		theta = math.degrees(math.atan2(FLAME_DIR[2], FLAME_DIR[1]))
		cyl(t, "m_recess", 0.21, 0.70,
			(side * FLAME_MOUTH[0], FLAME_MOUTH[1] - FLAME_DIR[1] * 0.35,
			FLAME_MOUTH[2] - FLAME_DIR[2] * 0.35), bm.rot_x(theta), 12)
		cyl(t, "m_sensor", 0.14, 0.09,
			(side * FLAME_MOUTH[0], FLAME_MOUTH[1] + FLAME_DIR[1] * 0.045,
			FLAME_MOUTH[2] + FLAME_DIR[2] * 0.045), bm.rot_x(theta), 10)

	# --- rounded shoulder pauldrons over the pods (layered: dome +
	#     red under-rim + trim crown cap) -------------------------------
	for side in (1.0, -1.0):
		sph(t, "m_primary", 0.46, (side * 1.34, 2.54, -0.08),
			(1.06, 0.64, 1.08), None, 16, 10)
		box(t, "m_accent", (0.96, 0.16, 1.04), (side * 1.34, 2.32, -0.08),
			None, 0.03)
		box(t, "m_trim", (0.70, 0.08, 0.78), (side * 1.34, 2.78, -0.08),
			None, 0.02)
		# deltoid plate covering the shoulder joint ball
		box(t, "m_primary", (0.30, 0.36, 0.36), (side * 1.24, 1.36, -0.06),
			bm.rot_z(side * -10.0), 0.03)

	# --- shoulder cannon pods (alpha sockets) --------------------------
	for side in (1.0, -1.0):
		box(t, "m_primary", (1.02, 0.72, 1.16), (side * 1.12, 2.20, -0.16), None, 0.05)
		box(t, "m_accent", (0.88, 0.14, 0.94), (side * 1.12, 2.62, -0.16), None, 0.03)
		box(t, "m_primary", (1.08, 0.42, 0.52), (side * 1.12, 2.18, -0.62), None, 0.04)
		cyl(t, "m_recess", 0.29, 0.32, (side * 1.08, 2.16, -0.86), bm.rot_x(90.0), 16)
		cyl(t, "m_trim", 0.33, 0.10, (side * 1.08, 2.16, -0.70), bm.rot_x(90.0), 16)
		box(t, "m_trim", (0.10, 0.56, 0.98), (side * 1.66, 2.20, -0.14), None, 0.02)
		box(t, "m_joint", (0.36, 0.30, 0.58), (side * 0.68, 2.06, 0.42), None, 0.03)
		for dx, dy in ((-0.17, 0.15), (0.17, -0.15)):
			cyl(t, "m_joint", 0.065, 0.14,
				(side * 1.08 + dx, 2.16 + dy, -0.80), bm.rot_x(90.0), 8)

	# --- hip sponsons (beta sockets) ----------------------------------
	for side in (1.0, -1.0):
		sph(t, "m_joint", 0.30, (side * 0.90, -0.05, 0.05), None, None, 16, 10)
		box(t, "m_primary", (0.42, 0.52, 0.70), (side * 1.02, -0.04, 0.02),
			None, 0.04)
		box(t, "m_secondary", (0.74, 0.66, 1.20), (side * 1.50, 0.22, 0.30), None, 0.05)
		box(t, "m_primary", (0.62, 0.44, 0.60), (side * 1.50, 0.20, -0.40), None, 0.04)
		cyl(t, "m_recess", 0.25, 0.30, (side * 1.65, 0.15, -0.66), bm.rot_x(90.0), 14)
		cyl(t, "m_trim", 0.29, 0.10, (side * 1.65, 0.15, -0.52), bm.rot_x(90.0), 14)
		box(t, "m_trim", (0.09, 0.48, 0.84), (side * 1.90, 0.18, 0.26), None, 0.02)

	# --- arms + tower shields -----------------------------------------
	for side in (1.0, -1.0):
		sph(t, "m_joint", 0.26, (side * 1.16, 1.30, -0.10), None, None, 16, 10)
		box(t, "m_secondary", (0.42, 0.70, 0.46), (side * 1.18, 0.96, -0.12),
			bm.rot_x(-10.0), 0.03)
		sph(t, "m_joint", 0.17, (side * 1.20, 0.56, -0.20), None, None, 12, 8)
		box(t, "m_primary", (0.48, 0.64, 0.54), (side * 1.20, 0.24, -0.24),
			bm.rot_x(-6.0), 0.03)
		box(t, "m_joint", (0.40, 0.30, 0.48), (side * 1.22, -0.16, -0.24), None, 0.03)
		# tower shield: taller and deeper, white body + red band + trim
		# crown along the top edge, clear of the beta barrels (x <= 1.415)
		box(t, "m_primary", (0.19, 1.42, 1.10), (side * 1.32, 0.34, -0.96),
			bm.rot_x(-5.0), 0.03)
		box(t, "m_accent", (0.21, 0.40, 1.14), (side * 1.32, 0.80, -1.02),
			bm.rot_x(-5.0), 0.02)
		box(t, "m_trim", (0.23, 0.09, 1.16), (side * 1.32, 1.06, -1.04),
			bm.rot_x(-5.0), 0.015)
		cyl(t, "m_trim", 0.24, 0.10, (side * 1.32, 0.20, -1.54),
			bm.rot_z(side * -90.0), 12)
		box(t, "m_sensor", (0.21, 0.07, 0.12), (side * 1.32, -0.30, -1.55),
			bm.rot_x(-5.0), 0.01)

	# --- belly + core -------------------------------------------------
	box(t, "m_secondary", (1.44, 0.40, 1.24), (0.0, -0.28, 0.05), None, 0.05)
	box(t, "m_primary", (0.72, 0.34, 0.92), (0.0, -0.40, -0.05), None, 0.04)
	sph(t, "m_sensor", 0.20, (0.0, -0.42, -0.50), None, None, 14, 9)


def build_head():
	"""Head is authored relative to HeadSensor = (0, 2.4, -0.78) * BULK."""
	t = "head"
	box(t, "m_primary", (1.00, 0.46, 0.74), (0.0, 0.0, 0.0), None, 0.04)
	box(t, "m_accent", (1.10, 0.17, 0.56), (0.0, 0.24, -0.10), bm.rot_x(-14.0), 0.03)
	box(t, "m_recess", (0.76, 0.24, 0.20), (0.0, -0.02, -0.36), None, 0.015)
	box(t, "m_sensor", (0.62, 0.09, 0.08), (0.0, 0.04, -0.42), None, 0.006)
	box(t, "m_secondary", (0.66, 0.18, 0.46), (0.0, -0.27, -0.06), bm.rot_x(12.0), 0.03)
	for side in (1.0, -1.0):
		box(t, "m_secondary", (0.18, 0.34, 0.52), (side * 0.52, -0.02, -0.04),
			bm.rot_z(side * -10.0), 0.025)
	# command crest
	box(t, "m_accent", (0.36, 0.36, 0.54), (0.0, 0.34, 0.04), None, 0.03)
	box(t, "m_trim", (0.10, 0.20, 0.62), (0.0, 0.56, 0.06), bm.rot_x(-8.0), 0.02)
	box(t, "m_sensor", (0.50, 0.05, 0.12), (0.0, 0.30, -0.22), None, 0.006)
	sph(t, "m_joint", 0.11, (0.0, 0.24, 0.06), None, None, 14, 9)
	cyl(t, "m_trim", 0.03, 0.50, (-0.30, 0.50, 0.10), bm.euler_g(8.0, 8.0, 0.0), 8)
	sph(t, "m_sensor", 0.05, (-0.33, 0.74, 0.07), None, None, 12, 8)
	sph(t, "m_sensor", 0.06, (0.20, 0.04, -0.40), (1.0, 0.9, 0.9), None, 12, 8)
	sph(t, "m_sensor", 0.06, (-0.20, 0.04, -0.40), (1.0, 0.9, 0.9), None, 12, 8)


def build_legs():
	for index in range(2):
		c = "l%dc" % index
		u = "l%du" % index
		low = "l%dl" % index
		f = "l%df" % index

		# coxa
		sph(c, "m_joint", 0.33, (0.0, 0.0, 0.0), None, None, 16, 10)
		loft(c, "m_trim", [(0.0, 0.0, 0.0), (0.0, 0.12, 0.0), (0.0, COXA, 0.0)],
			[0.27, 0.24, 0.20], segments=14)
		box(c, "m_primary", (0.52, 0.36, 0.58), (0.0, 0.16, 0.0), None, 0.035)
		box(c, "m_trim", (0.54, 0.08, 0.18), (0.0, 0.32, -0.24), None, 0.015)

		# thigh — thick tapered core with layered plates + side skirts
		loft(u, "m_primary", [
			(0.0, 0.0, 0.0), (0.03, 0.5, 0.04), (0.015, 1.0, 0.015), (0.0, THIGH, 0.0),
		], [0.30, 0.38, 0.31, 0.23], segments=18)
		box(u, "m_secondary", (0.68, 0.98, 0.28), (0.015, 0.62, -0.31),
			bm.rot_x(-5.0), 0.035)
		box(u, "m_accent", (0.46, 0.32, 0.18), (0.015, 1.04, -0.37),
			bm.rot_x(-7.0), 0.02)
		box(u, "m_primary", (0.54, 0.54, 0.22), (0.015, 1.36, 0.32),
			bm.rot_x(6.0), 0.03)
		box(u, "m_accent", (0.48, 0.32, 0.22), (0.015, 1.66, -0.33),
			bm.rot_x(-10.0), 0.025)
		for side in (1.0, -1.0):
			box(u, "m_secondary", (0.13, 0.80, 0.46), (side * 0.34, 0.72, 0.0),
				None, 0.025)
			cyl(u, "m_trim", 0.06, 0.84, (side * 0.40, 0.55, 0.02), None, 10)
		cyl(u, "m_accent", 0.33, 0.12, (0.0, 0.42, 0.0), None, 18)
		sph(u, "m_joint", 0.33, (0.0, THIGH, 0.0), None, None, 16, 10)
		cyl(u, "m_accent", 0.22, 0.15, (0.0, THIGH, 0.0), bm.rot_x(90.0), 14)

		# shin — thicker core, full plates both faces, side skirts
		loft(low, "m_primary", [
			(0.0, 0.0, 0.0), (0.0, 0.55, -0.03), (0.0, 1.10, -0.01), (0.0, SHIN, 0.0),
		], [0.26, 0.31, 0.24, 0.18], segments=16)
		box(low, "m_secondary", (0.60, 0.90, 0.26), (0.0, 0.62, -0.25), None, 0.03)
		box(low, "m_accent", (0.36, 0.26, 0.16), (0.0, 1.20, -0.29), None, 0.02)
		box(low, "m_primary", (0.44, 0.56, 0.20), (0.0, 0.72, 0.26), None, 0.03)
		for side in (1.0, -1.0):
			box(low, "m_secondary", (0.12, 0.72, 0.38), (side * 0.27, 0.62, 0.0),
				None, 0.022)
			cyl(low, "m_trim", 0.05, 0.76, (side * 0.31, 0.60, 0.05), None, 10)
		sph(low, "m_joint", 0.20, (0.0, SHIN, 0.0), None, None, 14, 9)

		# foot: pad bottom lands ~0.11 below the Foot node (ground + 0.1)
		sph(f, "m_joint", 0.17, (0.0, 0.13, 0.0), None, None, 14, 9)
		box(f, "m_primary", (0.86, 0.22, 1.06), (0.0, 0.0, 0.02), None, 0.03)
		box(f, "m_trim", (0.56, 0.08, 0.56), (0.0, -0.06, -0.05), None, 0.015)
		box(f, "m_secondary", (0.66, 0.14, 0.30), (0.0, 0.10, -0.34),
			bm.rot_x(-6.0), 0.02)
		for cx in (-0.22, 0.0, 0.22):
			yaw = -16.0 if cx > 0.0 else (16.0 if cx < 0.0 else 0.0)
			cone(f, "m_joint", 0.105, 0.008, 0.48,
				(cx, -0.03, -0.48), bm.euler_g(-95.0, yaw, 0.0))
		cone(f, "m_joint", 0.09, 0.008, 0.36, (0.0, -0.04, 0.44), bm.rot_x(95.0))
		box(f, "m_sensor", (0.34, 0.05, 0.08), (0.0, 0.07, -0.32), None, 0.01)


def build_poses():
	"""Doc-only rest pose (build_mech.construct drops empties before export —
	the Godot side re-solves the IK).  Kept for parity with build_princeps."""
	empties = {"chassis": Matrix.Identity(4), "head": bm.translate_g(HEAD_POSE)}
	for index in range(2):
		pose = bm.leg_pose(HIP_POS[index], HIP_OUT[index])
		empties["l%dc" % index] = pose["coxa"]
		empties["l%du" % index] = pose["upper"]
		empties["l%dl" % index] = pose["lower"]
		empties["l%df" % index] = pose["foot"]
	return empties


# ------------------------------------------------------------- validation --
NAME_RE = re.compile(r"^(chassis|head|l[01][culf])__m_"
		+ "(primary|secondary|accent|joint|trim|recess|sensor)$")
REQUIRED = ["chassis", "head"] + [
	"l%d%s" % (i, role) for i in range(2) for role in "culf"]


def _measure(path):
	bpy.ops.wm.read_factory_settings(use_empty=True)
	bpy.ops.import_scene.gltf(filepath=path)
	lo = [1e9, 1e9, 1e9]
	hi = [-1e9, -1e9, -1e9]
	tris = 0
	names = []
	mats = set()
	for obj in bpy.data.objects:
		if obj.type != "MESH":
			continue
		names.append(obj.name)
		tris += sum(max(1, len(poly.vertices) - 2) for poly in obj.data.polygons)
		for slot in obj.material_slots:
			if slot.material is not None:
				mats.add(slot.material.name)
		mw = obj.matrix_world
		for vertex in obj.data.vertices:
			bco = mw @ vertex.co
			gco = (bco.x, bco.z, -bco.y)  # Blender Z-up -> glTF/Godot Y-up
			for axis in range(3):
				lo[axis] = min(lo[axis], gco[axis])
				hi[axis] = max(hi[axis], gco[axis])
	return {
		"objects": len(names), "tris": tris, "lo": lo, "hi": hi,
		"names": names, "mats": mats,
	}


def validate():
	failures = []
	size = os.path.getsize(OUT_CITADEL)
	mine = _measure(OUT_CITADEL)
	ref = _measure(OUT_PRINCEPS)

	print("\n=== CITADEL build report ===")
	print("file            : %s (%d bytes)" % (OUT_CITADEL, size))
	print("objects / tris  : %d / %d" % (mine["objects"], mine["tris"]))
	print("bbox (game axes): x[%6.3f,%6.3f] y[%6.3f,%6.3f] z[%6.3f,%6.3f]" % (
		mine["lo"][0], mine["hi"][0], mine["lo"][1], mine["hi"][1],
		mine["lo"][2], mine["hi"][2]))
	print("size            : (%.3f, %.3f, %.3f)" % (
		mine["hi"][0] - mine["lo"][0], mine["hi"][1] - mine["lo"][1],
		mine["hi"][2] - mine["lo"][2]))
	print("materials       : %s" % ", ".join(sorted(mine["mats"])))
	print("princeps ref    : %d objects / %d tris, size (%.3f, %.3f, %.3f)" % (
		ref["objects"], ref["tris"], ref["hi"][0] - ref["lo"][0],
		ref["hi"][1] - ref["lo"][1], ref["hi"][2] - ref["lo"][2]))

	if size <= 200 * 1024:
		failures.append("file is %d bytes (need > 204800)" % size)
	if not 15000 <= mine["tris"] <= 25000:
		failures.append("triangle count %d outside the 15000..25000 budget"
			% mine["tris"])
	bad = sorted(n for n in mine["names"] if not NAME_RE.match(n))
	if bad:
		failures.append("part names violate the contract: %s" % bad[:6])
	guns = [n for n in mine["names"] if n.startswith("gun")]
	if guns:
		failures.append("gun* parts present (weapons belong to WeaponMount): %s" % guns)
	targets = set(n.split("__", 1)[0] for n in mine["names"])
	for needed in REQUIRED:
		if needed not in targets:
			failures.append("missing part group %r" % needed)
	if mine["mats"] != set(MAT_NAMES):
		failures.append("material keys %s != %s" % (
			sorted(mine["mats"]), sorted(MAT_NAMES)))
	for axis, label in enumerate("xyz"):
		a = mine["hi"][axis] - mine["lo"][axis]
		b = ref["hi"][axis] - ref["lo"][axis]
		ratio = a / b if b else 0.0
		print("bbox %s vs princeps: %.3f / %.3f = %.3f" % (label, a, b, ratio))
		if not 0.85 <= ratio <= 1.15:
			failures.append("bbox axis %s is %.0f%% off princeps (need +-15%%)"
				% (label, (ratio - 1.0) * 100.0))

	if failures:
		print("\nVALIDATION FAILED:")
		for line in failures:
			print("  - " + line)
		raise SystemExit(1)
	print("\nVALIDATION PASSED (%d checks)" % (4 + len(MAT_NAMES)))


def main():
	bm.MAT_SPECS.clear()
	bm.MAT_SPECS.update(MAT_SPECS)
	bm.construct(
		builders=[build_chassis, build_head, build_legs],
		poses_fn=build_poses,
		out_path=OUT_CITADEL)
	validate()


if __name__ == "__main__":
	main()
