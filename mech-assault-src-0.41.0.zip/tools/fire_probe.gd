extends Node

# Regression probe for "touching anywhere autoshoots".
#   * a finger press (source = ScreenTouch) must NEVER arm InputRouter._mouse_fire
#   * a real mouse press (source = InputEventMouseButton) on open ground must
#     still arm it — that is desktop click-to-fire
#   * a press on a Control keeps whatever it did (STOP consumes, PASS does not)
# Godot dispatches an EMULATED twin before its source event, so the two cases
# arrive in opposite orders; InputRouter._touch_twin_seen is what tells them
# apart. Run with:  "$GODOT" --headless --path . tools/fire_probe.tscn

func _ready() -> void:
	await _run()
	get_tree().quit()

func _pair(source_touch: bool, screen: Vector2) -> void:
	var touch := InputEventScreenTouch.new()
	touch.index = 0
	touch.pressed = true
	touch.position = screen
	var mouse := InputEventMouseButton.new()
	mouse.button_index = MOUSE_BUTTON_LEFT
	mouse.pressed = true
	mouse.position = screen
	mouse.global_position = screen
	if source_touch:
		Input.parse_input_event(touch)
	else:
		Input.parse_input_event(mouse)
	Input.flush_buffered_events()
	await get_tree().process_frame
	await get_tree().process_frame

func _release() -> void:
	var mouse := InputEventMouseButton.new()
	mouse.button_index = MOUSE_BUTTON_LEFT
	mouse.pressed = false
	Input.parse_input_event(mouse)
	var touch := InputEventScreenTouch.new()
	touch.index = 0
	touch.pressed = false
	Input.parse_input_event(touch)
	Input.flush_buffered_events()
	await get_tree().process_frame
	InputRouter._process(0.016)

func _expect(label: String, want: bool) -> void:
	var got := InputRouter._mouse_fire
	print("PROBE %-26s %s (want %s)" % [label, "PASS" if got == want else "FAIL",
			"fire" if want else "quiet"])
	await _release()

func _run() -> void:
	await get_tree().process_frame
	print("PROBE emul_mouse_from_touch=", Input.is_emulating_mouse_from_touch(),
			" emul_touch_from_mouse=", Input.is_emulating_touch_from_mouse())
	var layer := CanvasLayer.new()
	add_child(layer)
	var stop_btn := Button.new()
	stop_btn.text = "STOP"
	stop_btn.position = Vector2(400.0, 300.0)
	stop_btn.size = Vector2(220.0, 80.0)
	layer.add_child(stop_btn)
	var pass_btn := Button.new()
	pass_btn.text = "PASS"
	pass_btn.position = Vector2(400.0, 420.0)
	pass_btn.size = Vector2(220.0, 80.0)
	pass_btn.mouse_filter = Control.MOUSE_FILTER_PASS
	layer.add_child(pass_btn)
	await get_tree().process_frame
	await get_tree().process_frame

	var st := get_viewport().get_screen_transform()
	var empty := st * Vector2(900.0, 640.0)
	var on_stop := st * (stop_btn.get_global_transform_with_canvas()
			* (stop_btn.size * 0.5))
	var on_pass := st * (pass_btn.get_global_transform_with_canvas()
			* (pass_btn.size * 0.5))

	InputRouter._mouse_fire = false
	await _pair(true, empty)
	await _expect("finger on open ground", false)

	InputRouter._mouse_fire = false
	await _pair(true, on_stop)
	await _expect("finger on STOP button", false)

	InputRouter._mouse_fire = false
	await _pair(true, on_pass)
	await _expect("finger on PASS button", false)

	InputRouter._mouse_fire = false
	await _pair(false, empty)
	await _expect("mouse click on open ground", true)

	InputRouter._mouse_fire = false
	await _pair(false, on_stop)
	await _expect("mouse click on STOP button", false)
