#!/usr/bin/env python3
import json
from pathlib import Path
root=Path(__file__).resolve().parents[1]
contract=json.loads((root/"data/mech_assault_full_ui_contract.json").read_text())
required=["hangar","robot_equipment","titan_equipment","weapon_select","weapon_detail","weapon_inventory","robot_inventory","pilot_inventory","drone_inventory","specialization","upgrade","store","workshop","collections","events","datapads","missions","operations","leaderboards","profile","friends","squad","clan","starbase","news","settings","settings_graphics","settings_audio","settings_controls","settings_aiming","settings_battle_hud","settings_accessibility","game_modes","matchmaking","deployment","battle","battle_robot_select","battle_pause","post_battle","rewards","reward_claim","loading","errors","tutorial","confirmation","notifications"]
missing=[x for x in required if x not in contract["screens"]]
assert not missing, f"missing screens: {missing}"
assert contract["hangar"]["robot_slots"]==5
assert contract["hangar"]["titan_slots"]==1
assert contract["hangar"]["physical_3d_required"]
assert contract["navigation"]["context_restore"]
assert contract["battle"]["inventory_distinct_from_hangar"]
assert contract["battle"]["hangar_distinct_from_battle_roster"]
assert contract["responsive"]["safe_zones"]
assert contract["performance"]["event_driven_ui"]
print(f"PASS: {len(contract['screens'])} UI routes, {len(contract['screen_states'])} states, full acceptance flow present")
