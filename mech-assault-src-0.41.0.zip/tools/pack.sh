#!/usr/bin/env bash
# Zip the whole project so another agent can pick it up and continue —
# except the heavyweight binary content it does not need to edit:
#
#   excluded:  assets/   (1.6 GB meshes/textures — shipped separately)
#              build/    (APK, exe, screenshots, dumps)
#              .godot/   (import cache, regenerated on first run)
#              .git/     (history)
#
#   included:  AGENTS.md, project.godot, export_presets.cfg, src/, scenes/,
#              tools/ (validate.sh, smoke_test, probes), data/, docs/,
#              the launcher/icon PNGs and every manifest the code reads.
#
#   tools/pack.sh   ->  build/mech-assault-src-<version>.zip
set -euo pipefail
cd "$(dirname "$0")/.."

VER=$(grep -oP 'config/version="\K[^"]+' project.godot)
OUT="build/mech-assault-src-${VER}.zip"
mkdir -p build

rm -f "$OUT" build/mech-assault-code-*.zip

zip -q -X -r "$OUT" \
	.gitignore AGENTS.md FINAL_BUILD_STATUS.md project.godot \
	export_presets.cfg debug.keystore \
	icon.png icon.png.import logo_menu.png logo_menu.png.import \
	boot_splash.png boot_splash.png.import \
	src scenes tools data docs \
	-x '*/__pycache__/*' '*.pyc' 'tools/apply_wr_v38.py' 'tools/weapon_probe*'

echo "packed $(unzip -Z1 "$OUT" | wc -l) files -> $OUT ($(du -h "$OUT" | cut -f1))"
echo "excluded: assets/ build/ .godot/ .git/ (plus the superseded WR rewriter + stray weapon probe)"
