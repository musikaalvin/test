extends Node

func _ready() -> void:
	DirAccess.make_dir_recursive_absolute(ProjectSettings.globalize_path("res://build"))
	for kind: StringName in [&"armor", &"steel", &"rubber", &"hazard"]:
		var textures := PanelTextures.get_textures(kind)
		var albedo := (textures[&"albedo"] as ImageTexture).get_image()
		var rough := (textures[&"rough"] as ImageTexture).get_image()
		var normal := (textures[&"normal"] as ImageTexture).get_image()
		albedo.save_png("res://build/tex_%s_albedo.png" % kind)
		rough.save_png("res://build/tex_%s_rough.png" % kind)
		normal.save_png("res://build/tex_%s_normal.png" % kind)
		print("saved ", kind)
	get_tree().quit(0)
