@echo off
setlocal EnableExtensions EnableDelayedExpansion
rem ============================================================
rem  MECH ASSAULT - Windows console launcher
rem
rem  Double-click THIS file instead of mech-assault.console.exe.
rem  It keeps the window open, writes everything to a file next
rem  to the exe, and also forces Godot to write its own engine
rem  log right there. If the game crashes, you still get the log.
rem
rem  Send us:  console_log.txt   and   godot_console.log
rem ============================================================

set "HERE=%~dp0"
set "EXE=%HERE%mech-assault.console.exe"
set "OUT=%HERE%console_log.txt"
set "GLOG=%HERE%godot_console.log"

if not exist "%EXE%" (
    echo mech-assault.console.exe not found next to this file.
    echo Put run_console.bat in the same folder as the exe.
    pause
    exit /b 1
)

del /q "%OUT%" 2>nul
del /q "%GLOG%" 2>nul

echo === MECH ASSAULT console capture ===> "%OUT%"
echo date  : %DATE% %TIME%>> "%OUT%"
echo exe   : %EXE%>> "%OUT%"
echo os    : %OS%>> "%OUT%"
echo user  : %USERPROFILE%>> "%OUT%"
echo.>> "%OUT%"

echo.
echo === launching game (close the game window or press Ctrl+C to stop) ===
echo.

rem --log-file makes Godot write its engine log beside the exe, so we do
rem not depend on the APPDATA path at all.
powershell -NoProfile -ExecutionPolicy Bypass -Command ^
  "$ErrorActionPreference='Continue'; " ^
  "& '%EXE%' --log-file '%GLOG%' 2>&1 | Tee-Object -FilePath '%OUT%' -Append | Out-Host; " ^
  "exit $LASTEXITCODE"
set "RC=!ERRORLEVEL!"

if not exist "%OUT%" (
    rem PowerShell blocked/missing: plain redirect still keeps a file.
    "%EXE%" --log-file "%GLOG%" >> "%OUT%" 2>&1
    set "RC=!ERRORLEVEL!"
)

echo.>> "%OUT%"
echo === game exit code: !RC! ===>> "%OUT%"

rem Also grab Godot's default per-user log, in case --log-file was ignored.
set "USERLOG=%APPDATA%\Godot\app_userdata\MECH ASSAULT\logs\godot.log"
if exist "%USERLOG%" (
    echo.>> "%OUT%"
    echo === user engine log: %USERLOG% ===>> "%OUT%"
    powershell -NoProfile -Command "Get-Content -LiteralPath '%USERLOG%' -Tail 400" >> "%OUT%" 2>nul
)

echo.
echo ============================================================
if exist "%OUT%" (
    echo  Console log : %OUT%
) else (
    echo  Console log : NOT WRITTEN - see the window above
)
if exist "%GLOG%" (
    echo  Engine log  : %GLOG%
) else (
    echo  Engine log  : not written - trying
    echo                %USERLOG%
)
echo  Exit code   : !RC!
echo.
echo  Send us BOTH log files if the game will not stay open.
echo ============================================================
echo.
pause
endlocal
