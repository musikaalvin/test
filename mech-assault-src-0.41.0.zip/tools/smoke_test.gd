extends Node

const GAME_SCENE := "res://scenes/game.tscn"
const WARMUP_FRAMES := 90
const MOVE_FRAMES := 120
const FIRE_FRAMES := 60
const COOL_FRAMES := 150
const UNLOCK_FRAMES := 150

var _failures: PackedStringArray = []
var _checks: int = 0
var _game: Node3D
var _saved_quality_auto: bool = true
var _lock_second_staged: bool = false
var _phase: int = 0
var _frame: int = 0
var _start_position: Vector3 = Vector3.ZERO
var _shot_sample: Vector3 = Vector3.ZERO
var _heat_peak: float = 0.0
var _peak_active: int = 0
var _first_impact: Vector3 = Vector3.ZERO
var _climb_start_y: float = 0.0
var _climb_peak_y: float = 0.0
var _yaw_before_turn: float = 0.0
var _drone_shots_before: int = 0
var _staged_enemy: EnemyRobot = null
var _heal_snapshot: float = 0.0
var _hazard_hp0: float = 0.0
var _hazard_seen: String = ""
var _float_hp0: float = 0.0
var _ambient_before: float = 0.0
var _impact_hp0: float = 0.0

func _ready() -> void:
	_run.call_deferred()

func _run() -> void:
	# AUTO graphics would step tiers on FPS during the run; pin manual mode
	# for determinism and restore (plus persist) afterwards.
	_saved_quality_auto = GameState.quality_auto
	GameState.quality_auto = false
	if GameState.selected_robot != GameState.ROBOT_SCARAB:
		GameState.select_robot(GameState.ROBOT_SCARAB)
	if not GameState.owns_drone("wisp"):
		GameState.owned_drones.append("wisp")
	_game = (load(GAME_SCENE) as PackedScene).instantiate() as Node3D
	add_child(_game)
	for child in _game.get_children():
		if child is EnemyRobot:
			(child as EnemyRobot).ai_enabled = false

func _physics_process(_delta: float) -> void:
	if _game == null:
		return
	_frame += 1
	match _phase:
		0:
			if _frame >= 2:
				_check_static_structure()
				_phase = 1
				_frame = 0
		1:
			if _frame >= WARMUP_FRAMES:
				_verify_router_guard()
				if _player() == null:
					_assert(false, "player node resolvable after scene load")
					_finish()
					return
				_check_settled()
				_check_particle_amounts()
				_start_position = _player().global_position
				InputRouter.set_virtual_move(Vector2(0.0, 1.0))
				_phase = 2
				_frame = 0
		2:
			if _frame >= MOVE_FRAMES:
				InputRouter.set_virtual_move(Vector2.ZERO)
				_check_movement()
				_phase = 3
				_frame = 0
		3:
			if _frame == 0:
				InputRouter.look_delta = Vector2(-PI, 0.0)
			if _frame == 12:
				_stage_lock_check()
			if _frame >= 26:
				_check_lock_acquired()
				_check_lock_cycle()
				_check_target_hud()
				_check_weapons_wired()
				_check_slot_firing()
				InputRouter.set_virtual_fire(true)
				_phase = 4
				_frame = 0
		4:
			if _frame >= 1 and _shot_sample == Vector3.ZERO:
				_shot_sample = _first_player_projectile_position()
			_peak_active = maxi(_peak_active, Projectiles.active_player_count())
			if _first_impact == Vector3.ZERO and Projectiles.impact_count() > 0:
				_first_impact = Projectiles.last_impact_point()
			if _frame == FIRE_FRAMES:
				_check_firing()
				_check_electric_arc()
				_check_electric_parity()
				InputRouter.set_virtual_fire(false)
				_stage_lumen_target()
			if _frame == FIRE_FRAMES + 29:
				_lumen_direct_hit()
			if _frame == FIRE_FRAMES + 31:
				_lumen_place_wall()
			if _frame >= FIRE_FRAMES + 33:
				_lumen_curve_hit()
				_phase = 5
				_frame = 0
		5:
			if _frame >= COOL_FRAMES:
				_check_cooling()
				_force_overheat()
				_phase = 6
				_frame = 0
		6:
			if _frame == 2:
				_check_overheat_lock()
			if _frame >= UNLOCK_FRAMES:
				_check_overheat_unlock()
				_phase = 7
				_frame = 0
		7:
			if _frame == 1:
				_stage_wall_climb()
			if _frame == 10:
				var climb_player := _player()
				_climb_start_y = climb_player.global_position.y if climb_player != null else 0.0
				_climb_peak_y = _climb_start_y
				if climb_player != null:
					print("CLIMB_START pos=%s aim_yaw=%.2f wish=%s" % [
							climb_player.global_position, climb_player.aim_yaw,
							InputRouter.move_vector])
				InputRouter.set_virtual_move(Vector2(0.0, 1.0))
			if _frame >= 10:
				var climb_player := _player()
				if climb_player != null:
					_climb_peak_y = maxf(_climb_peak_y, climb_player.global_position.y)
			if _frame >= 70:
				_check_wall_climb()
				InputRouter.set_virtual_move(Vector2.ZERO)
				_phase = 8
				_frame = 0
		8:
			if _frame == 1:
				InputRouter.set_virtual_move(Vector2(0.0, -1.0))
			if _frame == 10:
				InputRouter.set_virtual_move(Vector2.ZERO)
				var turn_player := _player()
				var cam := _game.get_node_or_null("CameraRig")
				if turn_player != null and cam != null:
					for prop in cam.get_property_list():
						if String(prop["name"]) == "yaw":
							_yaw_before_turn = turn_player.rotation.y
							cam.set("yaw", wrapf(turn_player.rotation.y + PI, -PI, PI))
							break
				InputRouter.look_delta = Vector2(0.001, 0.0)
			if _frame == 119:
				InputRouter.look_delta = Vector2(0.001, 0.0)
			if _frame == 120:
				InputRouter.set_virtual_move(Vector2(0.0, 1.0))
			if _frame == 190:
				InputRouter.set_virtual_move(Vector2.ZERO)
			if _frame >= 260:
				_check_turn_gait()
				_phase = 9
				_frame = 0
		9:
			if _frame == 1:
				_stage_drone_check()
			if _frame == 14:
				if _player() != null:
					_snap_host_facing(_player())
				_check_drone_lock()
			if _frame == 20:
				_check_drone_weight()
			if _frame == 50:
				if _player() != null:
					_snap_host_facing(_player())
			if _frame == 84:
				_check_drone_combat()
			if _frame == 90:
				_stage_drone_heal()
			if _frame == 100:
				_check_drone_heal()
			if _frame == 105:
				_stage_drone_heal()
			if _frame >= 116:
				_check_drone_heal_cooldown()
				_phase = 10
				_frame = 0
		10:
			if _frame == 1:
				_stage_hazard_check()
			if _frame >= 2 and _frame <= 29:
				_hold_in_lake(true)
			if _frame == 30:
				_check_drowning()
				_stage_dash_float()
			if _frame >= 31 and _frame <= 77:
				_hold_in_lake(false)
			if _frame == 78:
				_check_dash_float()
				_end_hazard_stage()
				_stage_weather_check()
			if _frame == 84:
				_check_weather()
				_force_weather_clear()
				_check_regional_weather()
				_stage_volcano_check()
			if _frame == 92:
				_check_volcano()
				_end_environment_checks()
				_phase = 11
				_frame = 0
		11:
			if _frame == 2:
				_kill_player()
			if _frame == 6:
				_check_death_ui()
			if _frame >= 10:
				_phase = 12
				await _check_menu()
				_finish()
		12:
			pass

func _kill_player() -> void:
	var player := _player()
	if player == null:
		return
	player.receive_damage(1.0e9, player.global_position)

func _stage_wall_climb() -> void:
	var player := _player()
	if player == null:
		_assert(false, "player present for wall climb staging")
		return
	player.velocity = Vector3.ZERO
	var space := player.get_world_3d().direct_space_state
	var face_z := NAN
	for probe_height: float in [4.0, 3.0, 2.4]:
		var probe_from := Vector3(0.0, probe_height, -38.0)
		var query := PhysicsRayQueryParameters3D.create(
				probe_from, probe_from + Vector3(0.0, 0.0, -20.0))
		query.collision_mask = Layers.WORLD
		query.exclude = [player.get_rid()]
		var hit := space.intersect_ray(query)
		if not hit.is_empty():
			face_z = (hit["position"] as Vector3).z
			break
	_assert(not is_nan(face_z), "north perimeter wall found for climb staging")
	if is_nan(face_z):
		return
	var target_z := face_z + 1.15
	var down := PhysicsRayQueryParameters3D.create(
			Vector3(0.0, 8.0, target_z), Vector3(0.0, -14.0, target_z))
	down.collision_mask = Layers.WORLD
	down.exclude = [player.get_rid()]
	var floor_hit := space.intersect_ray(down)
	var ground_y := 0.0
	if not floor_hit.is_empty():
		ground_y = (floor_hit["position"] as Vector3).y
	player.global_position = Vector3(0.0, ground_y + 0.15, target_z)
	player.velocity = Vector3.ZERO
	player.aim_yaw = 0.0
	print("CLIMB_STAGE face_z=%.2f ground_y=%.2f placed=%s" % [
			face_z, ground_y, player.global_position])

func _check_wall_climb() -> void:
	var player := _player()
	if player == null:
		_assert(false, "player alive through wall climb test")
		return
	var rise := _climb_peak_y - _climb_start_y
	print("CLIMB_END rise=%.2f pos=%s" % [rise, player.global_position])
	_assert(rise > 1.2,
			"SCARAB climbs the north wall (rise=%.2f start=%.2f peak=%.2f pos=%s)" % [
				rise, _climb_start_y, _climb_peak_y, player.global_position])

func _check_turn_gait() -> void:
	var player := _player()
	if player == null or player.rig == null:
		_assert(false, "player present for turn gait check")
		return
	var turned := absf(wrapf(player.rotation.y - _yaw_before_turn, -PI, PI))
	_assert(turned > 3.0, "hull completed the 180 turn (%.2f rad)" % turned)
	var crossed := 0
	var checked := 0
	for leg in player.rig.leg_units:
		if absf(leg.outward.x) < 0.05:
			continue
		var foot := leg.get_node_or_null("Foot") as Node3D
		if foot == null:
			continue
		checked += 1
		var local := player.global_basis.inverse() \
				* (foot.global_position - player.global_position)
		if not is_finite(local.x) or local.x * leg.outward.x < -0.05:
			crossed += 1
	_assert(checked > 0 and checked == player.rig.leg_units.size(),
			"all feet resolvable for turn gait (%d)" % checked)
	_assert(crossed == 0,
			"feet stay on their own side after a turn (crossed %d of %d)" % [
				crossed, checked])

func _clear_ray(space: PhysicsDirectSpaceState3D, from: Vector3, to: Vector3,
		exclude: Array[RID]) -> bool:
	var query := PhysicsRayQueryParameters3D.new()
	query.from = from
	query.to = to
	query.collision_mask = Layers.WORLD
	query.collide_with_areas = false
	query.exclude = exclude
	return space.intersect_ray(query).is_empty()

# Drive a Button the way a device touch does: through the viewport, so the
# real BaseButton::_gui_input path runs and keeps touching the button after
# `pressed` fires. Emitting `pressed` directly (the old style) skips that
# tail and cannot catch a free-during-signal bug.
func _click_button(host: Control, control: Control) -> void:
	if control == null or not is_instance_valid(control) or host == null:
		return
	# Rows live inside ScrollContainer: a click on an off-screen rect is
	# swallowed by whatever control actually sits at that point.
	var node: Node = control.get_parent()
	while node != null:
		if node is ScrollContainer:
			(node as ScrollContainer).ensure_control_visible(control)
			break
		node = node.get_parent()
	await get_tree().process_frame
	await get_tree().process_frame
	if not is_instance_valid(control):
		return
	var rect := control.get_global_rect()
	var centre := rect.get_center()
	var screen_pos: Vector2 = host.get_viewport().get_screen_transform() * centre
	print("CLICK %s rect=%s screen=%s window=%s" % [
			control.name, rect, screen_pos, get_window().size])
	var hidden_layers: Array[CanvasLayer] = []
	for canvas_node in get_tree().root.find_children(
			"*", "CanvasLayer", true, false):
		var canvas_layer := canvas_node as CanvasLayer
		if canvas_layer.visible:
			canvas_layer.visible = false
			hidden_layers.append(canvas_layer)
	var press := InputEventMouseButton.new()
	press.button_index = MOUSE_BUTTON_LEFT
	press.pressed = true
	press.position = screen_pos
	press.global_position = screen_pos
	host.get_viewport().push_input(press)
	var release := InputEventMouseButton.new()
	release.button_index = MOUSE_BUTTON_LEFT
	release.pressed = false
	release.position = screen_pos
	release.global_position = screen_pos
	host.get_viewport().push_input(release)
	await get_tree().process_frame
	for canvas_layer in hidden_layers:
		canvas_layer.visible = true

func _snap_host_facing(player: PlayerRobot) -> void:
	# keep the host facing the north wall so the staged threat stays behind it
	player.aim_yaw = 0.0
	player.rotation.y = 0.0
	player.velocity = Vector3.ZERO
	var cam := _game.get_node_or_null("CameraRig")
	if cam != null:
		for prop in cam.get_property_list():
			if String(prop["name"]) == "yaw":
				cam.set("yaw", 0.0)
				break
	InputRouter.look_delta = Vector2(0.001, 0.0)

func _stage_drone_check() -> void:
	var player := _player()
	if player == null:
		_assert(false, "player present for drone staging")
		return
	var drone := player.get_node_or_null("DroneOrbit") as Node3D
	if drone == null:
		_assert(false, "drone companion attached for staging")
		return
	_snap_host_facing(player)
	# pick a FRESH enemy far from the player — earlier phases shoot at the
	# lock-staged one, and its survival varies run to run
	var enemy: EnemyRobot = null
	for child in _game.get_children():
		if child is EnemyRobot and (child as EnemyRobot).state != EnemyRobot.State.DEAD \
				and child.global_position.distance_to(player.global_position) > 40.0:
			enemy = child as EnemyRobot
			break
	if enemy == null:
		enemy = _first_enemy()
	if enemy == null:
		_assert(false, "enemy available for drone staging")
		return
	# earlier phases may have chewed this enemy down — heal it so the threat
	# survives the whole check window (a dead threat ends rear-guard duty)
	if enemy.health != null:
		enemy.health.heal(enemy.health.max_health)
	enemy.velocity = Vector3.ZERO
	_drone_shots_before = int(drone.get("shots_fired"))
	_staged_enemy = enemy
	# clear leftovers of earlier phases out of the test zone (they would steal
	# the drone's target lock or block its line of sight)
	var arena := _game.get_node_or_null("OpenRealm") as OpenRealm
	for child in _game.get_children():
		if child is EnemyRobot and child != enemy:
			var other := child as EnemyRobot
			if other.state == EnemyRobot.State.DEAD:
				continue
			if other.global_position.distance_to(player.global_position) < 30.0 \
					and arena != null and not arena.enemy_spawns.is_empty():
				other.global_position = arena.enemy_spawns[0] + Vector3.UP * 0.4
				other.velocity = Vector3.ZERO
	var space := player.get_world_3d().direct_space_state
	var right := player.global_transform.basis.x
	right.y = 0.0
	if right.length_squared() < 0.01:
		right = Vector3.RIGHT
	right = right.normalized()
	var eye := player.global_position + Vector3.UP * 1.6
	var drone_origin := player.global_position + right * 2.6 + Vector3.UP * 2.3
	var exclude: Array[RID] = [player.get_rid()]
	for child in _game.get_children():
		if child is EnemyRobot:
			exclude.append((child as EnemyRobot).get_rid())
	var staged := false
	for distance: float in [12.0, 9.0, 7.0]:
		for lateral: float in [0.0, 4.0, -4.0, 6.0, -6.0]:
			var spot := player.global_position + Vector3(0.0, 0.4, distance) \
					+ right * lateral
			if _clear_ray(space, eye, spot + Vector3.UP * 1.0, exclude) \
					and _clear_ray(space, drone_origin, spot + Vector3.UP * 1.0,
							exclude):
				enemy.global_position = spot
				enemy.velocity = Vector3.ZERO
				staged = true
				break
		if staged:
			break
	if not staged:
		enemy.global_position = player.global_position + Vector3(0.0, 0.4, 7.0)
		enemy.velocity = Vector3.ZERO
	print("DRONE_STAGE player=%s enemy=%s kind=%s hp=%.0f dist=%.0f shots_before=%d" % [
			player.global_position, enemy.global_position, enemy.kind_label(),
			enemy.health.current if enemy.health != null else -1.0,
			enemy.global_position.distance_to(player.global_position),
			_drone_shots_before])

func _check_drone_lock() -> void:
	var player := _player()
	if player == null:
		_assert(false, "player alive through drone stage")
		return
	var drone := player.get_node_or_null("DroneOrbit") as Node3D
	_assert(drone != null, "companion drone attached to robot")
	if drone == null:
		return
	var weapon := drone.get("weapon") as WeaponData
	_assert(weapon != null, "drone carries exactly one built-in weapon")
	if weapon != null:
		_assert(weapon.family != "" and weapon.damage > 0.0,
				"drone weapon is scaled-down combat data (%s dmg %.0f)" % [
					weapon.family, weapon.damage])
	var target := drone.get("target") as EnemyRobot
	_assert(target != null, "drone acquires the threat behind the robot")
	_assert(target == _staged_enemy, "drone locks the staged rear threat")

func _check_drone_weight() -> void:
	var player := _player()
	if player == null:
		_assert(false, "player alive through drone weight check")
		return
	var drone := player.get_node_or_null("DroneOrbit") as Node3D
	if drone == null:
		_assert(false, "drone present for weight check")
		return
	var weight := float(drone.get("rear_guard_weight"))
	_assert(weight > 0.5, "drone repositions when the threat is behind (%.2f)" % weight)
	var target := drone.get("target") as EnemyRobot
	print("DRONE_DEBUG f20 weight=%.2f shots=%d player_yaw=%.2f drone=%s target=%s enemy=%s" % [
			weight, int(drone.get("shots_fired")), player.rotation.y,
			drone.global_position,
			str(target.global_position) if target != null else "null",
			str(_staged_enemy.global_position) if _staged_enemy != null else "null"])

func _check_drone_combat() -> void:
	var player := _player()
	if player == null:
		_assert(false, "player alive through drone combat")
		return
	var drone := player.get_node_or_null("DroneOrbit") as Node3D
	if drone == null:
		_assert(false, "drone present for combat check")
		return
	var shots := int(drone.get("shots_fired")) - _drone_shots_before
	var weapon := drone.get("weapon") as WeaponData
	var min_shots := 3
	if weapon == null or weapon.shots_per_minute < 200.0:
		min_shots = 1
	_assert(shots >= min_shots, "drone fires its weapon independently (%d shots)" % shots)
	var enemy := _staged_enemy
	var hurt := enemy != null and enemy.health != null \
			and enemy.health.current < enemy.health.max_health
	_assert(hurt, "drone weapon damages the target (%s)" % (
			"hp %.0f/%.0f" % [enemy.health.current, enemy.health.max_health]
			if (enemy != null and enemy.health != null) else "no target"))
	var rear := drone.global_position.z - player.global_position.z
	_assert(rear > 1.2, "drone holds the rear-guard position (dz=%.2f)" % rear)
	var distance := drone.global_position.distance_to(player.global_position)
	_assert(distance < 6.5, "drone stays close to the robot (%.2f m)" % distance)
	print("DRONE_DEBUG f84 shots=%d weight=%.2f player_yaw=%.2f drone=%s staged=%s staged_hp=%.0f" % [
			shots, float(drone.get("rear_guard_weight")), player.rotation.y,
			drone.global_position,
			str(enemy.global_position) if enemy != null else "null",
			enemy.health.current if (enemy != null and enemy.health != null) else -1.0])

func _stage_drone_heal() -> void:
	var player := _player()
	if player == null or player.health == null:
		_assert(false, "player health present for drone heal staging")
		return
	player.health.hull = 0.0
	player.health.current = player.health.max_health * 0.2
	_heal_snapshot = player.health.current
	Events.player_health_changed.emit(player.health.current, player.health.max_health)

func _check_drone_heal() -> void:
	var player := _player()
	if player == null or player.health == null:
		_assert(false, "player health present for drone heal check")
		return
	var pct := 0.0
	for definition in GameState.DRONE_DEFS:
		if String(definition.get("id")) == GameState.drone_for_robot(GameState.selected_robot):
			pct = float(definition.get("heal", 0.0))
	_assert(pct > 0.0, "active drone defines an emergency heal (%.0f%%)" % (pct * 100.0))
	var delta := player.health.current - _heal_snapshot
	var expected := player.health.max_health * pct
	_assert(delta >= expected * 0.9
			and delta <= expected * 1.15 + player.health.max_health * 0.01,
			"drone bursts %.0f%% heal at critical HP (delta %.0f, expected %.0f)" % [
				pct * 100.0, delta, expected])
	print("DRONE_HEAL burst pct=%.0f%% hp=%.0f -> %.0f (delta %.0f)" % [
			pct * 100.0, _heal_snapshot, player.health.current, delta])

func _check_drone_heal_cooldown() -> void:
	var player := _player()
	if player == null or player.health == null:
		_assert(false, "player health present for heal cooldown check")
		return
	var delta := player.health.current - _heal_snapshot
	_assert(delta <= player.health.max_health * 0.01,
			"emergency heal respects its cooldown (delta %.0f)" % delta)

func _nature_node() -> Nature:
	return _game.get_node_or_null("Nature") as Nature

func _stage_hazard_check() -> void:
	var player := _player()
	if player == null or player.health == null:
		_assert(false, "player health present for hazard staging")
		return
	Events.hazard_changed.connect(_on_hazard_signal)
	_heal_full(player)
	player.global_position = Vector3(OpenRealm.LAKE_CENTRE.x, -2.5,
			OpenRealm.LAKE_CENTRE.y)
	player.velocity = Vector3.ZERO
	_hazard_hp0 = player.health.current
	_hazard_seen = ""

func _on_hazard_signal(kind: String) -> void:
	_hazard_seen = kind

func _hold_in_lake(clamp_y: bool) -> void:
	var player := _player()
	if player == null:
		return
	var point := player.global_position
	point.x = OpenRealm.LAKE_CENTRE.x
	point.z = OpenRealm.LAKE_CENTRE.y
	if clamp_y:
		point.y = -2.5
		player.velocity = Vector3.ZERO
	player.global_position = point

func _check_drowning() -> void:
	var player := _player()
	if player == null or player.health == null:
		_assert(false, "player health present for drowning check")
		return
	var loss := _hazard_hp0 - player.health.current
	_assert(loss > 1000.0, "standing in the lake drains HP (loss %.0f)" % loss)
	_assert(_hazard_seen == "WATER",
			"hazard signal reports WATER (got '%s')" % _hazard_seen)
	var chip := _game.get_node_or_null("HudLayer/Hud/HazardChip") as Label
	_assert(chip != null and chip.visible and String(chip.text).contains("WATER"),
			"HUD hazard chip shows WATER")
	print("DROWN hp %.0f -> %.0f (loss %.0f) signal=%s" % [
			_hazard_hp0, player.health.current, loss, _hazard_seen])

func _stage_dash_float() -> void:
	var player := _player()
	if player == null or player.health == null or player.ability == null:
		_assert(false, "player ability present for dash float staging")
		return
	_float_hp0 = player.health.current
	player.ability.activate()

func _check_dash_float() -> void:
	var player := _player()
	if player == null or player.health == null or player.ability == null:
		_assert(false, "player ability present for dash float check")
		return
	var loss := _float_hp0 - player.health.current
	_assert(player.ability.is_dash_active(), "dash active across the float window")
	_assert(loss <= player.health.max_health * 0.01,
			"dash floats over the lake with no drowning (loss %.0f)" % loss)
	_assert(player.global_position.y >= OpenRealm.WATER_LEVEL - 0.1,
			"floater rides above the surface (y=%.2f)" % player.global_position.y)
	print("DASH_FLOAT active=%s y=%.2f loss=%.0f" % [
			player.ability.is_dash_active(), player.global_position.y, loss])

func _end_hazard_stage() -> void:
	var player := _player()
	if Events.hazard_changed.is_connected(_on_hazard_signal):
		Events.hazard_changed.disconnect(_on_hazard_signal)
	if player == null:
		return
	if player.ability != null:
		player.ability.force_end()
	player.global_position = _start_position
	player.velocity = Vector3.ZERO
	if player.health != null:
		_heal_full(player)

func _heal_full(player: PlayerRobot) -> void:
	# Durability is War Robots style: permanent hull damage caps repairs, so a
	# test that wants a clean full bar clears it first.
	if player == null or player.health == null:
		return
	player.health.hull = 0.0
	player.health.heal(player.health.max_health)
	Events.player_health_changed.emit(player.health.current, player.health.max_health)

func _stage_weather_check() -> void:
	var nature := _nature_node()
	_assert(nature != null, "nature backdrop present for weather")
	if nature == null:
		return
	var weather := nature.get_node_or_null("WeatherSystem") as WeatherSystem
	_assert(weather != null, "weather system wired into the realm")
	if weather == null:
		return
	var world := _game.get_node_or_null("OpenRealm/WorldEnvironment") as WorldEnvironment
	if world != null and world.environment != null:
		# Compare against the weather system's clear-day base: lightning pulses
		# the live energy, and a natural storm may already have started.
		_ambient_before = weather._ambient_true
	weather.force_state("rain")

func _check_weather() -> void:
	var nature := _nature_node()
	if nature == null:
		_assert(false, "nature present for weather check")
		return
	var weather := nature.get_node_or_null("WeatherSystem") as WeatherSystem
	if weather == null:
		_assert(false, "weather system present for weather check")
		return
	_assert(weather.state == WeatherSystem.State.RAIN,
			"forced weather state reaches RAIN (%s)" % weather.state_name())
	_assert(weather._rain.emitting, "rain cell particles running")
	_assert(nature.wind_scale >= 2.0, "wind rises for the storm (%.1f)" % nature.wind_scale)
	var world := _game.get_node_or_null("OpenRealm/WorldEnvironment") as WorldEnvironment
	var ambient := 0.0
	if world != null and world.environment != null:
		ambient = nature._ambient_base
	_assert(ambient > 0.0 and ambient < _ambient_before * 0.8,
			"rain dims the ambient light (%.2f < %.2f)" % [ambient, _ambient_before])
	var water := _game.get_node_or_null("OpenRealm/RealmWater") as MeshInstance3D
	if water != null and water.mesh is PlaneMesh:
		var material := (water.mesh as PlaneMesh).material as ShaderMaterial
		_assert(material != null
				and material.get_shader_parameter("rain_strength") == 1.0,
				"lake shader picks up the rain")

func _force_weather_clear() -> void:
	var nature := _nature_node()
	if nature == null:
		return
	var weather := nature.get_node_or_null("WeatherSystem") as WeatherSystem
	if weather != null:
		weather.force_state("clear")
	_assert(nature.wind_scale == 1.0, "wind returns to calm after the rain")

func _check_regional_weather() -> void:
	# Regional micro-climates must persist even on a clear day: industrial
	# district rains, ruins snow, and every other district stays dry.
	var nature := _nature_node()
	if nature == null:
		_assert(false, "nature present for regional weather check")
		return
	var weather := nature.get_node_or_null("WeatherSystem") as WeatherSystem
	if weather == null:
		_assert(false, "weather system present for regional weather check")
		return
	_assert(weather._zones.size() == 5,
			"five regional weather zones (got %d)" % weather._zones.size())
	var industrial := weather.get_node_or_null("ZoneINDUSTRIAL") as CPUParticles3D
	var ruins := weather.get_node_or_null("ZoneRUINS") as CPUParticles3D
	var hub := weather.get_node_or_null("ZoneHUB") as CPUParticles3D
	_assert(industrial != null and industrial.emitting,
			"industrial district permanently rains")
	_assert(ruins != null and ruins.emitting,
			"ruins district permanently snows")
	_assert(hub == null or not hub.emitting,
			"hub stays dry while neighbours weather")

func _stage_volcano_check() -> void:
	var nature := _nature_node()
	if nature == null:
		_assert(false, "nature present for volcano check")
		return
	var volcano := nature.get_node_or_null("VolcanoActivity") as VolcanoActivity
	_assert(volcano != null, "volcano activity wired into the realm")
	if volcano != null:
		volcano._erupt_left = 0.0
		volcano.force_eruption()

func _check_volcano() -> void:
	var nature := _nature_node()
	if nature == null:
		_assert(false, "nature present for eruption check")
		return
	var volcano := nature.get_node_or_null("VolcanoActivity") as VolcanoActivity
	if volcano == null:
		_assert(false, "volcano activity present for eruption check")
		return
	_assert(volcano._fountain.emitting, "lava fountain erupts on demand")
	_assert(volcano._rocks.size() >= 1,
			"fire rocks launch toward the map (%d)" % volcano._rocks.size())
	var player := _player()
	if player == null or player.health == null:
		_assert(false, "player health present for impact check")
		return
	_impact_hp0 = player.health.current
	volcano.impact_at(player.global_position)
	var loss := _impact_hp0 - player.health.current
	_assert(loss >= player.health.max_health * 0.05,
			"fire-rock impact damages the robot (loss %.0f)" % loss)
	print("VOLCANO fountain rocks=%d impact_loss=%.0f" % [
			volcano._rocks.size(), loss])

func _end_environment_checks() -> void:
	var nature := _nature_node()
	if nature == null:
		return
	var weather := nature.get_node_or_null("WeatherSystem") as WeatherSystem
	if weather != null:
		weather.force_state("clear")
	var volcano := nature.get_node_or_null("VolcanoActivity") as VolcanoActivity
	if volcano != null:
		volcano._finish_eruption()
		for entry in volcano._rocks:
			var rock := entry.get("node") as Node3D
			if is_instance_valid(rock):
				rock.queue_free()
		volcano._rocks.clear()
	var player := _player()
	if player != null and player.health != null:
		_heal_full(player)
	var numbers := _game.get_node_or_null("HudLayer/Hud/DamageNumbers")
	if numbers != null and numbers.has_method("clear_entries"):
		numbers.call("clear_entries")

func _check_death_ui() -> void:
	var hud := _game.get_node_or_null("HudLayer/Hud") as Control
	_assert(hud != null, "hud present after death")
	if hud == null:
		return
	var panel := hud.get_node_or_null("EndPanel") as Control
	_assert(panel != null, "end panel exists")
	if panel == null:
		return
	_assert(panel.visible, "death end panel visible")
	var viewport := get_viewport().get_visible_rect()
	var seen_redeploy := false
	var seen_menu := false
	var button_count := 0
	for child in panel.get_children():
		if not (child is Button):
			continue
		var button := child as Button
		button_count += 1
		if button.text == "REDEPLOY":
			seen_redeploy = true
		if button.text == "MAIN MENU":
			seen_menu = true
		_assert(not button.disabled, "end button enabled (%s)" % button.text)
		var rect := button.get_global_rect()
		_assert(rect.size.x > 0.0 and rect.position.x >= -1.0
				and rect.position.y >= -1.0 and rect.end.x <= viewport.size.x + 1.0
				and rect.end.y <= viewport.size.y + 1.0,
				"end button inside viewport (%s %s)" % [button.text, rect])
	_assert(button_count >= 2, "end panel has buttons (%d)" % button_count)
	_assert(seen_redeploy, "redeploy button present")
	_assert(seen_menu, "main menu button present")
	_assert(GameState.match_reward_silver > 0 and GameState.match_reward_gold > 0,
			"match rewards tracked (%d silver / %d gold)" % [
				GameState.match_reward_silver, GameState.match_reward_gold])
	# postbattle-ui: rewards broken into readable lines + named controls
	var end_stats := panel.get_node_or_null("EndStats") as Label
	_assert(end_stats != null, "end panel stats label present")
	if end_stats != null:
		var stats_text := String(end_stats.text)
		_assert(stats_text.contains("REWARDS") and stats_text.contains("MODULES")
				and stats_text.contains("PILOT XP"),
				"end panel lists rewards + modules + pilot xp (%s)" %
					stats_text.replace("\n", " | "))
	_assert(GameState.match_reward_modules > 0,
			"module points tracked for the match (%d)" % GameState.match_reward_modules)
	_assert(panel.get_node_or_null("RedeployButton") != null
			and panel.get_node_or_null("MainMenuButton") != null,
			"end buttons are named")
	# postbattle results card: report column + rewards column + subtitle
	var end_subtitle := panel.get_node_or_null("EndSubtitle") as Label
	_assert(end_subtitle != null and not String(end_subtitle.text).is_empty(),
			"results subtitle present (%s)" % (
				String(end_subtitle.text) if end_subtitle != null else "?"))
	_assert(panel.get_node_or_null("ReportHeader") != null
			and panel.get_node_or_null("RewardsHeader") != null,
			"results carry battle-report + rewards headers")
	var report_dealt := panel.get_node_or_null("ReportValue_Dealt") as Label
	_assert(report_dealt != null and not String(report_dealt.text).is_empty(),
			"results show damage dealt (%s)" % (
				String(report_dealt.text) if report_dealt != null else "?"))
	var report_kills := panel.get_node_or_null("ReportValue_Kills") as Label
	_assert(report_kills != null and String(report_kills.text).is_valid_int(),
			"results show the kill count (%s)" % (
				String(report_kills.text) if report_kills != null else "?"))
	var report_time := panel.get_node_or_null("ReportValue_Time") as Label
	_assert(report_time != null and String(report_time.text).contains(":"),
			"results show the mission time (%s)" % (
				String(report_time.text) if report_time != null else "?"))

func _stage_lock_check() -> void:
	var player := _player()
	var enemy := _first_enemy()
	var camera := get_viewport().get_camera_3d()
	if player == null or enemy == null or camera == null:
		return
	var forward := -camera.global_transform.basis.z
	forward.y = 0.0
	if forward.length_squared() < 0.01:
		forward = Vector3.FORWARD
	forward = forward.normalized()
	var blockers: Array[RID] = [player.get_rid()]
	for child in _game.get_children():
		if child is EnemyRobot:
			blockers.append((child as EnemyRobot).get_rid())
	var candidates: Array[float] = [6.0, 4.5, 3.0, 9.0, 12.0]
	var staged := false
	for distance in candidates:
		var spot := player.global_position + forward * distance + Vector3.UP * 0.4
		var query := PhysicsRayQueryParameters3D.new()
		query.from = camera.global_position
		query.to = spot + Vector3.UP * 1.4
		query.collision_mask = Layers.WORLD
		query.collide_with_areas = false
		query.exclude = blockers
		if _game.get_world_3d().direct_space_state.intersect_ray(query).is_empty():
			enemy.global_position = spot
			enemy.velocity = Vector3.ZERO
			staged = true
			break
	if not staged:
		enemy.global_position = player.global_position + forward * 6.0 + Vector3.UP * 0.4
		enemy.velocity = Vector3.ZERO
	# Stage a second candidate in the same cone so the lock-cycle check has
	# something real to advance to.
	_lock_second_staged = false
	var second := _second_enemy()
	if second != null:
		var distances: Array[float] = [14.0, 16.0, 10.0, 4.5, 3.0]
		for distance in distances:
			var spot := player.global_position + forward * distance + Vector3.UP * 0.4
			if spot.distance_to(enemy.global_position) < 2.5:
				continue
			var second_query := PhysicsRayQueryParameters3D.new()
			second_query.from = camera.global_position
			second_query.to = spot + Vector3.UP * 1.4
			second_query.collision_mask = Layers.WORLD
			second_query.collide_with_areas = false
			second_query.exclude = blockers
			if _game.get_world_3d().direct_space_state.intersect_ray(second_query).is_empty():
				second.global_position = spot
				second.velocity = Vector3.ZERO
				_lock_second_staged = true
				print("LOCK_STAGE second=%s dist=%.1f" % [second.global_position, distance])
				break

func _second_enemy() -> EnemyRobot:
	var first := _first_enemy()
	for child in _game.get_children():
		if child is EnemyRobot and (child as EnemyRobot) != first \
				and (child as EnemyRobot).state != EnemyRobot.State.DEAD:
			return child as EnemyRobot
	return null

func _first_enemy() -> EnemyRobot:
	for child in _game.get_children():
		if child is EnemyRobot and (child as EnemyRobot).state != EnemyRobot.State.DEAD:
			return child as EnemyRobot
	return null

func _first_player_projectile_position() -> Vector3:
	for child in Projectiles.get_children():
		var projectile := child as Projectile
		if projectile != null and projectile.is_active() \
				and not projectile.weapon_item_id().begins_with("DRONE-"):
			return projectile.global_position
	return Vector3.ZERO

func _check_lock_acquired() -> void:
	var target := _game.get_lock_target() as EnemyRobot
	if target != null:
		_assert(true, "lock-on acquires enemy ahead of player")
		return
	var camera := get_viewport().get_camera_3d()
	var enemy := _first_enemy()
	var player := _player()
	var detail := "camera=%s enemy=%s player=%s" % [camera != null, enemy != null, player != null]
	if camera != null and enemy != null and player != null:
		var anchor := enemy.global_position + Vector3.UP * 1.4
		var behind := camera.is_position_behind(anchor)
		var screen := camera.unproject_position(anchor)
		var centre := get_viewport().get_visible_rect().size * 0.5
		var query := PhysicsRayQueryParameters3D.new()
		query.from = camera.global_position
		query.to = anchor
		query.collision_mask = Layers.WORLD
		query.collide_with_areas = false
		var blockers: Array[RID] = [player.get_rid()]
		for child in _game.get_children():
			if child is EnemyRobot:
				blockers.append((child as EnemyRobot).get_rid())
		query.exclude = blockers
		var hit := _game.get_world_3d().direct_space_state.intersect_ray(query)
		var hit_text := "clear"
		if not hit.is_empty():
			hit_text = str(hit.get("collider"))
		detail = "behind=%s dist=%.0f/%.0f los=%s enemy=(%.1f,%.1f) cam=(%.1f,%.1f,%.1f)" % [
				behind, screen.distance_to(centre),
				minf(get_viewport().get_visible_rect().size.x,
						get_viewport().get_visible_rect().size.y) * 0.24,
				hit_text, enemy.global_position.y, anchor.y,
				camera.global_position.x, camera.global_position.y, camera.global_position.z]
	_assert(target != null, "lock-on acquires enemy ahead of player (%s)" % detail)

func _check_lock_cycle() -> void:
	var candidates: Array = _game._cone_candidates()
	_assert(candidates.size() >= 1, "lock cone holds candidates (%d)" % candidates.size())
	var best := _game.get_lock_target() as EnemyRobot
	_assert(best != null and candidates.find(best) >= 0,
			"auto lock sits among cone candidates")
	if _lock_second_staged:
		_assert(candidates.size() >= 2,
				"two enemies staged inside the lock cone (%d)" % candidates.size())
		Events.lock_cycle_requested.emit()
		var advanced := _game.get_lock_target() as EnemyRobot
		_assert(advanced != null and advanced != best,
				"lock cycle advances to the next enemy")
		var wrapped := advanced
		var steps := 1
		while wrapped != best and steps < candidates.size():
			Events.lock_cycle_requested.emit()
			wrapped = _game.get_lock_target() as EnemyRobot
			steps += 1
		_assert(wrapped == best,
				"lock cycle wraps back to the closest enemy (%d steps, %d candidates)" % [
					steps, candidates.size()])
	else:
		Events.lock_cycle_requested.emit()
		var kept := _game.get_lock_target() as EnemyRobot
		_assert(kept == best, "single-candidate lock cycle keeps the same target")

func _check_target_hud() -> void:
	# War Robots target HUD: locked-enemy bracket, extended target box,
	# accumulating damage numbers, per-class shields and status chips.
	var hud := _game.get_node_or_null("HudLayer/Hud") as Control
	_assert(hud != null, "hud present for target hud checks")
	if hud == null:
		return
	var target := _game.get_lock_target() as EnemyRobot
	_assert(target != null, "lock target available for hud checks")
	if target == null:
		return
	var camera := get_viewport().get_camera_3d()
	_assert(camera != null, "camera available for target projection")
	if camera == null:
		return
	var frame := hud.get_node_or_null("Crosshair/LockFrame") as Control
	_assert(frame != null, "lock frame built inside the crosshair")
	if frame == null:
		return
	var hud_target := hud.get("_locked_enemy") as EnemyRobot
	_assert(hud_target == target, "hud bracket targets the session lock")
	if hud_target == null or hud_target != target:
		return
	_assert(frame.size.x > 0.0 and frame.size.y > 0.0,
			"lock frame carries a laid-out size (%s)" % frame.size)
	# Reproject synchronously so camera settle cannot drift the comparison.
	hud.call("_update_lock_frame")
	var anchor := target.global_position + Vector3.UP * 1.5
	var expected := camera.unproject_position(anchor)
	var followed := frame.global_position + frame.size * 0.5
	_assert(frame.visible, "lock frame visible on the locked enemy")
	_assert(followed.distance_to(expected) < 6.0,
			"lock frame sits on the enemy anchor (%.1f px)" % followed.distance_to(expected))
	# The bracket must track the bot instead of freezing on the old spot.  The
	# lateral step scales with range so the pixel delta always clears 40 px even
	# on a distant lock (a fixed 2 m shove reads as <10 px past ~60 m).
	var right := camera.global_transform.basis.x
	var camera_distance := camera.global_position.distance_to(target.global_position)
	var lateral := maxf(3.0, camera_distance * 0.16)
	target.global_position += right * lateral
	hud.call("_update_lock_frame")
	var moved := camera.unproject_position(target.global_position + Vector3.UP * 1.5)
	followed = frame.global_position + frame.size * 0.5
	_assert(followed.distance_to(moved) < 6.0,
			"lock frame follows the moved enemy (%.1f px)" % followed.distance_to(moved))
	_assert(followed.distance_to(expected) > 40.0,
			"lock frame leaves the old anchor (%.0f px)" % followed.distance_to(expected))
	target.global_position -= right * lateral
	hud.call("_update_lock_frame")
	# Director round: the old second dialog duplicated the marker's name/hull/
	# range readout. The glassy per-enemy marker is now the only one.
	_assert(hud.get_node_or_null("TargetInfo") == null,
			"no duplicate target dialog in the hud")
	# Damage flash must tint the edges only — the old full-screen rect washed
	# the whole picture pink on device.
	var vignette := hud.get("_vignette") as ColorRect
	_assert(vignette != null and vignette.material is ShaderMaterial,
			"damage vignette uses the edge-falloff shader")
	_assert(EnemyMarkers.OCCLUDER_PANELS.has("EndPanel"),
			"markers hide behind the end panel")
	# Accumulating damage numbers (WR Damage Report: one number per bot).
	var numbers := hud.get_node_or_null("DamageNumbers") as DamageNumbers
	_assert(numbers != null, "damage number layer present")
	if numbers != null:
		var previous_damage := GameState.damage_numbers
		GameState.damage_numbers = true
		if target.health != null:
			target.health.last_hit_zone = Health.Zone.HULL
		numbers.call("clear_entries")
		var point := target.global_position + Vector3.UP * 1.5
		numbers.call("_on_damage_applied", target, 120.0, point, Vector3.UP)
		numbers.call("_on_damage_applied", target, 80.0, point, Vector3.UP)
		var entries := int(numbers.call("entry_count"))
		_assert(entries == 1, "damage numbers share one entry per target (%d)" % entries)
		var accum: Dictionary = numbers._accum
		var target_id := target.get_instance_id()
		var entry: Dictionary = {}
		if accum.has(target_id):
			entry = accum[target_id]
		var hull_total := float(entry.get("hull", 0.0))
		_assert(absf(hull_total - 200.0) <= 0.5,
				"damage numbers add up consecutive hits (%.1f)" % hull_total)
		# Past the hide delay the counter fades but keeps its total.
		entry["last"] = 2.5
		numbers.call("_process", 0.016)
		_assert(not bool(entry.get("shown", true)),
				"damage number fades after the hide delay")
		numbers.call("_on_damage_applied", target, 50.0, point, Vector3.UP)
		hull_total = float(entry.get("hull", 0.0))
		_assert(absf(hull_total - 250.0) <= 0.5,
				"damage number resumes from its previous total (%.1f)" % hull_total)
		_assert(bool(entry.get("shown", false)),
				"damage number reappears on the next hit")
		numbers.call("clear_entries")
		GameState.damage_numbers = previous_damage
	# Per-class shields on the live roster (structural reads only).
	var kinds: Dictionary = {}
	for child in _game.get_children():
		if child is EnemyRobot:
			var enemy := child as EnemyRobot
			var kind_key := String(enemy.kind)
			if not kinds.has(kind_key):
				kinds[kind_key] = enemy
	_assert(kinds.size() == 4, "enemy roster covers four shield classes (%d)" % kinds.size())
	var brute := kinds.get("BRUTE") as EnemyRobot
	var stalker := kinds.get("STALKER") as EnemyRobot
	var wasp := kinds.get("WASP") as EnemyRobot
	var scuttler := kinds.get("SCUTTLER") as EnemyRobot
	_assert(brute != null and brute.health != null and brute.health.has_shield()
			and brute.health.shield_kind == Health.Zone.PHYSICAL,
			"BRUTE walks a physical shield")
	_assert(brute != null and brute.get_node_or_null("ShieldBubble") != null,
			"BRUTE renders its shield bubble")
	_assert(stalker != null and stalker.health != null
			and stalker.health.shield_kind == Health.Zone.ANCILE
			and stalker.health.shield_regen > 0.0,
			"STALKER carries a regenerating Ancile")
	_assert(wasp != null and wasp.health != null and wasp.health.has_shield()
			and wasp.health.shield_kind == Health.Zone.AEGIS,
			"WASP flies under an Aegis shield")
	_assert(scuttler != null and scuttler.health != null
			and not scuttler.health.has_shield(),
			"SCUTTLER has no shield pool")
	# Shield soak behaviour on a scratch Health (live enemies untouched).
	var probe := Health.new()
	probe.max_health = 100.0
	probe.current = 100.0
	add_child(probe)
	var broke := [false]
	var on_broken := func(_kind: int) -> void:
		broke[0] = true
	probe.shield_broken.connect(on_broken)
	probe.configure_shield(Health.Zone.ANCILE, 40.0, 10.0)
	probe.apply_damage(15.0, Vector3.ZERO)
	_assert(absf(probe.shield - 25.0) < 0.01,
			"shield soaks the hit before the hull (%.1f left)" % probe.shield)
	_assert(probe.current == 100.0, "hull untouched while the shield holds")
	_assert(probe.last_hit_zone == Health.Zone.ANCILE,
			"shield hit records the Ancile zone")
	probe.apply_damage(999.0, Vector3.ZERO)
	_assert(probe.shield == 0.0, "overkill drains the shield pool")
	_assert(bool(broke[0]), "shield break signal fires on depletion")
	_assert(probe.current < 100.0,
			"overflow spills into the hull (%.0f left)" % probe.current)
	probe.queue_free()
	# WR status chips on the enemy marker row.
	var marked := _first_enemy()
	_assert(marked != null, "live enemy available for the status chip check")
	if marked == null:
		return
	marked.apply_thermal_breach(3)
	marked.apply_suppression(0.6)
	var row_icons := marked.status_icon_row()
	_assert(row_icons.has("BR"), "thermal breach raises the BR icon")
	_assert(marked.status_icon_stacks("BR") == 3,
			"BR icon carries its stack count (%d)" % marked.status_icon_stacks("BR"))
	_assert(row_icons.has("SU"), "suppression raises the SU icon")
	var markers := hud.get_node_or_null("EnemyMarkers") as EnemyMarkers
	_assert(markers != null, "enemy marker layer present")
	var marker_data: Dictionary = {}
	if markers != null:
		var mid := marked.get_instance_id()
		if not markers._markers.has(mid):
			markers._create_marker(marked)
		marker_data = markers._markers[mid]
		markers.call("_sync_status", marker_data, marked)
		var status_row := marker_data.get("status_row") as Control
		_assert(status_row != null and status_row.get_child_count() >= 2,
				"marker row draws the effect chips (%d)" % (
					status_row.get_child_count() if status_row != null else 0))
		# Single glassy readout: frame + name + hull number live on the marker
		# itself (the duplicate dialog was removed this round).
		var glass := marker_data.get("glass") as Panel
		_assert(glass != null, "marker carries its glassy frame")
		if glass != null:
			var style := glass.get_theme_stylebox("panel") as StyleBoxFlat
			_assert(style != null and style.bg_color.a <= 0.55,
					"marker glass stays translucent (%.2f)" % (
						style.bg_color.a if style != null else 1.0))
			_assert(glass.size.x <= 90.0,
					"marker glass slab stays slim (%.0f px)" % glass.size.x)
		var marker_root := marker_data.get("root") as Control
		_assert(marker_root != null
				and marker_root.size.x <= 90.0 and marker_root.size.y <= 56.0,
				"marker stays a thin readout (%s)" % (
					str(marker_root.size) if marker_root != null else "null"))
		var hp_readout := marker_data.get("hp") as Label
		_assert(hp_readout != null, "marker reads out the hull value")
		var name_readout := marker_data.get("name") as Label
		_assert(name_readout != null and not name_readout.text.is_empty(),
				"marker names the hostile")
		markers.call("_update_positions")
		if hp_readout != null and marker_root != null and marker_root.visible:
			_assert(not hp_readout.text.is_empty(),
					"marker hull number fills on screen (%s)" % hp_readout.text)
	# Mandatory cleanup so later phases see a clean roster.  Only BR/SU are
	# asserted clear — the wisp drone can legitimately hold an SL slow.
	marked._breach_stacks = 0
	marked._breach_left = 0.0
	marked._suppression_left = 0.0
	if markers != null and not marker_data.is_empty():
		markers.call("_sync_status", marker_data, marked)
	var cleared_icons := marked.status_icon_row()
	_assert(not cleared_icons.has("BR") and not cleared_icons.has("SU"),
			"status effects clear after the chip check")

func _check_slot_firing() -> void:
	var system := _weapon_system()
	if system == null:
		_assert(false, "weapon system present for slot firing check")
		return
	var shots_before := system.shots_fired
	var heat_before := system.total_heat()
	InputRouter.set_virtual_slot(0, true)
	InputRouter._process(0.016)
	_assert(InputRouter.slot_held[0], "slot 0 press reaches InputRouter")
	system._physics_process(0.016)
	InputRouter.set_virtual_slot(0, false)
	InputRouter._process(0.016)
	_assert(not InputRouter.slot_held[0], "slot 0 release clears InputRouter")
	_assert(system.shots_fired > shots_before,
			"weapon segment fires its own gun alone (%d→%d)" % [shots_before, system.shots_fired])
	_assert(system.total_heat() > heat_before,
			"slot shot generated heat (%.3f→%.3f)" % [heat_before, system.total_heat()])

func _check_menu() -> void:
	_game.call("_open_exit_confirm")
	var pause := _game.get_node_or_null("ExitConfirm")
	_assert(pause != null and pause.visible, "pause menu opens")
	_assert(get_tree().paused, "match tree pauses behind pause menu")
	if pause != null:
		_assert(pause.get_node_or_null("PauseBox/PauseTitle") != null, "pause title present")
		_assert(pause.get_node_or_null("PauseBox/ResumeButton") != null, "pause resume button")
		_assert(pause.get_node_or_null("PauseBox/RestartButton") != null, "pause restart button")
		_assert(pause.get_node_or_null("PauseBox/GraphicsButton") != null, "pause graphics button")
		_assert(pause.get_node_or_null("PauseBox/LeaveButton") != null, "pause leave button")
		_assert(pause.get_node_or_null("PauseBox/PauseHint") != null, "pause controls hint present")
		var pause_hint := pause.get_node_or_null("PauseBox/PauseHint") as Label
		if pause_hint != null:
			_assert(not pause_hint.text.strip_edges().is_empty(),
					"pause hint carries platform text")
	_game.call("_close_pause")
	_assert(not get_tree().paused, "closing pause resumes the tree")
	var menu := (load("res://scenes/main_menu.tscn") as PackedScene).instantiate() as Control
	add_child(menu)
	_assert(menu != null, "menu scene instantiates")
	if menu == null:
		return
	# Anchors, bay sizing and pointer projections need two real frames.
	await get_tree().process_frame
	await get_tree().process_frame

	# --- shell: background, stamp, screen stack, persistent chrome ---
	_assert(menu.get_node_or_null("Background") != null, "menu background present")
	_assert(menu.get_node_or_null("GridBackdrop") != null, "menu grid backdrop present")
	var ui := menu.get_node_or_null("UI") as UIManager
	_assert(ui != null, "UIManager shell present")
	var stamp := menu.get_node_or_null("UI/ResourceBar/BarRow/BuildStamp") as Label
	_assert(stamp != null and String(stamp.text) == GameState.BUILD_LABEL,
			"build stamp shown (%s)" % (String(stamp.text) if stamp != null else "?"))
	if ui == null:
		menu.queue_free()
		return
	_assert(ui.current() == &"hangar", "hangar is the root screen")
	_assert(ui.stack_depth() == 1, "stack starts at the hangar")
	_assert(menu.get_node_or_null("UI/Screens") != null, "screen stack container present")
	_assert(menu.get_node_or_null("UI/ResourceBar") != null, "resource bar present")
	_assert(menu.find_children("QuitCancelButton", "Button", true, false).size() == 1,
			"quit confirm wired")
	var start_buttons := menu.find_children("StartButton", "Button", true, false)
	_assert(start_buttons.size() == 1
			and (start_buttons[0] as Button).text == "TO BATTLE",
			"battle CTA present and labelled (%d matches)" % start_buttons.size())
	var level_chip := menu.find_children("ChipLevel", "Panel", true, false)
	_assert(level_chip.size() == 1, "level chip present")
	if level_chip.size() == 1:
		var level_text := ""
		for label_node in (level_chip[0] as Control).find_children(
				"*", "Label", true, false):
			level_text += (label_node as Label).text
		_assert(level_text.contains("LV ") and level_text.contains("ACCOUNT"),
				"level chip live (%s)" % level_text)
	var silver_chip := menu.find_children("ChipSilver", "Panel", true, false)
	_assert(silver_chip.size() == 1, "silver chip present")
	if silver_chip.size() == 1:
		var silver_text := ""
		for label_node in (silver_chip[0] as Control).find_children(
				"*", "Label", true, false):
			silver_text += (label_node as Label).text
		_assert(silver_text.contains(UiParts.money(GameState.silver)),
				"silver chip mirrors the wallet (%s)" % silver_text)
	var gold_chip := menu.find_children("ChipGold", "Panel", true, false)
	_assert(gold_chip.size() == 1, "hangar gold chip exists")
	var platinum_chip := menu.find_children("ChipPlatinum", "Panel", true, false)
	_assert(platinum_chip.size() == 1, "platinum chip present")
	if platinum_chip.size() == 1:
		var platinum_text := ""
		for label_node in (platinum_chip[0] as Control).find_children(
				"*", "Label", true, false):
			platinum_text += (label_node as Label).text
		_assert(platinum_text.contains("PLAT") and platinum_text.length() > 5,
				"platinum chip labelled + live (%s)" % platinum_text)

	# --- hangar bay: environment, camera, pose driver ---
	var hangar := ui.screen(&"hangar") as HangarScreen
	_assert(hangar != null, "hangar screen wired")
	if hangar == null:
		menu.queue_free()
		return
	_assert(hangar.visible and not hangar.is_opaque(),
			"hangar is the visible transparent root")
	# TO BATTLE must deploy directly — the merged build pushed the game
	# modes hub instead, so no match ever started from the menu.
	if start_buttons.size() == 1:
		SceneRouter._switching = true
		(start_buttons[0] as Button).pressed.emit()
		_assert(hangar._leaving, "TO BATTLE arms the deploy path immediately")
		_assert(ui.stack_depth() == 1 and ui.current() == &"hangar",
				"TO BATTLE opens no menu detour (depth %d, %s)" % [
					ui.stack_depth(), ui.current()])
		hangar._leaving = false
		ui._leaving = false
		SceneRouter._switching = false
	var bay_env := hangar.bay_viewport().get_node_or_null("BayEnvironment") as WorldEnvironment
	_assert(bay_env != null and bay_env.environment != null
			and bay_env.environment.background_mode == Environment.BG_SKY,
			"bay uses bright sky background")
	var preview_control := hangar.bay_control() as Control
	_assert(preview_control != null and preview_control.size.x > 1.0
			and preview_control.mouse_filter == Control.MOUSE_FILTER_STOP,
			"bay captures drag input (%s)" % str(
				preview_control.size if preview_control != null else Vector2.ZERO))
	var preview_camera := hangar.bay_camera()
	_assert(preview_camera != null, "bay camera present")
	# v0.37.0 declutter: the deck dock, crew column and drag hint are gone —
	# every pad carries a + button instead of a name chip.
	var bay_slot_plus := menu.find_children("SlotPlus_*", "Button", true, false)
	_assert(bay_slot_plus.size() == HangarSlots.SLOTS.size(),
			"every pad carries a + button (%d/%d)" % [
				bay_slot_plus.size(), HangarSlots.SLOTS.size()])
	_assert(menu.find_children("BottomDock", "", true, false).size() == 0
			and menu.find_children("LeftNav", "", true, false).size() == 0
			and menu.find_children("DragHint", "", true, false).size() == 0
			and menu.find_children("DeckChip_*", "Button", true, false).size() == 0
			and menu.find_children("TitanChip", "Button", true, false).size() == 0,
			"hangar chrome decluttered (no dock / crew column / deck chips)")
	var summary_labels := menu.find_children("WeaponSummary", "Label", true, false)
	_assert(summary_labels.size() == 1
			and (String((summary_labels[0] as Label).text).contains("×")
				or String((summary_labels[0] as Label).text) == "NO WEAPONS MOUNTED"),
			"hangar shows only a weapon summary (%s)" % (
				String((summary_labels[0] as Label).text)
				if summary_labels.size() == 1 else "missing"))
	var name_labels := menu.find_children("SelectedName", "Label", true, false)
	_assert(name_labels.size() == 1
			and String((name_labels[0] as Label).text)
			== String(GameState.robot_def().get("name", "MECH")),
			"hangar summary names the selected mech (%s)" % (
				String((name_labels[0] as Label).text)
				if name_labels.size() == 1 else "missing"))
	var driver := hangar.pose_driver()
	_assert(driver != null, "hangar pose driver wired")
	if driver != null:
		# Regression: every titan must preview as a TitanRig (CITADEL/RAVAGER
		# used to fall through the PRAETOR-only branch and show a SCARAB clone).
		var prev_robot := GameState.selected_robot
		for robot_id in GameState.ROBOT_ORDER:
			GameState.selected_robot = robot_id
			driver.rebuild()
			var is_titan := bool(GameState.robot_def().get("is_titan", false))
			if is_titan:
				_assert(driver.rig is TitanRig,
						"hangar previews %s as TitanRig" % String(robot_id))
			elif robot_id == GameState.ROBOT_VORTEX:
				_assert(driver.rig is VortexRig and not (driver.rig is TitanRig),
						"hangar previews VORTEX as VortexRig")
			elif robot_id == GameState.ROBOT_RAMPART:
				_assert(driver.rig is ZephyrRig,
						"hangar previews ZEPHYR as ZephyrRig")
			else:
				_assert(driver.rig is RobotRig and not (driver.rig is TitanRig)
						and not (driver.rig is VortexRig) and not (driver.rig is ZephyrRig),
						"hangar previews SCARAB as RobotRig")
		GameState.selected_robot = prev_robot
		driver.rebuild()
		# --- physical hangar bay: six clickable platforms + restrained labels ---
		_assert(HangarSlots.SLOTS.size() == 6, "six hangar platforms defined")
		var seen_positions := {}
		for slot in HangarSlots.SLOTS:
			var slot_pos: Vector3 = slot["pos"]
			seen_positions["%.2f,%.2f" % [slot_pos.x, slot_pos.z]] = true
		_assert(seen_positions.size() == 6, "hangar platform anchors are distinct")
		var titan_slot: Dictionary = HangarSlots.SLOTS[HangarSlots.TITAN_SLOT]
		_assert(float(titan_slot["top"]) > 0.9
				and float(titan_slot["pos"].z) < -10.0,
				"titan pad is elevated and deep in the bay")
		var slots_root := driver.get_node_or_null("Slots")
		_assert(slots_root != null and slots_root.get_child_count() == 6,
				"six platform nodes built (%d)" % (
					slots_root.get_child_count() if slots_root != null else -1))
		if slots_root != null:
			for platform in slots_root.get_children():
				_assert(platform.get_node_or_null("DeckBody") != null,
						"platform %s carries deck physics" % String(platform.name))
		_assert(driver.has_method("slot_screen_rect") and driver.has_method("slot_robot")
				and driver.has_method("slot_points") and driver.has_method("selected_slot"),
				"hangar slot click/camera API present")
		_assert(driver.find_children("EmptyMarker*", "Node3D", true, false).size() == 0,
				"bay keeps no empty-slot holograms")
		_assert(driver.find_children("*", "Label3D", true, false).size() == 0,
				"bay keeps no floating 3D nameplates (pad chips are 2D)")
		_assert(hangar.has_method("pick_slot") and hangar.has_method("_on_slot_picked"),
				"bay click routes to slot pick handler")
		# Selected mech owns the hero pad (click/select semantics).
		GameState.selected_robot = GameState.ROBOT_SCARAB
		driver.rebuild()
		_assert(driver.slot_robot(HangarSlots.HERO) == GameState.ROBOT_SCARAB,
				"selected mech occupies the hero pad")
		_assert(driver.selected_slot() == HangarSlots.HERO, "hero pad is the selected slot")
		# Functional click round-trip: project a pad to screen, feed the press
		# back through the picker. Tapping the selected mech opens equipment.
		var hero_rect := driver.slot_screen_rect(HangarSlots.HERO, preview_camera)
		_assert(hero_rect.size.x > 0.0 and hero_rect.size.y > 0.0,
				"hero pad projects on screen (%s)" % str(hero_rect))
		if hero_rect.size.x > 0.0:
			var press := hero_rect.get_center() * preview_control.size \
					/ Vector2(hangar.bay_viewport().size)
			hangar.pick_slot(press)
			_assert(ui.current() == &"robot",
					"tapping the selected mech opens equipment (%s)" % ui.current())
			ui.pop()
			_assert(ui.current() == &"hangar", "equipment back returns to the hangar")
		# Empty pad: opens the robot store (the titan pad lands on the
		# titans tab).
		for slot_index in driver.slot_count():
			if driver.slot_robot(slot_index) != &"":
				continue
			var empty_rect := driver.slot_screen_rect(slot_index, preview_camera)
			if empty_rect.size.x <= 0.0:
				continue
			var empty_press := empty_rect.get_center() * preview_control.size \
					/ Vector2(hangar.bay_viewport().size)
			hangar.pick_slot(empty_press)
			_assert(ui.current() == &"store",
					"empty pad opens the store (slot %d -> %s)" % [
						slot_index, ui.current()])
			if ui.current() == &"store":
				var wants_titan := bool(HangarSlots.SLOTS[slot_index]["titan"])
				var empty_store := ui.screen(&"store")
				var titan_page := empty_store.find_children(
						"StoreTitanScroll", "ScrollContainer", true, false)
				_assert(titan_page.size() == 1
						and (titan_page[0] as Control).visible == wants_titan,
						"empty pad lands on the %s tab" % (
							"titans" if wants_titan else "robots"))
				ui.pop()
				_assert(ui.current() == &"hangar",
						"store back returns to the hangar")
			break
		GameState.selected_robot = prev_robot
		driver.rebuild()
		# --- slot "+" buttons: one per pad; tap = select + open details ---
		var slot_plus_all := menu.find_children("SlotPlus_*", "Button", true, false)
		_assert(slot_plus_all.size() == driver.slot_count(),
				"one + button per pad (%d/%d)" % [
					slot_plus_all.size(), driver.slot_count()])
		var hero_plus := menu.find_children(
				"SlotPlus_%d" % HangarSlots.HERO, "Button", true, false)
		_assert(hero_plus.size() == 1
				and (hero_plus[0] as Button).pressed.get_connections().size() > 0,
				"hero + button wired")
		if hero_plus.size() == 1:
			(hero_plus[0] as Button).pressed.emit()
			_assert(ui.current() == &"robot",
					"hero + opens the mech details (%s)" % ui.current())
			ui.pop()
			_assert(ui.current() == &"hangar", "+ flow returns to the hangar")
		# --- hangar drone flies beside the pose driver ---
		var orbits := menu.find_children("DroneOrbit", "Node3D", true, false)
		_assert(orbits.size() >= 1 and (orbits[0] as Node3D).get_parent() != null,
				"hangar drone orbit attached to pose driver")
		# --- showroom contract: framed, motionless, drag/zoom belong to the
		# model — the camera must never move on its own or under the hand.
		for fit_settle in 12:
			await get_tree().process_frame
		var safe_rect := hangar.fit_safe_rect()
		var bounds_rect := hangar.projected_bounds_rect()
		_assert(safe_rect.size.x >= 0.0 and bounds_rect.size.x >= 0.0
				and safe_rect.grow(6.0).encloses(bounds_rect),
				"rig framed inside the safe rect (bounds %s / safe %s)" % [
					str(bounds_rect), str(safe_rect)])
		var camera_at_rest := preview_camera.global_transform
		var rig_at_rest := (driver.rig as Node3D).global_transform
		for idle_frames in 200:
			await get_tree().process_frame
		_assert(preview_camera.global_transform.is_equal_approx(camera_at_rest),
				"camera never drifts at rest (200 frames)")
		_assert((driver.rig as Node3D).global_transform.is_equal_approx(rig_at_rest),
				"model never self-rotates (200 frames)")
		# Drag rotates the MODEL only; the camera stays bit-identical.
		var yaw_before := driver.user_yaw
		var camera_before_drag := preview_camera.global_transform
		var drag_press := InputEventMouseButton.new()
		drag_press.button_index = MOUSE_BUTTON_LEFT
		drag_press.pressed = true
		drag_press.position = Vector2(400.0, 400.0)
		preview_control.gui_input.emit(drag_press)
		var drag_motion := InputEventMouseMotion.new()
		drag_motion.relative = Vector2(60.0, 0.0)
		preview_control.gui_input.emit(drag_motion)
		var drag_release := InputEventMouseButton.new()
		drag_release.button_index = MOUSE_BUTTON_LEFT
		drag_release.pressed = false
		drag_release.position = Vector2(460.0, 400.0)
		preview_control.gui_input.emit(drag_release)
		_assert(absf(driver.user_yaw - yaw_before) > 0.5,
				"drag rotates the model (yaw %.1f -> %.1f)" % [
					yaw_before, driver.user_yaw])
		_assert(preview_camera.global_transform.is_equal_approx(camera_before_drag),
				"drag leaves the camera untouched")
		driver.rotate_user(yaw_before - driver.user_yaw)
		# Wheel zoom + hard clamp, then restore the default framing.
		var zoom_before := hangar.zoom_level()
		var wheel_up := InputEventMouseButton.new()
		wheel_up.button_index = MOUSE_BUTTON_WHEEL_UP
		wheel_up.pressed = true
		preview_control.gui_input.emit(wheel_up)
		_assert(hangar.zoom_level() > zoom_before,
				"wheel zooms the bay in (%.2f -> %.2f)" % [
					zoom_before, hangar.zoom_level()])
		hangar.call("_zoom_by", 50.0)
		_assert(hangar.zoom_level() <= HangarScreen.ZOOM_MAX + 0.001,
				"zoom clamps at the maximum (%.2f)" % hangar.zoom_level())
		hangar.call("_zoom_by", 1.0 / maxf(hangar.zoom_level(), 0.01))
		for zoom_settle in 60:
			await get_tree().process_frame
		_assert(absf(hangar.zoom_level() - 1.0) < 0.001,
				"zoom restored to the default (%.2f)" % hangar.zoom_level())
		# WR showroom contract: the 3D machine is the pad's identity —
		# no name plates under the robots, only the + button.
		_assert(menu.find_children("PadChip_*", "Panel", true, false).size() == 0
				and menu.find_children("PadName", "Label", true, false).size() == 0
				and menu.find_children("PadMK", "Label", true, false).size() == 0,
				"pads carry no name chips")
		_assert(menu.find_children("SlotPlus_*", "Button", true, false).size()
				== driver.slot_count(),
				"one + button per pad (%d)" % menu.find_children(
					"SlotPlus_*", "Button", true, false).size())
		# Upgrade bubble: honest — visible only with a caption.
		var bubbles := menu.find_children("UpgradeBubble", "Panel", true, false)
		_assert(bubbles.size() == 1, "upgrade bubble present")
		var bubble_buttons := menu.find_children("UpgradeButton", "Button", true, false)
		_assert(bubble_buttons.size() == 1
				and (bubble_buttons[0] as Button).pressed.get_connections().size() > 0,
				"upgrade bubble button wired")
		if bubbles.size() == 1 and (bubbles[0] as Control).visible:
			var captions := menu.find_children("BubbleCaption", "Label", true, false)
			_assert(captions.size() == 1
					and not String((captions[0] as Label).text).is_empty(),
					"visible bubble carries a caption")
		# Every visible hangar button is wired or honestly disabled.
		var hangar_button_total := 0
		var unwired_buttons: Array[String] = []
		for button_node in hangar.find_children("*", "Button", true, false):
			var audit_button := button_node as Button
			if not audit_button.is_visible_in_tree():
				continue
			hangar_button_total += 1
			var is_wired := audit_button.pressed.get_connections().size() > 0
			var is_honest := audit_button.disabled \
					and not audit_button.tooltip_text.is_empty()
			if not is_wired and not is_honest:
				unwired_buttons.append(String(audit_button.name))
		_assert(hangar_button_total >= 10 and unwired_buttons.is_empty(),
				"every visible hangar button wired or honest (%d, bad %s)" % [
					hangar_button_total, str(unwired_buttons)])

	# --- equipment workspace (overlay on the bay) ---
	ui.push(&"robot")
	_assert(ui.current() == &"robot", "equipment workspace opens")
	var robot_screen := ui.screen(&"robot") as RobotScreen
	_assert(robot_screen != null and robot_screen.visible, "equipment screen visible")
	if robot_screen != null:
		_assert(not robot_screen.is_opaque(),
				"equipment overlays the bay instead of covering it")
		_assert(hangar.visible, "hangar bay stays visible under the overlay")
		await get_tree().process_frame
		_assert(robot_screen.size.x >= 1100.0,
				"equipment is full-screen (%.0f px)" % robot_screen.size.x)
		var eq_titles := menu.find_children("RobotTitle", "Label", true, false)
		var expected_name := String(GameState.robot_def().get("name", "MECH"))
		_assert(eq_titles.size() == 1
				and String((eq_titles[0] as Label).text) == expected_name,
				"equipment title shows the selected robot (%s)" % (
					String((eq_titles[0] as Label).text) if eq_titles.size() == 1
					else "?"))
		var eq_rows := menu.find_children("EquipmentSlotRow*", "Panel", true, false)
		_assert(eq_rows.size() == GameState.SLOT_COUNT,
				"equipment lists one row per hardpoint (%d)" % eq_rows.size())
		var visible_rows := 0
		for row_node in eq_rows:
			if (row_node as Control).visible:
				visible_rows += 1
		_assert(visible_rows == GameState.slot_count(),
				"only real hardpoints shown (%d/%d)" % [visible_rows,
					GameState.slot_count()])
		var armor_row := menu.find_children("ArmorRow", "VBoxContainer", true, false)
		_assert(armor_row.size() == 1, "armor stat row present")
		if armor_row.size() == 1:
			var armor_value := (armor_row[0] as Control).find_children(
					"Value", "Label", true, false)
			_assert(armor_value.size() == 1
					and String((armor_value[0] as Label).text).contains("ARMOR"),
					"equipment shows the armor stat (%s)" % (
						String((armor_value[0] as Label).text)
						if armor_value.size() == 1 else "?"))
		var ability_lines := menu.find_children("AbilityLine", "Label", true, false)
		var builtin_name := String(GameState.robot_def().get("builtin", ""))
		_assert(ability_lines.size() == 1
				and ("BUILT-IN" in (ability_lines[0] as Label).text
					or builtin_name.is_empty()),
				"equipment shows the built-in weapon (%s)" % (
					(ability_lines[0] as Label).text if ability_lines.size() == 1
					else "missing"))
		var bonus_labels := menu.find_children("BonusLabel", "Label", true, false)
		_assert(bonus_labels.size() == 1
				and "BONUS" in (bonus_labels[0] as Label).text
				and "%" in (bonus_labels[0] as Label).text,
				"equipment bonus row shows meta percents (%s)" % (
					(bonus_labels[0] as Label).text if bonus_labels.size() == 1
					else "missing"))
		var pilot_line := menu.find_children("PilotLine", "Button", true, false)
		_assert(pilot_line.size() == 1 and "VEX" in (pilot_line[0] as Button).text,
				"equipment shows the assigned pilot (%s)" % (
					(pilot_line[0] as Button).text if pilot_line.size() == 1 else "missing"))
		_assert(menu.find_children("DroneLine", "Button", true, false).size() == 1,
				"equipment shows the assigned drone")
		_assert(menu.find_children("SpecLine", "Button", true, false).size() == 1,
				"equipment shows the specialisation line")
		_assert(menu.find_children("HullUpgradeButton", "Button", true, false).size() == 1,
				"hull upgrade action present")
		_assert(menu.find_children("ChangeRobotButton", "Button", true, false).size() == 1,
				"change robot action present")
		# img2 header: robot thumbnail strip + cycle arrows + MK stamp.
		var strip_owned := 0
		for robot_id in GameState.ROBOT_ORDER:
			if GameState.owns_robot(robot_id):
				strip_owned += 1
		var strip_chips := menu.find_children("RobotStrip_*", "Button", true, false)
		_assert(strip_chips.size() == strip_owned,
				"header strip lists every owned mech (%d/%d)" % [
					strip_chips.size(), strip_owned])
		var prev_arrows := menu.find_children("PrevRobotButton", "Button", true, false)
		var next_arrows := menu.find_children("NextRobotButton", "Button", true, false)
		_assert(prev_arrows.size() == 1 and next_arrows.size() == 1
				and (prev_arrows[0] as Button).pressed.get_connections().size() > 0
				and (next_arrows[0] as Button).pressed.get_connections().size() > 0,
				"header cycle arrows present and wired")
		var class_lines := menu.find_children("ClassLine", "Label", true, false)
		_assert(class_lines.size() == 1
				and ("MK" in (class_lines[0] as Label).text
					or "LV" in (class_lines[0] as Label).text),
				"equipment shows the hull upgrade stamp (%s)" % (
					(class_lines[0] as Label).text if class_lines.size() == 1
					else "missing"))
		_assert(menu.find_children("PaletteRow", "HBoxContainer", true, false).size() == 1,
				"paint swatch row present")
		var swatches := menu.find_children("Swatch*", "Button", true, false)
		_assert(swatches.size() == GameState.PALETTE_COUNT,
				"every paint swatch built (%d)" % swatches.size())
		var eq_back := robot_screen.find_children("BackButton", "Button", true, false)
		_assert(eq_back.size() == 1, "equipment back button present")

		# --- weapon catalogue (stacked on equipment) ---
		var eq_assign0 := menu.find_children("EqAssign0", "Button", true, false)
		_assert(eq_assign0.size() == 1, "hardpoint assign action present")
		if eq_assign0.size() == 1:
			(eq_assign0[0] as Button).pressed.emit()
			_assert(ui.current() == &"weapon_select",
					"assign opens the weapon catalogue (%s)" % ui.current())
			_assert(not hangar.visible,
					"opaque screens hide the bay (render target gated)")
			var weapon_rows := menu.find_children("WeaponRow_*", "Panel", true, false)
			_assert(weapon_rows.size() >= 1,
					"storage lists owned weapons (%d)" % weapon_rows.size())
			_assert(menu.find_children("TabStorage", "Button", true, false).size() == 1
					and menu.find_children("TabStore", "Button", true, false).size() == 1,
					"weapon catalogue tabs present")
			var text_storage := menu.find_children("TabStorage", "Button", true, false)
			var text_store := menu.find_children("TabStore", "Button", true, false)
			if text_storage.size() == 1 and text_store.size() == 1:
				_assert(String((text_storage[0] as Button).text) == "INVENTORY"
						and String((text_store[0] as Button).text) == "TO STORE",
						"tabs labelled like WR (%s / %s)" % [
							(text_storage[0] as Button).text,
							(text_store[0] as Button).text])
			# img3: right-hand stat sheet for the selected row.
			var sheets := menu.find_children("StatSheet", "Panel", true, false)
			_assert(sheets.size() == 1, "weapon catalogue keeps the stat sheet")
			var sheet_names := menu.find_children("SheetName", "Label", true, false)
			_assert(sheet_names.size() == 1
					and not String((sheet_names[0] as Label).text).is_empty(),
					"stat sheet shows the selected weapon (%s)" % (
						String((sheet_names[0] as Label).text)
						if sheet_names.size() == 1 else "empty"))
			var sheet_stats := menu.find_children(
					"SheetStat*", "HBoxContainer", true, false)
			_assert(sheet_stats.size() >= 4,
					"stat sheet lists the combat lines (%d)" % sheet_stats.size())
			var tab_store := menu.find_children("TabStore", "Button", true, false)
			if tab_store.size() == 1:
				(tab_store[0] as Button).pressed.emit()
				var store_rows := menu.find_children("WeaponRow_*", "Panel", true, false)
				var empty_label := menu.find_children("EmptyLabel", "Label", true, false)
				_assert(store_rows.size() > 0
						or (empty_label.size() == 1 and (empty_label[0] as Label).visible),
						"store tab shows rows or an honest empty state")
			var tab_storage := menu.find_children("TabStorage", "Button", true, false)
			if tab_storage.size() == 1:
				(tab_storage[0] as Button).pressed.emit()
			# Equip a different weapon in slot 0 through a real viewport
			# click (the device path: BaseButton::_gui_input keeps touching
			# the button after `pressed` fires), then put the original back.
			var before_item := GameState.equipped_item(GameState.selected_robot, 0)
			var swap_target := ""
			var swap_action: Button = null
			for row_node in menu.find_children("WeaponRow_*", "Panel", true, false):
				var row_id := String((row_node as Node).name).trim_prefix("WeaponRow_")
				if row_id == before_item:
					continue
				var action := (row_node as Control).get_node_or_null(
						"RowLayout/RowAction") as Button
				if action != null and not action.disabled:
					swap_target = row_id
					swap_action = action
					break
			if swap_action != null:
				await _click_button(menu, swap_action)
				_assert(GameState.equipped_item(GameState.selected_robot, 0) == swap_target,
						"viewport click mounts the chosen weapon (%s)" % swap_target)
				_assert(GameState.equip_item(GameState.selected_robot, 0, before_item),
						"loadout restored after the equip test")
				ui.refresh()
			# Row click opens the detail screen.
			var detail_rows := menu.find_children("WeaponRow_*", "Panel", true, false)
			if detail_rows.size() > 0:
				var press_event := InputEventMouseButton.new()
				press_event.button_index = MOUSE_BUTTON_LEFT
				press_event.pressed = true
				(detail_rows[0] as Control).gui_input.emit(press_event)
				_assert(ui.current() == &"weapon_detail",
						"row click opens the weapon detail (%s)" % ui.current())
				_assert(menu.find_children("DetailPreview", "Control", true, false).size() == 1,
						"detail preview picture present")
				var detail_stats := menu.find_children("StatLine*", "HBoxContainer", true, false)
				_assert(detail_stats.size() >= 6,
						"detail lists the combat stats (%d)" % detail_stats.size())
				_assert(menu.find_children("EquipButton", "Button", true, false).size() == 1,
						"detail equip action present")
				ui.pop()
				_assert(ui.current() == &"weapon_select",
						"detail back returns to the catalogue")
				# First press on an unselected row only selects it (the
				# stat sheet follows); the second press drills in.
				var rows_after := menu.find_children(
						"WeaponRow_*", "Panel", true, false)
				if rows_after.size() > 1:
					var second_row := rows_after[1] as Control
					var second_id := String(
							(rows_after[1] as Node).name).trim_prefix("WeaponRow_")
					second_row.gui_input.emit(press_event)
					_assert(ui.current() == &"weapon_select",
							"first press on another row only selects it")
					var sheet_name_second := menu.find_children(
							"SheetName", "Label", true, false)
					if sheet_name_second.size() == 1:
						_assert(String((sheet_name_second[0] as Label).text)
								== GameState.item_display_name(second_id),
								"selecting a row fills the stat sheet (%s)" \
								% second_id)
					second_row.gui_input.emit(press_event)
					_assert(ui.current() == &"weapon_detail",
							"tapping the selected row drills in")
					ui.pop()
					_assert(ui.current() == &"weapon_select",
							"second detail back returns to the catalogue")
			ui.pop()
			_assert(ui.current() == &"robot",
					"catalogue back returns to equipment")

		# --- upgrade workspace: hull ladder, priced next level ---
		var hull_button := menu.find_children("HullUpgradeButton", "Button", true, false)
		if hull_button.size() == 1:
			(hull_button[0] as Button).pressed.emit()
			_assert(ui.current() == &"upgrade",
					"hull upgrade opens the ladder (%s)" % ui.current())
			var mk_chips := menu.find_children("MkChip*", "Button", true, false)
			_assert(mk_chips.size() == GameState.MK_MAX,
					"upgrade shows the MK ladder (%d chips)" % mk_chips.size())
			var cost_values := menu.find_children("CostValue", "Label", true, false)
			_assert(cost_values.size() == 1
					and not String((cost_values[0] as Label).text).strip_edges().is_empty()
					and String((cost_values[0] as Label).text) != "—",
					"upgrade prices the next level (%s)" % (
						String((cost_values[0] as Label).text)
						if cost_values.size() == 1 else "?"))
			var confirm := menu.find_children("ConfirmButton", "Button", true, false)
			_assert(confirm.size() == 1, "upgrade confirm present")
			# Functional purchase with full state restore.
			var upgrades_saved: Dictionary = GameState.upgrades.duplicate()
			var silver_saved := GameState.silver
			var gold_saved := GameState.gold
			var parts_saved := GameState.spare_parts
			var plat_saved := GameState.platinum
			var hull_key := GameState.body_upgrade_key(GameState.selected_robot)
			var state_before := GameState.upgrade_state(hull_key)
			if confirm.size() == 1 and not (confirm[0] as Button).disabled:
				(confirm[0] as Button).pressed.emit()
				var state_after := GameState.upgrade_state(hull_key)
				_assert(state_after != state_before,
						"confirm purchases the next level (%s -> %s)" % [
							str(state_before), str(state_after)])
			GameState.upgrades = upgrades_saved
			GameState.silver = silver_saved
			GameState.gold = gold_saved
			GameState.spare_parts = parts_saved
			GameState.platinum = plat_saved
			Events.wallet_changed.emit()
			ui.pop()
			_assert(ui.current() == &"robot", "upgrade back returns to equipment")

		# --- paint: row toggles, a real viewport click changes the paint ---
		var paint_button := menu.find_children("PaintButton", "Button", true, false)
		var palette_row := menu.find_children("PaletteRow", "HBoxContainer", true, false)
		_assert(paint_button.size() == 1 and palette_row.size() == 1,
				"paint controls wired")
		if paint_button.size() == 1 and palette_row.size() == 1:
			_assert(not (palette_row[0] as Control).visible,
					"paint row starts closed")
			(paint_button[0] as Button).pressed.emit()
			_assert((palette_row[0] as Control).visible, "paint row toggles open")
			# Let the row lay out before measuring — swatches keep their
			# pre-reveal positions until the next frame.
			await get_tree().process_frame
			var palette_before := GameState.armor_palette
			var paints_saved := GameState.unlocked_paints.duplicate()
			var silver_spent := GameState.silver
			var target := (palette_before + 1) % GameState.PALETTE_COUNT
			var swatch := menu.find_child("Swatch%d" % target, true, false) as Button
			_assert(swatch != null, "swatch %d exists" % target)
			if swatch != null:
				var swatch_rect := swatch.get_global_rect()
				var centre := swatch_rect.get_center()
				var screen_pos := menu.get_viewport().get_screen_transform() * centre
				# game CanvasLayers (HUD/end panel) render above the plain
				# menu Control and would swallow the synthetic click.
				var hidden_layers: Array[CanvasLayer] = []
				for node in get_tree().root.find_children(
						"*", "CanvasLayer", true, false):
					var canvas_layer := node as CanvasLayer
					if canvas_layer.visible:
						canvas_layer.visible = false
						hidden_layers.append(canvas_layer)
				var press := InputEventMouseButton.new()
				press.button_index = MOUSE_BUTTON_LEFT
				press.pressed = true
				press.position = screen_pos
				press.global_position = screen_pos
				menu.get_viewport().push_input(press)
				var release := InputEventMouseButton.new()
				release.button_index = MOUSE_BUTTON_LEFT
				release.pressed = false
				release.position = screen_pos
				release.global_position = screen_pos
				menu.get_viewport().push_input(release)
				await get_tree().process_frame
				for canvas_layer in hidden_layers:
					canvas_layer.visible = true
				_assert(GameState.armor_palette == target,
						"swatch viewport click changes paint (%d -> %d) name=%s rect=%s screen=%s window=%s" % [
							palette_before, GameState.armor_palette,
							String(swatch.name), swatch_rect, screen_pos,
							get_window().size])
				_assert(GameState.paint_unlocked(target),
						"swatch click also owns the paint (%d)" % target)
			GameState.set_palette(palette_before)
			_assert(GameState.armor_palette == palette_before,
					"paint restored after click")
			GameState.unlocked_paints = paints_saved
			GameState.silver = silver_spent
			Events.wallet_changed.emit()

		# --- crew screens: pilot / drone / specialisation drill-downs ---
		var pilot_entry := menu.find_children("PilotLine", "Button", true, false)
		_assert(pilot_entry.size() == 1, "pilot entry button present")
		if pilot_entry.size() == 1:
			(pilot_entry[0] as Button).pressed.emit()
			_assert(ui.current() == &"pilot",
					"pilot entry opens the crew screen (%s)" % ui.current())
			var roster_rows := menu.find_children(
					"PilotRosterRows", "VBoxContainer", true, false)
			_assert(roster_rows.size() == 1, "pilot roster column present")
			var roster_chips := menu.find_children(
					"PilotRoster_*", "Button", true, false)
			_assert(roster_chips.size() == GameState.owned_pilots.size(),
					"roster lists every owned pilot (%d/%d)" % [
						roster_chips.size(), GameState.owned_pilots.size()])
			_assert(menu.find_children(
					"PilotPortrait", "Control", true, false).size() == 1,
					"pilot portrait present")
			var train_buttons := menu.find_children(
					"TrainButton*", "Button", true, false)
			_assert(train_buttons.size() == GameState.PILOT_SKILL_NAMES.size(),
					"every pilot skill row built (%d)" % train_buttons.size())
			_assert(menu.find_children(
					"PilotTierButton", "Button", true, false).size() == 1,
					"pilot tier upgrade action present")
			var saved_pilot: String = GameState.assigned_pilot(
					GameState.selected_robot)
			var pick: Button = null
			for chip_node in roster_chips:
				var chip_id := String((chip_node as Node).name).trim_prefix(
						"PilotRoster_")
				if chip_id != saved_pilot:
					pick = chip_node as Button
					break
			if pick != null:
				var pick_id := String(pick.name).trim_prefix("PilotRoster_")
				pick.pressed.emit()
				_assert(GameState.assigned_pilot(GameState.selected_robot) == pick_id,
						"roster click assigns that pilot (%s)" % pick_id)
				GameState.assign_pilot(GameState.selected_robot,
						StringName(saved_pilot))
			ui.pop()
			_assert(ui.current() == &"robot",
					"pilot back returns to equipment (%s)" % ui.current())

		var drone_entry := menu.find_children("DroneLine", "Button", true, false)
		_assert(drone_entry.size() == 1, "drone entry button present")
		if drone_entry.size() == 1:
			(drone_entry[0] as Button).pressed.emit()
			_assert(ui.current() == &"drone",
					"drone entry opens the drone bay (%s)" % ui.current())
			var drone_rows := menu.find_children("DroneRow_*", "Panel", true, false)
			_assert(drone_rows.size() == GameState.DRONE_DEFS.size(),
					"drone bay lists every drone (%d/%d)" % [
						drone_rows.size(), GameState.DRONE_DEFS.size()])
			var drone_wallet := menu.find_children(
					"DroneWallet", "Label", true, false)
			_assert(drone_wallet.size() == 1
					and "MICROCHIPS" in (drone_wallet[0] as Label).text,
					"drone wallet line present (%s)" % (
						(drone_wallet[0] as Label).text
						if drone_wallet.size() == 1 else "missing"))
			var drone_actions := ui.screen(&"drone").find_children(
					"DroneAction", "Button", true, false)
			_assert(drone_actions.size() == GameState.DRONE_DEFS.size(),
					"every drone row has a buy/equip action (%d)" % drone_actions.size())
			ui.pop()
			_assert(ui.current() == &"robot",
					"drone back returns to equipment (%s)" % ui.current())

		var spec_entry := menu.find_children("SpecLine", "Button", true, false)
		_assert(spec_entry.size() == 1, "spec entry button present")
		if spec_entry.size() == 1:
			(spec_entry[0] as Button).pressed.emit()
			_assert(ui.current() == &"spec",
					"spec entry opens the skill tree (%s)" % ui.current())
			_assert(menu.find_children(
					"SpecGrid", "Control", true, false).size() == 1,
					"specialisation hex grid present")
			var spec_wallet := menu.find_children(
					"SpecWallet", "Label", true, false)
			_assert(spec_wallet.size() == 1
					and "MODULE POINTS" in (spec_wallet[0] as Label).text,
					"spec wallet line present (%s)" % (
						(spec_wallet[0] as Label).text
						if spec_wallet.size() == 1 else "missing"))
			_assert(menu.find_children(
					"SpecHint", "Label", true, false).size() == 1,
					"spec hint line present")
			ui.pop()
			_assert(ui.current() == &"robot",
					"spec back returns to equipment (%s)" % ui.current())

		# --- combat stats screen (equipment STATS action) ---
		var stats_entry := menu.find_children("StatsButton", "Button", true, false)
		_assert(stats_entry.size() == 1, "equipment STATS button present")
		if stats_entry.size() == 1:
			(stats_entry[0] as Button).pressed.emit()
			_assert(ui.current() == &"stats",
					"stats entry opens the report (%s)" % ui.current())
			var stats_screen := ui.screen(&"stats")
			_assert(stats_screen.visible, "stats screen visible")
			var stat_rows := stats_screen.find_children(
					"StatRow_*", "HBoxContainer", true, false)
			_assert(stat_rows.size() == 7,
					"stats report shows all 7 rows (%d)" % stat_rows.size())
			_assert(stats_screen.find_children(
					"StatsRobot", "Label", true, false).size() == 1,
					"stats robot line present")
			ui.pop()
			_assert(ui.current() == &"robot",
					"stats back returns to equipment (%s)" % ui.current())

		# --- leave equipment, back navigation, quit confirm at the root ---
		ui.pop()
		_assert(ui.current() == &"hangar", "equipment back returns to the hangar")
		_assert(hangar.visible, "hangar visible again after the overlay closes")
	# --- hangar level-1 nav: store / inventory / settings ---
	var store_entry := menu.find_children("StoreButton", "Button", true, false)
	_assert(store_entry.size() == 1, "hangar store nav button present")
	if store_entry.size() == 1:
		(store_entry[0] as Button).pressed.emit()
		_assert(ui.current() == &"store",
				"store nav opens the store (%s)" % ui.current())
		var store_screen := ui.screen(&"store")
		_assert(store_screen.visible, "store screen visible")
		await get_tree().process_frame
		_assert(store_screen.size.x >= 1100.0,
				"store is a full-screen workspace (%.0f px wide)" % store_screen.size.x)
		var store_tabs := store_screen.find_children(
				"StoreTab*", "Button", true, false)
		_assert(store_tabs.size() == 5, "store has five tabs (%d)" % store_tabs.size())
		var robot_scroll := store_screen.find_children(
				"StoreRobotScroll", "ScrollContainer", true, false)
		var weapon_scroll := store_screen.find_children(
				"StoreWeaponScroll", "ScrollContainer", true, false)
		_assert(robot_scroll.size() == 1 and weapon_scroll.size() == 1
				and (robot_scroll[0] as Control).visible
				and not (weapon_scroll[0] as Control).visible,
				"store opens on robots tab")
		var store_robot_cards := store_screen.find_children(
				"StoreRobot_*", "PanelContainer", true, false)
		_assert(store_robot_cards.size() >= 3,
				"store lists the mechs (%d)" % store_robot_cards.size())
		var robot_previews := store_screen.find_children(
				"RobotPreview", "Control", true, false)
		_assert(robot_previews.size() >= 4,
				"robot preview pictures drawn (%d)" % robot_previews.size())
		var weapon_previews := store_screen.find_children(
				"WeaponPreview", "Control", true, false)
		_assert(weapon_previews.size() >= 6,
				"weapon preview pictures drawn (%d)" % weapon_previews.size())
		var pilot_previews := store_screen.find_children(
				"PilotPreview", "Control", true, false)
		_assert(pilot_previews.size() >= GameState.PILOT_DEFS.size(),
				"pilot preview pictures (%d)" % pilot_previews.size())
		var drone_previews := store_screen.find_children(
				"DronePreview", "Control", true, false)
		_assert(drone_previews.size() >= GameState.DRONE_DEFS.size(),
				"drone preview pictures (%d)" % drone_previews.size())
		var sig_lines := store_screen.find_children(
				"PilotSignature", "Label", true, false)
		_assert(sig_lines.size() == GameState.PILOT_DEFS.size(),
				"store pilot cards carry signature lines (%d)" % sig_lines.size())
		var weapons_tab := store_screen.find_children(
				"StoreTabWeapons", "Button", true, false)
		if weapons_tab.size() == 1:
			(weapons_tab[0] as Button).pressed.emit()
			var weapon_page := store_screen.find_children(
					"StoreWeaponScroll", "ScrollContainer", true, false)
			_assert(weapon_page.size() == 1
					and (weapon_page[0] as Control).visible,
					"store switches to weapons tab")
			store_screen.call("store_tab_set", 0)
		ui.pop()
		_assert(ui.current() == &"hangar", "store back returns to the hangar")

	var inventory_entry := menu.find_children("InventoryButton", "Button", true, false)
	_assert(inventory_entry.size() == 1, "hangar inventory nav button present")
	if inventory_entry.size() == 1:
		(inventory_entry[0] as Button).pressed.emit()
		_assert(ui.current() == &"inventory",
				"inventory nav opens the inventory (%s)" % ui.current())
		var inv_screen := ui.screen(&"inventory")
		_assert(inv_screen.visible, "inventory screen visible")
		await get_tree().process_frame
		_assert(inv_screen.size.x >= 1100.0 and inv_screen.size.y >= 640.0,
				"inventory is a full-screen bay view (%s)" % inv_screen.size)
		var inv_rows := inv_screen.find_children(
				"InvRobotRows", "VBoxContainer", true, false)
		_assert(inv_rows.size() == 1
				and (inv_rows[0] as VBoxContainer).get_child_count() >= 1,
				"inventory robots section populated")
		_assert(inv_screen.find_children(
				"Section_ONTHEBAY", "Label", true, false).size() == 1,
				"inventory separates the staged bay roster")
		_assert(inv_screen.find_children(
				"Section_WEAPONSTORAGE", "Label", true, false).size() == 1,
				"inventory labels the weapon storage")
		var inv_scarab := inv_screen.find_children(
				"StoreRobot_SCARAB", "PanelContainer", true, false)
		_assert(inv_scarab.size() == 1, "inventory lists the staged robot")
		if inv_scarab.size() == 1:
			var inv_state := (inv_scarab[0] as PanelContainer).find_children(
					"RobotState", "Label", true, false)
			_assert(inv_state.size() == 1
					and String((inv_state[0] as Label).text).contains("PAD"),
					"inventory card shows its bay pad (%s)" % (
						String((inv_state[0] as Label).text) if inv_state.size() == 1
						else "?"))
		var inv_weapon_tab := inv_screen.find_children(
				"InvTabWeapons", "Button", true, false)
		if inv_weapon_tab.size() == 1:
			(inv_weapon_tab[0] as Button).pressed.emit()
			var inv_weapon_page := inv_screen.find_children(
					"InvWeaponScroll", "ScrollContainer", true, false)
			_assert(inv_weapon_page.size() == 1
					and (inv_weapon_page[0] as Control).visible,
					"inventory switches to the weapon storage")
		ui.pop()
		_assert(ui.current() == &"hangar", "inventory back returns to the hangar")

	var settings_entry := menu.find_children("SettingsTopButton", "Button", true, false)
	_assert(settings_entry.size() == 1, "hangar settings gear present")
	if settings_entry.size() == 1:
		(settings_entry[0] as Button).pressed.emit()
		_assert(ui.current() == &"settings",
				"settings nav opens settings (%s)" % ui.current())
		var settings_screen := ui.screen(&"settings")
		_assert(settings_screen.visible, "settings screen visible")
		for section_name in ["Section_LOOK", "Section_AUDIO",
				"Section_GAMEPLAY", "Section_SYSTEM"]:
			_assert(settings_screen.find_children(
					section_name, "Label", true, false).size() == 1,
					"settings section %s" % section_name)
		for control_name in ["SensitivitySlider", "VolumeSlider", "MusicSlider",
				"DamageNumbersCheck", "FpsCounterCheck", "VibrationCheck",
				"ControlsModeButton", "GraphicsSettingButton", "ExitGameButton",
				"TargetPriorityButton", "CloseSettingsButton", "BackButton"]:
			_assert(settings_screen.find_children(
					control_name, "", true, false).size() == 1,
					"settings control %s present" % control_name)
		var gfx_setting := settings_screen.find_children(
				"GraphicsSettingButton", "Button", true, false)
		if gfx_setting.size() == 1:
			var label_before := Quality.tier_label()
			var tier_before := GameState.selected_quality
			var auto_before := GameState.quality_auto
			(gfx_setting[0] as Button).pressed.emit()
			_assert(Quality.tier_label() != label_before,
					"settings graphics button cycles the tier (%s -> %s)" % [
						label_before, Quality.tier_label()])
			GameState.selected_quality = tier_before
			GameState.quality_auto = auto_before
			GameState.save_settings()
			Quality.apply_viewport(settings_screen.get_viewport())
		var priority_button := settings_screen.find_children(
				"TargetPriorityButton", "Button", true, false)
		if priority_button.size() == 1:
			var priority_before := GameState.target_priority
			(priority_button[0] as Button).pressed.emit()
			_assert(GameState.target_priority != priority_before,
					"settings target priority cycles (%d -> %d)" % [
						priority_before, GameState.target_priority])
			GameState.set_target_priority(priority_before)
		var music_slider := settings_screen.find_children(
				"MusicSlider", "HSlider", true, false)
		if music_slider.size() == 1:
			var music_before := GameState.music_volume
			var slider := music_slider[0] as HSlider
			slider.value = 0.35 if not is_equal_approx(music_before, 0.35) else 0.8
			_assert(is_equal_approx(GameState.music_volume, slider.value),
					"music slider drives the music volume (%.2f)" % GameState.music_volume)
			slider.value = music_before
		var exit_button := settings_screen.find_children(
				"ExitGameButton", "Button", true, false)
		if exit_button.size() == 1:
			(exit_button[0] as Button).pressed.emit()
			var settings_quit := menu.get_node_or_null("UI/QuitConfirm") as Control
			_assert(settings_quit != null and settings_quit.visible,
					"settings EXIT GAME opens the quit confirm")
			ui.handle_back()
			_assert(settings_quit != null and not settings_quit.visible,
					"back dismisses the quit confirm")
		ui.pop()
		_assert(ui.current() == &"hangar", "settings back returns to the hangar")

	# --- remaining hangar destinations: briefing, stats, command, armory ---
	var inbox_entry := menu.find_children("InboxButton", "Button", true, false)
	_assert(inbox_entry.size() == 1, "hangar messages button present")
	if inbox_entry.size() == 1:
		(inbox_entry[0] as Button).pressed.emit()
		_assert(ui.current() == &"news",
				"messages open the briefing feed (%s)" % ui.current())
		var news_screen := ui.screen(&"news")
		if news_screen != null:
			var news_text := ""
			for news_label in news_screen.find_children("*", "Label", true, false):
				news_text += String((news_label as Label).text) + " "
			_assert(news_text.contains(GameState.BUILD_LABEL)
					and news_text.contains("PATCH NOTES"),
					"briefing shows real local patch notes")
		ui.pop()
		_assert(ui.current() == &"hangar", "briefing back returns to the hangar")

	var record_entry := menu.find_children("StatsRecordButton", "Button", true, false)
	_assert(record_entry.size() == 1, "combat stats corner button present")
	if record_entry.size() == 1:
		(record_entry[0] as Button).pressed.emit()
		_assert(ui.current() == &"stats",
				"combat stats open the report (%s)" % ui.current())
		ui.pop()
		_assert(ui.current() == &"hangar", "stats back returns to the hangar")

	var command_entry := menu.find_children("CommandButton", "Button", true, false)
	_assert(command_entry.size() == 1, "command entry present")
	if command_entry.size() == 1:
		(command_entry[0] as Button).pressed.emit()
		_assert(ui.current() == &"profile",
				"command opens the pilot profile (%s)" % ui.current())
		var profile_screen := ui.screen(&"profile")
		if profile_screen != null:
			var profile_text := ""
			for profile_label in profile_screen.find_children("*", "Label", true, false):
				profile_text += String((profile_label as Label).text) + " "
			_assert(profile_text.contains("LEVEL %d" % GameState.pilot_level()),
					"profile shows the real pilot level (%s)" % profile_text)
			var hub_labels: Array[String] = []
			for hub_button in profile_screen.find_children("*", "Button", true, false):
				hub_labels.append(String((hub_button as Button).text))
			_assert(not hub_labels.has("WORKSHOP") and not hub_labels.has("MISSIONS")
					and not hub_labels.has("DATA PADS") and not hub_labels.has("FRIENDS"),
					"hub nav drops toast-only stubs (%s)" % str(hub_labels))
		ui.pop()
		_assert(ui.current() == &"hangar", "profile back returns to the hangar")

	var armory_entry := menu.find_children("ArmoryButton", "Button", true, false)
	_assert(armory_entry.size() == 1, "armory entry present")
	if armory_entry.size() == 1:
		(armory_entry[0] as Button).pressed.emit()
		_assert(ui.current() == &"store",
				"armory opens the store (%s)" % ui.current())
		var armory_store := ui.screen(&"store")
		if armory_store != null:
			var armory_weapons := armory_store.find_children(
					"StoreWeaponScroll", "ScrollContainer", true, false)
			_assert(armory_weapons.size() == 1
					and (armory_weapons[0] as Control).visible,
					"armory lands on the weapons tab")
			armory_store.call("store_tab_set", 0)
		ui.pop()
		_assert(ui.current() == &"hangar", "armory back returns to the hangar")

	# Battle-modes data: only maps that actually ship (v0.15 deleted the rest).
	var mode_def: Array = MegaHubScreen.PAGE_DEFS[&"game_modes"]
	_assert(not (mode_def[2] as Array).has("IRONYARD SKIRMISH")
			and not (mode_def[2] as Array).has("CINDER VALLEY ASSAULT"),
			"battle-modes list only ships real maps")

	# --- chrome layout: no panel may overlap another ---
	var resource_bar := menu.get_node_or_null("UI/ResourceBar") as Control
	var top_util := menu.find_children("TopUtility", "HBoxContainer", true, false)
	_assert(resource_bar != null and top_util.size() == 1,
			"currency strip and utility row present")
	if resource_bar != null and top_util.size() == 1:
		var bar_rect := resource_bar.get_global_rect()
		var util_rect := (top_util[0] as Control).get_global_rect()
		_assert(not bar_rect.intersects(util_rect),
				"utility row clears the currency strip (%s / %s)" % [
					str(util_rect), str(bar_rect)])
	var right_nav := menu.find_children("RightNav", "GridContainer", true, false)
	if right_nav.size() == 1 and start_buttons.size() == 1:
		_assert(not (right_nav[0] as Control).get_global_rect().intersects(
				(start_buttons[0] as Button).get_global_rect()),
				"right rail clears TO BATTLE")
	if right_nav.size() == 1 and store_entry.size() == 1:
		_assert(not (right_nav[0] as Control).get_global_rect().intersects(
				(store_entry[0] as Button).get_global_rect()),
				"right rail clears STORE")

	ui.handle_back()
	var quit_panel := menu.get_node_or_null("UI/QuitConfirm") as Control
	_assert(quit_panel != null and quit_panel.visible,
			"back at the root opens the quit prompt")
	ui.handle_back()
	_assert(quit_panel != null and not quit_panel.visible,
			"second back dismisses the quit prompt")

	# --- full navigation flow (§51 step 11): deep chains unwind cleanly ---
	_assert(ui.current() == &"hangar" and ui.stack_depth() == 1,
			"flow test starts at the hangar root (depth %d)" % ui.stack_depth())
	var flow_chip := menu.find_children(
			"SlotPlus_%d" % HangarSlots.HERO, "Button", true, false)
	_assert(flow_chip.size() == 1, "flow entry + button present")
	if flow_chip.size() == 1:
		(flow_chip[0] as Button).pressed.emit()
		_assert(ui.current() == &"robot" and ui.stack_depth() == 2,
				"flow: pad + pushes equipment (depth %d)" % ui.stack_depth())
		var flow_assign := menu.find_children("EqAssign0", "Button", true, false)
		if flow_assign.size() == 1:
			(flow_assign[0] as Button).pressed.emit()
			_assert(ui.current() == &"weapon_select" and ui.stack_depth() == 3,
					"flow: assign pushes the catalogue (depth %d)" % ui.stack_depth())
			var flow_rows := menu.find_children("WeaponRow_*", "Panel", true, false)
			if flow_rows.size() > 0:
				var flow_press := InputEventMouseButton.new()
				flow_press.button_index = MOUSE_BUTTON_LEFT
				flow_press.pressed = true
				(flow_rows[0] as Control).gui_input.emit(flow_press)
				_assert(ui.current() == &"weapon_detail" and ui.stack_depth() == 4,
						"flow: row click pushes the detail (depth %d)" % ui.stack_depth())
				ui.handle_back()
				_assert(ui.current() == &"weapon_select" and ui.stack_depth() == 3,
						"flow: back unwinds to the catalogue (depth %d)" % ui.stack_depth())
			ui.handle_back()
			_assert(ui.current() == &"robot" and ui.stack_depth() == 2,
					"flow: back unwinds to equipment (depth %d)" % ui.stack_depth())
		var flow_stats := menu.find_children("StatsButton", "Button", true, false)
		if flow_stats.size() == 1:
			(flow_stats[0] as Button).pressed.emit()
			_assert(ui.current() == &"stats" and ui.stack_depth() == 3,
					"flow: stats stacks on equipment (depth %d)" % ui.stack_depth())
			ui.handle_back()
			_assert(ui.current() == &"robot" and ui.stack_depth() == 2,
					"flow: stats back returns to equipment (depth %d)" % ui.stack_depth())
		ui.handle_back()
		_assert(ui.current() == &"hangar" and ui.stack_depth() == 1,
				"flow: full unwind returns to the hangar root (depth %d)" % ui.stack_depth())
	_assert(ui.stack_depth() == 1, "no stack leaks after the flow test")

	# --- ability / builtin tool info on every robot ---
	for robot_id in GameState.ROBOT_DEFS.keys():
		_assert(String(GameState.ROBOT_DEFS[robot_id].get("ability_desc", "")).length() > 10,
				"ability description for %s" % String(robot_id))
	_assert(not String(GameState.robot_def(GameState.ROBOT_PRAETOR)
			.get("secondary_desc", "")).is_empty(), "praetor secondary ability description")
	_assert(not String(GameState.robot_def(GameState.ROBOT_RAMPART)
			.get("builtin_desc", "")).is_empty(), "zephyr builtin weapon description")
	# --- signature pilot + drone trio ---
	_assert(GameState.signature_pilot_name_for(GameState.ROBOT_SCARAB) == "VEX",
			"SCARAB signature pilot VEX")
	_assert(GameState.signature_pilot_name_for(GameState.ROBOT_VORTEX) == "ORIN",
			"VORTEX signature pilot ORIN")
	_assert(GameState.signature_pilot_name_for(GameState.ROBOT_RAMPART) == "SABLE",
			"ZEPHYR signature pilot SABLE")
	_assert(GameState.signature_pilot_name_for(GameState.ROBOT_PRAETOR) == "MARA VANCE",
			"PRAETOR signature pilot MARA VANCE")
	_assert(GameState.signature_pilot_name_for(GameState.ROBOT_CITADEL) == "DORN",
			"CITADEL signature pilot DORN")
	_assert(GameState.signature_pilot_name_for(GameState.ROBOT_RAVAGER) == "VARGA",
			"RAVAGER signature pilot VARGA")
	_assert(GameState.signature_drone_name_for(GameState.ROBOT_SCARAB) == "WISP",
			"SCARAB signature drone WISP")
	_assert(GameState.signature_drone_name_for(GameState.ROBOT_VORTEX) == "KESTREL",
			"VORTEX signature drone KESTREL")
	_assert(GameState.signature_drone_name_for(GameState.ROBOT_RAMPART) == "BULWARK",
			"ZEPHYR signature drone BULWARK")
	_assert(GameState.signature_drone_name_for(GameState.ROBOT_PRAETOR) == "",
			"titan has no signature drone")
	# --- specialized default loadouts ---
	var scarab_default: Array = GameState._default_loadout(GameState.ROBOT_SCARAB)
	_assert(scarab_default.size() == 4 and String(scarab_default[0]) == "RAZOR-M"
			and String(scarab_default[3]) == "MAUL-M", "SCARAB default loadout RAZOR+MAUL")
	var vortex_default: Array = GameState._default_loadout(GameState.ROBOT_VORTEX)
	_assert(vortex_default.size() == 4 and String(vortex_default[0]) == "VOLT-H",
			"VORTEX default loadout VOLT-H")
	var zephyr_default: Array = GameState._default_loadout(GameState.ROBOT_RAMPART)
	_assert(zephyr_default.size() == 3 and String(zephyr_default[0]) == "LUMEN-M"
			and String(zephyr_default[2]) == "PYRE-H", "ZEPHYR default loadout LUMEN+PYRE")
	var praetor_default: Array = GameState._default_loadout(GameState.ROBOT_PRAETOR)
	_assert(praetor_default.size() == 4 and String(praetor_default[0]) == "JUGGERNAUT-A"
			and String(praetor_default[2]) == "HAVOC-B", "PRAETOR default titan loadout")
	_assert(GameState.slot_size(GameState.ROBOT_PRAETOR, 0)
			!= GameState.slot_size(GameState.ROBOT_PRAETOR, 2),
			"titan alpha and beta hardpoints read differently")
	# --- pool always covers mounted copies ---
	var store_item_ids: Array[String] = []
	store_item_ids.append_array(GameState.ALL_ITEM_IDS)
	store_item_ids.append_array(GameState.TITAN_ITEM_IDS)
	for item_id in store_item_ids:
		_assert(GameState.pool_count(item_id) >= GameState.equipped_count(item_id),
				"pool covers mounted copies for %s" % item_id)
	# --- every robot gets its own drone ---
	var missing_drones: Array[String] = []
	for drone_id in ["wisp", "bulwark", "patch", "kestrel"]:
		if not GameState.owns_drone(drone_id):
			missing_drones.append(drone_id)
			GameState.owned_drones.append(drone_id)
	_assert(missing_drones.is_empty(), "default roster owns all four drones")
	var drone_assign_saved: Dictionary = GameState.drone_assignments.duplicate()
	var drone_levels_saved: Dictionary = GameState.drone_levels.duplicate()
	GameState.drone_assignments = {
		&"SCARAB": "wisp", &"VORTEX": "kestrel",
		&"RAMPART": "bulwark", &"PRAETOR": "",
	}
	var seen_drones := {}
	for robot_id in GameState.ROBOT_ORDER:
		if GameState.is_titan(robot_id):
			_assert(GameState.drone_for_robot(robot_id) == "",
					"titan flies no drone (%s)"
					% GameState.drone_for_robot(robot_id))
			continue
		var drone_id := GameState.drone_for_robot(robot_id)
		_assert(not drone_id.is_empty() and not seen_drones.has(drone_id),
				"robot %s flies its own drone (%s)" % [String(robot_id), drone_id])
		seen_drones[drone_id] = true
	_assert(seen_drones.size() == 3, "three chassis, three drones (%d)" % seen_drones.size())
	_assert(not seen_drones.has("patch"), "patch kept as the store spare (%s)" % str(seen_drones))
	# --- signature drone doubles the bonus (x1.5) ---
	GameState.drone_levels["kestrel"] = 1
	GameState.drone_assignments[&"VORTEX"] = "kestrel"
	GameState.drone_assignments[&"SCARAB"] = "kestrel"
	var sig_drone_bonus: float = float(
			GameState.drone_effects(GameState.ROBOT_VORTEX)["damage"]) - 1.0
	var plain_drone_bonus: float = float(
			GameState.drone_effects(GameState.ROBOT_SCARAB)["damage"]) - 1.0
	_assert(plain_drone_bonus > 0.0
			and absf(sig_drone_bonus - plain_drone_bonus * 1.5) < 0.0001,
			"signature drone x1.5 damage bonus (%.4f vs %.4f)"
			% [sig_drone_bonus, plain_drone_bonus])
	# --- signature pilot doubles the bonus (x1.5) ---
	var pilot_assign_saved: Dictionary = GameState.pilot_assignments.duplicate()
	if not GameState.pilots.has("vex"):
		GameState.pilots["vex"] = {"level": 21, "xp": 0, "tier": 1,
				"skills": [0, 0, 0, 0, 0, 0, 0]}
	var vex_state := GameState.pilots["vex"] as Dictionary
	var vex_skills_saved := (vex_state.get("skills", []) as Array).duplicate()
	vex_state["skills"] = [0, 0, 5, 0, 0, 0, 0]
	GameState.pilot_assignments[&"SCARAB"] = "vex"
	GameState.pilot_assignments[&"VORTEX"] = "vex"
	var sig_pilot_bonus: float = float(
			GameState.pilot_effects(GameState.ROBOT_SCARAB)["damage"]) - 1.0
	var plain_pilot_bonus: float = float(
			GameState.pilot_effects(GameState.ROBOT_VORTEX)["damage"]) - 1.0
	_assert(plain_pilot_bonus > 0.0
			and absf(sig_pilot_bonus - plain_pilot_bonus * 1.5) < 0.0001,
			"signature pilot x1.5 damage bonus (%.4f vs %.4f)"
			% [sig_pilot_bonus, plain_pilot_bonus])
	vex_state["skills"] = vex_skills_saved
	GameState.pilot_assignments = pilot_assign_saved
	GameState.drone_assignments = drone_assign_saved
	GameState.drone_levels = drone_levels_saved
	for drone_id in missing_drones:
		GameState.owned_drones.erase(drone_id)
	# --- single open world: no map selector, no cycling anywhere ---
	_assert(menu.find_children("MapButton", "Button", true, false).size() == 0,
			"map selector removed (single open world)")
	var main_menu := menu as MainMenu
	_assert(main_menu != null and not main_menu.has_method("map_display_name"),
			"legacy map naming removed from menu")
	_assert(not GameState.has_method("toggle_map"),
			"map cycling removed from game state")
	# --- settings toggles that live outside a screen (kept from v0.32) ---
	var previous_damage := GameState.damage_numbers
	GameState.set_damage_numbers(not previous_damage)
	_assert(GameState.damage_numbers == (not previous_damage), "damage numbers setting flips")
	GameState.set_damage_numbers(previous_damage)
	_assert(GameState.damage_numbers == previous_damage, "damage numbers setting restored")
	# --- audio ---
	_assert(AudioEngine.has_sound(&"cannon"), "audio cannon stream built")
	_assert(AudioEngine.has_sound(&"engine"), "audio engine loop built")
	for sound_id: StringName in [&"engine_vortex", &"engine_rampart", &"engine_praetor",
			&"reload"]:
		_assert(AudioEngine.has_sound(sound_id),
				"per-robot audio stream built (%s)" % sound_id)
	for sound_id: StringName in [&"zap", &"rail", &"launch", &"hiss", &"beam", &"flame",
			&"thump", &"scatter", &"sonic", &"whip", &"clank", &"menu_music"]:
		_assert(AudioEngine.has_sound(sound_id), "audio family stream built (%s)" % sound_id)
	for weapon_id: StringName in [&"cannon", &"scatter", &"sonic", &"whip", &"clank",
			&"impact_metal"]:
		var weapon_wav := AudioEngine._streams[weapon_id] as AudioStreamWAV
		_assert(weapon_wav != null and weapon_wav.mix_rate == 44100,
				"weapon stream at 44.1 kHz (%s)" % weapon_id)
		if weapon_wav == null:
			continue
		var peak := 0
		var wav_data: PackedByteArray = weapon_wav.data
		var total := 0
		var counted := 0
		for byte_index in range(0, mini(wav_data.size(), 44100), 2):
			var sample_value := absi(wav_data.decode_s16(byte_index))
			peak = maxi(peak, sample_value)
			total += sample_value
			counted += 1
		_assert(peak > 11000, "weapon stream punchy, not a rice pop (%s peak %d)"
				% [weapon_id, peak])
		_assert(counted > 0 and int(total / maxi(counted, 1)) > 700,
				"weapon stream has a sustained body (%s avg %d)"
				% [weapon_id, int(total / maxi(counted, 1))])
	_assert(Events.weapon_fired.get_connections().size() >= 2,
			"weapon_fired listeners wired (%d)" % Events.weapon_fired.get_connections().size())
	_assert(Events.weapon_impact.get_connections().size() >= 2,
			"weapon_impact listeners wired (%d)" % Events.weapon_impact.get_connections().size())
	_assert(InputMap.has_action(&"weapon_1") and InputMap.has_action(&"weapon_2"),
			"split weapon actions defined")
	_assert(AudioEngine.has_sound(&"menu_music"), "menu music stream built")
	_assert(AudioEngine.menu_music_active(), "menu music starts in hangar")
	menu.queue_free()
	# Standalone TouchControls: pin a known full SCARAB loadout so the ring
	# always shows four segments, regardless of the director's saved hangar.
	var saved_touch_loadout: Array = (GameState.loadouts[GameState.ROBOT_SCARAB] as Array).duplicate()
	GameState.loadouts[GameState.ROBOT_SCARAB] = ["RAZOR-M", "RAZOR-M", "MAUL-M", "MAUL-M"]
	var touch := TouchControls.new()
	add_child(touch)
	_assert(touch.fire_button() != null, "touch fire button built")
	_assert(touch.ability_button() != null, "touch ability wedge built")
	_assert(touch.secondary_button() == null,
			"SCARAB carries no secondary wedge (got %s)" % (
				touch.secondary_button().name if touch.secondary_button() != null
				else "null"))
	_assert(touch.ability_button() != null and touch.ability_button().text.begins_with("DASH"),
			"touch ability label adapts to robot (%s)" % (
				touch.ability_button().text if touch.ability_button() != null else "null"))
	var ability_dupes := 0
	for child in touch.get_children():
		if child is Button and String((child as Button).text).begins_with("DASH"):
			ability_dupes += 1
	_assert(ability_dupes == 1,
			"ability exists exactly once on the circular controller (%d)" % ability_dupes)
	_assert(touch.razor_button() != null, "touch razor group button built")
	_assert(touch.maul_button() != null, "touch maul group button built")
	_assert(touch.get_node_or_null("LookZone") != null, "touch look zone built")
	_assert(touch.segment_count() == 4,
			"four weapon segments for a full SCARAB loadout (%d)" % touch.segment_count())
	_assert(touch.lock_button() != null, "lock crosshair segment built")
	_assert(touch.visible == PlatformUtil.prefers_touch_ui(),
			"touch visibility follows the platform rule (%s)" % touch.visible)
	touch.size = get_viewport().get_visible_rect().size
	touch._layout_panel()
	var fire_rect := touch.fire_button().get_global_rect()
	var lock_rect := touch.lock_button().get_global_rect()
	var ability_rect := touch.ability_button().get_global_rect()
	var fire_centre := fire_rect.position + fire_rect.size * 0.5
	var lock_centre := lock_rect.position + lock_rect.size * 0.5
	var lock_distance := lock_centre.distance_to(fire_centre)
	_assert(lock_centre.y > fire_centre.y, "lock segment sits below the fire button")
	_assert(absf(lock_distance - 120.0) < 8.0,
			"lock segment on the ring radius (%.1f)" % lock_distance)
	var ability_centre := ability_rect.position + ability_rect.size * 0.5
	_assert(absf(ability_centre.distance_to(fire_centre) - 120.0) < 8.0,
			"ability wedge on the ring radius (%.1f)" %
			ability_centre.distance_to(fire_centre))
	_assert(ability_centre.y > fire_centre.y, "ability wedge at 6 o'clock")
	_assert(lock_rect.end.x <= touch.size.x + 1.0 and lock_rect.end.y <= touch.size.y + 1.0,
			"weapon ring stays inside the screen (%s)" % lock_rect)
	GameState.loadouts[GameState.ROBOT_SCARAB] = saved_touch_loadout
	touch.queue_free()
	var game_touch: Control = null
	var touch_layer := _game.get_node_or_null("TouchLayer")
	if touch_layer != null:
		for child in touch_layer.get_children():
			if child is TouchControls:
				game_touch = child as TouchControls
	_assert(game_touch != null, "game scene touch controls present")
	if game_touch != null:
		_assert(game_touch.visible == PlatformUtil.prefers_touch_ui(),
				"game touch rig visible flag follows platform (%s vs %s)" % [
					game_touch.visible, PlatformUtil.prefers_touch_ui()])
	if game_touch != null:
		var viewport_size := get_viewport().get_visible_rect().size
		_assert(game_touch.size.x >= viewport_size.x * 0.9,
				"touch root spans viewport width (%.0f/%.0f)" % [game_touch.size.x, viewport_size.x])
		_assert(game_touch.size.y >= viewport_size.y * 0.9,
				"touch root spans viewport height (%.0f/%.0f)" % [game_touch.size.y, viewport_size.y])
		var game_fire := game_touch.get_node_or_null("FireButton") as Control
		_assert(game_fire != null, "game fire button present")
		if game_fire != null:
			var rect := game_fire.get_global_rect()
			_assert(rect.position.x >= -1.0 and rect.position.y >= -1.0
					and rect.end.x <= viewport_size.x + 1.0
					and rect.end.y <= viewport_size.y + 1.0,
					"fire button inside viewport (%s)" % rect)
			# Raw multi-touch regression: a SECOND finger (stick already held,
			# so no emulated mouse exists) must drive FIRE, a weapon wedge and
			# the ability wedge straight through ScreenTouch.
			var fire_point := rect.position + rect.size * 0.5
			var down := InputEventScreenTouch.new()
			down.index = 1
			down.position = fire_point
			down.pressed = true
			game_touch._unhandled_input(down)
			InputRouter._process(0.016)
			_assert(InputRouter.fire_held,
					"raw ScreenTouch drives the centre FIRE button")
			var slide := InputEventScreenDrag.new()
			slide.index = 1
			slide.position = Vector2(4.0, fire_point.y)
			slide.relative = Vector2.ZERO
			game_touch._unhandled_input(slide)
			InputRouter._process(0.016)
			_assert(not InputRouter.fire_held,
					"sliding the fire finger off the button lets go")
			var up := InputEventScreenTouch.new()
			up.index = 1
			up.position = Vector2(4.0, fire_point.y)
			up.pressed = false
			game_touch._unhandled_input(up)
			InputRouter._process(0.016)
			_assert(not InputRouter.fire_held,
					"raw fire touch releases cleanly")
			if game_touch.segment_count() > 0 and game_touch.razor_button() != null:
				var seg_rect: Rect2 = game_touch.razor_button().get_rect()
				var seg_point: Vector2 = seg_rect.position + seg_rect.size * 0.5
				var seg_down := InputEventScreenTouch.new()
				seg_down.index = 2
				seg_down.position = seg_point
				seg_down.pressed = true
				game_touch._unhandled_input(seg_down)
				var seg_slot: int = game_touch._segment_slots[0]
				InputRouter._process(0.016)
				_assert(InputRouter.slot_held[seg_slot],
						"raw touch holds its weapon wedge (slot %d)" % seg_slot)
				var seg_up := InputEventScreenTouch.new()
				seg_up.index = 2
				seg_up.position = seg_point
				seg_up.pressed = false
				game_touch._unhandled_input(seg_up)
				InputRouter._process(0.016)
				_assert(not InputRouter.slot_held[seg_slot],
						"raw weapon wedge releases cleanly")
			if game_touch.ability_button() != null:
				var ab_rect: Rect2 = game_touch.ability_button().get_rect()
				var ab_point: Vector2 = ab_rect.position + ab_rect.size * 0.5
				var ab_down := InputEventScreenTouch.new()
				ab_down.index = 3
				ab_down.position = ab_point
				ab_down.pressed = true
				game_touch._unhandled_input(ab_down)
				var ab_up := InputEventScreenTouch.new()
				ab_up.index = 3
				ab_up.position = ab_point
				ab_up.pressed = false
				game_touch._unhandled_input(ab_up)
				_assert(InputRouter.ability_requested,
						"raw ScreenTouch tap requests the ability")
				InputRouter.clear_temporary()
	_check_upgrade_api()
	_check_pilot_api()
	_check_drone_api()
	_check_drone_shapes()
	_check_spec_api()
	_check_tier_behaviour()
	_check_open_realm()
	_check_enemy_variety()
	_check_match_timer()
	_check_world_liveliness()
	_arm_router_guard()
	_check_vortex_swap()
	_check_zephyr_swap()
	_check_chassis_sizes()
	_check_material_realism()
	_check_sonic_mount()
	_check_void_mount()
	_check_fire_animations()
	_check_shot_appearance()
	_check_robot_motion_profiles()
	_check_paint_shop_api()
	_check_titan_swap()
	_check_new_titans()
	_check_ownership_api()
	_check_store_api()
	_check_inventory_api()
	_check_input_responsiveness()
	_check_input_ownership()
	_check_particle_amounts()
	_check_hardware_profile()
	_check_status_feed()
	_check_combat_stats_api()
	_check_loading_screen()

func _check_tier_behaviour() -> void:
	var environment := Environment.new()
	var sun := DirectionalLight3D.new()
	var viewport := SubViewport.new()
	var previous := GameState.selected_quality
	GameState.selected_quality = 0
	Quality.apply_environment(environment, 0.0)
	Quality.apply_sun(sun)
	Quality.apply_viewport(viewport)
	_assert(not sun.shadow_enabled, "LOW tier disables sun shadows")
	_assert(environment.tonemap_exposure >= 1.3, "LOW tier bright exposure (%.2f)" % environment.tonemap_exposure)
	var sky := Quality.make_sky()
	var sky_material := sky.sky_material as ProceduralSkyMaterial
	_assert(sky_material != null and sky_material.sky_energy_multiplier >= 1.2,
			"daylight sky energy (%s)" % str(sky_material.sky_energy_multiplier if sky_material != null else null))
	_assert(not environment.glow_enabled, "LOW tier disables glow")
	_assert(viewport.scaling_3d_scale <= 0.65,
			"LOW tier drops render scale (%.2f)" % viewport.scaling_3d_scale)
	GameState.selected_quality = 2
	Quality.apply_environment(environment, 0.0)
	Quality.apply_sun(sun)
	Quality.apply_viewport(viewport)
	_assert(sun.shadow_enabled, "HIGH tier enables sun shadows")
	_assert(environment.glow_enabled, "HIGH tier enables glow")
	_assert(viewport.scaling_3d_scale >= 0.99, "HIGH tier renders at full scale")
	_assert(environment.tonemap_exposure >= 1.4, "HIGH tier bright exposure (%.2f)" % environment.tonemap_exposure)
	GameState.selected_quality = 3
	Quality.apply_environment(environment, 0.0)
	Quality.apply_sun(sun)
	Quality.apply_viewport(viewport)
	_assert(sun.shadow_enabled, "ULTRA tier enables sun shadows")
	_assert(Quality.shadow_filter_quality() == RenderingServer.SHADOW_QUALITY_SOFT_ULTRA,
			"ULTRA tier uses the softest PCF filter")
	GameState.selected_quality = 1
	_assert(Quality.shadow_filter_quality() == RenderingServer.SHADOW_QUALITY_SOFT_MEDIUM,
			"MEDIUM tier uses a medium PCF filter")
	GameState.selected_quality = 3
	_assert(viewport.msaa_3d == Viewport.MSAA_8X, "ULTRA tier uses 8x MSAA")
	_assert(viewport.scaling_3d_scale >= 0.99, "ULTRA tier full render scale")
	GameState.selected_quality = previous
	sun.free()
	viewport.free()

func _check_open_realm() -> void:
	var alt_game := (load(GAME_SCENE) as PackedScene).instantiate() as Node3D
	add_child(alt_game)
	var alt_arena := alt_game.get_node_or_null("OpenRealm") as CombatArena
	_assert(alt_arena != null, "open realm arena built into game scene")
	_assert(alt_game.get_node_or_null("Ironyard") == null,
			"legacy arena nodes removed from game scene")
	if alt_arena != null:
		_assert(alt_arena.enemy_spawns.size() >= 15,
				"open realm defines 15+ enemy spawns (%d)" % alt_arena.enemy_spawns.size())
		_assert(alt_arena.player_spawn != Vector3.ZERO, "open realm player spawn wired")
		var nearest_enemy := 1.0e9
		for enemy_point in alt_arena.enemy_spawns:
			nearest_enemy = minf(nearest_enemy, Vector2(enemy_point.x, enemy_point.z)
					.distance_to(Vector2(alt_arena.player_spawn.x, alt_arena.player_spawn.z)))
		_assert(nearest_enemy >= 55.0,
				"enemy spawns kept away from player (%.0fm nearest)" % nearest_enemy)
		_assert(alt_arena.get_node_or_null("RealmTerrain") != null,
				"open realm heightfield terrain built")
		var realm_terrain := alt_arena.get_node_or_null("RealmTerrain") as MeshInstance3D
		if realm_terrain != null and realm_terrain.mesh is ArrayMesh:
			var surface_arrays := (realm_terrain.mesh as ArrayMesh).surface_get_arrays(0)
			var uvs := surface_arrays[Mesh.ARRAY_TEX_UV] as PackedVector2Array
			_assert(uvs.size() > 0, "terrain carries UVs for PBR texturing")
		if realm_terrain != null and realm_terrain.material_override is StandardMaterial3D:
			var ground_mat := realm_terrain.material_override as StandardMaterial3D
			if AssetLibrary.has_pbr_set("forest_ground"):
				_assert(ground_mat.albedo_texture != null,
						"terrain albedo bound to the 8K PBR ground set")
				_assert(ground_mat.normal_texture != null,
						"terrain normal bound to the PBR ground set")
		_assert(alt_arena.get_node_or_null("RealmTerrainBody") != null,
				"open realm terrain collision built")
		_assert(alt_arena.get_node_or_null("RealmWater") != null, "lake water plane built")
		_assert(alt_arena.get_node_or_null("WorldEnvironment") != null,
				"open realm environment present")
		_assert(alt_arena.get_node_or_null("ReflectionProbe") != null,
				"open realm reflection probe present")
		var kit_bodies := 0
		var containers := 0
		var has_intersection := false
		var has_cathedral := false
		var has_ammo_box := false
		var has_palm := false
		var has_dock := false
		var has_building := false
		var has_cliff := false
		var has_cobble := false
		var bush_multis := 0
		for node in alt_arena.get_children():
			var node_name := String(node.name)
			if node is StaticBody3D and node_name.ends_with("_body"):
				kit_bodies += 1
				if node_name.begins_with("Building_") or node_name.begins_with("building-"):
					has_building = true
			if node_name.begins_with("containers_"):
				containers += 1
			if node_name.contains("Street_4WayIntersection"):
				has_intersection = true
			if node_name.contains("CathedralRuins"):
				has_cathedral = true
			if node_name.contains("ammo_box"):
				has_ammo_box = true
			if node_name.contains("Prop_Tree_Palm"):
				has_palm = true
			if node_name.contains("Prop_Docks"):
				has_dock = true
			if node_name.contains("Cliff_Base"):
				has_cliff = true
			if node_name.contains("Cobblestone_Floor"):
				has_cobble = true
			if node is MultiMeshInstance3D and node_name.ends_with("_mm"):
				bush_multis += 1
		_assert(has_building, "city + industrial buildings placed")
		_assert(kit_bodies >= 20, "open realm kit colliders built (%d)" % kit_bodies)
		_assert(containers >= 3, "container variants placed (%d)" % containers)
		_assert(has_intersection, "city 4-way intersection placed")
		_assert(has_cathedral, "cathedral ruins placed from ruins pack")
		_assert(has_ammo_box, "scifi prop pack placed")
		_assert(has_palm, "beach palm pack placed")
		_assert(has_dock, "lake docks placed")
		_assert(has_cliff, "cliff pack pieces placed")
		_assert(has_cobble, "village cobble plaza placed")
		_assert(bush_multis >= 3, "nature bush multimeshes placed (%d)" % bush_multis)
		_assert(alt_arena.get_node_or_null("RealmMagma") != null,
				"magma basin plane built")
		var realm_water := alt_arena.get_node_or_null("RealmWater") as MeshInstance3D
		if realm_water != null and realm_water.mesh is PlaneMesh:
			var water_material := (realm_water.mesh as PlaneMesh).material as ShaderMaterial
			var water_code := ""
			if water_material != null and water_material.shader != null:
				water_code = water_material.shader.code
			_assert(water_code.contains("hint_depth_texture"),
					"water shader reconstructs scene depth for shore foam")
			_assert(water_code.contains("rain_strength"),
					"water shader carries a rain ripple uniform")
		var realm_magma := alt_arena.get_node_or_null("RealmMagma") as MeshInstance3D
		if realm_magma != null and realm_magma.mesh is PlaneMesh:
			var magma_material := (realm_magma.mesh as PlaneMesh).material as ShaderMaterial
			_assert(magma_material != null and magma_material.shader != null
					and magma_material.shader.code.contains("EMISSION"),
					"magma shader glows with animated veins")
		_assert(HazardZones.zones.size() == 3,
				"three hazard zones registered (%d)" % HazardZones.zones.size())
		var crater_zone := HazardZones.zones[2]
		_assert(String(crater_zone["kind"]) == "magma"
				and float(crater_zone["dps"]) >= 0.1
				and float(crater_zone["radius"]) > 5.0,
				"volcano crater registers as a magma hazard (r%.0f dps%.2f)"
				% [float(crater_zone["radius"]), float(crater_zone["dps"])])
		var lake_zone := HazardZones.zone_at(
				Vector3(OpenRealm.LAKE_CENTRE.x, -2.5, OpenRealm.LAKE_CENTRE.y))
		_assert(not lake_zone.is_empty() and String(lake_zone["kind"]) == "water",
				"lake registers as a water hazard")
		var magma_zone := HazardZones.zone_at(
				Vector3(OpenRealm.MAGMA_CENTRE.x, -1.5, OpenRealm.MAGMA_CENTRE.y))
		_assert(not magma_zone.is_empty() and String(magma_zone["kind"]) == "magma",
				"magma basin registers as a magma hazard")
		_assert(HazardZones.zone_at(Vector3(0.0, 5.0, 0.0)).is_empty(),
				"hub ground stays hazard free")
		var basin := OpenRealm.terrain_height(OpenRealm.MAGMA_CENTRE.x,
				OpenRealm.MAGMA_CENTRE.y)
		_assert(basin < -2.0, "magma basin carved below the surface (%.1f)" % basin)
		var trench_mid := (OpenRealm.TUNNEL_START.y + OpenRealm.TUNNEL_END.y) * 0.5
		var trench_floor := OpenRealm.terrain_height(0.0, trench_mid)
		_assert(trench_floor < OpenRealm.TUNNEL_FLOOR + 1.0,
				"transit trench carved to its floor (%.1f)" % trench_floor)
		var shoulder := OpenRealm.terrain_height(
				OpenRealm.TUNNEL_HALF_WIDTH + OpenRealm.TUNNEL_SLOPE + 12.0, trench_mid)
		_assert(absf(shoulder - trench_floor) > 4.0,
				"trench keeps raised shoulders (%.1f)" % shoulder)
		_assert(absf(OpenRealm.terrain_height(0.0, OpenRealm.TUNNEL_START.y - 25.0)
				- trench_floor) > 4.0,
				"trench entrance ramps open onto natural ground")
		_assert(alt_arena.get_node_or_null("TunnelCeiling") != null,
				"tunnel ceiling slab built")
		_assert(alt_arena.get_node_or_null("TunnelShell") != null,
				"tunnel wall shell built")
		var gantries := 0
		var markers := 0
		var bunker_names: Array[String] = []
		for node in alt_arena.get_children():
			var child_name := String(node.name)
			if child_name.contains("TunnelGantry"):
				gantries += 1
			if child_name.contains("TunnelMarker"):
				markers += 1
			if child_name.begins_with("Bunker"):
				bunker_names.append(child_name)
		_assert(gantries >= 2, "both tunnel mouths gantry-marked (%d)" % gantries)
		_assert(markers >= 4, "guide posts flank both tunnel mouths (%d)" % markers)
		_assert(bunker_names.size() >= 2,
				"enterable bunkers built (%d)" % bunker_names.size())
		var hub_bunker := alt_arena.get_node_or_null("BunkerHub") as Node3D
		_assert(hub_bunker != null, "hub bunker present")
		if hub_bunker != null:
			var parts := 0
			var has_lamp := false
			for child in hub_bunker.get_children():
				if child is StaticBody3D:
					parts += 1
				if String(child.name) == "BunkerLamp":
					has_lamp = true
			_assert(parts >= 8, "bunker walls + props built (%d)" % parts)
			_assert(has_lamp, "bunker interior lamp lit")
			var space := alt_game.get_world_3d().direct_space_state
			var door_out := PhysicsRayQueryParameters3D.create(
					hub_bunker.to_global(Vector3(0.0, 1.4, -3.4)),
					hub_bunker.to_global(Vector3(0.0, 1.4, -9.0)),
					Layers.WORLD)
			var through_door := space.intersect_ray(door_out)
			var blocked_by := ""
			if not through_door.is_empty():
				var hit_collider: Variant = through_door.get("collider")
				var hit_name := ""
				if hit_collider is Node:
					hit_name = String((hit_collider as Node).name)
				if not hit_name.contains("RealmTerrain"):
					blocked_by = "%s at %s" % [hit_name,
							str(through_door.get("position"))]
			_assert(blocked_by.is_empty(),
					"bunker doorway is really open (blocked by %s)" % blocked_by)
			var into_roof := PhysicsRayQueryParameters3D.create(
					hub_bunker.to_global(Vector3(0.0, 1.4, 0.0)),
					hub_bunker.to_global(Vector3(0.0, 6.0, 0.0)),
					Layers.WORLD)
			_assert(not space.intersect_ray(into_roof).is_empty(),
					"bunker roof still blocks shots from inside")
		var alt_nature := alt_game.get_node_or_null("Nature") as Nature
		_assert(alt_nature != null, "nature built into the open realm scene")
		if alt_nature != null:
			_assert(alt_nature.get_node_or_null("WeatherSystem") != null,
					"weather system attached to nature")
			_assert(alt_nature.get_node_or_null("VolcanoActivity") != null,
					"volcano activity attached to nature")
	alt_game.free()

func _check_enemy_variety() -> void:
	var kinds := {}
	var kind_scale := {}
	var rig_scripts := {}
	var weapon_names := {}
	var labels := {}
	var kind_hp_min := {}
	var kind_hp_max := {}
	var off_pool := 0
	var total := 0
	var wasp_legless := false
	var min_hp := 1.0e12
	var worst_dps := 0.0
	for node in _game.get_children():
		if not (node is EnemyRobot):
			continue
		var enemy := node as EnemyRobot
		total += 1
		kinds[String(enemy.kind)] = true
		labels[enemy.kind_label()] = true
		var pool: Array = EnemyRobot.WEAPON_POOLS.get(enemy.kind, []) as Array
		if not pool.has(enemy._weapon_item):
			off_pool += 1
		if enemy.health != null:
			min_hp = minf(min_hp, enemy.health.max_health)
			var hp := enemy.health.max_health
			if kind_hp_min.has(String(enemy.kind)):
				kind_hp_min[String(enemy.kind)] = minf(
						float(kind_hp_min[String(enemy.kind)]), hp)
				kind_hp_max[String(enemy.kind)] = maxf(
						float(kind_hp_max[String(enemy.kind)]), hp)
			else:
				kind_hp_min[String(enemy.kind)] = hp
				kind_hp_max[String(enemy.kind)] = hp
		if enemy.rig != null:
			kind_scale[String(enemy.kind)] = enemy.rig.scale.x
		if enemy.rig != null:
			rig_scripts[String(enemy.rig.script.resource_path)] = true
			if enemy.kind == EnemyRobot.KIND_WASP:
				wasp_legless = enemy.rig.legs.is_empty() and enemy.rig.hover_height() > 3.0
		if enemy._weapon != null:
			weapon_names[enemy._weapon.display_name] = true
			var dps := enemy._weapon.damage * float(maxi(1, enemy._weapon.pellets)) \
					* enemy._weapon.shots_per_minute / 60.0
			worst_dps = maxf(worst_dps, dps)
	# drone combat can legitimately destroy some enemies before this runs —
	# the exact spawn count is asserted in _check_static_structure
	_assert(total >= 1 and total <= 15, "enemy roster tracked at match end (%d live)" % total)
	_assert(kinds.size() >= 4, "enemy roster has 4 kinds (%d)" % kinds.size())
	_assert(labels.size() >= 4,
			"enemy labels differ per family (%d: %s)" % [labels.size(),
				", ".join(PackedStringArray(labels.keys()))])
	_assert(rig_scripts.size() >= 4, "enemy roster has 4 rig shapes (%d)" % rig_scripts.size())
	_assert(weapon_names.size() >= 4,
			"enemy roster uses 4 weapons (%d: %s)" % [weapon_names.size(),
				", ".join(PackedStringArray(weapon_names.keys()))])
	_assert(wasp_legless, "wasp drone hovers legless")
	# dead enemies leave the tree — tier coverage reads the append-only spawn log
	var log_tiers := {}
	for tier in EnemyRobot.spawned_tiers:
		log_tiers[tier] = true
	_assert(log_tiers.size() == 4,
			"roster mixes BASE/MK1/MK2/MK3 (%d tiers: %s)" % [log_tiers.size(),
				", ".join(PackedStringArray(log_tiers.keys()))])
	_assert(off_pool == 0,
			"every enemy gun comes from its kind's pool (%d outside)" % off_pool)
	for kind_key in kind_hp_min.keys():
		if not kind_hp_max.has(kind_key):
			continue
		var lo := float(kind_hp_min[kind_key])
		var hi := float(kind_hp_max[kind_key])
		if hi > lo:
			_assert(hi / lo >= 1.5,
					"MK tiers stretch %s durability >= 1.5x (%.2f)" % [kind_key, hi / lo])
	if kind_scale.has("BRUTE") and kind_scale.has("SCUTTLER"):
		_assert(float(kind_scale["BRUTE"]) > float(kind_scale["SCUTTLER"]) + 0.25,
				"BRUTE is visibly bigger than SCUTTLER (%.2f > %.2f)" % [
					float(kind_scale["BRUTE"]), float(kind_scale["SCUTTLER"])])
	_assert(min_hp >= 40000.0, "enemy hit points WR-scale (min %.0f)" % min_hp)
	var scarab_armor := float(GameState.robot_def(GameState.ROBOT_SCARAB).get("armor", 0.0))
	# MK3 firepower (x1.4) deliberately shaves perfect-fire survival from the
	# old 20s base-only guard to ~16s — elites are supposed to hit harder.
	_assert(worst_dps > 0.0 and scarab_armor / worst_dps >= 15.0,
			"solo survival under perfect fire >= 15s (%.1fs)" % (
				scarab_armor / maxf(worst_dps, 1.0)))

func _check_match_timer() -> void:
	_assert(is_equal_approx(Hud.MATCH_LENGTH, 600.0),
			"match timer is 10 minutes (%.0fs)" % Hud.MATCH_LENGTH)
	_assert(is_equal_approx(Hud.TIMER_WARN, 60.0),
			"timer warning at 60s (%.0fs)" % Hud.TIMER_WARN)
	var timer := _game.get_node_or_null("HudLayer/Hud/TimerPanel/TimerValue") as Label
	_assert(timer != null, "HUD timer label present")

func _arm_router_guard() -> void:
	SceneRouter._switching = true
	SceneRouter._arm_switch_guard_clear()

func _verify_router_guard() -> void:
	_assert(not SceneRouter._switching,
			"scene router guard clears after armed switch")

func _check_material_realism() -> void:
	var armor := PanelTextures.get_textures(&"armor")
	_assert(armor.has(&"albedo") and armor.has(&"rough") and armor.has(&"normal"),
			"armor PBR set builds (albedo/rough/normal)")
	var albedo := (armor[&"albedo"] as ImageTexture).get_image()
	_assert(albedo != null and albedo.get_width() == 192,
			"armor albedo 192px (%d)" % (albedo.get_width() if albedo != null else 0))
	if albedo != null:
		var min_v := 1.0
		var max_v := 0.0
		for y in albedo.get_height():
			for x in albedo.get_width():
				var value := albedo.get_pixel(x, y).r
				min_v = minf(min_v, value)
				max_v = maxf(max_v, value)
		_assert(min_v <= 0.45 and max_v >= 0.95,
				"armor albedo spans dark seams + bright wear (%.2f..%.2f)" % [min_v, max_v])
	var hazard := PanelTextures.get_textures(&"hazard")
	_assert(hazard.has(&"albedo") and hazard.has(&"rough") and hazard.has(&"normal"),
			"hazard stripe kind builds")
	for index in GameState.PALETTE_COUNT:
		var palette := GameState.palette_colors(index)
		_assert(palette.size() == 3, "palette %d has three tones" % index)
		var primary_sum := palette[0].r + palette[0].g + palette[0].b
		var secondary_sum := palette[1].r + palette[1].g + palette[1].b
		_assert(secondary_sum < primary_sum,
				"palette %d secondary is darker than primary" % index)
	var rig := RobotRig.new()
	rig._make_materials()
	_assert(rig._primary.metallic <= 0.35,
			"painted armor not full-metal (m=%.2f)" % rig._primary.metallic)
	_assert(rig._trim.metallic >= 0.9, "bare steel trim stays metallic")
	rig.free()

func _check_sonic_mount() -> void:
	var materials := {
		"gold": MeshUtil.make_material(Color.GOLD, 0.9, 0.35),
		"dark": MeshUtil.make_material(Color(0.2, 0.2, 0.22), 0.7, 0.5),
		"joint": MeshUtil.make_material(Color(0.1, 0.1, 0.11), 0.6, 0.7),
		"trim": MeshUtil.make_material(Color(0.6, 0.6, 0.62), 0.9, 0.35),
		"sensor": MeshUtil.make_material(Color(0.1, 0.3, 0.4), 0.5, 0.4),
	}
	var mount := WeaponMount.new()
	mount.setup(0, WeaponData.for_item("ECHO-M"), 1.0, materials)
	add_child(mount)
	_assert(mount.muzzle != null, "sonic mount builds its muzzle")
	_assert(mount.get_node_or_null("resonator_drum") != null,
			"sonic mount builds its resonator drum")
	_assert(mount.get_node_or_null("horn_mouth") != null,
			"sonic mount builds its pressure horn")
	var fired := mount.try_fire([])
	_assert(fired, "sonic mount fires a shockwave volley")
	_assert(mount.heat > 0.0, "sonic mount accumulates heat (%.3f)" % mount.heat)
	_assert(not mount.overheated, "sonic first volley does not overheat")
	_assert(mount.get_node_or_null("MuzzleSmoke") != null,
			"sonic volley puffs muzzle smoke")
	mount.queue_free()

func _check_fire_animations() -> void:
	var materials := {
		"gold": MeshUtil.make_material(Color.GOLD, 0.9, 0.35),
		"dark": MeshUtil.make_material(Color(0.2, 0.2, 0.22), 0.7, 0.5),
		"joint": MeshUtil.make_material(Color(0.1, 0.1, 0.11), 0.6, 0.7),
		"trim": MeshUtil.make_material(Color(0.6, 0.6, 0.62), 0.9, 0.35),
		"sensor": MeshUtil.make_material(Color(0.1, 0.3, 0.4), 0.5, 0.4),
	}
	var build_anim_mount := func(item_id: String) -> WeaponMount:
		var m := WeaponMount.new()
		m.setup(0, WeaponData.for_item(item_id), 1.0, materials)
		add_child(m)
		return m
	var step_frames := func(m: WeaponMount, count: int = 2) -> void:
		for frame in count:
			m._process(0.05)

	var razor: WeaponMount = build_anim_mount.call("RAZOR-M")
	var cluster: Node3D = razor.get_node_or_null("BarrelCluster")
	_assert(cluster != null, "RAZOR builds its spinning barrel cluster")
	if cluster != null:
		var barrels: Array[Node] = cluster.find_children("barrel_*", "MeshInstance3D",
				true, false)
		_assert(barrels.size() == 4, "RAZOR cluster holds four barrels (%d)" % barrels.size())
		var spin_before: float = cluster.rotation.x
		razor._cooldown = 0.0
		razor.heat = 0.0
		_assert(razor.try_fire([]), "RAZOR fires for the spin test")
		step_frames.call(razor)
		_assert(not is_equal_approx(cluster.rotation.x, spin_before),
				"RAZOR barrels spin on firing")
		_assert(razor._anim_speed > 8.0, "RAZOR cluster reaches spin speed (%.1f)"
				% razor._anim_speed)
	razor.queue_free()

	var maul: WeaponMount = build_anim_mount.call("MAUL-M")
	maul._cooldown = 0.0
	maul.heat = 0.0
	_assert(maul.try_fire([]), "MAUL fires for the pump test")
	var pump: Node3D = maul.get_node_or_null("pump_grip")
	var pump_rest: float = pump.position.x if pump != null else 0.0
	step_frames.call(maul)
	var pump_now: float = pump.position.x if pump != null else 0.0
	_assert(pump != null and absf(pump_now - pump_rest) > 0.05,
			"MAUL pump slide travels after a shot (%.3f != %.3f)" % [pump_now, pump_rest])
	maul.queue_free()

	var families: Array[String] = ["VOLT-M", "LUMEN-M", "PYRE-M", "VOLLEY-M", "ECHO-M"]
	for item_id in families:
		var mount: WeaponMount = build_anim_mount.call(item_id)
		mount._cooldown = 0.0
		mount.heat = 0.0
		_assert(mount.try_fire([]), "%s fires for its animation assert" % item_id)
		if item_id == "PYRE-M":
			step_frames.call(mount, 8)
		else:
			step_frames.call(mount)
		var animated: Array[Node3D] = []
		if item_id == "VOLT-M":
			var core := mount.get_node_or_null("energy_core") as MeshInstance3D
			if core != null:
				animated.append(core)
		elif item_id == "LUMEN-M":
			var tip := mount.get_node_or_null("emitter_tip") as MeshInstance3D
			if tip != null:
				animated.append(tip)
		elif item_id == "PYRE-M":
			var pilot := mount.get_node_or_null("pilot_flame") as MeshInstance3D
			if pilot != null:
				animated.append(pilot)
		elif item_id == "VOLLEY-M":
			animated.assign(mount.find_children("tube_ready", "MeshInstance3D", true, false))
		elif item_id == "ECHO-M":
			var drum_ok := mount.get_node_or_null("resonator_drum") as MeshInstance3D
			if drum_ok != null:
				animated.append(drum_ok)
		_assert(not animated.is_empty(),
				"%s collects animation parts (%d)" % [item_id, animated.size()])
		if not animated.is_empty():
			var moved := false
			for part: Node3D in animated:
				if absf(part.scale.x - 1.0) > 0.05:
					moved = true
			_assert(moved, "%s fires with a visible transform animation" % item_id)
		mount.queue_free()

	var void_core: WeaponMount = build_anim_mount.call("VOID-A")
	var singularity := void_core.get_node_or_null("singularity_core") as MeshInstance3D
	_assert(singularity != null, "VOID builds its singularity core for the pulse test")
	void_core._cooldown = 0.0
	void_core.heat = 0.0
	_assert(void_core.try_fire([]), "VOID fires for the pulse test")
	var base_emission: float = 0.0
	if void_core._anim_material != null:
		base_emission = void_core._anim_material_base
	step_frames.call(void_core)
	_assert(singularity != null and singularity.scale.x > 1.05,
			"VOID core swells after a shot (%.2f)" % singularity.scale.x)
	_assert(void_core._anim_material != null
			and void_core._anim_material.emission_energy_multiplier > base_emission * 1.1,
			"VOID core material flares on firing")
	void_core.queue_free()

func _check_void_mount() -> void:
	var void_data := WeaponData.for_item("VOID-A")
	_assert(void_data != null and void_data.kind == WeaponData.Kind.SALVO
			and void_data.size == WeaponData.Size.ALPHA,
			"VOID-A is an Alpha grav-salvo gun")
	_assert(void_data != null and void_data.magazine == 8
			and is_equal_approx(void_data.reload_time, 7.0),
			"VOID-A 8-round magazine / 7 s reload")
	_assert(void_data != null and is_equal_approx(void_data.supercharge_damage_mult, 1.2),
			"VOID-A post-reload supercharge +20%")
	_assert(void_data != null and void_data.splash_radius > 0.0
			and void_data.suppression_radius > 0.0 and void_data.suppression_damage > 0.0,
			"VOID-A splash core + suppression pulse")
	var chash := WeaponData.for_item("CHASH-B")
	_assert(chash != null and chash.size == WeaponData.Size.BETA
			and chash.magazine == 8 and chash.suppression_radius > 0.0,
			"CHASH-B Beta magazine gun with suppression core")
	_assert(GameState.TITAN_ITEM_IDS.has("VOID-A") and GameState.TITAN_ITEM_IDS.has("CHASH-B"),
			"titan store carries VOID + CHASH")
	var materials := {
		"gold": MeshUtil.make_material(Color.GOLD, 0.9, 0.35),
		"dark": MeshUtil.make_material(Color(0.2, 0.2, 0.22), 0.7, 0.5),
		"joint": MeshUtil.make_material(Color(0.1, 0.1, 0.11), 0.6, 0.7),
		"trim": MeshUtil.make_material(Color(0.6, 0.6, 0.62), 0.9, 0.35),
		"sensor": MeshUtil.make_material(Color(0.1, 0.3, 0.4), 0.5, 0.4),
	}
	var mount := WeaponMount.new()
	mount.setup(0, void_data, 1.0, materials)
	add_child(mount)
	_assert(mount.muzzle != null and mount.get_node_or_null("grav_cell") != null,
			"VOID-A builds its grav cell")
	_assert(mount.get_node_or_null("singularity_core") != null,
			"VOID-A builds its singularity core")
	_assert(mount.ammo_left() == 8 and not mount.is_reloading()
			and not mount.is_supercharged(),
			"VOID-A starts with a full cold magazine")
	var fired_all := true
	for shot in 8:
		mount._cooldown = 0.0
		mount.heat = 0.0
		if not mount.try_fire([]):
			fired_all = false
	_assert(fired_all, "VOID-A fires its full magazine")
	_assert(mount.ammo_left() == 0 and mount.is_reloading(),
			"empty magazine starts the reload (ammo %d)" % mount.ammo_left())
	var pulse_target: EnemyRobot = null
	for node in get_tree().get_nodes_in_group("enemy"):
		if node is EnemyRobot and not (node as EnemyRobot).health.dead:
			pulse_target = node as EnemyRobot
			break
	if pulse_target != null:
		mount.global_position = pulse_target.global_position
		var damage_before := pulse_target.health.damage_taken
		mount._reload_pulse = 0.0
		mount._physics_process(0.05)
		_assert(pulse_target.suppressed_mult() == 0.5,
				"reload pulse suppresses the nearby enemy")
		_assert(pulse_target.health.damage_taken > damage_before,
				"reload pulse damages the nearby enemy (%.0f -> %.0f)"
				% [damage_before, pulse_target.health.damage_taken])
		pulse_target._suppression_left = 0.0
	mount._reload_left = 0.05
	mount._physics_process(0.1)
	_assert(not mount.is_reloading() and mount.ammo_left() == 8,
			"reload refills the magazine (ammo %d)" % mount.ammo_left())
	_assert(mount.is_supercharged(), "reload supercharges the gun")
	mount._cooldown = 0.0
	mount.heat = 0.0
	_assert(mount.try_fire([]), "supercharged shot fires")
	var boosted := false
	for child in Projectiles.get_children():
		var proj := child as Projectile
		if proj != null and proj.is_active() \
				and is_equal_approx(proj.weapon_damage(), 13000.0 * 1.2):
			boosted = true
	_assert(boosted, "supercharged round deals +20% damage (15600)")
	mount.queue_free()

func _check_shot_appearance() -> void:
	# --- every original builder stamps its own family. Sound routing and the
	# muzzle colour are keyed off data.family; before this pass all ten
	# builders fell through to the shared "RAZOR" default. ---
	var want := [
		["RAZOR-M", "RAZOR", WeaponData.FlashShape.BALL, WeaponData.TracerShape.STREAK],
		["MAUL-M", "MAUL", WeaponData.FlashShape.PUFF, WeaponData.TracerShape.STREAK],
		["VOLT-M", "VOLT", WeaponData.FlashShape.BALL, WeaponData.TracerShape.ORB],
		["TORQ-H", "TORQ", WeaponData.FlashShape.NEEDLE, WeaponData.TracerShape.NEEDLE],
		["BREACH-M", "BREACH", WeaponData.FlashShape.BALL, WeaponData.TracerShape.SHELL],
		["FERRIC-M", "FERRIC", WeaponData.FlashShape.PUFF, WeaponData.TracerShape.ORB],
		["LUMEN-M", "LUMEN", WeaponData.FlashShape.DISC, WeaponData.TracerShape.NEEDLE],
		["PYRE-M", "PYRE", WeaponData.FlashShape.CONE, WeaponData.TracerShape.STREAK],
		["VOLLEY-M", "VOLLEY", WeaponData.FlashShape.BALL, WeaponData.TracerShape.SHELL],
		["ECHO-M", "ECHO", WeaponData.FlashShape.DISC, WeaponData.TracerShape.ORB],
	]
	var colour_set := {}
	var shape_set := {}
	for entry in want:
		var item_id := str(entry[0])
		var family := str(entry[1])
		var data := WeaponData.for_item(item_id)
		_assert(data != null and data.family == family,
				"%s stamps its own family %s (got %s)" % [item_id, family,
				data.family if data != null else "<null>"])
		if data == null:
			continue
		var look := WeaponData.shot_look(family, data.kind)
		_assert(int(look["shape"]) == int(entry[2]),
				"%s muzzle silhouette (%d)" % [family, int(look["shape"])])
		_assert(WeaponData.tracer_shape_for(family, data.kind) == int(entry[3]),
				"%s tracer silhouette" % family)
		colour_set[(look["color"] as Color).to_html()] = true
		shape_set[int(look["shape"])] = true
	_assert(colour_set.size() == want.size(),
			"each weapon class flashes a different colour (%d)" % colour_set.size())
	_assert(shape_set.size() >= 5,
			"all five muzzle silhouettes are in use (%d)" % shape_set.size())

	# Family colour overrides that must beat the class default.
	var brass: Color = WeaponData.shot_look("RAZOR", WeaponData.Kind.AUTOCANNON)["color"]
	var frost: Color = WeaponData.shot_look("RIME", WeaponData.Kind.AUTOCANNON)["color"]
	_assert(brass != frost, "freeze rounds read icy rather than brass")
	var gladius: Color = WeaponData.shot_look("GLADIUS", WeaponData.Kind.AUTOCANNON)["color"]
	_assert(brass != gladius, "two autocannons do not share one muzzle colour")
	var breach: Color = WeaponData.shot_look("BREACH", WeaponData.Kind.BLAST)["color"]
	var void_col: Color = WeaponData.shot_look("VOID", WeaponData.Kind.SALVO)["color"]
	_assert(breach != void_col, "void chasm cores burn violet, not rocket orange")

	# --- built mounts actually carry the look ---
	var materials := {
		"gold": MeshUtil.make_material(Color.GOLD, 0.9, 0.35),
		"dark": MeshUtil.make_material(Color(0.2, 0.2, 0.22), 0.7, 0.5),
		"joint": MeshUtil.make_material(Color(0.1, 0.1, 0.11), 0.6, 0.7),
		"trim": MeshUtil.make_material(Color(0.6, 0.6, 0.62), 0.9, 0.35),
		"sensor": MeshUtil.make_material(Color(0.1, 0.3, 0.4), 0.5, 0.4),
	}
	var mount_ids := ["RAZOR-M", "MAUL-M", "TORQ-H", "LUMEN-M", "PYRE-M", "VOID-A"]
	var light_ranges := {}
	for item_id: String in mount_ids:
		var mount := WeaponMount.new()
		mount.setup(0, WeaponData.for_item(item_id), 1.0, materials)
		add_child(mount)
		var look := WeaponData.shot_look(mount.data.family, mount.data.kind)
		_assert(mount._flash != null and mount._flash_light != null,
				"%s builds muzzle flash + light" % item_id)
		if mount._flash != null and mount._flash_light != null:
			_assert(absf(mount._flash_life - float(look["life"])) < 0.0005,
					"%s flash life follows its family (%.3f s)" % [item_id, mount._flash_life])
			_assert(absf(mount._flash_lrange - float(look["lrange"])) < 0.0005,
					"%s flash light range follows its family (%.1f m)"
					% [item_id, mount._flash_lrange])
			_assert(mount._flash_light.light_color == (look["color"] as Color),
					"%s flash light colour matches its family" % item_id)
			_assert(is_equal_approx(mount._flash_stretch, float(look["stretch"])),
					"%s flash stretch matches its family" % item_id)
			light_ranges[item_id] = mount._flash_lrange
			var shape := int(look["shape"])
			var flash_mesh := mount._flash.mesh
			var cylinder := flash_mesh as CylinderMesh
			match shape:
				WeaponData.FlashShape.BALL, WeaponData.FlashShape.PUFF:
					_assert(flash_mesh is SphereMesh, "%s builds a round flash" % item_id)
				WeaponData.FlashShape.CONE:
					_assert(cylinder != null and cylinder.top_radius < cylinder.bottom_radius,
							"%s builds a tapered cone flash" % item_id)
				_:
					_assert(cylinder != null
							and absf(cylinder.top_radius - cylinder.bottom_radius) < 0.001,
							"%s builds a straight cylinder flash" % item_id)
		mount.queue_free()
	_assert(light_ranges.size() == mount_ids.size(),
			"every probe mount kept its own flash profile (%d)" % light_ranges.size())
	_assert(absf(float(light_ranges.get("RAZOR-M", 0.0)) - float(light_ranges.get("VOID-A", 99.0))) > 0.1,
			"flash light range differs between a rifle and a titan gun")

	# --- per-weapon fire voices ---
	_assert(AudioEngine.has_sound(&"whip"), "light kinetic whip voice built")
	_assert(AudioEngine.has_sound(&"clank"), "heavy titan clank voice built")
	_assert(AudioEngine._voice_stream(&"RAZOR", WeaponData.Kind.AUTOCANNON) == &"cannon",
			"RAZOR keeps the autocannon voice")
	_assert(AudioEngine._voice_stream(&"GLADIUS", WeaponData.Kind.AUTOCANNON) == &"whip",
			"GLADIUS uses the light whip voice")
	_assert(AudioEngine._voice_stream(&"JUGGERNAUT", WeaponData.Kind.AUTOCANNON) == &"clank",
			"titan kinetic guns use the heavy clank voice")
	_assert(AudioEngine._voice_stream(&"NOPE-UNKNOWN", WeaponData.Kind.BLAST) == &"launch",
			"unknown families fall back to their kind voice")
	_assert(AudioEngine._size_pitch(WeaponData.Size.LIGHT) > AudioEngine._size_pitch(WeaponData.Size.MEDIUM),
			"light barrels report higher than medium")
	_assert(AudioEngine._size_pitch(WeaponData.Size.HEAVY) < 0.0,
			"heavy barrels report lower than medium")
	var missing_voice: Array[String] = []
	var pitch_set := {}
	for item_id: String in GameState.ALL_ITEM_IDS + GameState.TITAN_ITEM_IDS:
		var data := WeaponData.for_item(item_id)
		if data == null:
			missing_voice.append(item_id + "=null")
			continue
		var stream := AudioEngine._voice_stream(StringName(data.family), data.kind)
		if not AudioEngine.has_sound(stream):
			missing_voice.append("%s->%s" % [item_id, stream])
		pitch_set[snappedf(AudioEngine._family_pitch(StringName(data.family)), 0.001)] = true
	_assert(missing_voice.is_empty(),
			"every weapon in the catalog resolves a registered voice (%d missing: %s)"
			% [missing_voice.size(), str(missing_voice)])
	_assert(pitch_set.size() >= 30,
			"family voices spread across the pitch range (%d distinct)" % pitch_set.size())

func _check_robot_motion_profiles() -> void:
	# Director: each robot shoots/reloads/moves with its own stance +
	# recoil/reload pose driving the hull in update_animation.
	var build_rig := func(robot_id: StringName) -> RobotRig:
		var previous_robot := GameState.selected_robot
		GameState.selected_robot = robot_id
		var rig: RobotRig
		match robot_id:
			GameState.ROBOT_VORTEX:
				rig = VortexRig.new()
			GameState.ROBOT_RAMPART:
				rig = ZephyrRig.new()
			_:
				if bool(GameState.robot_def().get("is_titan", false)):
					rig = TitanRig.new()
				else:
					rig = RobotRig.new()
		rig.visual_scale = float(GameState.robot_def().get("scale", 1.0))
		add_child(rig)
		GameState.selected_robot = previous_robot
		return rig

	var scarab: RobotRig = build_rig.call(GameState.ROBOT_SCARAB)
	_assert(scarab.fire_kick_decay > 0.0 and scarab.fire_pitch_kick < 0.0,
			"SCARAB ships its recoil tuning (decay %.1f, pitch %.2f)"
			% [scarab.fire_kick_decay, scarab.fire_pitch_kick])
	scarab.kick_fire()
	_assert(scarab._fire_kick > 0.0, "kick_fire arms the recoil kick (%.2f)"
			% scarab._fire_kick)
	var pitch_before: float = scarab._pitch
	scarab.update_animation(0.016, Vector3.ZERO, 0.0, true, 0.0, 0.0)
	_assert(scarab._pitch < pitch_before,
			"recoil kicks the hull pitch (%.4f -> %.4f)" % [pitch_before, scarab._pitch])
	scarab.set_reloading(true)
	for frame in 30:
		scarab.update_animation(0.016, Vector3.ZERO, 0.0, true, 0.0, 0.0)
	_assert(scarab._reload_pose > 0.5, "reload brace eases in (%.2f)" % scarab._reload_pose)
	scarab.set_reloading(false)
	for frame in 30:
		scarab.update_animation(0.016, Vector3.ZERO, 0.0, true, 0.0, 0.0)
	_assert(scarab._reload_pose < 0.2, "reload brace recovers (%.2f)" % scarab._reload_pose)
	var scarab_decay: float = scarab.fire_kick_decay
	var scarab_pitch: float = scarab.fire_pitch_kick
	var scarab_move_gain: float = scarab.move_pitch_gain
	var scarab_turn_roll: float = scarab.turn_roll_gain
	var scarab_bob_freq: float = scarab.bob_freq_base
	scarab.free()

	var vortex: RobotRig = build_rig.call(GameState.ROBOT_VORTEX)
	_assert(vortex.fire_kick_decay > scarab_decay,
			"VORTEX settles its recoil faster than SCARAB")
	_assert(vortex.move_pitch_gain > scarab_move_gain,
			"VORTEX reads movement weight (%.3f)" % vortex.move_pitch_gain)
	var vortex_turn_roll: float = vortex.turn_roll_gain
	vortex.free()

	var zephyr: RobotRig = build_rig.call(GameState.ROBOT_RAMPART)
	_assert(zephyr.hover_bob_amp >= 0.03,
			"ZEPHYR bobs in the air (%.3f)" % zephyr.hover_bob_amp)
	_assert(zephyr.turn_roll_gain > vortex_turn_roll,
			"ZEPHYR banks into turns harder than VORTEX")
	zephyr.free()

	var titan: RobotRig = build_rig.call(GameState.ROBOT_PRAETOR)
	_assert(titan.fire_pitch_kick < scarab_pitch - 0.01,
			"PRAETOR recoils deeper than SCARAB (%.3f)" % titan.fire_pitch_kick)
	_assert(titan.bob_freq_base < scarab_bob_freq,
			"PRAETOR walks with a heavier gait")
	titan.free()

	var original_robot := GameState.selected_robot
	GameState.selected_robot = GameState.ROBOT_SCARAB
	_assert(AudioEngine._robot_voice().x < 1.0,
			"SCARAB voice lower than stock")
	GameState.selected_robot = GameState.ROBOT_VORTEX
	_assert(AudioEngine._robot_voice().x > 1.0,
			"VORTEX voice raised")
	_assert(AudioEngine._engine_loop_id() == &"engine_vortex",
			"VORTEX hums its own engine loop")
	GameState.selected_robot = GameState.ROBOT_RAMPART
	_assert(AudioEngine._engine_loop_id() == &"engine_rampart",
			"ZEPHYR hums its own engine loop")
	_assert(AudioEngine._robot_voice().x >= 1.1,
			"ZEPHYR voice is the highest")
	GameState.selected_robot = GameState.ROBOT_PRAETOR
	_assert(AudioEngine._robot_voice().x < 0.9,
			"PRAETOR voice deepest (%.3f)" % AudioEngine._robot_voice().x)
	_assert(AudioEngine._engine_loop_id() == &"engine_praetor",
			"PRAETOR hums its own engine loop")
	GameState.selected_robot = original_robot
	_assert(Events.weapon_reload_started.get_connections().size() >= 1,
			"reload clack listener wired (%d)"
			% Events.weapon_reload_started.get_connections().size())

func _check_paint_shop_api() -> void:
	_assert(GameState.PAINT_COSTS.size() == GameState.PALETTE_COUNT,
			"a price exists for every palette (%d)" % GameState.PAINT_COSTS.size())
	var saved_unlocked: Array[int] = []
	for paint_index in GameState.unlocked_paints:
		saved_unlocked.append(paint_index)
	var saved_silver := GameState.silver
	GameState.unlocked_paints.erase(2)
	GameState.silver = 10000
	_assert(not GameState.paint_unlocked(2), "palette 2 locks for the test")
	_assert(not GameState.unlock_paint(2), "unlock refuses without enough silver")
	_assert(GameState.silver == 10000 and not GameState.paint_unlocked(2),
			"failed unlock keeps the wallet")
	GameState.silver = 40000
	_assert(GameState.unlock_paint(2), "unlock succeeds with enough silver")
	_assert(GameState.silver == 10000,
			"unlock deducts the 30000 price (%d)" % GameState.silver)
	_assert(GameState.paint_unlocked(2), "palette 2 unlocked after purchase")
	GameState.unlocked_paints = saved_unlocked
	GameState.silver = saved_silver
	GameState.save_settings()
	_assert(GameState.paint_unlocked(0), "free palette stays unlocked")
	var report := GameState.combat_stat_report()
	_assert(report.size() == 7, "combat stat report rows (%d)" % report.size())
	for row in report:
		var stat_key := String(row.get("key", ""))
		var base := float(row.get("base", 1.0))
		var final := float(row.get("final", 1.0))
		_assert(final >= 0.0, "stat %s never negative (%.3f)" % [stat_key, final])
		if stat_key == "regen":
			continue
		_assert(final > 0.0, "stat %s final positive" % stat_key)
		if stat_key == "defense" or stat_key == "cooldown":
			_assert(final <= base + 0.0001 and final >= 0.4 - 0.0001,
					"stat %s within defensive bounds (%.3f)" % [stat_key, final])
		else:
			_assert(final >= base - 0.0001, "stat %s never below base" % stat_key)

func _check_world_liveliness() -> void:
	var nature := _game.get_node_or_null("Nature")
	_assert(nature != null, "nature backdrop present")
	if nature == null:
		return
	_assert(nature.get_node_or_null("VoidGround") != null,
			"void-ground disc grounds the backdrop mountains")
	var weather := nature.get_node_or_null("WeatherSystem") as WeatherSystem
	_assert(weather != null, "weather system in the match")
	if weather != null:
		# Natural first event lands in 6-10 s; the storm phase holds a forced
		# state for 9999 s, so accept either scheduling.
		_assert(weather._state_left <= 10.0 or weather._state_left >= 9990.0,
				"first weather event arrives within 10 s (%.1f)" % weather._state_left)
	var volcano := nature.get_node_or_null("VolcanoActivity") as VolcanoActivity
	_assert(volcano != null, "volcano activity in the match")
	if volcano != null:
		# First eruption 10-16 s; after the forced test eruption it reschedules
		# 26-40 s out.
		_assert(volcano._erupt_in <= 40.0,
				"next eruption within 40 s (%.1f)" % volcano._erupt_in)
		_assert(volcano.get_node_or_null("AshPlume") != null, "ash plume keeps smoking")
	var player := get_tree().get_first_node_in_group("player") as Node3D
	_assert(player != null, "player present for liveliness checks")
	if player != null:
		var bolts_before := nature.find_children("LightningBolt*", "Node3D",
				false, false).size()
		nature.strike_lightning()
		var bolts := nature.find_children("LightningBolt*", "Node3D", false, false)
		_assert(bolts.size() > bolts_before, "lightning strike spawns a bolt")
		for bolt in bolts:
			var bolt_node := bolt as Node3D
			if bolt_node == null:
				continue
			var distance := bolt_node.global_position.distance_to(player.global_position)
			_assert(distance <= 180.0,
					"bolt lands near the player (%.0fm)" % distance)
			break
		var ability_value: Variant = player.get("ability")
		if ability_value is ShadowDash:
			_assert((ability_value as ShadowDash).get_node_or_null("DashTrail") != null,
					"dash trail built")
	var enemy := _first_enemy()
	if enemy != null:
		enemy._spawn_death_debris()
		_assert(enemy.get_node_or_null("DeathDebris") != null, "death debris burst spawns")
		var debris := enemy.get_node_or_null("DeathDebris") as CPUParticles3D
		if debris != null:
			debris.queue_free()

func _check_chassis_sizes() -> void:
	# Director: robots must differ in size — titan biggest, others bigger/smaller
	# in the hangar AND in battle.
	var scales := {}
	for robot_id in GameState.ROBOT_DEFS.keys():
		var s := float(GameState.ROBOT_DEFS[robot_id].get("scale", -1.0))
		scales[robot_id] = s
		_assert(s >= 0.8 and s <= 1.25,
				"robot %s declares a sane chassis scale (%.2f)" % [robot_id, s])
	_assert(absf(float(scales.get(GameState.ROBOT_SCARAB, -1.0)) - 1.0) < 0.001,
			"SCARAB is the 1.0 size baseline (%.2f)" % float(scales.get(GameState.ROBOT_SCARAB, -1.0)))
	var vortex_scale := float(scales.get(GameState.ROBOT_VORTEX, 1.0))
	var zephyr_scale := float(scales.get(GameState.ROBOT_RAMPART, 1.0))
	_assert(vortex_scale >= zephyr_scale + 0.2,
			"VORTEX is visibly bigger than ZEPHYR (%.2f vs %.2f)" % [vortex_scale, zephyr_scale])
	_assert(zephyr_scale < 1.0,
			"ZEPHYR is the smallest chassis (%.2f)" % zephyr_scale)
	# Leg lengths follow the chassis scale, so a scaled rig measures bigger.
	var leg_probe := LegUnit.new()
	leg_probe.apply_scale(1.18)
	_assert(leg_probe.thigh_length > 1.15 * 1.18 - 0.001
			and leg_probe.stride_length > 1.05 * 1.18 - 0.001,
			"apply_scale grows the IK constants (%.3f / %.3f)" % [
				leg_probe.thigh_length, leg_probe.stride_length])
	leg_probe.free()

func _check_zephyr_swap() -> void:
	var previous := GameState.selected_robot
	var saved_loadout: Array = (GameState.loadouts[GameState.ROBOT_RAMPART] as Array).duplicate()
	GameState.loadouts[GameState.ROBOT_RAMPART] = ["RAZOR-M", "RAZOR-M", "MAUL-H"]
	GameState.selected_robot = GameState.ROBOT_RAMPART
	var alt_game := (load("res://scenes/game.tscn") as PackedScene).instantiate()
	add_child(alt_game)
	var alt_player := alt_game.get_node_or_null("Player") as PlayerRobot
	_assert(alt_player != null, "zephyr game scene spawns player")
	if alt_player != null:
		_assert(alt_player.rig != null, "zephyr rig attached")
		if alt_player.rig != null:
			_assert(alt_player.rig is ZephyrRig, "zephyr rig class used")
			var z_scale := float(GameState.robot_def().get("scale", 1.0))
			_assert(is_equal_approx(alt_player.rig.visual_scale, z_scale),
					"zephyr rig carries its chassis scale (%.2f)" % alt_player.rig.visual_scale)
			_assert(is_equal_approx(alt_player.rig.scale.x, z_scale),
					"zephyr rig node is scaled (%.2f)" % alt_player.rig.scale.x)
			var z_capsule := (alt_player.get_node_or_null("BodyCollision") as CollisionShape3D)
			var z_shape: CapsuleShape3D = null
			if z_capsule != null:
				z_shape = z_capsule.shape as CapsuleShape3D
			_assert(z_shape != null and absf(z_shape.radius - 1.25 * z_scale) < 0.01,
					"zephyr hitbox scales with the chassis (%.3f)" % (
						z_shape.radius if z_shape != null else -1.0))
			_assert(alt_player.rig.leg_units.size() == 0,
					"zephyr has no IK legs (%d)" % alt_player.rig.leg_units.size())
			_assert(alt_player.rig.get_node_or_null("Tail") == null, "zephyr has no tail")
			_assert(alt_player.rig.hardpoint_count() == 3,
					"zephyr three hardpoints (%d)" % alt_player.rig.hardpoint_count())
			var zephyr_rig := alt_player.rig as ZephyrRig
			_assert(zephyr_rig != null and zephyr_rig.wings.size() == 4,
					"zephyr four wings (%d)" % (
						zephyr_rig.wings.size() if zephyr_rig != null else -1))
			if zephyr_rig != null:
				for wing_index in zephyr_rig.wings.size():
					var wing := zephyr_rig.wings[wing_index] as Node3D
					var wing_meshes := wing.find_children("*", "MeshInstance3D", true, false)
					_assert(wing_meshes.size() >= 1,
							"zephyr wing %d meshes attached (%d)" % [wing_index, wing_meshes.size()])
			var chassis_node := alt_player.rig.get_node_or_null("Chassis")
			var head_node := alt_player.rig.get_node_or_null("HeadSensor")
			_assert(chassis_node != null and head_node != null,
					"zephyr anchors present (chassis/head)")
			var meshes: Array[Node] = []
			if chassis_node != null:
				meshes.append_array(chassis_node.find_children("*", "MeshInstance3D", true, false))
			if head_node != null:
				meshes.append_array(head_node.find_children("*", "MeshInstance3D", true, false))
			_assert(meshes.size() >= 6, "zephyr GLB meshes attached (%d)" % meshes.size())
			var surfaces_checked := 0
			var materials_ok := 0
			for mesh_node in meshes:
				var surface_mesh := mesh_node as MeshInstance3D
				if surface_mesh == null or surface_mesh.mesh == null:
					continue
				for surface in surface_mesh.mesh.get_surface_count():
					var mat: Material = surface_mesh.get_active_material(surface)
					surfaces_checked += 1
					if mat is StandardMaterial3D:
						materials_ok += 1
			_assert(surfaces_checked > 0 and materials_ok == surfaces_checked,
					"zephyr materials mapped (%d/%d)" % [materials_ok, surfaces_checked])
		var alt_system := alt_player.get_node_or_null("WeaponSystem") as WeaponSystem
		if alt_system == null and alt_player.weapons != null:
			alt_system = alt_player.weapons
		_assert(alt_system != null and alt_system.mounts.size() == 3,
				"zephyr weapon mounts wired (%d)" % (
					alt_system.mounts.size() if alt_system != null else -1))
		if alt_system != null and alt_system.mounts.size() == 3:
			var all_wired := true
			for alt_mount in alt_system.mounts:
				if alt_mount.data == null:
					all_wired = false
			_assert(all_wired, "zephyr all three mounts have weapon data")
			_assert(alt_system.mounts[0].data != null
					and alt_system.mounts[0].data.family == "RAZOR",
					"zephyr slot0 is RAZOR (%s)" % (
						alt_system.mounts[0].data.family if alt_system.mounts[0].data != null else "null"))
			_assert(alt_system.mounts[2].data != null
					and alt_system.mounts[2].data.family == "MAUL",
					"zephyr slot2 is MAUL (%s)" % (
						alt_system.mounts[2].data.family if alt_system.mounts[2].data != null else "null"))
			_assert(alt_system.builtin != null and alt_system.builtin.data != null
					and alt_system.builtin.data.display_name == "WINDCUTTER",
					"zephyr builtin is the windcutter")
			_assert(alt_system.builtin_requires_field, "zephyr builtin is ability-gated")
			var fired := alt_system.mounts[0].try_fire([], Vector3.FORWARD, null)
			_assert(fired, "zephyr mount fires directly (try_fire)")
			var aim_ok := true
			for alt_mount in alt_system.mounts:
				var alt_socket := alt_mount.get_parent() as Node3D
				if alt_socket == null or alt_mount.muzzle == null:
					aim_ok = false
					continue
				var aim := alt_mount.muzzle.global_position - alt_socket.global_position
				var aim_local := alt_player.global_basis.inverse() * aim
				if aim_local.length() < 0.5 or aim_local.normalized().dot(Vector3.FORWARD) < 0.99:
					aim_ok = false
			_assert(aim_ok, "zephyr mounts aim forward")
		_assert(alt_player.ability is SiroccoAbility, "zephyr uses the gale veil ability")
		if alt_player.ability is SiroccoAbility:
			var gale := alt_player.ability as SiroccoAbility
			_assert(not gale.is_field_active(), "gale field starts inactive")
			gale.activate()
			_assert(gale.is_field_active(), "gale field activates")
			_assert(gale.charges == 1, "gale spends a charge (%d)" % gale.charges)
			var lifted := gale.tick_vertical(0.016)
			_assert(lifted and alt_player.velocity.y > 0.0,
					"gale tick lifts the robot (vy=%.2f)" % alt_player.velocity.y)
			if alt_player.health != null:
				var before := alt_player.health.current
				alt_player.health.apply_damage(500.0, alt_player.global_position)
				_assert(gale.is_stealth_active(), "damage during the field pops stealth")
				_assert(alt_player.health.current < before, "damage applied")
			gale.force_end()
			_assert(not gale.is_field_active() and not gale.is_stealth_active(),
					"gale force ends cleanly")
			# W7: hover inside a real interior must not punch through the roof.
			var interior := alt_game.get_node_or_null("OpenRealm/BunkerHub") as Node3D
			_assert(interior != null, "bunker staged for flyer ceiling test")
			if interior != null:
				var floor_y := interior.global_position.y
				var roof_y := floor_y + 3.4
				alt_player.global_position = interior.to_global(Vector3(0.0, 1.2, 0.0))
				alt_player.velocity = Vector3.ZERO
				gale.activate()
				_assert(gale.is_field_active(), "gale activates indoors")
				for step in 90:
					gale.tick_vertical(0.016)
					alt_player.global_position.y += alt_player.velocity.y * 0.016
				_assert(alt_player.global_position.y < roof_y - 0.4,
						"flyer holds under the bunker roof (%.2f < %.2f)" % [
							alt_player.global_position.y, roof_y - 0.4])
				_assert(alt_player.global_position.y > floor_y,
						"flyer stays above the bunker floor (%.2f > %.2f)" % [
							alt_player.global_position.y, floor_y])
				gale.force_end()
		_assert(alt_player.floor_snap_length == 0.0, "zephyr hover disables floor snap")
		_assert(alt_player.health != null and int(alt_player.health.max_health) == 380000,
				"zephyr armor 380K (got %s)" % (
					str(alt_player.health.max_health) if alt_player.health != null else "null"))
	alt_game.free()
	GameState.loadouts[GameState.ROBOT_RAMPART] = saved_loadout
	GameState.selected_robot = previous

func _check_vortex_swap() -> void:
	var previous := GameState.selected_robot
	GameState.selected_robot = GameState.ROBOT_VORTEX
	var alt_game := (load("res://scenes/game.tscn") as PackedScene).instantiate() as Node3D
	add_child(alt_game)
	var alt_player := alt_game.get_node_or_null("Player") as PlayerRobot
	_assert(alt_player != null, "vortex game scene spawns player")
	if alt_player != null:
		_assert(alt_player.rig != null, "vortex rig attached")
		if alt_player.rig != null:
			_assert(alt_player.rig is VortexRig, "vortex rig class used")
			_assert(alt_player.rig.leg_units.size() == 2,
					"vortex biped legs (%d)" % alt_player.rig.leg_units.size())
			_assert(alt_player.rig.get_node_or_null("Tail") == null, "vortex has no tail")
			_assert(alt_player.rig.hardpoint_count() == 4,
					"vortex four hardpoints (%d)" % alt_player.rig.hardpoint_count())
			var glb_parts := alt_player.rig.find_children("chassis__*", "MeshInstance3D", true, false)
			_assert(glb_parts.size() > 0, "vortex GLB chassis attached (%d)" % glb_parts.size())
			var leg_parts := alt_player.rig.find_children("l0*", "MeshInstance3D", true, false)
			_assert(leg_parts.size() > 0, "vortex GLB leg parts attached (%d)" % leg_parts.size())
			for leg in alt_player.rig.leg_units:
				_assert(_is_finite(leg.global_position), "vortex leg %s finite" % leg.name)
				_assert(leg.get_node_or_null("LegBody") != null, "vortex leg %s collision" % leg.name)
		var alt_system := alt_player.get_node_or_null("WeaponSystem") as WeaponSystem
		if alt_system == null and alt_player.weapons != null:
			alt_system = alt_player.weapons
		_assert(alt_system != null and alt_system.mounts.size() == 4,
				"vortex weapon mounts wired")
		if alt_system != null and alt_system.mounts.size() == 4:
			var all_wired := true
			for alt_mount in alt_system.mounts:
				if alt_mount.data == null:
					all_wired = false
			_assert(all_wired, "vortex all four mounts have weapon data")
			_assert(alt_system.mounts[0].data != null
					and alt_system.mounts[0].data.kind == WeaponData.Kind.ELECTRIC,
					"vortex mounts are VOLT electric")
			_assert(alt_system.mounts[0].data.family == "VOLT",
					"vortex weapon family VOLT (%s)" % alt_system.mounts[0].data.family)
			var fired := alt_system.mounts[0].try_fire([], Vector3.FORWARD, null)
			_assert(fired, "vortex mount fires directly (try_fire)")
		_assert(alt_player.health != null and int(alt_player.health.max_health) == 430000,
				"vortex armor 430K (got %s)" % (str(alt_player.health.max_health) if alt_player.health != null else "null"))
	alt_game.free()
	GameState.selected_robot = previous

func _check_upgrade_api() -> void:
	var saved_upgrades: Dictionary = GameState.upgrades.duplicate(true)
	var saved_silver := GameState.silver
	var saved_gold := GameState.gold
	var saved_parts := GameState.spare_parts
	_assert(GameState.ALL_ITEM_IDS.size() == 62, "catalog has 62 weapon items (%d)" % GameState.ALL_ITEM_IDS.size())
	_assert(GameState.TITAN_ITEM_IDS.size() == 26, "titan catalog has 26 items (%d)" % GameState.TITAN_ITEM_IDS.size())
	_assert(GameState.silver >= 1000000000, "silver grant default 1B (%d)" % GameState.silver)
	_assert(GameState.gold >= 1000000, "gold grant default 1M (%d)" % GameState.gold)
	_assert(GameState.spare_parts >= 1000000, "spare parts grant default 1M (%d)" % GameState.spare_parts)
	_assert(GameState.microchips >= 500000, "microchips grant default 500k (%d)" % GameState.microchips)
	_assert(GameState.module_points >= 500000, "module points grant default 500k (%d)" % GameState.module_points)
	_assert(GameState.platinum >= 500000, "platinum grant default 500k (%d)" % GameState.platinum)
	_assert(GameState.memorium >= 500000, "memorium grant default 500k (%d)" % GameState.memorium)
	_assert(GameState.fmt_amount(340000.0) == "340K",
			"fmt 340000 renders 340K (%s)" % GameState.fmt_amount(340000.0))
	_assert(GameState.fmt_amount(17000.0) == "17K",
			"fmt 17000 renders 17K (%s)" % GameState.fmt_amount(17000.0))
	_assert(GameState.fmt_amount(4250.0) == "4250",
			"fmt 4250 renders 4250 (%s)" % GameState.fmt_amount(4250.0))
	_assert(GameState.fmt_amount(2000000.0) == "2.00M",
			"fmt 2000000 renders 2.00M (%s)" % GameState.fmt_amount(2000000.0))
	_assert(GameState.fmt_amount(999900.0) == "1.00M",
			"fmt 999900 promotes to 1.00M, never 1000K (%s)" % GameState.fmt_amount(999900.0))
	for item_id in GameState.ALL_ITEM_IDS:
		var data := WeaponData.for_item(item_id)
		_assert(data != null, "catalog item %s builds" % item_id)
		if data != null:
			_assert(data.item_id == item_id, "catalog item %s id kept (%s)" % [item_id, data.item_id])
			var band_max := 12000.0
			match data.size:
				WeaponData.Size.LIGHT: band_max = 7000.0
				WeaponData.Size.HEAVY: band_max = 32000.0
				WeaponData.Size.ALPHA: band_max = 30000.0
				WeaponData.Size.BETA: band_max = 30000.0
				_: pass
			_assert(data.damage >= 300.0 and data.damage <= band_max,
					"catalog %s WR-scale damage (%.0f <= %.0f)" % [item_id, data.damage, band_max])
	var torq := WeaponData.for_item("TORQ-H")
	_assert(torq != null and torq.kind == WeaponData.Kind.MAGNETIC, "TORQ-H is magnetic")
	var breach := WeaponData.for_item("BREACH-M")
	_assert(breach != null and breach.kind == WeaponData.Kind.BLAST and breach.splash_radius > 0.0,
			"BREACH-M has splash")
	var ferric := WeaponData.for_item("FERRIC-L")
	_assert(ferric != null and ferric.kind == WeaponData.Kind.CORROSION
			and ferric.corrosion_dps > 0.0, "FERRIC-L has corrosion")
	var lumen := WeaponData.for_item("LUMEN-H")
	_assert(lumen != null and lumen.kind == WeaponData.Kind.BEAM
			and lumen.projectile_speed >= 250.0 and lumen.projectile_drop <= 0.05,
			"LUMEN-H is fast flat beam")
	# WR Lumen stats taken verbatim from the wiki ground truth (600 m, 60-round
	# magazine, 10 s reload, 60 rounds / 15 s unload), damage ladder lifted
	# onto our 300 floor by a uniform factor so the 1 : 1.5 : 2 shape survives.
	var lumen_light := WeaponData.for_item("LUMEN-L")
	var lumen_medium := WeaponData.for_item("LUMEN-M")
	if lumen_light != null and lumen_medium != null and lumen != null:
		_assert(lumen_light.beam_range == 600.0 and lumen_medium.beam_range == 600.0
				and lumen.beam_range == 600.0,
				"LUMEN reaches WR's 600 m (L %.0f / M %.0f / H %.0f)" % [
				lumen_light.beam_range, lumen_medium.beam_range, lumen.beam_range])
		_assert(lumen_light.magazine == 60 and lumen_medium.magazine == 60
				and lumen.magazine == 60 and is_equal_approx(lumen_light.reload_time, 10.0),
				"LUMEN carries WR's 60-round magazine on a 10 s reload (%d / %.1f)" % [
				lumen_light.magazine, lumen_light.reload_time])
		_assert(lumen_light.shots_per_minute == 240.0
				and lumen_medium.shots_per_minute == 240.0
				and lumen.shots_per_minute == 240.0,
				"LUMEN unloads 60 rounds in WR's 15 s (%.0f rpm)" % lumen_light.shots_per_minute)
		_assert(is_equal_approx(lumen_medium.damage, lumen_light.damage * 1.5)
				and is_equal_approx(lumen.damage, lumen_light.damage * 2.0)
				and lumen_light.damage >= 300.0,
				"LUMEN keeps WR's 1:1.5:2 ladder on our damage band (%.0f / %.0f / %.0f)" % [
				lumen_light.damage, lumen_medium.damage, lumen.damage])
	# Beam animation: the cover-bending polyline must round into a smooth arc
	# (War Robots Lumen snakes around the obstacle instead of kinking into a
	# hard V) while pinning the muzzle and impact points exactly.
	var beam_kink: Array[Vector3] = [
		Vector3.ZERO, Vector3(5.0, 6.0, 0.0), Vector3(10.0, 0.0, 0.0)]
	var beam_arc: Array[Vector3] = BeamEffect._smooth(beam_kink, 2)
	var beam_corner := absf(beam_kink[1].y)
	var beam_bend := 0.0
	for beam_point: Vector3 in beam_arc:
		beam_bend = maxf(beam_bend, absf(beam_point.y))
	_assert(beam_arc.size() > beam_kink.size() and beam_bend < beam_corner
			and beam_bend > 1.0,
			"beam bend rounds into a smooth arc (%d pts, bend %.1f < corner %.1f)" % [
			beam_arc.size(), beam_bend, beam_corner])
	_assert(beam_arc[0].is_equal_approx(beam_kink[0])
			and beam_arc[beam_arc.size() - 1].is_equal_approx(beam_kink[beam_kink.size() - 1]),
			"beam smoothing pins the muzzle and impact points")
	var pyre := WeaponData.for_item("PYRE-M")
	_assert(pyre != null and pyre.kind == WeaponData.Kind.FLAME
			and pyre.corrosion_dps > 0.0 and pyre.pellets > 1,
			"PYRE-M is burning scatter")
	var volley := WeaponData.for_item("VOLLEY-L")
	_assert(volley != null and volley.kind == WeaponData.Kind.SALVO
			and volley.splash_radius > 0.0 and volley.pellets == 2,
			"VOLLEY-L is twin salvo with splash")
	var echo := WeaponData.for_item("ECHO-M")
	_assert(echo != null and echo.kind == WeaponData.Kind.SONIC
			and echo.pellets > 1 and echo.hull_fraction == 1.0,
			"ECHO-M is multi-pellet sonic with 100% grey damage")
	_assert(GameState.ALL_ITEM_IDS.has("ECHO-L") and GameState.ALL_ITEM_IDS.has("ECHO-H"),
			"catalog carries the full ECHO family")
	# --- v0.35 WR 12.x catalog: parse, kinds, spot stats -------------------
	for item_id in GameState.TITAN_ITEM_IDS:
		var titan_data := WeaponData.for_item(item_id)
		_assert(titan_data != null and titan_data.item_id == item_id,
				"titan item %s builds" % item_id)
		if titan_data != null:
			_assert(titan_data.damage >= 300.0,
					"titan %s WR-scale damage (%.0f)" % [item_id, titan_data.damage])
	var iara := WeaponData.for_item("IARAGHI-L")
	_assert(iara != null and iara.kind == WeaponData.Kind.MAGNETIC
			and iara.magazine == 6 and iara.pellets == 6
			and iara.shots_per_minute <= 61.0,
			"IARAGHI-L charged burst (mag 6 / 6 pellets / 60 rpm)")
	var harm := WeaponData.for_item("HARMATTAN-H")
	_assert(harm != null and harm.kind == WeaponData.Kind.SCATTERGUN
			and harm.pellets == 12 and harm.magazine == 12,
			"HARMATTAN-H 12-pellet drum")
	var toxin := WeaponData.for_item("TOXIN-L")
	_assert(toxin != null and toxin.family == "TOXIN"
			and toxin.size == WeaponData.Size.LIGHT
			and toxin.kind == WeaponData.Kind.CORROSION
			and toxin.corrosion_dps > 0.0,
			"TOXIN-L family parse + corrosion")
	var cryo := WeaponData.for_item("CRYO-M")
	_assert(cryo != null and cryo.family == "CRYO"
			and cryo.size == WeaponData.Size.MEDIUM
			and is_equal_approx(cryo.damage, 1900.0)
			and cryo.slow_factor < 1.0,
			"CRYO-M medium freeze rocket")
	var glacier := WeaponData.for_item("GLACIER-H")
	_assert(glacier != null and glacier.family == "GLACIER"
			and glacier.size == WeaponData.Size.HEAVY,
			"GLACIER-H heavy freeze rocket")
	var atom := WeaponData.for_item("ATOMIZER-M")
	_assert(atom != null and atom.family == "ATOMIZER"
			and atom.size == WeaponData.Size.MEDIUM
			and atom.kind == WeaponData.Kind.AUTOCANNON,
			"ATOMIZER-M medium autocannon")
	var barq := WeaponData.for_item("BARQ-A")
	_assert(barq != null and barq.kind == WeaponData.Kind.ELECTRIC
			and barq.slow_factor < 1.0 and barq.magazine == 100
			and barq.size == WeaponData.Size.ALPHA,
			"BARQ-A arc + slowdown + mag 100")
	var evora := WeaponData.for_item("EVORA-A")
	_assert(evora != null and evora.kind == WeaponData.Kind.SONIC
			and is_equal_approx(evora.hull_fraction, 1.0)
			and evora.size == WeaponData.Size.ALPHA,
			"EVORA-A sonic grey damage (alpha)")
	var furnace := WeaponData.for_item("FURNACE-A")
	_assert(furnace != null and furnace.kind == WeaponData.Kind.BEAM
			and furnace.lock_beam and furnace.thermal_breach
			and furnace.breach_per_hit > 0.1,
			"FURNACE-A lock beam + thermal breach")
	var munin := WeaponData.for_item("MUNINN-A")
	_assert(munin != null and munin.chain_bounces == 3
			and munin.chain_range >= 50.0, "MUNINN-A bouncing stream (3 hops)")
	var striker := WeaponData.for_item("STRIKER-A")
	_assert(striker != null and striker.kind == WeaponData.Kind.MAGNETIC
			and striker.magazine == 8, "STRIKER-A charge mag 8")
	var anguisher := WeaponData.for_item("ANGUISHER-A")
	_assert(anguisher != null and anguisher.kind == WeaponData.Kind.CORROSION
			and anguisher.pellets == 12 and anguisher.corrosion_dps >= 900.0,
			"ANGUISHER-A acid titan shotgun")
	var chasm := WeaponData.for_item("CHASM-B")
	_assert(chasm != null and chasm.family == "CHASM"
			and chasm.item_id == "CHASM-B", "CHASM-B beta void gun alias")
	var maha := WeaponData.for_item("MAHA-VAJRA-B")
	_assert(maha != null and maha.family == "MAHA-VAJRA"
			and maha.pellets == 8, "MAHA-VAJRA-B family parse")
	var rime := WeaponData.for_item("RIME-L")
	_assert(rime != null and rime.family == "RIME"
			and rime.slow_factor < 1.0 and rime.splash_radius > 0.0,
			"RIME-L freeze rocket splash + slow")
	_assert(GameState.item_slot_size("TOXIN-L") == GameState.SlotSize.LIGHT,
			"item_slot_size strips TOXIN-L to LIGHT")
	_assert(GameState.item_slot_size("CRYO-M") == GameState.SlotSize.MEDIUM,
			"item_slot_size maps CRYO-M to MEDIUM")
	_assert(GameState.item_family("MAHA-VAJRA-B") == "MAHA-VAJRA",
			"item_family strips titan size token")
	_assert(GameState.item_class_label("IARAGHI-L").contains("Energy Burst"),
			"class label covers new families (%s)" % GameState.item_class_label("IARAGHI-L"))
	_assert(GameState.item_class_label("ATOMIZER-M").contains("Energy MG")
			and GameState.item_class_label("VENOM-M").contains("Corrosive"),
			"class label covers renamed Ultimate families")
	# v0.39 removed the invented sizes / cosmetic variants: none may survive.
	for removed_id in GameState.REMOVED_ITEM_IDS.keys():
		_assert(not GameState.ALL_ITEM_IDS.has(String(removed_id))
				and not GameState.TITAN_ITEM_IDS.has(String(removed_id)),
				"removed catalog id %s is gone" % String(removed_id))
	# WR 12.3/12.4 legendary pilots + specialist drones
	var nadir: Dictionary = GameState.pilot_def("nadir")
	_assert(nadir.size() > 0 and nadir.get("sig_robot", "") == GameState.ROBOT_SCARAB
			and not String(nadir.get("unique", "")).is_empty(),
			"nadir Rakhim signs with SCARAB + unique skill")
	var toshiro: Dictionary = GameState.pilot_def("toshiro")
	_assert(toshiro.size() > 0
			and toshiro.get("sig_robot", "") == GameState.ROBOT_CITADEL,
			"toshiro signs with CITADEL")
	var cliff: Dictionary = GameState.pilot_def("cliff")
	_assert(cliff.size() > 0
			and cliff.get("sig_robot", "") == GameState.ROBOT_RAVAGER,
			"cliff signs with RAVAGER")
	_assert(GameState.pilot_def("donnie").size() > 0
			and GameState.pilot_def("andor").size() > 0,
			"donnie + andor pilot defs present")
	var scourveil: Dictionary = GameState.drone_def("scourveil")
	_assert(scourveil.size() > 0 and scourveil.get("effect", "") == "speed"
			and scourveil.get("sig_robot", "") == GameState.ROBOT_SCARAB,
			"scourveil speed drone for SCARAB")
	var prena: Dictionary = GameState.drone_def("prena")
	_assert(prena.size() > 0 and prena.get("effect", "") == "damage"
			and float(prena.get("per_level", 0.0)) >= 0.012,
			"prena damage drone")
	_assert(GameState.owns_drone("scourveil") and GameState.owns_drone("prena"),
			"v35 migration grants both specialist drones")
	_assert(GameState.drone_level("scourveil") >= 1
			and GameState.drone_level("prena") >= 1,
			"specialist drones carry a level")
	var grey_health := Health.new()
	grey_health.max_health = 1000.0
	grey_health.current = 1000.0
	grey_health.apply_damage(200.0, Vector3.ZERO, 1.0)
	_assert(grey_health.current == 800.0 and grey_health.hull >= 200.0,
			"sonic hit applies as full grey damage (cur %.0f hull %.0f)"
			% [grey_health.current, grey_health.hull])
	grey_health.heal(500.0)
	_assert(grey_health.current == 800.0,
			"grey damage never repairs (cur %.0f)" % grey_health.current)
	grey_health.free()
	_assert(GameState.damage_mult_for(1, 12) <= GameState.damage_mult_for(2, 1),
			"damage no drop at MK1->MK2 (%.3f <= %.3f)" % [GameState.damage_mult_for(1, 12), GameState.damage_mult_for(2, 1)])
	_assert(GameState.damage_mult_for(2, 12) <= GameState.damage_mult_for(3, 1),
			"damage no drop at MK2->MK3 (%.3f <= %.3f)" % [GameState.damage_mult_for(2, 12), GameState.damage_mult_for(3, 1)])
	_assert(GameState.performance_mult_for(1, 12) <= GameState.performance_mult_for(2, 1),
			"performance no drop at MK1->MK2")
	_assert(is_equal_approx(GameState.damage_mult_for(3, 12), 2.48), "MK3 lv12 damage 2.48x (%.2f)" % GameState.damage_mult_for(3, 12))
	for item_id in GameState.ALL_ITEM_IDS:
		_assert(GameState.pool_count(item_id) >= 1, "inventory holds %s (%d)" % [item_id, GameState.pool_count(item_id)])
	var key := GameState.upgrade_key(GameState.ROBOT_SCARAB, 0)
	GameState.upgrades[key] = Vector2i(1, 1)
	GameState.silver = 1000000
	GameState.gold = 1000
	GameState.spare_parts = 100000
	var cost := GameState.upgrade_cost(key)
	_assert(not bool(cost["maxed"]) and int(cost["silver"]) > 0 and int(cost["gold"]) == 0,
			"MK1 upgrade costs silver (%s)" % str(cost))
	_assert(int(cost["parts"]) > 0, "MK1 upgrade costs spare parts (%d)" % int(cost["parts"]))
	var before := GameState.silver
	_assert(GameState.perform_upgrade(key), "perform MK1 lv1 -> lv2")
	_assert(GameState.upgrade_state(key) == Vector2i(1, 2), "upgrade state advanced (%s)" % str(GameState.upgrade_state(key)))
	_assert(GameState.silver < before, "silver deducted")
	GameState.upgrades[key] = Vector2i(1, 12)
	cost = GameState.upgrade_cost(key)
	_assert(int(cost["gold"]) > 0 and int(cost["silver"]) == 0, "lv12 upgrade costs gold")
	_assert(GameState.perform_upgrade(key), "perform MK1 lv12 -> MK2 lv1")
	_assert(GameState.upgrade_state(key) == Vector2i(2, 1), "MK transition reset level (%s)" % str(GameState.upgrade_state(key)))
	GameState.upgrades[key] = Vector2i(3, 12)
	_assert(bool(GameState.upgrade_cost(key)["maxed"]), "MK3 lv12 is maxed")
	_assert(not GameState.perform_upgrade(key), "maxed upgrade refuses purchase")
	_assert(GameState.body_mult(GameState.ROBOT_SCARAB) >= 1.0, "body armor multiplier >= 1")
	_assert(GameState.durability_mult_for(1, 12) <= GameState.durability_mult_for(2, 1),
			"durability no drop at MK1->MK2 (%.3f <= %.3f)" % [GameState.durability_mult_for(1, 12), GameState.durability_mult_for(2, 1)])
	_assert(GameState.durability_mult_for(2, 12) <= GameState.durability_mult_for(3, 1),
			"durability no drop at MK2->MK3 (%.3f <= %.3f)" % [GameState.durability_mult_for(2, 12), GameState.durability_mult_for(3, 1)])
	_assert(is_equal_approx(GameState.durability_mult_for(3, 12), 2.84),
			"MK3 lv12 durability 2.84x (%.2f)" % GameState.durability_mult_for(3, 12))
	_assert(is_equal_approx(GameState.durability_mult_for(1, 1), 1.0), "MK1 lv1 durability 1.0x")
	_assert(GameState.item_damage_mult(GameState.ROBOT_VORTEX, 3) >= 1.0, "vortex slot damage mult >= 1")
	# --- War Robots titan ladders: hull lv1-150, titan weapons lv1-25 ---
	var hull_key := GameState.body_upgrade_key(GameState.ROBOT_PRAETOR)
	var titan_weapon_key := GameState.upgrade_key(GameState.ROBOT_PRAETOR, 0)
	_assert(GameState.upgrade_class(hull_key) == GameState.UpgradeClass.TITAN_HULL,
			"titan hull rides the 1-150 ladder (%d)" % GameState.upgrade_class(hull_key))
	_assert(GameState.upgrade_level_cap(hull_key) == GameState.LV_MAX_TITAN,
			"titan hull cap is 150 (%d)" % GameState.upgrade_level_cap(hull_key))
	_assert(GameState.upgrade_class(titan_weapon_key) == GameState.UpgradeClass.TITAN_WEAPON,
			"titan weapon rides the 1-25 ladder (%d)" % GameState.upgrade_class(titan_weapon_key))
	_assert(GameState.upgrade_level_cap(titan_weapon_key) == GameState.LV_MAX_TITAN_WEAPON,
			"titan weapon cap is 25 (%d)" % GameState.upgrade_level_cap(titan_weapon_key))
	_assert(GameState.upgrade_class(key) == GameState.UpgradeClass.STANDARD
			and GameState.upgrade_level_cap(key) == GameState.LV_MAX,
			"normal weapon keeps MK1-3 x lv1-12")
	_assert(GameState.upgrade_mk_cap(key) == GameState.MK_MAX
			and GameState.upgrade_mk_cap(hull_key) == 1,
			"only normal ladders carry MK marks")
	var saved_platinum := GameState.platinum
	GameState.platinum = 100000
	GameState.upgrades[hull_key] = Vector2i(1, 1)
	var hull_cost := GameState.upgrade_cost(hull_key)
	_assert(not bool(hull_cost["maxed"]) and int(hull_cost["platinum"]) > 0
			and int(hull_cost["silver"]) == 0,
			"titan hull upgrade costs platinum (%s)" % str(hull_cost))
	_assert(GameState.perform_upgrade(hull_key), "titan hull lv1 -> lv2")
	_assert(GameState.upgrade_state(hull_key) == Vector2i(1, 2),
			"titan hull advances (%s)" % str(GameState.upgrade_state(hull_key)))
	_assert(GameState.platinum < 100000, "platinum deducted (%d)" % GameState.platinum)
	_assert(is_equal_approx(GameState.titan_durability_mult_for(1), 1.0),
			"titan hull lv1 durability 1.0x")
	_assert(GameState.titan_durability_mult_for(150) > 1.5,
			"titan hull lv150 durability > 1.5x (%.3f)"
			% GameState.titan_durability_mult_for(150))
	GameState.upgrades[hull_key] = Vector2i(1, 150)
	_assert(bool(GameState.upgrade_cost(hull_key)["maxed"]), "titan hull lv150 maxed")
	_assert(not GameState.perform_upgrade(hull_key), "maxed titan hull refuses purchase")
	GameState.upgrades[titan_weapon_key] = Vector2i(1, 1)
	var titan_weapon_cost := GameState.upgrade_cost(titan_weapon_key)
	_assert(int(titan_weapon_cost["platinum"]) > 0 and int(titan_weapon_cost["silver"]) == 0,
			"titan weapon upgrade costs platinum (%s)" % str(titan_weapon_cost))
	_assert(GameState.perform_upgrade(titan_weapon_key), "titan weapon lv1 -> lv2")
	_assert(GameState.upgrade_state(titan_weapon_key) == Vector2i(1, 2),
			"titan weapon advances (%s)" % str(GameState.upgrade_state(titan_weapon_key)))
	_assert(GameState.titan_damage_mult_for(25) > 1.4,
			"titan weapon lv25 damage > 1.4x (%.3f)" % GameState.titan_damage_mult_for(25))
	GameState.upgrades[titan_weapon_key] = Vector2i(1, 25)
	_assert(bool(GameState.upgrade_cost(titan_weapon_key)["maxed"]),
			"titan weapon lv25 maxed")
	_assert(not GameState.perform_upgrade(titan_weapon_key),
			"maxed titan weapon refuses purchase")
	GameState.platinum = saved_platinum
	GameState.upgrades = saved_upgrades
	GameState.silver = saved_silver
	GameState.gold = saved_gold
	GameState.spare_parts = saved_parts
	GameState.save_settings()


func _check_pilot_api() -> void:
	var saved_assign: Dictionary = GameState.pilot_assignments.duplicate(true)
	var saved_pilots: Dictionary = GameState.pilots.duplicate(true)
	var saved_silver := GameState.silver
	var saved_gold := GameState.gold
	var saved_memorium := GameState.memorium
	var saved_kills := GameState.enemies_killed
	_assert(GameState.PILOT_DEFS.size() == 15, "15 pilot defs (%d)" % GameState.PILOT_DEFS.size())
	_assert(GameState.PILOT_SKILL_NAMES.size() == 7, "7 pilot skill tracks (%d)" % GameState.PILOT_SKILL_NAMES.size())
	_assert(GameState.PILOT_SLOT_LEVELS.size() == 7, "7 skill unlock levels")
	_assert(GameState.assigned_pilot(GameState.ROBOT_SCARAB) == "vex",
			"scarab starts with vex (%s)" % GameState.assigned_pilot(GameState.ROBOT_SCARAB))
	_assert(GameState.assigned_pilot(GameState.ROBOT_VORTEX) == "orin",
			"vortex starts with orin (%s)" % GameState.assigned_pilot(GameState.ROBOT_VORTEX))
	GameState.assign_pilot(GameState.ROBOT_SCARAB, "orin")
	_assert(GameState.assigned_pilot(GameState.ROBOT_SCARAB) == "orin", "assignment moved")
	_assert(GameState.assigned_pilot(GameState.ROBOT_VORTEX) == "orin",
			"pilots can be shared (vortex keeps orin)")
	GameState.assign_pilot(GameState.ROBOT_SCARAB, "vex")
	GameState.assign_pilot(GameState.ROBOT_VORTEX, "orin")
	var vex := "vex"
	var vex_low := GameState.pilot_state(vex)
	vex_low["level"] = 1
	_assert(GameState.pilot_skill_unlocked(vex, 0), "skill 0 unlocked at lv1")
	_assert(not GameState.pilot_skill_unlocked(vex, 3), "skill 3 locked at lv1")
	var vex_state := GameState.pilot_state(vex)
	vex_state["level"] = 41
	_assert(GameState.pilot_skill_unlocked(vex, 3), "skill 3 unlocks at lv41")
	_assert(not GameState.pilot_skill_unlocked(vex, 6), "skill 6 locked below lv61")
	vex_state["level"] = 61
	_assert(GameState.pilot_skill_unlocked(vex, 6), "skill 6 unlocks at lv61")
	vex_state["level"] = 1
	vex_state["xp"] = 0
	vex_state["tier"] = 1
	vex_state["skills"] = [0, 0, 0, 0, 0, 0, 0]
	GameState.memorium = 1000000
	_assert(GameState.pilot_skill_cost(vex, 0) == 600, "skill lv1 costs 600 (%d)" % GameState.pilot_skill_cost(vex, 0))
	var memorium_before := GameState.memorium
	_assert(GameState.train_pilot_skill(vex, 0), "train skill 0")
	_assert(GameState.pilot_skill_level(vex, 0) == 1, "skill 0 reached lv1")
	_assert(GameState.memorium == memorium_before - 600,
			"training deducted 600 memorium (%d)" % GameState.memorium)
	_assert(not GameState.train_pilot_skill(vex, 3), "locked skill refuses training")
	for train_round in 9:
		GameState.memorium = 1000000
		_assert(GameState.train_pilot_skill(vex, 0), "train skill 0 round %d" % train_round)
	_assert(GameState.pilot_skill_level(vex, 0) == 10, "skill 0 maxed at 10 (%d)" % GameState.pilot_skill_level(vex, 0))
	_assert(not GameState.train_pilot_skill(vex, 0), "maxed skill refuses training")
	_assert(GameState.pilot_tier_cost(vex) == 150, "T1 to T2 costs 150 memorium (%d)" % GameState.pilot_tier_cost(vex))
	GameState.memorium = 100000
	_assert(GameState.upgrade_pilot_tier(vex), "tier upgrade T1 to T2")
	_assert(is_equal_approx(GameState.pilot_tier_mult(vex), 1.1), "T2 multiplier 1.1 (%.2f)" % GameState.pilot_tier_mult(vex))
	_assert(GameState.upgrade_pilot_tier(vex), "tier upgrade T2 to T3")
	_assert(is_equal_approx(GameState.pilot_tier_mult(vex), 1.2), "T3 multiplier 1.2 (%.2f)" % GameState.pilot_tier_mult(vex))
	_assert(GameState.pilot_tier_cost(vex) == 0, "standard pilot caps at T3")
	_assert(not GameState.upgrade_pilot_tier(vex), "max tier refuses purchase")
	_assert(GameState.pilot_max_tier("mara") == 4, "legendary pilot caps at T4")
	_assert(GameState.pilot_max_tier("rhett") == 3, "elite pilot caps at T3")
	var vex_assigned_robot := GameState.assigned_pilot(GameState.ROBOT_SCARAB)
	_assert(vex_assigned_robot == "vex", "vex reassigned to scarab")
	var effects := GameState.pilot_effects(GameState.ROBOT_SCARAB)
	_assert(effects["hp"] is float and effects["hp"] >= 1.1,
			"trained armor plating raises hp (%s)" % str(effects["hp"]))
	_assert(effects["defense"] is float and effects["defense"] <= 1.0,
			"defense never above 1 (%s)" % str(effects["defense"]))
	vex_state["level"] = 1
	vex_state["xp"] = 0
	GameState.enemies_killed = 0
	var phase_before := GameState.phase
	GameState.phase = GameState.Phase.COMBAT
	GameState.grant_pilot_match_xp()
	_assert(int(vex_state.get("level", 1)) >= 2 and int(vex_state.get("level", 1)) < 10,
			"match xp levels pilot (%d)" % int(vex_state.get("level", 1)))
	GameState.phase = phase_before
	# --- pilot hiring: silver for standard/elite, gold for legendary ---
	var saved_owned_pilots := PackedStringArray(GameState.owned_pilots)
	_assert(GameState.owns_pilot("vex"), "starter pilot owned")
	_assert(not GameState.owns_pilot("kade"), "legendary pilot unowned at start")
	_assert(GameState.pilot_buy_cost("nyx") == 25000,
			"standard pilot costs 25k silver (%d)" % GameState.pilot_buy_cost("nyx"))
	_assert(GameState.pilot_buy_cost("ilya") == 80000,
			"elite pilot costs 80k silver (%d)" % GameState.pilot_buy_cost("ilya"))
	_assert(GameState.pilot_buy_cost("kade") == 250
			and GameState.pilot_buy_currency("kade") == "gold",
			"legendary pilot costs 250 gold")
	_assert(GameState.pilot_buy_cost("vex") == 0, "owned pilot has no price")
	_assert(not GameState.assign_pilot(GameState.ROBOT_SCARAB, "kade"),
			"unowned pilot refuses assignment")
	GameState.silver = 50000
	_assert(GameState.buy_pilot("nyx"), "hire standard pilot with silver")
	_assert(GameState.silver == 25000, "silver deducted for pilot (%d)" % GameState.silver)
	_assert(GameState.assign_pilot(GameState.ROBOT_VORTEX, "nyx"),
			"owned pilot assignable")
	_assert(GameState.assigned_pilot(GameState.ROBOT_VORTEX) == "nyx",
			"nyx sits in vortex (%s)" % GameState.assigned_pilot(GameState.ROBOT_VORTEX))
	GameState.gold = 100
	_assert(not GameState.buy_pilot("kade"), "legendary hire refused without gold")
	GameState.gold = 1000
	_assert(GameState.buy_pilot("kade"), "hire legendary pilot with gold")
	_assert(GameState.gold == 750, "gold deducted for legendary (%d)" % GameState.gold)
	_assert(GameState.pilot_effects(GameState.ROBOT_VORTEX)["hp"] is float,
			"hired pilot still reports effects")
	GameState.owned_pilots = []
	for pilot_id in saved_owned_pilots:
		GameState.owned_pilots.append(String(pilot_id))
	GameState.save_settings()
	GameState.pilot_assignments = saved_assign
	GameState.pilots = saved_pilots
	GameState.silver = saved_silver
	GameState.gold = saved_gold
	GameState.memorium = saved_memorium
	GameState.enemies_killed = saved_kills
	GameState.save_settings()


func _check_drone_api() -> void:
	var saved_owned := PackedStringArray(GameState.owned_drones)
	var saved_levels: Dictionary = GameState.drone_levels.duplicate(true)
	var saved_active := GameState.selected_drone
	var saved_assignments: Dictionary = GameState.drone_assignments.duplicate(true)
	var saved_chips := GameState.microchips
	# the roster now ships every drone; strip two so buy/select flows stay testable
	GameState.owned_drones.erase("kestrel")
	GameState.owned_drones.erase("bulwark")
	_assert(GameState.DRONE_DEFS.size() == 6, "6 drone defs (%d)" % GameState.DRONE_DEFS.size())
	_assert(GameState.owns_drone("wisp"), "wisp owned by default")
	_assert(not GameState.owns_drone("kestrel"), "kestrel unowned after test strip")
	_assert(GameState.drone_level("wisp") == 1, "wisp starts at level 1 (%d)" % GameState.drone_level("wisp"))
	_assert(GameState.drone_level("kestrel") == 0, "unowned drone level 0 (%d)" % GameState.drone_level("kestrel"))
	_assert(float(GameState.drone_def("wisp").get("per_level", 0.0)) >= 0.008,
			"wisp per-level speed at least 0.8%% (%.4f)" % float(GameState.drone_def("wisp").get("per_level", 0.0)))
	_assert(float(GameState.drone_def("patch").get("per_level", 0.0)) > 0.0
			and float(GameState.drone_def("patch").get("per_level", 0.0)) <= 0.01,
			"patch repair scales with max HP (%.4f)" % float(GameState.drone_def("patch").get("per_level", 0.0)))
	GameState.microchips = 10000
	var buy_cost := GameState.drone_buy_cost("kestrel")
	_assert(buy_cost > 0, "kestrel buy cost (%d)" % buy_cost)
	_assert(GameState.buy_drone("kestrel"), "buy kestrel with microchips")
	_assert(GameState.owns_drone("kestrel"), "kestrel owned after purchase")
	_assert(GameState.microchips == 10000 - buy_cost, "chips deducted (%d)" % GameState.microchips)
	_assert(GameState.drone_buy_cost("kestrel") == 0, "owned drone has no buy cost")
	var up_cost := GameState.drone_upgrade_cost("kestrel")
	_assert(up_cost > 0, "kestrel upgrade cost (%d)" % up_cost)
	_assert(GameState.upgrade_drone("kestrel"), "upgrade kestrel to level 2")
	_assert(GameState.drone_level("kestrel") == 2, "kestrel reached level 2 (%d)" % GameState.drone_level("kestrel"))
	_assert(is_equal_approx(GameState.drone_break_mult(1), 1.0), "break mult lv1 is 1.0")
	_assert(is_equal_approx(GameState.drone_break_mult(4), 2.0), "break mult lv4 is 2.0")
	_assert(is_equal_approx(GameState.drone_break_mult(9), 3.0), "break mult lv9 is 3.0")
	_assert(GameState.select_drone("kestrel"), "select kestrel drone")
	_assert(GameState.selected_drone == "kestrel", "active drone is kestrel")
	var kestrel_fx := GameState.drone_effects()
	_assert(kestrel_fx["damage"] is float and kestrel_fx["damage"] > 1.0,
			"kestrel boosts damage (%s)" % str(kestrel_fx["damage"]))
	GameState.drone_levels["kestrel"] = 9
	_assert(GameState.drone_upgrade_cost("kestrel") == 0, "max level upgrade costs nothing")
	_assert(not GameState.upgrade_drone("kestrel"), "max level refuses upgrade")
	_assert(is_equal_approx(GameState.drone_break_mult(GameState.drone_level("kestrel")), 3.0),
			"level 9 drone uses 3x break")
	_assert(GameState.select_drone("wisp"), "select wisp drone")
	var wisp_fx := GameState.drone_effects()
	_assert(wisp_fx["speed"] is float and wisp_fx["speed"] > 1.0,
			"wisp boosts speed (%s)" % str(wisp_fx["speed"]))
	_assert(GameState.assign_drone(GameState.ROBOT_VORTEX, "kestrel"),
			"kestrel assigned to vortex only")
	_assert(GameState.drone_for_robot(GameState.ROBOT_VORTEX) == "kestrel",
			"vortex runs its own kestrel (%s)" % GameState.drone_for_robot(GameState.ROBOT_VORTEX))
	_assert(GameState.drone_for_robot(GameState.ROBOT_SCARAB) == "wisp",
			"scarab keeps wisp (%s)" % GameState.drone_for_robot(GameState.ROBOT_SCARAB))
	var vortex_drone_fx := GameState.drone_effects(GameState.ROBOT_VORTEX)
	_assert(vortex_drone_fx["damage"] is float and vortex_drone_fx["damage"] > 1.0,
			"per-robot kestrel boosts vortex damage (%s)" % str(vortex_drone_fx["damage"]))
	_assert(not GameState.select_drone("bulwark"), "cannot select unowned drone")
	var chips_before := GameState.microchips
	GameState.reward_chips(50)
	_assert(GameState.microchips == chips_before + 50, "reward chips credited (%d)" % GameState.microchips)
	_assert(GameState.match_reward_chips >= 50, "match chip rewards tracked (%d)" % GameState.match_reward_chips)
	GameState.owned_drones = []
	for drone_id in saved_owned:
		GameState.owned_drones.append(String(drone_id))
	GameState.drone_levels = saved_levels
	GameState.selected_drone = saved_active
	GameState.drone_assignments = saved_assignments
	GameState.microchips = saved_chips
	GameState.match_reward_chips = 0
	GameState.save_settings()


func _check_drone_shapes() -> void:
	var orbit_script := load("res://src/player/drone_orbit.gd") as GDScript
	_assert(orbit_script != null, "drone companion script loads")
	if orbit_script == null:
		return
	var saved_assignments: Dictionary = GameState.drone_assignments.duplicate(true)
	var saved_drone := GameState.selected_drone
	var saved_owned := PackedStringArray(GameState.owned_drones)
	var marker := {
		"wisp": "Nose", "bulwark": "Shield", "patch": "Antenna", "kestrel": "Spike",
	}
	var expected_kind := {
		"wisp": WeaponData.Kind.ELECTRIC,
		"bulwark": WeaponData.Kind.BLAST,
		"patch": WeaponData.Kind.FLAME,
		"kestrel": WeaponData.Kind.AUTOCANNON,
	}
	var expected_heal := {
		"wisp": 0.08, "bulwark": 0.12, "patch": 0.15, "kestrel": 0.08,
	}
	for kind in ["wisp", "bulwark", "patch", "kestrel"]:
		if not GameState.owns_drone(kind):
			GameState.owned_drones.append(kind)
		GameState.drone_assignments.erase(GameState.selected_robot)
		GameState.selected_drone = kind
		var orbit: Node3D = orbit_script.new() as Node3D
		add_child(orbit)
		_assert(orbit.get_node_or_null("Pod0") == null,
				"drone %s uses one body, not orbit pods" % kind)
		var body := orbit.get_node_or_null("Body") as Node3D
		_assert(body != null, "drone %s body present" % kind)
		if body != null:
			var body_meshes := body.find_children("*", "MeshInstance3D", true, false)
			_assert(body_meshes.size() >= 6,
					"drone %s shaped (%d meshes)" % [kind, body_meshes.size()])
			var eyes := body.find_children("Eye", "MeshInstance3D", true, false)
			_assert(eyes.size() == 1, "drone %s eye" % kind)
			var hits := body.find_children(marker[kind], "MeshInstance3D", true, false)
			_assert(hits.size() == 1, "drone %s has %s" % [kind, marker[kind]])
			var muzzles := body.find_children("Muzzle", "Marker3D", true, false)
			_assert(muzzles.size() == 1, "drone %s firing muzzle" % kind)
		var spawned := orbit.get("weapon") as WeaponData
		var spec := WeaponData.drone_for(kind)
		_assert(spawned != null and spec != null and spawned.family == spec.family,
				"drone %s spawns with exactly one weapon (%s)" % [
					kind, spec.family if spec != null else "?"])
		_assert(spec != null and int(expected_kind[kind]) == spec.kind,
				"drone %s weapon kind matches role" % kind)
		_assert(WeaponData.drone_fire_range(kind) > 5.0,
				"drone %s has a fire range" % kind)
		var heal_pct := float(orbit.call("heal_percent"))
		_assert(absf(heal_pct - float(expected_heal[kind])) < 0.001,
				"drone %s emergency heal is %.0f%% of max HP" % [kind, heal_pct * 100.0])
		orbit.free()
	GameState.drone_assignments = saved_assignments
	GameState.selected_drone = saved_drone
	GameState.owned_drones = []
	for drone_id in saved_owned:
		GameState.owned_drones.append(String(drone_id))


func _check_spec_api() -> void:
	var saved_specs: Dictionary = GameState.specs.duplicate(true)
	var saved_points := GameState.module_points
	_assert(GameState.SPEC_BASE.size() == 4, "4 base spec nodes (%d)" % GameState.SPEC_BASE.size())
	_assert(GameState.spec_nodes(GameState.ROBOT_SCARAB).size() == 8,
			"8 spec nodes on scarab (%d)" % GameState.spec_nodes(GameState.ROBOT_SCARAB).size())
	_assert(GameState.spec_nodes(GameState.ROBOT_VORTEX).size() == 8, "8 spec nodes on vortex")
	_assert(GameState.spec_nodes(GameState.ROBOT_RAMPART).size() == 8, "8 spec nodes on rampart")
	_assert(GameState.spec_nodes(GameState.ROBOT_PRAETOR).size() == 8, "8 spec nodes on praetor")
	_assert(GameState.spec_rank(GameState.ROBOT_SCARAB, "hull") == 0, "hull starts at rank 0")
	var cost := GameState.spec_upgrade_cost(GameState.ROBOT_SCARAB, "hull")
	_assert(cost == 4, "rank 1 costs 4 points (%d)" % cost)
	GameState.module_points = 1000
	_assert(GameState.upgrade_spec(GameState.ROBOT_SCARAB, "hull"), "upgrade hull rank 1")
	_assert(GameState.spec_rank(GameState.ROBOT_SCARAB, "hull") == 1, "hull reached rank 1")
	_assert(GameState.module_points == 1000 - 4, "module points deducted (%d)" % GameState.module_points)
	_assert(GameState.spec_upgrade_cost(GameState.ROBOT_SCARAB, "hull") == 8, "rank 2 costs 8")
	_assert(GameState.spec_rank(GameState.ROBOT_VORTEX, "hull") == 0, "spec ranks are per robot")
	if not GameState.specs.has(GameState.ROBOT_SCARAB):
		GameState.specs[GameState.ROBOT_SCARAB] = {}
	var scarab_specs := GameState.specs[GameState.ROBOT_SCARAB] as Dictionary
	scarab_specs["hull"] = GameState.SPEC_MAX_RANK
	_assert(GameState.spec_upgrade_cost(GameState.ROBOT_SCARAB, "hull") == 0, "maxed node costs nothing")
	_assert(not GameState.upgrade_spec(GameState.ROBOT_SCARAB, "hull"), "maxed node refuses upgrade")
	var effects := GameState.spec_effects(GameState.ROBOT_SCARAB)
	_assert(effects["hp"] is float and effects["hp"] >= 1.075,
			"maxed hull rank raises armor (%s)" % str(effects["hp"]))
	GameState.module_points = 0
	_assert(not GameState.upgrade_spec(GameState.ROBOT_SCARAB, "targeting"), "no points refuses upgrade")
	GameState.reward_module_points(5)
	_assert(GameState.module_points == 5, "module point reward credited (%d)" % GameState.module_points)
	GameState.specs = saved_specs
	GameState.module_points = saved_points
	GameState.save_settings()

func _player() -> PlayerRobot:
	return _game.get_node_or_null("Player") as PlayerRobot

func _check_static_structure() -> void:
	_assert(bool(ProjectSettings.get_setting("application/boot_splash/show_image", false)),
			"boot splash enabled (application/boot_splash/show_image)")
	var player := _player()
	_assert(player != null, "player node exists")
	if player == null:
		return
	_assert(player.rig != null, "robot rig attached")
	if player.rig == null:
		return
	_assert(player.rig.leg_units.size() == 4, "four legs built (got %d)" % player.rig.leg_units.size())
	_assert(player.rig.hardpoint_count() == 4, "four hardpoints (got %d)" % player.rig.hardpoint_count())
	var drone := player.get_node_or_null("DroneOrbit") as Node3D
	_assert(drone != null, "companion drone attached to robot")
	if drone != null:
		_assert(drone.get_node_or_null("Body") != null, "drone has a single body")
		_assert(drone.get_node_or_null("Pod0") == null,
				"drone has no orbit pods (one drone, not three)")
	_assert(_game.get_node_or_null("OpenRealm") != null, "arena present")
	var enemy_total := 0
	for child in _game.get_children():
		if child is EnemyRobot:
			enemy_total += 1
	_assert(enemy_total == 15, "match spawns exactly 15 enemies (got %d)" % enemy_total)
	var arena := _game.get_node_or_null("OpenRealm") as OpenRealm
	if arena != null:
		_assert(arena.enemy_spawns.size() >= 15, "enemy spawn points defined (%d)" % arena.enemy_spawns.size())
		var world_environment := arena.get_node_or_null("WorldEnvironment") as WorldEnvironment
		_assert(world_environment != null, "arena world environment present")
		if world_environment != null:
			var environment := world_environment.environment
			_assert(environment != null and environment.sky != null
					and environment.sky.sky_material is ProceduralSkyMaterial,
					"procedural sky material active")
			_assert(environment != null and environment.tonemap_mode == Environment.TONE_MAPPER_ACES,
					"ACES tonemap active")
			_assert(not environment.ssao_enabled,
					"ssao stays off (unsupported by mobile renderer)")
			_assert(environment.glow_enabled == (Quality.tier() >= Quality.Tier.MEDIUM),
					"glow follows graphics tier (%s)" % Quality.tier_label())
			_assert(environment.adjustment_enabled,
					"colour grading active (%s)" % Quality.tier_label())
		_assert(arena.get_node_or_null("ReflectionProbe") != null, "reflection probe present")
		var sun := arena.get_node_or_null("Sun") as DirectionalLight3D
		_assert(sun != null, "sun light present")
		if sun != null:
			_assert(sun.shadow_enabled == (Quality.tier() >= Quality.Tier.MEDIUM),
					"sun shadows follow graphics tier (%s)" % Quality.tier_label())
			_assert(sun.light_energy >= 2.8, "midday sun energy (%.1f)" % sun.light_energy)
			_assert(sun.rotation_degrees.x <= -50.0, "midday sun high in sky (%.0f deg)" % sun.rotation_degrees.x)
		if world_environment != null and world_environment.environment != null:
			_assert(world_environment.environment.ambient_light_energy >= 1.2,
					"bright ambient (%.2f)" % world_environment.environment.ambient_light_energy)
			_assert(world_environment.environment.sky.sky_material.sky_energy_multiplier >= 1.2,
					"sky energy multiplier (%.2f)" % world_environment.environment.sky.sky_material.sky_energy_multiplier)
		var nature := _game.get_node_or_null("Nature")
		_assert(nature != null, "nature backdrop wired")
		if nature != null:
			_assert(nature.get_node_or_null("SunDisk/SunCore") != null, "sun disk rendered in sky")
			var sun_core := nature.get_node_or_null("SunDisk/SunCore") as GeometryInstance3D
			var sun_halo := nature.get_node_or_null("SunDisk/SunHalo") as GeometryInstance3D
			_assert(sun_core != null and sun_core.cast_shadow
					== GeometryInstance3D.SHADOW_CASTING_SETTING_OFF,
					"sun disk never casts shadows")
			_assert(sun_halo != null and sun_halo.cast_shadow
					== GeometryInstance3D.SHADOW_CASTING_SETTING_OFF,
					"sun halo never casts shadows")
			var clouds := nature.find_children("Cloud_*", "Node3D", true, false)
			_assert(clouds.size() >= 12, "cloud field populated (%d)" % clouds.size())
			var cloud_shadows_off := true
			for cloud in clouds:
				var cloud_mesh := cloud as GeometryInstance3D
				if cloud_mesh == null or cloud_mesh.cast_shadow \
						!= GeometryInstance3D.SHADOW_CASTING_SETTING_OFF:
					cloud_shadows_off = false
					break
			_assert(cloud_shadows_off, "clouds never cast shadows (black shield fix)")
		_assert(_game.get_node_or_null("HudLayer/Hud/MenuButton") != null,
				"HUD MENU button present")
	_assert(_game.has_method("get_lock_target"), "lock-on target API present")
	var hub_h := OpenRealm.terrain_height(OpenRealm.HUB.x, OpenRealm.HUB.y)
	_assert(not is_nan(hub_h) and absf(hub_h - 1.2) < 0.35,
			"hub district flat at spawn (%.2f)" % hub_h)
	var lake_h := OpenRealm.terrain_height(OpenRealm.LAKE_CENTRE.x, OpenRealm.LAKE_CENTRE.y)
	_assert(not is_nan(lake_h) and lake_h < OpenRealm.WATER_LEVEL - 1.5,
			"lake basin below water line (%.2f)" % lake_h)
	var rim_h := OpenRealm.terrain_height(0.0, 215.0)
	_assert(not is_nan(rim_h) and rim_h > 25.0, "rim ridge rises (%.2f)" % rim_h)
	var edge_h := OpenRealm.terrain_height(OpenRealm.TERRAIN_EXTENT + 10.0, 0.0)
	_assert(not is_nan(edge_h) and edge_h < -4.0, "outer skirt drops (%.2f)" % edge_h)
	for leg in player.rig.leg_units:
		var position := leg.global_position
		_assert(_is_finite(position), "leg %s transform is finite" % leg.name)
		_assert(leg.get_node_or_null("Foot") != null, "leg %s claw foot built" % leg.name)
		_assert(leg.get_node_or_null("UpperBone/Knee") != null, "leg %s knee node built" % leg.name)
		var leg_body := leg.get_node_or_null("LegBody") as AnimatableBody3D
		_assert(leg_body != null, "leg %s has collision body" % leg.name)
		if leg_body != null:
			_assert(leg_body.get_node_or_null("FootShape") != null, "leg %s foot shape" % leg.name)
			_assert(leg_body.get_node_or_null("ShinShape") != null, "leg %s shin shape" % leg.name)
			_assert(leg_body.collision_layer == Layers.LEG, "leg %s on LEG layer" % leg.name)
	_assert(player.rig.get_node_or_null("Chassis") != null, "chassis node built")
	_assert(player.rig.get_node_or_null("HeadSensor") != null, "sensor head built")
	_assert(player.rig.get_node_or_null("Tail") != null, "scorpion tail built")
	for socket_index in 4:
		_assert(player.rig.get_node_or_null("WeaponHardpoint_%02d" % (socket_index + 1)) != null,
				"hardpoint socket %d exists" % (socket_index + 1))
	_assert(Layers.WORLD == 1 and Layers.PLAYER == 2 and Layers.ENEMY == 4 \
			and Layers.PROJECTILE == 8, "layer bits are unique powers of two")
	_assert(Layers.ENEMY_MASK == (Layers.WORLD | Layers.PLAYER | Layers.ENEMY),
			"enemy mask covers world, player and enemy only")
	_assert(player.ability is ShadowDash, "SCARAB ability is ShadowDash")
	_assert(player.ability != null and player.ability.max_charges == 3,
			"shadow dash keeps three charges")
	_assert(player.weapons != null and player.weapons.builtin != null,
			"builtin weapon mounted on SCARAB")
	if player.weapons != null and player.weapons.builtin != null:
		var builtin_data := player.weapons.builtin.data
		_assert(builtin_data != null and builtin_data.display_name == "STINGER LANCE",
				"SCARAB builtin is the stinger lance (%s)" % (
					builtin_data.display_name if builtin_data != null else "null"))
		_assert(player.weapons.builtin.muzzle != null, "builtin muzzle marker built")
	_assert(bool(GameState.robot_def(&"SCARAB").get("wall_climb", false)),
			"SCARAB can wall climb")
	_assert(not bool(GameState.robot_def(&"VORTEX").get("wall_climb", false)) \
			and not bool(GameState.robot_def(&"RAMPART").get("wall_climb", false)),
			"wall climb is SCARAB-only")
	_assert(String(GameState.robot_def(&"VORTEX").get("builtin", "")) == "ARC NEEDLER",
			"VORTEX builtin named ARC NEEDLER")
	_assert(String(GameState.robot_def(&"RAMPART").get("builtin", "")) == "WINDCUTTER",
			"RAMPART builtin named WINDCUTTER")
	var theme_panel := UiTheme.panel(0.5)
	_assert(theme_panel.border_width_left == 3 and theme_panel.border_width_top == 1,
			"panels carry accent left edge")
	_assert(UiTheme.button_normal(UiTheme.CYAN).corner_radius_top_left == UiTheme.CUT_LARGE,
			"buttons use cut-corner profile")
	_assert(AudioServer.get_bus_index("Music") != -1, "music bus routed at startup")
	_assert(GameState.robot_power() > 0, "robot power rating computed (%d)" % GameState.robot_power())
	_assert(GameState.pilot_level() >= 1, "pilot level computed (%d)" % GameState.pilot_level())
	var hud_root := _game.get_node_or_null("HudLayer/Hud") as Control
	_assert(hud_root != null, "hud root present")
	if hud_root != null:
		hud_root.call("_scan_radar")
		var scope := hud_root.get_node_or_null("Radar/RadarScope")
		_assert(scope != null, "combat radar scope present")
		_assert(scope != null and scope.get("player") != null,
				"radar tracks the player after scan")
		_assert(hud_root.get_node_or_null("KillFeed") != null, "kill feed present")
		# battle-ui: key chrome must fit the viewport and keep its designed gaps
		var view := hud_root.size
		var chrome: Array[String] = ["PlayerPanel", "MenuButton", "Radar",
				"TimerPanel", "StatsPanel", "KillFeed", "StatusFeed",
				"ControlHints"]
		for path in chrome:
			var rect := _hud_rect(hud_root, path)
			_assert(rect.size.x > 0.0 and rect.position.x >= -1.0
					and rect.position.y >= -1.0
					and rect.end.x <= view.x + 1.0 and rect.end.y <= view.y + 1.0,
					"HUD %s fits the viewport (%s in %s)" % [path, rect, view])
		var hud_gaps: Array = [
			["PlayerPanel", "Radar"], ["MenuButton", "TimerPanel"],
			["Radar", "TimerPanel"], ["TimerPanel", "StatsPanel"],
			["KillFeed", "StatusFeed"], ["StatusFeed", "ControlHints"],
			["KillFeed", "ControlHints"],
		]
		for pair in hud_gaps:
			var gap_a := _hud_rect(hud_root, String(pair[0]))
			var gap_b := _hud_rect(hud_root, String(pair[1]))
			_assert(not gap_a.intersects(gap_b),
					"HUD %s clears %s (%s vs %s)" % [
						pair[0], pair[1], gap_a, gap_b])
		_assert(hud_root.get_node_or_null("TimerPanel/KillsRow") != null,
				"kills row present in timer")
		_assert(hud_root.get_node_or_null("FpsCounter") != null, "fps chip present")
		var numbers := hud_root.get_node_or_null("DamageNumbers")
		_assert(numbers != null, "damage numbers layer present")
		if numbers != null and _player() != null:
			var previous_damage := GameState.damage_numbers
			GameState.damage_numbers = true
			var dcam := numbers.get_viewport().get_camera_3d()
			var dpoint: Vector3 = _player().global_position + Vector3.UP * 1.5
			if dcam != null:
				# camera may still be settling at frame 2; aim 8 m along its view
				# axis so the spawn point is never classified as behind the camera
				dpoint = dcam.global_position - dcam.global_transform.basis.z * 8.0 \
						+ Vector3.UP * 0.5
			numbers.call("clear_entries")
			numbers.call("_on_damage_applied", _game, 14.0, dpoint, Vector3.UP)
			_assert(numbers.call("entry_count") == 1,
					"damage number spawns for enemy hit (cam=%s entries=%s)" % [
						dcam != null, numbers.call("entry_count")])
			GameState.damage_numbers = previous_damage
		var feed := hud_root.get_node_or_null("KillFeed")
		if feed != null:
			feed.call("add_line", "SMOKE FEED", Color.WHITE)
			_assert(feed.get_child_count() >= 1, "kill feed renders a line")

func _hud_rect(hud: Control, path: String) -> Rect2:
	var node := hud.get_node_or_null(path) as Control
	if node == null:
		return Rect2(99999.0, 99999.0, 0.0, 0.0)
	return node.get_rect()

func _check_settled() -> void:
	var player := _player()
	_assert(player != null, "player alive after warmup")
	if player == null:
		return
	_assert(player.is_on_floor(), "player rests on ground")
	_assert(player.global_position.y < 12.0, "player did not fall through floor (y=%.2f)" % player.global_position.y)
	_assert(player.global_position.y >= 1.4, "player rests ON TOP of ground, capsule clear (y=%.2f)" % player.global_position.y)
	var camera := _game.get_node_or_null("CameraRig/SpringArm3D/Camera3D") as Camera3D
	_assert(camera != null, "camera present")
	if camera != null:
		var offset := camera.global_position - player.global_position
		_assert(offset.length() > 3.0, "camera sits behind player (dist=%.2f)" % offset.length())
	for index in player.rig.hardpoint_count():
		var muzzle := player.rig.muzzle_world_position(index)
		_assert(_is_finite(muzzle), "muzzle %d world position is finite" % index)

func _check_movement() -> void:
	var player := _player()
	if player == null:
		return
	var travelled := player.global_position.distance_to(_start_position)
	_assert(travelled > 2.0, "player travelled while input held (%.2f m)" % travelled)
	_assert(player.is_on_floor(), "player still grounded after running")
	_assert(absf(player.speed_ratio) > 0.05, "speed ratio responds (%.2f)" % player.speed_ratio)

func _weapon_system() -> WeaponSystem:
	var player := _player()
	if player == null:
		return null
	return player.weapons

func _check_weapons_wired() -> void:
	var player := _player()
	var system := _weapon_system()
	_assert(system != null, "weapon system bound to player")
	if system == null:
		return
	_assert(system.rig != null, "weapon system references rig")
	_assert(system.mounts.size() == 4, "four weapon mounts (got %d)" % system.mounts.size())
	if system.mounts.size() < 4:
		return
	_assert(system.mounts[0].data != null and system.mounts[0].data.kind == WeaponData.Kind.AUTOCANNON,
			"mount 0 is autocannon")
	_assert(system.mounts[2].data != null and system.mounts[2].data.kind == WeaponData.Kind.SCATTERGUN,
			"mount 2 is scattergun")
	_assert(system.mounts[1].data.pellets == 1, "autocannon single projectile")
	_assert(system.mounts[2].data.pellets > 1, "scattergun multi pellet")
	for index in system.mounts.size():
		_assert(system.mounts[index].muzzle != null, "mount %d muzzle exists" % index)
		_assert(system.mounts[index].heat_ratio() == 0.0, "mount %d starts cold" % index)
	_assert(Projectiles.active_player_count() == 0, "no projectiles before firing")

func _check_firing() -> void:
	var system := _weapon_system()
	if system == null:
		return
	_assert(system.shots_fired > 0, "weapons fired shots (%d)" % system.shots_fired)
	_assert(_peak_active > 0, "projectiles flew (peak %d in flight)" % _peak_active)
	_assert(_shot_sample != Vector3.ZERO, "captured projectile origin")
	var mid_flight := _first_player_projectile_position()
	if mid_flight != Vector3.ZERO and _shot_sample != Vector3.ZERO:
		_assert(mid_flight.distance_to(_shot_sample) > 0.5,
				"projectile travelled (%.2f m)" % mid_flight.distance_to(_shot_sample))
	_heat_peak = system.total_heat()
	_assert(_heat_peak > 0.1, "heat built up while firing (%.2f)" % _heat_peak)

func _check_electric_arc() -> void:
	var volt := WeaponData.for_item("VOLT-M")
	_assert(volt != null and volt.kind == WeaponData.Kind.ELECTRIC,
			"VOLT-M resolves to electric kind")
	var player := _player()
	if volt == null or player == null:
		return
	var exclude: Array[RID] = []
	if player is CollisionObject3D:
		exclude.append((player as CollisionObject3D).get_rid())
	var origin := player.global_position + Vector3.UP * 3.0
	var direction := -player.global_basis.z + Vector3.UP * 0.2
	var fired := Projectiles.fire(origin, direction, volt, exclude)
	_assert(fired, "electric projectile launched")
	if not fired:
		return
	var electric: Projectile = null
	for child in Projectiles.get_children():
		if child is Projectile and (child as Projectile).is_active() \
				and (child as Projectile).weapon_kind() == WeaponData.Kind.ELECTRIC:
			electric = child
			break
	_assert(electric != null, "active electric projectile found in pool")
	if electric == null:
		return
	var arc_count := 0
	for part in electric.get_children():
		if String(part.name) != "tracer":
			arc_count += 1
	_assert(arc_count == 6, "electric arc segments built (%d)" % arc_count)

# War Robots lightning parity: the arc curve, the ~8 s unload rhythm, the
# 600 m VOLT range, and the chain shock that leaps to nearby enemies at
# half power per hop — and only from an enemy hull, never from the player.
func _check_electric_parity() -> void:
	var volt := WeaponData.for_item("VOLT-M")
	if volt == null:
		_assert(false, "VOLT-M resolves for parity checks")
		return
	_assert(is_equal_approx(WeaponData.arc_distance_mult(40.0), 2.37),
			"arc curve clamps close range at +137% (%.2f)" % WeaponData.arc_distance_mult(40.0))
	_assert(is_equal_approx(WeaponData.arc_distance_mult(200.0), 1.71),
			"arc curve at 200 m is +71%")
	_assert(is_equal_approx(WeaponData.arc_distance_mult(400.0), 1.0),
			"arc curve baseline at 400 m")
	_assert(is_equal_approx(WeaponData.arc_distance_mult(600.0), 0.23),
			"arc curve at 600 m is -77%")
	_assert(is_equal_approx(WeaponData.arc_distance_mult(900.0), 0.23),
			"arc curve clamps beyond 600 m")
	var monotonic := true
	var prev_mult := WeaponData.arc_distance_mult(0.0)
	for step in range(1, 121):
		var next_mult := WeaponData.arc_distance_mult(float(step) * 5.0)
		if next_mult > prev_mult + 0.0001:
			monotonic = false
		prev_mult = next_mult
	_assert(monotonic, "arc damage never rises with distance")
	for id in ["VOLT-L", "VOLT-M", "VOLT-H"]:
		var w := WeaponData.for_item(id)
		if w == null:
			_assert(false, "%s resolves" % id)
			continue
		var reach := w.projectile_speed * w.projectile_lifetime
		_assert(absf(reach - 600.0) < 2.0, "%s reaches ~600 m (%.0f)" % [id, reach])
		var net := w.heat_per_shot * w.shots_per_minute / 60.0 - w.cooldown_rate
		_assert(net > 0.08 and net < 0.16,
				"%s unloads ~8 s before overheat (%.3f heat/s)" % [id, net])
	_assert(volt.chain_bounces == 2 and volt.chain_range == 50.0,
			"VOLT chains 2 hops within 50 m (%d / %.0f m)" % [
				volt.chain_bounces, volt.chain_range])
	var lance := WeaponData.for_item("ARCLANCE-B")
	_assert(lance != null and lance.chain_bounces == 3 and lance.chain_range == 50.0,
			"ARCLANCE chains 3 hops within 50 m")
	if lance != null:
		var lance_net: float = lance.heat_per_shot * lance.shots_per_minute / 60.0 \
				- lance.cooldown_rate
		_assert(lance_net > 0.08 and lance_net < 0.16,
				"ARCLANCE unloads ~8 s before overheat (%.3f heat/s)" % lance_net)
	var needler := WeaponData.builtin_for_robot(&"VORTEX")
	_assert(needler != null and needler.chain_bounces == 2,
			"ARC NEEDLER chains 2 hops")
	var razor := WeaponData.for_item("RAZOR-M")
	_assert(razor != null and razor.chain_bounces == 0,
			"kinetic rounds never chain")
	# In-flight curve: damage is scaled by distance travelled since the muzzle.
	# (Needs to live in the tree — global_position does not stick otherwise.)
	var probe := Projectile.new()
	probe._data = volt
	Projectiles.add_child(probe)
	probe._launch_origin = Vector3.ZERO
	probe.global_position = Vector3(0.0, 0.0, -400.0)
	_assert(is_equal_approx(probe.weapon_damage(), volt.damage),
			"electric round fires baseline damage at 400 m (%.0f)" % probe.weapon_damage())
	probe.global_position = Vector3(0.0, 0.0, -50.0)
	_assert(is_equal_approx(probe.weapon_damage(), volt.damage * 2.37),
			"electric round doubles up close (%.0f vs %.0f)" % [
				probe.weapon_damage(), volt.damage * 2.37])
	probe.global_position = Vector3(0.0, 0.0, -900.0)
	_assert(is_equal_approx(probe.weapon_damage(), volt.damage * 0.23),
			"electric round fades at long range (%.0f)" % probe.weapon_damage())
	probe._data = razor
	probe.global_position = Vector3(0.0, 0.0, -50.0)
	_assert(is_equal_approx(probe.weapon_damage(), razor.damage),
			"non-electric rounds never scale with range")
	probe.queue_free()
	# Functional chain: struck enemy arcs to its neighbour at half power,
	# the enemy beyond 50 m is out of range, and the player hull never chains.
	var player := _player()
	if player == null:
		return
	var exclude: Array[RID] = []
	if player is CollisionObject3D:
		exclude.append((player as CollisionObject3D).get_rid())
	var forward := -player.global_basis.z
	forward.y = 0.0
	if forward.length_squared() < 0.01:
		forward = Vector3.FORWARD
	forward = forward.normalized()
	var right := forward.cross(Vector3.UP).normalized()
	var dirs: Array[Vector3] = [forward, -forward, right, -right]
	var chain_dir := Vector3.ZERO
	for d in dirs:
		var a_probe := player.global_position + d * 8.0 + Vector3.UP * 1.5
		var b_probe := player.global_position + d * 23.0 + Vector3.UP * 1.5
		var c_probe := player.global_position + d * 70.0 + Vector3.UP * 1.5
		if _los_clear(a_probe, b_probe + Vector3.UP) \
				and _los_clear(a_probe, c_probe + Vector3.UP):
			chain_dir = d
			break
	_assert(chain_dir != Vector3.ZERO, "chain staging found a clear line of fire")
	if chain_dir == Vector3.ZERO:
		return
	var pos_a := player.global_position + chain_dir * 8.0 + Vector3.UP * 1.5
	var pos_b := player.global_position + chain_dir * 23.0 + Vector3.UP * 1.5
	var pos_c := player.global_position + chain_dir * 70.0 + Vector3.UP * 1.5
	var staged: Array[EnemyRobot] = []
	var spots: Array[Vector3] = [pos_a, pos_b, pos_c]
	for pos in spots:
		var bot := EnemyRobot.new()
		bot.ai_enabled = false
		_game.add_child(bot)
		bot.global_position = pos
		bot.setup(player)
		staged.append(bot)
	var fired := Projectiles.fire(player.global_position + Vector3.UP * 3.0,
			chain_dir, volt, exclude)
	_assert(fired, "chain test round launched")
	var chain_probe: Projectile = null
	for child in Projectiles.get_children():
		if child is Projectile and (child as Projectile).is_active() \
				and (child as Projectile).weapon_kind() == WeaponData.Kind.ELECTRIC:
			chain_probe = child
			break
	if chain_probe == null:
		_assert(false, "chain test projectile found in pool")
		for bot in staged:
			bot.queue_free()
		return
	# Isolate the chain: pull the live roster out of the group for this
	# synchronous block so a stray enemy within 50 m can not steal a hop.
	var pulled: Array[Node] = []
	for node in _game.get_tree().get_nodes_in_group("enemy"):
		if not staged.has(node):
			node.remove_from_group("enemy")
			pulled.append(node)
	chain_probe.hit_collider = staged[0]
	chain_probe.hit_point = pos_a
	chain_probe.global_position = pos_a
	var launch_dist: float = chain_probe._launch_origin.distance_to(chain_probe.global_position)
	var expected: float = volt.damage * WeaponData.arc_distance_mult(launch_dist)
	var hp_b: float = staged[1].health.current
	var hp_c: float = staged[2].health.current
	Projectiles._apply_chain(chain_probe)
	var loss_b: float = hp_b - staged[1].health.current
	var loss_c: float = hp_c - staged[2].health.current
	_assert(loss_b > 0.0, "chain shock leaps to the nearby enemy (%.0f)" % loss_b)
	_assert(absf(loss_b - expected * 0.5) <= expected * 0.05 + 1.0,
			"first hop deals half power (%.0f vs %.0f)" % [loss_b, expected * 0.5])
	_assert(is_zero_approx(loss_c),
			"enemy beyond 50 m stays out of the chain (%.0f)" % loss_c)
	var hp_b2: float = staged[1].health.current
	chain_probe.hit_collider = player
	Projectiles._apply_chain(chain_probe)
	_assert(is_zero_approx(hp_b2 - staged[1].health.current),
			"chain never starts from the player hull")
	for child in Projectiles.get_children():
		if child is Projectile and (child as Projectile).is_active() \
				and (child as Projectile).weapon_kind() == WeaponData.Kind.ELECTRIC:
			(child as Projectile).deactivate()
	for node in pulled:
		if is_instance_valid(node):
			node.add_to_group("enemy")
	for bot in staged:
		bot.queue_free()

func _los_clear(from: Vector3, to: Vector3) -> bool:
	var world := _game.get_world_3d()
	if world == null:
		return false
	var query := PhysicsRayQueryParameters3D.new()
	query.collision_mask = Layers.WORLD
	query.collide_with_areas = false
	query.collide_with_bodies = true
	query.from = from
	query.to = to
	return world.direct_space_state.intersect_ray(query).is_empty()

# War Robots-style LUMEN: hitscan lock-on beam, bends around cover, stacks
# Thermal Breach (damage-taken amplifier) on the target. Staged over several
# physics frames — a body added this frame is not in the broadphase yet.
var _lumen_target: EnemyRobot = null
var _lumen_wall: StaticBody3D = null
var _lumen_mount: WeaponMount = null
var _lumen_saved_data: WeaponData = null
var _lumen_saved_cooldown: float = 0.0
var _lumen_saved_ammo: int = 0
var _lumen_saved_reload: float = 0.0
var _lumen_exclude: Array[RID] = []
var _lumen_fired: bool = false
var _lumen_loss: float = -1.0

func _stage_lumen_target() -> void:
	if _lumen_target != null:
		return
	var lumen := WeaponData.for_item("LUMEN-H")
	_assert(lumen != null and lumen.kind == WeaponData.Kind.BEAM and lumen.lock_beam
			and lumen.thermal_breach and lumen.beam_range >= 120.0,
			"LUMEN-H is a lock-on thermal-breach beam (range %.0f)" % (
			lumen.beam_range if lumen != null else 0.0))
	var player := _player()
	var system := _weapon_system()
	if lumen == null or player == null or system == null or system.mounts.is_empty():
		return
	var space := player.get_world_3d().direct_space_state
	var forward := -player.global_basis.z
	forward.y = 0.0
	if forward.length_squared() < 0.01:
		forward = Vector3.FORWARD
	forward = forward.normalized()
	_lumen_exclude = [player.get_rid()]
	for child in _game.get_children():
		if child is EnemyRobot:
			_lumen_exclude.append((child as EnemyRobot).get_rid())
	var spot := player.global_position + forward * 9.0
	var staged := false
	for distance: float in [9.0, 6.0, 12.0, 15.0]:
		var candidate := player.global_position + forward * distance
		var query := PhysicsRayQueryParameters3D.create(
				player.global_position + Vector3.UP * 1.4, candidate + Vector3.UP * 0.4)
		query.collision_mask = Layers.WORLD
		query.collide_with_areas = false
		query.exclude = _lumen_exclude
		if space.intersect_ray(query).is_empty():
			spot = candidate
			staged = true
			break
	_assert(staged, "LUMEN staging spot clear ahead of player")
	if not staged:
		return
	var down := PhysicsRayQueryParameters3D.create(
			spot + Vector3.UP * 6.0, spot + Vector3.DOWN * 40.0)
	down.collision_mask = Layers.WORLD
	var floor_hit := space.intersect_ray(down)
	if floor_hit.is_empty():
		_assert(false, "ground under LUMEN staging spot")
		return
	_lumen_target = EnemyRobot.new()
	_lumen_target.ai_enabled = false
	_game.add_child(_lumen_target)
	_lumen_target.global_position = (floor_hit["position"] as Vector3) + Vector3.UP * 0.75
	_lumen_target.setup(player)
	_lumen_mount = system.mounts[0]
	_lumen_saved_data = _lumen_mount.data
	_lumen_saved_cooldown = _lumen_mount._cooldown
	_lumen_saved_ammo = _lumen_mount._ammo
	_lumen_saved_reload = _lumen_mount._reload_left
	_lumen_mount.data = lumen
	# The mount was built for a belt-fed gun (magazine 0 keeps _ammo at 0), so
	# loading WR's 60-round LUMEN magazine has to refill it — otherwise the very
	# first shot trips the empty-magazine reload gate and returns false.
	_lumen_mount._ammo = lumen.magazine
	_lumen_mount._reload_left = 0.0

func _lumen_aim() -> Vector3:
	if _lumen_target == null:
		return Vector3.ZERO
	return _lumen_target.global_position + Vector3.UP * 0.3

func _lumen_direct_hit() -> void:
	var player := _player()
	if _lumen_target == null or _lumen_mount == null or player == null:
		_assert(false, "LUMEN staging complete before direct hit")
		return
	_lumen_mount._cooldown = 0.0
	var hp0: float = _lumen_target.health.current
	var forward := -player.global_basis.z
	forward.y = 0.0
	forward = forward.normalized()
	_lumen_fired = _lumen_mount.try_fire(_lumen_exclude, forward, _lumen_aim())
	_lumen_loss = hp0 - _lumen_target.health.current
	_assert(_lumen_fired, "LUMEN beam fires at the locked hull")
	_assert(_lumen_loss >= _lumen_mount.data.damage * 0.5,
			"LUMEN hitscan damages the locked hull (%.0f)" % _lumen_loss)
	_assert(_lumen_target.breach_stacks() >= 1 and _lumen_target.breach_mult() > 1.0,
			"thermal breach stack applied (stacks=%d mult=%.2f)" % [
				_lumen_target.breach_stacks(), _lumen_target.breach_mult()])
	var beams := 0
	for child in _lumen_mount.get_children():
		if child is BeamEffect:
			beams += 1
	_assert(beams >= 1, "beam visual spawned (%d)" % beams)

func _lumen_place_wall() -> void:
	var player := _player()
	var space := _game.get_world_3d().direct_space_state
	if player == null or _lumen_target == null:
		return
	var forward := -player.global_basis.z
	forward.y = 0.0
	forward = forward.normalized()
	var mid := player.global_position + forward * 4.5
	var down := PhysicsRayQueryParameters3D.create(
			mid + Vector3.UP * 6.0, mid + Vector3.DOWN * 40.0)
	down.collision_mask = Layers.WORLD
	var ground := space.intersect_ray(down)
	_lumen_wall = StaticBody3D.new()
	_lumen_wall.name = "BeamBlocker"
	var shape := CollisionShape3D.new()
	var box := BoxShape3D.new()
	box.size = Vector3(16.0, 5.0, 0.6)
	shape.shape = box
	_lumen_wall.add_child(shape)
	_lumen_wall.collision_layer = Layers.WORLD
	var ground_y: float = (ground["position"] as Vector3).y if not ground.is_empty() \
			else player.global_position.y - 1.4
	_lumen_wall.position = Vector3(mid.x, ground_y + 2.5, mid.z)
	_lumen_wall.rotation.y = player.rotation.y
	_game.add_child(_lumen_wall)

func _lumen_curve_hit() -> void:
	var player := _player()
	var fired := false
	var loss := -1.0
	if _lumen_target != null and _lumen_mount != null and player != null:
		_lumen_mount._cooldown = 0.0
		var hp1: float = _lumen_target.health.current
		var forward := -player.global_basis.z
		forward.y = 0.0
		forward = forward.normalized()
		fired = _lumen_mount.try_fire(_lumen_exclude, forward, _lumen_aim())
		loss = hp1 - _lumen_target.health.current
	var min_loss := -1.0
	if _lumen_mount != null and _lumen_mount.data != null:
		min_loss = _lumen_mount.data.damage * 0.5
	_assert(fired and loss >= 0.0 and loss >= min_loss,
			"LUMEN beam curves around cover (fired=%s loss=%.0f)" % [fired, loss])
	if _lumen_target != null:
		_lumen_target._breach_left = 0.01
		_lumen_target._tick_status(0.1)
		_assert(_lumen_target.breach_stacks() == 0, "thermal breach decays to zero")
	if _lumen_mount != null:
		_lumen_mount.data = _lumen_saved_data
		_lumen_mount._ammo = _lumen_saved_ammo
		_lumen_mount._reload_left = _lumen_saved_reload
		_lumen_mount._cooldown = _lumen_saved_cooldown
	if _lumen_wall != null:
		_lumen_wall.queue_free()
		_lumen_wall = null
	if _lumen_target != null:
		_lumen_target.queue_free()
		_lumen_target = null

func _check_cooling() -> void:
	var system := _weapon_system()
	if system == null:
		return
	_assert(Projectiles.active_player_count() == 0, "projectiles cleared (%d)" % Projectiles.active_player_count())
	_assert(Projectiles.impact_count() > 0, "projectiles impacted (%d)" % Projectiles.impact_count())
	var player := _player()
	if player != null and _first_impact != Vector3.ZERO:
		_assert(_first_impact.distance_to(player.global_position) > 4.0,
				"impacts happened down-range (%.1f m)" % _first_impact.distance_to(player.global_position))
	_assert(system.total_heat() < _heat_peak, "heat cooling (peak %.2f now %.2f)" % [_heat_peak, system.total_heat()])
	var max_recoil := 0.0
	for mount in system.mounts:
		max_recoil = maxf(max_recoil, absf(mount.position.x))
	_assert(max_recoil < 0.05, "recoil returned to rest (%.3f)" % max_recoil)

func _force_overheat() -> void:
	var system := _weapon_system()
	if system == null:
		return
	system.mounts[0].heat = 1.0

func _check_overheat_lock() -> void:
	var system := _weapon_system()
	if system == null:
		return
	_assert(system.mounts[0].is_overheated(), "mount overheated at heat 1.0")
	var no_rids: Array[RID] = []
	_assert(not system.mounts[0].try_fire(no_rids), "overheated mount refuses to fire")

func _check_overheat_unlock() -> void:
	var system := _weapon_system()
	if system == null:
		return
	_assert(not system.mounts[0].is_overheated(), "mount cooled out of overheat (%.2f)" % system.mounts[0].heat_ratio())
	_assert(system.mounts[0].heat_ratio() <= system.mounts[0].data.overheat_lock + 0.01,
			"heat below lock threshold (%.2f)" % system.mounts[0].heat_ratio())
	InputRouter.set_virtual_fire(false)

# World-to-space bounds of every mesh under `root`, expressed in `space`.
func _node_bounds(root: Node3D, space: Node3D) -> AABB:
	var bounds := AABB()
	var found := false
	for mesh_node in root.find_children("*", "MeshInstance3D", true, false):
		var mesh_instance := mesh_node as MeshInstance3D
		if mesh_instance == null or mesh_instance.mesh == null:
			continue
		var local_box := mesh_instance.mesh.get_aabb()
		var to_space: Transform3D = space.global_transform.affine_inverse() \
				* mesh_instance.global_transform
		for corner in 8:
			var point := to_space * local_box.get_endpoint(corner)
			if not found:
				bounds = AABB(point, Vector3.ZERO)
				found = true
			else:
				bounds = bounds.expand(point)
	return bounds

func _is_finite(vector: Vector3) -> bool:
	return is_finite(vector.x) and is_finite(vector.y) and is_finite(vector.z)

func _assert(condition: bool, label: String) -> void:
	_checks += 1
	if condition:
		print("  PASS  %s" % label)
	else:
		_failures.append(label)
		print("  FAIL  %s" % label)

func _finish() -> void:
	if GameState.quality_auto != _saved_quality_auto:
		GameState.quality_auto = _saved_quality_auto
		GameState.save_settings()
	print("")
	print("SMOKE TEST: %d checks, %d failures" % [_checks, _failures.size()])
	if _failures.size() > 0:
		for failure in _failures:
			printerr("FAILED: %s" % failure)
		get_tree().quit(1)
	else:
		print("SMOKE TEST OK")
		get_tree().quit(0)

func _check_titan_swap() -> void:
	var previous := GameState.selected_robot
	GameState.selected_robot = GameState.ROBOT_PRAETOR
	var alt_game := (load("res://scenes/game.tscn") as PackedScene).instantiate() as Node3D
	add_child(alt_game)
	var alt_player := alt_game.get_node_or_null("Player") as PlayerRobot
	_assert(alt_player != null, "praetor game scene spawns player")
	if alt_player != null:
		_assert(alt_player.rig != null, "praetor rig attached")
		if alt_player.rig != null:
			_assert(alt_player.rig is TitanRig, "praetor rig class used")
			_assert(alt_player.rig.leg_units.size() == 2,
					"titan has 2 IK legs (%d)" % alt_player.rig.leg_units.size())
			_assert(alt_player.rig.get_node_or_null("Tail") == null, "titan has no tail")
			_assert(alt_player.rig.hardpoint_count() == 4,
					"titan four hardpoints (%d)" % alt_player.rig.hardpoint_count())
			var titan_chassis_meshes := 0
			var titan_head_meshes := 0
			var titan_leg_meshes := 0
			if alt_player.rig.chassis != null:
				titan_chassis_meshes = alt_player.rig.chassis.find_children(
						"chassis__*", "MeshInstance3D", false, false).size()
			if alt_player.rig.head_sensor != null:
				titan_head_meshes = alt_player.rig.head_sensor.find_children(
						"head__*", "MeshInstance3D", false, false).size()
			if alt_player.rig.leg_units.size() == 2:
				for titan_leg in alt_player.rig.leg_units:
					var leg_pattern := "l%d*" % alt_player.rig.leg_units.find(titan_leg)
					titan_leg_meshes += titan_leg.find_children(
							leg_pattern, "MeshInstance3D", true, false).size()
			_assert(titan_chassis_meshes >= 4,
					"titan princeps GLB chassis (%d)" % titan_chassis_meshes)
			_assert(titan_head_meshes >= 4,
					"titan princeps GLB head (%d)" % titan_head_meshes)
			_assert(titan_leg_meshes >= 10,
					"titan princeps GLB legs (%d)" % titan_leg_meshes)
			var titan_bounds := _node_bounds(alt_player.rig, alt_player.rig)
			_assert(titan_bounds.size.x > 4.0 and titan_bounds.size.y > 4.0,
					"titan hull is titan-scale (w %.1fm h %.1fm)" % [
						titan_bounds.size.x, titan_bounds.size.y])
		var alt_system := alt_player.get_node_or_null("WeaponSystem") as WeaponSystem
		if alt_system == null and alt_player.weapons != null:
			alt_system = alt_player.weapons
		_assert(alt_system != null and alt_system.mounts.size() == 4,
				"titan weapon mounts wired")
		if alt_system != null and alt_system.mounts.size() == 4:
			_assert(alt_system.builtin == null, "titan has no builtin weapon")
			_assert(alt_system.mounts[0].data != null
					and alt_system.mounts[0].data.family == "JUGGERNAUT",
					"titan slot0 is JUGGERNAUT (%s)" % (
						alt_system.mounts[0].data.family if alt_system.mounts[0].data != null else "null"))
			_assert(alt_system.mounts[2].data != null
					and alt_system.mounts[2].data.family == "HAVOC",
					"titan slot2 is HAVOC (%s)" % (
						alt_system.mounts[2].data.family if alt_system.mounts[2].data != null else "null"))
			var aim_ok := true
			for alt_mount in alt_system.mounts:
				var alt_socket := alt_mount.get_parent() as Node3D
				if alt_socket == null or alt_mount.muzzle == null:
					aim_ok = false
					continue
				var aim := alt_mount.muzzle.global_position - alt_socket.global_position
				var aim_local := alt_player.global_basis.inverse() * aim
				if aim_local.length() < 0.5 \
						or aim_local.normalized().dot(Vector3.FORWARD) < 0.99:
					aim_ok = false
			_assert(aim_ok, "titan mounts aim forward")
		_assert(alt_player.health != null and int(alt_player.health.max_health) == 700000,
				"titan armor 700K (got %s)" % (
					str(alt_player.health.max_health) if alt_player.health != null else "null"))
		var shape_node := alt_player.get_node_or_null("BodyCollision") as CollisionShape3D
		var capsule: CapsuleShape3D = null
		if shape_node != null:
			capsule = shape_node.shape as CapsuleShape3D
		_assert(capsule != null and absf(capsule.radius - 1.85 * TitanRig.BULK) < 0.02,
				"titan capsule radius scaled by BULK (%s)" % str(
					capsule.radius if capsule != null else -1.0))
		_assert(capsule != null and absf(capsule.height - 4.5 * TitanRig.BULK) < 0.02,
				"titan capsule height scaled by BULK (%s)" % str(
					capsule.height if capsule != null else -1.0))
		_assert(alt_player.ability is NullfieldAbility, "titan primary ability is Nullfield")
		_assert(alt_player.ability2 is GravThrustAbility, "titan secondary ability is GravThrust")
		_assert(InputMap.has_action("secondary_ability"),
				"secondary ability input action defined")
		if alt_player.ability != null:
			var nullfield := alt_player.ability as NullfieldAbility
			_assert(nullfield != null
					and nullfield.max_charges == 1
					and nullfield.barrier_duration == 10.0
					and nullfield.barrier_hits == 6,
					"nullfield matches Princeps tuning (1 charge / 10 s / 6 hits)")
			alt_player.ability.activate()
			_assert(alt_player.ability.charges == 0,
					"nullfield spends its charge (%d)" % alt_player.ability.charges)
			_assert(alt_player.ability.phase_name == "BARRIER",
					"nullfield reports BARRIER (%s)" % alt_player.ability.phase_name)
			if nullfield != null and alt_player.health != null:
				var hull_before := alt_player.health.current
				alt_player.health.apply_damage(250000.0, Vector3.ZERO)
				_assert(alt_player.health.current == hull_before,
						"nullfield soaks damage even at full hull (%.0f->%.0f)" % [
							hull_before, alt_player.health.current])
				_assert(alt_player.health.shield_max > 0.0,
						"nullfield raises its stasis pool")
			alt_player.ability.force_end()
			if alt_player.health != null:
				_assert(alt_player.health.shield_max == 0.0,
						"nullfield drops the pool after Quantum Lock ends")
		if alt_player.ability2 != null:
			var grav := alt_player.ability2 as GravThrustAbility
			_assert(grav != null and grav.max_charges == 2
					and is_equal_approx(grav.cast_delay, 0.5)
					and is_equal_approx(grav.slow_duration, 5.0),
					"grav thrust matches Princeps tuning (2 charges / 0.5 s / 5 s slow)")
			alt_player.ability2.activate()
			_assert(alt_player.ability2.charges == 1,
					"grav thrust spends a charge (%d)" % alt_player.ability2.charges)
	alt_game.free()
	GameState.selected_robot = previous

func _check_new_titans() -> void:
	# CITADEL and RAVAGER: defs/loadouts/ownership first (no scene), then one
	# spawned game scene each for rig, GLB, mounts, armor and dual abilities.
	var citadel_slots := GameState.robot_slots(GameState.ROBOT_CITADEL)
	_assert(citadel_slots.size() == 3,
			"citadel has 3 titan slots (%d)" % citadel_slots.size())
	_assert(GameState.is_titan(GameState.ROBOT_CITADEL), "citadel flagged titan")
	_assert(GameState.robot_buy_cost(GameState.ROBOT_CITADEL) == 3000
			and GameState.robot_buy_currency(GameState.ROBOT_CITADEL) == "plat",
			"citadel costs 3000 platinum")
	var ravager_slots := GameState.robot_slots(GameState.ROBOT_RAVAGER)
	_assert(ravager_slots.size() == 3,
			"ravager has 3 titan slots (%d)" % ravager_slots.size())
	_assert(GameState.is_titan(GameState.ROBOT_RAVAGER), "ravager flagged titan")
	_assert(GameState.robot_buy_cost(GameState.ROBOT_RAVAGER) == 2800
			and GameState.robot_buy_currency(GameState.ROBOT_RAVAGER) == "plat",
			"ravager costs 2800 platinum")
	_assert(GameState.ROBOT_ORDER.find(GameState.ROBOT_CITADEL) >= 0
			and GameState.ROBOT_ORDER.find(GameState.ROBOT_RAVAGER) >= 0,
			"both new titans ride the hangar cycle")
	var pairs: Array = [
		[GameState.ROBOT_CITADEL, citadel_slots],
		[GameState.ROBOT_RAVAGER, ravager_slots],
	]
	for pair in pairs:
		var robot_id: StringName = pair[0]
		var slots: Array = pair[1]
		var loadout := GameState.loadouts.get(robot_id, []) as Array
		_assert(loadout.size() == slots.size(),
				"%s default loadout fills every slot (%d/%d)" % [
					String(robot_id), loadout.size(), slots.size()])
		var sizes_ok := loadout.size() == slots.size()
		if sizes_ok:
			for index in loadout.size():
				if GameState.item_slot_size(String(loadout[index])) != slots[index]:
					sizes_ok = false
		_assert(sizes_ok, "%s loadout sizes match slot sizes" % String(robot_id))
	# Equip / free-copies arithmetic needs pool >= mounted on every item the new
	# chassis mount by default (guards _cover_mounted_copies after save loads).
	for item_id in ["JUGGERNAUT-A", "CELERITY-B", "DEMOLISHER-A", "HAVOC-B"]:
		_assert(GameState.pool_count(item_id) >= GameState.equipped_count(item_id),
				"%s pool covers its mounts (%d >= %d)" % [
					item_id, GameState.pool_count(item_id),
					GameState.equipped_count(item_id)])
	_check_spawned_new_titan(GameState.ROBOT_CITADEL, 500000,
			["JUGGERNAUT", "CELERITY", "CELERITY"])
	_check_spawned_new_titan(GameState.ROBOT_RAVAGER, 400000,
			["DEMOLISHER", "HAVOC", "HAVOC"])

func _check_spawned_new_titan(robot_id: StringName, armor: int, families: Array) -> void:
	var previous := GameState.selected_robot
	GameState.selected_robot = robot_id
	var alt_game := (load("res://scenes/game.tscn") as PackedScene).instantiate() as Node3D
	add_child(alt_game)
	var alt_player := alt_game.get_node_or_null("Player") as PlayerRobot
	_assert(alt_player != null, "%s game scene spawns player" % String(robot_id))
	if alt_player != null:
		_assert(alt_player.rig != null, "%s rig attached" % String(robot_id))
		if alt_player.rig != null:
			_assert(alt_player.rig is TitanRig, "%s rig class used" % String(robot_id))
			_assert(alt_player.rig.leg_units.size() == 2,
					"%s titan has 2 IK legs (%d)" % [
						String(robot_id), alt_player.rig.leg_units.size()])
			_assert(alt_player.rig.get_node_or_null("Tail") == null,
					"%s titan has no tail" % String(robot_id))
			_assert(alt_player.rig.hardpoint_count() == 4,
					"%s four hardpoints (%d)" % [
						String(robot_id), alt_player.rig.hardpoint_count()])
			var chassis_meshes := 0
			var head_meshes := 0
			var leg_meshes := 0
			if alt_player.rig.chassis != null:
				chassis_meshes = alt_player.rig.chassis.find_children(
						"chassis__*", "MeshInstance3D", false, false).size()
			if alt_player.rig.head_sensor != null:
				head_meshes = alt_player.rig.head_sensor.find_children(
						"head__*", "MeshInstance3D", false, false).size()
			if alt_player.rig.leg_units.size() == 2:
				for titan_leg in alt_player.rig.leg_units:
					var leg_pattern := "l%d*" % alt_player.rig.leg_units.find(titan_leg)
					leg_meshes += titan_leg.find_children(
							leg_pattern, "MeshInstance3D", true, false).size()
			_assert(chassis_meshes >= 4,
					"%s GLB chassis (%d)" % [String(robot_id), chassis_meshes])
			_assert(head_meshes >= 4,
					"%s GLB head (%d)" % [String(robot_id), head_meshes])
			_assert(leg_meshes >= 10,
					"%s GLB legs (%d)" % [String(robot_id), leg_meshes])
			var bounds := _node_bounds(alt_player.rig, alt_player.rig)
			_assert(bounds.size.x > 4.0 and bounds.size.y > 4.0,
					"%s hull is titan-scale (w %.1fm h %.1fm)" % [
						String(robot_id), bounds.size.x, bounds.size.y])
		var alt_system := alt_player.get_node_or_null("WeaponSystem") as WeaponSystem
		if alt_system == null and alt_player.weapons != null:
			alt_system = alt_player.weapons
		_assert(alt_system != null and alt_system.mounts.size() == 4,
				"%s weapon sockets wired (%s)" % [String(robot_id), str(
					alt_system.mounts.size() if alt_system != null else -1)])
		if alt_system != null and alt_system.mounts.size() == 4:
			_assert(alt_system.builtin == null,
					"%s has no builtin weapon" % String(robot_id))
			var mounted_families: Array = []
			for index in 4:
				var socket_mount := alt_system.mounts[index]
				mounted_families.append(
						socket_mount.data.family if socket_mount.data != null else "")
			var families_ok := mounted_families.size() == 4
			for index in families.size():
				if mounted_families[index] != families[index]:
					families_ok = false
			_assert(families_ok, "%s mounts %s" % [String(robot_id), str(mounted_families)])
			_assert(mounted_families[3] == "",
					"%s leaves the spare 4th socket empty" % String(robot_id))
			var aim_ok := true
			for armed_mount in alt_system.mounts:
				if armed_mount.data == null:
					continue
				var socket := armed_mount.get_parent() as Node3D
				if socket == null or armed_mount.muzzle == null:
					aim_ok = false
					continue
				var aim := armed_mount.muzzle.global_position - socket.global_position
				var aim_local := alt_player.global_basis.inverse() * aim
				if aim_local.length() < 0.5 \
						or aim_local.normalized().dot(Vector3.FORWARD) < 0.99:
					aim_ok = false
			_assert(aim_ok, "%s mounts aim forward" % String(robot_id))
		_assert(alt_player.health != null and int(alt_player.health.max_health) == armor,
				"%s armor %d (got %s)" % [String(robot_id), armor, str(
					alt_player.health.max_health if alt_player.health != null else "null")])
		var shape_node := alt_player.get_node_or_null("BodyCollision") as CollisionShape3D
		var capsule: CapsuleShape3D = null
		if shape_node != null:
			capsule = shape_node.shape as CapsuleShape3D
		_assert(capsule != null and absf(capsule.radius - 1.85 * TitanRig.BULK) < 0.02,
				"%s capsule radius scaled by BULK" % String(robot_id))
		_assert(capsule != null and absf(capsule.height - 4.5 * TitanRig.BULK) < 0.02,
				"%s capsule height scaled by BULK" % String(robot_id))
		_assert(InputMap.has_action("secondary_ability"),
				"secondary ability input action defined")
		match robot_id:
			GameState.ROBOT_CITADEL:
				_assert(alt_player.ability is ChallengeAbility,
						"citadel primary ability is Challenge")
				_assert(alt_player.ability2 is IronveilAbility,
						"citadel secondary ability is Ironveil")
				if alt_player.ability != null:
					_assert(alt_player.ability.charges == 1,
							"challenge starts charged (%d)" % alt_player.ability.charges)
					_assert(alt_player.ability.phase_name == "READY",
							"challenge reports READY (%s)" % alt_player.ability.phase_name)
					var challenge := alt_player.ability as ChallengeAbility
					var mark: EnemyRobot = null
					if challenge != null:
						mark = challenge._pick_target()
					if mark != null:
						challenge.activate()
						_assert(challenge.charges == 0,
								"challenge spends its charge on a target")
						_assert(challenge.phase_name == "CHALLENGE",
								"challenge reports CHALLENGE (%s)" % challenge.phase_name)
						_assert(mark.is_taunted(),
								"challenge taunts its mark")
				if alt_player.ability2 != null:
					alt_player.ability2.activate()
					_assert(alt_player.ability2.charges == 0,
							"ironveil spends a charge (%d)" % alt_player.ability2.charges)
					_assert(alt_player.ability2.phase_name == "BARRIER",
							"ironveil reports BARRIER (%s)" % alt_player.ability2.phase_name)
					var veil := alt_player.ability2 as IronveilAbility
					_assert(veil != null and veil.barrier_active,
							"ironveil barrier is up")
					if veil != null and alt_player.health != null:
						_assert(absf(alt_player.health.shield_mult - 0.1) < 0.001,
								"ironveil cuts damage taken (%.2f)" % (
									alt_player.health.shield_mult))
					alt_player.ability2.force_end()
					if veil != null and alt_player.health != null:
						_assert(not veil.barrier_active,
								"ironveil force_end drops the barrier")
						_assert(absf(alt_player.health.shield_mult - 1.0) < 0.001,
								"ironveil restores damage taken (%.2f)" % (
									alt_player.health.shield_mult))
			GameState.ROBOT_RAVAGER:
				_assert(alt_player.ability is ShroudAbility,
						"ravager primary ability is Shroud")
				_assert(alt_player.ability2 is LungeAbility,
						"ravager secondary ability is Lunge")
				var shroud_tune := alt_player.ability as ShroudAbility
				_assert(shroud_tune != null and shroud_tune.field_radius == 100.0
						and shroud_tune.duration == 8.0
						and is_equal_approx(shroud_tune.pulse_interval, 0.5)
						and shroud_tune.mark_cap == 3.0
						and shroud_tune.recharge_time <= 13.5,
						"shroud matches Dark Light tuning (100 m / 8 s / 0.5 s / x3 / 13 s)")
				var lunge_tune := alt_player.ability2 as LungeAbility
				_assert(lunge_tune != null and lunge_tune.max_charges == 2
						and lunge_tune.dash_duration == 1.0
						and lunge_tune.convert_ratio == 1.0
						and lunge_tune.dot_reduction == 0.5,
						"lunge matches Hook tuning (2 charges / 1 s / full convert / -50%)")
				if alt_player.ability != null:
					alt_player.ability.activate()
					_assert(alt_player.ability.charges == 0,
							"shroud spends its charge (%d)" % alt_player.ability.charges)
					_assert(alt_player.ability.phase_name == "SHROUD",
							"shroud reports SHROUD (%s)" % alt_player.ability.phase_name)
					var shroud := alt_player.ability as ShroudAbility
					_assert(shroud != null and shroud.field_active,
							"shroud field is up")
					alt_player.ability.force_end()
					_assert(shroud != null and not shroud.field_active,
							"shroud force_end drops the field")
				if alt_player.ability2 != null:
					_assert(alt_player.ability2.charges == 2,
							"lunge starts with 2 charges (%d)" % alt_player.ability2.charges)
					alt_player.ability2.activate()
					_assert(alt_player.ability2.charges == 1,
							"lunge spends a charge (%d)" % alt_player.ability2.charges)
					_assert(alt_player.ability2.phase_name == "DASHING",
							"lunge reports DASHING (%s)" % alt_player.ability2.phase_name)
					alt_player.ability2.force_end()
					_assert(alt_player.ability2.phase_name != "DASHING",
							"lunge force_end stops the dash")
	alt_game.free()
	GameState.selected_robot = previous

func _check_ownership_api() -> void:
	var saved_owned := PackedStringArray(GameState.owned_robots)
	var saved_robot := GameState.selected_robot
	var saved_silver := GameState.silver
	var saved_plat := GameState.platinum
	_assert(GameState.owns_robot(GameState.ROBOT_SCARAB), "scarab always owned")
	var was_owned := GameState.owns_robot(GameState.ROBOT_VORTEX)
	GameState.owned_robots.erase(GameState.ROBOT_VORTEX)
	GameState.owned_robots.erase(GameState.ROBOT_RAMPART)
	GameState.owned_robots.erase(GameState.ROBOT_PRAETOR)
	_assert(not GameState.owns_robot(GameState.ROBOT_VORTEX), "vortex strip works")
	_assert(GameState.robot_buy_cost(GameState.ROBOT_VORTEX) == 350000,
			"vortex costs 350000 (%d)" % GameState.robot_buy_cost(GameState.ROBOT_VORTEX))
	_assert(GameState.robot_buy_currency(GameState.ROBOT_VORTEX) == "silver",
			"vortex costs silver")
	_assert(GameState.robot_buy_cost(GameState.ROBOT_RAMPART) == 450000,
			"rampart costs 450000 (%d)" % GameState.robot_buy_cost(GameState.ROBOT_RAMPART))
	_assert(GameState.robot_buy_cost(GameState.ROBOT_PRAETOR) == 2500,
			"praetor costs 2500 (%d)" % GameState.robot_buy_cost(GameState.ROBOT_PRAETOR))
	_assert(GameState.robot_buy_currency(GameState.ROBOT_PRAETOR) == "plat",
			"praetor costs platinum")
	GameState.select_robot(GameState.ROBOT_VORTEX)
	_assert(GameState.selected_robot != GameState.ROBOT_VORTEX,
			"cannot select a locked robot")
	GameState.silver = 400000
	_assert(GameState.buy_robot(GameState.ROBOT_VORTEX), "buy vortex with silver")
	_assert(GameState.owns_robot(GameState.ROBOT_VORTEX), "vortex owned after purchase")
	_assert(GameState.silver == 50000,
			"vortex price deducted (silver %d)" % GameState.silver)
	GameState.select_robot(GameState.ROBOT_VORTEX)
	_assert(GameState.selected_robot == GameState.ROBOT_VORTEX,
			"owned robot selectable")
	GameState.cycle_robot()
	_assert(GameState.owns_robot(GameState.selected_robot),
			"cycle lands on an owned robot")
	if not was_owned:
		GameState.owned_robots.erase(GameState.ROBOT_VORTEX)
	var restore: Array[StringName] = []
	for id in saved_owned:
		restore.append(StringName(id))
	GameState.owned_robots = restore
	GameState.selected_robot = saved_robot
	GameState.silver = saved_silver
	GameState.platinum = saved_plat
	GameState.save_settings()

func _check_store_api() -> void:
	var saved_inv: Dictionary = GameState.inventory.duplicate(true)
	var saved_silver := GameState.silver
	var saved_plat := GameState.platinum
	_assert(GameState.weapon_buy_cost("RAZOR-L") == 25000,
			"light weapon costs 25000 (%d)" % GameState.weapon_buy_cost("RAZOR-L"))
	_assert(GameState.weapon_buy_cost("RAZOR-M") == 55000,
			"medium weapon costs 55000 (%d)" % GameState.weapon_buy_cost("RAZOR-M"))
	_assert(GameState.weapon_buy_cost("RAZOR-H") == 120000,
			"heavy weapon costs 120000 (%d)" % GameState.weapon_buy_cost("RAZOR-H"))
	_assert(GameState.weapon_buy_currency("RAZOR-H") == "silver",
			"normal weapons cost silver")
	_assert(GameState.weapon_buy_cost("JUGGERNAUT-A") == 550,
			"alpha titan weapon costs 550 (%d)" % GameState.weapon_buy_cost("JUGGERNAUT-A"))
	_assert(GameState.weapon_buy_currency("JUGGERNAUT-A") == "plat",
			"titan weapons cost platinum")
	_assert(GameState.weapon_buy_cost("HAVOC-B") == 400,
			"beta titan weapon costs 400 (%d)" % GameState.weapon_buy_cost("HAVOC-B"))
	_assert(GameState.weapon_buy_currency("CELERITY-B") == "plat",
			"beta titan weapon costs platinum")
	GameState.silver = 0
	GameState.platinum = 0
	_assert(not GameState.buy_item("RAZOR-L"), "cannot buy without silver")
	_assert(not GameState.buy_item("JUGGERNAUT-A"), "cannot buy titan weapon without platinum")
	_assert(not GameState.buy_item("NOPE-L"), "unknown item refused")
	GameState.silver = 100000
	var before := GameState.pool_count("RAZOR-M")
	_assert(GameState.buy_item("RAZOR-M"), "buy razor-m with silver")
	_assert(GameState.pool_count("RAZOR-M") == before + 1,
			"razor-m pool incremented (%d)" % GameState.pool_count("RAZOR-M"))
	_assert(GameState.silver == 45000,
			"razor-m price deducted (silver %d)" % GameState.silver)
	GameState.platinum = 600
	var titan_before := GameState.pool_count("JUGGERNAUT-A")
	_assert(GameState.buy_item("JUGGERNAUT-A"), "buy juggernaut with platinum")
	_assert(GameState.pool_count("JUGGERNAUT-A") == titan_before + 1,
			"juggernaut pool incremented (%d)" % GameState.pool_count("JUGGERNAUT-A"))
	_assert(GameState.platinum == 50,
			"juggernaut price deducted (plat %d)" % GameState.platinum)
	GameState.inventory = saved_inv
	GameState.silver = saved_silver
	GameState.platinum = saved_plat
	GameState.save_settings()

func _check_combat_stats_api() -> void:
	var stats := GameState.combat_stats(GameState.ROBOT_SCARAB)
	_assert(float(stats.get("hp", 0.0)) >= 1.0,
			"combat hp mult >= 1 (%s)" % str(stats.get("hp")))
	_assert(float(stats.get("damage", 0.0)) >= 1.0,
			"combat damage mult >= 1 (%s)" % str(stats.get("damage")))
	_assert(float(stats.get("fire_rate", 0.0)) >= 1.0,
			"combat fire rate mult >= 1 (%s)" % str(stats.get("fire_rate")))
	_assert(float(stats.get("speed", 0.0)) >= 1.0,
			"combat speed mult >= 1 (%s)" % str(stats.get("speed")))
	_assert(float(stats.get("cooldown", 9.0)) <= 1.0,
			"combat cooldown mult <= 1 (%s)" % str(stats.get("cooldown")))
	_assert(float(stats.get("defense", 0.0)) <= 1.0,
			"combat defense mult <= 1 (%s)" % str(stats.get("defense")))
	_assert(GameState.BASE_REGEN == 0.0,
			"robots have no free self-repair (BASE_REGEN=%s)" % str(GameState.BASE_REGEN))
	_assert(float(stats.get("regen", -1.0)) >= 0.0,
			"combat regen comes only from drone/pilot/spec (%s)" % str(stats.get("regen")))
	var razor := WeaponData.for_item("RAZOR-M")
	var razor_net := razor.heat_per_shot * (razor.shots_per_minute / 60.0) - razor.cooldown_rate
	_assert(razor_net > 0.0 and razor_net < 0.15,
			"autocannon overheat window is gentle (%.3f per second)" % razor_net)
	var base := WeaponData.for_item("RAZOR-M")
	var scaled := WeaponData.for_item("RAZOR-M")
	GameState.apply_combat_stats(scaled)
	_assert(scaled.damage >= base.damage * 0.99,
			"combat stats never nerf damage (%.1f vs %.1f)" % [scaled.damage, base.damage])
	_assert(scaled.shots_per_minute >= base.shots_per_minute * 0.99,
			"combat stats never nerf fire rate (%.0f vs %.0f)" % [
				scaled.shots_per_minute, base.shots_per_minute])
	var titan_stats := GameState.combat_stats(GameState.ROBOT_PRAETOR)
	_assert(float(titan_stats.get("hp", 0.0)) >= 1.0, "titan combat hp mult >= 1")

func _check_inventory_api() -> void:
	var saved_inventory: Dictionary = GameState.inventory.duplicate(true)
	var saved_loadout: Array = (GameState.loadouts[GameState.ROBOT_SCARAB] as Array).duplicate()
	var saved_upgrades: Dictionary = GameState.upgrades.duplicate(true)
	_assert(GameState.equipped_count("RAZOR-M") == 2,
			"two RAZOR-M mounted by default (%d)" % GameState.equipped_count("RAZOR-M"))
	_assert(GameState.pool_count("RAZOR-M") >= GameState.equipped_count("RAZOR-M"),
			"owned includes mounted copies (%d >= %d)" % [
				GameState.pool_count("RAZOR-M"), GameState.equipped_count("RAZOR-M")])
	_assert(GameState.free_copies("RAZOR-M") >= 0, "free copies never negative")
	_assert(GameState.equip_item(GameState.ROBOT_SCARAB, 2, "RAZOR-M"),
			"RAZOR-M equippable into third slot")
	_assert(GameState.equip_item(GameState.ROBOT_SCARAB, 3, "RAZOR-M"),
			"RAZOR-M equippable into fourth slot")
	_assert(GameState.filled_slots(GameState.ROBOT_SCARAB) == 4,
			"four hardpoints filled (%d)" % GameState.filled_slots(GameState.ROBOT_SCARAB))
	_assert(GameState.equipped_count("RAZOR-M") == 4,
			"four RAZOR-M stacked on scarab (%d)" % GameState.equipped_count("RAZOR-M"))
	GameState.inventory["MAUL-M"] = GameState.equipped_count("MAUL-M")
	_assert(GameState.free_copies("MAUL-M") == 0, "MAUL-M fully mounted, none free")
	_assert(not GameState.equip_item(GameState.ROBOT_SCARAB, 0, "MAUL-M"),
			"equip refuses when no free copies")
	_assert(not GameState.available_items_for_slot(GameState.ROBOT_SCARAB, 0).has("MAUL-M"),
			"assign list hides items with no free copies")
	GameState.inventory["MAUL-M"] = 10
	var key := GameState.upgrade_key(GameState.ROBOT_SCARAB, 0)
	GameState.upgrades[key] = Vector2i(3, 12)
	_assert(GameState.equip_item(GameState.ROBOT_SCARAB, 0, "MAUL-M"),
			"MAUL-M equippable with free copies")
	_assert(not GameState.upgrades.has(key), "upgrade track reset on weapon change")
	_assert(GameState.upgrade_state(key) == Vector2i(1, 1),
			"reset track defaults to MK1 lv1")
	var total_before := GameState.pool_count("MAUL-M")
	_assert(GameState.unequip_item(GameState.ROBOT_SCARAB, 0) == "MAUL-M",
			"unequip returns item id")
	_assert(GameState.pool_count("MAUL-M") == total_before,
			"unequip keeps total ownership (%d)" % total_before)
	GameState.loadouts[GameState.ROBOT_SCARAB] = saved_loadout
	GameState.inventory = saved_inventory
	GameState.upgrades = saved_upgrades
	GameState.save_settings()

func _check_status_feed() -> void:
	var feed := _game.find_child("StatusFeed", true, false) as Control
	_assert(feed != null, "bottom status feed present in the HUD")
	if feed == null:
		return
	_assert(feed.has_method("push") and feed.has_method("line_count"),
			"status feed API exposed")
	feed.call("push", "SMOKE STATUS LINE")
	_assert(_feed_has_text(feed, "SMOKE STATUS LINE"),
			"status line appears on push")
	_assert(int(feed.call("line_count")) <= 4,
			"status feed respects its line cap (%d)" % int(feed.call("line_count")))
	Events.enemy_killed.emit(999)
	_assert(_feed_has_text(feed, "HOSTILE DESTROYED"),
			"kill event reaches the red status feed")
	var rect := feed.get_global_rect()
	var viewport_size := get_viewport().get_visible_rect().size
	_assert(rect.position.y > viewport_size.y * 0.7,
			"status feed sits along the bottom band (%.0f)" % rect.position.y)
	_assert(rect.end.y <= viewport_size.y + 1.0,
			"status feed inside the viewport (%s)" % rect)
	_assert(absf((rect.position.x + rect.end.x) * 0.5 - viewport_size.x * 0.5) < 4.0,
			"status feed centred on screen (%.0f)" % ((rect.position.x + rect.end.x) * 0.5))

func _feed_has_text(feed: Control, needle: String) -> bool:
	var stack := feed.find_child("Lines", false, false)
	if stack == null:
		return false
	for line: Node in stack.get_children():
		if line is Label and String((line as Label).text).contains(needle):
			return true
	return false

func _check_hardware_profile() -> void:
	var recommended := Hardware.recommended_tier()
	_assert(recommended >= 0 and recommended <= 3,
			"hardware recommendation in tier range (%d)" % recommended)
	var fx := Hardware.fx_scale()
	_assert(fx >= 0.5 and fx <= 1.5, "fx budget scale sane (%.2f)" % fx)
	_assert(Hardware.cpu_cores() >= 1, "cpu core count detected (%d)" % Hardware.cpu_cores())
	_assert(not Hardware.short_label().is_empty(), "hardware short label built")
	_assert(Hardware.describe().contains("GPU"), "hardware description built")
	# AUTO tier cycle: AUTO → LOW → MEDIUM → HIGH → ULTRA → AUTO
	var saved_auto := GameState.quality_auto
	var saved_tier := GameState.selected_quality
	GameState.quality_auto = true
	var label := Quality.tier_label()
	_assert(label.begins_with("AUTO"), "tier label shows AUTO state (%s)" % label)
	var stepped := Quality.cycle_tier()
	_assert(not GameState.quality_auto and stepped == Quality.Tier.LOW,
			"AUTO cycle steps down to LOW (%d)" % stepped)
	stepped = Quality.cycle_tier()
	_assert(stepped == Quality.Tier.MEDIUM, "tier cycle reaches MEDIUM (%d)" % stepped)
	stepped = Quality.cycle_tier()
	_assert(stepped == Quality.Tier.HIGH, "tier cycle reaches HIGH (%d)" % stepped)
	stepped = Quality.cycle_tier()
	_assert(stepped == Quality.Tier.ULTRA, "tier cycle reaches ULTRA (%d)" % stepped)
	stepped = Quality.cycle_tier()
	_assert(GameState.quality_auto and stepped == Hardware.recommended_tier(),
			"tier cycle wraps back to AUTO at recommendation (%d)" % stepped)
	GameState.quality_auto = saved_auto
	GameState.selected_quality = saved_tier
	_assert(not Quality.tier_label().contains("AUTO") or saved_auto,
			"tier label leaves AUTO when manual mode restored (%s)" % Quality.tier_label())

func _check_loading_screen() -> void:
	# WR-style deploy briefing: hero map name, mode chips, two column roster,
	# honest progress — built headlessly so a layout regression fails CI.
	var screen := LoadingScreen.new()
	screen.name = "SmokeLoadingScreen"
	get_tree().root.add_child(screen)
	var hero := screen.get_node_or_null(
			"LoadingRoot/HeroBand/MapName") as Label
	_assert(hero != null and hero.text == "OPEN REALM",
			"deploy screen leads with the map name (%s)" % (
				hero.text if hero != null else "missing"))
	var chips := screen.get_node_or_null("LoadingRoot/HeroBand/ModeChips")
	_assert(chips != null and chips.get_child_count() == 3,
			"deploy screen carries three mode chips (%d)" % (
				chips.get_child_count() if chips != null else 0))
	if chips != null and chips.get_child_count() == 3:
		var hostile_chip := (chips.get_child(1) as PanelContainer) \
				.get_child(0) as Label
		_assert(hostile_chip != null and hostile_chip.text ==
				"%d HOSTILES" % EnemyRobot.KIND_PATTERN.size(),
				"hostile chip matches the spawn pattern (%s)" % (
					hostile_chip.text if hostile_chip != null else "?"))
	var allies := screen.get_node_or_null(
			"LoadingRoot/RosterRow/AlliesPanel/AlliesCard")
	_assert(allies != null, "deploy screen shows the allies card")
	var hostiles := screen.get_node_or_null(
			"LoadingRoot/RosterRow/HostilesPanel/HostilesCard")
	_assert(hostiles != null, "deploy screen shows the hostile roster")
	if hostiles != null:
		var seen := {}
		for kind in EnemyRobot.KIND_PATTERN:
			seen[kind] = true
		_assert(hostiles.get_child_count() == seen.size() + 1,
				"roster lists every hostile class (%d rows)" % (
					hostiles.get_child_count() - 1))
		var header := hostiles.get_child(0) as Label
		_assert(header != null and header.text.ends_with(
				str(EnemyRobot.KIND_PATTERN.size())),
				"roster header totals the hostiles (%s)" % (
					header.text if header != null else "?"))
	screen.set_progress(0.5, "BUILDING OPEN REALM")
	var percent := screen.get_node_or_null(
			"LoadingRoot/BottomBlock/StageRow/PercentLabel") as Label
	_assert(percent != null and percent.text == "50%",
			"deploy progress percent updates (%s)" % (
				percent.text if percent != null else "?"))
	var stage := screen.get_node_or_null(
			"LoadingRoot/BottomBlock/StageRow/StageLabel") as Label
	_assert(stage != null and stage.text == "BUILDING OPEN REALM",
			"deploy progress stage updates (%s)" % (
				stage.text if stage != null else "?"))
	var fill := screen.get_node_or_null(
			"LoadingRoot/BottomBlock/ProgressTrack/ProgressFill") as ColorRect
	_assert(fill != null and absf(fill.anchor_right - 0.5) < 0.001,
			"deploy progress fill tracks the ratio (%.3f)" % (
				fill.anchor_right if fill != null else -1.0))
	var tip := screen.get_node_or_null("LoadingRoot/BottomBlock/TipLine") as Label
	_assert(tip != null and tip.text.begins_with("TIP  //"),
			"deploy screen rotates its tips (%s)" % (
				tip.text if tip != null else "?"))
	screen.dismiss()

func _check_input_responsiveness() -> void:
	var ability_events := [0]
	var on_ability := func() -> void:
		ability_events[0] += 1
	Events.ability_requested.connect(on_ability)
	InputRouter.look_delta = Vector2.ZERO
	InputRouter.look_touch_index = -1
	var viewport_size := get_viewport().get_visible_rect().size
	var right := Vector2(viewport_size.x * 0.7, viewport_size.y * 0.5)
	var press := InputEventScreenTouch.new()
	press.index = 3
	press.position = right
	press.pressed = true
	InputRouter._unhandled_input(press)
	var release := InputEventScreenTouch.new()
	release.index = 3
	release.position = right
	release.pressed = false
	InputRouter._unhandled_input(release)
	_assert(ability_events[0] == 0,
			"look-zone tap no longer fires the ability (%d)" % ability_events[0])
	var drag_press := InputEventScreenTouch.new()
	drag_press.index = 4
	drag_press.position = right
	drag_press.pressed = true
	InputRouter._unhandled_input(drag_press)
	var drag := InputEventScreenDrag.new()
	drag.index = 4
	drag.position = right + Vector2(60.0, -30.0)
	drag.relative = Vector2(60.0, -30.0)
	InputRouter._unhandled_input(drag)
	var look := InputRouter.consume_look()
	_assert(look.length() > 0.01, "look drag still rotates the camera (%.3f)" % look.length())
	InputRouter.look_touch_index = -1
	InputRouter.consume_look()
	InputRouter.set_virtual_fire(true)
	InputRouter._process(0.016)
	_assert(InputRouter.fire_held, "fire input registers immediately")
	InputRouter.set_virtual_fire(false)
	InputRouter._process(0.016)
	_assert(not InputRouter.fire_held, "fire release registers immediately")
	InputRouter.request_ability()
	InputRouter._physics_process(0.016)
	_assert(ability_events[0] == 1, "ability button path still fires (%d)" % ability_events[0])
	Events.ability_requested.disconnect(on_ability)
	# Desktop look: hold RMB and drag.
	var rmb := InputEventMouseButton.new()
	rmb.button_index = MOUSE_BUTTON_RIGHT
	rmb.pressed = true
	InputRouter._unhandled_input(rmb)
	var motion := InputEventMouseMotion.new()
	motion.relative = Vector2(42.0, -21.0)
	InputRouter._unhandled_input(motion)
	var mouse_look := InputRouter.consume_look()
	_assert(mouse_look.length() > 0.01,
			"RMB drag looks around on desktop (%.3f)" % mouse_look.length())
	rmb.pressed = false
	InputRouter._unhandled_input(rmb)
	InputRouter.consume_look()
	# Per-segment slot firing reaches the input router immediately.
	InputRouter.set_virtual_slot(2, true)
	InputRouter._process(0.016)
	_assert(InputRouter.slot_held[2], "slot 2 press reaches the weapon system")
	InputRouter.set_virtual_slot(2, false)
	InputRouter._process(0.016)
	_assert(not InputRouter.slot_held[2], "slot 2 release clears immediately")
	# Controller bindings shipped in code (no OS driver wiring needed).
	var accept_has_joy := false
	for event in InputMap.action_get_events(&"ui_accept"):
		if event is InputEventJoypadButton \
				and (event as InputEventJoypadButton).button_index == JOY_BUTTON_A:
			accept_has_joy = true
	_assert(accept_has_joy, "ui_accept bound to pad A")
	var cancel_has_b := false
	for event in InputMap.action_get_events(&"ui_cancel"):
		if event is InputEventJoypadButton \
				and (event as InputEventJoypadButton).button_index == JOY_BUTTON_B:
			cancel_has_b = true
	_assert(cancel_has_b, "ui_cancel bound to pad B (back)")
	var pause_has_start := false
	for event in InputMap.action_get_events(&"pause"):
		if event is InputEventJoypadButton \
				and (event as InputEventJoypadButton).button_index == JOY_BUTTON_START:
			pause_has_start = true
	_assert(pause_has_start, "pause bound to pad START")
	var lock_has_y := false
	for event in InputMap.action_get_events(&"lock_cycle"):
		if event is InputEventJoypadButton \
				and (event as InputEventJoypadButton).button_index == JOY_BUTTON_Y:
			lock_has_y = true
	_assert(lock_has_y, "lock cycle bound to pad Y")
	# Emulated desktop touches (emulate_touch_from_mouse) must not steer the
	# camera while keyboard/mouse is the live mode — the Windows "robot plays
	# itself" bug: every click became a look drag.
	var saved_mode := PlatformUtil.current_mode
	PlatformUtil.set_mode(PlatformUtil.InputMode.KEYBOARD)
	InputRouter.look_touch_index = -1
	InputRouter.look_delta = Vector2.ZERO
	var ghost := InputEventScreenTouch.new()
	ghost.index = 6
	ghost.position = right
	ghost.pressed = true
	InputRouter._unhandled_input(ghost)
	var ghost_drag := InputEventScreenDrag.new()
	ghost_drag.index = 6
	ghost_drag.position = right + Vector2(50.0, -20.0)
	ghost_drag.relative = Vector2(50.0, -20.0)
	InputRouter._unhandled_input(ghost_drag)
	var ghost_look := InputRouter.consume_look()
	_assert(ghost_look == Vector2.ZERO,
			"emulated desktop touch cannot steer the camera (%s)" % ghost_look)
	_assert(InputRouter.look_touch_index == -1,
			"no look touch claimed while keys/mouse are live")
	PlatformUtil.set_mode(saved_mode)
	InputRouter.consume_look()

# Spec phases 2-10: one physical event must never drive two subsystems, and
# no source may emit input while it is not the live input source.
func _check_input_ownership() -> void:
	var mode_before := PlatformUtil.current_mode
	# Phase 2/4: `fire` is keyboard + pad only. The mouse is its own event
	# stream, so a click a Control already consumed cannot fire the guns.
	var mouse_bound := false
	for event in InputMap.action_get_events(&"fire"):
		if event is InputEventMouseButton:
			mouse_bound = true
	_assert(not mouse_bound, "fire action is no longer bound to the mouse button")

	# Phase 9: only an unconsumed LMB press arms mouse fire; the release is
	# read pre-GUI so a Control sitting under the cursor cannot swallow it.
	# A real mouse press arrives as [Touch twin, LMB] — feed the twin first.
	InputRouter._mouse_fire = false
	var twin := InputEventScreenTouch.new()
	twin.index = 0
	twin.pressed = true
	InputRouter._input(twin)
	var lmb := InputEventMouseButton.new()
	lmb.button_index = MOUSE_BUTTON_LEFT
	lmb.pressed = true
	InputRouter._unhandled_input(lmb)
	_assert(InputRouter._mouse_fire, "unconsumed LMB press arms mouse fire")
	# A finger press arrives as [LMB twin, Touch] — the twin must never fire.
	# This is the "touching anywhere autoshoots / every wheel button fires"
	# bug on the shipped builds.
	InputRouter._touch_twin_seen = false
	InputRouter._mouse_fire = false
	InputRouter._unhandled_input(lmb)
	_assert(not InputRouter._mouse_fire,
			"an emulated LMB with no touch twin cannot arm mouse fire")
	# The frame ends, the twin ordering starts over.
	InputRouter._process(0.016)
	_assert(not InputRouter._touch_twin_seen,
			"the touch-twin flag is cleared every frame")
	InputRouter._input(twin)
	InputRouter._unhandled_input(lmb)
	_assert(InputRouter._mouse_fire,
			"the next frame's real mouse press still arms mouse fire")
	var lmb_up := InputEventMouseButton.new()
	lmb_up.button_index = MOUSE_BUTTON_LEFT
	lmb_up.pressed = false
	InputRouter._input(lmb_up)
	_assert(not InputRouter._mouse_fire, "LMB release clears mouse fire")
	# A release that somehow never arrives must still be caught by the
	# per-frame resync against the real button state.
	InputRouter._mouse_fire = true
	InputRouter._process(0.016)
	_assert(not InputRouter._mouse_fire and not InputRouter.fire_held,
			"stuck mouse fire is re-synced against the real button state")

	# Phase 3: radial deadzone with a rescaled exit (no 0 -> dz jump) and
	# a hard clamp so a saved 0.99 cannot disable the dead zone.
	_assert(InputRouter._radial_deadzone(Vector2(0.10, 0.0), 0.15) == Vector2.ZERO,
			"input inside the deadzone is zero")
	var outside := InputRouter._radial_deadzone(Vector2(0.30, 0.0), 0.15)
	_assert(absf(outside.length() - (0.30 - 0.15) / 0.85) < 0.01,
			"deadzone exit is rescaled, not a jump (%.4f)" % outside.length())
	var clamped := InputRouter._radial_deadzone(Vector2(1.0, 0.0), 0.99)
	_assert(absf(clamped.length() - 1.0) < 0.01,
			"deadzone above the maximum is clamped (%.4f)" % clamped.length())

	var dz_left := GameState.pad_deadzone_left
	var dz_right := GameState.pad_deadzone_right
	GameState.set_pad_deadzone_left(0.99)
	_assert(is_equal_approx(GameState.pad_deadzone_left, GameState.DEADZONE_MAX)
			and is_equal_approx(InputRouter.pad_deadzone_left, GameState.DEADZONE_MAX),
			"left deadzone clamps to %.2f and syncs into the router"
			% GameState.DEADZONE_MAX)
	GameState.set_pad_deadzone_right(0.01)
	_assert(is_equal_approx(GameState.pad_deadzone_right, GameState.DEADZONE_MIN)
			and is_equal_approx(InputRouter.pad_deadzone_right, GameState.DEADZONE_MIN),
			"right deadzone clamps to %.2f and syncs into the router"
			% GameState.DEADZONE_MIN)
	GameState.set_pad_deadzone_left(dz_left)
	GameState.set_pad_deadzone_right(dz_right)

	# Phase 6: unplugging mid-input must not leave a ghost vector behind.
	InputRouter.move_vector = Vector2(0.4, 0.9)
	InputRouter.look_delta = Vector2(0.5, 0.5)
	InputRouter.look_touch_index = 7
	InputRouter._reset_pad_state()
	_assert(InputRouter.move_vector == Vector2.ZERO
			and InputRouter.look_delta == Vector2.ZERO
			and InputRouter.look_touch_index == -1,
			"pad reset clears stale move/look input")

	# Phase 10: the development diagnostics line renders and names sources.
	var diagnostics := InputRouter.input_snapshot()
	_assert(diagnostics.find("SRC ") >= 0 and diagnostics.find("FIRE ") >= 0
			and diagnostics.find("DZ ") >= 0,
			"input diagnostics snapshot renders (%s)" % diagnostics)
	PlatformUtil.set_mode(mode_before)
	InputRouter.consume_look()

# Phase 12: Godot rejects amount < 1 with a hard on-device error
# ("Amount of particles must be greater than 0"). Every emitter that is
# actually in the tree must therefore be >= 1.
func _check_particle_amounts() -> void:
	var bad: Array[String] = []
	for node in get_tree().root.find_children("*", "CPUParticles3D", true, false):
		var amount := int(node.get("amount"))
		if amount < 1:
			bad.append("CPUParticles3D@%s" % String(node.get_path()))
	_assert(bad.is_empty(),
			"every particle emitter in the tree has amount >= 1 (%s)" % str(bad))
